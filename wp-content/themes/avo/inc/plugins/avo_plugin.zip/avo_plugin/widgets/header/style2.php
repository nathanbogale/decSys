

<div class="avo-title style-2 <?php echo $avo_rtl;?>">
	<h2 class=" <?php echo  $settings['animation']; ?> custom-font" <?php if($avo_rtl==''){echo"data-splitting";} ?>><?php echo  $settings['title_1']; ?> <b><?php echo  $settings['title_2']; ?></b>.</h2>
</div>