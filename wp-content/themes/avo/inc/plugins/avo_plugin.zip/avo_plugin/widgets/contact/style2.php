		<div class="avo-contact-shortcode style-2 <?php echo 'mode-'.$settings['avo_mode'];?>"><?php echo $shortcode; ?></div>
