<div class="avo-offcanvas style-2">
	<div class="menu-icon">
	    <span class="icon">
	        <i></i>
	        <i></i> 
	    </span>
	    <span class="text o" data-splitting><?php echo $settings['title']; ?></span>
	    <span class="text c" data-splitting><?php echo $settings['subtitle']; ?></span>
	</div>
</div>