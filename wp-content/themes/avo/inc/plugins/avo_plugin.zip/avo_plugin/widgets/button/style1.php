

<a href="<?php echo esc_url( $settings['link']['url']); ?>" class="button style-1 btn-lit <?php echo 'mode-'.$settings['avo_mode'];?>" data-wow-delay=".5s">

	<span><?php echo  $settings['btn_text']; ?></span>
</a>