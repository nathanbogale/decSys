<?php

/**
* WPBakery Page Builder Avo Heading shortcode view 
*/

?>
<div class="avo-heading-sc heading">
	<?php echo $title; ?>
</div>