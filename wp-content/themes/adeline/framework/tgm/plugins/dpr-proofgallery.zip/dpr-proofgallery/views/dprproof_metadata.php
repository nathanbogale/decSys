<?php
/**
 * Template used to display the dprproof gallery
 *
 * @global string       $client_name
 * @global string       $event_date
 * @global int          $number_of_images
 * @global string       $file
 */
?>
<div id="dprproof_data" class="dprproof-data">
	<div class="proof-meta-data">
		<?php if ( ! empty( $client_name ) ) { ?>
		<div class="entry__meta-box">
			<h6 class="meta-box__title"><?php esc_attr_e( 'Client','dprproof' );?></h6>
			<span><?php echo $client_name; ?></span>
		</div>

		<?php
		}
		if ( ! empty( $event_date ) ) { ?>
		<div class="entry__meta-box">
			<h6 class="meta-box__title"><?php esc_html_e( 'Event date','dprproof' );?></h6>
			<span><?php echo $event_date; ?></span>
		</div>
		<?php
		}
		if ( ! empty( $number_of_images ) ) { ?>
		<div class="entry__meta-box">
			<h6 class="meta-box__title"><?php esc_html_e( 'Images','dprproof' );?></h6>
			<span><?php echo $number_of_images; ?></span>
		</div>
		<?php
		}


		if ( ! empty( $file ) || ! empty( $pdf )) { ?>
		<div class="entry__meta-box aligned-right">
			<?php if ( ! empty( $file )) { ?>
			<button class="button-download button btn-lg js-download" onclick="window.open('<?php echo $file; ?>')"><?php esc_html_e( 'Download ZIP','dprproof' ); ?></button>
			<?php } 
			if ( ! empty( $pdf ) ) { ?>
			<button class="button-download button btn-lg js-download" onclick="window.open('<?php echo $pdf; ?>')"><?php esc_html_e( 'Download PDF','dprproof' ); ?></button>
			<?php } ?>
		</div>
		<?php } ?>
	</div>
	<hr class="separator  separator--data"/>
<?php
