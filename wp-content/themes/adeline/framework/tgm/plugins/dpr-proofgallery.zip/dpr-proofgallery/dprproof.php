<?php
/**
 * @wordpress-plugin
 * Plugin Name: DPR Proof Gallery
 * Description: WordPress photo gallery proofing plugin. Based on <a href="https://wordpress.org/plugins/dprproof/" target ="_blank">PixProof by Pixelgrade</a> modified by Dynamicpress.
 * Version: 1.0
 * Author: Pixelgrade/DynamicPress
 * Text Domain: dprproof
 * License:     GPL-2.0+
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 * Domain Path: /lang
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/*

 * Admin notice text

 */

function _admin_notice__error() {

	echo '<div class="notice notice-error is-dismissible">';

		echo '<p>'. esc_html__( 'DPR Proof Gallery plugin is enabled but not effective. It requires Yvon theme in order to work.', 'dpr-adeline-extensions' ) .'</p>';

	echo '</div>';

}


$theme = wp_get_theme();
if ( 'Yvon' == $theme->name || 'adeline' == $theme->template ) {

require_once( plugin_dir_path( __FILE__ ) . 'includes/lib/abstracts/class-Dprproof_Singleton_Registry.php' );
require_once( plugin_dir_path( __FILE__ ) . 'includes/lib/abstracts/class-Dprproof_Plugin_Init.php' );
require_once( plugin_dir_path( __FILE__ ) . 'includes/lib/class-Dprproof_Array.php' );
require_once( plugin_dir_path( __FILE__ ) . 'includes/lib/class-Dprproof_Create_Archive.php' );
require_once( plugin_dir_path( __FILE__ ) . 'extras.php' );
require_once( plugin_dir_path( __FILE__ ) . 'includes/deprecated.php' );

/**
 * Returns the main instance of Dprproof_Plugin to prevent the need to use globals.
 *
 * @since  1.0.0
 * @return Dprproof_Plugin Dprproof_Plugin instance.
 */
function Dprproof_Plugin() {
	require_once( plugin_dir_path( __FILE__ ) . 'includes/class-Dprproof_Plugin.php' );

	return Dprproof_Plugin::getInstance( __FILE__, '1.0' );
}

global $dprproof_plugin;
$dprproof_plugin = Dprproof_Plugin();

} else {

add_action('admin_notices', '_admin_notice__error');

}
