<?php
/**
 * Deprecated stuff.
 *
 * 
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! class_exists( 'DprProofPlugin' ) ) {
	/**
	 * @deprecated Use Dprproof or Dprproof_Plugin class instead.
	 */
	class DprProofPlugin {
		static function get_attachment_class( $attachment ) {
			_deprecated_function( __METHOD__, '1.0', 'Use Dprproof::get_attachment_class() instead.' );
			return Dprproof::get_attachment_class( $attachment );
		}

		static function attachment_class( $attachment ) {
			_deprecated_function( __METHOD__, '1.0', 'Use Dprproof::attachment_class() instead.' );
			echo Dprproof::attachment_class( $attachment );
		}

		static function attachment_data( $attachment ) {
			_deprecated_function( __METHOD__, '1.0', 'Use Dprproof::attachment_data() instead.' );
			echo Dprproof::attachment_data( $attachment );
		}

		static function set_number_of_images( $number_of_images ) {
			_deprecated_function( __METHOD__, '1.0', 'Use Dprproof::set_number_of_images() instead.' );
			return Dprproof::set_number_of_images( $number_of_images );
		}

		static function get_number_of_images() {
			_deprecated_function( __METHOD__, '1.0', 'Use Dprproof::get_number_of_images() instead.' );
			return Dprproof::get_number_of_images();
		}

		static function get_thumbnails_size() {
			_deprecated_function( __METHOD__, '1.0', 'Use Dprproof::get_thumbnails_size() instead.' );
			return Dprproof::get_thumbnails_size();
		}

		static function get_gallery_grid_size() {
			_deprecated_function( __METHOD__, '1.0', 'Use Dprproof::get_gallery_grid_size() instead.' );
			return Dprproof::get_gallery_grid_size();
		}

		static function has_global_style() {
			_deprecated_function( __METHOD__, '1.0', 'Use Dprproof::has_global_style() instead.' );
			return Dprproof::has_global_style();
		}
	}

}

