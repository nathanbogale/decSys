<?php
/**
 * Document for class Dprproof.
 *
 * 
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! class_exists( 'Dprproof' ) ) :

/**
 * This is the class that handles the overall logic for the Dprproof.
 *
 

 
 */
class Dprproof extends Dprproof_Singleton_Registry {

	protected static $number_of_images;

	/**
	 * Constructor.
	 *
	 * @since 1.0
	 *
	 * @param $parent
	 */
	protected function __construct( $parent = null ) {
		// We need to initialize at this action so we can do some checks before hooking up.
		add_action( 'plugins_loaded', array( $this, 'init' ), 1 );
	}

	/**
	 * Initialize this module.
	 *
	 * @since 1.0
	 */
	public function init() {

		if ( ! self::check_setup() ) {
			return;
		}

		// Hook up.
		$this->add_hooks();
	}

	/**
	 * Check if everything needed for the core plugin logic is in place.
	 *
	 * @return bool
	 */
	public static function check_setup() {
		global $pagenow;

		$all_good = true;

		// Check if we can create zip archives, but only in the admin settings.
		if ( $pagenow === 'options-general.php' ) {
			$zip_test_filename = trailingslashit( get_temp_dir() ) . 'dprprooftest.zip';
			if ( ! file_exists( $zip_test_filename ) ) {
				try {
					$zip_archive = new Dprproof_Create_Archive( $zip_test_filename );
					// We will add this file so the archive holds something.
					$zip_archive->add_file( __FILE__, 'test.php' );
				} catch ( Exception $exception ) {
					Dprproof_Plugin::add_admin_notice( 'Dprproof::zip_cap_error_notice' );
					$all_good = false;
				}

				$zip_archive->close();

				unset( $zip_archive );
			}
		}

		return $all_good;
	}

	/**
	 * Initiate our hooks
	 *
	 * @since 1.0
	 */
	public function add_hooks() {

		add_action( 'init', array( $this, 'register_post_types' ), 99999 );

		add_action( 'cmb2_admin_init', array( $this, 'proof_gallery_metaboxes' ) );

		// Load admin dashboard stylesheets and scripts, dedicated to edit post.
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts_and_styles' ) );

		// Load public-facing style sheet and JavaScript.
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_styles' ), 99999999999 );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );

		/*
		 * FRONTEND RELATED
		 */
		// a little hook into the_content
		add_filter( 'the_content', array( $this, 'hook_into_the_content' ), 10, 1 );

		add_filter( 'dprproof_filter_gallery_filename', array( $this, 'prepare_the_gallery_name' ), 10, 4 );

		// parse comments to find referances for images
		add_filter( 'comment_text', array( $this, 'parse_comments' ) );

		// AJAX callbacks
		add_action( 'wp_ajax_dprproof_image_click', array( &$this, 'ajax_click_on_photo' ) );
		add_action( 'wp_ajax_nopriv_dprproof_image_click', array( &$this, 'ajax_click_on_photo' ) );
		add_action( 'wp_ajax_dprproof_zip_file_url', array( &$this, 'generate_photos_zip_file' ) );
		add_action( 'wp_ajax_nopriv_dprproof_zip_file_url', array( &$this, 'generate_photos_zip_file' ) );
		add_action( 'wp_ajax_dprproof_generate_pdf', array( &$this, 'generate_photos_pdf_file' ) );
		add_action( 'wp_ajax_nopriv_dprproof_generate_pdf', array( &$this, 'generate_photos_pdf_file' ) );		
	}

	/**
	 * Display an admin error notice if we can't create zip archives.
	 */
	public static function zip_cap_error_notice() {
		?>
		<div class="error notice">
			<p><?php esc_html_e( 'Something is wrong! Dprproof is not able to create .zip archives. Please contact your host and ask them to make sure that your WP installation can create zip archives via PHP.', 'dprproof' ); ?></p>
		</div>
		<?php
	}

	public function register_post_types() {

		// Bail if the CPT is not enabled.
		if ( dprproof_get_setting( 'enable_dprproof_gallery', 'on' ) !== 'on' ) {
			return;
		}

		$slug = 'proof_gallery';
		if ( dprproof_get_setting( dprproof_prefix( 'change_single_item_slug' ) ) === 'on' ) {
			$slug = dprproof_get_setting( dprproof_prefix( 'gallery_new_single_item_slug' ) );
		}

		$labels = apply_filters( 'dprproof_proof_gallery_cpt_labels', array(
			'name'               => dprproof_get_setting( dprproof_prefix( 'multiple_items_label' ), esc_html__( 'Proof Galleries', 'dprproof' ) ),
			'singular_name'      => dprproof_get_setting( dprproof_prefix( 'single_item_label' ), esc_html_x( 'Proof Gallery', 'Post Type Single Item Name', 'dprproof' ) ),
			'menu_name'          => dprproof_get_setting( dprproof_prefix( 'multiple_items_label' ), esc_html__( 'Proof Galleries', 'dprproof' ) ),
			'parent_item_colon'  => esc_html__( 'Parent Item:', 'dprproof' ),
			'all_items'          => esc_html__( 'All Items', 'dprproof' ),
			'view_item'          => esc_html__( 'View Item', 'dprproof' ),
			'add_new_item'       => esc_html__( 'Add New Proof Gallery', 'dprproof' ),
			'add_new'            => esc_html__( 'Add New', 'dprproof' ),
			'edit_item'          => esc_html__( 'Edit Proof Gallery', 'dprproof' ),
			'update_item'        => esc_html__( 'Update Proof Gallery', 'dprproof' ),
			'search_items'       => esc_html__( 'Search Proof Galleries', 'dprproof' ),
			'not_found'          => esc_html__( 'Not found', 'dprproof' ),
			'not_found_in_trash' => esc_html__( 'Not found in Trash', 'dprproof' ),
		) );

		$args = apply_filters( 'dprproof_proof_gallery_cpt_args', array(
			'label'               => dprproof_get_setting( dprproof_prefix( 'single_item_label' ), esc_html_x( 'Proof Gallery', 'Post Type Single Item Name', 'dprproof' ) ),
			'description'         => dprproof_get_setting( dprproof_prefix( 'multiple_items_label' ), esc_html__( 'Proof Galleries', 'dprproof' ) ),
			'labels'              => $labels,
			'supports'            => array(
				'title',
				'editor',
				'author',
				'thumbnail',
				'comments',
				'revisions',
				'page-attributes',
			),
			'hierarchical'        => true,
			'public'              => true,
			'show_ui'             => true,
			'show_in_menu'        => true,
			'show_in_nav_menus'   => true,
			'show_in_admin_bar'   => true,
			'menu_position'       => null,
			'menu_icon'           => 'dashicons-camera-alt',
			'can_export'          => true,
			'has_archive'         => false,
			'exclude_from_search' => true,
			'publicly_queryable'  => true,
			'query_var'           => $slug,
			'rewrite'             => array( 'slug' => $slug ),
			'capability_type'     => 'page',
			'yarpp_support'       => false,
		) );

		register_post_type( 'proof_gallery', $args );
	}

	/**
	 * Define the proof_gallery CPT metabox and fields.
	 */
	function proof_gallery_metaboxes() {

		$gallery_metabox = new_cmb2_box( array(
			'id'            => $this->prefix( 'gallery', true ),
			'title'         => esc_html__( 'Proof Gallery', 'dprproof' ),
			'object_types'  => array( 'proof_gallery', ), // Post type
			'context'    => 'normal',
			'priority'   => 'high',
			'show_names' => true, // Show field names on the left
		) );

		$gallery_metabox->add_field( array(
			'name'         => '',
			'id'           => $this->prefix( 'main_gallery', true ),
			'type'         => 'dprproof_gallery',
			'desc'          => esc_html__( 'Manage the photos you wish to share with your client.', 'dprproof'),
		) );

		$gallery_metabox->add_field( array(
			'name' => esc_html__( 'Gallery Position', 'dprproof' ),
			'desc' => esc_html__( 'Where should the photo proofing gallery should be displayed in relation to the content.', 'dprproof' ),
			'id'   => $this->prefix( 'position_in_content', true ),
			'type' => 'select',
			'default' => 'before',
			'options' => array(
				'before' => esc_html__( 'Before the content', 'dprproof' ),
				'after'  => esc_html__( 'After the content', 'dprproof' ),
				'inside' => esc_html__( 'Content inside gallery (between metadata and photos)', 'dprproof' ),
			),
		) );

		$gallery_metabox->add_field( array(
			'name' => esc_html__( 'Filter Alignment', 'dprproof' ),
			'desc' => esc_html__( 'Set Selected/Rejected filter alignment.', 'dprproof' ),
			'id'   => $this->prefix( 'filter_alignment', true ),
			'type' => 'select',
			'default' => 'before',
			'options' => array(
				'left' => esc_html__( 'Left', 'dprproof' ),
				'center'  => esc_html__( 'Center', 'dprproof' ),
				'right'  => esc_html__( 'Right', 'dprproof' )
			),
		) );

		$gallery_metabox->add_field( array(
			'name' => esc_html__( 'Disable Filter', 'dprproof' ),
			'desc' => esc_html__( 'Check this to disable Select/Reject filter for this proof gallery', 'dprproof' ),
			'id'   => $this->prefix( 'disable_filter', true ),
			'type' => 'checkbox',
		) );

		$gallery_metabox->add_field( array(
			'name'         => esc_html__( 'Client Details', 'dprproof' ),
			'id'           => $this->prefix( 'main_gallery_client_title', true ),
			'type'         => 'title',
		) );

		$gallery_metabox->add_field( array(
			'name'       => esc_html__( 'Name', 'dprproof' ),
			'id'         => $this->prefix( 'client_name', true ),
			'type'       => 'text',
		) );

		$gallery_metabox->add_field( array(
			'name' => esc_html__( 'Date', 'dprproof' ),
			'id'   => $this->prefix( 'event_date', true ),
			'type' => 'text_date',
			'desc' => esc_html__( 'Add the date when these photos were taken, if you wish.', 'dprproof' ),
		) );

		$gallery_metabox->add_field( array(
			'name'         => esc_html__( 'Subheader Custom Settings', 'dprproof' ),
			'id'           => $this->prefix( 'main_gallery_subheader_title', true ),
			'type'         => 'title',
		) );

		$gallery_metabox->add_field( array(
			'name'       => esc_html__( 'Custom Title', 'dprproof' ),
			'id'         => $this->prefix( 'subheader_title', true ),
			'type'       => 'text',
			'desc' => esc_html__( 'Add custom title. Will be displayed instead post title in subheader.', 'dprproof' ),
		) );

		$gallery_metabox->add_field( array(
			'name'       => esc_html__( 'Subtitle', 'dprproof' ),
			'id'         => $this->prefix( 'subheader_subtitle', true ),
			'type'       => 'text',
			'desc' => esc_html__( 'Add subtitle for this gallery, if you wish. Will be displayed in subheader.', 'dprproof' ),
		) );
		$gallery_metabox->add_field( array(
			'name'         => esc_html__( 'Advanced', 'dprproof' ),
			'id'           => $this->prefix( 'main_gallery_advanced_title', true ),
			'type'         => 'title',
		) );

		$gallery_metabox->add_field( array(
			'name'    => esc_html__( 'Photos Display Name', 'dprproof' ),
			'desc'    => wp_kses_post( __( 'How would you like to identify each photo?<br>Each photo numeric ID can be used in comments to automatically link to photos in the gallery for easy navigation and clearer conversations.<br>For example, the comment: "I really like the #123 and #276 photos" will have the IDs automatically linked to those photos.<br><strong>Unique IDs</strong> means any photo will be uniquely identified across all your site.<br><strong>Consecutive IDs</strong> means photos in this gallery will be identified with #1, #2, #3, and so on.', 'dprproof' ) ),
			'id'      => $this->prefix( 'photo_display_name', true ),
			'type'    => 'select',
			'show_option_none' => false,
			'options' => array(
				'unique_ids'  => esc_html__( 'Unique IDs', 'dprproof' ),
				'consecutive_ids'  => esc_html__( 'Consecutive IDs', 'dprproof' ),
				'file_name'  => esc_html__( 'File Name', 'dprproof' ),
				'unique_ids_photo_title'  => esc_html__( 'Unique IDs and Photo Title', 'dprproof' ),
				'consecutive_ids_photo_title'  => esc_html__( 'Consecutive IDs and Photo Title', 'dprproof' ),
			),
			'default'     => 'unique_ids',
		) );

		if ( ( dprproof_get_setting( 'enable_archive_zip_download' ) === 'on' && dprproof_get_setting( 'zip_archive_generation' ) === 'manual' ) ) {
			$gallery_metabox->add_field( array(
				'name' => esc_html__( 'Client .zip archive', 'dprproof' ),
				'desc' => esc_html__( 'Upload a .zip archive so the client can download it via the Download link. Leave it empty to hide the link.', 'dprproof' ),
				'id'   => $this->prefix( 'file', true ),
				'type' => 'file',
			) );
		}

		if ( dprproof_get_setting( 'enable_archive_zip_download' ) === 'on' && dprproof_get_setting( 'zip_archive_generation' ) !== 'manual' ) {
			$gallery_metabox->add_field( array(
				'name' => esc_html__( 'Disable Archive Download', 'dprproof' ),
				'desc' => esc_html__( 'Check this to remove the ability to download the zip archive for this gallery', 'dprproof' ),
				'id'   => $this->prefix( 'disable_archive_download', true ),
				'type' => 'checkbox',
			) );

		}
		if ( dprproof_get_setting( 'enable_pdf_download' ) === 'on') {
			$gallery_metabox->add_field( array(
				'name' => esc_html__( 'Disable PDF Download', 'dprproof' ),
				'desc' => esc_html__( 'Check this to remove the ability to download the PDF file for this gallery', 'dprproof' ),
				'id'   => $this->prefix( 'disable_pdf_download', true ),
				'type' => 'checkbox',
			) );
		
		}		
	}

	public function enqueue_admin_scripts_and_styles() {

		if ( ! $this->is_editing_post_type() ) {
			return;
		}

		// The styles.
		wp_register_style( $this->prefix( 'edit-post-style' ), plugins_url( 'assets/css/edit-post.css', Dprproof_Plugin()->get_file() ), array(), Dprproof_Plugin()->get_version() );
		wp_enqueue_style( $this->prefix( 'edit-post-style' ) );
	}

	public function is_editing_post_type() {
		$current_screen = get_current_screen();

		if ( ! empty( $current_screen ) && $current_screen instanceof WP_Screen ) {
			if ( $current_screen->base === 'post' && $current_screen->post_type === 'proof_gallery' ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Register and enqueue public-facing style sheet.
	 
	 */
	function enqueue_styles() {
			wp_enqueue_style( 'dprproof_magnific-popup', plugins_url( 'assets/css/mangnific-popup.css', Dprproof_Plugin()->get_file() ), array(), Dprproof_Plugin()->get_version() );
			wp_enqueue_style( 'dprproof_fonts', plugins_url( 'assets/css/dprproof-fonts.css', Dprproof_Plugin()->get_file() ), array(), Dprproof_Plugin()->get_version() );		
			wp_enqueue_style( 'dprproof_css', plugins_url( 'assets/css/public.css', Dprproof_Plugin()->get_file() ), array(), Dprproof_Plugin()->get_version() );
	}

	/**
	 * Register and enqueues public-facing JavaScript files.
	 
	 */
	public function enqueue_scripts() {

		wp_enqueue_script( dprproof_prefix( 'plugin-script' ), plugins_url( 'assets/js/public.js', Dprproof_Plugin()->get_file() ), array( 'jquery' ), Dprproof_Plugin()->get_version(), true );
		wp_localize_script( dprproof_prefix( 'plugin-script' ), 'dprproof', array(
			'ajaxurl' => admin_url( 'admin-ajax.php' ),
			'isRTL' => is_rtl(),
			'dprproof_settings' => array(
				'zip_archive_generation' => dprproof_get_setting( 'zip_archive_generation' )
			),
			'l10n' => array(	
				'select' => esc_html__('Select', 'dprproof'),
				'deselect' => esc_html__('Deselect', 'dprproof'),
				'ofCounter' => esc_html__('of ', 'dprproof'),
				'next' => esc_html__('Next', 'dprproof'),
				'previous' => esc_html__('Previous', 'dprproof')
			)
		) );
	}

	public function hook_into_the_content( $content ) {
		if ( get_post_type() !== 'proof_gallery' || post_password_required() ) {
			return $content;
		}

		$gallery  = self::get_gallery();
		$metadata = self::get_metadata();

		if ( get_post_meta( get_the_ID(), '_dprproof_position_in_content', true ) != 'inside' ) {
		$dprproof_output = '<div class="dpr-proof-gallery">' . $metadata . $gallery.'</div>';

		if ( get_post_meta( get_the_ID(), '_dprproof_position_in_content', true ) === 'before' ) {
			return $dprproof_output . $content;
		}

		return $content . $dprproof_output;

		} else {

			$dprproof_output = '<div class="dpr-proof-gallery">' . $metadata . $content . $gallery.'</div>';

			return $dprproof_output;

		}
	}

	static function get_gallery() {
		// get this gallery's metadata
		$gallery_data = get_post_meta( get_the_ID(), '_dprproof_main_gallery', true );
		// quit if there is no gallery data
		if ( empty( $gallery_data ) || ! isset( $gallery_data[ 'gallery' ] ) ) {
			return false;
		}

		/*
		 * All the variables in this function will be available in the scope of the template.
		 */

		$gallery_ids = explode( ',', $gallery_data[ 'gallery' ] );
		if ( empty( $gallery_ids ) ) {
			return false;
		}

		$order = 'post__in';
		if ( isset( $gallery_data[ 'random' ] ) && ( $gallery_data[ 'random' ] === 'true' ) ) {
			$order = 'rand';
		}

		$columns = 3;
		if ( ! empty( $gallery_data[ 'columns' ] ) ) {
			$columns = $gallery_data[ 'columns' ];
		}

		$thumbnails_size = 'thumbnail';
		if ( ! empty( $gallery_data[ 'size' ] ) ) {
			$thumbnails_size = $gallery_data[ 'size' ];
		}


		if ( self::has_global_style() ) {
			$thumbnails_size = self::get_thumbnails_size();
			$columns = self::get_gallery_grid_size();
		}

		// get attachments
		$attachments = get_posts( array(
			'post_status'    => 'any',
			'post_type'      => 'attachment',
			'post__in'       => $gallery_ids,
			'orderby'        => $order,
			'posts_per_page' => '-1'
		) );
		if ( is_wp_error( $attachments ) || empty( $attachments ) ) {
			return false;
		}

		$number_of_images = self::set_number_of_images( count( $attachments ) );

		// Get the settings so they are available in the template.
		$photo_display_name = get_post_meta( get_the_ID(), '_dprproof_photo_display_name', true );

		// Locate the template to be used.
		$template_name    = 'dprproof_gallery.php';
		$_located         = locate_template( 'templates/' . $template_name, false, false );
		// Use the default one if the (child) theme doesn't have it
		if ( ! $_located ) {
			$_located = trailingslashit( Dprproof_Plugin()->get_basepath() ) . 'views/' . $template_name;
		}

		ob_start();
		require $_located;

		return ob_get_clean();
	}

	static function get_metadata() {
		global $post;

		$client_name = get_post_meta( get_the_ID(), '_dprproof_client_name', true );

		$attachments = get_children( array(
			'post_parent'    => $post->post_parent,
			'post_status'    => 'inherit',
			'post_type'      => 'attachment',
			'post_mime_type' => 'image',
			'order'          => 'ASC',
			'orderby'        => 'menu_order ID'
		) );
		$event_date  = get_post_meta( get_the_ID(), '_dprproof_event_date', true );
		$download_is_disabled  = get_post_meta( get_the_ID(), '_dprproof_disable_archive_download', true );
		$pdf_is_disabled  = get_post_meta( get_the_ID(), '_dprproof_disable_pdf_download', true );

		if ( dprproof_get_setting( 'enable_archive_zip_download', 'on' ) === 'on' && $download_is_disabled !== 'on' ) {

			// If the user wants a download link, now we qenerate it
			if ( dprproof_get_setting( 'zip_archive_generation', 'manual' ) === 'manual' ) {
				$file = get_post_meta( get_the_ID(), '_dprproof_file', true );
			} else {
				$file = Dprproof::get_zip_file_url( get_the_ID() );
			}

		}

		if ( dprproof_get_setting( 'enable_pdf_download', 'on' ) === 'on' && $pdf_is_disabled !== 'on' ) {

			// If the user wants a PDF link, now we qenerate it
				$pdf = Dprproof::get_pdf_file_url( get_the_ID() );
		}

		$number_of_images = self::get_number_of_images();

		$template_name = 'dprproof_metadata.php';
		$_located      = locate_template( 'templates/' . $template_name, false, false );
		// Use the default one if the (child) theme doesn't have it
		if ( ! $_located ) {
			$_located = trailingslashit( Dprproof_Plugin()->get_basepath() ) . 'views/' . $template_name;
		}

		ob_start();
		require $_located;

		return ob_get_clean();

	}

	static function get_attachment_class( $attachment ) {

		$data = wp_get_attachment_metadata( $attachment->ID );

		if ( isset( $data[ 'selected' ] ) && ! empty( $data[ 'selected' ] ) && $data[ 'selected' ] == 'true' ) {
			return 'selected';
		}

		return '';
	}

	static function attachment_class( $attachment ) {
		echo self::get_attachment_class( $attachment );
	}

	static function attachment_data( $attachment ) {

		if ( empty( $attachment->ID ) ) {
			return;
		}

		$output = ' data-attachment_id="' . esc_attr( $attachment->ID ) . '"';

		echo $output;
	}

	static function set_number_of_images( $number_of_images ) {
		return self::$number_of_images = $number_of_images;
	}

	static function get_number_of_images() {
		return self::$number_of_images;
	}

	static function get_thumbnails_size() {
		return dprproof_get_setting( 'gallery_thumbnail_sizes', 'thumbnail' );
	}

	static function get_gallery_grid_size() {
		return dprproof_get_setting( 'gallery_grid_sizes', '3' );
	}

	static function has_global_style() {
		return dprproof_get_setting( 'enable_dprproof_gallery_global_style', 'off' ) === 'on' ? true : false;
	}

	public function ajax_click_on_photo() {

		ob_start();

		if ( ! isset( $_POST[ 'attachment_id' ] ) || ! isset( $_POST[ 'selected' ] ) ) {
			return false;
		}
		$attachment_id = $_POST[ 'attachment_id' ];
		$selected      = $_POST[ 'selected' ];

		$data               = wp_get_attachment_metadata( $attachment_id );
		$data[ 'selected' ] = $selected;

		wp_update_attachment_metadata( $attachment_id, $data );

		echo json_encode( ob_get_clean() );
		die();
	}

	public function parse_comments( $comment = '' ) {
		global $post;

		if ( 'proof_gallery' !== $post->post_type ) {
			return $comment;
		}
		$comment = preg_replace_callback( "=(^| )+#[\w\-]+=", 'dprproof_comments_match_callback', $comment );

		return $comment;
	}

	static function get_base_path() {
		return plugin_dir_path( __FILE__ );
	}

	// create an ajax call links
	static function get_zip_file_url( $post_id ) {
		return add_query_arg( array(
			'action'     => 'dprproof_zip_file_url',
			'gallery_id' => $post_id,
		), admin_url( 'admin-ajax.php' ) );
	}

	static function get_pdf_file_url( $post_id ) {
		return add_query_arg( array(
			'action'     => 'dprproof_generate_pdf',
			'gallery_id' => $post_id,
		), admin_url( 'admin-ajax.php' ) );
	}

	public function generate_photos_zip_file() {

		if ( ! isset ( $_REQUEST[ 'gallery_id' ] ) ) {
			wp_send_json_error( esc_html__('No gallery ID provided.', 'dprproof') );
		}

		global $post;
		$gallery_id = $_REQUEST[ 'gallery_id' ];

		$post = get_post( $gallery_id );

		if ( post_password_required( $post ) ) {
			wp_send_json_error( esc_html__('The gallery password is required.', 'dprproof') );
		}

		// Get this gallery's metadata.
		$gallery_data = get_post_meta( $gallery_id, '_dprproof_main_gallery', true );
		// Quit if there is no gallery data.
		if ( empty( $gallery_data ) || ! isset( $gallery_data[ 'gallery' ] ) ) {
			wp_send_json_error( esc_html__('No gallery data.', 'dprproof') );
		}

		$gallery_ids = explode( ',', $gallery_data[ 'gallery' ] );
		if ( empty( $gallery_ids ) ) {
			wp_send_json_error( esc_html__('Empty gallery.', 'dprproof') );
		}

		// get attachments
		$attachments = get_posts( array(
			'post_status'    => 'any',
			'post_type'      => 'attachment',
			'post__in'       => $gallery_ids,
			'orderby'        => 'post__in',
			'posts_per_page' => '-1',
		) );

		if ( is_wp_error( $attachments ) || empty( $attachments ) ) {
			wp_send_json_error( esc_html__('Could not get attachments.', 'dprproof') );
		}

		@set_time_limit(0);

		// create the archive
		if ( ! class_exists( 'PclZip' ) ) {
			require ABSPATH . 'wp-admin/includes/class-pclzip.php';
		}

		$filename = tempnam( get_temp_dir(), 'zip' ) . '.zip';
		try {
			$zip_archive = new Dprproof_Create_Archive( $filename );
		} catch ( Exception $exception ) {
			wp_send_json_error( $exception->getMessage() );
		}

		$with_errors = false;
		$errors = array();
		$zipped_images = 0;
		foreach ( $attachments as $key => $attachment ) {
			$metadata = wp_get_attachment_metadata( $attachment->ID );

			// Only those selected by the client.
			if ( isset( $metadata[ 'selected' ] ) && $metadata[ 'selected' ] == 'true' ) {
				$file = get_attached_file( $attachment->ID );
				if ( empty( $file ) ) {
					$with_errors = true;
					$errors[] = sprintf( esc_html__( 'Could not find the attached file for attachment #%s.', 'dprproof' ), $attachment->ID );
					continue;
				}

				try {
					if ( $zip_archive->add_file( $file, basename( $file ) ) ) {
						$zipped_images ++;
					} else {
						$zip_archive->close();
						$errors[] = sprintf( esc_html__( 'Could not add %s to the zip archive.', 'dprproof' ), $file );
						$with_errors = true;
						break;
					}
				} catch ( Exception $exception ) {
					$with_errors = true;
					$errors[] = $exception->getMessage();
				}
			}
		}

		if ( $with_errors ) {
			unset( $zip_archive );
			wp_send_json_error( $errors );
		}

		$zip_archive->close();

		$uniqueness = date( 'd_m_Y' );
		$file_name = apply_filters( 'dprproof_filter_gallery_filename', 'gallery_', $post->post_name, $uniqueness, '.zip' );

		// create the output of the archive
		header( 'Content-Description: File Transfer' );
		header( 'Content-Type: application/zip' );
		header( 'Content-Disposition: attachment; filename=' . $file_name  );
		header( 'Content-Transfer-Encoding: binary' );
		header( 'Expires: 0' );
		header( 'Cache-Control: must-revalidate' );
		header( 'Pragma: public' );
		header( 'Content-Length: ' . filesize( $filename ) );

		$chunksize = 512 * 1024;
		$file      = @fopen( $filename, 'rb' );
		while ( ! feof( $file ) ) {
			echo @fread( $file, $chunksize );
			flush();
		}
		fclose( $file );

		// delete the temporary file
		@unlink( $filename );

		exit;
	}

public function generate_photos_pdf_file() {

		if ( ! isset ( $_REQUEST[ 'gallery_id' ] ) ) {
			wp_send_json_error( esc_html__('No gallery ID provided.', 'dprproof') );
		}
		global $post;
		$gallery_id = $_REQUEST[ 'gallery_id' ];
		$post = get_post( $gallery_id );

		if ( post_password_required( $post ) ) {
			wp_send_json_error( esc_html__('The gallery password is required.', 'dprproof') );
		}
		// Get this gallery's metadata.
		$client_name = get_post_meta( $gallery_id, '_dprproof_client_name', true );
		$gallery_data = get_post_meta( $gallery_id, '_dprproof_main_gallery', true );
		$event_date = get_post_meta( $gallery_id, '_dprproof_event_date', true );
		// Quit if there is no gallery data.
		if ( empty( $gallery_data ) || ! isset( $gallery_data[ 'gallery' ] ) ) {
			wp_send_json_error( esc_html__('No gallery data.', 'dprproof') );
		}
		$gallery_ids = explode( ',', $gallery_data[ 'gallery' ] );
		if ( empty( $gallery_ids ) ) {
			wp_send_json_error( esc_html__('Empty gallery.', 'dprproof') );
		}
		// get attachments
		$attachments = get_posts( array(
			'post_status'    => 'any',
			'post_type'      => 'attachment',
			'post__in'       => $gallery_ids,
			'orderby'        => 'post__in',
			'posts_per_page' => '-1',
		) );

		if ( is_wp_error( $attachments ) || empty( $attachments ) ) {
			wp_send_json_error( esc_html__('Could not get attachments.', 'dprproof') );
		}

		$with_errors = false;
		$errors = array();
		$selected_images = array();
		$images_count = 0;
		foreach ( $attachments as $key => $attachment ) {
			$metadata = wp_get_attachment_metadata( $attachment->ID );

			// Only those selected by the client.
			if ( isset( $metadata[ 'selected' ] ) && $metadata[ 'selected' ] == 'true' ) {
				$selected_images[] = wp_get_attachment_url( $attachment->ID );
				$images_count ++;
			}
		}

	    $pdf = new FPDF();
		$pdf->AddPage();
		$pdf->SetFont('Arial','B',12);
		$pdf->Cell(50,10,'Client Name');
		$pdf->Cell(50,10,'Event Date');
		$pdf->Cell(50,10,'Count of Images');
		$pdf -> Ln(7);
		$pdf->SetFont('Helvetica','',12);
		$pdf -> SetTextColor(102,102,102);
		$pdf->Cell(50,10,$client_name);
		$pdf->Cell(50,10,$event_date);
		$pdf->Cell(50,10,$images_count);
		$pdf -> Ln(20);
		$y = $pdf-> GetY();
		$x = $pdf-> GetX();
		$width = $pdf-> GetPageWidth() -20;
		$i = 0;
		foreach ( $selected_images as $image ) {
			$y = $pdf-> GetY();
			$x = $pdf-> GetX();
			$pdf->Image($image,$x,$y,$width);
			$i++;
			if ($i<$images_count) {
			 $pdf -> addPage();
			}

		}
		$pdf->Output('D',$this->beautify_filename($client_name.' gallery '.date(d_m_Y)).'.pdf');
      	exit;  


		
	}

	public function beautify_filename($filename) {
    // reduce consecutive characters
    $filename = preg_replace(array(
        // "file   name.zip" becomes "file-name.zip"
        '/ +/',
        // "file___name.zip" becomes "file-name.zip"
        '/_+/',
        // "file---name.zip" becomes "file-name.zip"
        '/-+/'
    ), '-', $filename);
    $filename = preg_replace(array(
        // "file--.--.-.--name.zip" becomes "file.name.zip"
        '/-*\.-*/',
        // "file...name..zip" becomes "file.name.zip"
        '/\.{2,}/'
    ), '.', $filename);
    // lowercase for windows/unix interoperability http://support.microsoft.com/kb/100625
    $filename = mb_strtolower($filename, mb_detect_encoding($filename));
    // ".file-name.-" becomes "file-name"
    $filename = trim($filename, '.-');
    return $filename;
	}


	/**
	 * This filter must return the gallery's zip filename
	 *
	 * @param $file_name_prefix
	 * @param $post_slug
	 * @param $unique
	 * @param $extension
	 *
	 * @return string
	 */
	public function prepare_the_gallery_name( $file_name_prefix, $post_slug, $unique, $extension ) {
		return $file_name_prefix . $post_slug . '_' . $unique . $extension;
	}

	/**
	 * Adds a prefix to an option name.
	 *
	 * @param string $option
	 * @param bool $private Optional. Whether this option name should also get a '_' in front, marking it as private.
	 *
	 * @return string
	 */
	public function prefix( $option, $private = false ) {
		$option = dprproof_prefix( $option );

		if ( true === $private ) {
			return '_' . $option;
		}

		return $option;
	}
}

endif;
