<?php

// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}



if(!class_exists('DPR_Responsive_CSS')) {

	class DPR_Responsive_CSS {

		/**

		 * @var array

		 */

		protected $settings = array();

		/**

		 * @var string

		 */

		protected $value = '';

		/**

		 * @var array

		 */

		protected $layers = array( 'margin', 'border', 'padding' );

		/**

		 * @var array

		 */

		protected $positions = array( 'top', 'right', 'bottom', 'left' );

		/**

		 * @var array

		 */

		protected $devices = array( 'laptop', 'tablet', 'mobile');



		/**

		 *

		 */

		function __construct() {



			if(function_exists('vc_add_shortcode_param')) {

				vc_add_shortcode_param( 'dpr_responsive_css', array($this, 'dpr_responsive_css'), DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/admin/js/dpr_responsive_css_param.js' );

			}

			

		}



		function onionLayout($device) {

			$output = '<div class="vc_layout-onion vc_col-xs-7" style="width:390px;">'

			          . '    <div class="vc_margin">' . $this->layerControls( 'margin', $device)

			          . '      <div class="vc_border">' . $this->layerControls( 'border', $device )

			          . '          <div class="vc_padding">' . $this->layerControls( 'padding', $device )

			          . '              <div class="vc_content"><i></i></div>'

			          . '          </div>'

			          . '      </div>'

			          . '    </div>'

			          . '</div>';



			return $output;

		}

		/**

		 * @param $name

		 * @param string $prefix

		 *

		 * @return string

		 */

		protected function layerControls( $name , $prefix  ) {

			$output = '<label>' . $name . '</label>';

			foreach ( $this->positions as $pos ) {

				$output .= '<input type="text" class="vc_' . $pos . ' '.$prefix.'_'.$name.'_'.$pos.' css-input" placeholder="-" value="">';

			}



			return $output;

		}



		public static function generate_css($value, $class = '') {

			if(!$value || empty($value)) return;

			

			$css_output = '';

			

			$devices = array( 'laptop', 'tablet', 'mobile');

			

			$values = vc_parse_multi_attribute($value, array(

				'laptop_margin_top' => '',

				'laptop_margin_bottom' => '',

				'laptop_margin_left' => '',

				'laptop_margin_right' => '',

				'laptop_border_top' => '',

				'laptop_border_bottom' => '',

				'laptop_border_left' => '',

				'laptop_border_right' => '',

				'laptop_padding_top' => '',

				'laptop_padding_bottom' => '',

				'laptop_padding_left' => '',

				'laptop_padding_right' => '',

				'tablet_margin_top' => '',

				'tablet_margin_bottom' => '',

				'tablet_margin_left' => '',

				'tablet_margin_right' => '',

				'tablet_border_top' => '',

				'tablet_border_bottom' => '',

				'tablet_border_left' => '',

				'tablet_border_right' => '',

				'tablet_padding_top' => '',

				'tablet_padding_bottom' => '',

				'tablet_padding_left' => '',

				'tablet_padding_right' => '',

				'mobile_margin_top' => '',

				'mobile_margin_bottom' => '',

				'mobile_margin_left' => '',

				'mobile_margin_right' => '',

				'mobile_border_top' => '',

				'mobile_border_bottom' => '',

				'mobile_border_left' => '',

				'mobile_border_right' => '',

				'mobile_padding_top' => '',

				'mobile_padding_bottom' => '',

				'mobile_padding_left' => '',

				'mobile_padding_right' => '',



			));

			

			

			$devices_queries = array(

				'laptop' => '@media (max-width: 1280px) and (min-width: 1024px)',

				'tablet' => '@media (max-width: 1023px) and (min-width: 800px)',

				'mobile' => '@media (max-width: 799px)',

			);

			

			foreach($devices as $device) {

				$single_css = '';



				if(isset($values[$device.'_margin_top']) && $values[$device.'_margin_top'] != '') {

					$single_css .= 'margin-top: '.esc_attr($values[$device.'_margin_top']).' !important;';

				}

				if(isset($values[$device.'_margin_bottom']) && $values[$device.'_margin_bottom'] != '') {

					$single_css .= 'margin-bottom: '.esc_attr($values[$device.'_margin_bottom']).' !important;';

				}

				if(isset($values[$device.'_margin_left']) && $values[$device.'_margin_left'] != '') {

					$single_css .= 'margin-left: '.esc_attr($values[$device.'_margin_left']).' !important;';

				}

				if(isset($values[$device.'_margin_right']) && $values[$device.'_margin_right'] != '') {

					$single_css .= 'margin-right: '.esc_attr($values[$device.'_margin_right']).' !important;';

				}



				if(isset($values[$device.'_border_top']) && $values[$device.'_border_top'] != '') {

					$single_css .= 'border-top-width: '.esc_attr($values[$device.'_border_top']).' !important;';

				}

				if(isset($values[$device.'_border_bottom']) && $values[$device.'_border_bottom'] != '') {

					$single_css .= 'border-bottom-width: '.esc_attr($values[$device.'_border_bottom']).' !important;';

				}

				if(isset($values[$device.'_border_left']) && $values[$device.'_border_left'] != '') {

					$single_css .= 'border-left-width: '.esc_attr($values[$device.'_border_left']).' !important;';

				}

				if(isset($values[$device.'_border_right']) && $values[$device.'_border_right'] != '') {

					$single_css .= 'border-right-width: '.esc_attr($values[$device.'_border_right']).' !important;';

				}



				if(isset($values[$device.'_padding_top']) && $values[$device.'_padding_top'] != '') {

					$single_css .= 'padding-top: '.esc_attr($values[$device.'_padding_top']).' !important;';

				}

				if(isset($values[$device.'_padding_bottom']) && $values[$device.'_padding_bottom'] != '') {

					$single_css .= 'padding-bottom: '.esc_attr($values[$device.'_padding_bottom']).' !important;';

				}

				if(isset($values[$device.'_padding_left']) && $values[$device.'_padding_left'] != '') {

					$single_css .= 'padding-left: '.esc_attr($values[$device.'_padding_left']).' !important;';

				}

				if(isset($values[$device.'_padding_right']) && $values[$device.'_padding_right'] != '') {

					$single_css .= 'padding-right: '.esc_attr($values[$device.'_padding_right']).' !important;';

				}

				

				if($single_css != '') {

					$css_output .= $devices_queries[$device].'{'.$class.'{'.$single_css.'}}';

				}

			}

			

			return $css_output;

		}



		function dpr_responsive_css($settings, $value)

				{

					$uni = rand(1,9999);

					$param_name = isset($settings['param_name']) ? $settings['param_name'] : '';

					$type = isset($settings['type']) ? $settings['type'] : '';

					$class = isset($settings['class']) ? $settings['class'] : '';

					$output = '<div class="vc_css-editor vc_row vc_ui-flex-row">';

					$output .= '<div class="devices-nav vc_ui-button-group vc_col-sm-12">';

					$output .= '<div class="vc_general vc_ui-button vc_ui-button-default vc_ui-button-shape-rounded vc_ui-button-fw device-button active" data-target="laptop" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom CSS for small desktop (min width 1024px / max width 1280px).', 'dpr-adeline-extensions').'" data-balloon-pos="top"><span class="dashicons dashicons-laptop"></span>'.esc_html__('Small Desktop', 'dpr-adeline-extensions').'</div>';

					$output .= '<div class="vc_general vc_ui-button vc_ui-button-default vc_ui-button-shape-rounded vc_ui-button-fw device-button" data-target="tablet" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom CSS for tablet (min width 800px / max width 1023px).', 'dpr-adeline-extensions').'" data-balloon-pos="top"><span class="dashicons dashicons-tablet"></span>'.esc_html__('Tablet', 'dpr-adeline-extensions').'</div>';

					$output .= '<div class="vc_general vc_ui-button vc_ui-button-default vc_ui-button-shape-rounded vc_ui-button-fw device-button" data-target="mobile" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom CSS for mobile ( max width 799px).', 'dpr-adeline-extensions').'" data-balloon-pos="top"><span class="dashicons dashicons-smartphone"></span>'.esc_html__('Mobile', 'dpr-adeline-extensions').'</div>';

					$output .= '</div>';

					$output .= '<div class="css-panel laptop active" data-panel="laptop">';

					$output .= $this->onionLayout('laptop');

					$output .= '</div>';

					$output .= '<div class="css-panel tablet" data-panel="tablet">';

					$output .= $this->onionLayout('tablet');

					$output .= '</div>';

					$output .= '<div class="css-panel mobile" data-panel="mobile">';

					$output .= $this->onionLayout('mobile');

					$output .= '</div>';

					$output .= '<input type="hidden" id="dpr-responsive-css-value-'.$uni.'" class="wpb_vc_param_value ' . $param_name . ' ' . $type . ' ' . $class . '" name="' . $param_name . '" value="'.$value.'"/>';

					$output .= '</div><div class="vc_clearfix"></div>';

		

					return $output;

				}

		

	}



}



if(class_exists('DPR_Responsive_CSS')) {

	$DPR_Responsive_CSS = new DPR_Responsive_CSS();

	

}