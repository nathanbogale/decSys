<?php

// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}



//VC Column VC Map modifications



if(function_exists('vc_remove_param')) {

	

	vc_remove_param('vc_column','el_id');

	vc_remove_param('vc_column','el_class');

	vc_remove_param('vc_column','video_bg');

	vc_remove_param('vc_column','video_bg_url');

	vc_remove_param('vc_column','video_bg_parallax');

	vc_remove_param('vc_column','parallax');

	vc_remove_param('vc_column','parallax_image');

	vc_remove_param('vc_column','parallax_speed_bg');

	vc_remove_param('vc_column','parallax_speed_video');

}



	vc_add_param(

		'vc_column', array(

			'type' => 'dpr_title',

			'text' => esc_html__('Main column settings', 'dpr-adeline-extensions'),

			'param_name' => 'main_setting_title_1',

			'class' => '',

			'weight' => 1

		)

	);

	vc_add_param(

		'vc_column', array(

			'type' => 'dpr_radio',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Choose the background style for the column. The text colors will be changed according to the style you choose to make it more readable.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background style', 'dpr-adeline-extensions'),

			'param_name' => 'bg_style',
		
			'edit_field_class' => 'vc_column vc_col-sm-4',			

			'value' => '',

			'weight' => 1,

			'options' => array(

				__('Light', 'dpr-adeline-extensions') => '',

				__('Dark', 'dpr-adeline-extensions') => 'dark',

			)

		)

	);

	vc_add_param(

		'vc_column', array(

			'type' => 'dpr_radio',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the background type for the column. Default will be use settings from Design Options for this row. Gradient allows you to set the gradient backgrounds. Parallax Image allows you to upload the image and add the parallax. Video allows you to set the video as column background', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background type', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_bg_type',

			'weight' => 1,

			'value' => 'default',

			'edit_field_class' => 'vc_column vc_col-sm-8',	

			'options' => array(

				__('Default', 'dpr-adeline-extensions') => 'default',

				__('Parallax Image', 'dpr-adeline-extensions') => 'parallax-image',

				__('Video', 'dpr-adeline-extensions') => 'video',

				__('Gradient', 'dpr-adeline-extensions') => 'gradient',

			)

		)

	);

	vc_add_param(

		'vc_column', array(

			'type' => 'dpr_switcher',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('This option allows you to make this column sticky by scroll', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Sticky Column?', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_enable_sticky_column',

			'edit_field_class' => 'vc_column vc_col-sm-12',	
		
			'weight' => 1,		

			'value' => 'No',

			'options' => array(

				'yes' => array(

						'label' => '',

						'on' => 'Yes',

						'off' => 'No',

					),

				),

		)

	);



	vc_add_param(

		'vc_column', array(

			'type' => 'attach_image',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select parallax image from media library', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Parallax Image', 'dpr-adeline-extensions'),

			'param_name' => 'parallax_image',

			'weight' => 1,

			'value' => '',

			'dependency' => array(

				'element' => 'dpr_bg_type',

				'value' => 'parallax-image',

			),

		)

	);

	vc_add_param(

		'vc_column', array(

			'type' => 'dpr_radio',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Add parallax for column image background', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Parallax', 'dpr-adeline-extensions'),

			'param_name' => 'parallax',

			'weight' => 1,

			'value' => 'content-moving',

			'dependency' => array(

				'element' => 'dpr_bg_type',

				'value' => 'parallax-image',

			),

			'edit_field_class' => 'vc_column vc_col-sm-6',

			'options' => array(

				__( 'Simple', 'dpr-adeline-extensions' ) => 'content-moving',

				__( 'With fade', 'dpr-adeline-extensions' ) => 'content-moving-fade',

			),

		)

	);

	vc_add_param(

		'vc_column',array(

			'type' => 'number',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enter parallax speed ratio (Note: Default value is 1.5, min value is 1)', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Parallax Speed', 'dpr-adeline-extensions'),

			'param_name' => 'parallax_speed_bg',

			'value' =>'1.5',

			'min'=>'1',

			'max' => '10',

			'step' => '0.1',

			'weight' => '1',

			'dependency' => array(

				'element' => 'parallax',

				'value' => array('content-moving','content-moving-fade'),

			),

			'edit_field_class' => 'vc_column vc_col-sm-6',

		)

	);

	vc_add_param(

		'vc_column', array(

			'type' => 'textfield',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Add YouTube link.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('YouTube link', 'dpr-adeline-extensions'),

			'param_name' => 'video_bg_url',

			'weight' => 1,

			'value' => 'https://www.youtube.com/watch?v=lMJXxhRFO1k',

				'dependency' => array(

					'element' => 'dpr_bg_type',

					'value' => 'video',

				),

		)

	);

	vc_add_param(

		'vc_column', array(

			'type' => 'dpr_radio',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Add parallax for column video background', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Parallax', 'dpr-adeline-extensions'),

			'param_name' => 'video_bg_parallax',

			'weight' => 1,

			'value' => '',

			'dependency' => array(

				'element' => 'dpr_bg_type',

				'value' => 'video',

			),

			'edit_field_class' => 'vc_column vc_col-sm-6',

			'options' => array(

				__( 'None', 'dpr-adeline-extensions' ) => '',

				__( 'Simple', 'dpr-adeline-extensions' ) => 'content-moving',

				__( 'With fade', 'dpr-adeline-extensions' ) => 'content-moving-fade',

			),

		)

	);

	vc_add_param(

		'vc_column',array(

			'type' => 'number',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enter parallax speed ratio (Note: Default value is 1.5, min value is 1)', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Parallax Speed', 'dpr-adeline-extensions'),

			'param_name' => 'parallax_speed_video',

			'value' =>'1.5',

			'min'=>'1',

			'max' => '10',

			'step' => '0.1',

			'weight' => '1',

			'dependency' => array(

				'element' => 'video_bg_parallax',

				'value' => array('content-moving','content-moving-fade'),

			),

			'edit_field_class' => 'vc_column vc_col-sm-6',

		)

	);

	vc_add_param(

		'vc_column', array(

				'type' => 'dpr_gradient_picker',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the gradient for the column background.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Column gradient', 'dpr-adeline-extensions'),

				'param_name' => 'dpr_column_gradient',

				'weight' => 1,

				'value' => '',

				'dependency' => array(

					'element' => 'dpr_bg_type',

					'value' => 'gradient',

				),

		)

	);

	vc_add_param(

		'vc_column', array(

			'type' => 'dpr_title',

			'text' => esc_html__('Additional settings', 'dpr-adeline-extensions'),

			'param_name' => 'main_setting_title_3',

			'class' => '',

			'weight' => 1

		)

	);

	vc_add_param(

		'vc_column',array(

			'type' => 'textfield',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enter optional column ID. Make sure it is unique, and it is valid as w3c specification: %s (Must not have spaces).', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Element ID', 'dpr-adeline-extensions'),

			'param_name' => 'el_id',

		)

	);

	vc_add_param(

		'vc_column',array(

			'type' => 'textfield',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Extra Class Name', 'dpr-adeline-extensions'),

			'param_name' => 'el_class',

		)

	);

	vc_add_param(

		'vc_column', array(

			'type' => 'dpr_title',

			'text' => esc_html__('Default State', 'dpr-adeline-extensions'),

			'param_name' => 'default_design_setting_title',

			'group' => esc_html__('Design Options', 'dpr-adeline-extensions'),

			'class' => '',

			'weight' => 1

		)

	);

	vc_add_param(

		'vc_column',array(

			"type" => "dpr_shadow_picker",

			"class" => "",

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set shadow for this column.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Column Shadow', 'dpr-adeline-extensions'),

			'group' => esc_html__('Design Options', 'dpr-adeline-extensions'),

			"param_name" => "column_shadow",

			"value" => "none||||||"

		)

	);

	vc_add_param(

		'vc_column', array(

			'type' => 'dpr_title',

			'text' => esc_html__('Hover State', 'dpr-adeline-extensions'),

			'param_name' => 'hover_design_setting_title',

			'group' => esc_html__('Design Options', 'dpr-adeline-extensions'),

			'class' => '',

		)

	);

	vc_add_param(

		'vc_column', array(

			'type' => 'colorpicker',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the color for column hover background.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background Color Hover', 'dpr-adeline-extensions'),

			'param_name' => 'column_bg_color_hover',

			'edit_field_class' => 'vc_column vc_col-sm-6',

			'value' => '',

			'group' => esc_html__('Design Options', 'dpr-adeline-extensions'),

		)

	);

	vc_add_param(

		'vc_column', array(

			'type' => 'colorpicker',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the color for column hover border.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border Color Hover', 'dpr-adeline-extensions'),

			'param_name' => 'column_border_color_hover',

			'edit_field_class' => 'vc_column vc_col-sm-6',

			'value' => '',

			'group' => esc_html__('Design Options', 'dpr-adeline-extensions'),

		)

	);

	vc_add_param(

	'vc_column',array(

		'type' => 'dropdown',

		'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose border style in hoover state.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border Style Hover', 'dpr-adeline-extensions'),

		'param_name' => 'column_border_style_hover',

		'group' => esc_html__('Design Options', 'dpr-adeline-extensions'),

		'edit_field_class' => 'vc_column vc_col-sm-6',

		'value' => array(

				__('Inherit', 'dpr-adeline-extensions') => '',

				__('None', 'dpr-adeline-extensions') => 'none',

				__('Solid', 'dpr-adeline-extensions') => 'solid',

				__('Doted', 'dpr-adeline-extensions') => 'dotted',

				__('Dashed', 'dpr-adeline-extensions') => 'dashed',

			    __('Hidden', 'dpr-adeline-extensions') => 'double',

				__('Groove', 'dpr-adeline-extensions') => 'groove',

				__('Ridge', 'dpr-adeline-extensions') => 'ridge',

				__('Inset', 'dpr-adeline-extensions') => 'inset',

				__('Outset', 'dpr-adeline-extensions') => 'outset',

			   ),

		'std' => '',

	)

	);

	vc_add_param(

		'vc_column',array(

			'type' => 'number',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose border radius in hover state for this column.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border radius hover', 'dpr-adeline-extensions'),

			'param_name' => 'column_border_radius_hover',

			'value' =>'',

			'min'=>'0',

			'step' => '1',

			'group' => esc_html__('Design Options', 'dpr-adeline-extensions'),

			'edit_field_class' => 'vc_column vc_col-sm-6',

		)

	);

	vc_add_param(

		'vc_column',array(

			"type" => "dpr_shadow_picker",

			"class" => "",

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set hover shadow for this column.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Column Shadow Hover', 'dpr-adeline-extensions'),

			'group' => esc_html__('Design Options', 'dpr-adeline-extensions'),

			"param_name" => "column_shadow_hover",

			"value" => "none||||||"

		)

	);

	vc_add_param(

		'vc_column', array(

			'type' => 'dpr_switcher',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('This option allows you to add custom paddings, margins and border for different devices.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Responsive Custom CSS', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_enable_responsive_options',

			'edit_field_class' => 'vc_column vc_col-sm-6',

			'group' => esc_html__('Responsive Options', 'dpr-adeline-extensions'),			

			'value' => '',

			'options' => array(

				'yes' => array(

						'label' => '',

						'on' => 'Yes',

						'off' => 'No',

					),

				),

		)

	);

	vc_add_param(

		'vc_column', array(

			'type'				=> 'dpr_responsive_css',

			'heading'			=> esc_html__('Resposive settings', 'dpr-adeline-extensions'),

			'param_name'		=> 'responsive_css_panel',

			'group'				=> esc_html__('Responsive Options', 'dpr-adeline-extensions'),

			'dependency' => array(

					'element' => 'dpr_enable_responsive_options', 

					'value' => array('yes')

			),

		)

	);

