<?php







if ( !function_exists( "dpr_post_format_quote_sections " ) ):



    function dpr_post_format_quote_sections() {



		/*



     	* ---> START POST FORMAT QUOTE METABOX SECTIONS



		*/







		$post_format_quote_sections = array();



		$post_format_quote_sections[] = array(



			'fields'   => array(



								array(



									'id'       => 'quote_post_quote_text',



									'title'    =>  __( 'Quote Text', 'dpr-adeline-extensions' ),



									'type'     => 'textarea',



									'default'  => '',



								),



								array(



									'id'       => 'quote_post_quote_author',



									'type'     => 'text',



									'title'    => __('Quote Author', 'dpr-adeline-extensions'), 



									'default' => '',



								),



								array(



									'id'       => 'quote_post_quote_link',



									'title'    =>  __( 'Qute Link URL', 'dpr-adeline-extensions' ),



									'type'     => 'text',



									'default'  => '',



									'desc'     => __('Here you can enter custom quote for post format <i><b>Quote</b></i>. If you leave this filed blank will be used post content.', 'dpr-adeline-extensions'),



								),



			)



		);



		



		/*



     	* ---> END POST FORMAT QUOTE METABOX SECTIONS



		*/



		







        return $post_format_quote_sections;



    }



endif;