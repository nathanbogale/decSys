<?php

// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}

/*

* Add-on Name: Heading

*/



class WPBakeryShortCode_DPR_Heading extends WPBakeryShortCode {}



vc_map(

	array(

		'name'					=> esc_html__('DP Heading', 'dpr-adeline-extensions'),

		'base'					=> 'dpr_heading',

		"icon"					=> 'icon-dpr-heading',

		"class"					=> 'dpr_heading',

  		"category" =>array( esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions')),

		'description'			=> esc_html__('Customizable Heading', 'dpr-adeline-extensions'),

		'params'				=> array(

			array(

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose heading type.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Type', 'dpr-adeline-extensions'),

				'type'				=> 'dpr_image_select',

				'param_name'		=> 'type',

				'simple_mode'		=> false,

				'value' 			=> 'type-1',

				'options'			=> array(

					'type-01'			=> array(

						'label'			=> esc_html__('Type 1', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'heading/type-1.png'

					),

					'type-02'			=> array(

						'label'			=> esc_html__('Type 2', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'heading/type-2.png'

					),

					'type-03'			=> array(

						'label'			=> esc_html__('Type 3', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'heading/type-3.png'

					),

					'type-04'			=> array(

						'label'			=> esc_html__('Type 4', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'heading/type-4.png'

					),

					'type-05'			=> array(

						'label'			=> esc_html__('Type 5', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'heading/type-5.png'

					),

					'type-06'			=> array(

						'label'			=> esc_html__('Type 6', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'heading/type-6.png'

					),

					'type-07'			=> array(

						'label'			=> esc_html__('Type 7', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'heading/type-7.png'

					),

					'type-08'			=> array(

						'label'			=> esc_html__('Type 8', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'heading/type-8.png'

					),

					'type-09'			=> array(

						'label'			=> esc_html__('Type 9', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'heading/type-9.png'

					),

					'type-10'			=> array(

						'label'			=> esc_html__('Type 10', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'heading/type-10.png'

					),

					'type-11'			=> array(

						'label'			=> esc_html__('Type 11', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'heading/type-11.png'

					),

				),

			),

			array(

				'type' => 'dropdown',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set headline tag. The default tag is h3 but its change can be useful because of SEO.  ', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Tag', 'dpr-adeline-extensions'),

				'param_name' => 'tag',

				'std'         => 'h3',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'value' => array(

						__('H1', 'dpr-adeline-extensions') => 'h1',

						__('H2', 'dpr-adeline-extensions') => 'h2',

						__('H3', 'dpr-adeline-extensions') => 'h3',

						__('H4', 'dpr-adeline-extensions') => 'h4',

						__('H5', 'dpr-adeline-extensions') => 'h5',

						__('H6', 'dpr-adeline-extensions') => 'h6'

					   ),

			),

			array(

				'type'				=> 'textarea_html',

				'heading'			=> esc_html__('Headline Content', 'dpr-adeline-extensions'),

				'param_name'		=> 'content',

				'value'				=> esc_html__('Title','dpr-adeline-extensions'),

				'admin_label'		=> true,

			),

			array(

				'type'				=> 'textfield',

				'heading'			=> esc_html__('Subtitle', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle',

				'value'				=> esc_html__('', 'dpr-adeline-extensions'),

				'admin_label'		=> true,

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to choose the horizontal alignment for the heading.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Alignment', 'dpr-adeline-extensions'),

				'param_name'		=> 'alignment',

				'value'				=> '',

				'options'			=> array(

					esc_html__('Left', 'dpr-adeline-extensions')	=> '',

					esc_html__('Center', 'dpr-adeline-extensions')	=> 'text-center',

					esc_html__('Right', 'dpr-adeline-extensions')	=> 'text-right'

				),

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Title Margins', 'dpr-adeline-extensions' ),

				'param_name'       => 'title_margins_heading',

				'edit_field_class' => 'vc_column vc_col-sm-12',

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set the custom margin for headline.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Top margin', 'dpr-adeline-extensions'),

				'param_name'		=> 'headline_top_margin',

				'min'				=> 0,

				'suffix'   			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-6  ',

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set the custom margin for headline.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Bottom margin', 'dpr-adeline-extensions'),

				'param_name'		=> 'headline_bottom_margin',

				'min'				=> 0,

				'suffix'   			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-6  ',

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Subtitle Margins', 'dpr-adeline-extensions' ),

				'param_name'       => 'subtitle_margins_heading',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'subtitle', 'not_empty' => true),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set the custom margin for subtitle.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Top margin', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_top_margin',

				'min'				=> 0,

				'suffix'   			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-6  ',

				'dependency'		=> array('element' => 'subtitle', 'not_empty' => true),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set the custom margin for subtitle.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Bottom margin', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_bottom_margin',

				'min'				=> 0,

				'suffix'   			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-6  ',

				'dependency'		=> array('element' => 'subtitle', 'not_empty' => true),

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Additional Settings', 'dpr-adeline-extensions' ),

				'param_name'       => 'extra_features_title',

				'edit_field_class' => 'vc_column vc_col-sm-12',

			),

		   vc_map_add_css_animation( false ),

		    array(

				'type' => 'textfield',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Extra Class Name', 'dpr-adeline-extensions'),

				'param_name' => 'el_class',

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable separator for this header.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Use Separator?', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_separator',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Separator', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set seprator type.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Separator type', 'dpr-adeline-extensions'),

				'param_name'		=> 'separator_type',

				'value'				=> 'line',

				'options'			=> array(

					esc_html__('Line', 'dpr-adeline-extensions')	=> 'line',

					esc_html__('Image', 'dpr-adeline-extensions')	=> 'image'

				),

				'dependency'		=> array('element' => 'use_separator', 'value' => array('yes')),

				'group'				=> esc_html__('Separator', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set seprator line style.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Separator line style', 'dpr-adeline-extensions'),

				'param_name'		=> 'line_style',

				'value'				=> 'solid',

				'options'			=> array(

					esc_html__('Solid', 'dpr-adeline-extensions')	=> 'solid',

					esc_html__('Dashed', 'dpr-adeline-extensions')	=> 'dashed',

					esc_html__('Dotted', 'dpr-adeline-extensions')	=> 'dotted',

					esc_html__('Double', 'dpr-adeline-extensions')	=> 'double'

				),

				'dependency'		=> array('element' => 'separator_type', 'value' => array('line')),

				'group'				=> esc_html__('Separator', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Allows you to set width of separator line.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Width', 'dpr-adeline-extensions'),

				'param_name'		=> 'line_width',

				'min'				=> 1,

				'suffix'   			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4  ',

				'dependency'		=> array('element' => 'separator_type', 'value' => array('line')),

				'group'				=> esc_html__('Separator', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Allows you to set height of separator line.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'line_height',

				'min'				=> 1,

				'suffix'   			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4  ',

				'dependency'		=> array('element' => 'separator_type', 'value' => array('line')),

				'group'				=> esc_html__('Separator', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom separator line color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'line_color',

				'edit_field_class'	=> 'vc_col-sm-4 vc_column ',

				'dependency'		=> array('element' => 'separator_type', 'value' => array('line')),

				'group'				=> esc_html__('Separator', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Allows you to set width of separator line on hover.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Width Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'line_width_hover',

				'min'				=> 1,

				'suffix'   			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4  ',

				'dependency'		=> array('element' => 'separator_type', 'value' => array('line')),

				'group'				=> esc_html__('Separator', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Allows you to set height of separator line on hover.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'line_height_hover',

				'min'				=> 1,

				'suffix'   			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4  ',

				'dependency'		=> array('element' => 'separator_type', 'value' => array('line')),

				'group'				=> esc_html__('Separator', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom separator line hover color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Color Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'line_color_hover',

				'edit_field_class'	=> 'vc_col-sm-4 vc_column ',

				'dependency'		=> array('element' => 'separator_type', 'value' => array('line')),

				'group'				=> esc_html__('Separator', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'attach_image',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom separator imaage', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Image', 'dpr-adeline-extensions'),

				'param_name'		=> 'separator_image',

				'edit_field_class'	=> 'vc_column vc_col-sm-4  ',

				'dependency'		=> array('element' => 'separator_type', 'value' => array('image')),

				'group'				=> esc_html__('Separator', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set the custom separator image width.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Image width', 'dpr-adeline-extensions'),

				'param_name'		=> 'separator_image_width',

				'min'				=> 0,

				'suffix'   			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4  ',

				'dependency'		=> array('element' => 'separator_type', 'value' => array('image')),

				'group'				=> esc_html__('Separator', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set the custom separator image height.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Image height', 'dpr-adeline-extensions'),

				'param_name'		=> 'separator_image_height',

				'min'				=> 0,

				'suffix'   			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4  ',

				'dependency'		=> array('element' => 'separator_type', 'value' => array('image')),

				'group'				=> esc_html__('Separator', 'dpr-adeline-extensions'),

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Separator Margins', 'dpr-adeline-extensions' ),

				'param_name'       => 'separator_margins_heading',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'use_separator', 'value' => array('yes')),

				'group'				=> esc_html__('Separator', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set the custom margin for separator.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Top margin', 'dpr-adeline-extensions'),

				'param_name'		=> 'separator_top_margin',

				'min'				=> 0,

				'suffix'   			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4  ',

				'dependency'		=> array('element' => 'use_separator', 'value' => array('yes')),

				'group'				=> esc_html__('Separator', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set the custom margin for separator.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Bottom margin', 'dpr-adeline-extensions'),

				'param_name'		=> 'separator_bottom_margin',

				'min'				=> 0,

				'suffix'   			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4  ',

				'dependency'		=> array('element' => 'use_separator', 'value' => array('yes')),

				'group'				=> esc_html__('Separator', 'dpr-adeline-extensions'),

			),



			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Headline Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'headline_typography_head',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom headline color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Headline Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'headline_color',

				'edit_field_class'	=> 'vc_col-sm-3 vc_column ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size. If you leave this field blank will be used default size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'headline_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title linne height.Default is 18px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'headline_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'headline_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'headline_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

	  		),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font. .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_headline_google_fonts',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'headline_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'dependency'		=> array('element' => 'use_headline_google_fonts', 'value' => array('yes')),

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Subtitle Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_typography_head',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom subtitle color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Subtitle Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_color',

				'edit_field_class'	=> 'vc_col-sm-3 vc_column ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size. If you leave this field blank will be used default size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title linne height.Default is 18px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'subtitle_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

	  		),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font. .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_subtitle_google_fonts',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'subtitle_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'dependency'		=> array('element' => 'use_subtitle_google_fonts', 'value' => array('yes')),

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Headline Responsive Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'headline_reaponsive_typography_head',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Responsive', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable responsive typography for headline. .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Enable', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_hedline_responsive_typo',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Responsive', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_responsive_typo',

				'param_name'		=> 'headline_reaponsive_typography',

				'heading'			=> '',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'use_hedline_responsive_typo', 'value' => array('yes')),

				'group'				=> esc_attr__('Responsive', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Subtitle Responsive Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_reaponsive_typography_head',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Responsive', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable responsive typography for subtitle.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Enable', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_subtitle_responsive_typo',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Responsive', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_responsive_typo',

				'param_name'		=> 'subtitle_reaponsive_typography',

				'heading'			=> '',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'use_subtitle_responsive_typo', 'value' => array('yes')),

				'group'				=> esc_attr__('Responsive', 'dpr-adeline-extensions'),

			),

		),

	)

);