<?php

// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}

/*

* Add-on Name: Pogress Bar

*/



class WPBakeryShortCode_DPR_Progressbar extends WPBakeryShortCode {}



vc_map(

	array(

		'name'        => esc_html__( 'DP Progress Bar', 'dpr-adeline-extensions' ),

		'base'        => 'dpr_progressbar',

		'class'       => 'dpr_progressbar',

		'icon'        => 'icon-dpr-progress-bar',

  		"category" =>array( esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions')),

		'description' => esc_html__( 'Animated progress bar', 'dpr-adeline-extensions' ),

		'params'      => array(

			array(

				'heading'		=> esc_html__( 'Style', 'dpr-adeline-extensions' ),

				'type'			=> 'dpr_image_select',

				'param_name'	=> 'style',

				'options'		=> array(

					'simple'	=> array(

						'label'	=> esc_html__('Simple','dpr-adeline-extensions'),

						'src'		=> $module_images . 'progressbar/simple.png'

					),

					'compact'	=> array(

						'label'	=> esc_html__('Compact','dpr-adeline-extensions'),

						'src'		=> $module_images . 'progressbar/compact.png'

					),

				),

			),

			array(

				'type'				=> 'number',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enter the progress value.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Percentage value', 'dpr-adeline-extensions'),

				'param_name'		=> 'percent',

				'value'				=> 100,

				'min'				=> '10',

				'max'				=> '100',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to enable or disable the icon for the progress bar.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Use Icon?', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_icon',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				)

			),

			array(

				'type'				=> 'textfield',

				'heading'			=> esc_html__('Title', 'dpr-adeline-extensions'),

				'param_name'		=> 'title',

				'value'				=> esc_html__('Progress Bar Title', 'dpr-adeline-extensions'),

				'admin_label'		=> true,

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Additional Settings', 'dpr-adeline-extensions' ),

				'param_name'       => 'extra_features_title',

				'edit_field_class' => 'vc_column vc_col-sm-12',

			),

		   vc_map_add_css_animation( false ),

		    array(

				'type' => 'textfield',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Extra Class Name', 'dpr-adeline-extensions'),

				'param_name' => 'el_class',

			),

		  array(

				"type" => "dpr_icon_selector",

				"heading" => esc_attr__("Icon", 'dpr-adeline-extensions'),

				"param_name" => "icon",

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select icon.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'use_icon', 'value' => 'yes',),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> esc_html__('Icon size', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_size',

				'value'				=> 14,

				'edit_field_class'	=> 'vc_column vc_col-sm-6   ',

				'dependency'		=> array('element' => 'use_icon', 'value' => 'yes',),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'class'				=> '',

				'heading'			=> esc_html__('Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_color',

				'value'				=> '#292933',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'dependency'		=> array('element' => 'use_icon', 'value' => 'yes',),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),



			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'General styles', 'dpr-adeline-extensions' ),

				'param_name'       => 'styles_title',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			

			array(

				'type'				=> 'number',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to specify the progress bar height.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Progress Bar Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'progress_line_height_1',

				'value'				=> 9,

				'suffix' 			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'dependency'		=> array('element' => 'style', 'value'   => array('simple')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to specify the progress bar height.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Progress Bar Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'progress_line_height_2',

				'value'				=> 33,

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-6  ',

				'dependency'		=> array('element' => 'style', 'value'   => array('compact')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set the percents to the left', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Percents near the title?', 'dpr-adeline-extensions'),

				'param_name'		=> 'percent_near',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'dependency'		=> array('element' => 'style', 'value'   => array('simple')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				)

			),

			array(

				'type'             => 'dpr_title',

				'text'             => '',

				'param_name'       => 'sep_1',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable or disable progress bar animation', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Animate Progress?', 'dpr-adeline-extensions'),

				'param_name'		=> 'progress_animated',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

				'value'				=> 'yes',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				)

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable or disable the slanting lines decoration on progress line', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Slanting lines decoration?', 'dpr-adeline-extensions'),

				'param_name'		=> 'slanting_lines',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				)

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable or disable animation for the slanting lines', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Lines animation?', 'dpr-adeline-extensions'),

				'param_name'		=> 'slanting_lines_animate',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				)

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the position for the progress bar title.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Title position', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_position',

				'value'				=> 'top',

				'options'			=> array(

					esc_html__('Top', 'dpr-adeline-extensions')	=> 'top',

					esc_html__('Bottom', 'dpr-adeline-extensions')	=> 'bottom'

				),

				'edit_field_class'	=> 'vc_col-sm-12 vc_column ',

				'dependency'		=> array('element' => 'style', 'value'   => array('simple')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the position for the progress bar title and percents in bar.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Title & percents position', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_position_compact',

				'value'				=> 'position-1',

				'options'			=> array(

					esc_html__('Title Left/Percent Right', 'dpr-adeline-extensions')	=> 'position-1',

					esc_html__('Title & Percent Left', 'dpr-adeline-extensions')	=> 'position-2',

					esc_html__('Title Left & Percent Right Outside', 'dpr-adeline-extensions')	=> 'position-3'

				),

				'edit_field_class'	=> 'vc_col-sm-12 vc_column ',

				'dependency'		=> array('element' => 'style', 'value'   => array('compact')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			/*

			* Line Style

			*/

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Progress Line Style', 'dpr-adeline-extensions' ),

				'param_name'       => 'styles_title_2',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the progress line background type.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background Type', 'dpr-adeline-extensions'),

				'param_name'		=> 'line_bg_style',

				'value'				=> 'solid',

				'options'			=> array(

					esc_html__('Solid', 'dpr-adeline-extensions')	=> 'solid',

					esc_html__('Gradient', 'dpr-adeline-extensions')	=> 'gradient',

				),

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to specify custom progress bar border radius.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Progress Bar Border Radius', 'dpr-adeline-extensions'),

				'param_name'		=> 'line_border_radius',

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-6  ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose line color. The default color is transparent', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Progress Bar Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'line_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6  ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'line_bg_style', 'value' => 'solid'),

			),

			array(

				'type' => 'dpr_gradient_picker',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the gradient background for line. Solid color set above will be ignored', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Progress Bar Gradient', 'dpr-adeline-extensions'),

				'param_name' => 'line_gradient',

				'value' => '45;0%/rgb(77, 47, 255);100%/rgb(36, 143, 255)',

				'dependency'		=> array('element' => 'line_bg_style', 'value' => 'gradient'),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			/*

			* Line Back Style

			*/

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Line Background Style', 'dpr-adeline-extensions' ),

				'param_name'       => 'styles_title_3',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose line bg color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Progress Bar Background', 'dpr-adeline-extensions'),

				'param_name'		=> 'line_background_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-4  ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose line bg border color. The default color is transparent', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Progress Bar Border', 'dpr-adeline-extensions'),

				'param_name'		=> 'line_background_border_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-4  ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to specify the progress bar background padding. Default is 0', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Progress Bar Border Padding', 'dpr-adeline-extensions'),

				'param_name'		=> 'line_background_padding',

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4  ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			/*

			* Typography

			*/

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Title Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_typography_head',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'title', 'not_empty' => true),

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose title color. The default color is #292933', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Title Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-3  ',

				'dependency'		=> array('element' => 'title', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size. If you leave this field blank will be used default size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'title', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title linne height.Default is 18px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'title', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'title', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'title_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'dependency'		=> array('element' => 'title', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

	  		),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font. .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_use_google_fonts',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'dependency'		=> array('element' => 'title', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'title_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'dependency'		=> array('element' => 'title_use_google_fonts', 'value' => 'yes'),

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),



			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Number Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'number_typography_head',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose title color. The default color is #292933', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Number Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'number_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-3  ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size. If you leave this field blank will be used default size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'number_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title linne height.Default is 18px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'number_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'number_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'number_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

	  		),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font. .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'number_use_google_fonts',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'number_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'number_use_google_fonts', 'value' => 'yes'),

			),

			array(

				'type' => 'css_editor',

				'heading' => __( 'CSS box', 'dpr-adeline-extensions' ),

				'param_name' => 'css',

				'group' => __( 'Design Options', 'dpr-adeline-extensions' ),

			),

			

			

		),

	)

);