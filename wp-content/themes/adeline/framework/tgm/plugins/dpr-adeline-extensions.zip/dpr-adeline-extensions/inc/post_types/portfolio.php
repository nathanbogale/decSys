<?php

/**

 * Register Portfolio Post Type

 */



if ( ! class_exists( 'DPR_Portfolio_Post_Type' ) ) {



	class DPR_Portfolio_Post_Type {



		public function __construct() {

			add_action( 'init', array( $this, 'register_post_type' ) );

			add_action( 'init', array( $this, 'register_categories' ) );

			add_action( 'init', array( $this, 'register_tags' ) );

			if ( is_admin() ) {

				add_filter( 'manage_edit-dpr_portfolio_columns', array( $this, 'edit_columns' ) );

				add_action( 'manage_dpr_portfolio_posts_custom_column', array( $this, 'custom_columns' ), 10, 2 );

				add_action( 'restrict_manage_posts', array( $this, 'categories_filter' ) );



			}

		}



		/**

		 * Register portfolio post type

		 *

		 */

		public static function register_post_type() {



			// Get portfolio slug name from theme options

			$slug 	= adeline_get_option_value( 'portfolio_slug', '', 'portfolio' );

			$slug 	= $slug ? $slug : 'portfolio';



			register_post_type( 'dpr_portfolio', apply_filters( 'dpr_portfolio_args', array(

				'labels' => array(

					'name' 					=> esc_html__( 'Portfolio', 'dpr-adeline-extensions' ),

					'singular_name' 		=> esc_html__( 'Portfolio Item', 'dpr-adeline-extensions' ),

					'add_new' 				=> esc_html__( 'Add New', 'dpr-adeline-extensions' ),

					'add_new_item' 			=> esc_html__( 'Add New Item', 'dpr-adeline-extensions' ),

					'edit_item' 			=> esc_html__( 'Edit Portfolio Item', 'dpr-adeline-extensions' ),

					'new_item' 				=> esc_html__( 'Add New Item', 'dpr-adeline-extensions' ),

					'view_item' 			=> esc_html__( 'View Portfolio', 'dpr-adeline-extensions' ),

					'search_items' 			=> esc_html__( 'Search Items', 'dpr-adeline-extensions' ),

					'not_found' 			=> esc_html__( 'No Items Found', 'dpr-adeline-extensions' ),

					'not_found_in_trash' 	=> esc_html__( 'No Items Found In Trash', 'dpr-adeline-extensions' )

				),

				'public' 					=> true,

				'has_archive' 				=> false,

				'can_export'            	=> true,

				'capability_type' 			=> 'post',

				'menu_icon' 				=> 'dashicons-portfolio',

				'menu_position' 			=> 20,

				'query_var'          		=> false,

				'rewrite' 					=> array( 'slug' => $slug, 'with_front' => false ),

				'supports' 					=> array(

					'title',

					'editor',

					'excerpt',

					'thumbnail',

					'comments',

					'custom-fields',

					'revisions',

					'author',

					'page-attributes',

				),

				'show_in_rest' => true

			) ) );



		}



		/**

		 * Register category

		 *

		 */

		public static function register_categories() {



			// Get portfolio category slug name from theme options

			$slug = adeline_get_option_value( 'portfolio_category_slug', '', 'portfolio-category' );

			$slug = $slug ? $slug : 'portfolio-category';



			// Define args and apply filters

			$args = apply_filters( 'dpr_portfolio_category_args', array(

				'labels' => array(

					'name' 							=> esc_html__( 'Portfolio Categories', 'dpr-adeline-extensions' ),

					'singular_name' 				=> esc_html__( 'Portfolio Category', 'dpr-adeline-extensions' ),

					'menu_name' 					=> esc_html__( 'Categories', 'dpr-adeline-extensions' ),

					'search_items' 					=> esc_html__( 'Search','dpr-adeline-extensions' ),

					'popular_items' 				=> esc_html__( 'Popular', 'dpr-adeline-extensions' ),

					'all_items' 					=> esc_html__( 'All', 'dpr-adeline-extensions' ),

					'parent_item' 					=> esc_html__( 'Parent', 'dpr-adeline-extensions' ),

					'parent_item_colon' 			=> esc_html__( 'Parent', 'dpr-adeline-extensions' ),

					'edit_item' 					=> esc_html__( 'Edit', 'dpr-adeline-extensions' ),

					'update_item' 					=> esc_html__( 'Update', 'dpr-adeline-extensions' ),

					'add_new_item' 					=> esc_html__( 'Add New', 'dpr-adeline-extensions' ),

					'new_item_name' 				=> esc_html__( 'New', 'dpr-adeline-extensions' ),

					'separate_items_with_commas' 	=> esc_html__( 'Separate with commas', 'dpr-adeline-extensions' ),

					'add_or_remove_items' 			=> esc_html__( 'Add or remove', 'dpr-adeline-extensions' ),

					'choose_from_most_used' 		=> esc_html__( 'Choose from the most used', 'dpr-adeline-extensions' ),

				),

				'public' 							=> true,

				'show_in_nav_menus' 				=> true,

				'show_ui' 							=> true,

				'show_tagcloud' 					=> true,

				'hierarchical' 						=> true,

				'rewrite' 							=> array( 'slug' => $slug, 'with_front' => false ),

				'query_var' 						=> true

			) );



			register_taxonomy( 'dpr_portfolio_category', array( 'dpr_portfolio' ), $args );



		}



		/**

		 * Register tags

		 *

		 */

		public static function register_tags() {



			// Get portfolio tag slug name from theme options

			$slug = adeline_get_option_value( 'op_portfolio_tag_slug', '', 'portfolio-tag' );

			$slug = $slug ? $slug : 'portfolio-tag';



			// Define args and apply filters

			$args = apply_filters( 'dpr_portfolio_tag_args', array(

				'labels' => array(

					'name' 							=> esc_html__( 'Portfolio Tags', 'dpr-adeline-extensions' ),

					'singular_name' 				=> esc_html__( 'Portfolio Tag', 'dpr-adeline-extensions' ),

					'menu_name' 					=> esc_html__( 'Tags', 'dpr-adeline-extensions' ),

					'search_items' 					=> esc_html__( 'Search','dpr-adeline-extensions' ),

					'popular_items' 				=> esc_html__( 'Popular', 'dpr-adeline-extensions' ),

					'all_items' 					=> esc_html__( 'All', 'dpr-adeline-extensions' ),

					'parent_item' 					=> esc_html__( 'Parent', 'dpr-adeline-extensions' ),

					'parent_item_colon' 			=> esc_html__( 'Parent', 'dpr-adeline-extensions' ),

					'edit_item' 					=> esc_html__( 'Edit', 'dpr-adeline-extensions' ),

					'update_item' 					=> esc_html__( 'Update', 'dpr-adeline-extensions' ),

					'add_new_item' 					=> esc_html__( 'Add New', 'dpr-adeline-extensions' ),

					'new_item_name' 				=> esc_html__( 'New', 'dpr-adeline-extensions' ),

					'separate_items_with_commas' 	=> esc_html__( 'Separate with commas', 'dpr-adeline-extensions' ),

					'add_or_remove_items' 			=> esc_html__( 'Add or remove', 'dpr-adeline-extensions' ),

					'choose_from_most_used' 		=> esc_html__( 'Choose from the most used', 'dpr-adeline-extensions' ),

				),

				'public' 							=> true,

				'show_in_nav_menus' 				=> true,

				'show_ui' 							=> true,

				'show_tagcloud' 					=> true,

				'hierarchical' 						=> false,

				'rewrite' 							=> array( 'slug' => $slug, 'with_front' => false ),

				'query_var' 						=> true,

			) );



			// Register the tag taxonomy

			register_taxonomy( 'dpr_portfolio_tag', array( 'dpr_portfolio' ), $args );



		}



		/**

		 * Add categories and tags columns in portfolio post type

		 *

		 */

		public static function edit_columns( $columns ) {

			if ( taxonomy_exists( 'dpr_portfolio_category' ) ) {

				$columns['dpr_portfolio_category'] = esc_html__( 'Categories', 'dpr-adeline-extensions' );

			}

			if ( taxonomy_exists( 'dpr_portfolio_tag' ) ) {

				$columns['dpr_portfolio_tag']      = esc_html__( 'Tags', 'dpr-adeline-extensions' );

			}

			return $columns;

		}



		/**

		 * Display the custom columns

		 *

		 */

		public static function custom_columns( $column, $post_id ) {



			switch ( $column ) :



				// Display the categories in the column view

				case 'dpr_portfolio_category':



					if ( $category_list = get_the_term_list( $post_id, 'dpr_portfolio_category', '', ', ', '' ) ) {

						echo $category_list;

					} else {

						echo '&mdash;';

					}



				break;



				// Display the tags in the column view

				case 'dpr_portfolio_tag':



					if ( $tag_list = get_the_term_list( $post_id, 'dpr_portfolio_tag', '', ', ', '' ) ) {

						echo $tag_list;

					} else {

						echo '&mdash;';

					}



				break;



			endswitch;



		}



		/**

		 * Adds categories filter to the portfolio admin

		 *

		 */

		public static function categories_filter() {

			global $typenow;



			if ( 'dpr_portfolio' == $typenow ) {



		        $filter = array( 'dpr_portfolio_category' );



		        foreach ( $filter as $tax_slug ) {



					if ( ! taxonomy_exists( $tax_slug ) ) {

						continue;

					}



					$current_tax 	= isset( $_GET[ $tax_slug ] ) ? esc_html( $_GET[ $tax_slug ] ) : false;

					$tax_obj 		= get_taxonomy( $tax_slug );

					$tax_name 		= $tax_obj->labels->name;

					$terms 			= get_terms( $tax_slug );



					if ( count( $terms ) > 0 ) {

						echo "<select name='$tax_slug' id='$tax_slug' class='postform'>";

						echo "<option value=''>$tax_name</option>";

						foreach ( $terms as $term ) {

							echo '<option value=' . $term->slug, $current_tax == $term->slug ? ' selected="selected"' : '','>' . $term->name .' (' . $term->count .')</option>';

						}

						echo "</select>";

					}



		        }



		    }



		}





	}



}

new DPR_Portfolio_Post_Type();