<?php

// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}



if(!class_exists('DPR_Taxonomy_Multi_Select_Param')) {



	class DPR_Taxonomy_Multi_Select_Param {

		

		function __construct() {

			add_action( 'admin_enqueue_scripts', array( $this, 'param_scripts' ) );



			if(function_exists('vc_add_shortcode_param')) {

				vc_add_shortcode_param('dpr_tax_multi_select' , array(&$this,'tax_multi_select') );

			}

		}

		

		function param_scripts($hook) {

			wp_enqueue_style( 'chose-css', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/admin/css/chosen.css');

			wp_enqueue_script( 'chose-js' , DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/admin/js/chosen.jquery.min.js');

		}

		function tax_multi_select($settings, $value) {

		$param_name = isset($settings['param_name']) ? $settings['param_name'] : '';

		$type = isset($settings['type']) ? $settings['type'] : '';

		$mode = isset($settings['mode']) ? $settings['mode'] : 'multiple';

		$class = isset($settings['class']) ? $settings['class'] : '';

		$placeholder = isset($settings['placeholder']) ? $settings['placeholder'] : 'Select Taxonomies...';

		$taxonomy = isset($settings['taxonomy']) ? $settings['taxonomy'] : '';

		$uni = uniqid(rand());

		$selectedArray = explode(',', $value);

		$output = '<input type="hidden" id="multi-select-values-'.$uni.'" class="wpb_vc_param_value ' . $param_name . ' ' . $type . ' ' . $class . '" name="' . $param_name . '" value="'.$value.'"/>';

		$output .= '<select data-placeholder="'.esc_attr($placeholder).'" '.$mode.' id="chose-'.$uni.'">';

		if ($mode == 'single') {

		$output .= '<option value=""></option>';

		}

		if ( ! empty( $taxonomy ) ) {

			    $terms = get_terms($taxonomy);	

				$count = count($terms);

				if ( $count > 0 ) :

					foreach ( $terms as $term ):

					$selected = '';

					$option_value_string = (string)$term->term_id;

					if (in_array($option_value_string,$selectedArray)) {

						$selected = ' selected';

					}

					$output .= '<option value="' . esc_attr( $term->term_id ) . '"' . $selected . '>'

						   . htmlspecialchars( $term->name ) . '</option>';

					endforeach;

				endif;

		}

		$output .= '</select>';

		$output .= '<script>

			jQuery(document).ready(function(){

				jQuery("#chose-'.$uni.'").chosen({width: "100%", allow_single_deselect: true});

			})				

			jQuery("#chose-'.$uni.'").chosen().change(function(event, data) {

				jQuery("#multi-select-values-'.$uni.'").val(jQuery(this).val());

			});



			</script>';

		return $output;

	}

	}

}



if(class_exists('DPR_Taxonomy_Multi_Select_Param')) {

	$DPR_Taxonomy_Multi_Select_Param = new DPR_Taxonomy_Multi_Select_Param();

}

