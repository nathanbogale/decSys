<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$output = $custom_el_css = $css_class = $el_class = $css_animation = $css = $container_shadow = $container_bg_color_hover = $container_border_color_hover = $container_border_style_hover = $container_border_radius_hover = $container_shadow_hover = '';

$enable_magic_scroll = $magic_animation_type = $distance_scroll_x = $distance_scroll_y = $scale_scroll = $magic_class = $magic_attr = $parallax_scroll = '';

$enable_parallax_on_hover = $move_parallax= $move_parallax_attr= $parallax_move='';

$box_hover_effect = $hover_class = $continuous_class =  $hover_attr = $hover_tilt = $animated_class = $attr_class = $animation_effects = '';

$enable_hover_3d = $hover_tilt = '';

$enable_block_reveal = $reveal_js = $id = $reveal_animation_type = $reveal_animation_direction = $reveal_animation_delay = $reveal_overlay_type = $reveal_overlay_color = $reveal_overlay_gradient = '';

$atts = vc_map_get_attributes( 'dpr_animation_box', $atts );
extract( $atts );

$unique_id = uniqid('dpr-animation-box-');

if ( '' !== $css_animation && 'none' !== $css_animation ) {
	dpr_enqueue_waypoint_js();
	dpr_enqueue_animate_css();
	$el_class .= ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
}



$css_classes = array(
	$el_class,
	$unique_id,
	vc_shortcode_custom_css_class( $css ),
);
	wp_enqueue_script('tweenmax', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/TweenMax.min.js', array('jquery'), null, true);	
	wp_enqueue_script('scrollmagic', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/dpr.animated.box.min.js', array('jquery'), null, true);
	wp_enqueue_script('dpr-magic-box', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/dpr.animated.box.js', array('jquery'), null, true);	

if (!empty($enable_magic_scroll) && $enable_magic_scroll == 'yes') {
	
/* Magic scroll stuff */
	$magic_attr .= ' data-scroll_type="' . esc_attr($magic_animation_type) . '" ';
	if(!empty($magic_animation_type) && $magic_animation_type == 'position' ){
		$magic_attr .= ' data-scroll_x="' . esc_attr($distance_scroll_x) . '" ';
		$magic_attr .= ' data-scroll_y="' . esc_attr($distance_scroll_y) . '" ';
		$parallax_scroll .= ' parallax-scroll ';
	}
	if(!empty($magic_animation_type) && $magic_animation_type== 'scale'){
		$magic_attr .= ' data-scale_scroll="' . esc_attr($scale_scroll) . '" ';
		$parallax_scroll .= ' scale-scroll ';
	}
	if(!empty($magic_animation_type) && $magic_animation_type== 'both'){
		$magic_attr .= ' data-scroll_x="' . esc_attr($distance_scroll_x) . '" ';
		$magic_attr .= ' data-scroll_y="' . esc_attr($distance_scroll_y) . '" ';
		$magic_attr .= ' data-scale_scroll="' . esc_attr($scale_scroll) . '" ';
		$parallax_scroll .= ' both-scroll ';
	}
	$magic_class .= ' magic-scroll ';
}

/* Hover parallax stuff */
	$move_parallax=$move_parallax_attr=$parallax_move='';
	if(!empty($enable_parallax_on_hover) && $enable_parallax_on_hover=='yes' ){
		$move_parallax='dpr-move-parallax';
		$parallax_move='parallax-move';
		$move_parallax_attr .= ' data-move_speed_x="' . esc_attr($move_speed_x) . '" ';
		$move_parallax_attr .= ' data-move_speed_y="' . esc_attr($move_speed_y) . '" ';
	}

/* Content hover effects stuff */
	$hover_class  = '';
	if ($box_hover_effect == "grow") {
		$hover_class .= 'box-hover-grow';
	} elseif ($box_hover_effect == "push") {
		$hover_class .= 'box-hover-push';
	} elseif ($box_hover_effect == "bounce-in") {
		$hover_class .= 'box-hover-bounce-in';
	} elseif ($box_hover_effect == "float") {
		$hover_class .= 'box-hover-float';
	} elseif ($box_hover_effect == "wobble_horizontal") {
		$hover_class .= 'box-hover-wobble-horizontal';
	} elseif ($box_hover_effect == "wobble_vertical") {
		$hover_class .= 'box-hover-wobble-vertical';
	}

/* Continous animations stuff*/
	if ($continuous_effect == 'pulse') {
		$continuous_class .= ' box-effect-pulse ';
	} elseif ($continuous_effect == "floating") {
		$continuous_class .= ' box-effect-floating ';
	} elseif ($continuous_effect == "tossing") {
		$continuous_class .= ' box-effect-tossing ';
	}

/* Hover tilt stuff*/

	if (!empty($enable_hover_3d) && $enable_hover_3d == 'yes') {
		
		$hover_tilt = 'hover-tilt';
	}

/* Block Reveal stuff */

	if (!empty($enable_block_reveal) && $enable_block_reveal == 'yes') {
		$id = uniqid('reveal_');
		$bg_style = '#D3AE5F';
		if ( isset($reveal_overlay_color) && $reveal_overlay_color != '' && $reveal_overlay_type == 'solid') {
			$bg_style = $reveal_overlay_color;
		}
		if ( isset($reveal_overlay_gradient) && $reveal_overlay_gradient != '' && $reveal_overlay_type == 'gradient') {
				$gcArray = explode(';', $reveal_overlay_gradient);
				$gcOrientation = ($gcArray[0]).'deg';
				unset($gcArray[0]);
				$gcColors = '';
				foreach($gcArray as $point) {
					$pointarray = explode('/',$point);
					$gcColors .= ' ,'.$pointarray[1].' '.$pointarray[0].' ';
					
				}
				$bg_style= 'linear-gradient('.$gcOrientation.$gcColors.')';
		}
		if($reveal_animation_type == 'on_load'){
			$reveal_js=" var $id = new RevealFx(document.querySelector('#".$id."'), {
							revealSettings : {
								bgcolor: '".$bg_style."',
								 direction: '".$reveal_animation_direction."',
								 duration: '".$reveal_animation_delay."',
								onCover: function(contentEl, revealerEl) {
									contentEl.style.opacity = 1;
								}
							}
						});
						$id.reveal();
						";
					
		}
		else
		{
			$reveal_js="var scrollElemToWatch_1 = document.getElementById('".$id."'),
							watcher_$id = scrollMonitor.create(scrollElemToWatch_1, -300),				
							$id = new RevealFx(scrollElemToWatch_1, {
								revealSettings : {
									bgcolor: '".$bg_style."',
									direction: '".$reveal_animation_direction."',
									duration: '".$reveal_animation_delay."',
									onCover: function(contentEl, revealerEl) {
										contentEl.style.opacity = 1;
									}
								}
							})
							watcher_$id.enterViewport(function() {
							$id.reveal();
							
							watcher_$id.destroy();
						});
		";
		}
	}


$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->settings['base'], $atts ) );


// Add custom CSS rules

if (dpr_shadow_param_to_css($container_shadow) != '') {
	$custom_el_css .= '.'.$unique_id.'.dpr-animation-box {'.dpr_shadow_param_to_css($container_shadow).'}';
}

if ( $container_bg_color_hover != '' || $container_border_color_hover != '' || $container_border_style_hover != '' || $container_border_radius_hover != '' || dpr_shadow_param_to_css($container_shadow_hover) != '') {
	$custom_el_css .= '.'.$unique_id.'.dpr-animation-box:hover{';
		if ( $container_bg_color_hover != '') {
			$custom_el_css .= 'background-color:'.$container_bg_color_hover.'!important;';
		}
		if ( $container_border_color_hover != '') {
			$custom_el_css .= 'border-color:'.$container_border_color_hover.'!important;';
		}
		if ( $container_border_style_hover != '') {
			$custom_el_css .= 'border-style:'.$container_border_style_hover.'!important;';
		}
		if ( $container_border_radius_hover != '') {
			$custom_el_css .= 'border-radius:'.$container_border_radius_hover.'px!important;';
		}
		if (dpr_shadow_param_to_css($container_shadow_hover) != '') {
			$custom_el_css .= dpr_shadow_param_to_css($container_shadow_hover).';';
		}
	$custom_el_css .= '}';
}


/* Output */



			$output .= '<div id="'. esc_attr($unique_id) .'" class="dpr-animation-box-wrapper '.esc_attr($magic_class).'">';
				$output .= '<div class="animation_box_magic '.esc_attr($parallax_scroll).'" '.$magic_attr.'>';
					$output .= '<div class="animation_mouse_move_parallax '.esc_attr($move_parallax).'" >';
					
						$output .= '<div class="animation_mouse_move_parallax_inner '.esc_attr($parallax_move).'" '.$move_parallax_attr.' >';

							$output .= '<div class="hover_coninous_animation_box box-hover-effect ' . esc_attr($hover_class) . ' ' . esc_attr($continuous_class) . '">';

								$output .= '<div class="dpr-hover-parallax-tilt ' . esc_attr($hover_tilt) . '">';
									
									if (!empty($enable_block_reveal) && $enable_block_reveal == 'yes') {
									$output .= '<div id="'.esc_attr($id).'" class="dpr-reveal-box">';
									}
										$output .= '<div class="dpr-animation-box '.esc_attr($css_class). '">';
									
													$output .= do_shortcode($content);
										
										$output .= '</div>';
									if (!empty($enable_block_reveal) && $enable_block_reveal == 'yes') {
									$output .= '</div>';
									}
								$output .= '</div>';
							
							$output .= '</div>';							
						$output .= '</div>';
						
					$output .= '</div>';
				$output .= '</div>';

				if($reveal_js != '') {
					$output .= '<script>
					jQuery(document).ready(function(){'.
    					$reveal_js 
						.'});
						 </script>';
				}

				
				if($custom_el_css != '') {
					$output .= '<script>'
								. '(function($) {'
									. '$("head").append("<style>'.$custom_el_css.'</style>")'
								. '})(jQuery);'
							. '</script>';
				}
			$output .= '</div>';

echo $output;