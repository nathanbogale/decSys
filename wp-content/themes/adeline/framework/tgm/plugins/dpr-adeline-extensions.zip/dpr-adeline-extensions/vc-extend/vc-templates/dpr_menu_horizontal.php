<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$output = $unique_id = $css_animation = $css = $el_class = '';
$nav_menu = $menu_style = $menu_alignment = $display_menu_cart = $display_social_links = $menu_html = $custom_el_css = '';

$atts = vc_map_get_attributes( 'dpr_menu_horizontal', $atts );
extract( $atts );

$unique_id = uniqid('dpr-menu-horizontal-').'-'.rand(1,9999);

/* CSS Classes and styles */
if ( '' !== $css_animation && 'none' !== $css_animation ) {
	dpr_enqueue_waypoint_js();
	dpr_enqueue_animate_css();
	$el_class .= ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
}
$effect = adeline_get_option_value( 'fullscreen_appear_effect', '', 'overlay-hugeinc' );

if($display_menu_cart != 'yes') {
	$custom_el_css .= '#'.esc_js($unique_id) .' .woo-menu-icon {display:none !important;}'; 
}
/* Output */
$css_classes = array(
	'dpr-builder-menu-horizontal',
	$el_class,
	vc_shortcode_custom_css_class( $css ),
);
if ( $menu_style == 'minimal') {
	$css_classes[] = 'minimal-header';
}
if ( $menu_style == 'full-screen') {
	$css_classes[] = 'full_screen-header';
}


if ($menu_alignment == 'center') {
	$css_classes[] = 'center-menu';
}

$add_style = '';
if ($menu_alignment == 'center') {
}
if ($menu_alignment == 'right') {
	$add_style .= 'float:right;';
}
$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->settings['base'], $atts ) );

	// Get classes for the header menu
	$wrap_classes  = adeline_header_menu_classes( 'wrapper' );
	$inner_classes = adeline_header_menu_classes( 'inner' );
	
	// Get menu classes
	$menu_classes = array( 'main-menu' );
	// If full screen menu style
	if ( 'full-screen' == $menu_style ) {
		$menu_classes[] = 'fs-dropdown-menu';
	} else {
		$menu_classes[] = 'dropdown-menu';
	}
	// If is not full screen menu style
	if ( 'full-screen' != $menu_style ) {
		$menu_classes[] = 'sf-menu';
	}

	// Turn menu classes into space seperated string
	$menu_classes = implode( ' ', $menu_classes );
	
	// Menu arguments
	$menu_args = array(
		'menu' => $nav_menu,
		'menu_class'     => $menu_classes,
		'container'      => false,
		'container_id'   => 'custom-header-menu',
		'fallback_cb'    => false,
		'link_before'    => '<span class="text-wrapper">',
		'link_after'     => '</span>',
		'walker'         => new Adeline_Custom_Nav_Walker(),
	);


	?>

<div id="<?php echo esc_attr($unique_id) ?>" class="<?php echo esc_attr($css_class) ?>">

	<?php if ($menu_style == 'minimal' ) { ?>
		<div class="menu-bar-wrapper clr">
			<div class="menu-bar-inner clr">
				<a href="#" class="menu-bar"><span class="opener"></span></a>
			</div>
		</div>
	<?php } ?>
	
	<?php
    // Social
    if ( true == adeline_get_option_value( 'menu_social_display','',false ) && $menu_style != 'full-screen' && $display_social_links == 'yes') {
        get_template_part( 'template-parts/header/social' );
    } ?>
	<?php 	do_action( 'adeline_before_nav' ); ?>
	<div id="dpr-navigation-wrapper" style=" <?php echo esc_attr($add_style);?> " class="<?php echo esc_attr( $wrap_classes ); ?>">
    
    <?php if ($menu_style == 'full-screen' ) { ?>
		<div class="menu-bar-wrapper clr">
			<div class="menu-bar-inner clr">
				<a href="#" class="menu-bar"><span class="opener"></span></a>
			</div>
		</div>
		<div id="full-screen-menu" class="clr <?php echo esc_attr($effect)?>">
        			<div id="full-screen-menu-inner" class="clr">
	<?php } ?>

    <?php do_action( 'adeline_before_nav_inner' ); ?>
    <nav id="dpr-navigation" class="<?php echo esc_attr( $inner_classes ); ?>"<?php adeline_schema_markup( 'site_navigation' ); ?>>
    	<?php wp_nav_menu( $menu_args ); 
			
			// Header search
			if ( 'full-screen' != $menu_style ) {
				if ( 'drop_down' == adeline_menu_search_style() ) {
					get_template_part( 'template-parts/header/search-dropdown' );
				} else if ( 'expandable_search' == adeline_menu_search_style() ) {
					get_template_part( 'template-parts/header/search-expandable' );
				}
			}
        	// Social links if full screen header style
			if ( 'full-screen' == $menu_style
				&& true == adeline_get_option_value( 'menu_social_display','',false )  && $display_social_links == 'yes') {
				get_template_part( 'template-parts/header/social' );
			} ?>

	</nav>
    <?php do_action( 'adeline_after_nav_inner' ); ?>
    <?php if ($menu_style == 'full-screen' ) { ?>
		</div>
    </div>	
	<?php } ?>
    </div>
    <?php do_action( 'adeline_after_nav' ); ?>	
</div>
	<?php get_template_part( 'template-parts/mobile/mobile-icon' ); ?>

<?php
	if(!empty($custom_el_css)) {
		$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>");'
						. '})(jQuery);'
					. '</script>';
}
echo $output;