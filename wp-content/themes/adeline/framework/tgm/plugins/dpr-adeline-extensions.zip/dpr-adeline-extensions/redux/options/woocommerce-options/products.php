<?php

/**



 * Woocoommerce Options -> Products Archives



 *



 */

Redux::setSection($opt_name, array(

    'title'      => esc_html__('Products Archives', 'dpr-adeline-extensions'),

    'id'         => 'woocommerce_products',

    'subsection' => true,

    'fields'     => array(

        array(

            'id'      => 'woo_shop_page_title',

            'type'    => 'text',

            'title'   => __('Shop Page Title', 'dpr-adeline-extensions'),

            'default' => 'Shop',

            'hint'    => array(

                'title'   => esc_attr__('Shop Page Title', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set custom title for shop page.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'      => 'woo_shop_page_subtitle',

            'type'    => 'text',

            'title'   => __('Shop Page Subtitle', 'dpr-adeline-extensions'),

            'default' => '',

            'hint'    => array(

                'title'   => esc_attr__('Shop Page Subtitle', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set custom subtitle for shop page', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'      => 'woo_page_content_width',

            'type'    => 'image_select',

            'title'   => __('Page Width', 'dpr-adeline-extensions'),

            'options' => array(

                'boxed' => array(

                    'title' => esc_html__('Boxed', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/boxed.png',

                ),

                'full'  => array(

                    'title' => esc_html__('Full Width', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/full_width.png',

                ),

            ),

            'default' => 'boxed',

            'hint'    => array(

                'title'   => esc_attr__('Page Width', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Choose page width boxed or full width.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'      => 'woo_page_content_layout',

            'type'    => 'image_select',

            'title'   => __('Layout', 'dpr-adeline-extensions'),

            'options' => array(

                'right-sidebar' => array(

                    'title' => esc_html__('Sidebar right', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/sidebar_right.png',

                ),

                'left-sidebar'  => array(

                    'title' => esc_html__('Sidebar left', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/sidebar_left.png',

                ),

                'both-sidebars' => array(

                    'title' => esc_html__('Both sidebars', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/sidebar_both.png',

                ),

                'full-width'    => array(

                    'title' => esc_html__('No sidebar', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/sidebar_disabled.png',

                ),

            ),

            'default' => 'right-sidebar',

            'hint'    => array(

                'title'   => esc_attr__('Default Content Layout', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Choose default content layoyt eg sidebar position. This general settings can be overwriten for specific pages.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_page_both_sidebars_column_order',

            'type'     => 'image_select',

            'title'    => __('Both Sidebars: Column Order', 'dpr-adeline-extensions'),

            'options'  => array(

                'order-scs' => array(

                    'title' => esc_html__('Sidebar/Content/Sidebar', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/scs.png',

                ),

                'order-ssc' => array(

                    'title' => esc_html__('Sidebar/Sidebar/Content', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/ssc.png',

                ),

                'order-css' => array(

                    'title' => esc_html__('Content/Sidebar/Sidebar', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/css.png',

                ),

            ),

            'default'  => 'order-scs',

            'hint'     => array(

                'title'   => esc_attr__('Both Sidebars: Column Order', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Choose default column order. This general settings can be overwriten for specific pages.', 'dpr-adeline-extensions'),

            ),

            'required' => array('woo_page_content_layout', 'equals', 'both-sidebars'),

        ),

        array(

            'id'       => 'woo_page_sidebar_right_sticky',

            'type'     => 'switch',

            'default'  => false,

            'title'    => esc_html__('Sidebar Sticky', 'dpr-adeline-extensions'),

            'hint'     => array(

                'title'   => esc_attr__('Right Sidebar Sticky', 'dpr-adeline-extensions'),

                'content' => esc_attr__('If enabled main sidebar stay sticky by scroll', 'dpr-adeline-extensions'),

            ),

            'required' => array('woo_page_content_layout', 'equals', array('right-sidebar', 'both-sidebars', 'left-sidebar')),

        ),

        array(

            'id'       => 'woo_page_sidebar_left_sticky',

            'type'     => 'switch',

            'default'  => false,

            'title'    => esc_html__('Left Sidebar Sticky', 'dpr-adeline-extensions'),

            'hint'     => array(

                'title'   => esc_attr__('Left Sidebar Sticky', 'dpr-adeline-extensions'),

                'content' => esc_attr__('If enabled left sidebar stay sticky by scroll', 'dpr-adeline-extensions'),

            ),

            'required' => array('woo_page_content_layout', 'equals', array('both-sidebars')),

        ),

        array(

            'id'       => 'woo_archive_content_width',

            'type'     => 'dimensions',

            'title'    => esc_html__('Content Width (%)', 'dpr-adeline-extensions'),

            'width'    => true,

            'height'   => false,

            'mode'     => array('width' => 'width', 'height' => 'height'),

            'units'    => array('%'),

            'default'  => array(

                'width' => '72%',

            ),

            'hint'     => array(

                'title'   => esc_attr__('Content Width', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify themain content width (in %).', 'dpr-adeline-extensions'),

            ),

            'required' => array('woo_page_content_layout', 'equals', array('left-sidebar', 'right-sidebar')),

        ),

        array(

            'id'       => 'woo_archive_sidebar_width',

            'type'     => 'dimensions',

            'title'    => esc_html__('Sidebar Width (%)', 'dpr-adeline-extensions'),

            'width'    => true,

            'height'   => false,

            'mode'     => array('width' => 'width', 'height' => 'height'),

            'units'    => array('%'),

            'default'  => array(

                'width' => '28%',

            ),

            'hint'     => array(

                'title'   => esc_attr__('Sidebar Width', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify the sidebar width (in %).', 'dpr-adeline-extensions'),

            ),

            'required' => array('woo_page_content_layout', 'equals', array('left-sidebar', 'right-sidebar')),

        ),

        array(

            'id'       => 'woo_both_sidebars_content_width',

            'type'     => 'dimensions',

            'title'    => esc_html__('Both Sidebars: Content Width (%)', 'dpr-adeline-extensions'),

            'width'    => true,

            'height'   => false,

            'mode'     => array('width' => 'width', 'height' => 'height'),

            'units'    => array('%'),

            'default'  => array(

                'width' => '44%',

            ),

            'hint'     => array(

                'title'   => esc_attr__('Both Sidebars: Content Width', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify the main content width in both sidebars layout (in %).', 'dpr-adeline-extensions'),

            ),

            'required' => array('woo_page_content_layout', 'equals', 'both-sidebars'),

        ),

        array(

            'id'       => 'woo_page_both_sidebars_sidebars_width',

            'type'     => 'dimensions',

            'title'    => esc_html__('Both Sidebars: Sidebars Width (%)', 'dpr-adeline-extensions'),

            'width'    => true,

            'height'   => false,

            'mode'     => array('width' => 'width', 'height' => 'height'),

            'units'    => array('%'),

            'default'  => array(

                'width' => '28%',

            ),

            'hint'     => array(

                'title'   => esc_attr__('Both Sidebars: Sidebars Width', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify the sidebara width in both sidebars layout (in %).', 'dpr-adeline-extensions'),

            ),

            'required' => array('woo_page_content_layout', 'equals', 'both-sidebars'),

        ),

        array(

            'id'      => 'woo_products_per_page',

            'type'    => 'slider',

            'title'   => __('Products Per Page', 'dpr-adeline-extensions'),

            'default' => '3',

            'min'     => '1',

            'step'    => '1',

            'max'     => '100',

            'hint'    => array(

                'title'   => esc_attr__('Products Per Page', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set products per page count.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'      => 'woo_products_columns',

            'type'    => 'radio',

            'title'   => __('Columns Count', 'dpr-adeline-extensions'),

            'options' => array(

                '1' => '1 Column',

                '2' => '2 Columns',

                '3' => '3 Columns',

                '4' => '4 Columns',

                '5' => '5 Columns',

                '6' => '6 Columns',

            ),

            'default' => '3',

            'hint'    => array(

                'title'   => esc_attr__('Columns Count', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set columns count in shop archive view. ', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'      => 'woo_products_columns_tablet',

            'type'    => 'radio',

            'title'   => __('Columns Count: Tablet', 'dpr-adeline-extensions'),

            'options' => array(

                ''  => 'Inherit',

                '1' => '1 Column',

                '2' => '2 Columns',

                '3' => '3 Columns',

                '4' => '4 Columns',

            ),

            'default' => '',

            'hint'    => array(

                'title'   => esc_attr__('Columns Count: Tablet', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set columns count in shop archive view for tablet. ', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'      => 'woo_products_columns_mobile',

            'type'    => 'radio',

            'title'   => __('Columns Count: Mobile', 'dpr-adeline-extensions'),

            'options' => array(

                ''  => 'Inherit',

                '1' => '1 Column',

                '2' => '2 Columns',

                '3' => '3 Columns',

                '4' => '4 Columns',

            ),

            'default' => '',

            'hint'    => array(

                'title'   => esc_attr__('Columns Count: Mobile', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set columns count in shop archive view form mobile. ', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_products_toolbar_info',

            'type'     => 'info',

            'style'    => 'dpr-title',

            'required' => array('menu_cart_style', 'equals', 'drop_down'),

            'title'    => wp_kses_post(__('<h3>Toolbar</h3>', 'dpr-adeline-extensions')),

        ),

        array(

            'id'      => 'woo_products_toolbar_grid',

            'type'    => 'switch',

            'default' => true,

            'title'   => esc_html__('Display Grid/List Switcher', 'dpr-adeline-extensions'),

            'hint'    => array(

                'title'   => esc_attr__('Display Grid/List Switcher', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Hide or display grid/list view switcher.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_products_default_view',

            'type'     => 'image_select',

            'title'    => __('Default View', 'dpr-adeline-extensions'),

            'options'  => array(

                'grid' => array(

                    'title' => esc_html__('Grid View', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/blog-styles/grid.png',

                ),

                'list' => array(

                    'title' => esc_html__('List View', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/blog-styles/small-images.png',

                ),

            ),

            'default'  => 'grid',

            'required' => array('woo_products_toolbar_grid', 'equals', '1'),

            'hint'     => array(

                'title'   => esc_attr__('Default View', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Choose default default view as grid or list.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_products_excerpt_length',

            'type'     => 'slider',

            'title'    => __('Excerpt Length', 'dpr-adeline-extensions'),

            'default'  => '60',

            'min'      => '1',

            'step'     => '1',

            'max'      => '500',

            'required' => array('woo_products_toolbar_grid', 'equals', '1'),

            'desc'     => __('<i><small>Short description length for list view.</small><i>', 'dpr-adeline-extensions'),

            'hint'     => array(

                'title'   => esc_attr__('Excerpt Length', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set length for short description in list view.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'      => 'woo_products_toolbar_sort',

            'type'    => 'switch',

            'default' => true,

            'title'   => esc_html__('Display Sorting Control', 'dpr-adeline-extensions'),

            'hint'    => array(

                'title'   => esc_attr__('Display Sorting Control', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Hide or display product sorting select control.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'      => 'woo_products_toolbar_results_count',

            'type'    => 'switch',

            'default' => true,

            'title'   => esc_html__('Display Shop Results Count', 'dpr-adeline-extensions'),

            'hint'    => array(

                'title'   => esc_attr__('Display Shop Results Count', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Hide or display shop results count.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_products_info',

            'type'     => 'info',

            'style'    => 'dpr-title',

            'required' => array('menu_cart_style', 'equals', 'drop_down'),

            'title'    => wp_kses_post(__('<h3>Products</h3>', 'dpr-adeline-extensions')),

        ),

        array(

            'id'      => 'woo_products_elements',

            'type'    => 'sorter',

            'title'   => 'Products Elements Order',

            'hint'    => array(

                'title'   => esc_attr__('Products Elements Order', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enable or disable display of certain elements of product item and set element order', 'dpr-adeline-extensions'),

            ),

            'options' => array(

                'enabled'  => array(

                    'image'        => 'Image',

                    'title'        => 'Title',

                    'category'     => 'Categories',

                    'price-rating' => 'Price/Rating',

                    'description'  => 'Description',

                    'button'       => 'Add To Cart Button',

                ),

                'disabled' => array(

                ),

            ),

        ),

        array(

            'id'      => 'woo_products_image_style',

            'type'    => 'radio',

            'title'   => __('Product Image Style', 'dpr-adeline-extensions'),

            'options' => array(

                'single-image'   => 'Featured Image',

                'swapping-image' => 'Swapping Image',

                'slider'         => 'Gallery Slider',

            ),

            'default' => 'single-image',

            'hint'    => array(

                'title'   => esc_attr__('Product Image Style', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set style of featured image(s) display. ', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'      => 'woo_quick_view',

            'type'    => 'switch',

            'default' => true,

            'title'   => esc_html__('Display Quick View Button', 'dpr-adeline-extensions'),

            'hint'    => array(

                'title'   => esc_attr__('Display Quick View Button', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Hide or display quick view button.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'      => 'woo_products_content_alignment',

            'type'    => 'radio',

            'title'   => __('Product Content Alignment', 'dpr-adeline-extensions'),

            'options' => array(

                'left'   => 'Left',

                'center' => 'Center',

                'right'  => 'Right',

            ),

            'default' => 'left',

            'hint'    => array(

                'title'   => esc_attr__('Product Description Content Alignment', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set aligmnment for product description. ', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'      => 'woo_products_pagination_style',

            'type'    => 'radio',

            'title'   => __('Pagination Style', 'dpr-adeline-extensions'),

            'options' => array(

                'standard'        => 'Standard',

                'load_more'       => 'Load More Button',

                'infinite_scroll' => 'Infinite Scroll',

            ),

            'default' => 'standard',

            'hint'    => array(

                'title'   => esc_attr__('Pagination Style', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set style for pagination. ', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_products_pagination_infinite_spinners',

            'type'     => 'color',

            'output'   => array('background-color' => '.woocommerce.archive .loader-ellips__dot'),

            'validate' => 'color',

            'title'    => esc_html__('Infinite Scroll: Spinners Color', 'dpr-adeline-extensions'),

            'required' => array('woo_products_pagination_style', 'equals', 'infinite_scroll'),

            'default'  => '#c9c9ce',

            'hint'     => array(

                'title'   => esc_attr__('Infinite Scroll: Spinners Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set color for infinite scroll spinners.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_products_infinite_scroll_last_text',

            'type'     => 'text',

            'title'    => __('Infinite Scroll: Last Text', 'dpr-adeline-extensions'),

            'default'  => 'End of content',

            'required' => array('woo_products_pagination_style', 'equals', 'infinite_scroll'),

            'hint'     => array(

                'title'   => esc_attr__('Infinite Scroll: Last Text', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set infinite scroll last text.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_products_infinite_scroll_error_text',

            'type'     => 'text',

            'title'    => __('Infinite Scroll: Error Text', 'dpr-adeline-extensions'),

            'default'  => 'No more pages to load',

            'required' => array('woo_products_pagination_style', 'equals', 'infinite_scroll'),

            'hint'     => array(

                'title'   => esc_attr__('Infinite Scroll: Error Text', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set infinite scroll error text.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_pagination_loadmore_button_text',

            'type'     => 'text',

            'title'    => __('Load More: Button Text', 'dpr-adeline-extensions'),

            'default'  => 'Load More Products',

            'required' => array('woo_products_pagination_style', 'equals', 'load_more'),

            'hint'     => array(

                'title'   => esc_attr__('Load More: Button Text', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set load more button text.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_pagination_loadmore_nomore_text',

            'type'     => 'text',

            'title'    => __('Load More: End Text', 'dpr-adeline-extensions'),

            'default'  => 'No more products to load',

            'required' => array('woo_products_pagination_style', 'equals', 'load_more'),

            'hint'     => array(

                'title'   => esc_attr__('Load More: End Text', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set load more end text text.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_pagination_loadmore_button_bg',

            'type'     => 'color',

            'output'   => array('background-color' => '.archive.woocommerce .dp-adeline-loadmore-button'),

            'validate' => 'color',

            'title'    => esc_html__('Load More Button Background', 'dpr-adeline-extensions'),

            'required' => array('woo_products_pagination_style', 'equals', 'load_more'),

            'default'  => '#f1f2f4',

            'hint'     => array(

                'title'   => esc_attr__('Load More Button Background', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set background color for load more button.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_pagination_loadmore_button_text_color',

            'type'     => 'color',

            'output'   => array('color' => '.archive.woocommerce .dp-adeline-loadmore-button', 'fill' => '.archive.woocommerce .dp-adeline-loadmore-loading-icon', 'stroke' => '.archive.woocommerce .dp-adeline-loadmore-loading-icon'),

            'validate' => 'color',

            'title'    => esc_html__('Load More Button Color', 'dpr-adeline-extensions'),

            'required' => array('woo_products_pagination_style', 'equals', 'load_more'),

            'default'  => '#292933 ',

            'hint'     => array(

                'title'   => esc_attr__('ILoad More Button Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set color for load more button.', 'dpr-adeline-extensions'),

            ),

        )),

));
