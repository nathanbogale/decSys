<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
/*
Heading style
*/
$output .= $separator_html;
$output .= '<div class="headline-cover">';
$output .= $headline_html;
$output .= $subtitle_html;
$output .= '</div>';