<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$output = $unique_id = $css_animation = $css = $el_class = $switcher_type = $switcher_alignment = '';

$atts = vc_map_get_attributes( 'dpr_language_switcher', $atts );
extract( $atts );

$unique_id = uniqid('dpr-language-switcher-').'-'.rand(1,9999);

/* CSS Classes and styles */
if ( '' !== $css_animation && 'none' !== $css_animation ) {
	dpr_enqueue_waypoint_js();
	dpr_enqueue_animate_css();
	$el_class .= ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
}

/* Output */
$css_classes = array(
	'dpr-language-switcher',
	$el_class,
	vc_shortcode_custom_css_class( $css ),
);
$css_classes[] = $switcher_alignment;

$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->settings['base'], $atts ) );

	?>

<div id="<?php echo esc_attr($unique_id) ?>" class="<?php echo esc_attr($css_class) ?>">
	<?php 
	if($switcher_type == 'custom') {
	do_action('wpml_add_language_selector');
	}
	if($switcher_type == 'footer') {
	do_action('wpml_footer_language_selector');
	}

	?>
</div>

<?php

echo $output;