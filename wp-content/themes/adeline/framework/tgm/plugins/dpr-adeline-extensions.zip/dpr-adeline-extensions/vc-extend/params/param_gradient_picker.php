<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if(!class_exists('DPR_Gradient_Param')) {
	class DPR_Gradient_Param {
		function __construct() {
			add_action( 'admin_enqueue_scripts', array( $this, 'param_scripts' ) );

			if(function_exists('vc_add_shortcode_param')) {
				vc_add_shortcode_param( 'dpr_gradient_picker', array($this, 'dpr_gradient_picker') );
			}
		}
		function param_scripts($hook) {
			wp_enqueue_style( 'dpr-gradient-picker', DPR_EXTENSIONS_PLUGIN_URL.'inc/gradientPicker/css/dpr_gradientCreator.min.css');
			wp_enqueue_script( 'dpr-gradient-picker-js' , DPR_EXTENSIONS_PLUGIN_URL.'inc/gradientPicker/js/dpr_gradientCreator.min.js');
			wp_enqueue_script('redux-spectrum-js' , DPR_EXTENSIONS_PLUGIN_URL.'inc/gradientPicker/js/redux-spectrum.min.js');
		}

		function dpr_gradient_picker($settings, $value)
				{
					
					$param_name = isset($settings['param_name']) ? $settings['param_name'] : '';
					$type = isset($settings['type']) ? $settings['type'] : '';
					$class = isset($settings['class']) ? $settings['class'] : '';
					if ($value == '') $value="0;0% / rgba(0,0,0,0);100% / rgba(0,0,0,0)";
					$gcArray = explode(';', $value);
					$gcOrientation = $gcArray[0];
					unset($gcArray[0]);
					$gcString = implode (";", $gcArray);
					$uni = uniqid(rand());
					$output = '<input type="hidden" id="gcValue-'.$uni.'" class="wpb_vc_param_value ' . $param_name . ' ' . $type . ' ' . $class . '" name="' . $param_name . '" value="'.$value.'"/>';
		    		$output .= '<div id="gcPreview-'.$uni.'" class="vc-gcPreview"><div id="target1-'.$uni.'" class="vc-gcPreviewInner"></div></div><div id="gcPreview-button-'.$uni.'" class="vc-gcPreview-button"><i class="fa fa-arrow-down"></i><i class="fa fa-arrow-up"></i></div>';
					$output .= '<div style="clear:both;"></div>';
					$output .= '<div id="gradient-picker-wrap-'.$uni.'" class="gradient-picker-wrap">';
					$output .= '<div style="clear:both; height:15px;"></div>';
					//Left column
					$output .= '<div class="gradient-picker-wrap-left">';
					
					$output .= '<div class="gcTargetBg">';
					$output .= '<div id="target-'.$uni.'" class="gcTarget"></div>';
					$output .= '</div>';
					$output .= '<div id="dpGradientPicker-'.$uni.'"></div>';  
					$output .= '</div>';			
					//Right column
					$output .= '<div class="gradient-picker-wrap-right">';
					$output .= '<div id="slider-'.$uni.'" style="height:150px; margin:0 0 0 15px"></div>';
					$output .= '<div class="gcOrienatationHolder">';
					$output .= '<input id="dp-gradient-orientation-'.$uni.'" class="gcOrienatation" type="text" value="'.$gcOrientation.'" onchange="changeOrientation();">';
					$output .= '<span class="gcOrienatationSuffix">&#176;</span>';
					$output .= '</div>';
					$output .= '</div>';			
					$output .= '</div>';
					$output .= '<div style="clear:both;height:15px;"></div>';
					$output .= '<script>';
					$output .= 'jQuery(document).ready(function(){  ';
					$output .= 'jQuery("#gradient-picker-wrap-'.$uni.'").hide();';
					$output .= 'jQuery("#gcPreview-button-'.$uni.', #gcPreview-'.$uni.'").click(function(){
        								jQuery("#gradient-picker-wrap-'.$uni.'").slideToggle("slow");
        								jQuery("#gcPreview-button-'.$uni.'").toggleClass("active");
    									});';
					$output .= 'jQuery( "#slider-'.$uni.'" ).slider({
											orientation: "vertical",
											range: "min",
											min: -180,
											max: 180,
											value: '.$gcOrientation.',
											slide: function( event, ui ) {
											var orientation =  ui.value ;
											jQuery("#dpGradientPicker-'.$uni.'").data("gradientCreator").setOrientation(orientation);
											jQuery( "#dp-gradient-orientation-'.$uni.'" ).val( ui.value );
											jQuery("#gcValue-'.$uni.'").val(jQuery("#dpGradientPicker-'.$uni.'").data("gradientCreator").getStringGradient());
											}
										});';
		
					$output .= 'jQuery("#dpGradientPicker-'.$uni.'").gradientCreator({                                
										target: "#target-'.$uni.',#target1-'.$uni.'",
										orientation: '.$gcOrientation.',
										gradient: "'.$gcString.'",
										width:450,
										height: 15,
										tooltipGradient: "0% #e1e3e5,100% #dddddd",
										onChange: function(stringGradient,cssGradient) {
											jQuery("#gcValue-'.$uni.'").val(stringGradient);
										}
									}); ';
					$output .= '});';
					$output .=  'function changeOrientation(){
									var orientation = jQuery("#dp-gradient-orientation-'.$uni.'").val();
									jQuery("#dpGradientPicker-'.$uni.'").data("gradientCreator").setOrientation(orientation);
									jQuery("#gcValue-'.$uni.'").val(jQuery("#dpGradientPicker-'.$uni.'").data("gradientCreator").getStringGradient());
									jQuery("#slider-'.$uni.'").slider("value" , orientation);
								};';
					
					
					$output .= '</script>';
		
					return $output;
				}
		
	}

}

if(class_exists('DPR_Gradient_Param')) {
	$DPR_Gradient_Param = new DPR_Gradient_Param();
}