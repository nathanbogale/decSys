<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$unique_id = $css_animation = $el_class = $css = $output = $custom_el_css = $layout = $alignment = $alignment2 = '';
$use_icon = $icon_size = $icon_color = $icon_image_id = $icon_text = $icon_text_color = $icon_text_font_size = $icon_text_line_height = $icon_text_letter_spacing = $icon_text_font_style = $icon_text_use_google_fonts = $icon_text_google_font = $icon_text_typo_style = $icon_html = '';
$title = $title_color = $title_font_size = $title_line_height = $title_letter_spacing = $title_font_style = $title_use_google_fonts = $title_google_font = $title_typo_style = $title_html = '';
$subtitle = $subtitle_color = $subtitle_font_size = $subtitle_line_height = $subtitle_letter_spacing = $subtitle_font_style = $subtitle_use_google_fonts = $subtitle_google_font = $subtitle_typo_style = $subtitle_html = '';
$number = $units = $number_color = $number_font_size = $number_line_height = $number_letter_spacing = $number_font_style = $number_use_google_fonts = $number_google_font = $number_typo_style = $number_html = '';
$use_number_responsive_typo = $number_reaponsive_typography = '';


$atts = vc_map_get_attributes( 'dpr_counter', $atts );
extract( $atts );

$el_class = $this->getExtraClass( $el_class );
wp_enqueue_script('dpr-waypoints', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/waypoints.min.js', array('jquery'), null, true);
if ( '' !== $css_animation && 'none' !== $css_animation ) {
	dpr_enqueue_animate_css();
	$el_class .= ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
}
$unique_id = uniqid('dpr-counter-').'-'.rand(1,9999);

if(isset($layout)) {
	$el_class .= ' '.$layout;
}
if(isset($layout) && ($layout == 'layout-6')) {
	$el_class .= ' '.$alignment2;
}else{
	$el_class .= ' '.$alignment;
}

if($use_icon != 'yes') {
	$el_class .= ' no-icon';
}

$css_classes = array(
	'dpr-counter',
	$unique_id,
	$el_class,
	vc_shortcode_custom_css_class( $css ),
);

$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->settings['base'], $atts ) );

if(isset($icon_size) && $icon_size !='') {
	$custom_el_css .= '.'.esc_js($unique_id).' .module-icon i {font-size:'.$icon_size.'px;}';
}
if(isset($icon_color) && $icon_color !='') {
	$custom_el_css .= '.'.esc_js($unique_id).' .module-icon i {color:'.$icon_color.';}';
}

$title_typo_style = dpr_generate_typography_style($title_color, $title_font_size, $title_line_height, $title_letter_spacing, $title_font_style,$title_google_font);
$subtitle_typo_style = dpr_generate_typography_style($subtitle_color, $subtitle_font_size, $subtitle_line_height, $subtitle_letter_spacing, $subtitle_font_style,$subtitle_google_font);	
$number_typo_style = dpr_generate_typography_style($number_color, $number_font_size, $number_line_height, $number_letter_spacing, $number_font_style,$number_google_font);	
if($use_number_responsive_typo && isset($number_reaponsive_typography) && $number_reaponsive_typography != '') {
	$responsive_unique_class = '.'.esc_js($unique_id) .' .number-wrap';
	$custom_el_css .= DPR_Resposive_Typography_Param::generate_css($number_reaponsive_typography,$responsive_unique_class);
}

if($use_icon == 'yes') {
	$icon_html .= '<div class="module-icon">';
	if($icon_type == 'icon' && $icon != '' && $icon != 'none') {
		$icon_html .= '<i class="featured-icon '.$icon.'"></i>';
	} elseif('image' === $icon_type ) {
				$img_style = '';
				$image_url = dpr_get_attachment_image_src( $icon_image_id, 'full' );
				if (! empty( $icon_size )){
					
					$image_src = adeline_resize( $image_url[0], $icon_size, $icon_size, true, true, true );
					if(!$image_src) $image_src = $image_url[0];
				
				} else {
					
					$image_src = $image_url[0];
				
				}
				if ( ! empty( $icon_size ) ) {
	
					$img_style .= ' style="';
	
					if ( isset( $icon_size ) && ! empty( $icon_size ) ) {
						$img_style .= 'width:' . esc_attr($icon_size) . 'px;';
					}
	
					$img_style .= '"';
	
				}
				$alt_text = get_post_meta($icon_image_id , '_wp_attachment_image_alt', true);
				$icon_html .= '<img src="' . esc_url($image_src) . '"' . $img_style . ' alt="'.esc_attr($alt_text).'"/>';
				
			} elseif('text' === $icon_type && $icon_text != '' ) {
				$icon_text_typo_style = dpr_generate_typography_style($icon_text_color, $icon_text_font_size, $icon_text_line_height, $icon_text_letter_spacing, $icon_text_font_style, $icon_text_google_font);
				$icon_html .= '<span class="dpr-text-icon-wrap" '.$icon_text_typo_style.'>'.  esc_html($icon_text).'</span>';
			} 
	$icon_html .= '</div>';
}

$title_html .= '<div class="title-wrap">';
	if (isset($title) && !empty($title)) {
		$title_html .= '<h4 class="counter-title" '.$title_typo_style.'>'.wp_kses_post($title).'</h4>';
	}
	if (isset($subtitle) && !empty($subtitle)) {
		$title_html .= '<div class="counter-subtitle" '.$subtitle_typo_style.'>'.esc_html($subtitle).'</div>';
	}
$title_html .= '</div>';

$data_count = 'data-count="'.esc_attr($number).'"';
$number_html .= '<div class="number-wrap">';
	$number_html .= '<div class="number-wrap-inner">';
		$number_html .= '<div class="counter-numbers call-on-in-viewport" data-animation="'.esc_attr($animation).'" '.$data_count.' '.$number_typo_style.'>';
		if ($animation == 'none') {
			$number_html .= esc_attr($number);
		}else{
			$number_html .= '0';
		}
		$number_html .= '</div>';
		if(isset($units) && $units != ''){
		$number_html .= '<span class="units" '.$number_typo_style.'>'.$units.'</span>';
		}
	$number_html .= '</div>';
$number_html .= '</div>';



$output .= '<div id="'.esc_attr($unique_id).'" class="'.esc_attr($css_class).'">';

switch($layout)
{
    case 'layout-1';
	case 'layout-7';
		$output .= $icon_html;
		$output .= $number_html;
		$output .= $title_html;
	break;
    case 'layout-2';
		$output .= $number_html;
		$output .= $title_html;
		$output .= $icon_html;
	break;
    case 'layout-3';
        $output .= $number_html;
		$output .= '<div class="title-wrap">';
		$output .= $icon_html;
		$output .= '<div class="title-wrap-inner">';
			if (isset($title) && !empty($title)) {
				$output .= '<h4 class="counter-title" '.$title_typo_style.'>'.esc_html($title).'</h4>';
			}
			if (isset($subtitle) && !empty($subtitle)) {
				$output .='<div class="counter-subtitle" '.$subtitle_typo_style.'>'.esc_html($subtitle).'</div>';
			}
		$output .= '</div>';
		
		$output .= '</div>';
    break;
    case 'layout-4';
        $output .= '<div class="head-wrap">';
		$output .= $icon_html;
		$output .= $number_html;
		$output .= '</div>';
		$output .= $title_html;
    break;
    case 'layout-5';
        $output .= $icon_html;
		$output .= '<div class="head-wrap">';
		$output .= $number_html;
		$output .= $title_html;
		$output .= '</div>';
    break;
    case 'layout-6';
        $output .= '<div class="head-wrap">';
		$output .= $icon_html;
		$output .= $number_html;
		$output .= $title_html;
		$output .= '</div>';
    break;
    case 'layout-8';
		$output .= $number_html;
		$output .= $icon_html;		
		$output .= $title_html;
	break;

}

if(!empty($custom_el_css)) {
		$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>");'
						. '})(jQuery);'
					. '</script>';
}
$output .= '</div>';


echo $output;