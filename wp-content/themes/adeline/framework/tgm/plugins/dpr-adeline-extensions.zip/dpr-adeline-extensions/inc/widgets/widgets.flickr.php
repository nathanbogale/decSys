<?php

/**

 * Flickr Widget.

 *

 */



// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}



if ( ! class_exists( 'DPR_Flickr_Widget' ) ) {

	class DPR_Flickr_Widget extends WP_Widget {



		/**

		 * Register widget with WordPress.

		 *

		 */

		public function __construct() {

			parent::__construct(

				'dpr_flickr',

				esc_html__( 'DPR Flickr', 'dpr-adeline-extensions' ),

				array(

					'classname'   => 'widget-dpr-flickr flickr-widget',

					'description' => esc_html__( 'Use this widget to show gallery from Flickr.', 'dpr-adeline-extensions' ),

					'customize_selective_refresh' => true,

				)

			);

		}



		/**

		 * Front-end display of widget.

		 *

		 * @see WP_Widget::widget()

		 *

		 * @param array $args     Widget arguments.

		 * @param array $instance Saved values from database.

		 */

		public function widget( $args, $instance ) {



			$title      = isset( $instance['title'] ) ? apply_filters( 'widget_title', $instance['title'] ) : '';

			$number   	= isset( $instance['number'] ) ? $instance['number'] : '';

			$id  		= isset( $instance['id'] ) ? $instance['id'] : '';

			$link  		= isset( $instance['link'] ) ? $instance['link'] : '';

			// Before widget WP hook

			echo $args['before_widget'];



				// Show widget title

				if ( $title ) {

					echo $args['before_title'] . $title . $args['after_title'];

				}



				// Display flickr feed if ID is defined

				if ( $id ) : ?>

					<div class="dpr-flickr-wrap">

						<script src="https://www.flickr.com/badge_code_v2.gne?count=<?php echo intval( $number ); ?>&amp;display=latest&amp;size=s&amp;layout=x&amp;source=user&amp;user=<?php echo strip_tags( $id ); ?>"></script>

						<?php if ($link == "true") { ?>

                        <p class="flickr_stream_wrap"><a class="follow_btn" href="http://www.flickr.com/photos/<?php echo strip_tags( $id ); ?>"><?php esc_html_e( 'View stream on flickr', 'dpr-adeline-extensions' ); ?></a></p>

						<?php } ?>

					</div>

				<?php endif;



			// After widget WP hook

			echo $args['after_widget'];



		}



		/**

		 * Sanitize widget form values as they are saved.

		 *

		 * @see WP_Widget::update()

		 *

		 * @param array $new_instance Values just sent to be saved.

		 * @param array $old_instance Previously saved values from database.

		 *

		 * @return array Updated safe values to be saved.

		 */

		public function update( $new_instance, $old_instance ) {

			$instance               = $old_instance;

			$instance['title']      = ! empty( $new_instance['title'] ) ? strip_tags( $new_instance['title'] ) : '';

			$instance['number']     = ! empty( $new_instance['number'] ) ? intval( $new_instance['number'] ) : '';

			$instance['id']     	= ! empty( $new_instance['id'] ) ? strip_tags( $new_instance['id'] ) : '';

			$instance['link']     	= ! empty( $new_instance['link'] ) ? strip_tags( $new_instance['link'] ) : '';

			return $instance;

		}



		/**

		 * Back-end widget form.

		 *

		 * @see WP_Widget::form()

		 *

		 * @param array $instance Previously saved values from database.

		 */

		public function form( $instance ) {



			// Parse arguments

			$instance = wp_parse_args( (array) $instance, array(

				'title'         => esc_attr__( 'Flickr Photos', 'dpr-adeline-extensions' ),

				'id' 			=> '86832534@N03',

				'number'		=> 6,

				'link' => 'false'

			) ) ; ?>



			<p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title', 'dpr-adeline-extensions' ); ?>:</label>

				<input class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['title'] ); ?>" />

			</p>



			<p>

				<label for="<?php echo $this->get_field_id('id'); ?>"><?php esc_html_e( 'Flickr ID', 'dpr-adeline-extensions' ); ?></label>

				<input class="widefat" id="<?php echo $this->get_field_id('id'); ?>" name="<?php echo $this->get_field_name('id'); ?>" type="text" value="<?php echo esc_attr( $instance['id'] ); ?>" />

				<small><?php esc_html_e( 'Get Flickr ID entering url of your Flickr page on this site: idgettr.com.', 'dpr-adeline-extensions' ); ?></small>

			</p>



			<p>

				<label for="<?php echo $this->get_field_id('number'); ?>"><?php esc_html_e( 'Number:', 'dpr-adeline-extensions' ); ?></label>

				<input class="widefat" id="<?php echo $this->get_field_id('number'); ?>" name="<?php echo $this->get_field_name('number'); ?>" type="text" value="<?php echo esc_attr( $instance['number'] ); ?>" />

				<small><?php esc_html_e( 'The maximum is 10 images.', 'dpr-adeline-extensions' ); ?></small>

			</p>

            <p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'link' ) ); ?>"><?php esc_html_e( 'Show link to flickr stream:', 'dpr-adeline-extensions' ); ?></label>

				<select class='widefat' name="<?php echo $this->get_field_name( 'link' ); ?>" id="<?php echo $this->get_field_id( 'link' ); ?>">

					<option value="false" <?php if ( $instance['link'] == 'false') { ?>selected="selected"<?php } ?>><?php esc_html_e( 'Disabled', 'dpr-adeline-extensions' ); ?></option>

					<option value="true" <?php if ( $instance['link'] == 'true') { ?>selected="selected"<?php } ?>><?php esc_html_e( 'Enabled', 'dpr-adeline-extensions' ); ?></option>

				</select>

            </p>

		<?php



		}



	}

}

