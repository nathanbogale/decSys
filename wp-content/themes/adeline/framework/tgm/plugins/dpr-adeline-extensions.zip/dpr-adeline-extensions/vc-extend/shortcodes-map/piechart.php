<?php

// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}

/*

* Add-on Name: Piecharts

*/



class WPBakeryShortCode_DPR_Piechart extends WPBakeryShortCode {}



vc_map(

	array(

		'name'					=> esc_html__(' DP Pie Chart', 'dpr-adeline-extensions'),

		'base'					=> 'dpr_piechart',

		'class'					=> 'dpr_piechart',

		'icon'					=> 'icon-dpr-piechart',

  		"category" =>array( esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions')),

		'description'			=> esc_html__('Display animated pie chart', 'dpr-adeline-extensions'),

		'params'				=> array(

			array(

				'heading'			=> esc_html__('Layout', 'dpr-adeline-extensions'),

				'type'				=> 'dpr_image_select',

				'param_name'		=> 'layout',

				'simple_mode'		=> false,

				'options'			=> array(

					'layout-1'	=> array(

						'label'	=> esc_html__('Default','dpr-adeline-extensions'),

						'src'		=> $module_images . 'piechart/layout-1.png'

					),

					'layout-2'	=> array(

						'label'	=> esc_html__('Icon Center','dpr-adeline-extensions'),

						'src'		=> $module_images . 'piechart/layout-2.png'

					),

					'layout-3'	=> array(

						'label'	=> esc_html__('Icon by number','dpr-adeline-extensions'),

						'src'		=> $module_images . 'piechart/layout-3.png'

					),

					'layout-4'	=> array(

						'label'	=> esc_html__('Icon by title','dpr-adeline-extensions'),

						'src'		=> $module_images . 'piechart/layout-4.png'

					),

				),

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Content', 'dpr-adeline-extensions' ),

				'param_name'       => 'content_title',

				'edit_field_class' => 'vc_column vc_col-sm-12',

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set the number to display in pie chart.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Number', 'dpr-adeline-extensions'),

				'param_name'		=> 'number',

				'value'				=> 75,

				'min'				=> '10',

				'max'				=> '100',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

			),

			array(

				'type'				=> 'textfield',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set the measuring units you\'d like to display in the pie chart.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Unit', 'dpr-adeline-extensions'),

				'param_name'		=> 'unit',

				'value'				=> esc_html__('%', 'dpr-adeline-extensions'),

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set the size of the pie chart circle', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Circle size', 'dpr-adeline-extensions'),

				'param_name'		=> 'size',

				'suffix'			=> 'px',

				'value'				=> 160,

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to enable or disable the circle animation.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Disable Animation?', 'dpr-adeline-extensions'),

				'param_name'		=> 'animation_disable',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				)

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to change the direction for the animation.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Animation Anticlockwise?', 'dpr-adeline-extensions'),

				'param_name'		=> 'counterclockwise',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				)

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to enable icon usage.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Use Icon?', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_icon',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

				'dependency'		=> array('element' => 'layout', 'value'	=> array( 'layout-2', 'layout-3','layout-4')),

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				)

			),

			array(

				'type'				=> 'textfield',

				'heading'			=> esc_html__('Title', 'dpr-adeline-extensions'),

				'param_name'		=> 'title',

				'value'				=> esc_html__('Chart Title', 'dpr-adeline-extensions'),

				'admin_label'		=> true,

			),

			array(

				'type'				=> 'textfield',

				'heading'			=> esc_html__('Subtitle', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle',

				'value'				=> esc_html__('Chart subtitle', 'dpr-adeline-extensions'),

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Additional Settings', 'dpr-adeline-extensions' ),

				'param_name'       => 'extra_features_title',

				'edit_field_class' => 'vc_column vc_col-sm-12',

			),

		   vc_map_add_css_animation( false ),

		    array(

				'type' => 'textfield',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Extra Class Name', 'dpr-adeline-extensions'),

				'param_name' => 'el_class',

			),



			/*

			* Icon

			*/

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Use the existing icon font, upload custom image or SVG or add the text', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon Type', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_type',

				'value'				=> 'icon',

				'options'				=> array(

					esc_html__('Icon', 'dpr-adeline-extensions')	=> 'icon',

					esc_html__('Image', 'dpr-adeline-extensions')	=> 'image',

					esc_html__('Text', 'dpr-adeline-extensions')	=> 'text',

				),

				'dependency'		=> array('element' => 'use_icon', 'value' => array('yes')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

		  array(

				"type" => "dpr_icon_selector",

				"heading" => esc_attr__("Icon", 'dpr-adeline-extensions'),

				"param_name" => "icon",

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select icon.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'icon_type', 'value' => 'icon',),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'attach_image',

				'class'				=> '',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Upload the custom image or choose from media library.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Image', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_image_id',

				'dependency'		=> array('element' => 'icon_type', 'value' => array('image')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'textfield',

				'heading'			=> esc_html__('Text', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_text',

				'dependency'		=> array('element' => 'icon_type', 'value' => array('text')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set the size for the icon (image)', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Size', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_size',

				'suffix' 			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-6   ',

				'dependency'		=> array('element' => 'icon_type', 'value'   => array('icon', 'image')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'class'				=> '',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the icon color. The default color is #e1e4e9', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6  ',

				'dependency'		=> array('element' => 'icon_type', 'value' => array('icon')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Icon Text Typography', 'dpr-adeline-extensions' ),

				'param_name'       => 'icon_typography_title',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'icon_type', 'value' => array('text')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose title color. The default color is #292933', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Title Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_text_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-3  ',

				'dependency'		=> array('element' => 'icon_type', 'value' => array('text')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size. If you leave this field blank will be used default size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_text_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'icon_type', 'value' => array('text')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title linne height.Default is 18px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_text_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'icon_type', 'value' => array('text')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_text_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'icon_type', 'value' => array('text')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'icon_text_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'dependency'		=> array('element' => 'icon_type', 'value' => array('text')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

	  		),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font. .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_text_use_google_fonts',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'dependency'		=> array('element' => 'icon_type', 'value' => array('text')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'icon_text_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'dependency'		=> array('element' => 'icon_text_use_google_fonts', 'value' => 'yes'),

				'group'				=> esc_attr__('Icon', 'dpr-adeline-extensions'),

			),



			/*

			* Circle Style

			*/

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Pie Chart Bar', 'dpr-adeline-extensions'),

				'param_name'		=> 'chart_title_1',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Chart Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select pie chart bar color style.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color Style', 'dpr-adeline-extensions'),

				'param_name'		=> 'bar_color_type',

				'value'				=> 'solid',

				'options'				=> array(

					esc_html__('Solid', 'dpr-adeline-extensions')	=> 'solid',

					esc_html__('Gradient', 'dpr-adeline-extensions')	=> 'gradient'

				),

				'group'				=> esc_html__('Chart Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose piechart bar color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Bar Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'bar_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'bar_color_type', 'value' => 'solid'),

				'group'				=> esc_html__('Chart Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'param_group',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Add pie chart gradient color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Gradient Colors', 'dpr-adeline-extensions'),

				'param_name'		=> 'gradient_colors_pallete',

				'value' => urlencode( json_encode( array(

				array(

					'color' => '#FF057C',

				),

				array(

					'color' => '#7C64D5',

				),

				array(

					'color' => '#4CC3FF',

				),

			) ) ),



				'params'			=> array(

						array(

							'type'				=> 'colorpicker',

							'heading' 			=> esc_html__('Color', 'dpr-adeline-extensions'),

							'param_name'		=> 'color',

							'admin_label'		=> true,

							'edit_field_class'	=> 'vc_column vc_col-sm-12',

						),

				),

				'dependency'		=> array('element' => 'bar_color_type', 'value' => 'gradient'),

				'group'				=> esc_html__('Chart Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Specify the width for the pie chart bar.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Bar Width', 'dpr-adeline-extensions'),

				'param_name'		=> 'bar_width',

				'value'				=> 7,

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

				'group'				=> esc_html__('Chart Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Background Circle Style', 'dpr-adeline-extensions'),

				'param_name'		=> 'chart_title_2',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Chart Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose piechart background circle color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background  Circle Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'circle_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'dependency'		=> array('element' => 'color_style', 'value' => 'solid'),

				'group'				=> esc_html__('Chart Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Specify the width for the pie chart background circle.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background Circle Width', 'dpr-adeline-extensions'),

				'param_name'		=> 'circle_width',

				'value'				=> 1,

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'group'				=> esc_html__('Chart Style', 'dpr-adeline-extensions'),

			),

			/*

			* Typography

			*/

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Number Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'number_typography_head',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose title color. The default color is #292933', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Number Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'number_color',

				'value'				=> '#292933',

				'edit_field_class'	=> 'vc_column vc_col-sm-3  ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size. If you leave this field blank will be used default size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'number_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title linne height.Default is 18px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'number_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'number_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'number_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

	  		),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font. .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'number_use_google_fonts',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'number_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'number_use_google_fonts', 'value' => 'yes'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Title Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_typography_head',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'title', 'not_empty' => true),

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose title color. The default color is #292933', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Title Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-3  ',

				'dependency'		=> array('element' => 'title', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size. If you leave this field blank will be used default size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'title', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title linne height.Default is 18px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'title', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'title', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'title_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'dependency'		=> array('element' => 'title', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

	  		),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font. .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_use_google_fonts',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'dependency'		=> array('element' => 'title', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'title_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'dependency'		=> array('element' => 'title_use_google_fonts', 'value' => 'yes'),

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),



			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Subtitle Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_typography_head',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose title color. The default color is #292933', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Subtitle Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-3  ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size. If you leave this field blank will be used default size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title linne height.Default is 18px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'subtitle_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

	  		),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font. .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_use_google_fonts',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'subtitle_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'subtitle_use_google_fonts', 'value' => 'yes'),

			),

			array(

				'type' => 'css_editor',

				'heading' => __( 'CSS box', 'dpr-adeline-extensions' ),

				'param_name' => 'css',

				'group' => __( 'Design Options', 'dpr-adeline-extensions' ),

			),











		)

	)

);