<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$output = $unique_id = $css_animation = $css = $el_class = '';
$image  = $image_width = $image_height= $logo_alignment = '';
$image_html = '';

$atts = vc_map_get_attributes( 'dpr_logo', $atts );
extract( $atts );

$unique_id = uniqid('dpr-logo-').'-'.rand(1,9999);

/* CSS Classes and styles */
if ( '' !== $css_animation && 'none' !== $css_animation ) {
	dpr_enqueue_waypoint_js();
	dpr_enqueue_animate_css();
	$el_class .= ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
}

/* Output */
$css_classes = array(
	'dpr-builder-logo',
	$el_class,
	vc_shortcode_custom_css_class( $css ),
);

$add_style = '';
if ($logo_alignment == 'center') {
	$add_style .= 'margin: 0 auto;';
}
if ($logo_alignment == 'right') {
	$add_style .= 'float:right;';
}
$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->settings['base'], $atts ) );


/*HTML Parts */
		/* Image */
		$w = 200;
		$h = 60;
		if(isset($image_width) && $image_width != '') {
			$w = $image_width;
		}
		if(isset($image_height) && $image_height != '') {
			$h = $image_height;
		}
		
		if(isset($image) && $image != '') {
			$img_src = dpr_get_attachment_image_src($image, 'full');
			$img_atts = adeline_image_attributes( $img_src[1], $img_src[2], $w, $h );
			$alt_text = get_post_meta($image , '_wp_attachment_image_alt', true);
			$image_html = '<img src="'. adeline_resize( $img_src[0], $img_atts[ 'width' ], $img_atts[ 'height' ], $img_atts[ 'crop' ], true, $img_atts[ 'upscale' ] ).'" alt ="'.esc_attr($alt_text).'" width="'. esc_attr( $w ).'" height="'. esc_attr( $h ).'"/>';
		} 
?>

<div id="<?php echo esc_attr($unique_id) ?>" class="<?php echo esc_attr($css_class) ?>">
	<div id="dpr-logo" style=" <?php echo esc_attr($add_style);?> " class="<?php echo esc_attr( adeline_header_logo_classes() ); ?>"<?php adeline_schema_markup( 'logo' ); ?>>


	<div id="dpr-logo-inner" class="clr">

		<?php if ($logo_type == 'inherit') {

			echo adeline_header_logo();			
			
			adeline_print_mobile_logo();
			
			adeline_print_sticky_logo();
		} else {
			echo '<a href="'.esc_url( home_url( '/' ) ).'" class="custom-logo-link" rel="home">';
			echo wp_kses_post($image_html);
			echo '</a>';
		}

			do_action( 'adeline_after_logo_img' );

  ?>

	</div><!-- #dpr-logo-inner -->



</div>		
</div>

<?php


echo $output;