<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$unique_id = $el_class = $custom_el_css = $anim_class = $type = $bubble_bg_color = $bubble_border_color = $bubble_border_radius = $bubble_width = $css = "";
$node_style = $node_size = $node_inner_size = $node_bg_color = $node_border_color = $node_inner_color = $node_border_width = $node_border_radius = '';
$date_text = $date_bg_color = $date_border_color = $date_border_width = $date_border_radius = $text_color = $text_font_size = $text_line_height = $text_letter_spacing = $text_font_style = $use_google_fonts = $text_google_font = '';
$node_html = $date_html = $content_html = $output = '';

$atts = vc_map_get_attributes( 'dpr_time_line_item', $atts );
extract( $atts );

$unique_id = uniqid('dpr-timeline-item-').'-'.rand(1,9999);
if ( '' !== $css_animation && 'none' !== $css_animation ) {
	dpr_enqueue_waypoint_js();
	dpr_enqueue_animate_css();
	$anim_class .= ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
}

/* Element classes */
if(isset($type) & $type !='') {
	$el_class .= ' '.$type;
}

$css_classes = array(
	'dpr-timeline-item',
	esc_attr($unique_id),
	$el_class,
	vc_shortcode_custom_css_class( $css ),
);

$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->settings['base'], $atts ) );

/* * ************************
 * Styles and custom CSS
 * *********************** */
if(isset($bubble_bg_color) && !empty($bubble_bg_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .item-content .inner {background-color: '.esc_attr($bubble_bg_color).';}';
	$custom_el_css .= '.'.esc_js($unique_id).'.left .item-content .inner:after {border-left-color:'.esc_attr($bubble_bg_color).'}';
	$custom_el_css .= '.'.esc_js($unique_id).'.right .item-content .inner:after {border-right-color:'.esc_attr($bubble_bg_color).'}';
}
if(isset($bubble_border_color) && !empty($bubble_border_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .item-content .inner {border-color: '.esc_attr($bubble_border_color).';}';
	$custom_el_css .= '.'.esc_js($unique_id).'.left .item-content .inner:before {border-left-color:'.esc_attr($bubble_border_color).'}';
	$custom_el_css .= '.'.esc_js($unique_id).'.right .item-content .inner:before {border-right-color:'.esc_attr($bubble_border_color).'}';
}
if(isset($bubble_border_radius) && !empty( $bubble_border_radius)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .item-content .inner {border-radius: '.esc_attr( $bubble_border_radius).'px;}';
}
if(isset($node_size) && !empty( $node_size)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .timeline-node {width: '.esc_attr( $node_size).'px;height: '.esc_attr( $node_size).'px;}';
	$custom_el_css .= '.'.esc_js($unique_id).'.left .item-content {padding-right: '.esc_attr( ($node_size/2 + 25)).'px;}';
	$custom_el_css .= '.'.esc_js($unique_id).'.right .item-content {padding-left: '.esc_attr( ($node_size/2 + 25)).'px;}';
	$custom_el_css .= '.'.esc_js($unique_id).'.left .item-date {padding-left: '.esc_attr( ($node_size/2 + 15)).'px;}';
	$custom_el_css .= '.'.esc_js($unique_id).'.right .item-date {padding-right: '.esc_attr( ($node_size/2 + 15)).'px;}';
}
if(isset($node_bg_color) && !empty($node_bg_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .timeline-node .node-inner{background-color: '.esc_attr($node_bg_color).';}';
}
if(isset($node_border_color) && !empty($node_border_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .timeline-node .node-inner {border-color: '.esc_attr($node_border_color).';}';
}
if(isset($node_border_width) && !empty($node_border_width)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .timeline-node .node-inner {border-width: '.esc_attr($node_border_width).'px;}';
}
if(isset($node_border_radius) && !empty($node_border_radius)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .timeline-node .node-inner{border-radius: '.esc_attr($node_border_radius).'px;}';
}
if(isset($node_style) && $node_style == 'style-2') {
	if(isset($node_inner_size) && !empty($node_inner_size)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .timeline-node .node-dot{width: '.esc_attr($node_inner_size).'px;height: '.esc_attr($node_inner_size).'px;}';
	}
	if(isset($node_inner_color) && !empty($node_inner_color)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .timeline-node .node-dot{background-color: '.esc_attr($node_inner_color).' !important;}';
	}
}
if(isset($date_bg_color) && !empty($date_bg_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .date-label {background-color: '.esc_attr($date_bg_color).';}';
}
if(isset($date_border_color) && !empty($date_border_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .date-label {border-color: '.esc_attr($date_border_color).';}';
}
if(isset($date_border_width) && !empty($date_border_width)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .date-label {border-width: '.esc_attr($date_border_width).'px;}';
}
if(isset($date_border_radius) && !empty($date_border_radius)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .date-label {border-radius: '.esc_attr($date_border_radius).'px;}';
}

/* * ************************
 * Partial HTML.
 * *********************** */
if(!empty($date_text)) {
	$date_typo_style = dpr_generate_typography_style($text_color, $text_font_size, $text_line_height, $text_letter_spacing, $text_font_style,$text_google_font);
	$date_html .= '<div class="item-date">';
		$date_html .= '<div class="date-label" '.$date_typo_style.'>';
			$date_html .= '<span>'.esc_html($date_text).'</span>';
		$date_html .= '</div>';
	$date_html .= '</div>';
}
$content_html .= '<div class="item-content'.$anim_class.'">';
	$content_html .= '<div class="inner">';
		if($type == 'center') {
		$content_html .= '<div class="date-label" '.$date_typo_style.'>';
			$content_html .= '<span>'.esc_html($date_text).'</span>';
		$content_html .= '</div>';
		}
		$content_html .= do_shortcode($content);
	$content_html .= '</div>';
$content_html .= '</div>';



$node_html .= '<div class="timeline-node '.esc_attr($node_style).'">';
	$node_html .= '<div class="node-inner">';
		$node_html .= '<div class="node-dot"></div>';
	$node_html .= '</div>';
$node_html .= '</div>';

/* * ************************
 * Output
 * *********************** */
$output .= '<div id="'.esc_attr($unique_id).'" class="'.esc_attr($css_class).' clr">';
	$output .= '<div class="inner">';
	$output .= $node_html;
	switch($type) {
		case 'right';
		$output .= $date_html;
		$output .= $content_html;
		break;
		case 'left';
		$output .= $content_html;
		$output .= $date_html;
		break;
		case 'center';
		$output .= $content_html;
		break;
	}
	$output .= "</div>";
if(!empty($custom_el_css)) {
		$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>");'
						. '})(jQuery);'
					. '</script>';
}
$output .= "</div>";
echo $output;

