var $j = jQuery.noConflict();



$j( document ).on( 'ready', function() {

	"use strict";

	// Custom select

	dprInitializeAnimatedBackgroundText();

} );



/* ==============================================

ANIMATED TITLE

============================================== */

function dprInitializeAnimatedBackgroundText() {

			"use strict";
			
			$j('.dpr_row_bg_text').each(function () {

				var $self =  $j(this),
					toSplit = $self.find('h1');
					arrayMe(toSplit);

				$j(this).find('h1').on('on-in-viewport', function () {

					if (!$self.hasClass('animated')){

					$self.addClass('animated');

					$self.find(".dpr-single-char > span").each(function(e) {
                                $j(this).css("transition-delay", 120 * e + "ms").addClass("dpr-show")
                    })

					}
					

				}

			);

});

}


function arrayMe(string) {

	// For all matching elements
	$j(string).each(function() {



		// Get contents of string
		var myStr = $j(this);
		myContents = myStr.text().replace(/[^\s]/g, function(e) {
          return '<span class="dpr-single-char"><span>' + e + "</span></span>"
        });

		

		// Replace original string with constructed html string
		$j(this).html(myContents);
	});
}

			
										