<?php

// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}



//VC TTA Accordion VC Map modifications



$settings = array (

  'name' => __( 'DP Accordion', 'dpr-adeline-extensions' ),

  'category' =>array( esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions')),

  'icon' => 'icon-dpr-accordion'

);



vc_map_update( 'vc_tta_accordion', $settings ); 





if(function_exists('vc_remove_param')) {

	

	vc_remove_param('vc_tta_accordion','no_fill');

	vc_remove_param('vc_tta_accordion','title');

	vc_remove_param('vc_tta_accordion','style');

	vc_remove_param('vc_tta_accordion','shape');

	vc_remove_param('vc_tta_accordion','color');

	vc_remove_param('vc_tta_accordion','spacing');

	vc_remove_param('vc_tta_accordion','gap');

	vc_remove_param('vc_tta_accordion','autoplay');

	vc_remove_param('vc_tta_accordion','collapsible_all');

	vc_remove_param('vc_tta_accordion','c_icon');

	vc_remove_param('vc_tta_accordion','c_align');

	vc_remove_param('vc_tta_accordion','c_position');

	vc_remove_param('vc_tta_accordion','active_section');

	vc_remove_param('vc_tta_accordion','el_id');

	vc_remove_param('vc_tta_accordion','el_class');



}



/* General Tabs */



	vc_add_param(

		'vc_tta_accordion', array(

			'type' => 'hidden',

			'param_name' => 'no_fill',

			'std' => true,

		)

	);

	vc_add_param(

		'vc_tta_accordion', array(

			'type' => 'textfield',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Enter text used as widget title (Note: located above content element).', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Widget Title', 'dpr-adeline-extensions'),

			'param_name' => 'title',

			'value' => '',

			'weight' => 1

		)

	);



	vc_add_param(

		'vc_tta_accordion', array(

			'type' => 'dpr_image_select',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Select general style for this accordion', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Style', 'dpr-adeline-extensions'),

			'param_name' => 'style',

			'weight' => '1',

			'value' => 'style_1',

			'options'			=> array(

				'style_1'			=> array(

					'label'			=> esc_html__('Classic','dpr-adeline-extension'),

					'src'				=> $module_images . 'accordion/style_1.png'

				),

				'style_2'			=> array(

					'label'			=> esc_html__('Outlined','dpr-adeline-extension'),

					'src'				=> $module_images . 'accordion/style_3.png'

				),

				'style_3'			=> array(

					'label'			=> esc_html__('Underlined','dpr-adeline-extension'),

					'src'				=> $module_images . 'accordion/style_2.png'

				)

			),

		)

	);



	



	vc_add_param(

		'vc_tta_accordion', array(

			'type' => 'dpr_switcher',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allow collapse all accordion sections.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Allow collapse all?', 'dpr-adeline-extensions'),

			'param_name' => 'collapsible_all',

			'weight' => '1',

			'edit_field_class' => 'vc_column vc_col-sm-6',

			'value' => '',

			'options' => array(

				'yes' => array(

						'label' => '',

						'on' => 'Yes',

						'off' => 'No',

					),

				),

		)

	);



	vc_add_param(

		'vc_tta_accordion', array(

			'type' => 'dropdown',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select accordion spacing. This is space between accordion tab and tab content.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Spacing', 'dpr-adeline-extensions'),

			'param_name' => 'spacing',

			'weight' => '1',

			'edit_field_class' => 'vc_column vc_col-sm-6',

			'value' => array(

				__( 'None', 'dpr-adeline-extensions' ) => '',

				'1px' => '1',

				'2px' => '2',

				'3px' => '3',

				'4px' => '4',

				'5px' => '5',

				'10px' => '10',

				'15px' => '15',

				'20px' => '20',

				'25px' => '25',

				'30px' => '30',

				'35px' => '35',

			),

		)

	);



	vc_add_param(

		'vc_tta_accordion', array(

			'type' => 'dropdown',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select accordion gap. This is space between abccordion tabs.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Gap', 'dpr-adeline-extensions'),

			'param_name' => 'gap',

			'weight' => '1',

			'edit_field_class' => 'vc_column vc_col-sm-6',

			'value' => array(

				__( 'None', 'dpr-adeline-extensions' ) => '',

				'1px' => '1',

				'2px' => '2',

				'3px' => '3',

				'4px' => '4',

				'5px' => '5',

				'10px' => '10',

				'15px' => '15',

				'20px' => '20',

				'25px' => '25',

				'30px' => '30',

				'35px' => '35',

			),

			'std' => '5'

		)

	);



	vc_add_param(

		'vc_tta_accordion', array(

			'type' => 'dpr_radio',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select accordion navigation icon.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Navigation Icon', 'dpr-adeline-extensions'),

			'param_name' => 'c_icon',

			'weight' => '1',

			'edit_field_class' => 'vc_column vc_col-sm-8',

			'value' => '',

			'options' => array(

				__( 'None', 'dpr-adeline-extensions' ) => '',

				__( 'Chevron', 'dpr-adeline-extensions' ) => 'chevron',

				__( 'Plus', 'dpr-adeline-extensions' ) => 'plus',

				__( 'Triangle', 'dpr-adeline-extensions' ) => 'triangle',

			)

		)

	);

	

	vc_add_param(

		'vc_tta_accordion', array(

			'type' => 'dpr_radio',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select accordion navigation icon position.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Navigation Icon Position', 'dpr-adeline-extensions'),

			'param_name' => 'c_position',

			'weight' => '1',

			'edit_field_class' => 'vc_column vc_col-sm-4',

			'value' => 'left',

			'options' => array(

				__( 'Left', 'dpr-adeline-extensions' ) => 'left',

				__( 'Right', 'dpr-adeline-extensions' ) => 'right',

			),

			'dependency' => array(

				'element' => 'c_icon',

				'not_empty' => true,

			),

		)

	);



	vc_add_param(

		'vc_tta_accordion', array(

			'type' => 'dpr_title',

			'text' => esc_html__('Additional settings', 'dpr-adeline-extensions'),

			'param_name' => 'tta_accordion_title_1',

			'class' => '',

			'weight' => 1

		)

	);





	vc_add_param(

		'vc_tta_accordion', array(

			'type' => 'textfield',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Enter active section number (Note: to have all sections closed on initial load enter non-existing number).', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Active section', 'dpr-adeline-extensions'),

			'param_name' => 'active_section',

			'value' => '',

			'weight' => 0

		)

	);



	vc_add_param(

		'vc_tta_accordion', array(

			'type' => 'textfield',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Enter element ID (Note: make sure it is unique and valid according to w3c specification).).', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Element ID', 'dpr-adeline-extensions'),

			'param_name' => 'el_id',

			'value' => '',

			'weight' => 0

		)

	);



	vc_add_param(

		'vc_tta_accordion', array(

			'type' => 'textfield',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Extra class name', 'dpr-adeline-extensions'),

			'param_name' => 'el_class',

			'value' => '',

			'weight' => 0

		)

	);



/* Tabs Style */



	vc_add_param(

		'vc_tta_accordion', array(

			'type' => 'number',

			'class' => '',

			'weight' => '1',

			'edit_field_class' => 'vc_column vc_col-sm-4',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Set border width for tabs', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border Width', 'dpr-adeline-extensions'),

			'param_name' => 'border_width',

			'value' => '',

			'min'	=> 0,

			'max'	=> 10,

			'step' => 1,

			'suffix' => 'px',

			'group'	=> esc_html__('Tabs Style', 'dpr-adeline-extensions'),

			'dependency' => array(

				'element' => 'style',

				'value' => array('style_1','style_2'),

			),

		)

	);

	

	vc_add_param(

		'vc_tta_accordion', array(

			'type' => 'number',

			'class' => '',

			'edit_field_class' => 'vc_column vc_col-sm-8 no-padding-top',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Set border radius for tabs', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border Radius', 'dpr-adeline-extensions'),

			'param_name' => 'border_radius',

			'value' => '',

			'min'	=> 0,

			'max'	=> 23,

			'step' => 1,

			'suffix' => 'px',

			'group'	=> esc_html__('Tabs Style', 'dpr-adeline-extensions'),

			'dependency' => array(

				'element' => 'style',

				'value' => array('style_1','style_2'),

			),

		)

	);



	vc_add_param(

		'vc_tta_accordion', array(

			'type' => 'colorpicker',

			'class' => '',

			'edit_field_class' => 'vc_column vc_col-sm-4',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Choose the background color for inactive tabs. The background is not set by default', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Tab Background', 'dpr-adeline-extensions'),

			'param_name' => 'tab_background',

			'group'	=> esc_html__('Tabs Style', 'dpr-adeline-extensions'),

			'dependency' => array(

				'element' => 'style',

				'value' => array('style_1'),

			),

		)

	);

	

	vc_add_param(

		'vc_tta_accordion', array(

			'type' => 'colorpicker',

			'class' => '',

			'edit_field_class' => 'vc_column vc_col-sm-4',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Choose the background color for tabs hover state. The background is not set by default', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Tab Background Hover', 'dpr-adeline-extensions'),

			'param_name' => 'tab_background_hover',

			'group'	=> esc_html__('Tabs Style', 'dpr-adeline-extensions'),

			'dependency' => array(

				'element' => 'style',

				'value' => array('style_1'),

			),

		)

	);



	vc_add_param(

		'vc_tta_accordion', array(

			'type' => 'colorpicker',

			'class' => '',

			'edit_field_class' => 'vc_column vc_col-sm-4',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Choose the background color for active tabs. The background is not set by default', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Tab Background Active', 'dpr-adeline-extensions'),

			'param_name' => 'tab_background_active',

			'group'	=> esc_html__('Tabs Style', 'dpr-adeline-extensions'),

			'dependency' => array(

				'element' => 'style',

				'value' => array('style_1'),

			),

		)

	);



	vc_add_param(

		'vc_tta_accordion', array(

			'type' => 'colorpicker',

			'class' => '',

			'edit_field_class' => 'vc_column vc_col-sm-4',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Choose the border color for inactive tabs. The background is not set by default', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Tab Border', 'dpr-adeline-extensions'),

			'param_name' => 'tab_border',

			'group'	=> esc_html__('Tabs Style', 'dpr-adeline-extensions'),

			'dependency' => array(

				'element' => 'style',

				'value' => array('style_1','style_2'),

			),

		)

	);

	

	vc_add_param(

		'vc_tta_accordion', array(

			'type' => 'colorpicker',

			'class' => '',

			'edit_field_class' => 'vc_column vc_col-sm-4',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Choose the border color for tabs hover state. The background is not set by default', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Tab Border Hover', 'dpr-adeline-extensions'),

			'param_name' => 'tab_border_hover',

			'group'	=> esc_html__('Tabs Style', 'dpr-adeline-extensions'),

			'dependency' => array(

				'element' => 'style',

				'value' => array('style_1','style_2'),

			),

		)

	);



	vc_add_param(

		'vc_tta_accordion', array(

			'type' => 'colorpicker',

			'class' => '',

			'edit_field_class' => 'vc_column vc_col-sm-4',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Choose the border color for active tabs. The background is not set by default', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Tab Border Active', 'dpr-adeline-extensions'),

			'param_name' => 'tab_border_active',

			'group'	=> esc_html__('Tabs Style', 'dpr-adeline-extensions'),

			'dependency' => array(

				'element' => 'style',

				'value' => array('style_1','style_2'),

			),

		)

	);



	vc_add_param(

		'vc_tta_accordion', array(

			'type' => 'number',

			'class' => '',

			'edit_field_class' => 'vc_column vc_col-sm-4',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Set underline thicknes for active tab', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Underline Height Active', 'dpr-adeline-extensions'),

			'param_name' => 'underline_thick_active',

			'value' => '2',

			'min'	=> 0,

			'max'	=> 10,

			'step' => 1,

			'suffix' => 'px',

			'group'	=> esc_html__('Tabs Style', 'dpr-adeline-extensions'),

			'dependency' => array(

				'element' => 'style',

				'value' => array('style_3'),

			),

		)

	);

	

	vc_add_param(

		'vc_tta_accordion', array(

			'type' => 'colorpicker',

			'class' => '',

			'edit_field_class' => 'vc_column vc_col-sm-4',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Choose the underline color for active tabs.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Underline Color Active', 'dpr-adeline-extensions'),

			'param_name' => 'underline_color_active',

			'group'	=> esc_html__('Tabs Style', 'dpr-adeline-extensions'),

			'dependency' => array(

				'element' => 'style',

				'value' => array('style_3'),

			),

		)

	);

	

	vc_add_param(

		'vc_tta_accordion', array(

			'type' => 'colorpicker',

			'class' => '',

			'edit_field_class' => 'vc_column vc_col-sm-4',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Choose the background color for active tabs.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Bgackground Active', 'dpr-adeline-extensions'),

			'param_name' => 'underline_bg_color_active',

			'group'	=> esc_html__('Tabs Style', 'dpr-adeline-extensions'),

			'dependency' => array(

				'element' => 'style',

				'value' => array('style_3'),

			),

		)

	);



	vc_add_param(

		'vc_tta_accordion', array(

			'type' => 'number',

			'class' => '',

			'edit_field_class' => 'vc_column vc_col-sm-4',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Set underline thicknes for inactive tab', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Underline Height Inactive', 'dpr-adeline-extensions'),

			'param_name' => 'underline_thick_inactive',

			'value' => '1',

			'min'	=> 0,

			'max'	=> 10,

			'step' => 1,

			'suffix' => 'px',

			'group'	=> esc_html__('Tabs Style', 'dpr-adeline-extensions'),

			'dependency' => array(

				'element' => 'style',

				'value' => array('style_3'),

			),

		)

	);

	

	vc_add_param(

		'vc_tta_accordion', array(

			'type' => 'colorpicker',

			'class' => '',

			'edit_field_class' => 'vc_column vc_col-sm-4',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Choose the underline color for inactive tabs.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Underline Color Inactive', 'dpr-adeline-extensions'),

			'param_name' => 'underline_color_inactive',

			'group'	=> esc_html__('Tabs Style', 'dpr-adeline-extensions'),

			'dependency' => array(

				'element' => 'style',

				'value' => array('style_3'),

			),

		)

	);

	

	vc_add_param(

		'vc_tta_accordion', array(

			'type' => 'colorpicker',

			'class' => '',

			'edit_field_class' => 'vc_column vc_col-sm-4',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Choose the background color for inactive tabs.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background Inactive', 'dpr-adeline-extensions'),

			'param_name' => 'underline_bg_color_inactive',

			'group'	=> esc_html__('Tabs Style', 'dpr-adeline-extensions'),

			'dependency' => array(

				'element' => 'style',

				'value' => array('style_3'),

			),

		)

	);



	vc_add_param(

		'vc_tta_accordion', array(

			'type' => 'number',

			'class' => '',

			'edit_field_class' => 'vc_column vc_col-sm-4',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Set underline thicknes for inactive tab hover', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Underline Height Hover', 'dpr-adeline-extensions'),

			'param_name' => 'underline_thick_hover',

			'value' => '1',

			'min'	=> 0,

			'max'	=> 10,

			'step' => 1,

			'suffix' => 'px',

			'group'	=> esc_html__('Tabs Style', 'dpr-adeline-extensions'),

			'dependency' => array(

				'element' => 'style',

				'value' => array('style_3'),

			),

		)

	);

	

	vc_add_param(

		'vc_tta_accordion', array(

			'type' => 'colorpicker',

			'class' => '',

			'edit_field_class' => 'vc_column vc_col-sm-4',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Choose the underline color for inactive tabs hover.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Underline Color Hover', 'dpr-adeline-extensions'),

			'param_name' => 'underline_color_hover',

			'group'	=> esc_html__('Tabs Style', 'dpr-adeline-extensions'),

			'dependency' => array(

				'element' => 'style',

				'value' => array('style_3'),

			),

		)

	);

	

	vc_add_param(

		'vc_tta_accordion', array(

			'type' => 'colorpicker',

			'class' => '',

			'edit_field_class' => 'vc_column vc_col-sm-4',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Choose the background color for inactive tabs hover.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background Hover', 'dpr-adeline-extensions'),

			'param_name' => 'underline_bg_color_hover',

			'group'	=> esc_html__('Tabs Style', 'dpr-adeline-extensions'),

			'dependency' => array(

				'element' => 'style',

				'value' => array('style_3'),

			),

		)

	);

	

	vc_add_param(

		'vc_tta_accordion', array(

			'type' => 'dpr_switcher',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Add shadow to active tab.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Add shadow to tabs?', 'dpr-adeline-extensions'),

			'param_name' => 'add_shadows',

			'edit_field_class' => 'vc_column vc_col-sm-6',

			'group'	=> esc_html__('Tabs Style', 'dpr-adeline-extensions'),

			'value' => '',

			'options' => array(

				'yes' => array(

						'label' => '',

						'on' => 'Yes',

						'off' => 'No',

					),

				),

		)

	);



	vc_add_param(

		'vc_tta_accordion',array(

			"type" => "dpr_shadow_picker",

			"class" => "",

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set shadow for active tab.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Tab Shadow Active', 'dpr-adeline-extensions'),

			'group' => esc_html__('Tabs Style', 'dpr-adeline-extensions'),

			"param_name" => "tab_shadow_active",

			"value" => "none||||||",

			'dependency' => array(

				'element' => 'add_shadows',

				'not_empty' => true,

			),



		)

	);



	vc_add_param(

		'vc_tta_accordion',array(

			"type" => "dpr_shadow_picker",

			"class" => "",

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set shadow for active tab.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Tab Shadow Inactive', 'dpr-adeline-extensions'),

			'group' => esc_html__('Tabs Style', 'dpr-adeline-extensions'),

			"param_name" => "tab_shadow_inactive",

			"value" => "none||||||",

			'dependency' => array(

				'element' => 'add_shadows',

				'not_empty' => true,

			),



		)

	);



	vc_add_param(

		'vc_tta_accordion',array(

			"type" => "dpr_shadow_picker",

			"class" => "",

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set shadow for active tab.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Tab Shadow Hover', 'dpr-adeline-extensions'),

			'group' => esc_html__('Tabs Style', 'dpr-adeline-extensions'),

			"param_name" => "tab_shadow_hover",

			"value" => "none||||||",

			'dependency' => array(

				'element' => 'add_shadows',

				'not_empty' => true,

			),



		)

	);



/* Title group */

	vc_add_param(

		'vc_tta_accordion', array(

			'type' => 'number',

			'class' => '',

			'weight' => '1',

			'edit_field_class' => 'vc_column vc_col-sm-4',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Set tab title font size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Title Font Size', 'dpr-adeline-extensions'),

			'param_name' => 'title_font_size',

			'value' => '14',

			'min'	=> 1,

			'max'	=> 100,

			'step' => 1,

			'suffix' => 'px',

			'group'	=> esc_html__('Title Style', 'dpr-adeline-extensions'),

		)

	);



	vc_add_param(

		'vc_tta_accordion', array(

			'type' => 'dpr_radio',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select tab title alignment.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Title Alignment', 'dpr-adeline-extensions'),

			'param_name' => 'alignment',

			'edit_field_class' => 'vc_column vc_col-sm-8 no-padding-top',

			'value' => 'left',

			'options' => array(

				__( 'Left', 'dpr-adeline-extensions' ) => 'left',

				__( 'Center', 'dpr-adeline-extensions' ) => 'center',

				__( 'Right', 'dpr-adeline-extensions' ) => 'rights'

			),

			'group'	=> esc_html__('Title Style', 'dpr-adeline-extensions'),

		)

	);

	

	vc_add_param(

		'vc_tta_accordion', array(

			'type' => 'colorpicker',

			'class' => '',

			'edit_field_class' => 'vc_column vc_col-sm-4',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Choose title color for inactive tabs.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Title Color', 'dpr-adeline-extensions'),

			'param_name' => 'title_color',

			'group'	=> esc_html__('Title Style', 'dpr-adeline-extensions')

		)

	);



	vc_add_param(

		'vc_tta_accordion', array(

			'type' => 'colorpicker',

			'class' => '',

			'edit_field_class' => 'vc_column vc_col-sm-4',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Choose title color for active tab.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Title Color Active', 'dpr-adeline-extensions'),

			'param_name' => 'title_color_active',

			'group'	=> esc_html__('Title Style', 'dpr-adeline-extensions')

		)

	);



	vc_add_param(

		'vc_tta_accordion', array(

			'type' => 'colorpicker',

			'class' => '',

			'edit_field_class' => 'vc_column vc_col-sm-4',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Choose title color on hover.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Title Color Hover', 'dpr-adeline-extensions'),

			'param_name' => 'title_color_hover',

			'group'	=> esc_html__('Title Style', 'dpr-adeline-extensions')

		)

	);



/* Icon Group */



	vc_add_param(

		'vc_tta_accordion', array(

			'type' => 'number',

			'class' => '',

			'weight' => '1',

			'edit_field_class' => 'vc_column vc_col-sm-12',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Set tab icon font size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon Font Size', 'dpr-adeline-extensions'),

			'param_name' => 'icon_font_size',

			'value' => '14',

			'min'	=> 1,

			'max'	=> 100,

			'step' => 1,

			'suffix' => 'px',

			'group'	=> esc_html__('Icon Style', 'dpr-adeline-extensions'),

		)

	);





	vc_add_param(

		'vc_tta_accordion', array(

			'type' => 'colorpicker',

			'class' => '',

			'edit_field_class' => 'vc_column vc_col-sm-4',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Choose icon color for inactive tabs.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon Color', 'dpr-adeline-extensions'),

			'param_name' => 'icon_color',

			'group'	=> esc_html__('Icon Style', 'dpr-adeline-extensions')

		)

	);



	vc_add_param(

		'vc_tta_accordion', array(

			'type' => 'colorpicker',

			'class' => '',

			'edit_field_class' => 'vc_column vc_col-sm-4',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Choose icon color for active tab.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon Color Active', 'dpr-adeline-extensions'),

			'param_name' => 'icon_color_active',

			'group'	=> esc_html__('Icon Style', 'dpr-adeline-extensions')

		)

	);



	vc_add_param(

		'vc_tta_accordion', array(

			'type' => 'colorpicker',

			'class' => '',

			'edit_field_class' => 'vc_column vc_col-sm-4',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Choose icon color on hover.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon Color Hover', 'dpr-adeline-extensions'),

			'param_name' => 'icon_color_hover',

			'group'	=> esc_html__('Icon Style', 'dpr-adeline-extensions')

		)

	);



