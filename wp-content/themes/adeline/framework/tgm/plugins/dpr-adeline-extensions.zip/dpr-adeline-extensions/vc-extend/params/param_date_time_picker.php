<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if(!class_exists('DPR_Date_Time_Picker_Param')) {

	class DPR_Date_Time_Picker_Param {
		
		function __construct() {
			add_action('admin_enqueue_scripts', array($this, 'load_assets'));
			if(function_exists('vc_add_shortcode_param')) {
				vc_add_shortcode_param('dpr_datetimepicker' , array(&$this,'datetimepicker'),DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/admin/js/bootstrap-datetimepicker.min.js' );
			}
		}
		
		function datetimepicker($settings, $value) {
		$param_name = isset($settings['param_name']) ? $settings['param_name'] : '';
		$type = isset($settings['type']) ? $settings['type'] : '';
		$class = isset($settings['class']) ? $settings['class'] : '';
		$output = '<div id="dpr-date-time" class="dpr-datetime"><input data-format="yyyy/MM/dd hh:mm:ss" readonly class="wpb_vc_param_value ' . $param_name . ' ' . $type . ' ' . $class . '" name="' . $param_name . '" style="width:80%;" value="'.$value.'"/><div class="add-on" >  <i class="el el-calendar" data-date-icon="el el-calendar"></i></div></div>';
		return $output;
	}
		function load_assets() {
			wp_enqueue_style('dpr_date_time_picket_styles', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/admin/css/bootstrap-datetimepicker.min.css');
		}
	}
}

if(class_exists('DPR_Date_Time_Picker_Param')) {
	$DPR_Date_Time_Picker_Param = new DPR_Date_Time_Picker_Param();
}
