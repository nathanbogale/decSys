<?php



/**



 * Woocoommerce Options -> General Style



 * 



 */







	Redux::setSection( $opt_name, array(



		'title' => esc_html__('General Settings', 'dpr-adeline-extensions'),



		'id' => 'woocommerce_general',



		'subsection' => true,



		'fields' => array(



						array(



							'id'       => 'woo_cat_widget_style',



							'type'     => 'radio',



							'title'    => __('Categories Widget Style', 'dpr-adeline-extensions'),



							'options'  => array(



								'default' => 'Default', 



								'dropdown'  => 'Dropdown'



							),



							'default' => 'default',



							'hint' => array(



								'title'   => esc_attr__('Categories Widget Style','dpr-adeline-extensions'),



								'content' => esc_attr__('Choose the WooCommerce Categories widget style. ','dpr-adeline-extensions')



							),



						),



						array(



							'id'   => 'woo_onsale_info',



							'type' => 'info',



							'style' => 'dpr-title',



							'title' => wp_kses_post(__('<h3>OnSale Badge</h3>', 'dpr-adeline-extensions')),



						),



						array(



							'id'       => 'woo_onsale_style',



							'type'     => 'radio',



							'title'    => __('On Sale Badge Style', 'dpr-adeline-extensions'),



							'options'  => array(



								'square' => 'Square', 



								'circle'  => 'Circle'



							),



							'default' => 'square',



							'hint' => array(



								'title'   => esc_attr__('On Sale Badge Style','dpr-adeline-extensions'),



								'content' => esc_attr__('Set shape for On Sale badge. ','dpr-adeline-extensions')



							),



						),



						array(



							'id'       => 'woo_onsale_content',



							'type'     => 'radio',



							'title'    => __('On Sale Badge Content', 'dpr-adeline-extensions'),



							'options'  => array(



								'sale' => 'On Sale String', 



								'percent'  => 'Percent'



							),



							'default' => 'sale',



							'hint' => array(



								'title'   => esc_attr__('On Sale Badge Content','dpr-adeline-extensions'),



								'content' => esc_attr__('Set content for On Sale badge string or percent. ','dpr-adeline-extensions')



							),



						),



						array(



							'id'   => 'woocommerce_wishlist_info',



							'type' => 'info',



							'style' => 'dpr-title',



							'title' => wp_kses_post(__('<h3>Wishlist</h3>', 'dpr-adeline-extensions')),



						),



						array(



							'id'       => 'woo_main_menu_wishlist_button',



							'type'     => 'switch',



							'default' => false,



							'title'    =>  esc_html__('Display Wishlist Icon','dpr-adeline-extensions'),



							'hint' => array(



								'title'   => esc_attr__('Display Wishlist Icon','dpr-adeline-extensions'),



								'content' =>  esc_attr__('You need to activate the TI WooCommerce Wishlist plugin to add a wishlist button and icon.','dpr-adeline-extensions')



							)



						),



					)



	));



