<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if(!class_exists('DPR_Description_Param')) {
	class DPR_Description_Param {
		function __construct() {
			if(function_exists('vc_add_shortcode_param')) {
				vc_add_shortcode_param('dpr_description' , array($this, 'dpr_description'));
			}
		}
	
		function dpr_description($settings, $value) {
			$param_name = isset($settings['param_name']) ? $settings['param_name'] : '';
			$class = isset($settings['class']) ? $settings['class'] : '';
			$text = isset($settings['text']) ? $settings['text'] : '';
			$type = "";
			$output = '<p class="dpr-description-param '.esc_attr($class).'">'.wp_kses_post($text).'</p>';

			$output .= '<input type="hidden"  class="wpb_vc_param_value ' . esc_attr($param_name . ' ' . $type . ' ' . $class) . '" name="' . esc_attr($param_name) . '" value="'.$value.'" />';
			return $output;
		}
		
	}
	
	$DPR_Description_Param = new DPR_Description_Param();
}
