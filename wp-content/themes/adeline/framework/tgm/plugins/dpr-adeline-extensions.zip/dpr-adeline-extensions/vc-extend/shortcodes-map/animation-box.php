<?php

// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}



/*

  Shortcode: Carousel

 */



class WPBakeryShortCode_DPR_Animation_Box extends WPBakeryShortCodesContainer {

	

}



new dpr_hide_frontend("dpr_animation_box");



vc_map(

	array(

		'name' => esc_html__('DP Animation Box', 'dpr-adeline-extensions'),

		'base' => 'dpr_animation_box',

		'icon' => 'icon-dpr-animation-box',

		'class' => 'dpr_animation_box',

		'as_parent' => array('except' =>'dpr_animation_box'),

		'content_element' => true,

		'controls' => 'full',

		'show_settings_on_create' => true,

  		"category" =>array( esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions')),

		'description' => esc_html__('Animated on-scroll or on-hover container for other elements'),

		'params' => array_merge(array(

					array(

						'type'             => 'dpr_title',

						'text'             => esc_html__( 'Magic Scroll', 'dpr-adeline-extensions' ),

						'param_name'       => 'magic_scroll_title',

						'edit_field_class' => 'vc_column vc_col-sm-12',

					),

					array(

						'type'				=> 'dpr_switcher',

						'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable magic scroll effects for this container', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Enable Magic Scroll', 'dpr-adeline-extensions'),

						'param_name'		=> 'enable_magic_scroll',

						'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

						'options'			=> array(

							'yes'				=> array(

								'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

								'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

							),

						)

					),

					array(

						'type'				=> 'dpr_radio',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose scroll animation type.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Scroll Animation Type', 'dpr-adeline-extensions'),

						'param_name'		=> 'magic_animation_type',

						'value'				=> 'position',

						'std'				=> 'position',

						'options'			=> array(

							esc_html__("Position", 'dpr-adeline-extensions') => "position",

							esc_html__("Scale", 'dpr-adeline-extensions') => "scale",

							esc_html__("Position & Scale", 'dpr-adeline-extensions') => "both"

						),

						'dependency' => array('element' => 'enable_magic_scroll', 'value' => array('yes'))

					),

					array(

						'type'				=> 'number',

						'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enter Value of Horizontal Distance. You can use positive and negative value here. e.g. 10, -10 etc.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('(X) / Horizontal Scroll Distance', 'dpr-adeline-extensions'),

						'param_name'		=> 'distance_scroll_x',

						'min'				=> 1,

						'value' 			=> '0',

						'suffix'				=> 'px',

						'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

						'dependency' => array('element' => 'magic_animation_type', 'value' => array('position','both'))

					),

					array(

						'type'				=> 'number',

						'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enter Value of Vertical Distance. You can use positive and negative value here. e.g. 10, -10 etc.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('(Y) / Vertical Scroll Distance', 'dpr-adeline-extensions'),

						'param_name'		=> 'distance_scroll_y',

						'min'				=> 1,

						'value' 			=> '50',

						'suffix'				=> 'px',

						'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

						'dependency' => array('element' => 'magic_animation_type', 'value' => array('position','both'))

					),

					array(

						'type'				=> 'number',

						'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enter value of scale of box in %. e.g. 2 = 200%, 1.5 = 150%.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Scale Value', 'dpr-adeline-extensions'),

						'param_name'		=> 'scale_scroll',

						'min'				=> 1,

						'value' 			=> '0',

						'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

						'dependency' => array('element' => 'magic_animation_type', 'value' => array('scale','both'))

					),

					array(

						'type'             => 'dpr_title',

						'text'             => esc_html__( 'Parallax On Hover', 'dpr-adeline-extensions' ),

						'param_name'       => 'paralax_hover_title',

						'edit_field_class' => 'vc_column vc_col-sm-12',

					),

					array(

						'type'				=> 'dpr_switcher',

						'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable parallax on hover effects for this container', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Enable Parallax On Hover', 'dpr-adeline-extensions'),

						'param_name'		=> 'enable_parallax_on_hover',

						'options'			=> array(

							'yes'				=> array(

								'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

								'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

							),

						)

					),

					array(

						'type'				=> 'number',

						'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enter Value of Horizontal Speed move parallax. You can use positive and negative value here. e.g. 10, -10 etc.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Horizontal Move Parallax (X)', 'dpr-adeline-extensions'),

						'param_name'		=> 'move_speed_x',

						'min'				=> 1,

						'value' 			=> '20',

						'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

						'dependency' => array('element' => 'enable_parallax_on_hover', 'value' => array('yes'))

					),

					array(

						'type'				=> 'number',

						'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enter Value of Vertical Speed move parallax. You can use positive and negative value here. e.g. 10, -10 etc.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Vertical Move Parallax (Y)', 'dpr-adeline-extensions'),

						'param_name'		=> 'move_speed_y',

						'min'				=> 1,

						'value' 			=> '20',

						'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

						'dependency' => array('element' => 'enable_parallax_on_hover', 'value' => array('yes'))

					),

					array(

						'type'             => 'dpr_title',

						'text'             => esc_html__( 'Block Reveal Effect', 'dpr-adeline-extensions' ),

						'param_name'       => 'reveal_effect_title',

						'edit_field_class' => 'vc_column vc_col-sm-12',

					),

					array(

						'type'				=> 'dpr_switcher',

						'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable block reveal effect for this container', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Enable Block Reveal Effect', 'dpr-adeline-extensions'),

						'param_name'		=> 'enable_block_reveal',

						'options'			=> array(

							'yes'				=> array(

								'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

								'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

							),

						)

					),

					array(

						'type'				=> 'dpr_radio',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose block reveal animation type.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Block Reveal Animation Type', 'dpr-adeline-extensions'),

						'param_name'		=> 'reveal_animation_type',

						'value'				=> 'onscroll',

						'options'			=> array(

							esc_html__("On Scroll", 'dpr-adeline-extensions') => "onscroll",

							esc_html__("On Load", 'dpr-adeline-extensions') => "onload"

						),

						'dependency' => array('element' => 'enable_block_reveal', 'value' => array('yes'))

					),

					array(

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose animation direction.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Animation Direction', 'dpr-adeline-extensions'),

						'type'				=> 'dpr_image_select',

						'param_name'		=> 'reveal_animation_direction',

						'value' 			=> 'from-left',

						'edit_field_class' => 'vc_column vc_col-sm-12',

						'options'			=> array(

							'lr'			=> array(

								'label'			=> esc_html__('Left to right', 'dpr-adeline-extensions'),

								'src'				=> $module_images.'animated-box/reveal-1.jpg'

							),

							'rl'			=> array(

								'label'			=> esc_html__('Right to left', 'dpr-adeline-extensions'),

								'src'				=> $module_images.'animated-box/reveal-2.jpg'

							),

							'tb'			=> array(

								'label'			=> esc_html__('Top to Bottom', 'dpr-adeline-extensions'),

								'src'				=> $module_images.'animated-box/reveal-3.jpg'

							),

							'bt'			=> array(

								'label'			=> esc_html__('Bottom to Top', 'dpr-adeline-extensions'),

								'src'				=> $module_images.'animated-box/reveal-4.jpg'

							),

						),

						'dependency' => array('element' => 'enable_block_reveal', 'value' => array('yes'))

					),

					array(

						'type'				=> 'number',

						'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enter animation delay value in ms', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Animation Delay', 'dpr-adeline-extensions'),

						'param_name'		=> 'reveal_animation_delay',

						'min'				=> 1,

						'value' 			=> '500',

						'suffix'				=> 'ms',

						'dependency' => array('element' => 'enable_block_reveal', 'value' => array('yes'))

					),

					array(

						'type'				=> 'dpr_radio',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose block reveal overlay color type.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Overlay Color Type', 'dpr-adeline-extensions'),

						'param_name'		=> 'reveal_overlay_type',

						'value'				=> 'solid',

						'options'			=> array(

							esc_html__("Solid Color", 'dpr-adeline-extensions') => "solid",

							esc_html__("Gradient", 'dpr-adeline-extensions') => "gradient"

						),

						'dependency' => array('element' => 'enable_block_reveal', 'value' => array('yes'))

					),

					array(

						'type' => 'colorpicker',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose color for the overlay.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Overlay Color', 'dpr-adeline-extensions'),

						'edit_field_class' => 'vc_col-xs-6',

						'param_name' => 'reveal_overlay_color',

						"value" => '#D3AE5F',

						'admin_label' => false,

						'dependency' => array('element' => 'reveal_overlay_type', 'value' => array('solid'))

					),

					array(

						'type' => 'dpr_gradient_picker',

						'class' => '',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose gradient for the overlay.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Overlay gradient', 'dpr-adeline-extensions'),

						'param_name' => 'reveal_overlay_gradient',

						'value' => '45;0%/rgb(34, 8, 113);100%/rgb(14, 237, 171)',

						'dependency' => array('element' => 'reveal_overlay_type', 'value' => array('gradient'))

					),

					array(

						'type'             => 'dpr_title',

						'text'             => esc_html__( 'Animations Settings', 'dpr-adeline-extensions' ),

						'param_name'       => 'animations_title',

						'edit_field_class' => 'vc_column vc_col-sm-12',

					),

					vc_map_add_css_animation( false ),

					array(

						'type'				=> 'dpr_switcher',

						'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('You can enable option of on hover tilt effect for this container.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Enable 3D Tilt on Hover', 'dpr-adeline-extensions'),

						'param_name'		=> 'enable_hover_3d',

						'value' 			=> 'no',

						'options'			=> array(

							'yes'				=> array(

								'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

								'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

							),

						)

					),

					array(

						'type' => 'dropdown',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose content hover effect.This Effects will be applied when you hover on this section.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Content Hover Effect', 'dpr-adeline-extensions'),

						'param_name' => 'box_hover_effect',

						'edit_field_class' => 'vc_column vc_col-sm-6',

						'value' => array(

								__('None', 'dpr-adeline-extensions') => '',

								__('Grow', 'dpr-adeline-extensions') => 'grow',

								__('Push', 'dpr-adeline-extensions') => 'push',

								__('Bounce In', 'dpr-adeline-extensions') => 'bounce-in',

								__('Float', 'dpr-adeline-extensions') => 'float',

								__('Wobble horizontal', 'dpr-adeline-extensions') => 'wobble_horizontal',

								__('Wobble Vertical', 'dpr-adeline-extensions') => 'wobble_vertical',

							   ),

						'std' => '',

					),

					array(

						'type' => 'dropdown',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('This Effect will be applied on section as a continuous effect in normal and hover state.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Continuous Effect', 'dpr-adeline-extensions'),

						'param_name' => 'continuous_effect',

						'edit_field_class' => 'vc_column vc_col-sm-6',

						'value' => array(

									__('None', 'dpr-adeline-extensions') => '',

									__('Pulse', 'dpr-adeline-extensions') => 'pulse',

									__('Floating', 'dpr-adeline-extensions') => 'floating',

									__('Tossing', 'dpr-adeline-extensions') => 'tossing'

							   ),

						'std' => '',

					),

					/*EXTRA FEATURES */

					array(

						'type'             => 'dpr_title',

						'text'             => esc_html__( 'Additional Settings', 'dpr-adeline-extensions' ),

						'param_name'       => 'extra_features_title',

						'edit_field_class' => 'vc_column vc_col-sm-12',

					),

					array(

						'type' => 'textfield',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Extra Class Name', 'dpr-adeline-extensions'),

						'param_name' => 'el_class',

					),

					array(

						'type' => 'css_editor',

						'heading' => __( 'CSS box', 'dpr-adeline-extensions' ),

						'param_name' => 'css',

						'group' => __( 'Design Options', 'dpr-adeline-extensions' ),

					),

					array(

						'type' => 'dpr_title',

						'text' => esc_html__('Default State', 'dpr-adeline-extensions'),

						'param_name' => 'default_design_setting_title',

						'group' => esc_html__('Design Options', 'dpr-adeline-extensions'),

					),

					array(

						"type" => "dpr_shadow_picker",

						"class" => "",

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set shadow for this container.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Box Shadow', 'dpr-adeline-extensions'),

						'group' => esc_html__('Design Options', 'dpr-adeline-extensions'),

						"param_name" => "container_shadow",

						"value" => "none||||||"

					),					

					array(

						'type' => 'dpr_title',

						'text' => esc_html__('Hover State', 'dpr-adeline-extensions'),

						'param_name' => 'hover_design_setting_title',

						'group' => esc_html__('Design Options', 'dpr-adeline-extensions'),

					),

					array(

						'type' => 'colorpicker',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the color for container hover background.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background Color Hover', 'dpr-adeline-extensions'),

						'param_name' => 'container_bg_color_hover',

						'edit_field_class' => 'vc_column vc_col-sm-6',

						'value' => '',

						'group' => esc_html__('Design Options', 'dpr-adeline-extensions'),

					),					

					array(

						'type' => 'colorpicker',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the color for container hover border.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border Color Hover', 'dpr-adeline-extensions'),

						'param_name' => 'container_border_color_hover',

						'edit_field_class' => 'vc_column vc_col-sm-6',

						'value' => '',

						'group' => esc_html__('Design Options', 'dpr-adeline-extensions'),

					),					

					array(

						'type' => 'dropdown',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose border style in hover state.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border Style Hover', 'dpr-adeline-extensions'),

						'param_name' => 'container_border_style_hover',

						'group' => esc_html__('Design Options', 'dpr-adeline-extensions'),

						'edit_field_class' => 'vc_column vc_col-sm-6',

						'value' => array(

								__('Inherit', 'dpr-adeline-extensions') => '',

								__('None', 'dpr-adeline-extensions') => 'none',

								__('Solid', 'dpr-adeline-extensions') => 'solid',

								__('Doted', 'dpr-adeline-extensions') => 'dotted',

								__('Dashed', 'dpr-adeline-extensions') => 'dashed',

								__('Hidden', 'dpr-adeline-extensions') => 'double',

								__('Groove', 'dpr-adeline-extensions') => 'groove',

								__('Ridge', 'dpr-adeline-extensions') => 'ridge',

								__('Inset', 'dpr-adeline-extensions') => 'inset',

								__('Outset', 'dpr-adeline-extensions') => 'outset',

							   ),

						'std' => '',

					),

					array(

						'type' => 'number',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose border radius in hover state for this container.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border radius hover', 'dpr-adeline-extensions'),

						'param_name' => 'container_border_radius_hover',

						'value' =>'',

						'min'=>'0',

						'step' => '1',

						'group' => esc_html__('Design Options', 'dpr-adeline-extensions'),

						'edit_field_class' => 'vc_column vc_col-sm-6',

					),					

					array(

						"type" => "dpr_shadow_picker",

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set hover shadow for this container.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Box Shadow Hover', 'dpr-adeline-extensions'),

						'group' => esc_html__('Design Options', 'dpr-adeline-extensions'),

						"param_name" => "container_shadow_hover",

						"value" => "none||||||"

					)										

							

			)),

		'js_view' => 'VcColumnView'

	)

);

