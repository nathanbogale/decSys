<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$unique_id = $el_class = $custom_el_css =  $type = $css = "";
$title = $title_color = $title_font_size = $title_line_height = $title_letter_spacing = $title_font_style = $title_use_google_fonts = $title_google_font = '';
$subtitle = $subtitle_color = $subtitle_font_size = $subtitle_line_height = $subtitle_letter_spacing = $subtitle_font_style = $subtitle_use_google_fonts = $subtitle_google_font = '';
$image_id = $image_block_type = $image_block_height = $parallax_factor = $parallax_type = $image_block_anim = $content_block_anim = $content_typo_style = $content_color = $content_font_size = $content_line_height = $content_letter_spacing = $content_font_style = $content_google_font= 
$read_more = $link = $content_html = $image_html = $output = $img_anim_class = $content_anim_class ='';

$atts = vc_map_get_attributes( 'dpr_split_section', $atts );
extract( $atts );

$unique_id = uniqid('dpr-split-section-').'-'.rand(1,9999);

/* Element classes */

if ( '' !== $image_block_anim && 'none' !== $image_block_anim ) {
	dpr_enqueue_waypoint_js();
	dpr_enqueue_animate_css();
	$img_anim_class .= ' wpb_animate_when_almost_visible wpb_' . $image_block_anim . ' ' . $image_block_anim;
}
if ( '' !== $content_block_anim && 'none' !== $content_block_anim ) {
	dpr_enqueue_waypoint_js();
	dpr_enqueue_animate_css();
	$content_anim_class .= ' wpb_animate_when_almost_visible wpb_' . $content_block_anim . ' ' . $content_block_anim;
}

if(isset($type) & $type !='') {
	$el_class .= ' '.$type;
}

$css_classes = array(
	'dpr-split-section',
	$unique_id,
	$el_class,
	vc_shortcode_custom_css_class( $css ),
);

$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->settings['base'], $atts ) );

/* * ************************
 * Styles and custom CSS
 * *********************** */

/* * ************************
 * Partial HTML.
 * *********************** */
$title_wrap_html = $subtitle_html = $title_html = $read_more_html = '';
if(!empty($subtitle)) {
	$title_typo_style = dpr_generate_typography_style($title_color, $title_font_size, $title_line_height, $title_letter_spacing, $title_font_style,$title_google_font);
	$title_html .= '<h3 class="dpr-headline" '.$title_typo_style.' >'.esc_html($title).'</h3>';
}
if(!empty($subtitle)) {
	$subtitle_typo_style = dpr_generate_typography_style($subtitle_color, $subtitle_font_size, $subtitle_line_height, $subtitle_letter_spacing, $subtitle_font_style, $subtitle_google_font);
	$subtitle_html .= '<div class="dpr-heading-subtitle" '.$subtitle_typo_style.' >'.esc_html($subtitle).'</div>';
}
if(isset($title) &&!empty($title) || isset($subtitle) && !empty($subtitle)) {
	$title_wrap_html .= '<div class="dpr-heading-wrapper"><div class="dpr-heading-inner-wrapper"><div class="dpr-heading">';
		$title_wrap_html .= $title_html;
		$title_wrap_html .= $subtitle_html;
	$title_wrap_html .= '</div></div></div>';
}

$read_more_data = dpr_generate_read_more($atts);
$read_more_html .= $read_more_data[0];
$custom_el_css .= $read_more_data[1];

$content_html .= '<div class="item-content'.$content_anim_class.'">';
	$content_html .= $title_wrap_html;
	$content_typo_style = dpr_generate_typography_style($content_color, $content_font_size, $content_line_height, $content_letter_spacing, $content_font_style,$content_google_font);
	$content_html .= '<div class="description" '.$content_typo_style.'>'.$content.'</div>';
	$content_html .= $read_more_html;
$content_html .= '</div>';


$image_html .= '<div class="item-image'.$img_anim_class.'">';
	if(isset($image_id) && $image_id != '') {
	$image_url = dpr_get_attachment_image_src( $image_id, 'full' );
	$alt_text = get_post_meta($image_id , '_wp_attachment_image_alt', true);
	$image_src = $image_url[0];
		if($image_block_type == 'simple') {
			$image_html .= '<img src="' . esc_url($image_src) . '" alt ="'.esc_attr($alt_text).'"/>';
		}
		if($image_block_type == 'parallax') {
			wp_enqueue_script( 'dpr_parralax_js', DPR_EXTENSIONS_PLUGIN_URL . 'vc-extend/assets/frontend/js/dpr.parallax.js', false, true);
			$parallax_wrap_data_atts = '';
			$custom_el_css .= '.'.$unique_id.' .item-image .parallax-wrapper {background-image: url('.esc_url($image_src ).')}';
			$custom_el_css .= '.'.$unique_id.' .item-image .parallax-wrapper {height: '.esc_attr($image_block_height).'px;}';
			if(isset($parallax_type) && !empty($parallax_type)) {
					$parallax_wrap_data_atts .= 'data-paroller-direction="'.$parallax_type.'"';
			}
			if(isset($parallax_factor) && !empty($parallax_factor)) {
					$parallax_wrap_data_atts .= ' data-paroller-factor="'.$parallax_factor.'"';
			}
			$image_html .= '<div class="parallax-wrapper" '.$parallax_wrap_data_atts.'></div>';
		}
	}
	
$image_html .= '</div>';



/* * ************************
 * Output
 * *********************** */
$output .= '<div id="'.esc_attr($unique_id).'" class="'.esc_attr($css_class).' clr">';
	$output .= '<div class="inner">';
	switch($type) {
		case 'right';
		$output .= $content_html;
		$output .= $image_html;
		break;
		case 'left';
		$output .= $image_html;
		$output .= $content_html;
		break;
	}
	$output .= "</div>";
if(!empty($custom_el_css)) {
		$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>");'
						. '})(jQuery);'
					. '</script>';
}
$output .= "</div>";
echo $output;

