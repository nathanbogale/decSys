<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if(!class_exists('DPR_Radio_Param')) {
	class DPR_Radio_Param {
		function __construct() {
			if(function_exists('vc_add_shortcode_param')) {
				vc_add_shortcode_param('dpr_radio' , array(&$this, 'dpr_radio' ), DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/admin/js/dpr_param.js');
			}
		}
	
		function dpr_radio($settings, $value){
			$output = '';
			$uniquid = uniqid('dpr-radio');
			
			$param_name = isset($settings['param_name']) ? $settings['param_name'] : '';
			$type = isset($settings['type']) ? $settings['type'] : '';
			$class = isset($settings['class']) ? $settings['class'] : '';
			$style = isset($settings['css_style']) ? 'style="'.esc_attr($settings['css_style']).'"' : '';
			
			$options = isset($settings['options']) ? $settings['options'] : '';
			$result = empty($value) ? $settings['value'] : $value;
			
			if(!empty($options) && is_array($options)) {
				$output .= '<div id="'.esc_attr($uniquid).'" class="dpr-radio-container '.$class.'">';
					$output .= '<ul class="options-list">';
						foreach($options as $name => $val) {
							$checked = ($val == $result) ? 'checked="checked"' : '';
							$output .= '<li '. ($checked != '' ? 'class="active"' : '') .'>'
										. '<label '.$style.'>'
											. '<input type="radio" '. $checked .' value="'.$val.'" />'
											. strip_tags($name,'<i><span>')
										. '</label>'
									. '</li>';
						}
					$output .= '</ul>';
					$output .= '<input type="hidden" name="' . esc_attr($param_name) . '" class="wpb_vc_param_value ' . esc_attr($param_name . ' ' . $type . ' ' . $class) . '" value="'.$result.'" />';
				$output .= '</div>';
			}
			
			return $output;
		}
		
	}
	
	$DPR_Radio_Param = new DPR_Radio_Param();
}
