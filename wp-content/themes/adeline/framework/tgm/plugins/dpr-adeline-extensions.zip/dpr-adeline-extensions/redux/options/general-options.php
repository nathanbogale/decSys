<?php

/**



 * General Theme Options



 *



 */

Redux::setSection($opt_name, array(

    'title' => __('General', 'dpr-adeline-extensions'),

    'id'    => 'basic_tab',

    'desc'  => __('Basic theme settings are configured here.', 'dpr-adeline-extensions'),

    'icon'  => 'el el-cogs',

));

require_once $options_dir . '/general-options/general-settings.php';

require_once $options_dir . '/general-options/general-styling.php';

require_once $options_dir . '/general-options/scroll-to-top.php';

require_once $options_dir . '/general-options/pagination.php';

require_once $options_dir . '/general-options/forms.php';

require_once $options_dir . '/general-options/buttons.php';

require_once $options_dir . '/general-options/social.php';

require_once $options_dir . '/general-options/sharing.php';

require_once $options_dir . '/general-options/404-page.php';

require_once $options_dir . '/general-options/login-page.php';

require_once $options_dir . '/general-options/page-preloader.php';

require_once $options_dir . '/general-options/magic-cursor.php';

require_once $options_dir . '/general-options/right-click-blocker.php';

require_once $options_dir . '/general-options/advanced-options.php';

require_once $options_dir . '/general-options/api-integrations.php';
