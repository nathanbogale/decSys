<?php

/**

 * General Options -> Social Links

 * 

 */



	Redux::setSection( $opt_name, array(



		'title' => esc_html__('Social Links', 'dpr-adeline-extensions'),



		'id' => 'general_social_links',

		'subsection' => true,

		'fields' => array(

						array(

							'id' => 'social_link_facebook',

							'type' => 'text',



							'title' => esc_html__('Facebook', 'dpr-adeline-extensions'),



							'hint' => array(



							'title'   => esc_attr__('Facebook link','dpr-adeline-extensions'),



							'content' => esc_attr__('If you leave this link blank facebook icon will be not displayed','dpr-adeline-extensions'),



							)



						),



						array(



							'id' => 'social_link_twitter',



							'type' => 'text',



							'title' => esc_html__('Twitter', 'dpr-adeline-extensions'),



							'hint' => array(



							'title'   => esc_attr__('Twitter link','dpr-adeline-extensions'),



							'content' => esc_attr__('If you leave this link blank twitter icon will be not displayed','dpr-adeline-extensions'),



							)



						),



						array(



							'id' => 'social_link_googleplus',



							'type' => 'text',



							'title' => esc_html__('Googleplus', 'dpr-adeline-extensions'),



							'hint' => array(



							'title'   => esc_attr__('Googleplus link','dpr-adeline-extensions'),



							'content' => esc_attr__('If you leave this link blank googleplus icon will be not displayed','dpr-adeline-extensions'),



							)



						),



						array(



							'id' => 'social_link_pinterest',



							'type' => 'text',



							'title' => esc_html__('Pinterest', 'dpr-adeline-extensions'),



							'hint' => array(



							'title'   => esc_attr__('Pinterest link','dpr-adeline-extensions'),



							'content' => esc_attr__('If you leave this link blank pinterest icon will be not displayed','dpr-adeline-extensions'),



							)



						),



						array(



							'id' => 'social_link_dribbble',



							'type' => 'text',



							'title' => esc_html__('Dribbble', 'dpr-adeline-extensions'),



							'hint' => array(



							'title'   => esc_attr__('Dribbble link','dpr-adeline-extensions'),



							'content' => esc_attr__('If you leave this link blank dribbble icon will be not displayed','dpr-adeline-extensions'),



							)



						),



						array(



							'id' => 'social_link_instagram',



							'type' => 'text',



							'title' => esc_html__('Instagram', 'dpr-adeline-extensions'),



							'hint' => array(



							'title'   => esc_attr__('Instagram link','dpr-adeline-extensions'),



							'content' => esc_attr__('If you leave this link blank instagram icon will be not displayed','dpr-adeline-extensions'),



							)



						),



						array(



							'id' => 'social_link_linkedin',



							'type' => 'text',



							'title' => esc_html__('Linkedin', 'dpr-adeline-extensions'),



							'hint' => array(



							'title'   => esc_attr__('Linkedin link','dpr-adeline-extensions'),



							'content' => esc_attr__('If you leave this link blank linkedin icon will be not displayed','dpr-adeline-extensions'),



							)



						),



						array(



							'id' => 'social_link_flickr',



							'type' => 'text',



							'title' => esc_html__('Flickr', 'dpr-adeline-extensions'),



							'hint' => array(



							'title'   => esc_attr__('Flickr link','dpr-adeline-extensions'),



							'content' => esc_attr__('If you leave this link blank flickr icon will be not displayed','dpr-adeline-extensions'),



							)



						),



						array(



							'id' => 'social_link_skype',



							'type' => 'text',



							'title' => esc_html__('Skype', 'dpr-adeline-extensions'),



							'hint' => array(



							'title'   => esc_attr__('Skype link','dpr-adeline-extensions'),



							'content' => esc_attr__('If you leave this link blank skype icon will be not displayed','dpr-adeline-extensions'),



							)



						),



						array(



							'id' => 'social_link_vk',



							'type' => 'text',



							'title' => esc_html__('VK', 'dpr-adeline-extensions'),



							'hint' => array(



							'title'   => esc_attr__('VK link','dpr-adeline-extensions'),



							'content' => esc_attr__('If you leave this link blank VK icon will be not displayed','dpr-adeline-extensions'),



							)



						),



						array(



							'id' => 'social_link_viadeo',



							'type' => 'text',



							'title' => esc_html__('Viadeo', 'dpr-adeline-extensions'),



							'hint' => array(



							'title'   => esc_attr__('Viadeo link','dpr-adeline-extensions'),



							'content' => esc_attr__('If you leave this link blank viadeo icon will be not displayed','dpr-adeline-extensions'),



							)



						),



						array(



							'id' => 'social_link_tumblr',



							'type' => 'text',



							'title' => esc_html__('Tumblr', 'dpr-adeline-extensions'),



							'hint' => array(



							'title'   => esc_attr__('Tumblr link','dpr-adeline-extensions'),



							'content' => esc_attr__('If you leave this link blank tumblr icon will be not displayed','dpr-adeline-extensions'),



							)



						),



						array(



							'id' => 'social_link_github',



							'type' => 'text',



							'title' => esc_html__('Github', 'dpr-adeline-extensions'),



							'hint' => array(



							'title'   => esc_attr__('Github link','dpr-adeline-extensions'),



							'content' => esc_attr__('If you leave this link blank github icon will be not displayed','dpr-adeline-extensions'),



							)



						),



						array(



							'id' => 'social_link_youtube',



							'type' => 'text',



							'title' => esc_html__('Youtube', 'dpr-adeline-extensions'),



							'hint' => array(



							'title'   => esc_attr__('Youtube link','dpr-adeline-extensions'),



							'content' => esc_attr__('If you leave this link blank youtube icon will be not displayed','dpr-adeline-extensions'),



							)



						),



						array(



							'id' => 'social_link_vimeo',



							'type' => 'text',



							'title' => esc_html__('Vimeo', 'dpr-adeline-extensions'),



							'hint' => array(



							'title'   => esc_attr__('Vimeo link','dpr-adeline-extensions'),



							'content' => esc_attr__('If you leave this link blank vimeo icon will be not displayed','dpr-adeline-extensions'),



							)



						),



						array(



							'id' => 'social_link_vine',



							'type' => 'text',



							'title' => esc_html__('Vine', 'dpr-adeline-extensions'),



							'hint' => array(



							'title'   => esc_attr__('Vine link','dpr-adeline-extensions'),



							'content' => esc_attr__('If you leave this link blank vine icon will be not displayed','dpr-adeline-extensions'),



							)



						),



						array(



							'id' => 'social_link_stumbleupon',



							'type' => 'text',



							'title' => esc_html__('Stumbleupon', 'dpr-adeline-extensions'),



							'hint' => array(



							'title'   => esc_attr__('Stumbleupon link','dpr-adeline-extensions'),



							'content' => esc_attr__('If you leave this link blank stumbleupon icon will be not displayed','dpr-adeline-extensions'),



							)



						),



						array(



							'id' => 'social_link_xing',



							'type' => 'text',



							'title' => esc_html__('Xing', 'dpr-adeline-extensions'),



							'hint' => array(



							'title'   => esc_attr__('Xing link','dpr-adeline-extensions'),



							'content' => esc_attr__('If you leave this link blank xing icon will be not displayed','dpr-adeline-extensions'),



							)



						),



						array(



							'id' => 'social_link_digg',



							'type' => 'text',



							'title' => esc_html__('Digg', 'dpr-adeline-extensions'),



							'hint' => array(



							'title'   => esc_attr__('Digg link','dpr-adeline-extensions'),



							'content' => esc_attr__('If you leave this link blank digg icon will be not displayed','dpr-adeline-extensions'),



							)



						),



						array(



							'id' => 'social_link_lastfm',



							'type' => 'text',



							'title' => esc_html__('Lastfm', 'dpr-adeline-extensions'),



							'hint' => array(



							'title'   => esc_attr__('Lastfm link','dpr-adeline-extensions'),



							'content' => esc_attr__('If you leave this link blank lastfm icon will be not displayed','dpr-adeline-extensions'),



							)



						),



						array(



							'id' => 'social_link_soundcloud',



							'type' => 'text',



							'title' => esc_html__('Soundcloud', 'dpr-adeline-extensions'),



							'hint' => array(



							'title'   => esc_attr__('Soundcloud link','dpr-adeline-extensions'),







							'content' => esc_attr__('If you leave this link blank soundcloud icon will be not displayed','dpr-adeline-extensions'),



							)



						),



						array(



							'id' => 'social_link_delicious',



							'type' => 'text',



							'title' => esc_html__('Delicious', 'dpr-adeline-extensions'),



							'hint' => array(



							'title'   => esc_attr__('Delicious','dpr-adeline-extensions'),



							'content' => esc_attr__('If you leave this link blank delicious icon will be not displayed','dpr-adeline-extensions'),



							)



						),



						array(



							'id' => 'social_link_yelp',



							'type' => 'text',



							'title' => esc_html__('Yelp', 'dpr-adeline-extensions'),



							'hint' => array(



							'title'   => esc_attr__('Yelp link','dpr-adeline-extensions'),



							'content' => esc_attr__('If you leave this link blank yelp icon will be not displayed','dpr-adeline-extensions'),



							)



						),



						array(



							'id' => 'social_link_tripadvisor',



							'type' => 'text',



							'title' => esc_html__('Tripadvisor', 'dpr-adeline-extensions'),



							'hint' => array(



							'title'   => esc_attr__('Tripadvisor link','dpr-adeline-extensions'),



							'content' => esc_attr__('If you leave this link blank tripadvisor icon will be not displayed','dpr-adeline-extensions'),



							)



						),

						array(

							'id' => 'social_link_odnoklassniki',

							'type' => 'text',

							'title' => esc_html__('Odnoklassniki', 'dpr-adeline-extensions'),

							'hint' => array(

							'title'   => esc_attr__('Odnoklassniki link','dpr-adeline-extensions'),

							'content' => esc_attr__('If you leave this link blank odnoklassniki icon will be not displayed','dpr-adeline-extensions'),

							)

						),

						array(



							'id' => 'social_link_rss',



							'type' => 'text',



							'title' => esc_html__('RSS', 'dpr-adeline-extensions'),



							'hint' => array(



							'title'   => esc_attr__('RSS','dpr-adeline-extensions'),



							'content' => esc_attr__('If you leave this link blank RSS icon will be not displayed','dpr-adeline-extensions'),



							)



						),



						array(



							'id' => 'social_link_email',



							'type' => 'text',



							'title' => esc_html__('Email', 'dpr-adeline-extensions'),



							'hint' => array(



							'title'   => esc_attr__('Email','dpr-adeline-extensions'),



							'content' => esc_attr__('If you leave this link blank email icon will be not displayed','dpr-adeline-extensions'),



							)



						),



	)



	));