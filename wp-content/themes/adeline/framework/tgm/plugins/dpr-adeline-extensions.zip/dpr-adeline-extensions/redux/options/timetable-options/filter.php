<?php



/**



 * Timetable Options -> Filter Bar



 * 



 */







	Redux::setSection( $opt_name, array(



		'title' => esc_html__('Filter Bar', 'dpr-adeline-extensions'),



		'id' => 'timetsble_filter_bar',



		'subsection' => true,



		'fields' => array(



						array(



							'id'   => 'timetable_filter_bar_margin',



							'type' => 'spacing',



							'output'  => array('.mptt-shortcode-wrapper .mptt-navigation-tabs'),



							'mode' => 'margin',



							'units' => array('px'),



							'display_units' => true,



							'units_extended' => false,



							'title' => __('Filter Bar Margin (px)', 'dpr-adeline-extensions'),



							'default' => array(



							'margin-left' => '0px',



							'margin-right' => '0px',



							'margin-bottom' => '25px',



							'margin-top' => '0px', 



							'units' => 'px', 



							),



							'hint' => array (



								'title' => esc_attr__('Filter Bar Margin', 'dpr-adeline-extensions'),



								'content' => esc_attr__('Choose default margin for filter bar.', 'dpr-adeline-extensions')



							)



						),



						array(



							'id'   => 'timetable_filter_buttons_margin',



							'type' => 'spacing',



							'output'  => array('.mptt-shortcode-wrapper .mptt-navigation-tabs li'),



							'mode' => 'margin',



							'units' => array('px'),



							'display_units' => true,



							'units_extended' => false,



							'title' => __('Filter Bar Buttons: Margin (px)', 'dpr-adeline-extensions'),



							'default' => array(



							'margin-left' => '0px',



							'margin-right' => '5px',



							'margin-bottom' => '0px',



							'margin-top' => '0px', 



							'units' => 'px', 



							),



							'hint' => array (



								'title' => esc_attr__('Filter Bar Buttons: Margin', 'dpr-adeline-extensions'),



								'content' => esc_attr__('Choose default margin for filter bar buttons.', 'dpr-adeline-extensions')



							)



						),



						array(



							'id'   => 'timetable_filter_buttons_padding',



							'type' => 'spacing',



							'output'  => array('.mptt-shortcode-wrapper .mptt-navigation-tabs li a'),



							'mode' => 'padding',



							'units' => array('px'),



							'display_units' => true,



							'units_extended' => false,



							'title' => __('Filter Bar Buttons: Padding (px)', 'dpr-adeline-extensions'),



							'default' => array(



							'padding-left' => '12px',



							'padding-right' => '12px',



							'padding-bottom' => '8px',



							'padding-top' => '8px', 



							'units' => 'px', 



							),



							'hint' => array (



								'title' => esc_attr__('Filter Bar Buttons: Padding (px)', 'dpr-adeline-extensions'),



								'content' => esc_attr__('Choose default padding for filter bar buttons.', 'dpr-adeline-extensions')



							)



						),



						array(



							'id'             => 'timetable_filter_buttons_border_radius',



							'type'           => 'dpr_border_radius',



							'units' 		 => array('px','%'),



							'all' => true,



							'output'  => array('.mptt-shortcode-wrapper .mptt-navigation-tabs li a'),



							'units_extended' => false,



							'title'          => __('Filter Bar Buttons: Border Radius', 'dpr-adeline-extensions'),



							'default'            => array(



								'border-top-left-radius'     => '5px', 



								'border-top-right-radius'   => '5px', 



								'border-bottom-right-radius'  => '5px', 



								'border-bottom-left-radius'    => '5px',



								'units'          => 'px', 



							),



							'hint' => array(



								'title'   => esc_attr__('Filter Bar Buttons: Border Radius', 'dpr-adeline-extensions'),



								'content' => esc_attr__( 'Specify border radius for filter buttons.', 'dpr-adeline-extensions')



							)



						),



						array(         



							'id'       => 'timetable_filter_buttons_bg',



							'type'     => 'color',



							'title'    => __('Filter Bar Buttons: Background', 'dpr-adeline-extensions'),



							'default'  => '#e5e5e9',



							'output'  => array( 'background-color' =>'.mptt-shortcode-wrapper .mptt-navigation-tabs li a'),



							'hint' => array(



								'title'   => esc_attr__('Filter Bar Buttons: Background','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Set background color for filter bar buttons.','dpr-adeline-extensions')



							)



						),



						array(         



							'id'       => 'timetable_filter_buttons_bg_hover',



							'type'     => 'color',



							'title'    => __('Filter Bar Buttons: Background Hover', 'dpr-adeline-extensions'),



							'default'  => '#D3AE5F',



							'output'  => array( 'background-color' =>'.mptt-shortcode-wrapper .mptt-navigation-tabs li a:hover, .mptt-shortcode-wrapper .mptt-navigation-tabs li.active a'),



							'hint' => array(



								'title'   => esc_attr__('Filter Bar Buttons: Background Hover','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Set background color for filter bar buttons hover and active.','dpr-adeline-extensions')



							)



						),



						array(         



							'id'       => 'timetable_filter_buttons_text',



							'type'     => 'color',



							'title'    => __('Filter Bar Buttons Text', 'dpr-adeline-extensions'),



							'default'  => '#292933',



							'output'  => array('.mptt-navigation-tabs li a'),



							'hint' => array(



								'title'   => esc_attr__('Filter Bar Buttons Text','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Set filter bar button text color.','dpr-adeline-extensions')



							)



						),



						array(         



							'id'       => 'timetable_filter_buttons_text_hover',



							'type'     => 'color',



							'title'    => __('Filter Bar Buttons Text: Hover', 'dpr-adeline-extensions'),



							'default'  => '#ffffff',



							'output'  => array('.mptt-navigation-tabs li a:hover, .mptt-navigation-tabs li.active a'),



							'hint' => array(



								'title'   => esc_attr__('Filter Bar Buttons Text: Hover','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Set filter bar button text color active nad hover.','dpr-adeline-extensions')



							)



						),



						array(         



							'id'       => 'timetable_filter_buttons_border',



							'type'     => 'color',



							'title'    => __('Filter Bar Buttons Border', 'dpr-adeline-extensions'),



							'default'  => '#e5e5e9',



							'output'  => array( 'border-color' =>'.mptt-navigation-tabs li a'),



							'hint' => array(



								'title'   => esc_attr__('Filter Bar Buttons Border','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Set border color for filter bar buttons.','dpr-adeline-extensions')



							)



						),



						array(         



							'id'       => 'timetable_filter_buttons_border_hover',



							'type'     => 'color',



							'title'    => __('Filter Bar Buttons Border: Hover', 'dpr-adeline-extensions'),



							'default'  => '#D3AE5F',



							'output'  => array( 'border-color' =>'.mptt-shortcode-wrapper .mptt-navigation-tabs li a:hover, .mptt-shortcode-wrapper .mptt-navigation-tabs li.active a'),



							'hint' => array(



								'title'   => esc_attr__('Filter Bar Buttons Border: Hover','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Set border color for filter bar buttons hover and active.','dpr-adeline-extensions')



							)



						),



			)



	));



