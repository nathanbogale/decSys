<?php

if (!defined('ABSPATH')) {exit;}

/*

 * Add-on Name: Testimonial

 */

class WPBakeryShortCode_DPR_Testimonial extends WPBakeryShortCode
{}

vc_map(

    array(

        'name'        => esc_html__('DP Testimonial', 'dpr-adeline-extensions'),

        'base'        => 'dpr_testimonial',

        'class'       => 'dpr_testimonial',

        'icon'        => 'icon-dpr-testimonial',

        "category"    => array(esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'), esc_attr__('Content', 'dpr-adeline-extensions')),

        'description' => esc_html__('Display your customers testimonials. ', 'dpr-adeline-extensions'),

        'params'      => array(

            array(

                'heading'    => esc_html__('Style ', 'dpr-adeline-extensions'),

                'type'       => 'dpr_image_select',

                'param_name' => 'style',

                'options'    => array(

                    'style-1'  => array(

                        'label' => esc_html__('Style 1', 'dpr-adeline-extensions'),

                        'src'   => $module_images . 'testimonials/style-1.jpg',

                    ),

                    'style-2'  => array(

                        'label' => esc_html__('Style 2', 'dpr-adeline-extensions'),

                        'src'   => $module_images . 'testimonials/style-2.jpg',

                    ),

                    'style-3'  => array(

                        'label' => esc_html__('Style 3', 'dpr-adeline-extensions'),

                        'src'   => $module_images . 'testimonials/style-3.jpg',

                    ),

                    'style-4'  => array(

                        'label' => esc_html__('Style 4', 'dpr-adeline-extensions'),

                        'src'   => $module_images . 'testimonials/style-4.jpg',

                    ),

                    'style-5'  => array(

                        'label' => esc_html__('Style 5', 'dpr-adeline-extensions'),

                        'src'   => $module_images . 'testimonials/style-5.jpg',

                    ),

                    'style-6'  => array(

                        'label' => esc_html__('Style 6', 'dpr-adeline-extensions'),

                        'src'   => $module_images . 'testimonials/style-6.jpg',

                    ),

                    'style-7'  => array(

                        'label' => esc_html__('Style 7', 'dpr-adeline-extensions'),

                        'src'   => $module_images . 'testimonials/style-7.jpg',

                    ),

                    'style-8'  => array(

                        'label' => esc_html__('Style 8', 'dpr-adeline-extensions'),

                        'src'   => $module_images . 'testimonials/style-8.jpg',

                    ),

                    'style-9'  => array(

                        'label' => esc_html__('Style 9', 'dpr-adeline-extensions'),

                        'src'   => $module_images . 'testimonials/style-9.jpg',

                    ),

                    'style-10' => array(

                        'label' => esc_html__('Style 10', 'dpr-adeline-extensions'),

                        'src'   => $module_images . 'testimonials/style-10.jpg',

                    ),

                ),

            ),

            array(

                'type'             => 'dpr_title',

                'text'             => esc_html__('Additional Settings', 'dpr-adeline-extensions'),

                'param_name'       => 'extra_features_title',

                'edit_field_class' => 'vc_column vc_col-sm-12',

            ),

            vc_map_add_css_animation(false),

            array(

                'type'       => 'textfield',

                'heading'    => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Extra Class Name', 'dpr-adeline-extensions'),

                'param_name' => 'el_class',

            ),

            /* Content */

            array(

                'type'             => 'attach_image',

                'heading'          => esc_html__('Customer Image', 'dpr-adeline-extensions'),

                'param_name'       => 'image_id',

                'edit_field_class' => 'vc_column vc_col-sm-12  ',

                'description'      => esc_html__('Choose the image from the media library', 'dpr-adeline-extensions'),

                'group'            => esc_html__('Content', 'dpr-adeline-extensions'),

            ),

            array(

                'type'        => 'textfield',

                'heading'     => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Set the testimonial title.', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Title', 'dpr-adeline-extensions'),

                'param_name'  => 'title',

                'admin_label' => true,

                'value'       => esc_html__('Customer Name', 'dpr-adeline-extensions'),

                'group'       => esc_html__('Content', 'dpr-adeline-extensions'),

            ),

            array(

                'type'       => 'textfield',

                'heading'    => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Set the testimonial subtitle.', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Subtitle', 'dpr-adeline-extensions'),

                'param_name' => 'subtitle',

                'value'      => esc_html__('Customer Position', 'dpr-adeline-extensions'),

                'group'      => esc_html__('Content', 'dpr-adeline-extensions'),

            ),

            array(

                'type'             => 'dpr_switcher',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Allows you to display title and subtitle in one line.', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('One line title?', 'dpr-adeline-extensions'),

                'param_name'       => 'one_line_title',

                'options'          => array(

                    'yes' => array(

                        'yes' => esc_attr__('Yes', 'dpr-adeline-extensions'),

                        'no'  => esc_attr__('No', 'dpr-adeline-extensions'),

                    ),

                ),

                'edit_field_class' => 'vc_col-sm-12 vc_column ',

                'group'            => esc_html__('Content', 'dpr-adeline-extensions'),

            ),

            array(

                'type'       => 'textarea',

                'heading'    => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Set the content for testimonial.', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Content', 'dpr-adeline-extensions'),

                'param_name' => 'description',

                'value'      => esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce malesuada lacus condimentum, convallis nulla.', 'dpr-adeline-extensions'),

                'group'      => esc_html__('Content', 'dpr-adeline-extensions'),

            ),

            /* Style */

            array(

                'type'             => 'dpr_title',

                'text'             => esc_html__('Testimonial Image Style', 'dpr-adeline-extensions'),

                'param_name'       => 'style_title_1',

                'edit_field_class' => 'vc_column vc_col-sm-12',

                'group'            => esc_html__('Style', 'dpr-adeline-extensions'),

            ),

            array(

                'type'             => 'number',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Set image size. Default is 90px.', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Image size', 'dpr-adeline-extensions'),

                'param_name'       => 'img_size',

                'min'              => 0,

                'suffix'           => 'px',

                'edit_field_class' => 'vc_column vc_col-sm-6 ',

                'group'            => esc_html__('Style', 'dpr-adeline-extensions'),

            ),

            array(

                'type'             => 'number',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Set image border radius. Default is 50%.', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Image Border Radius', 'dpr-adeline-extensions'),

                'param_name'       => 'img_border_radius',

                'min'              => 0,

                'suffix'           => 'px',

                'edit_field_class' => 'vc_column vc_col-sm-6 ',

                'group'            => esc_html__('Style', 'dpr-adeline-extensions'),

            ),

            array(

                'type'             => 'number',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Set image border width.', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Image Border Width', 'dpr-adeline-extensions'),

                'param_name'       => 'img_border_width',

                'min'              => 0,

                'suffix'           => 'px',

                'edit_field_class' => 'vc_column vc_col-sm-6 ',

                'group'            => esc_html__('Style', 'dpr-adeline-extensions'),

            ),

            array(

                'type'             => 'colorpicker',

                'class'            => '',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Choose bordr color foe image color for content_area. The default is #f1f2f4.', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Image Border Color', 'dpr-adeline-extensions'),

                'param_name'       => 'img_border_color',

                'edit_field_class' => 'vc_column vc_col-sm-6  ',

                'group'            => esc_html__('Style', 'dpr-adeline-extensions'),

            ),

            array(

                'type'             => 'dpr_switcher',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Allows you to add shadow for image.', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Enable Shadow', 'dpr-adeline-extensions'),

                'param_name'       => 'enable_shadow',

                'options'          => array(

                    'yes' => array(

                        'yes' => esc_attr__('Yes', 'dpr-adeline-extensions'),

                        'no'  => esc_attr__('No', 'dpr-adeline-extensions'),

                    ),

                ),

                'edit_field_class' => 'vc_column vc_col-sm-6',

                'group'            => esc_html__('Style', 'dpr-adeline-extensions'),

            ),

            array(

                "type"       => "dpr_shadow_picker",

                "class"      => "",

                'heading'    => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Set shadow for image.', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Image Shadow', 'dpr-adeline-extensions'),

                "param_name" => "image_shadow",

                "value"      => "none||||||",

                'dependency' => array('element' => 'enable_shadow', 'value' => 'yes'),

                'group'      => esc_html__('Style', 'dpr-adeline-extensions'),

            ),

            array(

                'type'             => 'dpr_title',

                'text'             => esc_html__('Testimonial Bubble Style', 'dpr-adeline-extensions'),

                'param_name'       => 'style_title_2',

                'edit_field_class' => 'vc_column vc_col-sm-12',

                'group'            => esc_html__('Style', 'dpr-adeline-extensions'),

            ),

            array(

                'type'             => 'colorpicker',

                'class'            => '',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Choose background color for testimonial bubble.', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Bubble Background', 'dpr-adeline-extensions'),

                'param_name'       => 'bg_color',

                'edit_field_class' => 'vc_column vc_col-sm-4  ',

                'group'            => esc_html__('Style', 'dpr-adeline-extensions'),

            ),

            array(

                'type'             => 'number',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Set testimonial bubble border radius.', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Bubble Border Radius', 'dpr-adeline-extensions'),

                'param_name'       => 'bg_border_radius',

                'min'              => 0,

                'suffix'           => 'px',

                'edit_field_class' => 'vc_column vc_col-sm-4 ',

                'dependency'       => array('element' => 'bg_color', 'not_empty' => true),

                'group'            => esc_html__('Style', 'dpr-adeline-extensions'),

            ),

            array(

                'type'             => 'dpr_switcher',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Allows you to add pointer arrow to testimonial bubble.', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Use Triangle Arrow?', 'dpr-adeline-extensions'),

                'param_name'       => 'enable_arrow',

                'options'          => array(

                    'yes' => array(

                        'yes' => esc_attr__('Yes', 'dpr-adeline-extensions'),

                        'no'  => esc_attr__('No', 'dpr-adeline-extensions'),

                    ),

                ),

                'edit_field_class' => 'vc_column vc_col-sm-4',

                'dependency'       => array('element' => 'bg_color', 'not_empty' => true),

                'group'            => esc_html__('Style', 'dpr-adeline-extensions'),

            ),

            /* Typography */

            array(

                'type'             => 'dpr_title',

                'text'             => esc_html__('Title Typography', 'dpr-adeline-extensions'),

                'param_name'       => 'typography_title_1',

                'class'            => '',

                'edit_field_class' => 'vc_column vc_col-sm-12',

                'group'            => esc_attr__('Typography', 'dpr-adeline-extensions'),

            ),

            array(

                'type'             => 'colorpicker',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Set custom ttle color. Default is headings color set in template options.', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Color', 'dpr-adeline-extensions'),

                'param_name'       => 'title_color',

                'edit_field_class' => 'vc_column vc_col-sm-3 ',

                'group'            => esc_html__('Typography', 'dpr-adeline-extensions'),

            ),

            array(

                'type'             => 'number',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Set custom font size.Default is 18px .', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Font size', 'dpr-adeline-extensions'),

                'param_name'       => 'title_font_size',

                'min'              => 1,

                'suffix'           => 'px',

                'edit_field_class' => 'vc_column vc_col-sm-3 ',

                'group'            => esc_html__('Typography', 'dpr-adeline-extensions'),

            ),

            array(

                'type'             => 'number',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Set custom title linne height.Default is 18px .', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Line Height', 'dpr-adeline-extensions'),

                'param_name'       => 'title_line_height',

                'min'              => 1,

                'suffix'           => 'px',

                'edit_field_class' => 'vc_column vc_col-sm-3 ',

                'group'            => esc_html__('Typography', 'dpr-adeline-extensions'),

            ),

            array(

                'type'             => 'number',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Set custom title letter sapacing. Default is 0 .', 'dpr-adeline-extensions') . '" data-balloon-pos="left"><span></span></span>' . esc_html__('Letter spacing', 'dpr-adeline-extensions'),

                'param_name'       => 'title_letter_spacing',

                'min'              => 1,

                'suffix'           => 'px',

                'edit_field_class' => 'vc_column vc_col-sm-3 ',

                'group'            => esc_html__('Typography', 'dpr-adeline-extensions'),

            ),

            array(

                'type'             => 'checkbox',

                'class'            => '',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Set custom font style', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Font style', 'dpr-adeline-extensions'),

                'param_name'       => 'title_font_style',

                'edit_field_class' => 'vc_column vc_col-sm-6 ',

                'value'            => array(

                    __('<i>Italic</i>', 'dpr-adeline-extensions')    => 'italic',

                    __('<u>Underline</u>', 'dpr-adeline-extensions') => 'underline',

                    __('<b>Bold</b>', 'dpr-adeline-extensions')      => 'bold',

                ),

                'group'            => esc_html__('Typography', 'dpr-adeline-extensions'),

            ),

            array(

                'type'             => 'dpr_switcher',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Enable custom Google font. .', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Custom font family', 'dpr-adeline-extensions'),

                'param_name'       => 'title_use_google_fonts',

                'edit_field_class' => 'vc_column vc_col-sm-6 ',

                'options'          => array(

                    'yes' => array(

                        'yes' => esc_attr__('Yes', 'dpr-adeline-extensions'),

                        'no'  => esc_attr__('No', 'dpr-adeline-extensions'),

                    ),

                ),

                'group'            => esc_html__('Typography', 'dpr-adeline-extensions'),

            ),

            array(

                'type'             => 'google_fonts',

                'param_name'       => 'title_google_font',

                'settings'         => array(

                    'fields' => array(

                        'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

                        'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

                    ),

                ),

                'edit_field_class' => 'vc_column vc_col-sm-12 ',

                'dependency'       => array('element' => 'title_use_google_fonts', 'value' => 'yes'),

                'group'            => esc_attr__('Typography', 'dpr-adeline-extensions'),

            ),

            array(

                'type'             => 'dpr_title',

                'text'             => esc_html__('Subtitle Typography', 'dpr-adeline-extensions'),

                'param_name'       => 'subtitle_typography_head',

                'class'            => '',

                'edit_field_class' => 'vc_column vc_col-sm-12',

                'group'            => esc_html__('Typography', 'dpr-adeline-extensions'),

            ),

            array(

                'type'             => 'colorpicker',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Set custom subtitle color. Default is #808080.', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Color', 'dpr-adeline-extensions'),

                'param_name'       => 'subtitle_color',

                'edit_field_class' => 'vc_column vc_col-sm-3 ',

                'group'            => esc_html__('Typography', 'dpr-adeline-extensions'),

            ),

            array(

                'type'             => 'number',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Set custom font size.Default is 13px .', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Font size', 'dpr-adeline-extensions'),

                'param_name'       => 'subtitle_font_size',

                'min'              => 1,

                'suffix'           => 'px',

                'edit_field_class' => 'vc_column vc_col-sm-3 ',

                'group'            => esc_html__('Typography', 'dpr-adeline-extensions'),

            ),

            array(

                'type'             => 'number',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Set custom linne height.Default is 28px .', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Line Height', 'dpr-adeline-extensions'),

                'param_name'       => 'subtitle_line_height',

                'min'              => 1,

                'suffix'           => 'px',

                'edit_field_class' => 'vc_column vc_col-sm-3 ',

                'group'            => esc_html__('Typography', 'dpr-adeline-extensions'),

            ),

            array(

                'type'             => 'number',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Set custom letter sapacing. Default is 0 .', 'dpr-adeline-extensions') . '" data-balloon-pos="left"><span></span></span>' . esc_html__('Letter spacing', 'dpr-adeline-extensions'),

                'param_name'       => 'subtitle_letter_spacing',

                'min'              => 1,

                'suffix'           => 'px',

                'edit_field_class' => 'vc_column vc_col-sm-3 ',

                'group'            => esc_html__('Typography', 'dpr-adeline-extensions'),

            ),

            array(

                'type'             => 'checkbox',

                'class'            => '',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Set custom font style', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Font style', 'dpr-adeline-extensions'),

                'param_name'       => 'subtitle_font_style',

                'edit_field_class' => 'vc_column vc_col-sm-6 ',

                'value'            => array(

                    __('<i>Italic</i>', 'dpr-adeline-extensions')    => 'italic',

                    __('<u>Underline</u>', 'dpr-adeline-extensions') => 'underline',

                    __('<b>Bold</b>', 'dpr-adeline-extensions')      => 'bold',

                ),

                'group'            => esc_html__('Typography', 'dpr-adeline-extensions'),

            ),

            array(

                'type'             => 'dpr_switcher',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Enable custom Google font. .', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Custom font family', 'dpr-adeline-extensions'),

                'param_name'       => 'subtitle_use_google_fonts',

                'edit_field_class' => 'vc_column vc_col-sm-6 ',

                'options'          => array(

                    'yes' => array(

                        'yes' => esc_attr__('Yes', 'dpr-adeline-extensions'),

                        'no'  => esc_attr__('No', 'dpr-adeline-extensions'),

                    ),

                ),

                'group'            => esc_html__('Typography', 'dpr-adeline-extensions'),

            ),

            array(

                'type'             => 'google_fonts',

                'param_name'       => 'subtitle_google_font',

                'settings'         => array(

                    'fields' => array(

                        'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

                        'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

                    ),

                ),

                'edit_field_class' => 'vc_column vc_col-sm-12 ',

                'dependency'       => array('element' => 'subtitle_use_google_fonts', 'value' => 'yes'),

                'group'            => esc_attr__('Typography', 'dpr-adeline-extensions'),

            ),

            array(

                'type'             => 'dpr_title',

                'text'             => esc_html__('Content Typography', 'dpr-adeline-extensions'),

                'param_name'       => 'description_typgraphy_head',

                'class'            => '',

                'edit_field_class' => 'vc_column vc_col-sm-12',

                'group'            => esc_attr__('Typography', 'dpr-adeline-extensions'),

            ),

            array(

                'type'             => 'colorpicker',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Set custom content color. Default is text color set in template options.', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Color', 'dpr-adeline-extensions'),

                'param_name'       => 'content_color',

                'edit_field_class' => 'vc_column vc_col-sm-3 ',

                'group'            => esc_html__('Typography', 'dpr-adeline-extensions'),

            ),

            array(

                'type'             => 'number',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Set custom font size.Default text font size set in template options .', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Font size', 'dpr-adeline-extensions'),

                'param_name'       => 'content_font_size',

                'min'              => 1,

                'suffix'           => 'px',

                'edit_field_class' => 'vc_column vc_col-sm-3 ',

                'group'            => esc_html__('Typography', 'dpr-adeline-extensions'),

            ),

            array(

                'type'             => 'number',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Set custom line height. Default is text line height set in template options .', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Line Height', 'dpr-adeline-extensions'),

                'param_name'       => 'content_line_height',

                'min'              => 1,

                'suffix'           => 'px',

                'edit_field_class' => 'vc_column vc_col-sm-3 ',

                'group'            => esc_html__('Typography', 'dpr-adeline-extensions'),

            ),

            array(

                'type'             => 'number',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Set custom letter sapacing. Default is 0 .', 'dpr-adeline-extensions') . '" data-balloon-pos="left"><span></span></span>' . esc_html__('Letter spacing', 'dpr-adeline-extensions'),

                'param_name'       => 'content_letter_spacing',

                'min'              => 1,

                'suffix'           => 'px',

                'edit_field_class' => 'vc_column vc_col-sm-3 ',

                'group'            => esc_html__('Typography', 'dpr-adeline-extensions'),

            ),

            array(

                'type'             => 'checkbox',

                'class'            => '',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Set custom font style', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Font style', 'dpr-adeline-extensions'),

                'param_name'       => 'content_font_style',

                'edit_field_class' => 'vc_column vc_col-sm-6 ',

                'value'            => array(

                    __('<i>Italic</i>', 'dpr-adeline-extensions')    => 'italic',

                    __('<u>Underline</u>', 'dpr-adeline-extensions') => 'underline',

                    __('<b>Bold</b>', 'dpr-adeline-extensions')      => 'bold',

                ),

                'group'            => esc_html__('Typography', 'dpr-adeline-extensions'),

            ),

            array(

                'type'             => 'dpr_switcher',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Enable custom Google font. .', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Custom font family', 'dpr-adeline-extensions'),

                'param_name'       => 'content_use_google_fonts',

                'edit_field_class' => 'vc_column vc_col-sm-6 ',

                'options'          => array(

                    'yes' => array(

                        'yes' => esc_attr__('Yes', 'dpr-adeline-extensions'),

                        'no'  => esc_attr__('No', 'dpr-adeline-extensions'),

                    ),

                ),

                'dependency'       => array('element' => 'title', 'not_empty' => true),

                'group'            => esc_html__('Typography', 'dpr-adeline-extensions'),

            ),

            array(

                'type'             => 'google_fonts',

                'param_name'       => 'content_google_font',

                'settings'         => array(

                    'fields' => array(

                        'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

                        'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

                    ),

                ),

                'edit_field_class' => 'vc_column vc_col-sm-12 ',

                'dependency'       => array('element' => 'content_use_google_fonts', 'value' => 'yes'),

                'group'            => esc_attr__('Typography', 'dpr-adeline-extensions'),

            ),

            array(

                'type'             => 'dpr_title',

                'text'             => esc_html__('Title Responsive Typography', 'dpr-adeline-extensions'),

                'param_name'       => 'title_reaponsive_typography_head',

                'class'            => '',

                'edit_field_class' => 'vc_column vc_col-sm-12',

                'group'            => esc_attr__('Responsive', 'dpr-adeline-extensions'),

            ),

            array(

                'type'             => 'dpr_switcher',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Enable responsive typography for title.', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Enable', 'dpr-adeline-extensions'),

                'param_name'       => 'use_title_responsive_typo',

                'edit_field_class' => 'vc_column vc_col-sm-6 ',

                'options'          => array(

                    'yes' => array(

                        'yes' => esc_attr__('Yes', 'dpr-adeline-extensions'),

                        'no'  => esc_attr__('No', 'dpr-adeline-extensions'),

                    ),

                ),

                'group'            => esc_html__('Responsive', 'dpr-adeline-extensions'),

            ),

            array(

                'type'             => 'dpr_responsive_typo',

                'param_name'       => 'title_reaponsive_typography',

                'heading'          => '',

                'class'            => '',

                'edit_field_class' => 'vc_column vc_col-sm-12',

                'dependency'       => array('element' => 'use_title_responsive_typo', 'value' => array('yes')),

                'group'            => esc_attr__('Responsive', 'dpr-adeline-extensions'),

            ),

            array(

                'type'             => 'dpr_title',

                'text'             => esc_html__('Subtitle Responsive Typography', 'dpr-adeline-extensions'),

                'param_name'       => 'subtitle_reaponsive_typography_head',

                'class'            => '',

                'edit_field_class' => 'vc_column vc_col-sm-12',

                'group'            => esc_attr__('Responsive', 'dpr-adeline-extensions'),

            ),

            array(

                'type'             => 'dpr_switcher',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Enable responsive typography for subtitle.', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Enable', 'dpr-adeline-extensions'),

                'param_name'       => 'use_subtitle_responsive_typo',

                'edit_field_class' => 'vc_column vc_col-sm-6 ',

                'options'          => array(

                    'yes' => array(

                        'yes' => esc_attr__('Yes', 'dpr-adeline-extensions'),

                        'no'  => esc_attr__('No', 'dpr-adeline-extensions'),

                    ),

                ),

                'group'            => esc_html__('Responsive', 'dpr-adeline-extensions'),

            ),

            array(

                'type'             => 'dpr_responsive_typo',

                'param_name'       => 'subtitle_reaponsive_typography',

                'heading'          => '',

                'class'            => '',

                'edit_field_class' => 'vc_column vc_col-sm-12',

                'dependency'       => array('element' => 'use_subtitle_responsive_typo', 'value' => array('yes')),

                'group'            => esc_attr__('Responsive', 'dpr-adeline-extensions'),

            ),

            array(

                'type'             => 'dpr_title',

                'text'             => esc_html__('Content Responsive Typography', 'dpr-adeline-extensions'),

                'param_name'       => 'content_reaponsive_typography_head',

                'class'            => '',

                'edit_field_class' => 'vc_column vc_col-sm-12',

                'group'            => esc_attr__('Responsive', 'dpr-adeline-extensions'),

            ),

            array(

                'type'             => 'dpr_switcher',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Enable responsive typography for bubble content.', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Enable', 'dpr-adeline-extensions'),

                'param_name'       => 'use_content_responsive_typo',

                'edit_field_class' => 'vc_column vc_col-sm-6 ',

                'options'          => array(

                    'yes' => array(

                        'yes' => esc_attr__('Yes', 'dpr-adeline-extensions'),

                        'no'  => esc_attr__('No', 'dpr-adeline-extensions'),

                    ),

                ),

                'group'            => esc_html__('Responsive', 'dpr-adeline-extensions'),

            ),

            array(

                'type'             => 'dpr_responsive_typo',

                'param_name'       => 'content_reaponsive_typography',

                'heading'          => '',

                'class'            => '',

                'edit_field_class' => 'vc_column vc_col-sm-12',

                'dependency'       => array('element' => 'use_content_responsive_typo', 'value' => array('yes')),

                'group'            => esc_attr__('Responsive', 'dpr-adeline-extensions'),

            ),

        ),

    )

);
