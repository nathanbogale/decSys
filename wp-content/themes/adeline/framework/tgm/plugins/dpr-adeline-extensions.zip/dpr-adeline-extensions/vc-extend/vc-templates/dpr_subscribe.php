<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$unique_id = $el_class = $custom_el_css = $style = $btn_text = $placeholder_text = $feed_name = "";
$border_radius = $button_alignment = $field_color = $placeholder_color = $field_bg_color = $field_border_color = $field_border_width = $btn_text_color = $btn_text_color_hover = $btn_bg_color = $btn_bg_color_hover = '';

$atts = vc_map_get_attributes( 'dpr_subscribe', $atts );
extract( $atts );

$unique_id = uniqid('dpr-subscribe-').'-'.rand(1,9999);
if ( '' !== $css_animation && 'none' !== $css_animation ) {
			wp_enqueue_script( 'vc_waypoints' );
			wp_enqueue_style( 'vc_animate-css' );
			$el_class .= ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
}

/* Element classes */
if(isset($style) & $style !='') {
	$el_class .= ' '.$style;
}
if(isset($button_alignment) & $style !='') {
	$el_class .= ' '.$button_alignment;
}

$css_classes = array(
	'dpr-subscribe',
	$unique_id,
	$el_class,
);

$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->settings['base'], $atts ) );

/* * ************************
 * Styles and custom CSS
 * *********************** */
if(isset($border_radius) && !empty($border_radius)) {
	if ($style= "style-2") {
		$custom_el_css .= '.'.esc_js($unique_id).' input.text, .'.esc_js($unique_id).' .submit {border-radius: '.esc_attr($border_radius).'px !important;}';
	} else {
		$custom_el_css .= '.'.esc_js($unique_id).' input.text, .'.esc_js($unique_id).' .submit {border-radius: '.esc_attr($border_radius).'px;}';
	}
}
if(isset($field_color) && !empty($field_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).' input.text {color: '.esc_attr($field_color).';}';
}
if(isset($field_bg_color) && !empty($field_bg_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).' input.text {background: '.esc_attr($field_bg_color).';}';
}
if(isset($field_border_color) && !empty($field_border_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).' input.text {border-color: '.esc_attr($field_border_color).';}';
}
if(isset($field_border_width) && !empty($field_border_width)) {
	$custom_el_css .= '.'.esc_js($unique_id).' input.text, .'.esc_js($unique_id).' .submit {border-width: '.esc_attr($field_border_width).'px;}';
}
if(isset($btn_text_color) && !empty($btn_text_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .submit {color: '.esc_attr($btn_text_color).';}';
}
if(isset($btn_text_color_hover) && !empty($btn_text_color_hover)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .submit:hover {color: '.esc_attr($btn_text_color_hover).';}';
}
if(isset($btn_bg_color) && !empty($btn_bg_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .submit {background: '.esc_attr($btn_bg_color).';border-color:'.esc_attr($btn_bg_color).'}';
}
if(isset($btn_bg_color_hover) && !empty($btn_bg_color_hover)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .submit:hover {background: '.esc_attr($btn_bg_color_hover).';border-color:'.esc_attr($btn_bg_color_hover).'}';
}
if(isset($btn_border_color) && !empty($btn_border_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .submit {border-color:'.esc_attr($btn_bg_color).'}';
}
if(isset($btn_border_color_hover) && !empty($btn_border_color_hover)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .submit:hover {border-color:'.esc_attr($btn_border_color_hover).'}';
}
if(isset($placeholder_color) && !empty($placeholder_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).' ::-webkit-input-placeholder {color: '.esc_attr($placeholder_color).';}';
	$custom_el_css .= '.'.esc_js($unique_id).' :-moz-placeholder {color: '.esc_attr($placeholder_color).';}';
	$custom_el_css .= '.'.esc_js($unique_id).' ::-moz-placeholder {color: '.esc_attr($placeholder_color).';}';
	$custom_el_css .= '.'.esc_js($unique_id).' :-ms-input-placeholder {color: '.esc_attr($placeholder_color).';}';
}

/* * ************************
 * Output
 * *********************** */
$output .= '<div id="'.esc_attr($unique_id).'" class="'.esc_attr($css_class).' clr">';
	if($feed_name == '') :
		$output .= '<div class="burner-error">'.esc_html__('Please fill in the Feedburner Feed Name parameter', 'dpr-adeline-extensions').'</div>';
	endif;
	$output .= '<div class="form-container">';
		$output .= '<form action="//feedburner.google.com/fb/a/mailverify" method="post" target="popupwindow" onsubmit="window.open(\'http://feedburner.google.com/fb/a/mailverify?uri='. $feed_name.'\', \'popupwindow\', \'scrollbars=yes,width=550,height=520\');return true">';
			$output .= '<div class="divTable">';
				$output .= '<div class="divTableRow">';
					$output .= '<div class="divTableCell email-wrap">';
						$output .= '<input class="text" type="text" name="email" id="'.uniqid('subsmail_').'" placeholder="'. esc_attr($placeholder_text).'" />';
					$output .= '</div>';
					$output .= '<div class="divTableCell submit-wrap">';
						$output .= '<button type="submit" class="submit">'.$btn_text.'</button>';
					$output .= '</div>';
				$output .= '</div>';
			$output .= '</div>';
			$output .= '<input type="hidden" value="'.esc_attr($feed_name).'" name="uri"/>';
			$output .= '<input type="hidden" name="loc" value="en_US"/>';
		$output .= '</form>';
	$output .= '</div>';


if(!empty($custom_el_css)) {
		$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>");'
						. '})(jQuery);'
					. '</script>';
}
$output .= "</div>";
echo $output;

