<?php

// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}

/*

* Add-on Name: Countdown

*/



class WPBakeryShortCode_DPR_Language_Switcher extends WPBakeryShortCode {}



vc_map(

	array(

		'name'					=> esc_html__(' DP Language Switcher', 'dpr-adeline-extensions'),

		'base'					=> 'dpr_language_switcher',

		'icon'					=> 'icon-dpr-lang-switcher',

  		"category" =>array( esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions'),esc_attr__('Header Builder', 'dpr-adeline-extensions'),),

		'description'			=> esc_html__('Display WPML Language Switcher ', 'dpr-adeline-extensions'),

		'params'				=> array(

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select switcher type.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Switcher Type', 'dpr-adeline-extensions'),

				'param_name'		=> 'switcher_type',

				'value'				=> 'custom',

				'edit_field_class'	=> 'vc_column vc_col-sm-12  ',

				'description'			=> wp_kses_post(__('<strong>Custom</strong> outputs the language switcher based on the WPML options set in the <strong>Custom Language Switchers</strong> section. <strong>Footer</strong> outputs the language switcher based on the WPML options set in the <strong>Footer Language Switchers</strong> section even if the <b>Show language switcher in footer</b> option is disabled. <a href="https://wpml.org/documentation/getting-started-guide/language-setup/language-switcher-options/#custom-locations" target="_blank">More info</a> ', 'dpr-adeline-extensions')),

				'options'			=> array(

					esc_html__('Custom Switcher', 'dpr-adeline-extensions')	=> 'custom',

					esc_html__('Footer Switcher', 'dpr-adeline-extensions')	=> 'footer'

				)

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set switcher alignment in column.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Switcher Alignment', 'dpr-adeline-extensions'),

				'param_name'		=> 'switcher_alignment',

				'value'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12  ',

				'options'			=> array(

					esc_html__('Left', 'dpr-adeline-extensions')	=> '',

					esc_html__('Center', 'dpr-adeline-extensions')	=> 'text-center',

					esc_html__('Right', 'dpr-adeline-extensions')	=> 'text-right',

				)

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Additional Settings', 'dpr-adeline-extensions' ),

				'param_name'       => 'extra_features_title',

				'edit_field_class' => 'vc_column vc_col-sm-12',

			),

		   vc_map_add_css_animation( false ),

		    array(

				'type' => 'textfield',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Extra Class Name', 'dpr-adeline-extensions'),

				'param_name' => 'el_class',

			),







			array(

				'type' => 'css_editor',

				'heading' => __( 'CSS box', 'dpr-adeline-extensions' ),

				'param_name' => 'css',

				'group' => __( 'Design Options', 'dpr-adeline-extensions' ),

			),



		)

	)

);