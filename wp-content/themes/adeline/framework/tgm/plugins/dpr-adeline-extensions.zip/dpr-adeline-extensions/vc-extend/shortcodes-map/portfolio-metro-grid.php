<?php

// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}

/*

* Add-on Name: Portfolio Metro Grid

*/



class WPBakeryShortCode_DPR_Portfolio_Metro_Grid extends WPBakeryShortCode {}



vc_map(

	array(

		'name'					=> esc_html__('DP Portfolio Metro', 'dpr-adeline-extensions'),

		'base'					=> 'dpr_portfolio_metro_grid',

		"icon"					=> 'icon-dpr-portfolio-metro-grid',

		"class"					=> 'dpr_portfolio_metro_grid',

  		"category" =>array( esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions')),

		'description'			=> esc_html__('Display portfolio items in metro style grid', 'dpr-adeline-extensions'),

		'params'				=> array(

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Source Settings', 'dpr-adeline-extensions' ),

				'param_name'       => 'extra_features_title',

				'edit_field_class' => 'vc_column vc_col-sm-12',

			),

			array(

				'type'				=> 'param_group',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Add portfolio items to display.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('List of portfolio items', 'dpr-adeline-extensions'),

				'param_name'		=> 'item_list',

				'params'			=> array(

					array(

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose portfolio item.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Portfolio Item', 'dpr-adeline-extensions'),

						'type'				=> 'dpr_image_post_select',

						'param_name'		=> 'portfolio_item',

						'admin_label' => true,

						'value' 			=> '',

						'edit_field_class' => 'vc_column vc_col-sm-12',

						'post_type' => 'dpr_portfolio'

					),

					array(

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose size for this portfolio item.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Item Size', 'dpr-adeline-extensions'),

						'type'				=> 'dpr_image_select',

						'param_name'		=> 'item_size',

						'value' 			=> 'default',

						'edit_field_class' => 'vc_column vc_col-sm-8',

						'options'			=> array(

							'default'			=> array(

								'label'			=> esc_html__('Default', 'dpr-adeline-extensions'),

								'src'				=> $module_images.'portfolio/media-size-1.png'

							),

							'wide'			=> array(

								'label'			=> esc_html__('Wide 2:1', 'dpr-adeline-extensions'),

								'src'				=> $module_images.'portfolio/media-size-2.png'

							),

							'tall'			=> array(

								'label'			=> esc_html__('Tall 1:2', 'dpr-adeline-extensions'),

								'src'				=> $module_images.'portfolio/media-size-3.png'

							),

							'large'			=> array(

								'label'			=> esc_html__('Large 2:2', 'dpr-adeline-extensions'),

								'src'				=> $module_images.'portfolio/media-size-4.png'

							),

						),

					),

					array(

						'type'				=> 'colorpicker',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Here you can set custom overlay color for this item.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom Overlay Color', 'dpr-adeline-extensions'),

						'param_name'		=> 'custom_overlay_color',

						'edit_field_class'	=> 'vc_column vc_col-sm-4',

					),

					

						),

			),

			array(

			'type'             => 'dpr_title',

			'text'             => esc_html__( 'Additional Settings', 'dpr-adeline-extensions' ),

			'param_name'       => 'extra_features_title',

			'edit_field_class' => 'vc_column vc_col-sm-12',

		),

			vc_map_add_css_animation( false ),

		    array(

				'type' => 'textfield',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Extra Class Name', 'dpr-adeline-extensions'),

				'param_name' => 'el_class',

			),

			array(

			'type'             => 'dpr_title',

			'text'             => esc_html__( 'Grid General Settings', 'dpr-adeline-extensions' ),

			'param_name'       => 'grid_title_1',

			'edit_field_class' => 'vc_column vc_col-sm-12',

			'group'				=> esc_html__('Grid Settings', 'dpr-adeline-extensions'),

		),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set columns count.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Columns Count', 'dpr-adeline-extensions'),

				'param_name'		=> 'columns',

				'min'				=> 1,

				'max' 				=> 6,

				'value' 			=> 4,

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'group'				=> esc_html__('Grid Settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set columns count for tablets.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Columns Count: Tablet', 'dpr-adeline-extensions'),

				'param_name'		=> 'columns_tablet',

				'min'				=> 1,

				'max' 				=> 4,

				'value' 			=> 2,

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'group'				=> esc_html__('Grid Settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set columns count for mobile.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Columns Count: Mobile', 'dpr-adeline-extensions'),

				'param_name'		=> 'columns_mobile',

				'min'				=> 1,

				'max' 				=> 2,

				'value' 			=> 1,

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'group'				=> esc_html__('Grid Settings', 'dpr-adeline-extensions'),

			),

			array(

			'type'             => 'dpr_title',

			'text'             => esc_html__( 'Grid Items Settings', 'dpr-adeline-extensions' ),

			'param_name'       => 'grid_title_2',

			'edit_field_class' => 'vc_column vc_col-sm-12',

			'group'				=> esc_html__('Grid Settings', 'dpr-adeline-extensions'),

		),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set padding for portfolio entry.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Entry Padding', 'dpr-adeline-extensions'),

				'param_name'		=> 'items_padding',

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'group'				=> esc_html__('Grid Settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose entry background color. Default is transparent', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Entry Background Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'items_bg_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'group'				=> esc_html__('Grid Settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set border radius for items.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Items Border Radius', 'dpr-adeline-extensions'),

				'param_name'		=> 'items_border_radius',

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'group'				=> esc_html__('Grid Settings', 'dpr-adeline-extensions'),

			),

			array(

			'type'            	=> 'dpr_title',

			'class'			  	=> 'small',

			'text'            	=> esc_html__( 'Content Style', 'dpr-adeline-extensions' ),

			'param_name'       	=> 'grid_title_4',

			'edit_field_class' 	=> 'vc_column vc_col-sm-12',

			'group'				=> esc_html__('Grid Settings', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'dpr_switcher',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('This option allows you to enable or disable display of entry title.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Display Entry Title?', 'dpr-adeline-extensions'),

				'param_name' => 'display_title',

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'value' => 'yes',

				'options' => array(

					'yes' => array(

							'label' => '',

							'on' => 'Yes',

							'off' => 'No',

						),

					),

				'group'				=> esc_html__('Grid Settings', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'dpr_switcher',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('This option allows you to enable or disable display of entry category.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Display Entry Category?', 'dpr-adeline-extensions'),

				'param_name' => 'display_category',

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'value' => '',

				'options' => array(

					'yes' => array(

							'label' => '',

							'on' => 'Yes',

							'off' => 'No',

						),

					),

				'group'				=> esc_html__('Grid Settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose title color. Default is as set in Template Options.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Title Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Grid Settings', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'display_title', 'value' => array('yes')),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose title hover color. Default is as set in Template Options.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Title Color: Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_color_hover',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Grid Settings', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'display_title', 'value' => array('yes')),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose category link color. Default is as set in Template Options.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Category Link Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'category_link_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Grid Settings', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'display_category', 'value' => array('yes')),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose category link hover color. Default is as set in Template Options.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Category Link Color: Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'category_link_color_hover',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Grid Settings', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'display_category', 'value' => array('yes')),

			),

			array(

			'type'            	=> 'dpr_title',

			'class'			  	=> 'small',

			'text'            	=> esc_html__( 'Portfolio Entry Decoration && Hover State', 'dpr-adeline-extensions' ),

			'param_name'       	=> 'grid_title_5',

			'edit_field_class' 	=> 'vc_column vc_col-sm-12',

			'group'				=> esc_html__('Grid Settings', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'dropdown',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set hover animation for portfolio items.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Item Hover animation', 'dpr-adeline-extensions'),

				'param_name' => 'entry_hover_animation',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'value' => array(

					__('None', 'dpr-adeline-extensions') => 'none',

                    __('Scale Up 3%', 'dpr-adeline-extensions')       => 'dpr-upscale-onhover-1',

                    __('Scale Up 6%', 'dpr-adeline-extensions')       => 'dpr-upscale-onhover-2',

                    __('Scale Up 15%', 'dpr-adeline-extensions')      => 'dpr-upscale-onhover-3',

                     __('Scale Up 10%', 'dpr-adeline-extensions')      => 'dpr-upscale-onhover-3',

                    __('Scale Down 3%', 'dpr-adeline-extensions')     => 'dpr-downscale-onhover-4',

                    __('Scale Down 6%', 'dpr-adeline-extensions')     => 'dpr-downscale-onhover-2',

                    __('Move Up 5px', 'dpr-adeline-extensions')       => 'dpr-up-onhover-1',

                    __('Move Up 10px', 'dpr-adeline-extensions')      => 'dpr-up-onhover-2',

                    __('Move Up 15px', 'dpr-adeline-extensions')      => 'dpr-up-onhover-3',

                    __('Move Up 20px', 'dpr-adeline-extensions')      => 'dpr-up-onhover-4',

                    __('Move Down 5px', 'dpr-adeline-extensions')     => 'dpr-down-onhover-1',

                    __('Move Down 10px', 'dpr-adeline-extensions')    => 'dpr-down-onhover-2',

                    __('Move Down 15px', 'dpr-adeline-extensions')    => 'dpr-down-onhover-3',

                    __('Move Down 20px', 'dpr-adeline-extensions')    => 'dpr-down-onhover-4',

                    __('Move UpLeft 5px', 'dpr-adeline-extensions')   => 'dpr-up-left-onhover-1',

                    __('Move UpLeft 10px', 'dpr-adeline-extensions')  => 'dpr-up-left-onhover-2',

                    __('Move UpLeft 15px', 'dpr-adeline-extensions')  => 'dpr-up-left-onhover-3',

                    __('Move UpLeft 20px', 'dpr-adeline-extensions')  => 'dpr-up-left-onhover-4',

                    __('Move UpRight 5px', 'dpr-adeline-extensions')  => 'dpr-up-right-onhover-1',

                    __('Move UpRight 10px', 'dpr-adeline-extensions') => 'dpr-up-right-onhover-2',

                    __('Move UpRight 15px', 'dpr-adeline-extensions')  => 'dpr-up-right-onhover-3',

                    __('Move UpRight 20px', 'dpr-adeline-extensions') => 'dpr-up-right-onhover-4',

                    __('Move DownLeft 5px', 'dpr-adeline-extensions')  => 'dpr-down-left-onhover-1',

                    __('Move DownLeft 10px', 'dpr-adeline-extensions') => 'dpr-down-left-onhover-2',

                    __('Move DownLeft 15px', 'dpr-adeline-extensions')  => 'dpr-down-left-onhover-3',

                    __('Move DownLeft 20px', 'dpr-adeline-extensions') => 'dpr-down-left-onhover-4',  

                    __('Move DownRight 5px', 'dpr-adeline-extensions')  => 'dpr-down-right-onhover-1',

                    __('Move DownRight 10px', 'dpr-adeline-extensions') => 'dpr-down-right-onhover-2',

                    __('Move DownRight 15px', 'dpr-adeline-extensions')  => 'dpr-down-right-onhover-3',

                    __('Move DownRight 20px', 'dpr-adeline-extensions') => 'dpr-down-right-onhover-4', 

                    __('Item Tilt', 'dpr-adeline-extensions') => 'dpr-item-tilt',
					   ),

				'group'	=> esc_html__('Grid Settings', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'dropdown',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set appear animation for portfolio items.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Portfolio Items Appearing Animation', 'dpr-adeline-extensions'),

				'param_name' => 'entry_appear_animation',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'value' => array(

								esc_html__('None', 'dpr-adeline-extensions') => 'none',

								esc_html__('Fade', 'dpr-adeline-extensions') => 'fade',

								esc_html__('Fade Up', 'dpr-adeline-extensions') => 'fade-up',

								esc_html__('Fade Down', 'dpr-adeline-extensions') => 'fade-down',

								esc_html__('Fade Left', 'dpr-adeline-extensions') => 'fade-left',

								esc_html__('Fade Right', 'dpr-adeline-extensions') => 'fade-right',

								esc_html__('Fade Up Right', 'dpr-adeline-extensions') => 'fade-up-right',

								esc_html__('Fade Up Left', 'dpr-adeline-extensions') => 'fade-up-left',

								esc_html__('Fade Down Right', 'dpr-adeline-extensions') => 'fade-down-right',

								esc_html__('Fade Down Left', 'dpr-adeline-extensions') => 'fade-down-left',

								esc_html__('Flip Up', 'dpr-adeline-extensions') => 'flip-up',

								esc_html__('Flip Down', 'dpr-adeline-extensions') => 'flip-down',

								esc_html__('Flip Left', 'dpr-adeline-extensions') => 'flip-left',

								esc_html__('Flip Right', 'dpr-adeline-extensions') => 'flip-right',

								esc_html__('Slide Up', 'dpr-adeline-extensions') => 'slide-up',

								esc_html__('Slide Down', 'dpr-adeline-extensions') => 'slide-down',

								esc_html__('Slide Left', 'dpr-adeline-extensions') => 'slide-left',

								esc_html__('Slide Right', 'dpr-adeline-extensions') => 'slide-right',

								esc_html__('Zoom In', 'dpr-adeline-extensions') => 'zoom-in',

								esc_html__('Zoom In Up', 'dpr-adeline-extensions') => 'zoom-in-up',

								esc_html__('Zoom In Down', 'dpr-adeline-extensions') => 'zoom-in-down',

								esc_html__('Zoom In Left', 'dpr-adeline-extensions') => 'zoom-in-left',

								esc_html__('Zoom In Right', 'dpr-adeline-extensions') => 'zoom-in-right',

								esc_html__('Zoom Out', 'dpr-adeline-extensions') => 'zoom-out',

								esc_html__('Zoom Out Up', 'dpr-adeline-extensions') => 'zoom-out-up',

								esc_html__('Zoom Out Down', 'dpr-adeline-extensions') => 'zoom-out-down',

								esc_html__('Zoom Out Left', 'dpr-adeline-extensions') => 'zoom-out-left',

								esc_html__('Zoom Out Right', 'dpr-adeline-extensions') => 'zoom-out-right'

					   ),

				'group'	=> esc_html__('Grid Settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set appear animation duration in miliseconds. If you leave this blank will be used default value 400ms.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Appear Animation Duration', 'dpr-adeline-extensions'),

				'param_name'		=> 'appear_animation_duration',

				'value'				=> 400,

				'suffix'			=> 'ms',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'group'				=> esc_html__('Grid Settings', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'entry_appear_animation', 'value_not_equal_to' => 'none'),

			),

			array(

				'type' => 'dropdown',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set appear animation easing', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Appear Animation Easing', 'dpr-adeline-extensions'),

				'param_name' => 'appear_animation_easing',

				'edit_field_class' => 'vc_column vc_col-sm-4',

				'value' => array(

								esc_html__('Linear', 'dpr-adeline-extensions') => 'linear',

								esc_html__('Ease', 'dpr-adeline-extensions') => 'ease',

								esc_html__('Ease In', 'dpr-adeline-extensions') => 'ease-in',

								esc_html__('Ease Out', 'dpr-adeline-extensions') => 'ease-out',

								esc_html__('Ease In Out', 'dpr-adeline-extensions') => 'ease-in-out',

								esc_html__('Ease In Back', 'dpr-adeline-extensions') => 'ease-in-back',

								esc_html__('Ease In Back', 'dpr-adeline-extensions') => 'ease-out-back',

								esc_html__('Ease In Out Back', 'dpr-adeline-extensions') => 'ease-in-out-back',

								esc_html__('Ease In Sine', 'dpr-adeline-extensions') => 'ease-in-sine',

								esc_html__('Ease Out Sine', 'dpr-adeline-extensions') => 'ease-out-sine',

								esc_html__('Ease In Out Sine', 'dpr-adeline-extensions') => 'ease-in-out-sine',

								esc_html__('Ease In Quad', 'dpr-adeline-extensions') => 'ease-in-quad',

								esc_html__('Ease Out Quad', 'dpr-adeline-extensions') => 'ease-out-quad',

								esc_html__('Ease In Out Quad', 'dpr-adeline-extensions') => 'ease-in-out-quad',

								esc_html__('Ease In Cubic', 'dpr-adeline-extensions') => 'ease-in-cubic',

								esc_html__('Ease Out Cubic', 'dpr-adeline-extensions') => 'ease-out-cubic',

								esc_html__('Ease In Out Cubic', 'dpr-adeline-extensions') => 'ease-in-out-cubic',

								esc_html__('Ease In Quart', 'dpr-adeline-extensions') => 'ease-in-quart',

								esc_html__('Ease Out Quart', 'dpr-adeline-extensions') => 'ease-out-quart',

								esc_html__('Ease In Out Quart', 'dpr-adeline-extensions') => 'ease-in-out-quart',

					   ),

				'group'	=> esc_html__('Grid Settings', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'entry_appear_animation', 'value_not_equal_to' => 'none'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set appear animation delay in miliseconds. If you leave this blank snimstion will be not delayed.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Appear Animation Delay', 'dpr-adeline-extensions'),

				'param_name'		=> 'appear_animation_delay',

				'suffix'			=> 'ms',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'group'				=> esc_html__('Grid Settings', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'entry_appear_animation', 'value_not_equal_to' => 'none'),

			),

			array (

				'type' => 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set image overlay style.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Image Overlay Type', 'dpr-adeline-extensions'),

				'param_name' => 'entry_overlay_type',

				'value' => 'solid',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

				'options' => array (

					esc_attr__('Solid Color', 'dpr-adeline-extensions') => 'solid',

					esc_attr__('Gradient', 'dpr-adeline-extensions') => 'gradient'

				),

				'group'	=> esc_html__('Overlay', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose image overlay color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Image Overlay Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'overlay_color',

				'value' => 'rgba(0,0,0,0.4)',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 no-padding-top',

				'group'	=> esc_html__('Overlay', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'entry_overlay_type', 'value' => 'solid'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set overlay spacing if you wish make overlay smaller as image.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Overlay spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'overlay_spacing',

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 no-padding-top',

				'group'	=> esc_html__('Overlay', 'dpr-adeline-extensions'),

			),

			array(

			'type'            	=> 'dpr_title',

			'class'			  	=> 'separator',

			'text'            	=> '',

			'param_name'       	=> 'grid_sep_2',

			'edit_field_class' 	=> 'vc_column vc_col-sm-12',

			'group'	=> esc_html__('Overlay', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'dpr_gradient_picker',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the gradient background for button. Solid color set above will be ignored', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Gradient background', 'dpr-adeline-extensions'),

				'param_name' => 'overlay_gradient',

				'value' => '45;0%/rgba(75, 50, 255, 0.5);100%/rgba(13, 193, 255, 0.5)',

				'group'	=> esc_html__('Overlay', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'entry_overlay_type', 'value' => 'gradient'),

			),

			array(

			'type'            	=> 'dpr_title',

			'class'			  	=> 'small',

			'text'            	=> esc_html__( 'Overlay Icons Settings', 'dpr-adeline-extensions' ),

			'param_name'       	=> 'overlay_title_3',

			'edit_field_class' 	=> 'vc_column vc_col-sm-12',

			'group'	=> esc_html__('Overlay', 'dpr-adeline-extensions'),	

			),

			array (

				'type' => 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set image overlay icons style.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Overlay Icons Style', 'dpr-adeline-extensions'),

				'param_name' => 'overlay_icons_style',

				'value' => 'icons',

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'options' => array (

					esc_attr__('No Icons', 'dpr-adeline-extensions') => 'none',

					esc_attr__('Icons', 'dpr-adeline-extensions') => 'icons',

					esc_attr__('Plus sign', 'dpr-adeline-extensions') => 'plus'

				),

				'group'	=> esc_html__('Overlay', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set overlay icons size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Overlay icons size', 'dpr-adeline-extensions'),

				'param_name'		=> 'overlay_icons_size',

				'value' => 45,

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'group'	=> esc_html__('Overlay', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'overlay_icons_style', 'value' => 'icons'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set overlay icons font size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Overlay icons font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'overlay_icons_font_size',

				'value' => 16,

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'group'	=> esc_html__('Overlay', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'overlay_icons_style', 'value' => 'icons'),

			),

			array (

				'type' => 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set image overlay link icon type.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Link Icon', 'dpr-adeline-extensions'),

				'param_name' => 'link_icon_type',

				'value' => 'theme-default',

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'options' => array (

					esc_attr__('None', 'dpr-adeline-extensions') => 'none',			

					esc_attr__('Theme Default', 'dpr-adeline-extensions') => 'theme-default',

					esc_attr__('Custom', 'dpr-adeline-extensions') => 'custom'

				),

				'group'	=> esc_html__('Overlay', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'overlay_icons_style', 'value' => 'icons'),

			),

			array(

				'type' => 'dropdown',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select icon library for link icon .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom Link Icon Library ', 'dpr-adeline-extensions'),

				'value' => array(

					__( 'Font Awesome', 'dpr-adeline-extensions' ) => 'fontawesome',

					__( 'Open Iconic', 'dpr-adeline-extensions' ) => 'openiconic',

					__( 'Typicons', 'dpr-adeline-extensions' ) => 'typicons',

					__( 'Entypo', 'dpr-adeline-extensions' ) => 'entypo',

					__( 'Linecons', 'dpr-adeline-extensions' ) => 'linecons'

				),

				'param_name' => 'link_icon_lib',

				'description' => __( 'Select icon library.', 'dpr-adeline-extensions' ),

				'dependency' => array(

					'element' => 'link_icon_type',

					'value' => 'custom',

				),

				'group'	=> esc_html__('Overlay', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'iconpicker',

				'heading' => __( 'Icon', 'dpr-adeline-extensions' ),

				'param_name' => 'link_icon_fontawesome',

				'value' => 'fa fa-external-link',

				'settings' => array(

					'emptyIcon' => false,

					// default true, display an "EMPTY" icon?

					'iconsPerPage' => 4000,

					// default 100, how many icons per/page to display

				),

				'dependency' => array(

					'element' => 'link_icon_lib',

					'value' => 'fontawesome',

				),

				'description' => __( 'Select icon from library.', 'dpr-adeline-extensions' ),

				'group'	=> esc_html__('Overlay', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'iconpicker',

				'heading' => __( 'Icon', 'dpr-adeline-extensions' ),

				'param_name' => 'link_icon_openiconic',

				'value' => 'vc-oi vc-oi-link',

				'settings' => array(

					'emptyIcon' => false,

					// default true, display an "EMPTY" icon?

					'type' => 'openiconic',

					'iconsPerPage' => 4000,

					// default 100, how many icons per/page to display

				),

				'dependency' => array(

					'element' => 'link_icon_lib',

					'value' => 'openiconic',

				),

				'description' => __( 'Select icon from library.', 'dpr-adeline-extensions' ),

				'group'	=> esc_html__('Overlay', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'iconpicker',

				'heading' => __( 'Icon', 'dpr-adeline-extensions' ),

				'param_name' => 'link_icon_typicons',

				'value' => 'typcn typcn-link',

				'settings' => array(

					'emptyIcon' => false,

					// default true, display an "EMPTY" icon?

					'type' => 'typicons',

					'iconsPerPage' => 4000,

					// default 100, how many icons per/page to display

				),

				'dependency' => array(

					'element' => 'link_icon_lib',

					'value' => 'typicons',

				),

				'description' => __( 'Select icon from library.', 'dpr-adeline-extensions' ),

				'group'	=> esc_html__('Overlay', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'iconpicker',

				'heading' => __( 'Icon', 'dpr-adeline-extensions' ),

				'param_name' => 'link_icon_entypo',

				'value' => 'entypo-icon entypo-icon-link',

				'settings' => array(

					'emptyIcon' => false,

					// default true, display an "EMPTY" icon?

					'type' => 'entypo',

					'iconsPerPage' => 4000,

					// default 100, how many icons per/page to display

				),

				'dependency' => array(

					'element' => 'link_icon_lib',

					'value' => 'entypo',

				),

				'group'	=> esc_html__('Overlay', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'iconpicker',

				'heading' => __( 'Icon', 'dpr-adeline-extensions' ),

				'param_name' => 'link_icon_linecons',

				'value' => 'vc_li vc_li-clip',

				'settings' => array(

					'emptyIcon' => false,

					// default true, display an "EMPTY" icon?

					'type' => 'linecons',

					'iconsPerPage' => 4000,

					// default 100, how many icons per/page to display

				),

				'dependency' => array(

					'element' => 'link_icon_lib',

					'value' => 'linecons',

				),

				'description' => __( 'Select icon from library.', 'dpr-adeline-extensions' ),

				'group'	=> esc_html__('Overlay', 'dpr-adeline-extensions'),

			),

			array (

				'type' => 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set image overlay zoom icon type.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Zoom Icon', 'dpr-adeline-extensions'),

				'param_name' => 'zoom_icon_type',

				'value' => 'theme-default',

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'options' => array (

					esc_attr__('None', 'dpr-adeline-extensions') => 'none',			

					esc_attr__('Theme Default', 'dpr-adeline-extensions') => 'theme-default',

					esc_attr__('Custom', 'dpr-adeline-extensions') => 'custom'

				),

				'group'	=> esc_html__('Overlay', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'overlay_icons_style', 'value' => 'icons'),

			),

			array(

				'type' => 'dropdown',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select icon library for zoom icon .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom Zoom Icon Library ', 'dpr-adeline-extensions'),

				'value' => array(

					__( 'Font Awesome', 'dpr-adeline-extensions' ) => 'fontawesome',

					__( 'Open Iconic', 'dpr-adeline-extensions' ) => 'openiconic',

					__( 'Typicons', 'dpr-adeline-extensions' ) => 'typicons',

					__( 'Entypo', 'dpr-adeline-extensions' ) => 'entypo',

					__( 'Linecons', 'dpr-adeline-extensions' ) => 'linecons'

				),

				'param_name' => 'zoom_icon_lib',

				'description' => __( 'Select icon library.', 'dpr-adeline-extensions' ),

				'dependency' => array(

					'element' => 'zoom_icon_type',

					'value' => 'custom',

				),

				'group'	=> esc_html__('Overlay', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'iconpicker',

				'heading' => __( 'Icon', 'dpr-adeline-extensions' ),

				'param_name' => 'zoom_icon_fontawesome',

				'value' => 'fa fa-search-plus',

				'settings' => array(

					'emptyIcon' => false,

					// default true, display an "EMPTY" icon?

					'iconsPerPage' => 4000,

					// default 100, how many icons per/page to display

				),

				'dependency' => array(

					'element' => 'zoom_icon_lib',

					'value' => 'fontawesome',

				),

				'description' => __( 'Select icon from library.', 'dpr-adeline-extensions' ),

				'group'	=> esc_html__('Overlay', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'iconpicker',

				'heading' => __( 'Icon', 'dpr-adeline-extensions' ),

				'param_name' => 'zoom_icon_openiconic',

				'value' => 'vc-oi vc-oi-resize-full',

				'settings' => array(

					'emptyIcon' => false,

					// default true, display an "EMPTY" icon?

					'type' => 'openiconic',

					'iconsPerPage' => 4000,

					// default 100, how many icons per/page to display

				),

				'dependency' => array(

					'element' => 'zoom_icon_lib',

					'value' => 'openiconic',

				),

				'description' => __( 'Select icon from library.', 'dpr-adeline-extensions' ),

				'group'	=> esc_html__('Overlay', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'iconpicker',

				'heading' => __( 'Icon', 'dpr-adeline-extensions' ),

				'param_name' => 'zoom_icon_typicons',

				'value' => 'typcn typcn-arrow-maximise',

				'settings' => array(

					'emptyIcon' => false,

					// default true, display an "EMPTY" icon?

					'type' => 'typicons',

					'iconsPerPage' => 4000,

					// default 100, how many icons per/page to display

				),

				'dependency' => array(

					'element' => 'zoom_icon_lib',

					'value' => 'typicons',

				),

				'description' => __( 'Select icon from library.', 'dpr-adeline-extensions' ),

				'group'	=> esc_html__('Overlay', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'iconpicker',

				'heading' => __( 'Icon', 'dpr-adeline-extensions' ),

				'param_name' => 'zoom_icon_entypo',

				'value' => 'entypo-icon entypo-icon-resize-full',

				'settings' => array(

					'emptyIcon' => false,

					// default true, display an "EMPTY" icon?

					'type' => 'entypo',

					'iconsPerPage' => 4000,

					// default 100, how many icons per/page to display

				),

				'dependency' => array(

					'element' => 'zoom_icon_lib',

					'value' => 'entypo',

				),

				'group'	=> esc_html__('Overlay', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'iconpicker',

				'heading' => __( 'Icon', 'dpr-adeline-extensions' ),

				'param_name' => 'zoom_icon_linecons',

				'value' => 'vc_li vc_li-search',

				'settings' => array(

					'emptyIcon' => false,

					// default true, display an "EMPTY" icon?

					'type' => 'linecons',

					'iconsPerPage' => 4000,

					// default 100, how many icons per/page to display

				),

				'dependency' => array(

					'element' => 'zoom_icon_lib',

					'value' => 'linecons',

				),

				'description' => __( 'Select icon from library.', 'dpr-adeline-extensions' ),

				'group'	=> esc_html__('Overlay', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose overlay icons color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icons Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'overlay_icons_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'group'	=> esc_html__('Overlay', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'overlay_icons_style', 'value' => 'icons'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose overlay icons background color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icons Background', 'dpr-adeline-extensions'),

				'param_name'		=> 'overlay_icons_bg',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'group'	=> esc_html__('Overlay', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'overlay_icons_style', 'value' => 'icons'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose overlay icons border color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icons Border', 'dpr-adeline-extensions'),

				'param_name'		=> 'overlay_icons_border',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'group'	=> esc_html__('Overlay', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'overlay_icons_style', 'value' => 'icons'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose overlay icons hover color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icons Color: Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'overlay_icons_color_hover',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'group'	=> esc_html__('Overlay', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'overlay_icons_style', 'value' => 'icons'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose overlay icons background hover color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icons Background: Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'overlay_icons_bg_hover',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'group'	=> esc_html__('Overlay', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'overlay_icons_style', 'value' => 'icons'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose overlay icons border hover color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icons Border: Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'overlay_icons_border_hover',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'group'	=> esc_html__('Overlay', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'overlay_icons_style', 'value' => 'icons'),

			),

			array (

				'type' => 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose where to link the plus sign.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Plus Sign Link', 'dpr-adeline-extensions'),

				'param_name' => 'plus_link',

				'value' => 'lightbox',

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'options' => array (

					esc_attr__('Lightbox', 'dpr-adeline-extensions') => 'lightbox',

					esc_attr__('Portfolio Item', 'dpr-adeline-extensions') => 'item',

				),

				'group'	=> esc_html__('Overlay', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'overlay_icons_style', 'value' => 'plus'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set plus sign size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Plus sign size', 'dpr-adeline-extensions'),

				'param_name'		=> 'plus_size',

				'value' => 45,

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'group'	=> esc_html__('Overlay', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'overlay_icons_style', 'value' => 'plus'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose plus sign color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Plus Sign Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'plus_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'value'  => 'rgba(255,255,255,0.8)',

				'group'	=> esc_html__('Overlay', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'overlay_icons_style', 'value' => 'plus'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose plus sign hover color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Plus Sign Color: Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'plus_color_hover',

				'value'  => 'rgba(255,255,255,1)',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'group'	=> esc_html__('Overlay', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'overlay_icons_style', 'value' => 'plus'),

			),

			array(

			'type'            	=> 'dpr_title',

			'class'			  	=> 'small',

			'text'            	=> esc_html__( 'Overlay Content Settings', 'dpr-adeline-extensions' ),

			'param_name'       	=> 'overlay_title_4',

			'edit_field_class' 	=> 'vc_column vc_col-sm-12',

			'group'	=> esc_html__('Overlay', 'dpr-adeline-extensions'),	

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose overlay title color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Overlay Title Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'overlay_title_color',

				'value'  => '#ffffff',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'	=> esc_html__('Overlay', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose overlay title hover color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Overlay Title Color: Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'overlay_title_color_hover',

				'value'  => '#ffffff',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'	=> esc_html__('Overlay', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose overlay category color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Overlay Category Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'overlay_category_color',

				'value'  => '#ffffff',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'	=> esc_html__('Overlay', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose overlay category hover color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Overlay Category Color: Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'overlay_category_color_hover',

				'value'  => '#ffffff',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'	=> esc_html__('Overlay', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'dpr_switcher',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('This option allows you to enable filter for this grid.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Enable Filter', 'dpr-adeline-extensions'),

				'param_name' => 'enable_filter',

				'edit_field_class' => 'vc_column vc_col-sm-12 no-padding-top',

				'value' => '',

				'options' => array(

					'yes' => array(

							'label' => '',

							'on' => 'Yes',

							'off' => 'No',

						),

					),

				'group'				=> esc_html__('Filter', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'dpr_switcher',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('This option allows you to enable ALL button in filter for this grid.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Enable All Button', 'dpr-adeline-extensions'),

				'param_name' => 'enable_all',

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'value' => '',

				'options' => array(

					'yes' => array(

							'label' => '',

							'on' => 'Yes',

							'off' => 'No',

						),

					),

				'group'				=> esc_html__('Filter', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'enable_filter', 'value' => 'yes'),

			),

		    array(

				'type' => 'textfield',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set text for all button.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('All button text', 'dpr-adeline-extensions'),

				'param_name' => 'all_text',

				'value' => 'All',

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Filter', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'enable_all', 'value' => 'yes'),

			),

			array(

				'type'             => 'dpr_title',

				'class' => 'separator',

				'text'             => '',

				'param_name'       => 'filer_sep_1',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group'				=> esc_html__('Filter', 'dpr-adeline-extensions'),

			),

			array (

				'type' => 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set filter position.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Filter Position', 'dpr-adeline-extensions'),

				'param_name' => 'filter_position',

				'value' => 'center',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options' => array (

					esc_attr__('Left', 'dpr-adeline-extensions') => 'left',			

					esc_attr__('Center', 'dpr-adeline-extensions') => 'center',

					esc_attr__('Right', 'dpr-adeline-extensions') => 'right',

					esc_attr__('Full', 'dpr-adeline-extensions') => 'full',

				),

				'group'				=> esc_html__('Filter', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'enable_filter', 'value' => 'yes'),

			),

			array (

				'type' => 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set filter taxonomy (categories or tags).', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Filter Taxonomy', 'dpr-adeline-extensions'),

				'param_name' => 'filter_taxonomy',

				'value' => 'categories',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options' => array (

					esc_attr__('Categories', 'dpr-adeline-extensions') => 'categories',			

					esc_attr__('Tags', 'dpr-adeline-extensions') => 'tags',

				),

				'group'				=> esc_html__('Filter', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'enable_filter', 'value' => 'yes'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set filter bar bottom margin.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Filter Bar bottom margin', 'dpr-adeline-extensions'),

				'param_name'		=> 'filter_bar_margin',

				'value' => 25,

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Filter', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'enable_filter', 'value' => 'yes'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set filter buttons spacing.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Filter Buttons Spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'filter_buttons_spacing',

				'value' => 5,

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Filter', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'enable_filter', 'value' => 'yes'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set filter buttons top and bottom padding.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Filter Buttons Top/Bottom Padding', 'dpr-adeline-extensions'),

				'param_name'		=> 'filter_buttons_vertical_padding',

				'value' => 8,

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Filter', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'enable_filter', 'value' => 'yes'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set filter buttons left and right padding.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Filter Buttons Left/Right Padding', 'dpr-adeline-extensions'),

				'param_name'		=> 'filter_buttons_horizontal_padding',

				'value' => 12,

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Filter', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'enable_filter', 'value' => 'yes'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set filter buttons border radius.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Filter Buttons Border Radius', 'dpr-adeline-extensions'),

				'param_name'		=> 'filter_buttons_border_radius',

				'value' => 5,

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Filter', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'enable_filter', 'value' => 'yes'),

			),

			array(

				'type'             => 'dpr_title',

				'class' => 'separator',

				'text'             => '',

				'param_name'       => 'filer_sep_2',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group'				=> esc_html__('Filter', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose filter buttons background color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Buttons Background', 'dpr-adeline-extensions'),

				'param_name'		=> 'filter_buttons_bg_color',

				'value'  => '#f1f2f4',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Filter', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'enable_filter', 'value' => 'yes'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose filter buttons background hover color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Buttons Background: Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'filter_buttons_bg_color_hover',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'value'  => '#D3AE5F',

				'group'				=> esc_html__('Filter', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'enable_filter', 'value' => 'yes'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose filter buttons text color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Buttons Text Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'filter_buttons_color',

				'value'  => '#292933',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Filter', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'enable_filter', 'value' => 'yes'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose filter buttons text hover color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Buttons Text Color: Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'filter_buttons_color_hover',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'value'  => '#ffffff',

				'group'				=> esc_html__('Filter', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'enable_filter', 'value' => 'yes'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose filter buttons border color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Buttons Border Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'filter_border_color',

				'value'  => '#f1f2f4',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Filter', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'enable_filter', 'value' => 'yes'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose filter buttons border hover color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Buttons Border Color: Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'filter_border_color_hover',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'value'  => '#D3AE5F',

				'group'				=> esc_html__('Filter', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'enable_filter', 'value' => 'yes'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Tilte Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_typography_head',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size. If you leave this field blank will be used default size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title linne height.Default is 18px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'title_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

	  		),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font. .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_use_google_fonts',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'title_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'dependency'		=> array('element' => 'title_use_google_fonts', 'value' => 'yes'),

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),



			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Category Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'category_typography_head',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size. If you leave this field blank will be used default size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'category_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom category linne height.Default is 18px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'category_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom category letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'category_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'category_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

	  		),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font. .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'category_use_google_fonts',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'category_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'dependency'		=> array('element' => 'category_use_google_fonts', 'value' => 'yes'),

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Filter Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'filter_typography_head',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size. If you leave this field blank will be used default size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'filter_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom filter line height.Default is 18px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'filter_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom filter letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'filter_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'filter_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

	  		),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font. .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'filter_use_google_fonts',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'filter_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'dependency'		=> array('element' => 'filter_use_google_fonts', 'value' => 'yes'),

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),













			

			

		),

	)

);