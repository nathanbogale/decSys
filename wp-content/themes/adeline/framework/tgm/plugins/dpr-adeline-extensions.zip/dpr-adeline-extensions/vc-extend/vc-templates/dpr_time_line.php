<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$el_class = $output = $custom_el_css = $timeline_style = $timeline_size = $timeline_color = '';


$atts = vc_map_get_attributes( 'dpr_time_line', $atts );
extract( $atts );

$unique_id = uniqid('dpr-timeline');

/* Custom CSS */
if(isset($timeline_style) && !empty($timeline_style)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .central-line {border-right-style: '.esc_attr($timeline_style).';}';
}
if(isset($timeline_size) && !empty($timeline_size)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .central-line {border-right-width: '.esc_attr($timeline_size).'px;}';
}
if(isset($timeline_color) && !empty($timeline_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .central-line {border-right-color: '.esc_attr($timeline_color).';}';
}




$output .= '<div id="'.esc_attr($unique_id).'" class="dpr-timeline '.$el_class.' '.esc_attr($unique_id).'">';
	$output .= '<div class="central-line"></div>';
	$output .= do_shortcode($content);

if(!empty($custom_el_css)) {
		$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>");'
						. '})(jQuery);'
					. '</script>';
}
$output .= '</div>';

echo $output;