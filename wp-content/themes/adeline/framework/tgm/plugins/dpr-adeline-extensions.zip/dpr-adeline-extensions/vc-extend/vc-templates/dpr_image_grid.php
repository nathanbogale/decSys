<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$unique_id = $css_animation = $el_class = $column_class = $massonry_wrapper_class = $output = $custom_el_css = $hover_style = $grid_style = '';
$items_offset = $use_borders = $border_color = $columns = '';
$back_side_bg = $opacity_idle = $opacity_hover = $thumb_radius = '';
$overlay_style = $overlay_background = $overlay_gradient = $overlay_class = '';
$title_color = $title_font_size = $title_line_height  = $title_letter_spacing = $title_font_style = $title_google_font = $title_typo_style = '';
$image_list = '';

$atts = vc_map_get_attributes( 'dpr_image_grid', $atts );
extract( $atts );

$el_class = $this->getExtraClass( $el_class );
if ( '' !== $css_animation && 'none' !== $css_animation ) {
	dpr_enqueue_waypoint_js();
	dpr_enqueue_animate_css();
	$el_class .= ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
}
$unique_id = uniqid('dpr-image-grid-').'-'.rand(1,9999);

if(isset($hover_style)) {
	if($hover_style == 'grayscale_opacity') {
		$el_class .= ' style-opacity style-grayscale';
	} else {
		$el_class .= ' style-'.$hover_style;
	}
}

if(isset($use_borders) && $use_borders == 'yes') {
	$el_class .= ' with-borders';
}

$css_classes = array(
	'dpr-carousel-wrap dpr-image-carousel-wrap grid-mode',
	$unique_id,
	$el_class,
);

$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->settings['base'], $atts ) );

if ($hover_style == 'overlay') {
	$overlay_class = ' overlay';	
}

if (isset($columns) && $columns != '') {
	$column_class = 'columns-'.$columns;
}

if (isset($grid_style) && $grid_style == 'masonry') {
	$column_class .= ' isotope-entry';
	$massonry_wrapper_class .= ' blog-masonry-grid';
}

if($items_offset != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .dpr-image-carousel-item {padding: '.esc_js($items_offset/2).'px;}';
}



if(isset($thumb_radius) && $thumb_radius != '') {
	$custom_el_css .=	'.'.esc_js($unique_id).' .dpr-image-carousel-item .img-wrap {border-radius: '.esc_js($thumb_radius).'px}';
}
if(isset($back_side_bg) && $back_side_bg != '') {
	$custom_el_css .=	'.'.esc_js($unique_id).' .dpr-image-carousel-item .img-wrap .img-wrap-back {background-color: '.esc_js($back_side_bg).'}';
}

if(isset($opacity_idle) && $opacity_idle != '') {
	$custom_el_css .=	'.'.esc_js($unique_id).'.style-opacity .dpr-image-carousel-item .img-wrap {opacity: '.esc_js($opacity_idle/100).'}';
}

if(isset($opacity_hover) && $opacity_hover != '') {
	$custom_el_css .=	'.'.esc_js($unique_id).'.style-opacity .dpr-image-carousel-item .img-wrap:hover {opacity: '.esc_js($opacity_hover/100).'}';
}

if(isset($border_color) && $border_color != '') {
	$custom_el_css .= '.'.esc_js($unique_id).'.grid-mode.with-borders .dpr-image-carousel-item{	-webkit-box-shadow: -1px -1px 0px 0px '.$border_color.';-moz-box-shadow: -1px -1px 0px 0px '.$border_color.';box-shadow: -1px -1px 0px 0px '.$border_color.';}';
	$custom_el_css .= '.'.esc_js($unique_id).'.grid-mode.with-borders .dpr-image-carousel-item.no-left-border{	-webkit-box-shadow: 0px -1px 0px 0px '.$border_color.';-moz-box-shadow: 0px -1px 0px 0px '.$border_color.';box-shadow: 0px -1px 0px 0px '.$border_color.';}';
	$custom_el_css .= '.'.esc_js($unique_id).'.grid-mode.with-borders .dpr-image-carousel-item.no-top-border{	-webkit-box-shadow: -1px 0px 0px 0px '.$border_color.';-moz-box-shadow: -1px 0px 0px 0px '.$border_color.';box-shadow: -1px 0px 0px 0px '.$border_color.';}';
}

if(isset($overlay_style) && $overlay_style == 'solid' && $overlay_background != '' ) {
	$custom_el_css .=	'.'.esc_js($unique_id).' .covering-link.overlay {background-color: '.esc_js($overlay_background).'}';
}
if(isset($overlay_style) && $overlay_style == 'gradient' && $overlay_gradient != '' ) {
	$custom_el_css .= '.'.esc_js($unique_id).' .covering-link.overlay{'.esc_js(adeline_gradientToBgCSS ($overlay_gradient)).';}';
}




$back_typo_style = dpr_generate_typography_style($title_color, $title_font_size, $title_line_height, $title_letter_spacing, $title_font_style,$title_google_font);


$output .= '<div id="'.esc_attr($unique_id).'" class="'.esc_attr($css_class).'">';
	$output .= '<div class="dpr-carousel-wrap-inner'.$massonry_wrapper_class.'">';
			
			if(isset($image_list) && !empty($image_list) && function_exists('vc_param_group_parse_atts')) {
				$image_list = (array) vc_param_group_parse_atts($image_list);
				
				$n  = 0;
				
				foreach($image_list as $item) {
					$image_url = $img_src = $img_html = $sec_image_url = $sec_img_src = $sec_img_html = $back_html = $link = $link_title = $link_rel = $link_target = $link_html = $custom_back_style = $column_border_class  ='';
					
					if(isset($item['image_id']) && !empty($item['image_id'])) {
						
						if(isset($item['description']) && !empty($item['description'])){
								$back_html = '<span class="back-text"><span class="back-text-inner" '.$back_typo_style.'>'.esc_html($item['description']).'</span></span>';
						}
						
						$image = dpr_get_attachment_image_src($item['image_id'], 'full');
						if ($image[0] != '') {
							$image_src = $image[0];
						} else {
							$image_src = adeline_no_image_url();
						}
						$alt_text = get_post_meta($item['image_id'] , '_wp_attachment_image_alt', true);
						$img_html .= '<img src="'.esc_url($image[0]).'" alt ="'.esc_attr($alt_text).'"/>';
						
						if(isset($item['secondary_image_id']) && !empty($item['secondary_image_id'])) {
							$sec_image = dpr_get_attachment_image_src($item['secondary_image_id'], 'full');
							if ($sec_image[0] != '') {
							$sec_image_src = $sec_image[0];
							} else {
								$sec_image_src = adeline_no_image_url();
							}
							$sec_alt_text = get_post_meta($item['secondary_image_id'] , '_wp_attachment_image_alt', true);
							$sec_img_html .= '<img class="hover-image" src="'.esc_url($sec_image_src).'" alt ="'.esc_attr($sec_alt_text).'"/>';
						}
						if(isset($item['use_link']) && $item['use_link'] == 'custom' && isset($item['link'])) {
							$link = vc_build_link($item['link']);
							$link_title = !empty($link['title']) ? 'title="'.esc_attr($link['title']).'"' : '';
							$link_rel = !empty($link['rel']) ? 'rel="'.esc_attr($link['rel']).'"' : '';
							$link_target = !empty($link['target']) ? 'target="'.esc_attr(preg_replace('/\s+/', '', $link['target'])).'"' : '';
							$link_html .= '<a href="'.esc_url($link['url']).'" class="covering-link'.$overlay_class.'" '.$link_title.' '.$link_target.' '.$link_rel.'></a>';
						} elseif (isset($item['use_link']) && $item['use_link'] == 'ligthbox') {
    						$link_html .= '<a href="'.esc_url($image_src).'" data-rel="lightcase:'.$unique_id.'" class="covering-link'.$overlay_class.'"></a>';
						} else {
							if($hover_style == 'overlay') {
								$link_html .= '<span class="covering-link'.$overlay_class.'"></a>';
							}
						}
						
						if(isset($item['custom_back_bg']) && $item['custom_back_bg'] == 'yes' && isset($item['custom_back_bg_color']) && $item['custom_back_bg_color'] != '') {
							$custom_back_style = ' style = "background-color:'.$item['custom_back_bg_color'].'"';
						}
						if ($n <= ($columns-1)) {
							$column_border_class .= ' no-top-border'; 	
						}
						if ($n/$columns == round($n/$columns)) {
							$column_border_class .= ' no-left-border';
						}
						$output .= '<div class="dpr-image-carousel-item '.$column_class.$column_border_class.'">';
							$output .= '<div class="img-wrap">';
								switch ( $hover_style ) {
										case 'opacity';
											$output .= $img_html;
										break;
										case 'grayscale';
											$output .= $img_html;
										break;
										case 'grayscale_opacity';
											$output .= $img_html;
										break;
										case 'secondary_image';
											$output .= $img_html;
											$output .= $sec_img_html;
										break;
										case 'flip';
											$output .= '<div class="img-wrap-front">';
												$output .= $img_html;
											$output .= '</div>';
											$output .= '<div class="img-wrap-back"'.$custom_back_style.'>';
												$output .= '<div class="content-wrap">'; 
													$output .= $back_html;
												$output .= '</div>'; 
											$output .= '</div>';
										break;
										case 'overlay';
											$output .= $img_html;
										break;
										

								}
								$output .= $link_html;
							$output .= '</div>';
							
						$output .=  '</div>';
						$n += 1;
					}
				}
			}
		
	$output .= '</div>';


if(!empty($custom_el_css)) {
		$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>");'
						. '})(jQuery);'
					. '</script>';
}
$output .= '</div>';

echo $output;