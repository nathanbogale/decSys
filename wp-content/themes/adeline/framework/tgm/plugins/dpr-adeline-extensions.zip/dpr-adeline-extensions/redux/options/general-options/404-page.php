<?php



/**



 * General Options -> 404 Page



 * 



 */







	Redux::setSection( $opt_name, array(



		'title' => esc_html__('404 Error Page', 'dpr-adeline-extensions'),



		'id' => 'general_404_page',



		'subsection' => true,



		'fields' => array(



					array(



						'id'       => 'error_page_blank',



						'type'     => 'switch',



						'title'    =>  esc_html__('Blank Page','dpr-adeline-extensions'),



						'default' => false,



						'hint' => array(



							'title'   => esc_attr__('Blank Page','dpr-adeline-extensions'),



							'content' => esc_attr__('Enable this option to remove all default elements (header, footer, etc) from error page.','dpr-adeline-extensions')



						)



					),



					array(



						'id'       => 'error_page_template',



						'type'     => 'radio',



						'title'    => __('Error Page Content', 'dpr-adeline-extensions'), 



						'options'  => array(



							'default' => 'Default Template', 



							'custom' => 'Custom Template'



						),



						'default' => 'default',



						'hint' => array(



							'title'   => esc_attr__('Error Page Content','dpr-adeline-extensions'),



							'content' => esc_attr__('You can use default error page template and content entered bellow or select custom error page template created in menu Particles','dpr-adeline-extensions')



						),







					),



					array(



						'id' => 'error_page_particle_selected',



						'type'     => 'select',



						'data'     => 'posts',



						'args' => array('post_type' => array('dpr_particle'), 'posts_per_page' => -1),



						'title' => esc_html__('Custom Error Page Template', 'dpr-adeline-extensions'),



						'desc' => __('Please note that you need first create custom error page template in Particles menu'),



						'hint' => array(



							'title'   => esc_attr__('Custom error page template','dpr-adeline-extensions'),



							'content' => esc_attr__('','dpr-adeline-extensions')



						),



						'required' =>	array('error_page_template','not','default')



					),



					array(



						'id'       => 'error_page_title',



						'type'     => 'text',



						'title'    => __('Error Page Title', 'dpr-adeline-extensions'),



						'default'  => '404',



						'required' =>	array('error_page_template','equals','default'),



						'hint' => array(



							'title'   => esc_attr__('Error Page Title','dpr-adeline-extensions'),



							'content' =>  esc_attr__('You can change error page title. No HTML allowed.','dpr-adeline-extensions')



						),



					),



					array(



						'id' => 'error_page_title_color',



						'type' => 'color',



						'output' => array('.error404-content .error-title') ,



						'validate' => 'color',



						'title' => esc_html__('Error Page Title Color', 'dpr-adeline-extensions'),



						'default' => '#292933',



						'hint' => array(



							'title'   => esc_attr__('Error Page Ttitle Color','dpr-adeline-extensions'),



							'content' => esc_attr__('Set error page title color.','dpr-adeline-extensions')



						),



						'required' =>	array('error_page_template','equals','default')



					),



					array(



						'id'=>'error_page_text',



						'type' => 'textarea',



						'title' => __('Error Page Text', 'dpr-adeline-extensions'), 



						'validate' => 'html_custom',



						'default' => 'We are sorry. But the page you are looking for is not available.<br />Perhaps you can try a new searching.',



						'allowed_html' => array(



							'a' => array(



								'href' => array(),



								'title' => array()



							),



							'br' => array(),



							'em' => array(),



							'strong' => array()



						),



						'hint' => array(



							'title'   => esc_attr__('Error Page Text','dpr-adeline-extensions'),



							'content' => esc_attr__('You can change error page text. Custom HTML is allowed','dpr-adeline-extensions')



						),



						'required' =>	array('error_page_template','equals','default')



					),



					array(



						'id' => 'error_page_text_color',



						'type' => 'color',



						'output' => array('.error404-content .error-text') ,



						'validate' => 'color',



						'title' => esc_html__('Error Page Text color', 'dpr-adeline-extensions'),



						'default' => '#292933',



						'hint' => array(



							'title'   => esc_attr__('Error Page Text Color','dpr-adeline-extensions'),



							'content' => esc_attr__('Set error page text color.','dpr-adeline-extensions')



						),



						'required' =>	array('error_page_template','equals','default')



					),



					



					array(         



						'id'       => 'error_page_bg',



						'type'     => 'background',



						'title'    => __('Error Page Background', 'dpr-adeline-extensions'),



						'output' => array('.error404 #main'),



						'default'  => array(



							'background-color' => '#ffffff',



							'background-size' => 'cover'



						),



						'hint' => array(



							'title'   => esc_attr__('Error Page Background','dpr-adeline-extensions'),



							'content' => esc_attr__('You can set custom error page background','dpr-adeline-extensions')



						)



						),







	)



	));