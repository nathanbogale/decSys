<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$output = $shortcode_output = $custom_el_css = $el_class  = $css_animation =  '';
$filter_bar_margin = $filter_buttons_margin = $filter_buttons_padding = $filter_buttons_border_radius = $filter_buttons_bg = $filter_buttons_bg_hover = '';
$filter_buttons_text = $filter_buttons_text_hover = $filter_buttons_border = $filter_buttons_border_hover = '';
$th_bg_color = $th_border_color = $th_color = $th_font_size = $th_line_height = $th_letter_spacing = $th_font_style = $use_th_google_fonts = $th_google_font = $th_typo_css = '';
$tr_bg_color = $tr_border_color = $tr_bg_color_even = $tr_border_color_even = $tr_color = $tr_font_size = $tr_line_height = $tr_letter_spacing = $tr_font_style = $use_tr_google_fonts = $tr_google_font = $tr_typo_css = '';

$atts = vc_map_get_attributes(  $this->getShortcode(), $atts  );
extract( $atts );

$el_class = $this->getExtraClass( $el_class );
if ( '' !== $css_animation && 'none' !== $css_animation ) {
	dpr_enqueue_waypoint_js();
	dpr_enqueue_animate_css();
	$el_class .= ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
}
$unique_id = uniqid('dpr-timetable-').'-'.rand(1,9999);

$css_classes = array(
	'dpr-time-table',
	esc_attr($unique_id),
	$el_class,
);

if ($dropdown_position == 'right') {
	$css_classes[] = 'right-aligned-select';
}
if ($dropdown_width == 'full') {
	$css_classes[] = 'full-width-select';
}
if ($filter_position == 'left') {
	$css_classes[] = 'filter-pos-left';
}
if ($filter_position == 'right') {
	$css_classes[] = 'filter-pos-right';
}
if ($filter_position == 'full') {
	$css_classes[] = 'filter-pos-full';
}

$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->settings['base'], $atts ) );

/* * ************************
 * Styles and custom CSS
 * *********************** 
*/

//Filter
	if(isset($filter_bar_margin) && !empty($filter_bar_margin)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .mptt-shortcode-wrapper .mptt-navigation-tabs {margin-bottom: '.esc_js($filter_bar_margin).'px;}';
	}
	if(isset($filter_buttons_spacing) && !empty($filter_buttons_spacing)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .mptt-shortcode-wrapper .mptt-navigation-tabs li {margin-right: '.esc_js($filter_buttons_spacing).'px;}';
	}
	if(isset($filter_buttons_padding) && !empty($filter_buttons_vertical_padding)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .mptt-shortcode-wrapper .mptt-navigation-tabs li a {padding-top: '.esc_js($filter_buttons_vertical_padding).'px; padding-bottom: '.esc_js($filter_buttons_vertical_padding).'px;}';
	}
	if(isset($filter_buttons_horizontal_padding) && !empty($filter_buttons_horizontal_padding)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .mptt-shortcode-wrapper .mptt-navigation-tabs li a {padding-left: '.esc_js($filter_buttons_horizontal_padding).'px; padding-right: '.esc_js($filter_buttons_horizontal_padding).'px;}';
	}
	if(isset($filter_buttons_border_radius) && !empty($filter_buttons_border_radius)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .mptt-shortcode-wrapper .mptt-navigation-tabs li a {border-radius: '.esc_js($filter_buttons_border_radius).'px;}';
	}
	if(isset($filter_buttons_bg_color) && !empty($filter_buttons_bg_color)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .mptt-shortcode-wrapper .mptt-navigation-tabs li a {background-color: '.esc_js($filter_buttons_bg_color).';}';
	}
	if(isset( $filter_buttons_bg_color_hover) && !empty( $filter_buttons_bg_color_hover)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .mptt-shortcode-wrapper .mptt-navigation-tabs li a:hover, .mptt-shortcode-wrapper .mptt-navigation-tabs li.active a {background-color: '.esc_js( $filter_buttons_bg_color_hover).';}';
	}
	if(isset($filter_buttons_color) && !empty($filter_buttons_color)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .mptt-shortcode-wrapper .mptt-navigation-tabs li a {color: '.esc_js($filter_buttons_color).';}';
	}
	if(isset($filter_buttons_color_hover) && !empty($filter_buttons_color_hover)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .mptt-shortcode-wrapper .mptt-navigation-tabs li a:hover, .mptt-shortcode-wrapper .mptt-navigation-tabs li.active a {color: '.esc_js($filter_buttons_color_hover).';}';
	}
	if(isset($filter_border_color) && !empty($filter_border_color)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .mptt-shortcode-wrapper .mptt-navigation-tabs li a {border-color: '.esc_js($filter_border_color).';}';
	}
	if(isset($filter_border_color_hover) && !empty($filter_border_color_hover)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .mptt-shortcode-wrapper .mptt-navigation-tabs li a:hover, .mptt-shortcode-wrapper .mptt-navigation-tabs li.active a {border-color: '.esc_js($filter_border_color_hover).';}';
	}
// Table
	$th_typo_css = dpr_generate_typography_css($th_color, $th_font_size, $th_line_height, $th_letter_spacing, $th_font_style,$th_google_font);
	if(isset($th_bg_color) && !empty($th_bg_color)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .mptt-shortcode-wrapper .mptt-shortcode-table tr.mptt-shortcode-row th {background-color: '.esc_js($th_bg_color).';'.$th_typo_css.'}';
	}
	if(isset($th_border_color) && !empty($th_border_color)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .mptt-shortcode-wrapper .mptt-shortcode-table tr.mptt-shortcode-row th {border-color: '.esc_js($th_border_color).';}';
	}
	$tr_typo_css = dpr_generate_typography_css($tr_color, $tr_font_size, $tr_line_height, $tr_letter_spacing, $tr_font_style,$tr_google_font);
	if(isset($tr_bg_color) && !empty($tr_bg_color)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .mptt-shortcode-wrapper .mptt-shortcode-table tbody td {background-color: '.esc_js($tr_bg_color).';'.$tr_typo_css.'}';
	}
	if(isset($tr_border_color) && !empty($tr_border_color)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .mptt-shortcode-wrapper .mptt-shortcode-table tbody td {border-color: '.esc_js($tr_border_color).';}';
	}
	if(isset($tr_bg_color_even) && !empty($tr_bg_color_even)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .mptt-shortcode-wrapper .mptt-shortcode-table tbody tr:nth-child(2n+2) td {background-color: '.esc_js($tr_bg_color_even).';}';
	}
	if(isset($tr_border_color_even) && !empty($tr_border_color_even)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .mptt-shortcode-wrapper .mptt-shortcode-table tbody tr:nth-child(2n+2) td {border-color: '.esc_js($tr_border_color_even).';}';
	}

/* * ************************
 * Output
 * *********************** */

$shortcode_output = '[mp-timetable ';
if ( ! empty( $el_id ) ) {
			$shortcode_output .='id="'.$el_id.'" ';
}
if ( ! empty( $columns_include ) ) {
			$shortcode_output .='col="'.$columns_include.'" ';
}
if ( ! empty( $events_include ) ) {
			$shortcode_output .='events="'.$events_include.'" ';
}
if ( ! empty( $categories_include ) ) {
			$shortcode_output .='event_categ="'.$categories_include.'" ';
}
if ( ! empty( $event_timeframe ) ) {
			$shortcode_output .='increment="'.$event_timeframe.'" ';
}
if ($display_title == 'yes') {
		$shortcode_output .='title="1" ';
	} else {
		$shortcode_output .='title="0" ';
}
if ($display_time == 'yes') {
		$shortcode_output .='time="1" ';
	} else {
		$shortcode_output .='time="0" ';
}		
if ($display_subtitle == 'yes') {
		$shortcode_output .='sub-title="1" ';
	} else {
		$shortcode_output .='sub-title="0" ';
}		
if ($display_description == 'yes') {
		$shortcode_output .='description="1" ';
	} else {
		$shortcode_output .='description="0" ';
}
if ($display_user == 'yes') {
		$shortcode_output .='user="1" ';
	} else {
		$shortcode_output .='user="0" ';
}
if ($block_height != '') {
		$shortcode_output .='row_height="'.$block_height.'" ';
	} else {
		$shortcode_output .='row_height="45" ';
}
if ($filter_type != '') {
	$shortcode_output .='view="'.$filter_type.'" ';
}

$shortcode_output .='label="'.$all_text.'" ';

if ($enable_all == 'yes') {
		$shortcode_output .='hide_label="0" ';
	} else {
		$shortcode_output .='hide_label="1" ';
}
if ($display_hours == 'yes') {
		$shortcode_output .='hide_hrs="0" ';
	} else {
		$shortcode_output .='hide_hrs="1" ';
}
if ($display_empty_rows == 'yes') {
		$shortcode_output .='hide_empty_rows="0" ';
	} else {
		$shortcode_output .='hide_empty_rows="1" ';
}
if ($merge_cells == 'yes') {
		$shortcode_output .='group="1" ';
	} else {
		$shortcode_output .='group="0" ';
}
if ($disable_link == 'yes') {
		$shortcode_output .='disable_event_url="1" ';
	} else {
		$shortcode_output .='disable_event_url="0" ';
}

$shortcode_output .= ' text_align="'.$horizontal_align.'" ';
$shortcode_output .= ' text_align_vertical="'.$vertical_align.'" ';
$shortcode_output .= ' responsive"'.$mobile_view.'" ';
$shortcode_output .=']';

echo '<div id="'.esc_attr($unique_id).'" class="'.esc_attr($css_class).'">';

echo do_shortcode($shortcode_output);
if(!empty($custom_el_css)) {
		$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>");'
						. '})(jQuery);'
					. '</script>';
}
echo '</div>';
echo $output;