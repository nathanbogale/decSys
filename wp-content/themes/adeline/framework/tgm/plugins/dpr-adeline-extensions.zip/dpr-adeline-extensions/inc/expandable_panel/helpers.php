<?php



/**

 * Initialize Expandable Panel Functionality

 */



if ( ! class_exists( 'DPR_Expandable_Panel' ) ) {



	class DPR_Expandable_Panel {



		public function __construct() {

			add_action( 'wp_enqueue_scripts', array( $this, 'dpr_side_panel_scripts' ), 999 );

			add_action( 'widgets_init', array( $this, 'adeline_register_sidebar' ), 11 );

			add_filter( 'body_class', array( $this, 'dpr_side_panel_body_classes' ) );

			add_filter( 'wp_nav_menu_items', array( $this, 'dpr_side_panel_button' ), 12, 2 );

			add_action( 'adeline_after_mobile_icon', array( $this, 'dpr_side_panel_mobile_button' ) );

			add_action( 'wp_footer', array( $this, 'dpr_side_panel_overlay' ) );

			add_action( 'wp_footer', array( $this, 'dpr_side_panel' ) );

		}









	/**

	 * Registers sidebar

	 */

	public function adeline_register_sidebar() {



		register_sidebar( array(

			'name'			=> esc_html__( 'Expandable Panel', 'dpr-adeline-extensions' ),

			'id'			=> 'side-panel-sidebar',

			'description'	=> esc_html__( 'Widgets in this area are used in the expandable panel.', 'dpr-adeline-extensions' ),

			'before_widget'	=> '<div class="sidebar-box %2$s clr">',

			'after_widget'	=> '</div>',

			'before_title'	=> '<h5 class="panel-widget-title">',

			'after_title'	=> '</h5>',

		) );



	}



	/**

	 * Enqueue scripts.

	 */

	public function dpr_side_panel_scripts() {



		// Load main stylesheet

		wp_enqueue_style( 'dpr-side-panel-style', DPR_EXTENSIONS_PLUGIN_URL . 'inc/expandable_panel/assets/css/style.min.css', false, '1.0.0' );



		// If rtl

		if ( is_RTL() ) {

			wp_enqueue_style( 'dpr-side-panel-style', DPR_EXTENSIONS_PLUGIN_URL . 'inc/expandable_panel/assets/css/rtl.css', false, '1.0.0' );



		}

		

		// Load js script.

		wp_enqueue_script( 'nicescroll' );

        wp_enqueue_script( 'dpr-side-panel-js', DPR_EXTENSIONS_PLUGIN_URL . 'inc/expandable_panel/assets/js/main.min.js', false, true);

	}

	

	/**

	 * Add classes to body

	 */

	public function dpr_side_panel_body_classes( $classes ) {



		// Panel position

		$classes[] = 'dpr-sp-'.adeline_get_option_value('side_panel_position','','right');



		// If no breakpoint

		if ( '959' == adeline_get_option_value( 'hide_breakpoint', '','959' ) ) {

			$classes[] = 'dpr-sp-no-breakpoint';

		}



		// If no displace

		if ( true !=  adeline_get_option_value( 'content_displace') ) {

			$classes[] = 'dpr-sp-no-displace';

		}



		// Return classes

		return $classes;



	}

	

	/**

	 * Side Panel Icon HTML

	 */

	public function dpr_side_panel_icon_html() {

		

		$icon_html = '';

		$icon = adeline_get_option_value('opening_button_icon','','Default-exchange');

		$icon = $icon ? $icon : 'Default-exchange';

		$image_src = adeline_get_option_value('opening_button_image','url','');

		$img_style = 'style="width:auto; height:'.adeline_get_option_value('opening_button_icon_size','','20').'px;"';

		

		if ( 'icon' == adeline_get_option_value('opening_button_icon_type','','icon') ) {

			$icon_html = '<i class="side-panel-icon '. $icon .'"></i>';

		}

		if ( 'image' == adeline_get_option_value('opening_button_icon_type','','icon') ) {

			$icon_html .= '<img src="' . esc_url($image_src) . '"' . $img_style . '/>';

		}

		return $icon_html;

	

	

	}



	/**

	 * Add button to open the expandable panel

	 */

	public function dpr_side_panel_button( $items, $args ) {



		// Button position

		$btn_pos = adeline_get_option_value('opening_button_position','','beside');

		

		// Only used on main menu, centered right menu and custom header horizontal menu

		$possible_add_icon = false;

		if ($args->theme_location == 'main_menu' || $args->theme_location == 'centered_menu_right' || $args->container_id == 'custom-header-menu') {

				$possible_add_icon = true;

		}

		if ( 'menu' != $btn_pos || adeline_get_option_value('expandable_panel') != true ) {

				$possible_add_icon = false;

		}

		if ( !$possible_add_icon ) {

			return $items;

		}





		// Get text

		$text = adeline_get_option_value('opening_button_text','','');



		// Get text position

		$text_position = adeline_get_option_value( 'opening_button_text_position','','after' );

		$text_position = $text_position.'-icon';



		// Classes

		$classes = array( 'side-panel-btn' ); 



		// If text

		if ( $text ) {

			$classes[] = 'has-text';



			// Text position

			if ( $text_position ) {

				$classes[] = $text_position;

			}

		}



		// Turn classes into space seperated string

		$classes = implode( ' ', $classes );



		// Add button to menu

		$items .= '<li class="side-panel-li">';

			$items .= '<a href="#" class="'. $classes .'">';

				if ( $text

					&& 'before-icon' == $text_position ) {

					$items .= '<span class="side-panel-text">'. $text .'</span>';

				}

					$items .= $this->dpr_side_panel_icon_html();

				if ( $text

					&& 'after-icon' == $text_position ) {

					$items .= '<span class="side-panel-text">'. $text .'</span>';

				}

			$items .= '</a>';

		$items .= '</li>';

		

		// Return nav $items

		return $items;



	}



	/**

	 * Add button to open the side panel

	 */

	public function dpr_side_panel_mobile_button() {





		// Get text

		$text = adeline_get_option_value('opening_button_text','','');



		// Get text position

		$text_position = adeline_get_option_value( 'opening_button_text_position','','after' );

		$text_position = $text_position.'-icon';



		// Classes

		$classes = array( 'side-panel-btn' ); 



		// If text

		if ( $text ) {

			$classes[] = 'has-text';



			// Text position

			if ( $text_position ) {

				$classes[] = $text_position;

			}

		}



		// Turn classes into space seperated string

		$classes = implode( ' ', $classes );



		// Add button to menu

		$items = '<a href="#" class="'. $classes .'">';

			if ( $text

				&& 'before-icon' == $text_position ) {

				$items .= '<span class="side-panel-text">'. $text .'</span>';

			}

			$items .= $this->dpr_side_panel_icon_html();

			if ( $text

				&& 'after-icon' == $text_position ) {

				$items .= '<span class="side-panel-text">'. $text .'</span>';

			}

		$items .= '</a>';

		

		// Echo nav $items

		echo $items;

		

	}



	/**

	 * Overlay

	 */

	public function dpr_side_panel_overlay() {



		// Return if not true

		if ( true != adeline_get_option_value('content_overlay') ) {

			return;

		}



		// Add overlay div

		echo '<div class="dpr-sp-overlay"></div>';



	}



	/**

	 * Side Panel Template

	 */

	public function dpr_side_panel() {



		$file = DPR_EXTENSIONS_PLUGIN_PATH. 'inc/expandable_panel/template/side-panel.php';



		if ( file_exists( $file ) ) {

			include $file;

		}



	}

	



	}



}

new DPR_Expandable_Panel();