/**
 * Backend JS for responsive css param
 */
(function ($) {
	vc.atts.dpr_responsive_css = {
	
	init: function (param, $field) {
			if($field.find('.dpr_responsive_css').val() != "") {
			var valString = $field.find('.dpr_responsive_css').val();
			var splited = valString.split("|")
			jQuery.each(splited , function (index, value){
				var inputVar = value.split(":")
				$field.find('.'+ inputVar[0]).val(inputVar[1])
			});
			}
			$field.find('.css-input').on('change', function () {
			
			var $parent = $field.parent();
			var options = {},
				string_parts,
				string;
						
			options.laptop_margin_top = $parent.find('.laptop_margin_top').val();
			options.laptop_margin_bottom = $parent.find('.laptop_margin_bottom').val();
			options.laptop_margin_left = $parent.find('.laptop_margin_left').val();
			options.laptop_margin_right = $parent.find('.laptop_margin_right').val();

			options.laptop_border_top = $parent.find('.laptop_border_top').val();
			options.laptop_border_bottom = $parent.find('.laptop_border_bottom').val();
			options.laptop_border_left = $parent.find('.laptop_border_left').val();
			options.laptop_border_right = $parent.find('.laptop_border_right').val();

			options.laptop_padding_top = $parent.find('.laptop_padding_top').val();
			options.laptop_padding_bottom = $parent.find('.laptop_padding_bottom').val();
			options.laptop_padding_left = $parent.find('.laptop_padding_left').val();
			options.laptop_padding_right = $parent.find('.laptop_padding_right').val();

			options.tablet_margin_top = $parent.find('.tablet_margin_top').val();
			options.tablet_margin_bottom = $parent.find('.tablet_margin_bottom').val();
			options.tablet_margin_left = $parent.find('.tablet_margin_left').val();
			options.tablet_margin_right = $parent.find('.tablet_margin_right').val();

			options.tablet_border_top = $parent.find('.tablet_border_top').val();
			options.tablet_border_bottom = $parent.find('.tablet_border_bottom').val();
			options.tablet_border_left = $parent.find('.tablet_border_left').val();
			options.tablet_border_right = $parent.find('.tablet_border_right').val();

			options.tablet_padding_top = $parent.find('.tablet_padding_top').val();
			options.tablet_padding_bottom = $parent.find('.tablet_padding_bottom').val();
			options.tablet_padding_left = $parent.find('.tablet_padding_left').val();
			options.tablet_padding_right = $parent.find('.tablet_padding_right').val();

			options.mobile_margin_top = $parent.find('.mobile_margin_top').val();
			options.mobile_margin_bottom = $parent.find('.mobile_margin_bottom').val();
			options.mobile_margin_left = $parent.find('.mobile_margin_left').val();
			options.mobile_margin_right = $parent.find('.mobile_margin_right').val();

			options.mobile_border_top = $parent.find('.mobile_border_top').val();
			options.mobile_border_bottom = $parent.find('.mobile_border_bottom').val();
			options.mobile_border_left = $parent.find('.mobile_border_left').val();
			options.mobile_border_right = $parent.find('.mobile_border_right').val();

			options.mobile_padding_top = $parent.find('.mobile_padding_top').val();
			options.mobile_padding_bottom = $parent.find('.mobile_padding_bottom').val();
			options.mobile_padding_left = $parent.find('.mobile_padding_left').val();
			options.mobile_padding_right = $parent.find('.mobile_padding_right').val();
			
			string_parts = _.map(options, function (value, key) {
				if (_.isString(value) && 0 < value.length) {
					return key + ':' + encodeURIComponent(value);
				}
			});
			string = $.grep(string_parts, function (value) {
				return _.isString(value) && 0 < value.length;
			}).join('|');
			$field.find('.dpr_responsive_css').val(string);
			
			
			});
		$field.find('.device-button').click(function (e) {
				var target = jQuery(this).data('target');
				e.preventDefault();
				$field.find('.css-panel, .device-button').each(function () {
					jQuery(this).removeClass('active');
				});
				jQuery(this).addClass('active');
				$field.find('.css-panel[data-panel="'+target+'"]').addClass('active');				
			});

	},
};
})(window.jQuery);
