<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
/*
Heading style
*/

$output .= '<div class="headline-cover">';
$output .= $headline_html;
$output .= $subtitle_html;
$output .= '</div>';
$output .= $separator_html;