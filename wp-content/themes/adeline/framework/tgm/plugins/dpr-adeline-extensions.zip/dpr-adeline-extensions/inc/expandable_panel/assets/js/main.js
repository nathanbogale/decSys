// Side panel

var $j = jQuery.noConflict();



$j( document ).on( 'ready', function() {

	// Init side panel

	initSidePanel();

} );



/* ==============================================

INIT SIDE PANEL

============================================== */

function initSidePanel() {

	"use strict"



	// Open/Close panel

	$j( 'a.side-panel-btn, .side-panel-btn a, #side-panel-wrap a.close-panel, .dpr-sp-overlay' ).on( 'click', function( e ) {

		e.preventDefault();



		if ( ! $j( '.side-panel-btn' ).hasClass( 'opened' ) ) {



			$j( '#side-panel-inner' ).css( { 'visibility': 'visible' } );

			$j( this ).addClass( 'opened' );

			$j( 'body' ).addClass( 'dpr-sp-opened' );

			$j( '.side-panel-btn > .side-panel-icon.hamburger' ).addClass( 'is-active' );



		} else {



			$j( '.side-panel-btn' ).removeClass( 'opened' );

			$j( 'body' ).removeClass( 'dpr-sp-opened' );

			$j( '.side-panel-btn > .side-panel-icon.hamburger' ).removeClass( 'is-active' );



		}



	} );



	// Close when click on mobile button

	$j( '#dpr-adeline-mobile-menu-icon a.mobile-menu' ).on( 'click', function() {



		if ( $j( '.side-panel-btn' ).hasClass( 'opened' ) ) {



			$j( 'a.side-panel-btn' ).removeClass( 'opened' );

			$j( 'body' ).removeClass( 'dpr-sp-opened' );

			$j( '.side-panel-btn > .side-panel-icon.hamburger' ).removeClass( 'is-active' );



		}



	} );



	// Panel scrollbar

	if ( ! navigator.userAgent.match( /(Android|iPod|iPhone|iPad|IEMobile|Opera Mini)/ ) ) {

		$j( '#side-panel-inner' ).niceScroll( {

			autohidemode		: false,

			cursorborder		: 0,

			cursorborderradius	: 0,

			cursorcolor			: 'transparent',

			cursorwidth			: 0,

			horizrailenabled	: false,

			mousescrollstep		: 40,

			scrollspeed			: 60,

			zindex				: 100005,

		} );

	}



}