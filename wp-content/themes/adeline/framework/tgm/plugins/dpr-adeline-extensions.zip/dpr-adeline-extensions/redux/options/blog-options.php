<?php



/**



 * Blog Page Options



 * 



 */







    Redux::setSection( $opt_name, array(



        'title'  => __( 'Blog', 'dpr-adeline-extensions' ),



        'id'     => 'blog_tab',



        'desc'   => __( 'Basic blog entries settings are configured here.', 'dpr-adeline-extensions' ),



        'icon'   => 'el el-edit'



    ) );



	require_once($options_dir . '/blog-options/blog-page-settings.php');



	require_once($options_dir . '/blog-options/single-post-settings.php');



