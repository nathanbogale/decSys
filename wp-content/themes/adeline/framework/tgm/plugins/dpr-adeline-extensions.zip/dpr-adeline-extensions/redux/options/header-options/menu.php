<?php

/**



 * Header Options -> Menu



 *



 */

Redux::setSection($opt_name, array(

    'title'      => esc_html__('Menu', 'dpr-adeline-extensions'),

    'id'         => 'header_menu',

    'subsection' => true,

    'fields'     => array(

        array(

            'id'    => 'menu_main_styling_info',

            'type'  => 'info',

            'style' => 'dpr-title',

            'title' => wp_kses_post(__('<h3>Main Styling</h3>', 'dpr-adeline-extensions')),

        ),

        array(

            'id'       => 'menu_link_color',

            'type'     => 'color',

            'output'   => array('color' => '#dpr-navigation-wrapper .dropdown-menu > li > a,#dpr-adeline-mobile-menu-icon a,#searchform-header-replace-close'),

            'validate' => 'color',

            'title'    => esc_html__('Menu Link Color', 'dpr-adeline-extensions'),

            'default'  => '#292933',

            'hint'     => array(

                'title'   => esc_attr__('Menu Link Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set main menu link color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_link_color_hover',

            'type'     => 'color',

            'output'   => array('color' => '#dpr-navigation-wrapper .dropdown-menu > li > a:hover,#dpr-adeline-mobile-menu-icon a:hover,#searchform-header-replace-close:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Menu Link Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'hint'     => array(

                'title'   => esc_attr__('Menu Link Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set main menu link hover color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_link_color_curent',

            'type'     => 'color',

            'output'   => array('color' => '#dpr-navigation-wrapper .dropdown-menu > .current-menu-item > a,#dpr-navigation-wrapper .dropdown-menu > .current-menu-ancestor > a,#dpr-navigation-wrapper .dropdown-menu > .current-menu-item > a:hover,#dpr-navigation-wrapper .dropdown-menu > .current-menu-ancestor > a:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Menu Link Color: Current Menu Item', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'hint'     => array(

                'title'   => esc_attr__('Menu Link Color: Current Menu Item', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set main menu current menu item link color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_link_bg_color',

            'type'     => 'color',

            'output'   => array('background-color' => '#dpr-navigation-wrapper .dropdown-menu > li > a'),

            'validate' => 'color',

            'title'    => esc_html__('Menu Item Background Color', 'dpr-adeline-extensions'),

            'default'  => '',

            'hint'     => array(

                'title'   => esc_attr__('Menu Item Background Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set menu item background color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_link_bg_color_hover',

            'type'     => 'color',

            'output'   => array('background-color' => '#dpr-navigation-wrapper .dropdown-menu > li > a:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Menu Item Background Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '',

            'hint'     => array(

                'title'   => esc_attr__('Menu Item Background Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set menu item hover background color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_link_bg_color_curent',

            'type'     => 'color',

            'output'   => array('color' => '#dpr-navigation-wrapper .dropdown-menu > .current-menu-item > a,#dpr-navigation-wrapper .dropdown-menu > .current-menu-ancestor > a,#dpr-navigation-wrapper .dropdown-menu > .current-menu-item > a:hover,#dpr-navigation-wrappe .dropdown-menu > .current-menu-ancestor > a:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Menu Item Background Color: Current Menu Item', 'dpr-adeline-extensions'),

            'default'  => '',

            'hint'     => array(

                'title'   => esc_attr__('Menu Item Background Color: Current Menu Item', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set current menu item background color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'             => 'menu_link_spacing',

            'type'           => 'spacing',

            'output'         => array('#dpr-navigation-wrapper .dropdown-menu > li > a'),

            'mode'           => 'padding',

            'units'          => array('px'),

            'display_units'  => true,

            'units_extended' => false,

            'top'            => false,

            'bottom'         => false,

            'title'          => __('Menu Items Horizontal Padding(px)', 'dpr-adeline-extensions'),

            'default'        => array(

                'padding-left'  => '15px',

                'padding-right' => '15px',

                'units'         => 'px',

            ),

            'hint'           => array(

                'title'   => esc_attr__('Menu Items Horizontal Padding(px)', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Choose default menu items left/right padding.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'      => 'first_level_arrows',

            'type'    => 'switch',

            'default' => false,

            'title'   => esc_html__('Top Level Dropdown Indicators', 'dpr-adeline-extensions'),

            'hint'    => array(

                'title'   => esc_attr__('Top Level Dropdown Indicators', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enable or disable display dropdown arrows in top level menu ', 'dpr-adeline-extensions'),

            ),

        ),

/* Overlapping Header styling */

        array(

            'id'    => 'menu_overlapp_info',

            'type'  => 'info',

            'style' => 'dpr-title',

            'title' => wp_kses_post(__('<h3>Overlapping Header Menu styling</h3>', 'dpr-adeline-extensions')),

        ),

        array(

            'id'    => 'menu_overlapp_light_info',

            'type'  => 'info',

            'style' => 'dpr-subtitle',

            'title' => wp_kses_post(__('<h3>Overlapping Light Style</h3>', 'dpr-adeline-extensions')),

        ),

        array(

            'id'       => 'menu_link_color_ol',

            'type'     => 'color',

            'output'   => array('color' => 'body.header-overlapping-used.overlapping-style-light #dpr-navigation-wrapper .dropdown-menu > li > a,body.header-overlapping-used.overlapping-style-light #dpr-adeline-mobile-menu-icon a,body.header-overlapping-used.overlapping-style-light #searchform-header-replace-close'),

            'validate' => 'color',

            'title'    => esc_html__('Menu Link Color', 'dpr-adeline-extensions'),

            'default'  => '#fff',

            'hint'     => array(

                'title'   => esc_attr__('Menu Link Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set main menu link color for overlapping header light style.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_link_color_hover_ol',

            'type'     => 'color',

            'output'   => array('color' => 'body.header-overlapping-used.overlapping-style-light #dpr-navigation-wrapper .dropdown-menu > li > a:hover,body.header-overlapping-used.overlapping-style-light #dpr-adeline-mobile-menu-icon a:hover,body.header-overlapping-used.overlapping-style-light #searchform-header-replace-close:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Menu Link Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'hint'     => array(

                'title'   => esc_attr__('Overlapping Light Menu Link Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set main menu link hover color for overlapping header light style.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_link_color_curent_ol',

            'type'     => 'color',

            'output'   => array('color' => 'body.header-overlapping-used.overlapping-style-light #dpr-navigation-wrapper .dropdown-menu > .current-menu-item > a,body.header-overlapping-used.overlapping-style-light #dpr-navigation-wrapper .dropdown-menu > .current-menu-ancestor > a,body.header-overlapping-used.overlapping-style-light #dpr-navigation-wrapper .dropdown-menu > .current-menu-item > a:hover,body.header-overlapping-used.overlapping-style-light #dpr-navigation-wrapper .dropdown-menu > .current-menu-ancestor > a:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Overlapping Light Menu Link Color: Current Menu Item', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'hint'     => array(

                'title'   => esc_attr__('Overlapping Light Menu Link Color: Current Menu Item', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set main menu current menu item link color for overlapping header light style.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'    => 'menu_overlapp_dark_info',

            'type'  => 'info',

            'style' => 'dpr-subtitle',

            'title' => wp_kses_post(__('<h3>Overlapping Dark Style</h3>', 'dpr-adeline-extensions')),

        ),

        array(

            'id'       => 'menu_link_color_od',

            'type'     => 'color',

            'output'   => array('color' => 'body.header-overlapping-used.overlapping-style-dark #dpr-navigation-wrapper .dropdown-menu > li > a,body.header-overlapping-used.overlapping-style-dark #dpr-adeline-mobile-menu-icon a,body.header-overlapping-used.overlapping-style-dark #searchform-header-replace-close'),

            'validate' => 'color',

            'title'    => esc_html__('Menu Link Color', 'dpr-adeline-extensions'),

            'default'  => '#292933',

            'hint'     => array(

                'title'   => esc_attr__('Menu Link Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set main menu link coloroverlapping header dark style.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_link_color_hover_od',

            'type'     => 'color',

            'output'   => array('color' => 'body.header-overlapping-used.overlapping-style-dark #dpr-navigation-wrapper .dropdown-menu > li > a:hover,body.header-overlapping-used.overlapping-style-dark #dpr-adeline-mobile-menu-icon a:hover,body.header-overlapping-used.overlapping-style-dark #searchform-header-replace-close:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Menu Link Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'hint'     => array(

                'title'   => esc_attr__('Menu Link Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set main menu link hover color overlapping header dark style.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_link_color_curent_od',

            'type'     => 'color',

            'output'   => array('color' => 'body.header-overlapping-used.overlapping-style-dark #dpr-navigation-wrapper .dropdown-menu > .current-menu-item > a,body.header-overlapping-used.overlapping-style-dark #dpr-navigation-wrapper .dropdown-menu > .current-menu-ancestor > a,body.header-overlapping-used.overlapping-style-dark #dpr-navigation-wrapper .dropdown-menu > .current-menu-item > a:hover,body.header-overlapping-used.overlapping-style-dark #dpr-navigation-wrapper .dropdown-menu > .current-menu-ancestor > a:hover', 'background-color' => 'body.header-overlapping-used.overlapping-style-dark .menu-bar .opener'),

            'validate' => 'color',

            'title'    => esc_html__('Menu Link Color: Current Menu Item', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'hint'     => array(

                'title'   => esc_attr__('Menu Link Color: Current Menu Item', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set main menu current menu item link color overlapping header dark style.', 'dpr-adeline-extensions'),

            ),

        ),

/* Dropdowns Styling */

        array(

            'id'    => 'dropdown_styling_info',

            'type'  => 'info',

            'style' => 'dpr-title',

            'title' => wp_kses_post(__('<h3>Dropdowns Stylling</h3>', 'dpr-adeline-extensions')),

        ),

        array(

            'id'      => 'dropdown_width',

            'type'    => 'dimensions',

            'output'  => array('.dropdown-menu .sub-menu'),

            'title'   => esc_html__('Menu Dropdowns Width (px)', 'dpr-adeline-extensions'),

            'width'   => true,

            'height'  => false,

            'mode'    => array('width' => 'min-width', 'height' => 'height'),

            'units'   => array('px'),

            'default' => array(

                'width' => '220px',

            ),

            'hint'    => array(

                'title'   => esc_attr__('Menu Dropdowns Width ', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify the minimum menu dropdowns width.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'dropdown_background',

            'type'     => 'color',

            'output'   => array('background-color' => '.dropdown-menu .sub-menu,#searchform-dropdown,#current-shop-items-dropdown'),

            'validate' => 'color',

            'title'    => esc_html__('Dropdown Background Color', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'hint'     => array(

                'title'   => esc_attr__('Dropdown Background Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set background color for menu dropdowns.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'      => 'dropdown_top_border',

            'type'    => 'switch',

            'default' => false,

            'title'   => esc_html__('Use Dropdown Top Decoration', 'dpr-adeline-extensions'),

            'hint'    => array(

                'title'   => esc_attr__('Dropdown Top Border', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enable or disable display dropdown top border menu ', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'dropdown_top_border_color',

            'type'     => 'color',

            'output'   => array('border-color' => '.dropdown-menu .sub-menu,#searchform-dropdown,#current-shop-items-dropdown'),

            'validate' => 'color',

            'title'    => esc_html__('Dropdown Top Decoration Color', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'required' => array('dropdown_top_border', 'equals', '1'),

            'hint'     => array(

                'title'   => esc_attr__('Dropdown Top Decoration Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set color for dropdowns top decoration.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'dropdown_top_border_width',

            'type'     => 'slider',

            'title'    => __('Top Border Width', 'dpr-adeline-extensions'),

            'default'  => '4',

            'min'      => '1',

            'step'     => '1',

            'max'      => '20',

            'required' => array('dropdown_top_border', 'equals', '1'),

            'hint'     => array(

                'title'   => esc_attr__('Top Border Width', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set top border width for dropdowns.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'dropdown_top_arrow',

            'type'     => 'switch',

            'default'  => false,

            'title'    => esc_html__('Use Top Arrow', 'dpr-adeline-extensions'),

            'required' => array('dropdown_top_border', 'equals', '1'),

            'hint'     => array(

                'title'   => esc_attr__('Use Top Arrow', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enable or disable display dropdown top arrow for first level submenus ', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'dropdown_separators_color',

            'type'     => 'color',

            'output'   => array('border-color' => '.dropdown-menu ul li.menu-item,.navigation > ul > li > ul.megamenu.sub-menu > li,.navigation .megamenu li ul.sub-menu'),

            'validate' => 'color',

            'title'    => esc_html__('Dropdown Separators Color', 'dpr-adeline-extensions'),

            'default'  => 'rgba(255,255,255,0)',

            'hint'     => array(

                'title'   => esc_attr__('Dropdown Background Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set separator lines color for menu dropdowns.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'dropdown_link_color',

            'type'     => 'color',

            'output'   => array('color' => '.dropdown-menu ul li a.menu-link'),

            'validate' => 'color',

            'title'    => esc_html__('Dropdown Link Color', 'dpr-adeline-extensions'),

            'default'  => '#292933',

            'hint'     => array(

                'title'   => esc_attr__('Dropdown Link Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set color for menu dropdowns links.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'dropdown_link_color_hover',

            'type'     => 'color',

            'output'   => array('color' => '.dropdown-menu ul li a.menu-link:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Dropdown Link Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'hint'     => array(

                'title'   => esc_attr__('Dropdown Link Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set hover color for menu dropdowns links.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'dropdown_link_background_hover',

            'type'     => 'color',

            'output'   => array('background-color' => '.dropdown-menu ul li a.menu-link:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Dropdown Link Background Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '#f1f2f4',

            'hint'     => array(

                'title'   => esc_attr__('Dropdown Link Background Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set background color for menu dropdowns links.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'dropdown_link_color_current',

            'type'     => 'color',

            'output'   => array('color' => '.dropdown-menu ul > .current-menu-item > a.menu-link'),

            'validate' => 'color',

            'title'    => esc_html__('Dropdown Link Color: Current', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'hint'     => array(

                'title'   => esc_attr__('Dropdown Link Color: Current Item', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set hover color for menu dropdowns links.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'dropdown_link_background_current',

            'type'     => 'color',

            'output'   => array('background-color' => '.dropdown-menu ul > .current-menu-item > a.menu-link'),

            'validate' => 'color',

            'title'    => esc_html__('Dropdown Link Background Color: Current', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'hint'     => array(

                'title'   => esc_attr__('Dropdown Link Background Color: Current Item', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set background color for menu dropdowns links.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'      => 'second_level_arrows',

            'type'    => 'switch',

            'default' => true,

            'title'   => esc_html__('Second Level Dropdown Indicators', 'dpr-adeline-extensions'),

            'hint'    => array(

                'title'   => esc_attr__('Second Level Dropdown Indicators', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enable or disable display dropdown arrows in second level menu ', 'dpr-adeline-extensions'),

            ),

        ),

/* Search Style */

        array(

            'id'    => 'search_styling_info',

            'type'  => 'info',

            'style' => 'dpr-title',

            'title' => wp_kses_post(__('<h3>Search Style</h3>', 'dpr-adeline-extensions')),

        ),

        array(

            'id'      => 'menu_search_style',

            'type'    => 'radio',

            'title'   => __('Search Style', 'dpr-adeline-extensions'),

            'options' => array(

                'disabled'          => 'Disabled',

                'drop_down'         => 'Drop Down',

                'expandable_search' => 'Expandable Verical Search',

                'full_screen'       => 'Full Screen Search',

            ),

            'default' => 'disabled',

            'hint'    => array(

                'title'   => esc_attr__('Search Style', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set search style for menu', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'dropdown_search_color',

            'type'     => 'color',

            'output'   => array('color' => '#searchform-dropdown input, #searchform-dropdown input::placeholder'),

            'validate' => 'color',

            'title'    => esc_html__('Input Color', 'dpr-adeline-extensions'),

            'default'  => '#243854',

            'required' => array('menu_search_style', 'equals', array('drop_down')),

            'hint'     => array(

                'title'   => esc_attr__('Input Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set color for dropdown search input.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'dropdown_search_bg_color',

            'type'     => 'color',

            'output'   => array('background-color' => '#searchform-dropdown input'),

            'validate' => 'color',

            'title'    => esc_html__('Input Background Color', 'dpr-adeline-extensions'),

            'default'  => 'rgba(0,0,0,0)',

            'required' => array('menu_search_style', 'equals', array('drop_down')),

            'hint'     => array(

                'title'   => esc_attr__('Input Background Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set background color for search input.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'dropdown_search_border_color',

            'type'     => 'color',

            'output'   => array('border-color' => '#searchform-dropdown input'),

            'validate' => 'color',

            'title'    => esc_html__('Search Input Border Color', 'dpr-adeline-extensions'),

            'default'  => '#e5e5e9',

            'required' => array('menu_search_style', 'equals', array('drop_down')),

            'hint'     => array(

                'title'   => esc_attr__('Search Input Border Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set border color for search input.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'fullscreen_search_appear_effect',

            'type'     => 'select',

            'title'    => esc_html__('Fullscreen Search Appearance Effect', 'dpr-adeline-extensions'),

            'desc'     => '',

            'options'  => array(

                'overlay-hugeinc'     => esc_html__('Fade', 'dpr-adeline-extensions'),

                'overlay-corner'      => esc_html__('Corner', 'dpr-adeline-extensions'),

                'overlay-slidedown'   => esc_html__('Slide Down', 'dpr-adeline-extensions'),

                'overlay-scale'       => esc_html__('Scale', 'dpr-adeline-extensions'),

                'overlay-simplegenie' => esc_html__('Genie', 'dpr-adeline-extensions'),

            ),

            'default'  => 'overlay-hugeinc',

            'hint'     => array(

                'title'   => esc_attr__('Fullscreen Search Appearance Effect', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Select the appear animation effect for the full screen search.', 'dpr-adeline-extensions'),

            ),

            'required' => array('menu_search_style', 'equals', array('full_screen')),

        ),

        array(

            'id'       => 'full_screen_search_bg_color',

            'type'     => 'color',

            'output'   => array('background-color' => '#searchform-fullscreen'),

            'validate' => 'color',

            'title'    => esc_html__('Fullscreen Search Background Color', 'dpr-adeline-extensions'),

            'default'  => 'rgba(255,255,255,.8)',

            'required' => array('menu_search_style', 'equals', array('full_screen')),

            'hint'     => array(

                'title'   => esc_attr__('Fullscreen Search Background Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set background color for fullscreen search.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'full_screen_search_color',

            'type'     => 'color',

            'output'   => array('color' => '#searchform-fullscreen form input, #searchform-fullscreen form label'),

            'validate' => 'color',

            'title'    => esc_html__('Fullscreen Search Input Color', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'required' => array('menu_search_style', 'equals', array('full_screen')),

            'hint'     => array(

                'title'   => esc_attr__('Fullscreen Search Input Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set color for search input.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'full_screen_search_underline_color',

            'type'     => 'color',

            'output'   => array('border-color' => '#searchform-fullscreen form input'),

            'validate' => 'color',

            'title'    => esc_html__('Search Input Underline Color', 'dpr-adeline-extensions'),

            'default'  => 'rgba(255,255,255,.7)',

            'required' => array('menu_search_style', 'equals', array('full_screen')),

            'hint'     => array(

                'title'   => esc_attr__('Search Input Underline Color:', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set color for search input underline.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'full_screen_search_underline_color_active',

            'type'     => 'color',

            'output'   => array('border-color' => '#searchform-fullscreen form input:hover, #searchform-fullscreen form input:focus '),

            'validate' => 'color',

            'title'    => esc_html__('Search Input Underline Color: Focus', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'required' => array('menu_search_style', 'equals', array('full_screen')),

            'hint'     => array(

                'title'   => esc_attr__('Search Input Underline Color: Focus', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set color for search focus and active input underline', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'full_screen_search_close_bg_color',

            'type'     => 'color',

            'output'   => array('background-color' => '#searchform-fullscreen a.search-fullscreen-close'),

            'validate' => 'color',

            'title'    => esc_html__('Close Button Background Color', 'dpr-adeline-extensions'),

            'default'  => 'rgba(255,255,255,0.2)',

            'required' => array('menu_search_style', 'equals', array('full_screen')),

            'hint'     => array(

                'title'   => esc_attr__('Close Button Background Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set background color for close button.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'full_screen_search_close_color',

            'type'     => 'color',

            'output'   => array('background-color' => '#searchform-fullscreen a.search-fullscreen-close span:before, #searchform-fullscreen a.search-fullscreen-close span:after'),

            'validate' => 'color',

            'title'    => esc_html__('Close Button Color', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'required' => array('menu_search_style', 'equals', array('full_screen')),

            'hint'     => array(

                'title'   => esc_attr__('Close Button Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set background color for close button.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'full_screen_search_close_bg_color_hover',

            'type'     => 'color',

            'output'   => array('background-color' => '#searchform-fullscreen a.search-fullscreen-close:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Close Button Background Color: Hover', 'dpr-adeline-extensions'),

            'default'  => 'rgba(255,255,255,0.4)',

            'required' => array('menu_search_style', 'equals', array('full_screen')),

            'hint'     => array(

                'title'   => esc_attr__('Close Button Background Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set hover background color for close button.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'full_screen_search_close_color_hover',

            'type'     => 'color',

            'output'   => array('background-color' => '#searchform-fullscreen a.search-fullscreen-close:hover span:before, #searchform-fullscreen a.search-fullscreen-close:hover span:after'),

            'validate' => 'color',

            'title'    => esc_html__('Close Button Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'required' => array('menu_search_style', 'equals', array('full_screen')),

            'hint'     => array(

                'title'   => esc_attr__('Close Button Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set hover color for close button.', 'dpr-adeline-extensions'),

            ),

        ),

/* Menu Effects */

        array(

            'id'    => 'menu_effets_info',

            'type'  => 'info',

            'style' => 'dpr-title',

            'title' => wp_kses_post(__('<h3>Top Menu Effects</h3>', 'dpr-adeline-extensions')),

        ),

        array(

            'id'      => 'menu_effect',

            'type'    => 'select',

            'title'   => esc_html__('Menu Link Effect', 'dpr-adeline-extensions'),

            'desc'    => '',

            'options' => array(

                'no' => esc_html__('None', 'dpr-adeline-extensions'),

                '1'  => esc_html__('Underline Animated From Left', 'dpr-adeline-extensions'),

                '2'  => esc_html__('Underline Animated From Bottom', 'dpr-adeline-extensions'),

                '3'  => esc_html__('Underline Animated From Top', 'dpr-adeline-extensions'),

                '4'  => esc_html__('Underline Animated From Center', 'dpr-adeline-extensions'),

                '5'  => esc_html__('Underline & Overline Animated From Left', 'dpr-adeline-extensions'),

                '6'  => esc_html__('Underline & Overline Animated From Right', 'dpr-adeline-extensions'),

                '7'  => esc_html__('Underline & Overline Animated From Center', 'dpr-adeline-extensions'),

                '8'  => esc_html__('Underline & Overline Animated Oposite', 'dpr-adeline-extensions'),

                '9'  => esc_html__('Underline & Overline Animated Oposite Reverse', 'dpr-adeline-extensions'),

                '10' => esc_html__('Stroke', 'dpr-adeline-extensions'),

                '11' => esc_html__('Marker', 'dpr-adeline-extensions'),

                '12' => esc_html__('Background Animated From Left', 'dpr-adeline-extensions'),

                '13' => esc_html__('Background Animated From Bottom', 'dpr-adeline-extensions'),

                '14' => esc_html__('Bracket', 'dpr-adeline-extensions'),

                '15' => esc_html__('Circular Reveal', 'dpr-adeline-extensions'),

            ),

            'default' => 'none',

            'hint'    => array(

                'title'   => esc_attr__('Menu Link Effect', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Select menu link effect.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_effect_color_1',

            'type'     => 'color',

            'output'   => array('background-color' => '.effect-1 #dpr-navigation-wrapper .dropdown-menu > li > a.menu-link > span:after'),

            'validate' => 'color',

            'title'    => esc_html__('Menu Effect Color', 'dpr-adeline-extensions'),

            'default'  => 'rgba(247, 35, 35, 0.15)',

            'required' => array('menu_effect', 'equals', '1'),

            'hint'     => array(

                'title'   => esc_attr__('Close Button Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set hover color for close button.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_effect_color_2',

            'type'     => 'color',

            'output'   => array('background-color' => '.effect-2 #dpr-navigation-wrapper .dropdown-menu > li > a.menu-link > span:after '),

            'validate' => 'color',

            'title'    => esc_html__('Menu Effect Color', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'required' => array('menu_effect', 'equals', '2'),

            'hint'     => array(

                'title'   => esc_attr__('Close Button Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set hover color for close button.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_effect_color_3',

            'type'     => 'color',

            'output'   => array('background-color' => '.effect-3 #dpr-navigation-wrapper .dropdown-menu > li > a.menu-link > span:after '),

            'validate' => 'color',

            'title'    => esc_html__('Menu Effect Color', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'required' => array('menu_effect', 'equals', '3'),

            'hint'     => array(

                'title'   => esc_attr__('Close Button Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set hover color for close button.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_effect_color_4',

            'type'     => 'color',

            'output'   => array('background-color' => '.effect-4 #dpr-navigation-wrapper .dropdown-menu > li > a.menu-link > span:before'),

            'validate' => 'color',

            'title'    => esc_html__('Menu Effect Color', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'required' => array('menu_effect', 'equals', '4'),

            'hint'     => array(

                'title'   => esc_attr__('Close Button Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set hover color for close button.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_effect_color_5',

            'type'     => 'color',

            'output'   => array('background-color' => '.effect-5 #dpr-navigation-wrapper .dropdown-menu > li > a.menu-link > span:before, .effect-5 #dpr-navigation-wrapper .dropdown-menu > li > a.menu-link > span:after'),

            'validate' => 'color',

            'title'    => esc_html__('Menu Effect Color', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'required' => array('menu_effect', 'equals', '5'),

            'hint'     => array(

                'title'   => esc_attr__('Close Button Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set hover color for close button.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_effect_color_6',

            'type'     => 'color',

            'output'   => array('background-color' => '.effect-6 #dpr-navigation-wrapper .dropdown-menu > li > a.menu-link > span:before, .effect-6 #dpr-navigation-wrapper .dropdown-menu > li > a.menu-link > span:after'),

            'validate' => 'color',

            'title'    => esc_html__('Menu Effect Color', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'required' => array('menu_effect', 'equals', '6'),

            'hint'     => array(

                'title'   => esc_attr__('Close Button Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set hover color for close button.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_effect_color_7',

            'type'     => 'color',

            'output'   => array('background-color' => '.effect-7 #dpr-navigation-wrapper .dropdown-menu > li > a.menu-link > span:before, .effect-7 #dpr-navigation-wrapper .dropdown-menu > li > a.menu-link > span:after'),

            'validate' => 'color',

            'title'    => esc_html__('Menu Effect Color', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'required' => array('menu_effect', 'equals', '7'),

            'hint'     => array(

                'title'   => esc_attr__('Close Button Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set hover color for close button.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_effect_color_8',

            'type'     => 'color',

            'output'   => array('background-color' => '.effect-8 #dpr-navigation-wrapper .dropdown-menu > li > a.menu-link > span:before, .effect-8 #dpr-navigation-wrapper .dropdown-menu > li > a.menu-link > span:after'),

            'validate' => 'color',

            'title'    => esc_html__('Menu Effect Color', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'required' => array('menu_effect', 'equals', '8'),

            'hint'     => array(

                'title'   => esc_attr__('Close Button Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set hover color for close button.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_effect_color_9',

            'type'     => 'color',

            'output'   => array('background-color' => '.effect-9 #dpr-navigation-wrapper .dropdown-menu > li > a.menu-link > span:before, .effect-9 #dpr-navigation-wrapper .dropdown-menu > li > a.menu-link > span:after'),

            'validate' => 'color',

            'title'    => esc_html__('Menu Effect Color', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'required' => array('menu_effect', 'equals', '9'),

            'hint'     => array(

                'title'   => esc_attr__('Close Button Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set hover color for close button.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_effect_color_10',

            'type'     => 'color',

            'output'   => array('background-color' => '.effect-10 #dpr-navigation-wrapper .dropdown-menu > li > a.menu-link > span:before '),

            'validate' => 'color',

            'title'    => esc_html__('Menu Effect Color', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'required' => array('menu_effect', 'equals', '10'),

            'hint'     => array(

                'title'   => esc_attr__('Close Button Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set hover color for close button.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_effect_color_11',

            'type'     => 'color',

            'output'   => array('background-color' => '.effect-11 #dpr-navigation-wrapper .dropdown-menu > li > a.menu-link > span:before'),

            'validate' => 'color',

            'title'    => esc_html__('Menu Effect Color', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'required' => array('menu_effect', 'equals', '11'),

            'hint'     => array(

                'title'   => esc_attr__('Close Button Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set hover color for close button.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_effect_color_12',

            'type'     => 'color',

            'output'   => array('background-color' => '.effect-12 #dpr-navigation-wrapper .dropdown-menu > li > a.menu-link > span:before'),

            'validate' => 'color',

            'title'    => esc_html__('Menu Effect Color', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'required' => array('menu_effect', 'equals', '12'),

            'hint'     => array(

                'title'   => esc_attr__('Close Button Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set hover color for close button.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_effect_color_13',

            'type'     => 'color',

            'output'   => array('background-color' => '.effect-13 #dpr-navigation-wrapper .dropdown-menu > li > a.menu-link > span:before'),

            'validate' => 'color',

            'title'    => esc_html__('Menu Effect Color', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'required' => array('menu_effect', 'equals', '13'),

            'hint'     => array(

                'title'   => esc_attr__('Close Button Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set hover color for close button.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_effect_color_14',

            'type'     => 'color',

            'output'   => array('color' => '.effect-14 #dpr-navigation-wrapper .dropdown-menu > li > a.menu-link > span:before, .effect-14 #dpr-navigation-wrapper .dropdown-menu > li > a.menu-link > span:after'),

            'validate' => 'color',

            'title'    => esc_html__('Menu Effect Color', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'required' => array('menu_effect', 'equals', '14'),

            'hint'     => array(

                'title'   => esc_attr__('Close Button Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set hover color for close button.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_effect_color_15',

            'type'     => 'color',

            'output'   => array('border-color' => '.effect-15 #dpr-navigation-wrapper .dropdown-menu > li > a.menu-link > span:before, .effect-15 #dpr-navigation-wrapper .dropdown-menu > li > a.menu-link > span:after'),

            'validate' => 'color',

            'title'    => esc_html__('Menu Effect Color', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'required' => array('menu_effect', 'equals', '15'),

            'hint'     => array(

                'title'   => esc_attr__('Close Button Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set hover color for close button.', 'dpr-adeline-extensions'),

            ),

        ),

    ),

));
