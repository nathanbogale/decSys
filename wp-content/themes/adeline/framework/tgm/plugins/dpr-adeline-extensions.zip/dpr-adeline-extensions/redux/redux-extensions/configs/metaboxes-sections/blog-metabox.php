<?php

if (!function_exists("dpr_blog_metabox_sections")):

    function dpr_blog_metabox_sections()
{

        // Declare your sections

        /*

         * ---> START BLOP PAGE METABOX SECTIONS

         */

        $blog_metabox_sections = array();

        $blog_metabox_sections[] = array(

            'title'    => esc_html__('Source', 'dpr-adeline-extensions'),

            'subtitle' => esc_html__('', 'dpr-adeline-extensions'),

            'fields'   => array(

                array(

                    'id'    => 'blog_posts_per_page',

                    'type'  => 'spinner',

                    'title' => __('Blog Posts per Page', 'dpr-adeline-extensions'),

                    'desc'  => wp_kses_post(__('<small><i>Put -1 to display all bog posts items. Default is 12.</i></small>', 'dpr-adeline-extensions')),

                    'min'   => '-1',

                    'step'  => '1',

                    'max'   => '200',

                    'hint'  => array(

                        'title'   => esc_attr__('Blog Posts per Page', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('You can set count posts per page count for this page.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'    => 'blog_use_query',

                    'type'  => 'switch',

                    'desc'  => wp_kses_post(__('<small><em>By default are displayed all blog items. Enable this option if you need create custom blog items set to display.</em></small>', 'dpr-adeline-extensions')),

                    'title' => esc_html__('Use Qustom Query?', 'dpr-adeline-extensions'),

                    'hint'  => array(

                        'title'   => esc_attr__('Use Qustom Query?', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Use custom query to create source for blog page.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'blog_query_categories',

                    'type'     => 'select',

                    'data'     => 'terms',

                    'multi'    => true,

                    'args'     => array('taxonomies' => 'category'),

                    'title'    => __('Categories', 'dpr-adeline-extensions'),

                    'required' => array('blog_use_query', 'equals', '1'),

                    'desc'     => wp_kses_post(__('<small><i>If you leave this field blank all categories will be included.</i></small>', 'dpr-adeline-extensions')),

                    'hint'     => array(

                        'title'   => esc_attr__('Categories', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Select categories to include in source', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'blog_query_categories_excluded',

                    'type'     => 'select',

                    'data'     => 'terms',

                    'multi'    => true,

                    'args'     => array('taxonomies' => 'category'),

                    'title'    => __('Excluded Categories', 'dpr-adeline-extensions'),

                    'required' => array('blog_use_query', 'equals', '1'),

                    'desc'     => wp_kses_post(__('<small><i>Select categories to exclude from source.</i></small>', 'dpr-adeline-extensions')),

                    'hint'     => array(

                        'title'   => esc_attr__('Excluded Categories', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Select categories to exclude from source', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'blog_query_offset',

                    'type'     => 'spinner',

                    'title'    => __('Items count', 'dpr-adeline-extensions'),

                    'required' => array('blog_use_query', 'equals', '1'),

                    'desc'     => wp_kses_post(__('<small><i>If set this field to -1 all items will be included.</i></small>', 'dpr-adeline-extensions')),

                    'min'      => '-1',

                    'step'     => '1',

                    'max'      => '200',

                    'hint'     => array(

                        'title'   => esc_attr__('Blog Items Count', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('You can set blog items to display. If you set to -1 will be included all items.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'blog_query_orderby',

                    'type'     => 'select',

                    'title'    => __('Order By', 'dpr-adeline-extensions'),

                    'required' => array('blog_use_query', 'equals', '1'),

                    'desc'     => wp_kses_post(__('<small><i>Sort retrieved blog items by parameter.</i></small>', 'dpr-adeline-extensions')),

                    'options'  => array(

                        'none'          => 'No Order',

                        'date'          => 'Date',

                        'title'         => 'Title',

                        'name'          => 'Slug',

                        'author'        => 'Author',

                        'ID'            => 'ID',

                        'comment_count' => 'Comment Count',

                        'random'        => 'Random',

                    ),

                    'hint'     => array(

                        'title'   => esc_attr__('Order By', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Sort retrieved blog items by parameter', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'blog_query_order',

                    'type'     => 'select',

                    'title'    => __('Order', 'dpr-adeline-extensions'),

                    'required' => array('portfolio_use_query', 'equals', '1'),

                    'desc'     => wp_kses_post(__('<small><i>Select the ascending or descending order</i></small>', 'dpr-adeline-extensions')),

                    'options'  => array(

                        'ASC'  => 'Ascending Order',

                        'DESC' => 'Decending Order',

                    ),

                    'hint'     => array(

                        'title'   => esc_attr__('Order', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Select the ascending or descending order', 'dpr-adeline-extensions'),

                    ),

                ),

            ),

        );

        $blog_metabox_sections[] = array(

            'title'    => esc_html__('Blog Page Options', 'dpr-adeline-extensions'),

            'subtitle' => esc_html__('', 'dpr-adeline-extensions'),

            'fields'   => array(

                array(

                    'id'    => 'blog_general_setting_info',

                    'type'  => 'info',

                    'style' => 'dpr-title',

                    'title' => wp_kses_post(__('<h3>General Setting</h3>', 'dpr-adeline-extensions')),

                ),

                array(

                    'id'      => 'blog_main_content_position',

                    'type'    => 'radio',

                    'title'   => __('Page Content Position', 'dpr-adeline-extensions'),

                    'options' => array(

                        'above'  => 'Above Blog List',

                        'bellow' => 'Bellow Blog List',

                    ),

                    'default' => 'above',

                    'hint'    => array(

                        'title'   => esc_attr__('Main Page Content Position', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set main page content (entered in WP editor or created in composer) position in relation to the blog', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'blog_headings_tag',

                    'type'     => 'select',

                    'title'    => esc_html__('Heading Tag', 'dpr-adeline-extensions'),

                    'desc'     => '',

                    'options'  => array(

                        'h1'   => esc_html__('H1', 'dpr-adeline-extensions'),

                        'h2'   => esc_html__('H2', 'dpr-adeline-extensions'),

                        'h3'   => esc_html__('H3', 'dpr-adeline-extensions'),

                        'h4'   => esc_html__('H4', 'dpr-adeline-extensions'),

                        'h5'   => esc_html__('H5', 'dpr-adeline-extensions'),

                        'h6'   => esc_html__('H6', 'dpr-adeline-extensions'),

                        'span' => esc_html__('span', 'dpr-adeline-extensions'),

                        'p'    => esc_html__('p', 'dpr-adeline-extensions'),

                        'div'  => esc_html__('div', 'dpr-adeline-extensions'),

                    ),

                    'hint'     => array(

                        'title'   => esc_attr__('Heading Tag', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('By default blog entry title is closed in H2 tag but you can select other tag . This options can be useful for SEO adjustement ', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('subheader_display', 'equals', '1'),

                ),

                array(

                    'id'    => 'blog_excerpt_length',

                    'type'  => 'slider',

                    'title' => __('Excerpt Length', 'dpr-adeline-extensions'),

                    'min'   => '1',

                    'step'  => '1',

                    'max'   => '300',

                    'desc'  => __('<i><small>Enter 300 to display full content.</small><i>', 'dpr-adeline-extensions'),

                    'hint'  => array(

                        'title'   => esc_attr__('Excerpt Length', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set excerpt length for blog items.If you set 300 will be displayed full content.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'    => 'blog_image_info',

                    'type'  => 'info',

                    'style' => 'dpr-title',

                    'title' => wp_kses_post(__('<h3>Blog Featured Image Setting</h3>', 'dpr-adeline-extensions')),

                ),

                array(

                    'id'    => 'blog_image_hover_overlay',

                    'type'  => 'switch',

                    'title' => esc_html__('Use Overlay On Image Hover', 'dpr-adeline-extensions'),

                    'hint'  => array(

                        'title'   => esc_attr__('Use Overlay On Image Hover', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Enable overlay on blog image hover.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'blog_image_hover_overlay_bg',

                    'type'     => 'color',

                    'title'    => __('Overlay Color', 'dpr-adeline-extensions'),

                    'output'   => array('background-color' => '.blog-entry.post .thumbnail .overlay'),

                    'hint'     => array(

                        'title'   => esc_attr__('Overlay Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set background color for blog image on hover overlay.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('blog_image_hover_overlay', 'equals', '1'),

                ),

                array(

                    'id'      => 'blog_image_width',

                    'type'    => 'dimensions',

                    'title'   => esc_html__('Custom Image Width (px)', 'dpr-adeline-extensions'),

                    'width'   => true,

                    'height'  => false,

                    'mode'    => array('width' => 'width', 'height' => 'height'),

                    'units'   => array('px'),

                    'default' => array(

                        'width' => '',

                    ),

                    'hint'    => array(

                        'title'   => esc_attr__('Custom Image Width', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Specify the cusrtom image width. In combination with custom image height bellow you can set custom featured image aspect ratio. If you leave this fields blank will be used original images size and aspect ratio.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'      => 'blog_image_height',

                    'type'    => 'dimensions',

                    'title'   => esc_html__('Custom Image Height (px)', 'dpr-adeline-extensions'),

                    'width'   => false,

                    'height'  => true,

                    'mode'    => array('width' => 'width', 'height' => 'height'),

                    'units'   => array('px'),

                    'default' => array(

                        'width' => '',

                    ),

                    'hint'    => array(

                        'title'   => esc_attr__('Custom Image Height', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Specify the cusrtom image height. In combination with custom image width above you can set custom featured image aspect ratio. If you leave this fields blank will be used original images size and aspect ratio.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'    => 'blog_style_info',

                    'type'  => 'info',

                    'style' => 'dpr-title',

                    'title' => wp_kses_post(__('<h3>Blog Style</h3>', 'dpr-adeline-extensions')),

                ),

                array(

                    'id'      => 'blog_style',

                    'type'    => 'image_select',

                    'title'   => __('Blog Style', 'dpr-adeline-extensions'),

                    'options' => array(

                        'large-image' => array(

                            'title' => esc_html__('Large Image', 'dpr-adeline-extensions'),

                            'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/blog-styles/large-images.png',

                        ),

                        'small-image' => array(

                            'title' => esc_html__('Small Image', 'dpr-adeline-extensions'),

                            'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/blog-styles/small-images.png',

                        ),

                        'posts-grid'  => array(

                            'title' => esc_html__('Grid', 'dpr-adeline-extensions'),

                            'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/blog-styles/grid.png',

                        ),

                    ),

                    'hint'    => array(

                        'title'   => esc_attr__('Blog Style', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Choose default blog style.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'      => 'blog_entry_style',

                    'type'    => 'image_select',

                    'title'   => __('Blog Entry Style', 'dpr-adeline-extensions'),

                    'options' => array(

                        'simple' => array(

                            'title' => esc_html__('Simple', 'dpr-adeline-extensions'),

                            'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/blog-styles/simple.png',

                        ),

                        'tiled'  => array(

                            'title' => esc_html__('Tiled', 'dpr-adeline-extensions'),

                            'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/blog-styles/tiled.png',

                        ),

                    ),

                    'hint'    => array(

                        'title'   => esc_attr__('Blog Entry Style', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Choose style for blog entries.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'blog_entry_shadow',

                    'type'     => 'select',

                    'title'    => esc_html__('Entry Shadow', 'dpr-adeline-extensions'),

                    'desc'     => '',

                    'options'  => array(

                        ''       => esc_html__('None', 'dpr-adeline-extensions'),

                        '1'      => esc_html__('Shadow Depth 1', 'dpr-adeline-extensions'),

                        '2'      => esc_html__('Shadow Depth 2', 'dpr-adeline-extensions'),

                        '3'      => esc_html__('Shadow Depth 3', 'dpr-adeline-extensions'),

                        '4'      => esc_html__('Shadow Depth 4', 'dpr-adeline-extensions'),

                        '5'      => esc_html__('Shadow Depth 5', 'dpr-adeline-extensions'),

                        '6'      => esc_html__('Shadow Depth 6', 'dpr-adeline-extensions'),

                        'custom' => esc_html__('Custom Shadow', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('blog_entry_style', 'equals', 'tiled'),

                    'hint'     => array(

                        'title'   => esc_attr__('Entry Shadow', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set shadow for blog entry.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'blog_entry_custom_shadow',

                    'type'     => 'dpr_box_shadow',

                    'title'    => wp_kses_post(__('Custom Box Shadow', 'dpr-adeline-extensions')),

                    'output'   => array('.blog-item.entry-style-tiled .blog-item-inner'),

                    'hint'     => array(

                        'title'   => esc_attr__('Custom Box Shadow', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Create custom box shadow.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('blog_entry_shadow', 'equals', 'custom'),

                ),

                array(

                    'id'       => 'blog_entry_shadow_hover',

                    'type'     => 'select',

                    'title'    => esc_html__('Entry Shadow: Hover', 'dpr-adeline-extensions'),

                    'desc'     => '',

                    'options'  => array(

                        ''       => esc_html__('None', 'dpr-adeline-extensions'),

                        '1'      => esc_html__('Shadow Depth 1', 'dpr-adeline-extensions'),

                        '2'      => esc_html__('Shadow Depth 2', 'dpr-adeline-extensions'),

                        '3'      => esc_html__('Shadow Depth 3', 'dpr-adeline-extensions'),

                        '4'      => esc_html__('Shadow Depth 4', 'dpr-adeline-extensions'),

                        '5'      => esc_html__('Shadow Depth 5', 'dpr-adeline-extensions'),

                        '6'      => esc_html__('Shadow Depth 6', 'dpr-adeline-extensions'),

                        'custom' => esc_html__('Custom Shadow', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('blog_entry_style', 'equals', 'tiled'),

                    'hint'     => array(

                        'title'   => esc_attr__('Entry Shadow: Hover', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set shadow for blog entry hover state.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'blog_entry_custom_shadow_hover',

                    'type'     => 'dpr_box_shadow',

                    'title'    => wp_kses_post(__('Custom Box Shadow: Hover', 'dpr-adeline-extensions')),

                    'output'   => array('.blog-item.entry-style-tiled .blog-item-inner:hover'),

                    'hint'     => array(

                        'title'   => esc_attr__('Custom Box Shadow: Hover', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Create custom box shadow for entry hover state.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('blog_entry_shadow_hover', 'equals', 'custom'),

                ),

                array(

                    'id'       => 'blog_entry_hover_animation',

                    'type'     => 'select',

                    'title'    => esc_html__('Entry Hover Animation', 'dpr-adeline-extensions'),

                    'desc'     => '',

                    'options'  => array(

                        'none'                     => esc_html__('None', 'dpr-adeline-extensions'),

                        'dpr-upscale-onhover-1'    => esc_html__('Scale Up 3%', 'dpr-adeline-extensions'),

                        'dpr-upscale-onhover-2'    => esc_html__('Scale Up 6%', 'dpr-adeline-extensions'),

                        'dpr-upscale-onhover-3'    => esc_html__('Scale Up 10%', 'dpr-adeline-extensions'),

                        'dpr-upscale-onhover-4'    => esc_html__('Scale Up 15%', 'dpr-adeline-extensions'),

                        'dpr-downscale-onhover-1'  => esc_html__('Scale Down 3%', 'dpr-adeline-extensions'),

                        'dpr-downscale-onhover-2'  => esc_html__('Scale Down 6%', 'dpr-adeline-extensions'),

                        'dpr-up-onhover-1'         => esc_html__('Move Up 5px', 'dpr-adeline-extensions'),

                        'dpr-up-onhover-2'         => esc_html__('Move Up 10px', 'dpr-adeline-extensions'),

                        'dpr-up-onhover-3'         => esc_html__('Move Up 15px', 'dpr-adeline-extensions'),

                        'dpr-up-onhover-4'         => esc_html__('Move Up 20px', 'dpr-adeline-extensions'),

                        'dpr-down-onhover-1'       => esc_html__('Move Down 5px', 'dpr-adeline-extensions'),

                        'dpr-down-onhover-2'       => esc_html__('Move Down 10px', 'dpr-adeline-extensions'),

                        'dpr-down-onhover-3'       => esc_html__('Move Down 15px', 'dpr-adeline-extensions'),

                        'dpr-down-onhover-4'       => esc_html__('Move Down 20px', 'dpr-adeline-extensions'),

                        'dpr-up-left-onhover-1'    => esc_html__('Move UpLeft 5px', 'dpr-adeline-extensions'),

                        'dpr-up-left-onhover-2'    => esc_html__('Move UpLeft 10px', 'dpr-adeline-extensions'),

                        'dpr-up-left-onhover-3'    => esc_html__('Move UpLeft 15px', 'dpr-adeline-extensions'),

                        'dpr-up-left-onhover-4'    => esc_html__('Move UpLeft 20px', 'dpr-adeline-extensions'),

                        'dpr-up-right-onhover-1'   => esc_html__('Move UpRight 5px', 'dpr-adeline-extensions'),

                        'dpr-up-right-onhover-2'   => esc_html__('Move UpRight 10px', 'dpr-adeline-extensions'),

                        'dpr-up-right-onhover-3'   => esc_html__('Move UpRight 15px', 'dpr-adeline-extensions'),

                        'dpr-up-right-onhover-4'   => esc_html__('Move UpRight 20px', 'dpr-adeline-extensions'),

                        'dpr-down-left-onhover-1'  => esc_html__('Move DownLeft 5px', 'dpr-adeline-extensions'),

                        'dpr-down-left-onhover-2'  => esc_html__('Move DownLeft 10px', 'dpr-adeline-extensions'),

                        'dpr-down-left-onhover-3'  => esc_html__('Move DownLeft 15px', 'dpr-adeline-extensions'),

                        'dpr-down-left-onhover-4'  => esc_html__('Move DownLeft 20px', 'dpr-adeline-extensions'),

                        'dpr-down-right-onhover-1' => esc_html__('Move DownRight 5px', 'dpr-adeline-extensions'),

                        'dpr-down-right-onhover-2' => esc_html__('Move DownRight 10px', 'dpr-adeline-extensions'),

                        'dpr-down-right-onhover-3' => esc_html__('Move DownRight 15px', 'dpr-adeline-extensions'),

                        'dpr-down-right-onhover-4' => esc_html__('Move DownRight 20px', 'dpr-adeline-extensions'),

                		'dpr-item-tilt' => esc_html__('Item Tilt', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('blog_entry_style', 'equals', 'tiled'),

                    'hint'     => array(

                        'title'   => esc_attr__('Entry Hover Animation', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set entry hover animation.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'blog_thumb_info',

                    'type'     => 'info',

                    'style'    => 'dpr-title',

                    'required' => array('blog_style', 'equals', 'small-image'),

                    'title'    => wp_kses_post(__('<h3>Small Image Style Settings</h3>', 'dpr-adeline-extensions')),

                ),

                array(

                    'id'       => 'blog_thumb_image_position',

                    'type'     => 'radio',

                    'title'    => __('Image Position', 'dpr-adeline-extensions'),

                    'required' => array('blog_style', 'equals', 'small-image'),

                    'options'  => array(

                        'left'        => 'Left',

                        'right'       => 'Right',

                        'alternately' => 'Alternately',

                    ),

                    'hint'     => array(

                        'title'   => esc_attr__('Image Position', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set image position', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'blog_thumb_image_vertical_position',

                    'type'     => 'radio',

                    'title'    => __('Image Vertical Position', 'dpr-adeline-extensions'),

                    'required' => array('blog_style', 'equals', 'small-image'),

                    'options'  => array(

                        'top'    => 'Top',

                        'center' => 'Center',

                        'bottom' => 'Bottom',

                    ),

                    'hint'     => array(

                        'title'   => esc_attr__('Image Vertical Position', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set image vertical position', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'blog_thumb_image_category',

                    'type'     => 'switch',

                    'title'    => esc_html__('Display Category', 'dpr-adeline-extensions'),

                    'required' => array('blog_style', 'equals', 'small-image'),

                    'hint'     => array(

                        'title'   => esc_attr__('Display Category', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Enable or disable display category link.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'blog_thumb_image_comments',

                    'type'     => 'switch',

                    'title'    => esc_html__('Display Comments', 'dpr-adeline-extensions'),

                    'required' => array('blog_style', 'equals', 'small-image'),

                    'hint'     => array(

                        'title'   => esc_attr__('Display Ccomments', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Enable or disable display comments.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'blog_thumb_image_author',

                    'type'     => 'switch',

                    'title'    => esc_html__('Display Author', 'dpr-adeline-extensions'),

                    'required' => array('blog_style', 'equals', 'small-image'),

                    'hint'     => array(

                        'title'   => esc_attr__('Display Author', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Enable or disable display author.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'blog_thumb_image_date',

                    'type'     => 'switch',

                    'title'    => esc_html__('Display Date', 'dpr-adeline-extensions'),

                    'required' => array('blog_style', 'equals', 'small-image'),

                    'hint'     => array(

                        'title'   => esc_attr__('Display Date', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Enable or disable display date.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'blog_thumb_category_color',

                    'type'     => 'color',

                    'title'    => __('Category Link Color', 'dpr-adeline-extensions'),

                    'output'   => array('.blog-item.small-image .blog-item-category a'),

                    'hint'     => array(

                        'title'   => esc_attr__('Category Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set category link color.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('blog_style', 'equals', 'small-image'),

                ),

                array(

                    'id'       => 'blog_thumb_category_color_hover',

                    'type'     => 'color',

                    'title'    => __('Category Link Color: Hover', 'dpr-adeline-extensions'),

                    'output'   => array('.blog-item.small-image .blog-item-category a:hover'),

                    'hint'     => array(

                        'title'   => esc_attr__('Category Link Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set category link color.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('blog_style', 'equals', 'small-image'),

                ),

                array(

                    'id'       => 'blog_thumb_comments_color',

                    'type'     => 'color',

                    'title'    => __('Comments Link Color', 'dpr-adeline-extensions'),

                    'output'   => array('.blog-item.small-image .blog-item-comments', '.blog-item.small-image .blog-item-comments a'),

                    'hint'     => array(

                        'title'   => esc_attr__('Category Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set comments link color.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('blog_style', 'equals', 'small-image'),

                ),

                array(

                    'id'       => 'blog_thumb_comments_color_hover',

                    'type'     => 'color',

                    'title'    => __('Comments Link Color: Hover', 'dpr-adeline-extensions'),

                    'output'   => array('.blog-item.small-image .blog-item-comments:hover', '.blog-item.small-image .blog-item-comments a:hover'),

                    'hint'     => array(

                        'title'   => esc_attr__('Comments Link Color: Hover', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set comments link hover color.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('blog_style', 'equals', 'small-image'),

                ),

                array(

                    'id'       => 'blog_thumb_author_color',

                    'type'     => 'color',

                    'title'    => __('Author Link Color', 'dpr-adeline-extensions'),

                    'output'   => array('.blog-item.small-image .blog-item-author', '.blog-item.small-image .blog-item-author a'),

                    'hint'     => array(

                        'title'   => esc_attr__('Author Link Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set author link color.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('blog_style', 'equals', 'small-image'),

                ),

                array(

                    'id'       => 'blog_thumb_author_color_hover',

                    'type'     => 'color',

                    'title'    => __('Author Link Color: Hover', 'dpr-adeline-extensions'),

                    'output'   => array('.blog-item.small-image .blog-item-author:hover', '.blog-item.small-image .blog-item-author a:hover'),

                    'hint'     => array(

                        'title'   => esc_attr__('Author Link Color: Hover', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set author link hover color.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('blog_style', 'equals', 'small-image'),

                ),

                array(

                    'id'       => 'blog_thumb_date_color',

                    'type'     => 'color',

                    'title'    => __('Date Color', 'dpr-adeline-extensions'),

                    'output'   => array('.blog-item.small-image .blog-item-date'),

                    'hint'     => array(

                        'title'   => esc_attr__('Date Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set date color.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('blog_style', 'equals', 'small-image'),

                ),

                array(

                    'id'       => 'blog_grid_info',

                    'type'     => 'info',

                    'style'    => 'dpr-title',

                    'required' => array('blog_style', 'equals', 'posts-grid'),

                    'title'    => wp_kses_post(__('<h3>Grid Style Settings</h3>', 'dpr-adeline-extensions')),

                ),

                array(

                    'id'       => 'blog_grid_image_size',

                    'type'     => 'radio',

                    'title'    => __('Image Size', 'dpr-adeline-extensions'),

                    'required' => array('blog_style', 'equals', 'posts-grid'),

                    'options'  => array(

                        'thumbnail'    => 'Thumbnail',

                        'medium'       => 'Medium',

                        'medium_large' => 'Medium Large',

                        'large'        => 'Large',

                    ),

                    'hint'     => array(

                        'title'   => esc_attr__('Image Size', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set size of images used to dispaly in grid. ', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'blog_grid_columns',

                    'type'     => 'radio',

                    'title'    => __('Columns Count', 'dpr-adeline-extensions'),

                    'required' => array('blog_style', 'equals', 'posts-grid'),

                    'options'  => array(

                        '2' => '2 Columns',

                        '3' => '3 Columns',

                        '4' => '4 Columns',

                        '5' => '5 Columns',

                        '6' => '6 Columns',

                    ),

                    'hint'     => array(

                        'title'   => esc_attr__('Columns Count', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set columns count in grid view. ', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'blog_grid_style',

                    'type'     => 'radio',

                    'title'    => __('Grid Style', 'dpr-adeline-extensions'),

                    'required' => array('blog_style', 'equals', 'posts-grid'),

                    'options'  => array(

                        'masonry'  => 'Masonry',

                        'fit-rows' => 'Fit Rows',

                    ),

                    'hint'     => array(

                        'title'   => esc_attr__('Grid Style', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Select grid style. ', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'blog_grid_equal_heights',

                    'type'     => 'switch',

                    'title'    => esc_html__('Use Equal Heights', 'dpr-adeline-extensions'),

                    'required' => array('blog_grid_style', 'equals', 'fit-rows'),

                    'hint'     => array(

                        'title'   => esc_attr__('Use Equal Heights', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Enable equal height items in row.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'blog_elements_info',

                    'type'     => 'info',

                    'style'    => 'dpr-title',

                    'required' => array('blog_style', 'not', 'small-image'),

                    'title'    => wp_kses_post(__('<h3>Blog Entry Elements Enabling && Positioning</h3>', 'dpr-adeline-extensions')),

                ),

                array(

                    'id'       => 'blog_item_elements',

                    'type'     => 'sorter',

                    'title'    => 'Blog Item Elements Order',

                    'required' => array('blog_style', 'not', 'small-image'),

                    'hint'     => array(

                        'title'   => esc_attr__('Blog Item Elements Order', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Enable or disable display of certain elements of blog item and set element order', 'dpr-adeline-extensions'),

                    ),

                    'options'  => array(

                        'enabled'  => array(

                            'featured_image' => 'Featured Image',

                            'title'          => 'Title',

                            'meta'           => 'Meta Data',

                            'content'        => 'Content',

                            'read_more'      => 'Read More',

                        ),

                        'disabled' => array(

                        ),

                    ),

                ),

                array(

                    'id'       => 'blog_item_meta',

                    'type'     => 'sorter',

                    'title'    => 'Blog Item Meta Data Order',

                    'required' => array('blog_style', 'not', 'small-image'),

                    'hint'     => array(

                        'title'   => esc_attr__('Blog Item Meta Data Order', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Enable or disable meta data display and set meta data order', 'dpr-adeline-extensions'),

                    ),

                    'options'  => array(

                        'enabled'  => array(

                            'date'     => 'Date',

                            'author'   => 'Author',

                            'category' => 'Category',

                            'comments' => 'Comments',

                        ),

                        'disabled' => array(

                        ),

                    ),

                ),

                array(

                    'id'    => 'blog_pagination_type_info',

                    'type'  => 'info',

                    'style' => 'dpr-title',

                    'title' => wp_kses_post(__('<h3>Pagination Style</h3>', 'dpr-adeline-extensions')),

                ),

                array(

                    'id'      => 'blog_pagination_type',

                    'type'    => 'radio',

                    'title'   => __('Pagination Style', 'dpr-adeline-extensions'),

                    'options' => array(

                        'default'         => 'Default',

                        'load_more'       => 'Load More Button',

                        'infinite_scroll' => 'Infinite Scroll',

                        'next_prev'       => 'Next / Prev',

                    ),

                    'hint'    => array(

                        'title'   => esc_attr__('Pagination Style', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set pagination style', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'blog_pagination_infinite_spinners',

                    'type'     => 'color',

                    'output'   => array('background-color' => '.loader-ellips__dot'),

                    'validate' => 'color',

                    'title'    => esc_html__('Spinners Color', 'dpr-adeline-extensions'),

                    'required' => array('blog_pagination_type', 'equals', array('infinite_scroll', 'load_more')),

                    'hint'     => array(

                        'title'   => esc_attr__('Spinners Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set color for loading spinners.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'blog_pagination_infinite_scroll_last_text',

                    'type'     => 'text',

                    'title'    => __('Infinite Scroll: Last Text', 'dpr-adeline-extensions'),

                    'required' => array('blog_pagination_type', 'equals', 'infinite_scroll'),

                    'hint'     => array(

                        'title'   => esc_attr__('Infinite Scroll: Last Text', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set infinite scroll last text.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'blog_pagination_infinite_scroll_error_text',

                    'type'     => 'text',

                    'title'    => __('Infinite Scroll: Error Text', 'dpr-adeline-extensions'),

                    'required' => array('blog_pagination_type', 'equals', 'infinite_scroll'),

                    'hint'     => array(

                        'title'   => esc_attr__('Infinite Scroll: Error Text', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set infinite scroll error text.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'blog_pagination_loadmore_button_text',

                    'type'     => 'text',

                    'title'    => __('Load More: Button Text', 'dpr-adeline-extensions'),

                    'required' => array('blog_pagination_type', 'equals', 'load_more'),

                    'hint'     => array(

                        'title'   => esc_attr__('Load More: Button Text', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set load more button text.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'blog_pagination_loadmore_nomore_text',

                    'type'     => 'text',

                    'title'    => __('Load More: End Text', 'dpr-adeline-extensions'),

                    'required' => array('blog_pagination_type', 'equals', 'load_more'),

                    'hint'     => array(

                        'title'   => esc_attr__('Load More: End Text', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set load more end text text.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'blog_pagination_loadmore_button_bg',

                    'type'     => 'color',

                    'output'   => array('background-color' => '.dp-adeline-loadmore-button'),

                    'validate' => 'color',

                    'title'    => esc_html__('Load More Button Background', 'dpr-adeline-extensions'),

                    'required' => array('blog_pagination_type', 'equals', 'load_more'),

                    'hint'     => array(

                        'title'   => esc_attr__('Load More Button Background', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set background color for load more button.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'blog_pagination_loadmore_button_text_color',

                    'type'     => 'color',

                    'output'   => array('color' => '.dp-adeline-loadmore-button', 'fill' => '.dp-adeline-loadmore-loading-icon', 'stroke' => '.dp-adeline-loadmore-loading-icon'),

                    'validate' => 'color',

                    'title'    => esc_html__('Load More Button Color', 'dpr-adeline-extensions'),

                    'required' => array('blog_pagination_type', 'equals', 'load_more'),

                    'hint'     => array(

                        'title'   => esc_attr__('ILoad More Button Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set color for load more button.', 'dpr-adeline-extensions'),

                    ),

                ),

            ),

        );

        return $blog_metabox_sections;

    }

endif;
