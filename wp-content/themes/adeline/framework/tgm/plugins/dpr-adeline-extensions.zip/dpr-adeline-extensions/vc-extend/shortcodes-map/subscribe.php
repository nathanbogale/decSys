<?php

// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}

/*

* Add-on Name: Featured box

*/



class WPBakeryShortCode_DPR_Subscribe extends WPBakeryShortCode {}



vc_map(

	array(

		'name'					=> esc_html__('DP Subscribe', 'dpr-adeline-extensions'),

		'base'					=> 'dpr_subscribe',

		"icon"					=> 'icon-dpr-subscribe',

		"class"					=> 'dpr_subscribe',

  		"category" =>array( esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions')),

		'description'			=> esc_html__('Display Google Feedburner subscribe form', 'dpr-adeline-extensions'),

		'params'				=> array(

			array(

				'heading'			=> esc_html__('Style', 'dpr-adeline-extensions'),

				'type'				=> 'dpr_image_select',

				'param_name'		=> 'style',

				'simple_mode'		=> false,

				'options'			=> array(

					'style-1'			=> array(

						'label'			=> esc_html__('Default', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'subscribe/style-1.png'

					),

					'style-2'			=> array(

						'label'			=> esc_html__('Inside', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'subscribe/style-2.png'

					),

					'style-3'			=> array(

						'label'			=> esc_html__('Outside', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'subscribe/style-3.png'

					),

					'style-4'			=> array(

						'label'			=> esc_html__('Minimal', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'subscribe/style-4.png'

					),

					'style-5'			=> array(

						'label'			=> esc_html__('Animated', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'subscribe/style-5.png'

					),

				),

			),

			array(

				'type'				=> 'textfield',

				'heading'			=> esc_html__('Button Text', 'dpr-adeline-extensions'),

				'param_name'		=> 'btn_text',

				'value'				=> esc_html__('Sign Up', 'dpr-adeline-extensions'),

				'edit_field_class' => 'vc_column vc_col-sm-6',

			),

			array(

				'type'				=> 'textfield',

				'heading'			=> esc_html__('Placeholder Text', 'dpr-adeline-extensions'),

				'param_name'		=> 'placeholder_text',

				'value'				=> esc_html__('Enter your email', 'dpr-adeline-extensions'),

				'edit_field_class' => 'vc_column vc_col-sm-6',

			),

			array(

				'type'				=> 'textfield',

				'heading'			=> esc_html__('Your Feedburner Feed Name', 'dpr-adeline-extensions'),

				'param_name'		=> 'feed_name',

				'value'				=> esc_html__('YourFeedEmail', 'dpr-adeline-extensions'),

				'description'		=> esc_html__('Setup guide', 'dpr-adeline-extensions') .' <a href="https://support.google.com/feedburner/answer/78978" target="_blank"> '.esc_html__('Adding FeedBurner Email', 'dpr-adeline-extensions').'</a>',

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Additional Settings', 'dpr-adeline-extensions' ),

				'param_name'       => 'extra_features_title',

				'edit_field_class' => 'vc_column vc_col-sm-12',

			),

		   vc_map_add_css_animation( false ),

		    array(

				'type' => 'textfield',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Extra Class Name', 'dpr-adeline-extensions'),

				'param_name' => 'el_class',

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Overall Style', 'dpr-adeline-extensions'),

				'param_name'		=> 'style_title_1',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set field and button border radius.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Field and Button Border radius', 'dpr-adeline-extensions'),

				'param_name'		=> 'border_radius',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to choose the horizontal alignment for the button.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Alignment', 'dpr-adeline-extensions'),

				'param_name'		=> 'button_alignment',

				'value'				=> 'left-align',

				'options'			=> array(

					esc_html__('Left', 'dpr-adeline-extensions')	=> 'left-align',

					esc_html__('Center', 'dpr-adeline-extensions')	=> 'center-align',

					esc_html__('Right', 'dpr-adeline-extensions')	=> 'right-align'

				),

				'edit_field_class'	=> 'vc_col-sm-8 vc_column ',

				'dependency'		=> array('element' => 'style', 'value' => array('style-5')),

				'group'				=> esc_attr__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Field style', 'dpr-adeline-extensions'),

				'param_name'		=> 'style_title_2',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose text color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Text color', 'dpr-adeline-extensions'),

				'param_name'		=> 'field_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose placeholder color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Placeholder color', 'dpr-adeline-extensions'),

				'param_name'		=> 'placeholder_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> '',

				'class'				=> 'separator',

				'param_name'		=> 'sep_1',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose field background color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Field Background Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'field_bg_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose field border color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Field border color', 'dpr-adeline-extensions'),

				'param_name'		=> 'field_border_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set field border width.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border width', 'dpr-adeline-extensions'),

				'param_name'		=> 'field_border_width',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Button style', 'dpr-adeline-extensions'),

				'param_name'		=> 'style_title_3',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom button text color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Text Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'btn_text_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom button text hover color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Text Color: Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'btn_text_color_hover',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> '',

				'class'				=> 'separator',

				'param_name'		=> 'sep_2',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom button background color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'btn_bg_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom button background hover color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background Color: Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'btn_bg_color_hover',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> '',

				'class'				=> 'separator',

				'param_name'		=> 'sep_3',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom button border color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'btn_border_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom button border hover color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border Color: Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'btn_border_color_hover',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			

			

		),

	)

);