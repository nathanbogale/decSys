<?php

if ( ! defined( 'ABSPATH' ) ) { exit; }



class WPBakeryShortCode_DPR_Hover_Animated_Stack extends WPBakeryShortCode {}



vc_map(

	array(

		'name'					=> esc_html__('DP Hover Animated Stack', 'dpr-adeline-extensions'),

		'base'					=> 'dpr_hover_animated_stack',

		'class'					=> '',

		'icon'					=> 'icon-hover-animated-stack',

  		"category" =>array( esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions')),

		"description" => esc_attr__('Hover animated stack of layers', 'dpr-adeline-extensions'),

		'params'				=> array(
	

			array(

			'type' => 'textfield',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Extra Class Name', 'dpr-adeline-extensions'),

			'param_name' => 'el_class',

			),
	
			array(

				'type'				=> 'dpr_switcher',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to enable or disable additional static content bellow animated stack.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Display Static Content Bellow', 'dpr-adeline-extensions'),

				'param_name'		=> 'static_content_show',

				'options'			=> array(

					'show'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_col-sm-6 vc_column '
			),
	
			array(

				'type'				=> 'number',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set stack min height.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Min Stack Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'min_height',

				'min'				=> 100,

				'suffix'  			=> 'px',

				'value' => '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',
	
				'group'				=> esc_html__('Animated Stack', 'dpr-adeline-extensions'),

			),
	

			array(

				'type'				=> 'param_group',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Add images to the strack, set postion, animation and animation delay.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('List of stack layers', 'dpr-adeline-extensions'),

				'param_name'		=> 'stack_layers',

				'params'			=> array(
	
					array(

						'type'				=> 'dpr_radio',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select layer type', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Layer type', 'dpr-adeline-extensions'),

						'param_name'		=> 'layer_type',

						'value'				=> 'image',

						'options'			=> array(

							esc_html__('Image', 'dpr-adeline-extensions')		=> 'image',

							esc_html__('Text', 'dpr-adeline-extensions')			=> 'text',
							
							esc_html__('Icon', 'dpr-adeline-extensions')			=> 'icon',							
							
							esc_html__('Inline SVG', 'dpr-adeline-extensions')	=> 'svg',
							
							esc_html__('HTML', 'dpr-adeline-extensions')			=> 'html',	

						),
	
						'admin_label'		=> true,

						'edit_field_class'	=> 'vc_col-sm-8 vc_column vc_column-with-padding'

					),
					
					array(

						'type'			=> 'attach_image',

						'heading'		=> esc_html__('Upload Image:', 'dpr-adeline-extensions'),

						'param_name'	=> 'image_id',	
						
						'edit_field_class'	=> 'vc_column vc_col-sm-6 vc_column-with-padding',

						'dependency'		=> array('element' => 'layer_type', 'value' => array('image'))


					),
	
					array(

					'type'				=> 'number',

					'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Set the custom size for the image. If you leave blank image will be displayed in original dimmensions', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Image Size', 'dpr-adeline-extensions'),

					'param_name'		=> 'img_size',

					'min'				=> 1,

					'suffix'  			=> 'px',

					'value' => '',

					'edit_field_class'	=> 'vc_column vc_col-sm-6  vc_column-with-padding',

					'dependency'		=> array('element' => 'layer_type', 'value' => array('image'))

				),


					array(

						'type'				=> 'textarea',

						'heading'			=> esc_html__('Text', 'dpr-adeline-extensions'),

						'param_name'		=> 'layer_text',
	
						'dependency'		=> array('element' => 'layer_type', 'value' => array('text'))

					),


					array(

						'type'				=> 'number',

						'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size. ', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

						'param_name'		=> 'text_font_size',

						'min'				=> 1,
						
						'value'				=> 27,

						'suffix'				=> 'px',

						'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

						'dependency'		=> array('element' => 'layer_type', 'value' => array('text'))

					),

					array(

						'type'				=> 'number',

						'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom text linne height.Default is 27px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

						'param_name'		=> 'text_line_height',

						'min'				=> 1,
	
						'value'				=> 27,

						'suffix'				=> 'px',

						'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

						'dependency'		=> array('element' => 'layer_type', 'value' => array('text'))

					),

					array(

						'type'				=> 'number',

						'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom text letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

						'param_name'		=> 'text_spacing',

						'min'				=> 1,

						'suffix'				=> 'px',

						'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

						'dependency'		=> array('element' => 'layer_type', 'value' => array('text'))

					),

					array(

						'type' => 'checkbox',

						'class' => '',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

						'param_name' => 'text_font_style',

						'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

						'value' => array(

								__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

								__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

								__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

							),

						'dependency'		=> array('element' => 'layer_type', 'value' => array('text'))

					),


					array(

						'type'				=> 'dpr_switcher',

						'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font. .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

						'param_name'		=> 'use_google_fonts',

						'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

						'options'			=> array(

							'yes'				=> array(

								'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

								'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

							),

						),

						'dependency'		=> array('element' => 'layer_type', 'value' => array('text'))

					),

					array(

						'type'				=> 'google_fonts',

						'param_name'		=> 'text_google_font',

						'settings'			=> array(

							'fields'			=> array(

								'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

								'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

							),

						),

						'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

						'dependency'		=> array('element' => 'use_google_fonts', 'value' => 'yes')

					),

					array(

						"type" => "dpr_icon_selector",

						"heading" => esc_attr__("Icon", 'dpr-adeline-extensions'),

						"param_name" => "icon",

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select icon.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon', 'dpr-adeline-extensions'),
						
						'dependency'		=> array('element' => 'layer_type', 'value' => array('icon'))
						

					),
	
					array(

					'type'				=> 'number',

					'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Set the custom size for the icon.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon Size', 'dpr-adeline-extensions'),

					'param_name'		=> 'icon_size',

					'min'				=> 1,

					'suffix'  			=> 'px',

					'value' => '50',

					'edit_field_class'	=> 'vc_column vc_col-sm-6  vc_column-with-padding',

					'dependency'		=> array('element' => 'layer_type', 'value' => array('icon'))

					),
	
					array(

						'type'       => 'textarea_raw_html',

						'heading'    => esc_html__('Inline SVG code', 'dpr-adeline-extensions'),

						'param_name' => 'inline_svg',

						'dependency'		=> array('element' => 'layer_type', 'value' => array('svg')),

						'description'        => 'Enter inline SVG code here. Please dont use inline style eg &lt;path style=&quot;fill: #fff;&quot; ... /&gt;',
						'value'      => '',

					),
					array(

					'type'				=> 'number',

					'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Set the custom size for the svg.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('SVG max width', 'dpr-adeline-extensions'),

					'param_name'		=> 'svg_size',

					'min'				=> 1,

					'suffix'  			=> 'px',

					'value' => '100',

					'edit_field_class'	=> 'vc_column vc_col-sm-6  vc_column-with-padding',

					'dependency'		=> array('element' => 'layer_type', 'value' => array('svg'))

				),

					array(

						'type'       => 'textarea_raw_html',

						'heading'    => esc_html__('HTML code', 'dpr-adeline-extensions'),

						'param_name' => 'html_code',

						'dependency'		=> array('element' => 'layer_type', 'value' => array('html')),
	
						'description'       => 'Enter HTML code for layer here',

						'value'      => '',

					),
					array(

						'type'				=> 'dpr_title',

						'text'				=> '',

						'param_name'		=> 'sep_1',

						'class'				=> '',

						'edit_field_class'	=> 'vc_column vc_col-sm-12',


					),


								
	
					array(

					'type'				=> 'dpr_radio',

					'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to choose the horizontal alignment of layer content.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Alignment', 'dpr-adeline-extensions'),

					'param_name'		=> 'content_alignment',

					'value'				=> 'center',

					'options'			=> array(

						esc_html__('Left', 'dpr-adeline-extensions')	=> 'left',

						esc_html__('Center', 'dpr-adeline-extensions')	=> 'center',

						esc_html__('Right', 'dpr-adeline-extensions')	=> 'right'

					),

					'edit_field_class'	=> 'vc_col-sm-6 vc_column'

				),

					array(

					'type'				=> 'dpr_radio',

					'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to choose the vertical alignment of layer content.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Vertical Alignment', 'dpr-adeline-extensions'),

					'param_name'		=> 'content_valignment',

					'value'				=> 'middle',

					'options'			=> array(

						esc_html__('Top', 'dpr-adeline-extensions')	=> 'top',

						esc_html__('Middle', 'dpr-adeline-extensions')	=> 'middle',

						esc_html__('Bottom', 'dpr-adeline-extensions')	=> 'bottom'

					),

					'edit_field_class'	=> 'vc_col-sm-6 vc_column ',	
	

				),


					array(

						'type'             => 'dpr_title',

						'text'             => esc_html__( 'Animation Settings', 'dpr-adeline-extensions' ),

						'param_name'       => 'animation_title',

						'edit_field_class' => 'vc_column vc_col-sm-12',

					),

					array(

						'type'				=> 'number',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set transition duration).', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Duration', 'dpr-adeline-extensions'),

						'param_name'		=> 'duration',

						'min'				=> 0,

						'suffix'  			=> 's',

						'value' => '1',
						
						'step' => 0.1,

						'edit_field_class'	=> 'vc_column vc_col-sm-4   '

					),

	
					array(

					'type' => 'dropdown',

					'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set transition timing function.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Timing function', 'dpr-adeline-extensions'),

					'param_name' => 'timing_function',

					'edit_field_class' => 'vc_column vc_col-sm-4',

					'value' => array(

							__('Ease', 'dpr-adeline-extensions') => 'ease',							
							
							__('Linear', 'dpr-adeline-extensions') => 'linear',

							__('Ease In', 'dpr-adeline-extensions') => 'ease-in',

							__('Ease Out', 'dpr-adeline-extensions') => 'ease-out',

							__('Ease In Out', 'dpr-adeline-extensions') => 'ease-in-out'

						   )

					),

					array(

						'type'				=> 'number',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set transition delay).', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Delay', 'dpr-adeline-extensions'),

						'param_name'		=> 'delay',

						'min'				=> 0,

						'suffix'  			=> 's',

						'value' => '',

						'edit_field_class'	=> 'vc_column vc_col-sm-4   '

					),


					array(

						'type'             => 'dpr_title',

						'text'             => esc_html__( 'Idle State', 'dpr-adeline-extensions' ),

						'param_name'       => 'idle_state_title',

						'edit_field_class' => 'vc_column vc_col-sm-12',

					),
	
					array(

						'type'				=> 'colorpicker',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose color for idle state', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color', 'dpr-adeline-extensions'),

						'param_name'		=> 'color_idle',

						'edit_field_class'	=> 'vc_col-sm-3 vc_column ',
	
						'dependency'		=> array('element' => 'layer_type', 'value' => array('text','icon','svg')),	

					),
	
					array(

					'type'				=> 'number',

					'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set opacity in idle state.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Opacity', 'dpr-adeline-extensions'),

					'param_name'		=> 'opacity_idle',

					'min'				=> 0,
					
					'max' 				=> 1,
	
					'step'				=> 0.01,

					'suffix'  			=> 's',

					'value' => '1',

					'edit_field_class'	=> 'vc_column vc_col-sm-3'

					),


					array(

						'type'             => 'dpr_title',

						'text'             => esc_html__( 'Hover State', 'dpr-adeline-extensions' ),

						'param_name'       => 'hover_state_title',

						'edit_field_class' => 'vc_column vc_col-sm-12',

					),	

					array(

						'type'				=> 'colorpicker',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose color for idle state', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color', 'dpr-adeline-extensions'),

						'param_name'		=> 'color_hover',

						'edit_field_class'	=> 'vc_col-sm-3 vc_column ',
	
						'dependency'		=> array('element' => 'layer_type', 'value' => array('text','icon','svg')),	

					),

					array(

					'type'				=> 'number',

					'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set opacity in hover state.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Opacity', 'dpr-adeline-extensions'),

					'param_name'		=> 'opacity_hover',

					'min'				=> 0,
					
					'max' 				=> 1,
	
					'step'				=> 0.01,

					'suffix'  			=> 's',

					'value' => '1',

					'edit_field_class'	=> 'vc_column vc_col-sm-3  '

					),


					array(

					'type'				=> 'number',

					'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set rtation in hover state.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Rotation', 'dpr-adeline-extensions'),

					'param_name'		=> 'rotate_hover',

					'min'				=> 360,
					
					'max' 				=> -360,
	
					'step'				=> 1,

					'suffix'  			=> 'deg',

					'value' => '0',

					'edit_field_class'	=> 'vc_column vc_col-sm-3'

					),

					array(

					'type'				=> 'number',

					'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set scale in hover state.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Scale', 'dpr-adeline-extensions'),

					'param_name'		=> 'scale_hover',

					'min'				=> 0,
					
					'max' 				=> 1,
	
					'step'				=> 0.1,

					'value' => '1',

					'edit_field_class'	=> 'vc_column vc_col-sm-3'

					),
	
					array(

					'type' => 'textfield',

					'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set translate X position in hover state.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Translate X', 'dpr-adeline-extensions'),

					'param_name' => 'translatex_hover',

					'edit_field_class'	=> 'vc_column vc_col-sm-6',
	
					),
	
					array(

					'type' => 'dropdown',

					'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set translate X units in hover state.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Units', 'dpr-adeline-extensions'),

					'param_name' => 'translatex_units_hover',

					'edit_field_class' => 'vc_column vc_col-sm-6',

					'value' => array(

							__('px', 'dpr-adeline-extensions') => 'px',							
							
							__('%', 'dpr-adeline-extensions') => '%',

							__('vw', 'dpr-adeline-extensions') => 'vw'

						   )

					),

					array(

					'type' => 'textfield',

					'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set translate Y position in hover state.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Translate Y', 'dpr-adeline-extensions'),

					'param_name' => 'translatey_hover',

					'edit_field_class'	=> 'vc_column vc_col-sm-6',
	
					),
	
					array(

					'type' => 'dropdown',

					'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set translate Y units in hover state.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Units', 'dpr-adeline-extensions'),

					'param_name' => 'translatey_units_hover',

					'edit_field_class' => 'vc_column vc_col-sm-6',

					'value' => array(

							__('px', 'dpr-adeline-extensions') => 'px',							
							
							__('%', 'dpr-adeline-extensions') => '%',

							__('vh', 'dpr-adeline-extensions') => 'vh'

						   )

					),
					
					array(

						'type' => 'textfield',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('If you wish to style particular layer differently, use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom Layer Class Name', 'dpr-adeline-extensions'),

						'param_name' => 'custom_layer_class',

					),


					),

				'group'				=> esc_html__('Animated Stack', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to choose the horizontal alignment for the featured box.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Alignment', 'dpr-adeline-extensions'),

				'param_name'		=> 'static_content_alignment',

				'value'				=> 'text-center',

				'options'			=> array(

					esc_html__('Left', 'dpr-adeline-extensions')	=> 'text-left',

					esc_html__('Center', 'dpr-adeline-extensions')	=> 'text-center',

					esc_html__('Right', 'dpr-adeline-extensions')	=> 'text-right'

				),

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',
	
				'dependency'		=> array('element' => 'static_content_show', 'value'   => 'show'),
				
				'group'				=> esc_html__('Static Content', 'dpr-adeline-extensions'),
			),


			array(

				'type'				=> 'textarea',

				'heading'			=> esc_html__('Title', 'dpr-adeline-extensions'),

				'param_name'		=> 'title',

				'value'				=> esc_html__('Box Title', 'dpr-adeline-extensions'),

				'admin_label'		=> true,
				
				'dependency'		=> array('element' => 'static_content_show', 'value'   => 'show'),

				'group'				=> esc_html__('Static Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'textfield',

				'heading'			=> esc_html__('Subtitle', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle',

				'value'				=> esc_html__('Subtitle', 'dpr-adeline-extensions'),
	
				'dependency'		=> array('element' => 'static_content_show', 'value'   => 'show'),

				'group'				=> esc_html__('Static Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'textarea',

				'heading'			=> esc_html__('Content', 'dpr-adeline-extensions'),

				'param_name'		=> 'main_content',

				'value'				=> esc_html__('Featured box content. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque mollis ex eu blandit scelerisque.', 'dpr-adeline-extensions'),
	
				'dependency'		=> array('element' => 'static_content_show', 'value'   => 'show'),

				'group'				=> esc_html__('Static Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select where the link should be applied.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Link aply to', 'dpr-adeline-extensions'),

				'param_name'		=> 'read_more',

				'value'				=> 'none',

				'options'			=> array(

					esc_html__('No Link', 'dpr-adeline-extensions')		=> 'none',

					esc_html__('Complete Box', 'dpr-adeline-extensions')	=> 'box',

					esc_html__('Box Title', 'dpr-adeline-extensions')		=> 'title',

					esc_html__('Read More', 'dpr-adeline-extensions')		=> 'more',

				),
	
				'dependency'		=> array('element' => 'static_content_show', 'value'   => 'show'),

				'group'				=> esc_html__('Static Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'vc_link',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Add a custom link or select existing page. You can remove existing link as well.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Link URL', 'dpr-adeline-extensions'),

				'param_name'		=> 'link',

				'dependency'		=> array('element' => 'read_more', 'value' => array('box','title','more')),

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',
	
				'group'				=> esc_html__('Static Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to enable or disable the Read more.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Display Read more button', 'dpr-adeline-extensions'),

				'param_name'		=> 'readmore_show',

				'options'			=> array(

					'show'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'dependency'		=> array('element' => 'read_more', 'value' => array('box','title','more')),

				'group'				=> esc_html__('Static Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose read more style.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Read more style', 'dpr-adeline-extensions'),

				'param_name'		=> 'readmore_style',

				'value'				=> 'button',

				'options'			=> array(

					esc_html__('Button', 'dpr-adeline-extensions')		=> 'button',

					esc_html__('Outlined Button', 'dpr-adeline-extensions') => 'button-outlined',

					esc_html__('Minimal', 'dpr-adeline-extensions')			=> 'minimal',

					esc_html__('Custom Button', 'dpr-adeline-extensions')	=> 'custom',

				),

				'dependency'		=> array('element' => 'readmore_show', 'value'   => 'show'),

				'group'				=> esc_html__('Static Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom button size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom button size', 'dpr-adeline-extensions'),

				'param_name'		=> 'custom_button_size',

				'value'				=> 'btn-sm',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'options'			=> array(

					esc_html__('Default', 'dpr-adeline-extensions')		=> '',

					esc_html__('Large', 'dpr-adeline-extensions') => 'btn-lg',

					esc_html__('Extra Large', 'dpr-adeline-extensions')	=> 'btn-xl',

					esc_html__('Small', 'dpr-adeline-extensions')	=> 'btn-sm',

				),

				'dependency'		=> array('element' => 'readmore_style', 'value'   => 'custom'),

				'group'				=> esc_html__('Static Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom button shape.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom button shape', 'dpr-adeline-extensions'),

				'param_name'		=> 'custom_button_shape',

				'value'				=> '',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'options'			=> array(

					esc_html__('Default', 'dpr-adeline-extensions')		=> '',

					esc_html__('Rounded', 'dpr-adeline-extensions') => 'btn-round',

					esc_html__('Circle', 'dpr-adeline-extensions')	=> 'btn-circle',

					esc_html__('Square', 'dpr-adeline-extensions')	=> 'btn-square',

				),

				'dependency'		=> array('element' => 'readmore_style', 'value'   => 'custom'),

				'group'				=> esc_html__('Static Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom button text color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'custom_button_color',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'dependency'		=> array('element' => 'readmore_style', 'value'   => array('custom','minimal')),

				'group'				=> esc_html__('Static Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom button text color hover', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'custom_button_color_hover',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'dependency'		=> array('element' => 'readmore_style', 'value'   => array('custom','minimal')),

				'group'				=> esc_html__('Static Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom button background color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background', 'dpr-adeline-extensions'),

				'param_name'		=> 'custom_button_bg_color',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'dependency'		=> array('element' => 'readmore_style', 'value'   => 'custom'),

				'group'				=> esc_html__('Static Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom button background color hover', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'custom_button_bg_color_hover',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'dependency'		=> array('element' => 'readmore_style', 'value'   => 'custom'),

				'group'				=> esc_html__('Static Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom button border color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border', 'dpr-adeline-extensions'),

				'param_name'		=> 'custom_button_border_color',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'dependency'		=> array('element' => 'readmore_style', 'value'   => 'custom'),

				'group'				=> esc_html__('Static Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom button border color hover', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'custom_button_border_color_hover',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'dependency'		=> array('element' => 'readmore_style', 'value'   => 'custom'),

				'group'				=> esc_html__('Static Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'textfield',

				'heading'			=> esc_html__('Read more text', 'dpr-adeline-extensions'),

				'param_name'		=> 'readmore_text',

				'value'				=> esc_html__('Read more', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'readmore_show', 'value'   => 'show'),

				'group'				=> esc_html__('Static Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Title Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_typography_head',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'static_content_show', 'value'   => 'show'),

				'group'				=> esc_attr__('Content Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom ttle color. Default is headings color set in template options.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'static_content_show', 'value'   => 'show'),

				'group'				=> esc_html__('Content Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size.Default is 18px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'static_content_show', 'value'   => 'show'),

				'group'				=> esc_html__('Content Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title linne height.Default is 18px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'static_content_show', 'value'   => 'show'),

				'group'				=> esc_html__('Content Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'static_content_show', 'value'   => 'show'),

				'group'				=> esc_html__('Content Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'title_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'dependency'		=> array('element' => 'static_content_show', 'value'   => 'show'),

				'group'				=> esc_html__('Content Typography', 'dpr-adeline-extensions'),

	  		),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title color in hover state.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color: Hover State', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_color_hover',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'static_content_show', 'value'   => 'show'),

				'group'				=> esc_html__('Content Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font. .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_title_google_fonts',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'dependency'		=> array('element' => 'static_content_show', 'value'   => 'show'),

				'group'				=> esc_html__('Content Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'title_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'dependency'		=> array('element' => 'use_title_google_fonts', 'value' => 'yes'),

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Subtitle Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_typography_head',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'static_content_show', 'value'   => 'show'),

				'group'				=> esc_html__('Content Typography', 'dpr-adeline-extensions'),

			),

			

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom subtitle color. Default is #808080.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'static_content_show', 'value'   => 'show'),
	
				'group'				=> esc_html__('Content Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size.Default is 13px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'static_content_show', 'value'   => 'show'),

				'group'				=> esc_html__('Content Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom linne height.Default is 28px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'static_content_show', 'value'   => 'show'),

				'group'				=> esc_html__('Content Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'static_content_show', 'value'   => 'show'),

				'group'				=> esc_html__('Content Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'subtitle_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'dependency'		=> array('element' => 'static_content_show', 'value'   => 'show'),

				'group'				=> esc_html__('Content Typography', 'dpr-adeline-extensions'),

	  		),



			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom subtitle color in hover state.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__(' Color:Hover State', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_color_hover',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'dependency'		=> array('element' => 'static_content_show', 'value'   => 'show'),

				'group'				=> esc_html__('Content Typography', 'dpr-adeline-extensions'),

			),



						

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Content Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'content_typgraphy_head',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'static_content_show', 'value'   => 'show'),

				'group'				=> esc_attr__('Content Typography', 'dpr-adeline-extensions'),

			),

			

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom content color. Default is text color set in template options.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'content_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'static_content_show', 'value'   => 'show'),

				'group'				=> esc_html__('Content Typography', 'dpr-adeline-extensions'),

			),

			

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size.Default text font size set in template options .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'content_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'static_content_show', 'value'   => 'show'),

				'group'				=> esc_html__('Content Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title linne height. Default is text line height set in template options .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'content_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'static_content_show', 'value'   => 'show'),

				'group'				=> esc_html__('Content Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'content_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'static_content_show', 'value'   => 'show'),

				'group'				=> esc_html__('Content Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'content_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'dependency'		=> array('element' => 'static_content_show', 'value'   => 'show'),

				'group'				=> esc_html__('Content Typography', 'dpr-adeline-extensions'),

	  		),



			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom content color in hover state.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color: Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'content_color_hover',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'dependency'		=> array('element' => 'static_content_show', 'value'   => 'show'),

				'group'				=> esc_html__('Content Typography', 'dpr-adeline-extensions'),

			),


			
			array(

				'type' => 'css_editor',

				'heading' => __( 'CSS box', 'dpr-adeline-extensions' ),

				'param_name' => 'css',

				'group' => __( 'Design Options', 'dpr-adeline-extensions' ),

			),


		),

		

	)

);