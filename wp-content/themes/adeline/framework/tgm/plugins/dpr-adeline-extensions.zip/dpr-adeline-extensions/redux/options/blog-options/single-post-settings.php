<?php



/**



 * Blog -> Single Post Options



 * 



 */







	Redux::setSection( $opt_name, array(



		'title' => esc_html__('Single Post Options', 'dpr-adeline-extensions'),



		'id' => 'blog_single_settings',



		'subsection' => true,



		'fields' => array(



						array(



							'id'   => 'blog_single_setting_info',



							'type' => 'info',



							'style' => 'dpr-title',



							'title' => wp_kses_post(__('<h3>General Setting</h3>', 'dpr-adeline-extensions')),



						),



						array (



							'id' => 'blog_single_layout',



							'type' => 'image_select',



							'title' => __('General Layout', 'dpr-adeline-extensions'),



							'options' => array (



								'right-sidebar' => array (



									'title' => esc_html__('Sidebar right', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/sidebar_right.png'



								),					



								'left-sidebar' => array (



									'title' => esc_html__('Sidebar left', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/sidebar_left.png'



								),



								'both-sidebars' => array (



									'title' => esc_html__('Both sidebars', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/sidebar_both.png'



								),



	



								'full-width' => array (



									'title' => esc_html__('Full width', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/sidebar_disabled.png',	



								),



								'full-screen' => array (



									'title' => esc_html__('Full screen', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/full_screen.png',	



								),



							),



							'default' => 'right-sidebar',



							'hint' => array (



								'title' => esc_attr__('Blog && Archives Pages Layout', 'dpr-adeline-extensions'),



								'content' => esc_attr__('Choose default single post layoyt eg sidebar position.', 'dpr-adeline-extensions')



							)



						),



						array (



							'id' => 'blog_single_both_sidebars_column_order',



							'type' => 'image_select',



							'title' => __('Both Sidebars: Column Order', 'dpr-adeline-extensions'),



							'options' => array (



								'order-scs' => array (



									'title' => esc_html__('Sidebar/Content/Sidebar', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/scs.png'



								),					



								'order-ssc' => array (



									'title' => esc_html__('Sidebar/Sidebar/Content', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/ssc.png'



								),



								'order-css' => array (



									'title' => esc_html__('Content/Sidebar/Sidebar', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/css.png'



								),



							),



							'default' => 'order-scs',



							'hint' => array (



								'title' => esc_attr__('Both Sidebars: Column Order', 'dpr-adeline-extensions'),



								'content' => esc_attr__('Choose default column order. This general settings can be overwriten for specific pages.', 'dpr-adeline-extensions')



							),



							'required' => array('blog_single_layout','equals','both-sidebars')



						),



						array(



							'id' => 'blog_single_headings_tag',



							'type' => 'select',



							'title' => esc_html__('Heading Tag', 'dpr-adeline-extensions'),



							'desc' => '',



							'options' => array(



								'h1' => esc_html__('H1', 'dpr-adeline-extensions'),



								'h2' => esc_html__('H2', 'dpr-adeline-extensions'),



								'h3' => esc_html__('H3', 'dpr-adeline-extensions'),



								'h4' => esc_html__('H4', 'dpr-adeline-extensions'),



								'h5' => esc_html__('H5', 'dpr-adeline-extensions'),



								'h6' => esc_html__('H6', 'dpr-adeline-extensions'),



								'span' => esc_html__('span', 'dpr-adeline-extensions'),



								'p' => esc_html__('p', 'dpr-adeline-extensions'),



								'div' => esc_html__('div', 'dpr-adeline-extensions'),



							),



							'default' => 'h2',



							'hint' => array(



								'title'   => esc_attr__('Heading Tag','dpr-adeline-extensions'),



								'content' =>  esc_attr__('By default post title is closed in H2 tag but you can select other tag . This options can be useful for SEO adjustement ','dpr-adeline-extensions')



							),



							'required' => array('subheader_display','equals','1')



						),



						array(



							'id'       => 'blog_single_subheader_title',



							'type'     => 'radio',



							'title'    => __('Title In Subheader', 'dpr-adeline-extensions'), 



							'options'  => array(



								'blog' => 'Blog Title', 



								'post-title' => 'Post Title'



							),



							'default' => 'post-title',



							'hint' => array(



								'title'   => esc_attr__('Title In Subheader','dpr-adeline-extensions'),



								'content' => esc_attr__('You can select title to display in subheader area','dpr-adeline-extensions')



							),



						),



						array(



							'id'       => 'blog_single_next_prev_taxonomy',



							'type'     => 'radio',



							'title'    => __('Next/Prev Links Taxonomy', 'dpr-adeline-extensions'),



							'options'  => array(



								'category' => 'Category', 



								'post_tag' => 'Post Tag'



							),



							'default' => 'category',



							'hint' => array(



								'title'   => esc_attr__('Next/Prev Links Taxonomy','dpr-adeline-extensions'),



								'content' => esc_attr__('Set taxonomy for Next/Prev links. ','dpr-adeline-extensions')



							),



						),



						array(



							'id'   => 'blog_single_elements_info',



							'type' => 'info',



							'style' => 'dpr-title',



							'title' => wp_kses_post(__('<h3>Elements & Meta Data</h3>', 'dpr-adeline-extensions')),



						),



						array(



							'id'      => 'blog_single_elements',



							'type'    => 'sorter',



							'title'   => 'Single Post Elements Order',



							'hint' => array(



								'title'   => esc_attr__('Single Post Elements Order','dpr-adeline-extensions'),



								'content' => esc_attr__('Enable or disable display of certain elements for single post and set element order','dpr-adeline-extensions')



							),



							'options' => array(



								'enabled'  => array(



									'featured_image' => 'Featured Image',



									'title'   => 'Title',



									'meta' => 'Meta Data',



									'content'     => 'Content',



									'tags' => 'Tags',



									'social_share' => 'Social Share',



									'next_prev' => 'Next Prev Links',



									'related' => 'Related Posts',



									'comments' => 'Comments',



									'author_info' => 'Author Info Box',



								),



								'disabled' => array(



								)



							)



						),



						array(



							'id'      => 'blog_single_meta',



							'type'    => 'sorter',



							'title'   => 'Single Post Meta Data Order',



							'hint' => array(



								'title'   => esc_attr__('Single Post Meta Data Order','dpr-adeline-extensions'),



								'content' => esc_attr__('Enable or disable meta data display for single post and set meta data order','dpr-adeline-extensions')



							),



							'options' => array(



								'enabled'  => array(



									'date' => 'Date',



									'author'   => 'Author',



									'category' => 'Category',



									'comments' => 'Comments'



								),



								'disabled' => array(



								)



							)



						),



						array(



							'id'   => 'blog_single_related_info',



							'type' => 'info',



							'style' => 'dpr-title',



							'title' => wp_kses_post(__('<h3>Related Posts Settings</h3>', 'dpr-adeline-extensions')),



						),



						array(



							'id'       => 'blog_single_related_title',



							'type'     => 'text',



							'title'    => __('Related Posts Block Title', 'dpr-adeline-extensions'),



							'default'  => 'Related Posts',



							'hint' => array(



								'title'   => esc_attr__('Related Posts Block Title','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Set title for related post block.','dpr-adeline-extensions')



							),



						),



						array(



							'id'       => 'blog_single_related_taxonomy',



							'type'     => 'radio',



							'title'    => __('Related Posts Taxonomy', 'dpr-adeline-extensions'),



							'options'  => array(



								'category' => 'Category', 



								'post_tag' => 'Post Tag'



							),



							'default' => 'category',



							'hint' => array(



								'title'   => esc_attr__('Related Posts Taxonomy','dpr-adeline-extensions'),



								'content' => esc_attr__('Set taxonomy for related posts. ','dpr-adeline-extensions')



							),



						),



						array(



							'id'       => 'blog_single_related_count',



							'type'     => 'slider', 



							'title'    => __('Related Post Count', 'dpr-adeline-extensions'),



							'default'  => '3',



							'min'      => '1',



							'step'     => '1',



							'max'      => '12',



							'hint' => array(



								'title'   => esc_attr__('Related Post Count','dpr-adeline-extensions'),



								'content' => esc_attr__('Set max count of related posts to display.','dpr-adeline-extensions')



							)



						),



						array(



							'id'       => 'blog_single_related_columns',



							'type'     => 'slider', 



							'title'    => __('Related Post Columns', 'dpr-adeline-extensions'),



							'default'  => '3',



							'min'      => '1',



							'step'     => '1',



							'max'      => '6',



							'hint' => array(



								'title'   => esc_attr__('Related Post Columns','dpr-adeline-extensions'),



								'content' => esc_attr__('Set columns count in related posts section.','dpr-adeline-extensions')



							)



						),



						array(



						'id' => 'blog_single_related_image_width',



						'type' => 'dimensions',



						'title' => esc_html__('Related Posts Image Custom Width (px)', 'dpr-adeline-extensions'),



						'width' => true,



						'height' => false,



						'mode' => array ('width' => 'width', 'height' => 'height'),



						'units' => array('px'),



						'default'  => array(



							'width' => ''



						),



						'hint' => array(



							'title'   => esc_attr__('Related Posts Image Custom Width','dpr-adeline-extensions'),



							'content' => esc_attr__('Specify the custom image width in related posts section. In combination with custom image height bellow you can set custom featured image aspect ratio. If you leave this fields blank will be used original images size and aspect ratio.','dpr-adeline-extensions')



						)



						),



						array(



						'id' => 'blog_single_related_image_height',



						'type' => 'dimensions',



						'title' => esc_html__('Related Posts Image Custom Height (px)', 'dpr-adeline-extensions'),



						'width' => false,



						'height' => true,



						'mode' => array ('width' => 'width', 'height' => 'height'),



						'units' => array('px'),



						'default'  => array(



							'width' => ''



						),



						'hint' => array(



							'title'   => esc_attr__('Related Posts Image Custom Height','dpr-adeline-extensions'),



							'content' => esc_attr__('Specify the custom image image height in related posts section. In combination with custom image width above you can set custom featured image aspect ratio. If you leave this fields blank will be used original images size and aspect ratio.','dpr-adeline-extensions')



						)



						),



				)



	));



