<?php

// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}



/*

  Shortcode: Carousel

 */



class WPBakeryShortCode_DPR_Shuffled_Images extends WPBakeryShortCode {

}



vc_map(

	array(

		'name' => esc_html__('DP Shuffled Images', 'dpr-adeline-extensions'),

		'base' => 'dpr_shuffled_images',

		'icon' => 'icon-dpr-shuffled-images',

		'class' => 'dpr_shuffled_images',

  		"category" =>array( esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions')),

		'description' => esc_html__('Shuffled images gallery'),

		'params' => array_merge(array(
	
	
			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to choose the shuffle direction.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Shuffle Direction', 'dpr-adeline-extensions'),

				'param_name'		=> 'shuffle_direction',

				'value'				=> 'left',

				'options'			=> array(

					esc_html__('Left', 'dpr-adeline-extensions')	=> 'left',


					esc_html__('Right', 'dpr-adeline-extensions')	=> 'right'

				),

				'edit_field_class'	=> 'vc_col-sm-6 vc_column vc_column-with-padding'

			),

			array(

			'type'				=> 'dpr_switcher',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('This option allows you to animate element on appear.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Appear Animation?', 'dpr-adeline-extensions'),

			'param_name'		=> 'appear_animation',

			'options'			=> array(

				'yes'		=> array(

					'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

					'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

				),

			),

			'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

			),

	
			array(
				'type' => 'attach_images',
				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select images for shuffled element.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Images', 'dpr-adeline-extensions'),
				'param_name' => 'images',
				'value' => '',
				'description' => esc_html__( 'Select images from media library.The number of images should not exceed 5 to achieve the optimal appearance of the element', 'js_composer' ),
			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Additional Settings', 'dpr-adeline-extensions' ),

				'param_name'       => 'extra_features_title',

				'edit_field_class' => 'vc_column vc_col-sm-12',

			),
	

			array(

			'type' => 'textfield',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Extra Class Name', 'dpr-adeline-extensions'),

			'param_name' => 'el_class',

			),
	
			array(

				'type' => 'css_editor',

				'heading' => __( 'CSS box', 'dpr-adeline-extensions' ),

				'param_name' => 'css',

				'group' => __( 'Design Options', 'dpr-adeline-extensions' ),

			),

							

			)),


	)

);

