<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$unique_id = $css_animation = $el_class = $output = $custom_el_css = $style = '';
$image_id = $use_link = $link_aply_to = $box_link = '';
$title = $title_color = $title_font_size = $title_line_height  = $title_letter_spacing = $title_font_style = $title_google_font = $title_typo_style = '';
$subtitle = $subtitle_color = $subtitle_font_size = $subtitle_line_height  = $subtitle_letter_spacing = $subtitle_font_style = $subtitle_google_font = $subtitle_typo_style = '';
$description = $content_color = $content_font_size = $content_line_height  = $content_letter_spacing = $content_font_style = $content_google_font = $content_typo_style = '';
$text_alignment = $img_border_radius = $enable_shadow = $shadow_visibility = $image_shadow = $icon_size = $icon_color = $overlay_color_hover = $enable_idle_overlay = $overlay_color_idle = '';
$fliper_height = $fliper_back_color = $flip_style = $social_networks = '';
$image_html = $idle_overlay_html = $hover_overlay_html = $title_html = $subtitle_html = $description_html = $box_link_html = $title_link_html = $social_html = '';


$atts = vc_map_get_attributes( 'dpr_team_box', $atts );
extract( $atts );

$el_class = $this->getExtraClass( $el_class );
if ( '' !== $css_animation && 'none' !== $css_animation ) {
	dpr_enqueue_waypoint_js();
	dpr_enqueue_animate_css();
	$el_class .= ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
}
$unique_id = uniqid('dpr-team-box-').'-'.rand(1,9999);

/* Element classes */
if(isset($style)) {
	$el_class .= ' '.$style;
}
if(isset($text_alignment)) {
	$el_class .= ' text-'.$text_alignment;
}
if($style == 'style-8' || $style == 'style-9') {
	$el_class .= ' dpr-flip-item';
	$el_class .= ' '.$flip_style;
}
$css_classes = array(
	'dpr-team-box',
	esc_attr($unique_id),
	$el_class,
);

$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->settings['base'], $atts ) );

/* * ************************
 * Styles and custom CSS
 * *********************** */
if (isset($overlay_color_hover) && $overlay_color_hover != '') {
	$custom_el_css .= '.'.esc_js($unique_id).':hover .overlay-hover {background-color:'.esc_attr($overlay_color_hover).';}';
}
if (isset($fliper_back_color) && $fliper_back_color != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .flip-wrap .flip-wrap-back {background-color:'.esc_attr($fliper_back_color).';}';
}
if (isset($img_border_radius) && $img_border_radius != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .image-wrap, .'.esc_js($unique_id).' .flip-wrap  {border-radius:'.esc_attr($img_border_radius).'px;}';
}
if (isset($icon_color) && $icon_color != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .dpr-adeline-social-block ul li a:not(:hover) {color:'.esc_attr($icon_color).' !important;}';
}
if (isset($icon_size) && $icon_size != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .dpr-adeline-social-block ul li a {font-size:'.esc_attr($icon_size).'px;}';
}
if (isset($enable_shadow) && $enable_shadow == 'yes') {
	if(dpr_shadow_param_to_css($image_shadow) != '') {
		if(isset($shadow_visibility) && $shadow_visibility == 'allways') {
			$custom_el_css .= '.'.esc_js($unique_id) .' .image-wrap {'.dpr_shadow_param_to_css($image_shadow).'}';
		}
		if(isset($shadow_visibility) && $shadow_visibility == 'onhover') {
			$custom_el_css .= '.'.esc_js($unique_id) .':hover .image-wrap {'.dpr_shadow_param_to_css($image_shadow).'}';
		}
	}
}


/* * ************************
 * Partial HTML.
 * *********************** */

/* Box Link */
if(isset($use_link) && $use_link  == 'yes') {
	$box_link_attributes    = array();
	if (function_exists('vc_build_link')) {
		$box_link = ( '||' === $box_link ) ? '' : $box_link;
		$box_link = vc_build_link( $box_link );
	
		$link_href   = $box_link['url'];
		$link_title  = $box_link['title'];
		$link_rel  = $box_link['rel'];
		$link_target = strlen($box_link['target']) > 0 ? $box_link['target'] : '_self';
	
		$box_link_attributes[] = 'href="' . esc_url( trim( $link_href ) ) . '"';
		$box_link_attributes[] = 'title="' . esc_attr( trim( $link_title ) ) . '"';
		$box_link_attributes[] = 'target="' . esc_attr( trim( $link_target ) ) . '"';
		$box_link_attributes[] = 'rel="' . esc_attr( trim( $link_rel ) ) . '"';
	}
	if($box_link['url'] != '' && $link_aply_to == 'image') {
			$box_link_html .= '<a class="dpr-cover-link" '.implode(' ',$box_link_attributes).'></a>';
	}
	if($box_link['url'] != '' && $link_aply_to == 'title') {
			$title_link_html .= '<a class="dpr-cover-link" '.implode(' ',$box_link_attributes).'></a>';
	}
}
/* Image and overlays*/
if(isset($image_id) && $image_id != '') {
	$image = dpr_get_attachment_image_src($image_id, 'full');
	$alt_text = get_post_meta($image_id , '_wp_attachment_image_alt', true);
	$image_html .= '<img src="'.esc_url($image[0]).'" alt ="'.esc_attr($alt_text).'"/>';
}

/* Title */
if(!empty($title)) {
	$title_typo_style = dpr_generate_typography_style($title_color, $title_font_size, $title_line_height, $title_letter_spacing, $title_font_style,$title_google_font);
	$title_html .= '<h4 class="title" ' . $title_typo_style . '>' . $title . '</h4>';
	$title_html .= $title_link_html;
}
/* Subtitle */
if(!empty($subtitle)) {
	$subtitle_typo_style = dpr_generate_typography_style($subtitle_color, $subtitle_font_size, $subtitle_line_height, $subtitle_letter_spacing, $subtitle_font_style,$subtitle_google_font);
	$subtitle_html .= '<div class="subtitle" ' . $subtitle_typo_style . '>' . $subtitle . '</div>';
}
/* Description */
if(!empty($description)) {
	$content_typo_style = dpr_generate_typography_style($content_color, $content_font_size, $content_line_height, $content_letter_spacing, $content_font_style,$content_google_font);
	$description_html .= '<div class="box-content" ' . $content_typo_style . '>' . wp_kses_post($description) . '</div>';
}
/* Social Links */
$social_html .='<div class="dpr-adeline-social-block clr">';
if(isset($social_networks) && !empty($social_networks) && function_exists('vc_param_group_parse_atts')) {
$social_html .= '<div class="social-menu-inner clr minimal-social text-center"><ul>';	
$social_networks = (array) vc_param_group_parse_atts($social_networks);
	foreach($social_networks as $item) {
			$link_attr = 'href="#"';
			if(isset($item['link']) ) {
				$link = $item['link'];
				$link = vc_build_link($link);
					$link_target = !empty($link['target']) ? 'target="'.esc_attr(preg_replace('/\s+/', '', $link['target'])).'"' : '';
					if($link['url'] != '' ) {
						$link_attr = 'href="'.esc_url($link['url']).'" title="'.esc_attr($link['title']).'" '.$link_target.' rel="'.esc_attr($link['rel']).'"';
					}
			}
			if(isset($item['network'])) {
			$social_html .= '<li class="dpr-adeline-'.esc_attr($item['network']).'"><a '.$link_attr.'><span class="dpr-icon-'.esc_attr($item['network']).'"></span></a></li>';	
			}
	}
$social_html .= '</ul></div>';	
}
$social_html .= '</div>'; 

/* Overlays */
if(isset($enable_idle_overlay) && $enable_idle_overlay == 'yes') {
	$idle_overlay_html .= '<span class="overlay-idle"></span>';
	if(isset($idle_overlay_gradient) && !empty($idle_overlay_gradient)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .overlay-idle {'.esc_js(adeline_gradientToBgCSS ($idle_overlay_gradient)).';}';
	}
}
$hover_overlay_html = '<span class="overlay-hover"></span>';

/* * ************************
 * Output
 * *********************** */
$output .= '<div id="'.esc_attr($unique_id).'" class="'.esc_attr($css_class).'">';
switch ($style) {
	case 'style-1':
		$output .= '<div class="image-wrap">';
		$output .= $image_html;
		$output .= $box_link_html;
		$output .= '</div>';
		$output .= '<div class="box-content-wrap">';
		$output .= '<div class="box-title">';
		$output .= $title_html;
		$output .= $subtitle_html;
		$output .= '</div>';
		$output .= $description_html;
		$output .=  $social_html;
		$output .= '</div>';
		break;
	case 'style-2':
		$output .= '<div class="box-title">';
		$output .= $title_html;
		$output .= $subtitle_html;
		$output .= '</div>';
		$output .= '<div class="image-wrap">';
		$output .= $image_html;
		$output .= $box_link_html;
		$output .= '</div>';
		$output .= '<div class="box-content-wrap">';
		$output .= $description_html;
		$output .=  $social_html;
		$output .= '</div>';
		break;
	case 'style-3':
		$output .= '<div class="image-wrap">';
		$output .= $image_html;
		$output .= $idle_overlay_html;
		$output .= $box_link_html;
		$output .= '<div class="box-title">';
		$output .= $title_html;
		$output .= $subtitle_html;
		$output .= '</div>';
		$output .= '</div>';
		$output .= '<div class="box-content-wrap">';
		$output .= $description_html;
		$output .=  $social_html;
		$output .= '</div>';
		break;
	case 'style-4':
		$output .= '<div class="image-wrap">';
		$output .= $image_html;
		$output .= $box_link_html;
		$output .= '</div>';
		$output .= '<div class="box-content-wrap">';
		$output .= '<div class="box-title">';
		$output .= $title_html;
		$output .= $subtitle_html;
		$output .= '</div>';
		$output .= $description_html;
		$output .=  $social_html;
		$output .= '</div>';
		break;
	case 'style-5':
		$output .= '<div class="box-content-wrap">';
		$output .= '<div class="box-title">';
		$output .= $title_html;
		$output .= $subtitle_html;
		$output .= '</div>';
		$output .= $description_html;
		$output .=  $social_html;
		$output .= '</div>';
		$output .= '<div class="image-wrap">';
		$output .= $image_html;
		$output .= $box_link_html;
		$output .= '</div>';
		break;
	case 'style-6':
		$output .= '<div class="image-wrap">';
		$output .= $image_html;
		$output .= $idle_overlay_html;
		$output .= $hover_overlay_html;
		$output .= '<div class="box-title">';
		$output .= $title_html;
		$output .= $subtitle_html;
		$output .= '</div>';
		$output .= '<div class="box-title second">';
		$output .= $title_html;
		$output .= $subtitle_html;
		$output .= '</div>';
		$output .= '<div class="box-content-wrap">';
		$output .= $description_html;
		$output .=  $social_html;
		$output .= '</div>';		
		$output .= $box_link_html;
		$output .= '</div>';
		break;
	case 'style-7':
		$output .= '<div class="image-wrap">';
		$output .= $image_html;
		$output .= $hover_overlay_html;
		$output .= '<div class="box-title second">';
		$output .= $title_html;
		$output .= $subtitle_html;
		$output .= '</div>';
		$output .= '<div class="box-content-wrap">';
		$output .= $description_html;
		$output .=  $social_html;
		$output .= '</div>';
		$output .= $box_link_html;
		$output .= '</div>';
		break;
	case 'style-8':
		$output .= '<div class="flip-wrap">';
		$output .= '<div class="flip-wrap-front">';
		$output .= '<div class="image-wrap">';
		$output .= $image_html;
		$output .= $idle_overlay_html;
		$output .= '<div class="content-wrap">';
		$output .= '<div class="box-title second">';
		$output .= $title_html;
		$output .= $subtitle_html;
		$output .= '</div>';
		$output .= '</div>';	
		$output .= '</div>';
		$output .= '</div>';
		$output .= '<div class="flip-wrap-back">';
		$output .= '<div class="content-wrap">';
		$output .= '<div class="box-title">';
		$output .= $title_html;
		$output .= $subtitle_html;
		$output .= '</div>';
		$output .= '<div class="box-content-wrap">';
		$output .= $description_html;
		$output .=  $social_html;
		$output .= '</div>';
		$output .= $box_link_html;
		$output .= '</div>';		
		$output .= '</div>';
		$output .= '</div>';
		break;
	case 'style-9':
		$output .= '<div class="flip-wrap">';
		$output .= '<div class="flip-wrap-front">';
		$output .= '<div class="image-wrap">';
		$output .= $image_html;
		$output .= '<div class="content-wrap">';
		$output .= '</div>';	
		$output .= '</div>';
		$output .= '</div>';
		$output .= '<div class="flip-wrap-back">';
		$output .= '<div class="content-wrap">';
		$output .= '<div class="box-title">';
		$output .= $title_html;
		$output .= $subtitle_html;
		$output .= '</div>';
		$output .= '<div class="box-content-wrap">';
		$output .= $description_html;
		$output .=  $social_html;
		$output .= '</div>';
		$output .= $box_link_html;
		$output .= '</div>';		
		$output .= '</div>';
		$output .= '</div>';
		break;


}
if(!empty($custom_el_css)) {
		$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>");'
						. '})(jQuery);'
					. '</script>';
}

$output .= '</div>';
echo $output;


