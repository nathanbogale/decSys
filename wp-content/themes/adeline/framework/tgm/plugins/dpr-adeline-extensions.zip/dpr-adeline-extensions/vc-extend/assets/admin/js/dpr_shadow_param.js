/**
 * Backend JS for shadow param
 */
!function(a){if(!a.wp.wpColorPicker.prototype._hasAlpha){var b="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAIAAAHnlligAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAHJJREFUeNpi+P///4EDBxiAGMgCCCAGFB5AADGCRBgYDh48CCRZIJS9vT2QBAggFBkmBiSAogxFBiCAoHogAKIKAlBUYTELAiAmEtABEECk20G6BOmuIl0CIMBQ/IEMkO0myiSSraaaBhZcbkUOs0HuBwDplz5uFJ3Z4gAAAABJRU5ErkJggg==",c='<div class="wp-picker-holder" />',d='<div class="wp-picker-container" />',e='<input type="button" class="button button-small" />',f=void 0!==wpColorPickerL10n.current;if(f)var g='<a tabindex="0" class="wp-color-result" />';else var g='<button type="button" class="button wp-color-result" aria-expanded="false"><span class="wp-color-result-text"></span></button>',h="<label></label>",i='<span class="screen-reader-text"></span>';Color.fn.toString=function(){if(this._alpha<1)return this.toCSS("rgba",this._alpha).replace(/\s+/g,"");var a=parseInt(this._color,10).toString(16);return this.error?"":(a.length<6&&(a=("00000"+a).substr(-6)),"#"+a)},a.widget("wp.wpColorPicker",a.wp.wpColorPicker,{_hasAlpha:!0,_create:function(){if(a.support.iris){var j=this,k=j.element;if(a.extend(j.options,k.data()),"hue"===j.options.type)return j._createHueOnly();j.close=a.proxy(j.close,j),j.initialValue=k.val(),k.addClass("wp-color-picker"),f?(k.hide().wrap(d),j.wrap=k.parent(),j.toggler=a(g).insertBefore(k).css({backgroundColor:j.initialValue}).attr("title",wpColorPickerL10n.pick).attr("data-current",wpColorPickerL10n.current),j.pickerContainer=a(c).insertAfter(k),j.button=a(e).addClass("hidden")):(k.parent("label").length||(k.wrap(h),j.wrappingLabelText=a(i).insertBefore(k).text(wpColorPickerL10n.defaultLabel)),j.wrappingLabel=k.parent(),j.wrappingLabel.wrap(d),j.wrap=j.wrappingLabel.parent(),j.toggler=a(g).insertBefore(j.wrappingLabel).css({backgroundColor:j.initialValue}),j.toggler.find(".wp-color-result-text").text(wpColorPickerL10n.pick),j.pickerContainer=a(c).insertAfter(j.wrappingLabel),j.button=a(e)),j.options.defaultColor?(j.button.addClass("wp-picker-default").val(wpColorPickerL10n.defaultString),f||j.button.attr("aria-label",wpColorPickerL10n.defaultAriaLabel)):(j.button.addClass("wp-picker-clear").val(wpColorPickerL10n.clear),f||j.button.attr("aria-label",wpColorPickerL10n.clearAriaLabel)),f?k.wrap('<span class="wp-picker-input-wrap" />').after(j.button):(j.wrappingLabel.wrap('<span class="wp-picker-input-wrap hidden" />').after(j.button),j.inputWrapper=k.closest(".wp-picker-input-wrap")),k.iris({target:j.pickerContainer,hide:j.options.hide,width:j.options.width,mode:j.options.mode,palettes:j.options.palettes,change:function(c,d){j.options.alpha?(j.toggler.css({"background-image":"url("+b+")"}),f?j.toggler.html('<span class="color-alpha" />'):(j.toggler.css({position:"relative"}),0==j.toggler.find("span.color-alpha").length&&j.toggler.append('<span class="color-alpha" />')),j.toggler.find("span.color-alpha").css({width:"45px",height:"45px",position:"absolute",top:0,left:0,"border-top-left-radius":"2px","border-bottom-left-radius":"2px",background:d.color.toString()})):j.toggler.css({backgroundColor:d.color.toString()}),a.isFunction(j.options.change)&&j.options.change.call(this,c,d)}}),k.val(j.initialValue),j._addListeners(),j.options.hide||j.toggler.click()}},_addListeners:function(){var b=this;b.wrap.on("click.wpcolorpicker",function(a){a.stopPropagation()}),b.toggler.click(function(){b.toggler.hasClass("wp-picker-open")?b.close():b.open()}),b.element.on("change",function(c){(""===a(this).val()||b.element.hasClass("iris-error"))&&(b.options.alpha?(f&&b.toggler.removeAttr("style"),b.toggler.find("span.color-alpha").css("backgroundColor","")):b.toggler.css("backgroundColor",""),a.isFunction(b.options.clear)&&b.options.clear.call(this,c))}),b.button.on("click",function(c){a(this).hasClass("wp-picker-clear")?(b.element.val(""),b.options.alpha?(f&&b.toggler.removeAttr("style"),b.toggler.find("span.color-alpha").css("backgroundColor","")):b.toggler.css("backgroundColor",""),a.isFunction(b.options.clear)&&b.options.clear.call(this,c)):a(this).hasClass("wp-picker-default")&&b.element.val(b.options.defaultColor).change()})}}),a.widget("a8c.iris",a.a8c.iris,{_create:function(){if(this._super(),this.options.alpha=this.element.data("alpha")||!1,this.element.is(":input")||(this.options.alpha=!1),"undefined"!=typeof this.options.alpha&&this.options.alpha){var b=this,c=b.element,d='<div class="iris-strip iris-slider iris-alpha-slider"><div class="iris-slider-offset iris-slider-offset-alpha"></div></div>',e=a(d).appendTo(b.picker.find(".iris-picker-inner")),f=e.find(".iris-slider-offset-alpha"),g={aContainer:e,aSlider:f};"undefined"!=typeof c.data("custom-width")?b.options.customWidth=parseInt(c.data("custom-width"))||0:b.options.customWidth=100,b.options.defaultWidth=c.width(),(b._color._alpha<1||-1!=b._color.toString().indexOf("rgb"))&&c.width(parseInt(b.options.defaultWidth+b.options.customWidth)),a.each(g,function(a,c){b.controls[a]=c}),b.controls.square.css({"margin-right":"0"});var h=b.picker.width()-b.controls.square.width()-20,i=h/6,j=h/2-i;a.each(["aContainer","strip"],function(a,c){b.controls[c].width(j).css({"margin-left":i+"px"})}),b._initControls(),b._change()}},_initControls:function(){if(this._super(),this.options.alpha){var a=this,b=a.controls;b.aSlider.slider({orientation:"vertical",min:0,max:100,step:1,value:parseInt(100*a._color._alpha),slide:function(b,c){a._color._alpha=parseFloat(c.value/100),a._change.apply(a,arguments)}})}},_change:function(){this._super();var a=this,c=a.element;if(this.options.alpha){var d=a.controls,e=parseInt(100*a._color._alpha),f=a._color.toRgb(),g=["rgb("+f.r+","+f.g+","+f.b+") 0%","rgba("+f.r+","+f.g+","+f.b+", 0) 100%"],h=a.options.defaultWidth,i=a.options.customWidth,j=a.picker.closest(".wp-picker-container").find(".wp-color-result");d.aContainer.css({background:"linear-gradient(to bottom, "+g.join(", ")+"), url("+b+")"}),j.hasClass("wp-picker-open")&&(d.aSlider.slider("value",e),a._color._alpha<1?(d.strip.attr("style",d.strip.attr("style").replace(/rgba\(([0-9]+,)(\s+)?([0-9]+,)(\s+)?([0-9]+)(,(\s+)?[0-9\.]+)\)/g,"rgb($1$3$5)")),c.width(parseInt(h+i))):c.width(h))}var k=c.data("reset-alpha")||!1;k&&a.picker.find(".iris-palette-container").on("click.palette",".iris-palette",function(){a._color._alpha=1,a.active="external",a._change()})},_addInputListeners:function(a){var b=this,c=100,d=function(c){var d=new Color(a.val()),e=a.val();a.removeClass("iris-error"),d.error?""!==e&&a.addClass("iris-error"):d.toString()!==b._color.toString()&&("keyup"===c.type&&e.match(/^[0-9a-fA-F]{3}$/)||b._setOption("color",d.toString()))};a.on("change",d).on("keyup",b._debounce(d,c)),b.options.hide&&a.on("focus",function(){b.show()})}})}}(jQuery),jQuery(document).ready(function(a){a(".color-picker").wpColorPicker()});

function hex2rgba(hex, alpha) {
    var r = parseInt(hex.slice(1, 3), 16),
        g = parseInt(hex.slice(3, 5), 16),
        b = parseInt(hex.slice(5, 7), 16);

    if (alpha) {
        return "rgba(" + r + ", " + g + ", " + b + ", " + alpha + ")";
    } else {
        return "rgb(" + r + ", " + g + ", " + b + ")";
    }
}
function rgb2hex(rgb){
 if (rgb.substr(0, 1) === '#') {
        return rgb;
    }
 rgb = rgb.match(/^rgba?[\s+]?\([\s+]?(\d+)[\s+]?,[\s+]?(\d+)[\s+]?,[\s+]?(\d+)[\s+]?/i);
 return (rgb && rgb.length === 4) ? "#" +
  ("0" + parseInt(rgb[1],10).toString(16)).slice(-2) +
  ("0" + parseInt(rgb[2],10).toString(16)).slice(-2) +
  ("0" + parseInt(rgb[3],10).toString(16)).slice(-2) : '';
}
function genParamValue(style,color,hor,ver,bl,spr,css){
	return ( style + '|' + color + '|' + hor + '|' + ver + '|' + bl + '|' + spr + '|' +css );
}
function genShadowCss($style, $color, $hor, $ver, $bl, $spr){
	if ($style == 'none' ) {
		return '';
	}
	else if ($style =='custom') {
		if ($hor == '') $hor = 0;
		if ($ver == '') $ver = 0;
		if ($bl == '') $bel = 0;
		if ($spr == '') $spr = 0;
		if ($color == '') $color = rgba(0,0,0,0);
	    return 'box-shadow: '+ $hor + 'px ' + $ver +'px ' + $bl + 'px ' + $spr + 'px ' + $color;
	} else {
		var $hexColor = rgb2hex( $color );

		switch($style) {
			case 'd1':
	    		return 'box-shadow: 0 1px 3px '+ hex2rgba($hexColor,0.2) + ',0 1px 1px '+ hex2rgba($hexColor,0.14) + ',0 2px 1px -1px '+ hex2rgba($hexColor,0.12);
				break;
			case 'u1':
	    		return 'box-shadow: 0 -1px 3px '+ hex2rgba($hexColor,0.2) + ',0 -1px 1px '+ hex2rgba($hexColor,0.14) + ',0 -2px 1px -1px '+ hex2rgba($hexColor,0.12);
				break;
			case 'd2':
	    		return 'box-shadow: 0 1px 5px '+ hex2rgba($hexColor,0.2) + ',0 2px 2px '+ hex2rgba($hexColor,0.14) + ',0 3px 1px -2px '+ hex2rgba($hexColor,0.12);
				break;
			case 'u2':
	    		return 'box-shadow: 0 -1px 5px '+ hex2rgba($hexColor,0.2) + ',0 -2px 2px '+ hex2rgba($hexColor,0.14) + ',0 -3px 1px -2px '+ hex2rgba($hexColor,0.12);
				break;
			case 'd3':
	    		return 'box-shadow: 0 1px 8px '+ hex2rgba($hexColor,0.2) + ',0 3px 4px '+ hex2rgba($hexColor,0.14) + ',0 3px 3px -2px '+ hex2rgba($hexColor,0.12);
				break;
			case 'u3':
	    		return 'box-shadow: 0 -1px 8px '+ hex2rgba($hexColor,0.2) + ',0 -3px 4px '+ hex2rgba($hexColor,0.14) + ',0 -3px 3px -2px '+ hex2rgba($hexColor,0.12);
				break;
			case 'd4':
	    		return 'box-shadow: 0 2px 4px -1px '+ hex2rgba($hexColor,0.2) + ',0 4px 5px '+ hex2rgba($hexColor,0.14) + ',0 1px 10px '+ hex2rgba($hexColor,0.12);
				break;
			case 'u4':
	    		return 'box-shadow: 0 -2px 4px -1px '+ hex2rgba($hexColor,0.2) + ',0 -4px 5px '+ hex2rgba($hexColor,0.14) + ',0 -1px 10px '+ hex2rgba($hexColor,0.12);
				break;
			case 'd5':
	    		return 'box-shadow: 0 3px 5px -1px '+ hex2rgba($hexColor,0.2) + ',0 5px 8px '+ hex2rgba($hexColor,0.14) + ',0 1px 14px '+ hex2rgba($hexColor,0.12);
				break;
			case 'u5':
	    		return 'box-shadow: 0 -3px 5px -1px '+ hex2rgba($hexColor,0.2) + ',0 -5px 8px '+ hex2rgba($hexColor,0.14) + ',0 -1px 14px '+ hex2rgba($hexColor,0.12);
				break;
			case 'd6':
	    		return 'box-shadow: 0 3px 5px -1px '+ hex2rgba($hexColor,0.2) + ',0 6px 10px '+ hex2rgba($hexColor,0.14) + ',0 1px 18px '+ hex2rgba($hexColor,0.12);
				break;
			case 'u6':
	    		return 'box-shadow: 0 -3px 5px -1px '+ hex2rgba($hexColor,0.2) + ',0 -6px 10px '+ hex2rgba($hexColor,0.14) + ',0 -1px 18px '+ hex2rgba($hexColor,0.12);
				break;
			case 'd7':
	    		return 'box-shadow: 0 4px 5px -2px '+ hex2rgba($hexColor,0.2) + ',0 7px 10px 1px '+ hex2rgba($hexColor,0.14) + ',0 2px 16px 1px '+ hex2rgba($hexColor,0.12);
				break;
			case 'u7':
	    		return 'box-shadow: 0 -4px 5px -2px '+ hex2rgba($hexColor,0.2) + ',0 -7px 10px 1px '+ hex2rgba($hexColor,0.14) + ',0 -2px 16px 1px '+ hex2rgba($hexColor,0.12);
				break;
			case 'd8':
	    		return 'box-shadow: 0 5px 5px -3px '+ hex2rgba($hexColor,0.2) + ',0 8px 10px 1px '+ hex2rgba($hexColor,0.14) + ',0 3px 14px 2px '+ hex2rgba($hexColor,0.12);
				break;
			case 'u8':
	    		return 'box-shadow: 0 -5px 5px -3px '+ hex2rgba($hexColor,0.2) + ',0 -8px 10px 1px '+ hex2rgba($hexColor,0.14) + ',0 -3px 14px 2px '+ hex2rgba($hexColor,0.12);
				break;
			case 'd9':
	    		return 'box-shadow: 0 5px 6px -3px '+ hex2rgba($hexColor,0.2) + ',0 9px 12px 1px '+ hex2rgba($hexColor,0.14) + ',0 3px 16px 2px '+ hex2rgba($hexColor,0.12);
				break;
			case 'u9':
	    		return 'box-shadow: 0 -5px 6px -3px '+ hex2rgba($hexColor,0.2) + ',0 -9px 12px 1px '+ hex2rgba($hexColor,0.14) + ',0 -3px 16px 2px '+ hex2rgba($hexColor,0.12);
				break;
			case 'd10':
	    		return 'box-shadow: 0 6px 6px -3px '+ hex2rgba($hexColor,0.2) + ',0 10px 14px 1px '+ hex2rgba($hexColor,0.14) + ',0 4px 18px 3px '+ hex2rgba($hexColor,0.12);
				break;
			case 'u10':
	    		return 'box-shadow: 0 -6px 6px -3px '+ hex2rgba($hexColor,0.2) + ',0 -10px 14px 1px '+ hex2rgba($hexColor,0.14) + ',0 -4px 18px 3px '+ hex2rgba($hexColor,0.12);
				break;
			case 'd11':
	    		return 'box-shadow: 0 6px 7px -4px '+ hex2rgba($hexColor,0.2) + ',0 11px 15px 1px '+ hex2rgba($hexColor,0.14) + ',0 4px 20px 3px '+ hex2rgba($hexColor,0.12);
				break;
			case 'u11':
	    		return 'box-shadow: 0 -6px 7px -4px '+ hex2rgba($hexColor,0.2) + ',0 -11px 15px 1px '+ hex2rgba($hexColor,0.14) + ',0 -4px 20px 3px '+ hex2rgba($hexColor,0.12);
				break;
			case 'd12':
	    		return 'box-shadow: 0 7px 8px -4px '+ hex2rgba($hexColor,0.2) + ',0 12px 17px 2px '+ hex2rgba($hexColor,0.14) + ',0 5px 22px 4px '+ hex2rgba($hexColor,0.12);
				break;
			case 'u12':
	    		return 'box-shadow: 0 -7px 8px -4px '+ hex2rgba($hexColor,0.2) + ',0 -12px 17px 2px '+ hex2rgba($hexColor,0.14) + ',0 -5px 22px 4px '+ hex2rgba($hexColor,0.12);
				break;
			case 'd13':
	    		return 'box-shadow: 0 7px 8px -4px '+ hex2rgba($hexColor,0.2) + ',0 13px 19px 2px '+ hex2rgba($hexColor,0.14) + ',0 5px 24px 4px '+ hex2rgba($hexColor,0.12);
				break;
			case 'u13':
	    		return 'box-shadow: 0 -7px 8px -4px '+ hex2rgba($hexColor,0.2) + ',0 -13px 19px 2px '+ hex2rgba($hexColor,0.14) + ',0 -5px 24px 4px '+ hex2rgba($hexColor,0.12);
				break;
			case 'd14':
	    		return 'box-shadow: 0 7px 9px -4px '+ hex2rgba($hexColor,0.2) + ',0 14px 21px 2px '+ hex2rgba($hexColor,0.14) + ',0 5px 26px 4px '+ hex2rgba($hexColor,0.12);
				break;
			case 'u14':
	    		return 'box-shadow: 0 -7px 9px -4px '+ hex2rgba($hexColor,0.2) + ',0 -14px 21px 2px '+ hex2rgba($hexColor,0.14) + ',0 -5px 26px 4px '+ hex2rgba($hexColor,0.12);
				break;
			case 'd15':
	    		return 'box-shadow: 0 8px 9px -5px '+ hex2rgba($hexColor,0.2) + ',0 15px 22px 2px '+ hex2rgba($hexColor,0.14) + ',0 6px 28px 5px '+ hex2rgba($hexColor,0.12);
				break;
			case 'u15':
	    		return 'box-shadow: 0 -8px 9px -5px '+ hex2rgba($hexColor,0.2) + ',0 -15px 22px 2px '+ hex2rgba($hexColor,0.14) + ',0 -6px 28px 5px '+ hex2rgba($hexColor,0.12);
				break;
			case 'd16':
	    		return 'box-shadow: 0 8px 10px -5px '+ hex2rgba($hexColor,0.2) + ',0 16px 24px 2px '+ hex2rgba($hexColor,0.14) + ',0 6px 30px 5px '+ hex2rgba($hexColor,0.12);
				break;
			case 'u16':
	    		return 'box-shadow: 0 -8px 10px -5px '+ hex2rgba($hexColor,0.2) + ',0 -16px 24px 2px '+ hex2rgba($hexColor,0.14) + ',0 -6px 30px 5px '+ hex2rgba($hexColor,0.12);
				break;
			case 'd17':
	    		return 'box-shadow: 0 8px 11px -5px '+ hex2rgba($hexColor,0.2) + ',0 17px 26px 2px '+ hex2rgba($hexColor,0.14) + ',0 6px 32px 5px '+ hex2rgba($hexColor,0.12);
				break;
			case 'u17':
	    		return 'box-shadow: 0 -8px 11px -5px '+ hex2rgba($hexColor,0.2) + ',0 -17px 26px 2px '+ hex2rgba($hexColor,0.14) + ',0 -6px 32px 5px '+ hex2rgba($hexColor,0.12);
				break;
			case 'd18':
	    		return 'box-shadow: 0 9px 11px -5px '+ hex2rgba($hexColor,0.2) + ',0 18px 28px 2px '+ hex2rgba($hexColor,0.14) + ',0 7px 34px 6px '+ hex2rgba($hexColor,0.12);
				break;
			case 'u18':
	    		return 'box-shadow: 0 -9px 11px -5px '+ hex2rgba($hexColor,0.2) + ',0 -18px 28px 2px '+ hex2rgba($hexColor,0.14) + ',0 -7px 34px 6px '+ hex2rgba($hexColor,0.12);
				break;
			case 'd19':
	    		return 'box-shadow: 0 9px 12px -6px '+ hex2rgba($hexColor,0.2) + ',0 19px 29px 2px '+ hex2rgba($hexColor,0.14) + ',0 7px 36px 6px '+ hex2rgba($hexColor,0.12);
				break;
			case 'u19':
	    		return 'box-shadow: 0 -9px 12px -6px '+ hex2rgba($hexColor,0.2) + ',0 -19px 29px 2px '+ hex2rgba($hexColor,0.14) + ',0 -7px 36px 6px '+ hex2rgba($hexColor,0.12);
				break;
			case 'd20':
	    		return 'box-shadow: 0 10px 13px -6px '+ hex2rgba($hexColor,0.2) + ',0 20px 31px 3px '+ hex2rgba($hexColor,0.14) + ',0 8px 38px 7px '+ hex2rgba($hexColor,0.12);
				break;
			case 'u20':
	    		return 'box-shadow: 0 -10px 13px -6px '+ hex2rgba($hexColor,0.2) + ',0 -20px 31px 3px '+ hex2rgba($hexColor,0.14) + ',0 -8px 38px 7px '+ hex2rgba($hexColor,0.12);
				break;
			case 'd21':
	    		return 'box-shadow: 0 10px 13px -6px '+ hex2rgba($hexColor,0.2) + ',0 21px 33px 3px '+ hex2rgba($hexColor,0.14) + ',0 8px 40px 7px '+ hex2rgba($hexColor,0.12);
				break;
			case 'u21':
	    		return 'box-shadow: 0 -10px 13px -6px '+ hex2rgba($hexColor,0.2) + ',0 -21px 33px 3px '+ hex2rgba($hexColor,0.14) + ',0 -8px 40px 7px '+ hex2rgba($hexColor,0.12);
				break;
			case 'd22':
	    		return 'box-shadow: 0 10px 14px -6px '+ hex2rgba($hexColor,0.2) + ',0 22px 35px 3px '+ hex2rgba($hexColor,0.14) + ',0 8px 42px 7px '+ hex2rgba($hexColor,0.12);
				break;
			case 'u22':
	    		return 'box-shadow: 0 -10px 14px -6px '+ hex2rgba($hexColor,0.2) + ',0 -22px 35px 3px '+ hex2rgba($hexColor,0.14) + ',0 -8px 42px 7px '+ hex2rgba($hexColor,0.12);
				break;
			case 'd23':
	    		return 'box-shadow: 0 11px 14px -7px '+ hex2rgba($hexColor,0.2) + ',0 23px 36px 3px '+ hex2rgba($hexColor,0.14) + ',0 9px 44px 8px '+ hex2rgba($hexColor,0.12);
				break;
			case 'u23':
	    		return 'box-shadow: 0 -11px 14px -7px '+ hex2rgba($hexColor,0.2) + ',0 -23px 36px 3px '+ hex2rgba($hexColor,0.14) + ',0 -9px 44px 8px '+ hex2rgba($hexColor,0.12);
				break;
			case 'd24':
	    		return 'box-shadow: 0 11px 15px -7px '+ hex2rgba($hexColor,0.2) + ',0 24px 38px 3px '+ hex2rgba($hexColor,0.14) + ',0 9px 46px 8px '+ hex2rgba($hexColor,0.12);
				break;
			case 'u24':
	    		return 'box-shadow: 0 -11px 15px -7px '+ hex2rgba($hexColor,0.2) + ',0 -24px 38px 3px '+ hex2rgba($hexColor,0.14) + ',0 -9px 46px 8px '+ hex2rgba($hexColor,0.12);
				break;
		} 
	}
}


(function ($) {
	
'use strict';
vc.atts.dpr_shadow_picker = {
	
	init: function (param, $field) {
		$field.find(".shadow-color-control").wpColorPicker({
			palettes: true,
			
			change: function (event, ui) {
				//var paramVal,cssVal;
				var hexcolor = jQuery(this).wpColorPicker('color');
				$field.find(".shadow-color-selected").val(hexcolor);
				$field.find(".shadow-color-selected").change();
			},
			clear: function () {
				$field.find(".shadow-color-selected").val('');
			}
		});
		var paramValueArray = $field.find('.wpb_vc_param_value').val().split('|');
		$field.find('.vc-dpr-shadow-style').val(paramValueArray[0]);
		$field.find(".shadow-color-control").wpColorPicker('color',paramValueArray[1])
		$field.find('.shadow-color-selected').val(paramValueArray[1]);
		$field.find('.shadow-v').val(paramValueArray[2]);
		$field.find('.shadow-h').val(paramValueArray[3]);
		$field.find('.shadow-b').val(paramValueArray[4]);
		$field.find('.shasow-s').val(paramValueArray[5]);
		$field.find('.vc-dpr-shadow-preview-inner').attr('style',paramValueArray[6]);
		var currStyle = $field.find('.vc-dpr-shadow-style').val(),
			expandSection = function (val) {
				if (val == 'custom') {
					$field.find('.vc-dpr-shadow-custom').show();
				} else {
					$field.find('.vc-dpr-shadow-custom').hide();
				}
			};

		expandSection(currStyle);
		
		$field.find('.vc-dpr-shadow-style').on('change', function () {
			var paramVal,cssVal;
			if($field.find(".shadow-color-selected").val() == '' && jQuery(this).val() != 'none' ) {
				$field.find(".shadow-color-control").wpColorPicker('color','#000000')
			}
			if (jQuery(this).val() == 'none' ) {
				$field.find('.wp-picker-clear').trigger('click');
				$field.find(".shadow-color-selected").val('');
				$field.find(".shadow-v").val('');
				$field.find(".shadow-h").val('');
				$field.find(".shadow-b").val('');
				$field.find(".shadow-s").val('');			
			}
			expandSection($(this).val());
			cssVal = genShadowCss($field.find('.vc-dpr-shadow-style').val(),$field.find(".shadow-color-selected").val(),$field.find(".shadow-v").val(),$field.find(".shadow-h").val(),$field.find(".shadow-b").val(),$field.find(".shadow-s").val())
			paramVal = genParamValue( $field.find('.vc-dpr-shadow-style').val(),$field.find(".shadow-color-selected").val(),$field.find(".shadow-v").val(),$field.find(".shadow-h").val(),$field.find(".shadow-b").val(),$field.find(".shadow-s").val(), cssVal );
			$field.find('.dpr_shadow_picker').val(paramVal);
			$field.find('.vc-dpr-shadow-preview-inner').attr('style',cssVal);
		});
		
		$field.find('.shadow-v, .shadow-h, .shadow-b, .shadow-s,.shadow-color-selected').on('change', function () {
			var paramVal,cssVal;
			cssVal = genShadowCss($field.find('.vc-dpr-shadow-style').val(),$field.find(".shadow-color-selected").val(),$field.find(".shadow-v").val(),$field.find(".shadow-h").val(),$field.find(".shadow-b").val(),$field.find(".shadow-s").val())
			paramVal = genParamValue( $field.find('.vc-dpr-shadow-style').val(),$field.find(".shadow-color-selected").val(),$field.find(".shadow-v").val(),$field.find(".shadow-h").val(),$field.find(".shadow-b").val(),$field.find(".shadow-s").val(), cssVal );
			$field.find('.dpr_shadow_picker').val(paramVal);
			$field.find('.vc-dpr-shadow-preview-inner').attr('style',cssVal);
		});
		
	},
};
})(window.jQuery);

/*Box Shadow*/



