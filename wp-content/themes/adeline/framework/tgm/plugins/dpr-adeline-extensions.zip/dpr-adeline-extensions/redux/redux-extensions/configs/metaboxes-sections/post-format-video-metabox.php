<?php







if ( !function_exists( "dpr_post_format_video_sections " ) ):



    function dpr_post_format_video_sections() {



		/*



     	* ---> START POST FORMAT VIDEO METABOX SECTIONS



		*/







		$post_format_video_sections = array();



		$post_format_video_sections[] = array(



			'fields'   => array(



								array(



									'id'       => 'video_post_oembed_video_url',



									'type'     => 'text',



									'title'    => __('oEmbed Video URL ', 'dpr-adeline-extensions'), 



									'desc'     => __('Enter a video URL that is compatible with WordPress built-in oEmbed feature.<br/><a href="http://codex.wordpress.org/Embeds" target="_blank">Learn More</a>', 'dpr-adeline-extensions'),



									'default' => '',



								),



								array(



									'id' => 'video_post_self_hosted_video_url',



									'type' => 'media',



									'title' => esc_html__('Self Hosted Video', 'dpr-adeline-extensions'),



									'url' => true,



									'mode' => false,



									'readonly' => false,



									'preview' => false,



									'desc'     => __('Enter your self hosted video URL<br/><a href="http://make.wordpress.org/core/2013/04/08/audio-video-support-in-core/" target="_blank">Learn More</a>', 'dpr-adeline-extensions'),



								),



								array(



									'id'       => 'video_post_embeded_code',



									'title'    =>  __( 'Embed Code', 'dpr-adeline-extensions' ),



									'type'     => 'textarea',



									'default'  => '',



									'desc'     => __('Enter your embed/iframe code<br/><a href="https://wordpress.org/plugins/iframe/" target="_blank">Learn More</a>', 'dpr-adeline-extensions'),



								),



			)



		);



		



		/*



     	* ---> END POST FORMAT VIDEO METABOX SECTIONS



		*/



		







        return $post_format_video_sections;



    }



endif;