<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$output = $unique_id = $content_position = $category = $image_type = $image  = $title = $subtitle = $subtitle_pos = $enable_name = $css_animation = $css = $el_class = $custom_el_css  = '';
$image_width = $image_height =  $cat_name_border_radius = $title_color = $subtitle_color =  $cat_name_bg = $mask_type = $mask_color = $mask_gradient = $shadow = $shadow_custom = $shadow_hover = $shadow_custom_hover = $hover_animation = '';
$title_font_size = $title_line_height  = $title_letter_spacing = $title_font_style = $title_google_font = $title_typo_style = '';
$price_font_size = $price_line_height  = $price_letter_spacing = $price_font_style = $price_google_font = $price_typo_style =  '';
$image_html = $title_html = $subtitle_html = $cat_badge_html = '';

$atts = vc_map_get_attributes( 'dpr_woo_category', $atts );
extract( $atts );
$unique_id = uniqid('dpr-woo-category-').'-'.rand(1,9999);

/* CSS Classes and styles */
if ( '' !== $css_animation && 'none' !== $css_animation ) {
	dpr_enqueue_waypoint_js();
	dpr_enqueue_animate_css();
	$el_class .= ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
}

/* Output */
$css_classes = array(
	'dpr-woo-category',
	esc_attr($unique_id),
	$el_class,
	vc_shortcode_custom_css_class( $css ),
);

if(isset($content_position) && $content_position != '' ) {
	$css_classes[] = 'content-'.$content_position;
}
if ( 'custom' != $shadow && '' != $shadow ) $css_classes[] = 'dpr-shadow-'.$shadow;
if ( 'custom' != $shadow_hover && '' != $shadow_hover ) $css_classes[] = 'dpr-shadow-onhover-'.$shadow_hover;
if ( 'none' != $hover_animation && '' != $hover_animation ) $css_classes[] = $hover_animation;
if ( 'yes' == $enable_name ) $css_classes[] = 'cat-name-enabled';
if ( isset($subtitle_pos) && $subtitle_pos != '') $css_classes[] = 'title-'.$subtitle_pos;

$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->settings['base'], $atts ) );


// Custom CSS stuff
$title_typo_style = dpr_generate_typography_style('', $title_font_size, $title_line_height, $title_letter_spacing, $title_font_style,$title_google_font);

$subtitle_typo_style = dpr_generate_typography_style('', $subtitle_font_size, $subtitle_line_height, $subtitle_letter_spacing, $subtitle_font_style, $subtitle_google_font);

if(isset($title_color) && $title_color != '') {
	$custom_el_css .= '.'.esc_js($unique_id).'  h4.category-title, .'.esc_js($unique_id).'  h4.category-title a  {color:'.$title_color.' !important;}';
}
if(isset($title_color_hover) && $title_color_hover != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .category-inner:hover  h4.category-title, .'.esc_js($unique_id).':hover  h4.category-title a  {color:'.$title_color_hover.'  !important;}';
}
if(isset($subtitle_color) && $subtitle_color != '') {
	$custom_el_css .= '.'.esc_js($unique_id).'  .category-inner .category-subtitle {color:'.$subtitle_color.' !important;}';
}
if(isset($subtitle_color_hover) && $subtitle_color_hover != '') {
	$custom_el_css .= '.'.esc_js($unique_id).'  .category-inner:hover .category-subtitle {color:'.$subtitle_color_hover.' !important;}';
}

if(isset($cat_name_bg) && $cat_name_bg != '') {
	$custom_el_css .= '.'.esc_js($unique_id).'  .category-name {background-color:'.$cat_name_bg.';}';
}
if(isset($cat_name_border_radius) && $cat_name_border_radius != '') {
	$custom_el_css .= '.'.esc_js($unique_id).'  .category-name {border-radius:'.$cat_name_border_radius.'px;}';
}
if(isset($mask_color) && $mask_color != '' && $mask_type == 'solid') {
	$custom_el_css .= '.'.esc_js($unique_id).' .category-inner .image-wrap > a:before {background-color:'.$mask_color.';}';
}
if(isset($mask_gradient) && $mask_gradient != '' && $mask_type == 'gradient') {
	$custom_el_css .= '.'.esc_js($unique_id).' .category-inner .image-wrap > a:before {'.esc_js(adeline_gradientToBgCSS ($mask_gradient)).'}';
}


/*Category url*/
$cat_url = '';
$cat_src = get_term_link(intval($category), 'product_cat');
if($cat_src && !empty($cat_src) && !is_wp_error($cat_src)) {
	$cat_url = $cat_src;
}
/* Category name */ 
$cat_name = '';
if( $term = get_term_by( 'id', $category, 'product_cat' ) ){
    $cat_name = $term->name;
}

/*HTML Parts */

		/* Category Image */
		$w = 600;
		$h = 600;
		if(isset($image_width) && $image_width != '') {
			$w = $image_width;
		}
		if(isset($image_height) && $image_height != '') {
			$h = $image_height;
		}
		
		if(isset($image_type) && $image_type == 'custom' && isset($image) && $image != '') {
			$img_src = dpr_get_attachment_image_src($image, 'full');
			$alt_text = get_post_meta($image , '_wp_attachment_image_alt', true);
			$img_atts = adeline_image_attributes( $img_src[1], $img_src[2], $w, $h );
			$image_html = '<img src="'. adeline_resize( $img_src[0], $img_atts[ 'width' ], $img_atts[ 'height' ], $img_atts[ 'crop' ], true, $img_atts[ 'upscale' ] ).'" alt ="'.esc_attr($alt_text).'" width="'. esc_attr( $w ).'" height="'. esc_attr( $h ).'"/>';
		} else {
				$category_image_id = get_woocommerce_term_meta($category, 'thumbnail_id', true);
				if (!empty($category_image_id)) {
				$img_src = dpr_get_attachment_image_src($category_image_id, 'full');
				$alt_text = get_post_meta($category_image_id , '_wp_attachment_image_alt', true);
				$img_atts = adeline_image_attributes( $img_src[1], $img_src[2], $w, $h );
				$image_html = '<img src="'. adeline_resize( $img_src[0], $img_atts[ 'width' ], $img_atts[ 'height' ], $img_atts[ 'crop' ], true, $img_atts[ 'upscale' ] ).'"  alt ="'.esc_attr($alt_text).'" width="'. esc_attr( $w ).'" height="'. esc_attr( $h ).'"/>';
				} else {
				//$image_src = adeline_no_image_url();
				$image_html = '<img src="'. adeline_no_image_url().'" alt="" width="'. esc_attr( $w ).'/>';

				}
		}

	/* Subtitle */
                if($subtitle != '') { 
                       $subtitle_html .= '<div class="category-subtitle" '. $subtitle_typo_style.'>'.wp_kses_post($subtitle).'</div>';               
                }
	/* Title */
                if($title != '') { 
                       $title_html .= '<h4 class="category-title" '. $title_typo_style.'><a href="'.esc_url($cat_url).'" title="" >'.wp_kses_post($title).'</a></h4>';               
                }
	/* Cat name */
				if($enable_name == 'yes' && $cat_name != '') { 
						$cat_badge_html .= '<div class="category-name">'.esc_html($cat_name).'</div>';
				}
?>


<div id="<?php echo esc_attr($unique_id) ?>" class="<?php echo esc_attr($css_class) ?>">
<?php if(isset($category) && $category !='') { ?>
			<div class="category-inner">
               <div class="content-wrap">
               		<?php if ($subtitle_pos == 'bellow') { 
						echo $title_html;
						echo $subtitle_html;
					} else {
						echo $subtitle_html;
						echo $title_html;
					}
					echo $cat_badge_html; ?>
                </div>


            <div class="image-wrap clr">
            <a href="<?php echo esc_url($cat_url) ?>" class="woocommerce-LoopProduct-link"><?php echo wp_kses_post($image_html)?></a>
            </div>
				 
                
		<?php } else {
            echo '<p>'.esc_html__('No category selected', 'dpr-adeline-extensions').'</p>';
        } ?>
		</div>

<?php
	if(!empty($custom_el_css)) {
		$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>");'
						. '})(jQuery);'
					. '</script>';
}



echo $output;
?>
</div>
