<?php

/**

Plugin Name: DPR Adeline Extensions

Plugin URI: http://www.dynamicpress.eu

Description: Plugin which adds custom functions (post types , shortcodes, widgets, theme options ) used in Dynamicpress themes.

Version: 1.0

Text Domain: dpr-adeline-extensions

Domain Path: /languages

Author: Dynamicpress

Author URI: http://www.dynamicpress.eu/

 */



// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}



define('DPR_EXTENSIONS_PLUGIN_URL',plugins_url().'/dpr-adeline-extensions/');

define('DPR_EXTENSIONS_PLUGIN_PATH',plugin_dir_path(__FILE__));



/**

 * Main DPR Copmpound exteension class

*/



class DPR_Theme_Extensions {

	/**

	 * Core singleton class

	 * @var self - pattern realization

	 */

	private static $_instance;

	

	/**

	 * Get the instane of DPR_Theme_Extensions

	 *

	 * @return self

	 */

	public static function getInstance() {

		if ( ! ( self::$_instance instanceof self ) ) {

			self::$_instance = new self();

		}



		return self::$_instance;

	}

	

	/**

	 * Constructor

	 *

	 */

	public function __construct() {

		$theme = wp_get_theme();

		if ( 'Adeline' == $theme->name || 'adeline' == $theme->template ) {

			add_action('admin_enqueue_scripts', array($this,'loadAdminAssets'));

			$this->loadIconManager();

			$this->loadRedux();

			$this->loadHelpersFunctions();

			$this->loadCustomPostTypes();

			$this->loadWidgets();

			$this->loadExpandablePanel();
			
			$this->loadSocialShare();

			add_action('init', array($this, 'loadVcExtensions',), 2);

			add_action('init', array($this, 'init',), 10);

		} else {

			add_action('admin_notices', array($this, '_admin_notice__error'));

		}

	}

	

	/**

	 * Cloning disabled

	 */

	public function __clone() {

	}



	/**

	 * Serialization disabled

	 */

	public function __sleep() {

	}



	/**

	 * De-serialization disabled

	 */

	public function __wakeup() {

	}

	

	

	

	/**

	 * Callback function for WP init action hook. Loads required objects.

	 *

	 * @access public

	 *

	 * @return void

	 */

	public function init() {

		load_plugin_textdomain( 'dpr-adeline-extensions', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );

		if ( ! function_exists( 'is_plugin_active' ) ) {

     		require_once( ABSPATH . '/wp-admin/includes/plugin.php' );

		}

	}

	/*

	 * Load DPR admin assets

	 */

	 

	public function loadAdminAssets() {

        wp_register_style( 'dpr_wp_admin_css', DPR_EXTENSIONS_PLUGIN_URL . 'assets/admin/css/dpr-admin.css', false, '1.0.0' );

        wp_enqueue_style( 'dpr_wp_admin_css' );

        wp_register_style( 'balloon_css', DPR_EXTENSIONS_PLUGIN_URL . 'assets/admin/css/balloon.css', false, '1.0.0' );

        wp_enqueue_style( 'balloon_css' );

		wp_register_script( 'dpr_wp_admin_js', DPR_EXTENSIONS_PLUGIN_URL . 'assets/admin/js/dpr-admin.js', array( 'jquery' ), '', true );

        wp_enqueue_script( 'dpr_wp_admin_js' );

	}



	/*

	 * Load DPR Icon Manager functions

	 */

	

	public function loadIconManager() {

		if ( file_exists( DPR_EXTENSIONS_PLUGIN_PATH.'inc/font_icon_manager/dpr_icon_manager.php' ) ) {

		require_once(DPR_EXTENSIONS_PLUGIN_PATH.'inc/font_icon_manager/dpr_icon_manager.php' );

		}

	}

	/*

	 * Load Redux Core

	 */

	public function loadRedux() {

		    // Load the embedded Redux Framework

			if ( file_exists( DPR_EXTENSIONS_PLUGIN_PATH.'redux/redux-init.php' ) ) {

				require_once  DPR_EXTENSIONS_PLUGIN_PATH.'redux/redux-init.php';

			}

	}

	/*

	 * Load DPR Custom post types

	 */

	 

	public function loadCustomPostTypes() {

		require_once(DPR_EXTENSIONS_PLUGIN_PATH.'inc/post_types/portfolio.php');

		require_once(DPR_EXTENSIONS_PLUGIN_PATH.'inc/post_types/particles.php');

		require_once(DPR_EXTENSIONS_PLUGIN_PATH.'inc/post_types/particle-shortcode.php');

		require_once(DPR_EXTENSIONS_PLUGIN_PATH.'inc/post_types/gallery.php');

	}

	/*

	 * Load DPR Widgets

	 */

	 

	public function loadWidgets() {

		require_once(DPR_EXTENSIONS_PLUGIN_PATH.'inc/widgets/widgets.init.php');

	}

	/*

	 * Load DPR Helpers functions

	 */

	 

	public function loadHelpersFunctions() {

		require_once(DPR_EXTENSIONS_PLUGIN_PATH.'inc/helpers_functions.php');

		require_once( DPR_EXTENSIONS_PLUGIN_PATH .'inc/dpr-aqua-resizer.php' );

		require_once( DPR_EXTENSIONS_PLUGIN_PATH .'inc/dpr-jsmin.php' );	

	}

	/*

	 * Load VC Extensions functions

	 */

	 

	public function loadVcExtensions() {

		if(class_exists ( 'Vc_Manager' )) {

				require_once(DPR_EXTENSIONS_PLUGIN_PATH.'vc-extend/dpr_vc_extensions.php');

				vc_set_shortcodes_templates_dir( DPR_EXTENSIONS_PLUGIN_PATH.'vc-extend/vc-templates' );

		} 		

	}


	/*

	 * Load Expandable Panel

	 */

	 

	public function loadExpandablePanel() {

		require_once(DPR_EXTENSIONS_PLUGIN_PATH.'inc/expandable_panel/helpers.php');

	}


	/*

	 * Load Social Share 

	 */

	 

	public function loadSocialShare() {

		require_once(DPR_EXTENSIONS_PLUGIN_PATH.'inc/social_share/helpers.php');

	}


	/*

	 * Admin notice text

	 */

	public function _admin_notice__error() {

		echo '<div class="notice notice-error is-dismissible">';

			echo '<p>'. esc_html__( 'DPR Adeline Extensions plugin is enabled but not effective. It requires Adeline theme in order to work.', 'dpr-adeline-extensions' ) .'</p>';

		echo '</div>';

	}

}



$DPR_Theme_Extensions = new DPR_Theme_Extensions();



