<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$output = $el_class = '';

$atts = vc_map_get_attributes( 'dpr_parallax_stack', $atts );
extract( $atts );
$el_class = $this->getExtraClass( $el_class );

$css_classes = array(
	'dpr-parallax-stack',
	$el_class
);
$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->settings['base'], $atts ) );

$id = uniqid('dpr-paralax-stack');
$output .= '<div id="'.esc_attr($id).'" class="'.esc_attr($css_class).'">';
	$output .= do_shortcode($content);
$output .= '</div>';

echo $output;