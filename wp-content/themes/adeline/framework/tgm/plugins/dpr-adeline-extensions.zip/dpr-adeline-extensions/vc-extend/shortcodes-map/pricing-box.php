<?php

if ( ! defined( 'ABSPATH' ) ) { exit; }

/*

* Add-on Name: Pricing Box

*/



class WPBakeryShortCode_DPR_Price_Box extends WPBakeryShortCode {}



$features_list_params = array(

					array(

						'type'		    => 'dpr_radio',

						'heading'		=> esc_html__('Type', 'dpr-adeline-extensions'),

						'param_name'	=> 'features_style',

						'value'			=> 'text_only',

						'options'		=> array(

							esc_html__('Text', 'dpr-adeline-extensions')			=> 'text_only',

							esc_html__('Icon', 'dpr-adeline-extensions')			=> 'icon_only',

							esc_html__('Text & icon', 'dpr-adeline-extensions')	=> 'text_icon',

							esc_html__('Dot Only', 'dpr-adeline-extensions')			=> 'dot',

						),

					),

					array(

						'type'			=> 'textfield',

						'heading'		=> esc_html__('Feature text', 'dpr-adeline-extensions'),

						'param_name'	=> 'label',

						'admin_label'	=> true,

						'dependency'	=> array('element' => 'features_style', 'value'  => array('text_icon', 'text_only')),

					),

					array(

						'type' => 'dropdown',

						'heading' => __( 'Icon library', 'dpr-adeline-extensions' ),

						'value' => array(

							__( 'Font Awesome', 'dpr-adeline-extensions' ) => 'fontawesome',

							__( 'Open Iconic', 'dpr-adeline-extensions' ) => 'openiconic',

							__( 'Typicons', 'dpr-adeline-extensions' ) => 'typicons',

							__( 'Entypo', 'dpr-adeline-extensions' ) => 'entypo',

							__( 'Linecons', 'dpr-adeline-extensions' ) => 'linecons',

							__( 'Pixel', 'dpr-adeline-extensions' ) => 'pixelicons',

							__( 'Mono Social', 'dpr-adeline-extensions' ) => 'monosocial',

						),

						'param_name' => 'icon_type',

						'description' => __( 'Select icon library.', 'dpr-adeline-extensions' ),

						'dependency'	=> array('element' => 'features_style', 'value'  => array('text_icon', 'icon_only')),

					),

					array(

						'type' => 'iconpicker',

						'heading' => __( 'Icon', 'dpr-adeline-extensions' ),

						'param_name' => 'icon_fontawesome',

						'value' => 'fa fa-angle-double-right',

						'settings' => array(

							'emptyIcon' => false,

							// default true, display an "EMPTY" icon?

							'iconsPerPage' => 4000,

							// default 100, how many icons per/page to display

						),

						'dependency' => array(

							'element' => 'icon_type',

							'value' => 'fontawesome',

						),

						'description' => __( 'Select icon from library.', 'dpr-adeline-extensions' ),

					),

					array(

						'type' => 'iconpicker',

						'heading' => __( 'Icon', 'dpr-adeline-extensions' ),

						'param_name' => 'icon_openiconic',

						'value' => 'vc-oi vc-oi-ok',

						'settings' => array(

							'emptyIcon' => false,

							// default true, display an "EMPTY" icon?

							'type' => 'openiconic',

							'iconsPerPage' => 4000,

							// default 100, how many icons per/page to display

						),

						'dependency' => array(

							'element' => 'icon_type',

							'value' => 'openiconic',

						),

						'description' => __( 'Select icon from library.', 'dpr-adeline-extensions' ),

					),

					array(

						'type' => 'iconpicker',

						'heading' => __( 'Icon', 'dpr-adeline-extensions' ),

						'param_name' => 'icon_typicons',

						'value' => 'typcn typcn-arrow-right',

						'settings' => array(

							'emptyIcon' => false,

							// default true, display an "EMPTY" icon?

							'type' => 'typicons',

							'iconsPerPage' => 4000,

							// default 100, how many icons per/page to display

						),

						'dependency' => array(

							'element' => 'icon_type',

							'value' => 'typicons',

						),

						'description' => __( 'Select icon from library.', 'dpr-adeline-extensions' ),

					),

					array(

						'type' => 'iconpicker',

						'heading' => __( 'Icon', 'dpr-adeline-extensions' ),

						'param_name' => 'icon_entypo',

						'value' => 'entypo-icon entypo-icon-right-open',

						'settings' => array(

							'emptyIcon' => false,

							// default true, display an "EMPTY" icon?

							'type' => 'entypo',

							'iconsPerPage' => 4000,

							// default 100, how many icons per/page to display

						),

						'dependency' => array(

							'element' => 'icon_type',

							'value' => 'entypo',

						),

					),

					array(

						'type' => 'iconpicker',

						'heading' => __( 'Icon', 'dpr-adeline-extensions' ),

						'param_name' => 'icon_linecons',

						'settings' => array(

							'emptyIcon' => false,

							// default true, display an "EMPTY" icon?

							'type' => 'linecons',

							'iconsPerPage' => 4000,

							// default 100, how many icons per/page to display

						),

						'dependency' => array(

							'element' => 'icon_type',

							'value' => 'linecons',

						),

						'description' => __( 'Select icon from library.', 'dpr-adeline-extensions' ),

					),

					array(

						'type' => 'iconpicker',

						'heading' => __( 'Icon', 'dpr-adeline-extensions' ),

						'param_name' => 'icon_pixelicons',

						'value' => 'vc_pixel_icon vc_pixel_icon-tick',

						'settings' => array(

							'emptyIcon' => false,

							// default true, display an "EMPTY" icon?

							'type' => 'pixelicons',

							'source' => array(

											array( 'vc_pixel_icon vc_pixel_icon-alert' => __( 'Alert', 'dpr-adeline-extensions' ) ),

											array( 'vc_pixel_icon vc_pixel_icon-info' => __( 'Info', 'dpr-adeline-extensions' ) ),

											array( 'vc_pixel_icon vc_pixel_icon-tick' => __( 'Tick', 'dpr-adeline-extensions' ) ),

											array( 'vc_pixel_icon vc_pixel_icon-explanation' => __( 'Explanation', 'dpr-adeline-extensions' ) ),

											array( 'vc_pixel_icon vc_pixel_icon-address_book' => __( 'Address book', 'dpr-adeline-extensions' ) ),

											array( 'vc_pixel_icon vc_pixel_icon-alarm_clock' => __( 'Alarm clock', 'dpr-adeline-extensions' ) ),

											array( 'vc_pixel_icon vc_pixel_icon-anchor' => __( 'Anchor', 'dpr-adeline-extensions' ) ),

											array( 'vc_pixel_icon vc_pixel_icon-application_image' => __( 'Application Image', 'dpr-adeline-extensions' ) ),

											array( 'vc_pixel_icon vc_pixel_icon-arrow' => __( 'Arrow', 'dpr-adeline-extensions' ) ),

											array( 'vc_pixel_icon vc_pixel_icon-asterisk' => __( 'Asterisk', 'dpr-adeline-extensions' ) ),

											array( 'vc_pixel_icon vc_pixel_icon-hammer' => __( 'Hammer', 'dpr-adeline-extensions' ) ),

											array( 'vc_pixel_icon vc_pixel_icon-balloon' => __( 'Balloon', 'dpr-adeline-extensions' ) ),

											array( 'vc_pixel_icon vc_pixel_icon-balloon_buzz' => __( 'Balloon Buzz', 'dpr-adeline-extensions' ) ),

											array( 'vc_pixel_icon vc_pixel_icon-balloon_facebook' => __( 'Balloon Facebook', 'dpr-adeline-extensions' ) ),

											array( 'vc_pixel_icon vc_pixel_icon-balloon_twitter' => __( 'Balloon Twitter', 'dpr-adeline-extensions' ) ),

											array( 'vc_pixel_icon vc_pixel_icon-battery' => __( 'Battery', 'dpr-adeline-extensions' ) ),

											array( 'vc_pixel_icon vc_pixel_icon-binocular' => __( 'Binocular', 'dpr-adeline-extensions' ) ),

											array( 'vc_pixel_icon vc_pixel_icon-document_excel' => __( 'Document Excel', 'dpr-adeline-extensions' ) ),

											array( 'vc_pixel_icon vc_pixel_icon-document_image' => __( 'Document Image', 'dpr-adeline-extensions' ) ),

											array( 'vc_pixel_icon vc_pixel_icon-document_music' => __( 'Document Music', 'dpr-adeline-extensions' ) ),

											array( 'vc_pixel_icon vc_pixel_icon-document_office' => __( 'Document Office', 'dpr-adeline-extensions' ) ),

											array( 'vc_pixel_icon vc_pixel_icon-document_pdf' => __( 'Document PDF', 'dpr-adeline-extensions' ) ),

											array( 'vc_pixel_icon vc_pixel_icon-document_powerpoint' => __( 'Document Powerpoint', 'dpr-adeline-extensions' ) ),

											array( 'vc_pixel_icon vc_pixel_icon-document_word' => __( 'Document Word', 'dpr-adeline-extensions' ) ),

											array( 'vc_pixel_icon vc_pixel_icon-bookmark' => __( 'Bookmark', 'dpr-adeline-extensions' ) ),

											array( 'vc_pixel_icon vc_pixel_icon-camcorder' => __( 'Camcorder', 'dpr-adeline-extensions' ) ),

											array( 'vc_pixel_icon vc_pixel_icon-camera' => __( 'Camera', 'dpr-adeline-extensions' ) ),

											array( 'vc_pixel_icon vc_pixel_icon-chart' => __( 'Chart', 'dpr-adeline-extensions' ) ),

											array( 'vc_pixel_icon vc_pixel_icon-chart_pie' => __( 'Chart pie', 'dpr-adeline-extensions' ) ),

											array( 'vc_pixel_icon vc_pixel_icon-clock' => __( 'Clock', 'dpr-adeline-extensions' ) ),

											array( 'vc_pixel_icon vc_pixel_icon-fire' => __( 'Fire', 'dpr-adeline-extensions' ) ),

											array( 'vc_pixel_icon vc_pixel_icon-heart' => __( 'Heart', 'dpr-adeline-extensions' ) ),

											array( 'vc_pixel_icon vc_pixel_icon-mail' => __( 'Mail', 'dpr-adeline-extensions' ) ),

											array( 'vc_pixel_icon vc_pixel_icon-play' => __( 'Play', 'dpr-adeline-extensions' ) ),

											array( 'vc_pixel_icon vc_pixel_icon-shield' => __( 'Shield', 'dpr-adeline-extensions' ) ),

											array( 'vc_pixel_icon vc_pixel_icon-video' => __( 'Video', 'dpr-adeline-extensions' ) ),

										),

						),

						'dependency' => array(

							'element' => 'icon_type',

							'value' => 'pixelicons',

						),

						'description' => __( 'Select icon from library.', 'dpr-adeline-extensions' ),

					),

					array(

						'type' => 'iconpicker',

						'heading' => __( 'Icon', 'dpr-adeline-extensions' ),

						'param_name' => 'icon_monosocial',

						'value' => 'vc-mono vc-mono-fivehundredpx',

						// default value to backend editor admin_label

						'settings' => array(

							'emptyIcon' => false,

							// default true, display an "EMPTY" icon?

							'type' => 'monosocial',

							'iconsPerPage' => 4000,

							// default 100, how many icons per/page to display

						),

						'dependency' => array(

							'element' => 'icon_type',

							'value' => 'monosocial',

						),

						'description' => __( 'Select icon from library.', 'dpr-adeline-extensions' ),

					),

					

					array(

						'type'				=> 'colorpicker',

						'class'				=> '',

						'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom list icon color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon Color', 'dpr-adeline-extensions'),

						'param_name'		=> 'custom_icon_color',

						'value'				=> '',

						'edit_field_class'	=> 'vc_column vc_col-sm-4  ',

						'dependency'	=> array('element' => 'features_style', 'value'  => array('text_icon', 'icon_only')),

					),

					array(

						'type'			=> 'dpr_switcher',

						'heading' 		=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Use badge for this feature.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Use Featured Badge', 'dpr-adeline-extensions'),

						'param_name'	=> 'use_feature_badge',

						'options'		=> array(

							'yes'				=> array(

								'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

								'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

						),

						'edit_field_class'	=> 'vc_column vc_col-sm-12',

						'dependency'	=> array('element' => 'features_style', 'value'  => array('text_icon', 'text_only','icon_only')),

					),

					array(

						'type'			=> 'textfield',

						'heading'		=> esc_html__('Badge text', 'dpr-adeline-extensions'),

						'param_name'	=> 'badge_text',

						'value'			=> esc_html__('NEW', 'dpr-adeline-extensions'),

						'edit_field_class'	=> 'vc_column vc_col-sm-4',

						'dependency'	=> array('element' => 'use_feature_badge', 'value'  => array('yes')),

					),

					array(

						'type'				=> 'colorpicker',

						'class'				=> '',

						'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the badge text color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color', 'dpr-adeline-extensions'),

						'param_name'		=> 'text_color',

						'value'				=> '#fff',

						'edit_field_class'	=> 'vc_column vc_col-sm-4  ',

						'dependency'	=> array('element' => 'use_feature_badge', 'value'  => array('yes')),

					),

					array(

						'type'				=> 'colorpicker',

						'class'				=> '',

						'value'				=> '#F45C1E',

						'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the badge background color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background Color', 'dpr-adeline-extensions'),

						'param_name'		=> 'bg_color',

						'edit_field_class'	=> 'vc_column vc_col-sm-4  ',

						'dependency'	=> array('element' => 'use_feature_badge', 'value'  => array('yes')),

					),

					array(

						'type'				=> 'colorpicker',

						'class'				=> '',

						'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the dot color. Default is #e1e4e9.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Dot Color', 'dpr-adeline-extensions'),

						'param_name'		=> 'dot_color',

						'edit_field_class'	=> 'vc_column vc_col-sm-12  ',

						'dependency'	=> array('element' => 'features_style', 'value'  => array('dot')),

					),



);





$features_list_params = array_merge($features_list_params);



vc_map(

	array(

		'name'        => esc_html__('DP Price Box', 'dpr-adeline-extensions'),

		'base'        => 'dpr_price_box',

		'class'       => 'dpr_price_box',

		'icon'        => 'icon-dpr-price-box',

  		"category" 				=>array( esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions')),

		'description' => esc_html__('Display styled pricing box. ', 'dpr-adeline-extensions'),

		'params'			=> array(

			array(

				'heading'			=> esc_html__('Layout', 'dpr-adeline-extensions'),

				'type'				=> 'dpr_image_select',

				'param_name'		=> 'layout',

				'options'			=> array(

					'minimal'	=> array(

						'label'	=> esc_html__('Minimal','dpr-adeline-extensions'),

						'src'		=> $module_images . 'price-box/minimal.png'

					),

					'classic'	=> array(

						'label'	=> esc_html__('Classic','dpr-adeline-extensions'),

						'src'		=> $module_images . 'price-box/classic.png'

					),

					'color'	=> array(

						'label'	=> esc_html__('Color','dpr-adeline-extensions'),

						'src'		=> $module_images . 'price-box/color.png'

					),

					'flip'	=> array(

						'label'	=> esc_html__('Flip','dpr-adeline-extensions'),

						'src'		=> $module_images . 'price-box/flip.png'

					)

				),

			),

			array(

				'type'				=> 'textfield',

				'heading'			=> esc_html__('Title', 'dpr-adeline-extensions'),

				'param_name'		=> 'title',

				'value'				=> esc_html__('Pricing title', 'dpr-adeline-extensions'),

				'admin_label'		=> true,

			),

			array(

				'type'				=> 'textfield',

				'heading'			=> esc_html__('Subtitle', 'dpr-adeline-extensions'),

				'value'				=> esc_html__('Pricing table subtitle', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle',

			),

			array(

				'type'				=> 'textfield',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you set any currency symbol you need.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Currency Symbol', 'dpr-adeline-extensions'),

				'param_name'		=> 'currency',

				'value'				=> esc_html__('$', 'dpr-adeline-extensions'),

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you set the price for this box.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Price', 'dpr-adeline-extensions'),

				'param_name'		=> 'price',

				'value'				=> 9.99,

				'min'				=> 0,

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

			),

			array(

				'type'				=> 'textfield',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set the recurring fee for this pricing box, it will be displayed at the right side of the price.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Recurring period', 'dpr-adeline-extensions'),

				'param_name'		=> 'price_period',

				'value'				=> esc_html__(' mo.', 'dpr-adeline-extensions'),

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Additional Settings', 'dpr-adeline-extensions' ),

				'param_name'       => 'extra_features_title',

				'edit_field_class' => 'vc_column vc_col-sm-12',

			),

		   vc_map_add_css_animation( false ),

		    array(

				'type' => 'textfield',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Extra Class Name', 'dpr-adeline-extensions'),

				'param_name' => 'el_class',

			),

			array(

				'type'			=> 'dpr_switcher',

				'heading' 		=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to add the link to your image.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Use Icon', 'dpr-adeline-extensions'),

				'param_name'	=> 'use_icon',

				'options'		=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

			),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_radio',

				'heading'			=> esc_html__('Icon to display', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_type',

				'value'				=> 'icon',

				'options'			=> array(

					esc_html__('Icon', 'dpr-adeline-extensions')	=> 'icon',

					esc_html__('Image', 'dpr-adeline-extensions')	=> 'image',

					esc_html__('Text', 'dpr-adeline-extensions')	=> 'text',

				),

				'dependency'		=> array('element' => 'use_icon', 'value' => array('yes')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

		  array(

				"type" => "dpr_icon_selector",

				"heading" => esc_attr__("Icon", 'dpr-adeline-extensions'),

				"param_name" => "icon",

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select icon.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'icon_type', 'value' => 'icon',),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'attach_image',

				'heading'			=> esc_html__('Upload Image', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_image_id',

				'description'		=> esc_html__('Choose the image from the media library', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'icon_type', 'value' => array('image')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'textfield',

				'heading'			=> esc_html__('Text', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_text',

				'dependency'		=> array('element' => 'icon_type', 'value' => array('text')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set the size for the icon (image).', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Size', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_size',

				'min'				=> 12,

				'edit_field_class'	=> 'vc_column vc_col-sm-4   ',

				'dependency'		=> array('element' => 'icon_type', 'value' => array('custom', 'icon')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'class'				=> '',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the icon color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-4  ',

				'dependency'		=> array('element' => 'icon_type', 'value' => array('icon')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'class'				=> '',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the text color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'text_icon_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-3  ',

				'dependency'		=> array('element' => 'icon_type', 'value' => array('text')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'text_icon_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'icon_type', 'value' => array('text')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom linne height..', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'text_icon_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'icon_type', 'value' => array('text')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom letter spacing.', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'text_icon_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'icon_type', 'value' => array('text')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'text_icon_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'dependency'		=> array('element' => 'icon_type', 'value' => array('text')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

	  		),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to use custom Google font.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'text_icon_use_google_fonts',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'dependency'		=> array('element' => 'icon_type', 'value' => array('text')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'text_icon_custom_fonts',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'dependency'		=> array('element' => 'text_icon_use_google_fonts', 'value' => 'yes'),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'textarea',

				'heading'			=> esc_html__('Content', 'dpr-adeline-extensions'),

				'param_name'		=> 'content_description',

				'value'				=> esc_html__('Pricing box content. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque mollis ex eu blandit scelerisque.', 'dpr-adeline-extensions'),

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'param_group',

				'heading'			=> esc_html__('Features', 'dpr-adeline-extensions'),

				'param_name'		=> 'list_values',

				'value'				=> '',

				'params'      => $features_list_params,

				'group'       => esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'textfield',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enter the text for the prcing box button.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Button Text', 'dpr-adeline-extensions'),

				'param_name'		=> 'button_text',

				'value'				=> esc_html__('Button', 'dpr-adeline-extensions'),

				'group'				=> esc_html__('Button', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'vc_link',

				'heading'			=> esc_html__('Button link', 'dpr-adeline-extensions'),

				'param_name'		=> 'button_link',

				'description'		=> esc_html__('Add link to button.', 'dpr-adeline-extensions'),

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'dependency'		=> array('element' => 'button_text', 'not_empty' => true),

				'group'				=> esc_html__('Button', 'dpr-adeline-extensions'),

			),

			array(

				'type'			=> 'dpr_switcher',

				'heading' 		=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set the full width for the button according to the pricing table width.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Full width button', 'dpr-adeline-extensions'),

				'param_name'	=> 'button_full_width',

				'options'		=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

			),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Button', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> 'Button Style',

				'param_name'		=> 'button_title_1',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'button_text', 'not_empty' => true),

				'group'				=> esc_html__('Button', 'dpr-adeline-extensions'),

			),



			array(

				'type'				=> 'colorpicker',

				'heading' 		=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Default color is inherited from Theme Options.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Text color', 'dpr-adeline-extensions'),

				'param_name'		=> 'button_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'dependency'		=> array('element' => 'button_text', 'not_empty' => true),

				'group'				=> esc_html__('Button', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' 		=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Default text hover color is inherited from Theme Options ', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Text color: Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'button_hover_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'dependency'		=> array('element' => 'button_text', 'not_empty' => true),

				'group'				=> esc_html__('Button', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' 		=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Default background color is inherited from Theme Options ', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background color', 'dpr-adeline-extensions'),

				'param_name'		=> 'button_bg_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'dependency'		=> array('element' => 'button_text', 'not_empty' => true),

				'group'				=> esc_html__('Button', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' 		=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Default hover background color is inherited from Theme Options', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background color: Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'button_bg_hover_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'dependency'		=> array('element' => 'button_text', 'not_empty' => true),

				'group'				=> esc_html__('Button', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set button border color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Button Border color', 'dpr-adeline-extensions'),

				'param_name'		=> 'button_border_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'dependency'		=> array('element' => 'button_text', 'not_empty' => true),

				'group'				=> esc_html__('Button', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose button border color on hover.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Button Border color: Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'button_border_color_hover',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'dependency'		=> array('element' => 'button_text', 'not_empty' => true),

				'group'				=> esc_html__('Button', 'dpr-adeline-extensions'),

			),



			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose button border radius.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Button Border radius', 'dpr-adeline-extensions'),

				'param_name'		=> 'button_border_radius',

				'min'				=> 0,

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'dependency'		=> array('element' => 'button_text', 'not_empty' => true),

				'group'				=> esc_html__('Button', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Default left padding is inherited from Theme Options.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Left padding', 'dpr-adeline-extensions'),

				'param_name'		=> 'button_left_padding',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'dependency'		=> array('element' => 'button_text', 'not_empty' => true),

				'group'				=> esc_html__('Button', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Default right padding is inherited from Theme Options.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Right padding', 'dpr-adeline-extensions'),

				'param_name'		=> 'button_right_padding',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'dependency'		=> array('element' => 'button_text', 'not_empty' => true),

				'group'				=> esc_html__('Button', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'textfield',

				'heading'			=> esc_html__('Badge', 'dpr-adeline-extensions'),

				'param_name'		=> 'badge_text',

				'value'				=> esc_html__('HOT', 'dpr-adeline-extensions'),

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_html__('Badge', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> 'Button Style',

				'param_name'		=> 'badge_title_1',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'badge_text', 'not_empty' => true),

				'group'				=> esc_html__('Badge', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the color for the badge.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Badge Text Color', 'dpr-adeline-extensions'),

				'class'				=> '',

				'param_name'		=> 'badge_color',

				'value'				=> '#ffffff',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'dependency'		=> array('element' => 'badge_text', 'not_empty' => true),

				'group'				=> esc_html__('Badge', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the backround color for the badge.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Badge Background Color', 'dpr-adeline-extensions'),

				'class'				=> '',

				'param_name'		=> 'badge_bg_color',

				'value'				=> '#7F45C1E',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'dependency'		=> array('element' => 'badge_text', 'not_empty' => true),

				'group'				=> esc_html__('Badge', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the border radius for the badge background.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Badge Border Radius', 'dpr-adeline-extensions'),

				'param_name'		=> 'badge_border_radius',

				'value'				=> 4,

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'dependency'		=> array('element' => 'badge_text', 'not_empty' => true),

				'group'				=> esc_html__('Badge', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Title Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_typography_head',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'title', 'not_empty' => true),

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom ttle color. Default is headings color set in template options.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'title', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size.Default is 18px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'title', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title linne height.Default is 18px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'title', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'title', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'title_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'dependency'		=> array('element' => 'title', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

	  		),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font. .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_google_fonts',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'dependency'		=> array('element' => 'title', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'title_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'dependency'		=> array('element' => 'use_google_fonts', 'value' => 'yes'),

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),



			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Subtitle Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_typography_head',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'subtitle', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom subtitle color. Default is #808080.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'subtitle', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size.Default is 13px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'subtitle', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom linne height.Default is 28px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'subtitle', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'subtitle', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'subtitle_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'dependency'		=> array('element' => 'subtitle', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

	  		),

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Content Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'content_typgraphy_head',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom content color. Default is text color set in template options.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'content_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size.Default text font size set in template options .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'content_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title linne height. Default is text line height set in template options .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'content_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'content_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'content_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

	  		),

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Features List Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'features_typgraphy_head',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom content color. Default is text color set in template options.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'features_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size.Default text font size set in template options .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'features_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title linne height. Default is text line height set in template options .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'features_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'features_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'features_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

	  		),

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('General Styles', 'dpr-adeline-extensions'),

				'param_name'		=> 'style_title_1',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom front side background color. Default is #D3AE5F', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Front side Background Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'front_bg_color',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'dependency'		=> array('element' => 'layout', 'value' => array('flip')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'attach_image',

				'heading'			=> esc_html__('Front Side Background Image', 'dpr-adeline-extensions'),

				'param_name'		=> 'front_image_id',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'description'		=> esc_html__('Choose the image from the media library', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'layout', 'value' => array('flip')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom back side background color. Default is #c09c81', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Back side Background Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'back_bg_color',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'dependency'		=> array('element' => 'layout', 'value' => array('flip')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'attach_image',

				'heading'			=> esc_html__('Back Side Background Image', 'dpr-adeline-extensions'),

				'param_name'		=> 'back_image_id',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'description'		=> esc_html__('Choose the image from the media library', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'layout', 'value' => array('flip')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom border style.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border style', 'dpr-adeline-extensions'),

				'param_name'		=> 'border_style',

				'value'				=> '',

				'options'			=> array(

					esc_html__('Default', 'dpr-adeline-extensions')	=> '',

					esc_html__('None', 'dpr-adeline-extensions')	=> 'none',

					esc_html__('Solid', 'dpr-adeline-extensions')	=> 'solid',

					esc_html__('Dotted', 'dpr-adeline-extensions')	=> 'dotted',

					esc_html__('Dashed', 'dpr-adeline-extensions')	=> 'dashed',

				),

				'edit_field_class'	=> 'vc_col-sm-9 vc_column ',

				'dependency'		=> array('element' => 'layout', 'value' => array('classic', 'minimal')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom price box border color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'border_color',

				'edit_field_class'	=> 'vc_col-sm-4 vc_column ',

				'dependency'		=> array('element' => 'layout', 'value' => array('classic', 'minimal')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom price box border radius.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border width', 'dpr-adeline-extensions'),

				'param_name'		=> 'border_width',

				'min'				=> 0,

				'suffix' 			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

				'dependency'		=> array('element' => 'layout', 'value' => array('classic', 'minimal')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom price box border radius.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border radius', 'dpr-adeline-extensions'),

				'param_name'		=> 'border_radius',

				'min'				=> 0,

				'suffix' 			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom price box border color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border Color: Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'border_color_hover',

				'edit_field_class'	=> 'vc_col-sm-4 vc_column ',

				'dependency'		=> array('element' => 'layout', 'value' => array('classic', 'minimal')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom price box border radius.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border width: Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'border_width_hover',

				'min'				=> 0,

				'suffix' 			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

				'dependency'		=> array('element' => 'layout', 'value' => array('classic', 'minimal')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom price box border radius.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border radius: Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'border_radius_hover',

				'min'				=> 0,

				'suffix' 			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

				'dependency'		=> array('element' => 'layout', 'value' => array('minimal', 'classic', 'color')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set minimal height if needed to fit layout of back side.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Minimal Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'min_height',

				'min'				=> 0,

				'suffix' 			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

				'dependency'		=> array('element' => 'layout', 'value' => array('flip')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			

			array(

				'type'				=> 'dpr_title',

				'text'				=> '',

				'param_name'		=> 'style_sep_1',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'layout', 'value' => array('classic')),

				'group'				=> esc_attr__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom price box background color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Box Background', 'dpr-adeline-extensions'),

				'param_name'		=> 'box_bg_color',

				'edit_field_class'	=> 'vc_col-sm-4 vc_column ',

				'dependency'		=> array('element' => 'layout', 'value' => array('color')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom background for top content area.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Top Area Background', 'dpr-adeline-extensions'),

				'param_name'		=> 'top_bg_color',

				'edit_field_class'	=> 'vc_col-sm-4 vc_column ',

				'dependency'		=> array('element' => 'layout', 'value' => array('classic')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom background for features area.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Features Background', 'dpr-adeline-extensions'),

				'param_name'		=> 'features_bg_color',

				'edit_field_class'	=> 'vc_col-sm-4 vc_column',

				'dependency'		=> array('element' => 'layout', 'value' => array('classic')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> '',

				'param_name'		=> 'style_sep_2',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Specify the top offset, it will be added above the pricing table content.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Top offset', 'dpr-adeline-extensions'),

				'param_name'		=> 'top_offset',

				'value'				=> 30,

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'dependency'		=> array('element' => 'layout', 'value' => array('minimal', 'classic', 'color')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Specify the bottom offset, it will be added under the pricing table content.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Bottom offset', 'dpr-adeline-extensions'),

				'param_name'		=> 'bottom_offset',

				'value'				=> 30,

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'dependency'		=> array('element' => 'layout', 'value' => array('minimal', 'classic', 'color')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable hover shadow for thix box.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Use Hover Shadow?', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_hover_shadow',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'dependency'		=> array('element' => 'layout', 'value' => array('minimal', 'classic', 'color')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				"type" => "dpr_shadow_picker",

				"class" => "",

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set hover shadow for this box.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Shadow', 'dpr-adeline-extensions'),

				"param_name" => "box_shadow",

				"value" => "none||||||",

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'use_hover_shadow', 'value' => 'yes'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Content Delimiter Style', 'dpr-adeline-extensions'),

				'param_name'		=> 'style_title_2',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_radio',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose delimiter style.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Delimiter', 'dpr-adeline-extensions'),

				'param_name'		=> 'delimeter_style',

				'value'				=> 'solid',

				'options'			=> array(

					esc_html__('Solid','dpr-adeline-extensions')	=> 'solid',

					esc_html__('Dotted','dpr-adeline-extensions')	=> 'dotted',

					esc_html__('Dashed','dpr-adeline-extensions')	=> 'dashed',

					esc_html__('None','dpr-adeline-extensions')	=> 'none',

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the delimiter color. The default color is #e1e4e9', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Delimiter color', 'dpr-adeline-extensions'),

				'class'				=> '',

				'param_name'		=> 'delimeter_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'dependency'		=> array('element' => 'delimeter_style', 'value' => array('solid', 'dotted', 'dashed')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'			=> 'dpr_switcher',

				'heading' 		=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Use arrowed style seprator.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Use Arrow Delimiter', 'dpr-adeline-extensions'),

				'param_name'	=> 'use_arrow',

				'options'		=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

			),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'dependency'		=> array('element' => 'layout', 'value' => array('classic')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),





			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Price Style', 'dpr-adeline-extensions'),

				'param_name'		=> 'style_title_3',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> esc_html__('Currency symbol size', 'dpr-adeline-extensions'),

				'param_name'		=> 'symbol_size',

				'value'				=> 25,

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> esc_html__('Price size', 'dpr-adeline-extensions'),

				'param_name'		=> 'amount_size',

				'value'				=> 55,

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> esc_html__('Recurring fee size', 'dpr-adeline-extensions'),

				'param_name'		=> 'period_size',

				'suffix'			=> 'px',

				'value'				=> 25,

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'price_letter_spacing',

				'suffix'			=> 'px',

				'value'				=> -4,

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the color for the currency, price and fee. The default color is inherited from Theme Options heading color settings', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color', 'dpr-adeline-extensions'),

				'class'				=> '',

				'param_name'		=> 'price_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Features Area Style', 'dpr-adeline-extensions'),

				'param_name'		=> 'style_title_4',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Style', 'dpr-adeline-extensions'),

			),

			

			array(

				'type'				=> 'dpr_radio',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose features delimiter style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Delimiter style', 'dpr-adeline-extensions'),

				'param_name'		=> 'features_delimiter_style',

				'value'				=> 'solid',

				'options'			=> array(

					esc_html__('Solid','dpr-adeline-extensions')	=> 'solid',

					esc_html__('Dotted','dpr-adeline-extensions')	=> 'dotted',

					esc_html__('Dashed','dpr-adeline-extensions')	=> 'dashed',

					esc_html__('None','dpr-adeline-extensions')	=> 'none',

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose features delimiter color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Delimiter color', 'dpr-adeline-extensions'),

				'class'				=> '',

				'param_name'		=> 'features_delimiter_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'dependency'		=> array('element' => 'features_delimiter_style', 'value' => array('solid', 'dotted', 'dashed')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set the icon size', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon Size', 'dpr-adeline-extensions'),

				'param_name'		=> 'features_icon_size',

				'suffix'			=> 'px',

				'value'				=> 14,

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the color for the feature\'s icon', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'features_icon_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-3',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Specify the top/bottom offset between the pricing box features', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Top/bottom offset', 'dpr-adeline-extensions'),

				'param_name'		=> 'features_offset',

				'suffix'			=> 'px',

				'value'				=> 20,

				'edit_field_class'	=> 'vc_column vc_col-sm-3',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

		)

	)

);