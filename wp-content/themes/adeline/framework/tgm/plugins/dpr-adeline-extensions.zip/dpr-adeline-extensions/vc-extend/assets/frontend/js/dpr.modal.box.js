var $j = jQuery.noConflict();

$j( document ).on( 'ready', function() {
	"use strict";
	// Custom select
	dprInitializeModalBoxes();
} );

/* ==============================================
MODAL BOXES
============================================== */
function dprInitializeModalBoxes() {
	"use strict"
    $j(function(){

		$j('.dpr-md-trigger').click(function(){
							var _id = $j(this).data('id');
							$j('#modal-'+_id).addClass("md-show");
							$j('#overlay-'+_id).addClass("active");
							return false;
						});
		$j('.dpr-md-overlay').click(function(){
							var _id = $j(this).data('id');
							$j('#modal-'+_id).removeClass("md-show");
							$j(this).removeClass("active");
							return false;
						});
		$j('.dpr-modal-close').click(function(){
							var _id = $j(this).data('id');
							$j('#modal-'+_id).removeClass("md-show");
							$j('#overlay-'+_id).removeClass("active");
							return false;
						});
		$j('.dpr-md-trigger-delay').each(function(){
							var cookie_name = $j(this).data('name');
							var cookie_expiry = $j(this).data('expiry');
							if (cookie_expiry === undefined || cookie_expiry == '') {
								cookie_expiry = 0;
							}
							if ( Cookies.get( cookie_name ) != 'viewed' || Cookies.get( cookie_name ) === undefined  ) { 
							var self = $j(this);
							var _delay = $j(this).data('delay');
							setTimeout(function () {
							var _id = $j(self).data('id');
							$j('#modal-'+_id).addClass("md-show");
							$j('#overlay-'+_id).addClass("active");
							
							}, _delay);
							Cookies.set( cookie_name, 'viewed', { expires: cookie_expiry ,path: '' } );
							}
							return false;
							
						});
		$j('.dpr-md-trigger-onscroll').waypoint(function() {
							var cookie_name = $j(this).data('name');
							var cookie_expiry = $j(this).data('expiry');
							if (cookie_expiry === undefined || cookie_expiry == '') {
								cookie_expiry = 0;
							}
							if ( Cookies.get( cookie_name ) != 'viewed' || Cookies.get( cookie_name ) === undefined  ) {
							var _id = $j(this).data('id');
							$j('#modal-'+_id).addClass("md-show");
							$j('#overlay-'+_id).addClass("active");
							Cookies.set( cookie_name, 'viewed', { expires: cookie_expiry ,path: '' } );
							}
							return false;
							
          },{
              triggerOnce: true,
              offset: '90%'
        });

    });
}