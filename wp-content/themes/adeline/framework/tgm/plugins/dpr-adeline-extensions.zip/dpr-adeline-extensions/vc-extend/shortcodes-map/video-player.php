<?php

// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}

/*

* Add-on Name: Heading

*/



class WPBakeryShortCode_DPR_Video_Player extends WPBakeryShortCode {}



vc_map(

	array(

		'name'					=> esc_html__('DP Video Player', 'dpr-adeline-extensions'),

		'base'					=> 'dpr_video_player',

		"icon"					=> 'icon-dpr-video-player',

		"class"					=> 'dpr_video_player',

  		"category" =>array( esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions')),

		'description'			=> esc_html__('Add a video as inline video player or in popup', 'dpr-adeline-extensions'),

		'params'				=> array(

			array(

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose heading type.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Type', 'dpr-adeline-extensions'),

				'type'				=> 'dpr_image_select',

				'param_name'		=> 'type',

				'simple_mode'		=> false,

				'value' 			=> 'inline',

				'options'			=> array(

					'inline'			=> array(

						'label'			=> esc_html__('Inline Player', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'video-player/inline.png'

					),

					'popup'			=> array(

						'label'			=> esc_html__('PopUp Player', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'video-player/button.png'

					),

					'popup-minimal'			=> array(

						'label'			=> esc_html__('Minimal Button', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'video-player/minimal.png'

					)

				),

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Additional Settings', 'dpr-adeline-extensions' ),

				'param_name'       => 'extra_features_title',

				'edit_field_class' => 'vc_column vc_col-sm-12',

			),

		   vc_map_add_css_animation( false ),

		    array(

				'type' => 'textfield',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Extra Class Name', 'dpr-adeline-extensions'),

				'param_name' => 'el_class',

			),

			array(

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose heading type.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Type', 'dpr-adeline-extensions'),

				'type'				=> 'dpr_image_select',

				'param_name'		=> 'video_type',

				'simple_mode'		=> false,

				'value' 			=> 'oembed',

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

				'options'			=> array(

					'oembed'			=> array(

						'label'			=> esc_html__('oEmbed', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'video-player/oembed.png'

					),

					'selfhosted'			=> array(

						'label'			=> esc_html__('Self Hosted', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'video-player/self-hosted.png'

					)

				),

			),

			array(

				'type'				=> 'attach_image',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Upload or select from media library.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Thumbnail image', 'dpr-adeline-extensions'),

				'param_name'		=> 'thumb_image',

				'edit_field_class'	=> 'vc_column vc_col-sm-4  ',

				'dependency'		=> array('element' => 'type', 'value' => array('inline')),

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose video acpect ratio.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Aspect Ratio', 'dpr-adeline-extensions'),

				'param_name'		=> 'aspect_ratio',

				'value' 			=> '75%',

				'edit_field_class'	=> 'vc_column vc_col-sm-8  ',

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

				'options'			=> array(

					esc_html__('Standart 4:3', 'dpr-adeline-extensions')	=> '75%',

					esc_html__('HD Video 16:9', 'dpr-adeline-extensions')	=> '56.25%',

					esc_html__('Cinemascope 21:9', 'dpr-adeline-extensions')	=> '41.9%',

				),

			),

			array(

				'type'				=> 'textfield',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set title to display in button.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Title', 'dpr-adeline-extensions'),

				'param_name'		=> 'title',

				'value'				=> esc_html__('Title','dpr-adeline-extensions'),

				'admin_label'		=> true,

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'type', 'value' => array('popup')),

			),

			array(

				'type'				=> 'textfield',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set subtitle to display in button.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Subtitle', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle',

				'value'				=> esc_html__('', 'dpr-adeline-extensions'),

				'admin_label'		=> true,

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'type', 'value' => array('popup')),

			),

			array(

				'type'				=> 'textfield',

				'heading'			=> esc_html__('Video link', 'dpr-adeline-extensions'),

				'param_name'		=> 'video_link',

				'value'				=> esc_html__('', 'dpr-adeline-extensions'),

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions')

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Video Container Style', 'dpr-adeline-extensions' ),

				'param_name'       => 'video_container_style_heading',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'type', 'value' => array('inline')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set the border_radius.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border Radius', 'dpr-adeline-extensions'),

				'param_name'		=> 'video_container_border_radius',

				'min'				=> 0,

				'suffix'   			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-6  ',

				'dependency'		=> array('element' => 'type', 'value' => array('inline')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				"type" => "dpr_shadow_picker",

				"class" => "",

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set shadow for video container.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Shadow', 'dpr-adeline-extensions'),

				"param_name" => "container_shadow",

				"value" => "none||||||",

				'dependency'		=> array('element' => 'type', 'value' => array('inline')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				"type" => "dpr_shadow_picker",

				"class" => "",

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set shadow for video container in hover state.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Shadow Hover', 'dpr-adeline-extensions'),

				"param_name" => "container_shadow_hover",

				"value" => "none||||||",

				'dependency'		=> array('element' => 'type', 'value' => array('inline')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Button Style', 'dpr-adeline-extensions' ),

				'param_name'       => 'playbutton_icon_heading',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Button Alignment.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Button alignment', 'dpr-adeline-extensions'),

				'param_name'		=> 'alignment',

				'value'				=> '',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'options'			=> array(

					esc_html__('Left', 'dpr-adeline-extensions')	=> '',

					esc_html__('Center', 'dpr-adeline-extensions')	=> 'text-center',

					esc_html__('Right', 'dpr-adeline-extensions')	=> 'text-right',

				),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'type', 'value' => array('popup','popup-minimal')),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Force full width button', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Full width button', 'dpr-adeline-extensions'),

				'param_name'		=> 'force_fullwidth_button',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'type', 'value' => array('popup')),

			),

			array(

				'type'				=> 'dpr_clear',

				'param_name'		=> 'clear_1',

				'edit_field_class'	=> 'vc_col-sm-12 vc_column ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom icon color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_color',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom icon color on hover', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon Color Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_color_hover',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom icon background color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon Background Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_bg_color',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom icon color on hover', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon Background Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_bg_color_hover',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom icon border color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon border Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_border_color',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'type', 'value' => array('inline','popup-minimal')),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom icon border_color on hover', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon Border Color Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_border_color_hover',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'type', 'value' => array('inline','popup-minimal')),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set the custom icon border size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border Width', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_border_size',

				'min'				=> 0,

				'suffix'   			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4  ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'type', 'value' => array('inline','popup-minimal')),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set the custom play button size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Button size', 'dpr-adeline-extensions'),

				'param_name'		=> 'button_size',

				'min'				=> 0,

				'suffix'   			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4  ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set the custom play button icon size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon Size', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_size',

				'min'				=> 0,

				'suffix'   			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Add pulse animation.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Pulse animation', 'dpr-adeline-extensions'),

				'param_name'		=> 'pulse_animation',

				'value'				=> '',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'options'			=> array(

					esc_html__('None', 'dpr-adeline-extensions')	=> '',

					esc_html__('On Hover', 'dpr-adeline-extensions')	=> 'pulse-onhover',

					esc_html__('Permanent', 'dpr-adeline-extensions')	=> 'pulse-permanent',

				),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'type', 'value' => array('popup-minimal')),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose pulse animation color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Pulse animation color', 'dpr-adeline-extensions'),

				'param_name'		=> 'pulse_color',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'pulse_animation', 'value' => array('pulse-onhover','pulse-permanent')),

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Button Outline Style', 'dpr-adeline-extensions' ),

				'param_name'       => 'button_outline_heading',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'type', 'value' => array('popup')),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose button outline background color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Button Outline Background', 'dpr-adeline-extensions'),

				'param_name'		=> 'outline_bg',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'type', 'value' => array('popup')),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose button outline background color on hover', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Button Outline Background Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'outline_bg_hover',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'type', 'value' => array('popup')),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose button outline border color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Button Outline Border', 'dpr-adeline-extensions'),

				'param_name'		=> 'outline_border',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'type', 'value' => array('popup')),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose button outline border color on hover', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Button Outline Border Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'outline_border_hover',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'type', 'value' => array('popup')),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set the outline border width.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border Width', 'dpr-adeline-extensions'),

				'param_name'		=> 'outline_border_width',

				'min'				=> 0,

				'suffix'   			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-6  ',

				'dependency'		=> array('element' => 'type', 'value' => array('popup')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set the outline padding.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Padding', 'dpr-adeline-extensions'),

				'param_name'		=> 'outline_padding',

				'min'				=> 0,

				'suffix'   			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-6  ',

				'dependency'		=> array('element' => 'type', 'value' => array('popup')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Title Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_typography_head',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'type', 'value' => array('popup')),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom title color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Title Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_color',

				'edit_field_class'	=> 'vc_col-sm-3 vc_column ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'type', 'value' => array('popup')),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size. If you leave this field blank will be used default size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'type', 'value' => array('popup')),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title line height.Default is 18px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'type', 'value' => array('popup')),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'type', 'value' => array('popup')),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'title_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'type', 'value' => array('popup')),

	  		),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font. .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_title_google_fonts',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'type', 'value' => array('popup')),

			),

			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'title_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'dependency'		=> array('element' => 'use_title_google_fonts', 'value' => array('yes')),

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Subtitle Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_typography_head',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'type', 'value' => array('popup')),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom subtitle color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Subtitle Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_color',

				'edit_field_class'	=> 'vc_col-sm-3 vc_column ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'type', 'value' => array('popup')),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size. If you leave this field blank will be used default size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'type', 'value' => array('popup')),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title linne height.Default is 18px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'type', 'value' => array('popup')),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'type', 'value' => array('popup')),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'subtitle_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'type', 'value' => array('popup')),

	  		),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_subtitle_google_fonts',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'type', 'value' => array('popup')),

			),

			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'subtitle_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'dependency'		=> array('element' => 'use_subtitle_google_fonts', 'value' => array('yes')),

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

		),

	)

);