<?php

if ( ! defined( 'ABSPATH' ) ) { exit; }



class WPBakeryShortCode_DPR_Social_Icons extends WPBakeryShortCode {}



vc_map(

	array(

		'name'					=> esc_html__('DP Social Icons', 'dpr-adeline-extensions'),

		'base'					=> 'dpr_social_icons',

		'class'					=> '',

		'icon'					=> 'icon-dpr-social-icons',

  		"category" =>array( esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions')),

		"description" => esc_attr__('Display list of social icons', 'dpr-adeline-extensions'),

		'params'				=> array(

			array(

				'heading'			=> esc_html__('Style', 'dpr-adeline-extensions'),

				'type'				=> 'dpr_image_select',

				'param_name'		=> 'style',

				'simple_mode'		=> false,

				'value' => 'minima-social',

				'options'			=> array(

					'minimal-social'	=> array(

						'label'	=> esc_html__('Minimal','dpr-adeline-extensions'),

						'src'		=> $module_images . 'social-icons/minimal.jpg'

					),

					'rounded'	=> array(

						'label'	=> esc_html__('Rounded','dpr-adeline-extensions'),

						'src'		=> $module_images . 'social-icons/rounded.jpg'

					),

					'outlined'	=> array(

						'label'	=> esc_html__('Outlined','dpr-adeline-extensions'),

						'src'		=> $module_images . 'social-icons/outlined.jpg'

					),

					'colored'	=> array(

						'label'	=> esc_html__('colored','dpr-adeline-extensions'),

						'src'		=> $module_images . 'social-icons/colored.jpg'

					),

				),

			),

			array(

				'type' => 'dpr_radio',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Set buttons alignment', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Alignment', 'dpr-adeline-extensions'),

				'param_name'		=> 'alignment',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'value' => '',

				'options' => array(

					__('Left', 'dpr-adeline-extensions') => '',

					__('Center', 'dpr-adeline-extensions') => 'text-center',

					__('Right', 'dpr-adeline-extensions') => 'text-right',

				),

				'value'			=> 'left',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Additional Settings', 'dpr-adeline-extensions' ),

				'param_name'       => 'extra_features_title',

				'edit_field_class' => 'vc_column vc_col-sm-12',

			),

		   vc_map_add_css_animation( false ),

		    array(

				'type' => 'textfield',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Extra Class Name', 'dpr-adeline-extensions'),

				'param_name' => 'el_class',

			),

			array(

				'type'				=> 'param_group',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Add social networks to this list', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Networks', 'dpr-adeline-extensions'),

				'param_name'		=> 'social_networks',

				'value' => urlencode( json_encode( array(

				array(

					'network' => 'facebook',

				),

				array(

					'network' => 'instagram',

				),

				array(

					'network' => 'pinterest',

				),

			) ) ),



				'params'			=> array(

					array(

						'type'				=> 'dropdown',

						'param_name'		=> 'network',

						'heading'			=> esc_html__('Network', 'dpr-adeline-extensions'),

						'default' => '',

						'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

						'admin_label' => true,

						'value'			=> array(

							esc_html__('Facebook', 'dpr-adeline-extensions')		=> 'facebook',

							esc_html__('Twitter', 'dpr-adeline-extensions')			=> 'twitter',

							esc_html__('Google+', 'dpr-adeline-extensions')			=> 'google-plus',

							esc_html__('Pinterest', 'dpr-adeline-extensions')		=> 'pinterest-p',

							esc_html__('Dribbble', 'dpr-adeline-extensions')		=> 'dribbble',

							esc_html__('Instagram', 'dpr-adeline-extensions')		=> 'instagram',

							esc_html__('Linkedin', 'dpr-adeline-extensions')		=> 'linkedin',

							esc_html__('Flickr', 'dpr-adeline-extensions')			=> 'flickr',

							esc_html__('Skype', 'dpr-adeline-extensions')			=> 'skype',

							esc_html__('VK', 'dpr-adeline-extensions')				=> 'vk',

							esc_html__('Tumblr', 'dpr-adeline-extensions')			=> 'tumblr',

							esc_html__('Github', 'dpr-adeline-extensions')			=> 'github-alt',

							esc_html__('YouTube', 'dpr-adeline-extensions')			=> 'youtube',

							esc_html__('Vimeo', 'dpr-adeline-extensions')			=> 'vimeo',

							esc_html__('Vine', 'dpr-adeline-extensions')			=> 'vine',

							esc_html__('Stumbleupon', 'dpr-adeline-extensions')		=> 'stumbleupon',

							esc_html__('Xing', 'dpr-adeline-extensions')			=> 'xing',

							esc_html__('Digg', 'dpr-adeline-extensions')			=> 'digg',

							esc_html__('Lastfm', 'dpr-adeline-extensions')			=> 'lastfm',

							esc_html__('Soundcloud', 'dpr-adeline-extensions')		=> 'soundcloud',

							esc_html__('Delicious', 'dpr-adeline-extensions')		=> 'delicious',

							esc_html__('Yelp', 'dpr-adeline-extensions')			=> 'yelp',

							esc_html__('Tripadvisor', 'dpr-adeline-extensions') 	=> 'tripadvisor',
							esc_html__('Odnoklassniki', 'dpr-adeline-extensions') 	=> 'odnoklassniki',
							esc_html__('RSS', 'dpr-adeline-extensions')				=> 'rss',

							esc_html__('Email', 'dpr-adeline-extensions')			=> 'envelope-o',

						),

					

					),

					array(

						'type'				=> 'vc_link',

						'heading' => esc_html__('Link URL', 'dpr-adeline-extensions'),

						'param_name'		=> 'link',

						'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

					),

				),

				'group'				=> esc_html__('Social Networks', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set the size for the icons', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon Size', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_size',

				'suffix' 			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-6   ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set the padding for the icons', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon Paddings', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_padding',

				'suffix' 			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-6   ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'class'				=> '',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose icons color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6  ',

				'dependency'		=> array('element' => 'style', 'value' => array('minimal-social','rounded','outlined')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'class'				=> '',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose icons hover color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon Color: Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_color_hover',

				'edit_field_class'	=> 'vc_column vc_col-sm-6  ',

				'dependency'		=> array('element' => 'style', 'value' => array('minimal-social','rounded','outlined')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'             => 'dpr_title',

				'text'             => '',

				'param_name'       => 'style_sep_1',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'class'				=> '',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose icons background color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon Background Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_bg_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6  ',

				'dependency'		=> array('element' => 'style', 'value' => array('rounded')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'class'				=> '',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose icons background color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon Background Color:hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_bg_color_hover',

				'edit_field_class'	=> 'vc_column vc_col-sm-6  ',

				'dependency'		=> array('element' => 'style', 'value' => array('rounded')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'             => 'dpr_title',

				'text'             => '',

				'param_name'       => 'style_sep_2',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'class'				=> '',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose icons border color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon Border Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_border_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6  ',

				'dependency'		=> array('element' => 'style', 'value' => array('outlined')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'class'				=> '',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose icons border color hover.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon Border Color: Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_border_color_hover',

				'edit_field_class'	=> 'vc_column vc_col-sm-6  ',

				'dependency'		=> array('element' => 'style', 'value' => array('outlined')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'             => 'dpr_title',

				'text'             => '',

				'param_name'       => 'style_sep_3',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'class'				=> '',

				'suffix' 			=> 'px',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose icons border radius.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon Border Radius', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_border_radius',

				'edit_field_class'	=> 'vc_column vc_col-sm-6  ',

				'dependency'		=> array('element' => 'style', 'value' => array('colored','rounded','outlined')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'class'				=> '',

				'suffix' 			=> 'px',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose icons border radius hover.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon Border Radius:hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_border_radius_hover',

				'edit_field_class'	=> 'vc_column vc_col-sm-6  ',

				'dependency'		=> array('element' => 'style', 'value' => array('colored','rounded','outlined')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'class'				=> '',

				'suffix' 			=> 'px',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose icons border width.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon Border Width', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_border_width',

				'edit_field_class'	=> 'vc_column vc_col-sm-6  ',

				'dependency'		=> array('element' => 'style', 'value' => array('outlined')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			

			array(

				'type' => 'css_editor',

				'heading' => __( 'CSS box', 'dpr-adeline-extensions' ),

				'param_name' => 'css',

				'group' => __( 'Design Options', 'dpr-adeline-extensions' ),

			),

		),

	)

);