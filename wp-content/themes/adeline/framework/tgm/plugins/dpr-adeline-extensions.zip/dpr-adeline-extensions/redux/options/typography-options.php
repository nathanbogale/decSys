<?php

/**



 * Typography Theme Options



 *



 */

Redux::setSection($opt_name, array(

    'title' => __('Typography', 'dpr-adeline-extensions'),

    'id'    => 'typography_tab',

    'desc'  => __('Basic theme typography is configured here.', 'dpr-adeline-extensions'),

    'icon'  => 'el el-fontsize',

));

Redux::setSection($opt_name, array(

    'title'      => esc_html__('Body', 'dpr-adeline-extensions'),

    'subsection' => true,

    'fields'     => array(

        array(

            'id'             => 'body_typo',

            'type'           => 'typography',

            'title'          => esc_html__('Body Typography', 'dpr-adeline-extensions'),

            'google'         => true,

            'font-style'     => true,

            'subsets'        => true,

            'font-size'      => true,

            'text-align'     => false,

            'line-height'    => true,

            'word-spacing'   => false,

            'letter-spacing' => true,

            'text-transform' => true,

            'color'          => true,

            'preview'        => true,

            'all_styles'     => true,

            'output'         => array('body'),

            'units'          => 'px',

            'default'        => array(

                'font-style'  => '',

                'font-weight' => '300',

                'font-family' => 'Roboto',

                'google'      => true,

                'font-size'   => '17px',

                'line-height' => '27px',

                'color'       => '#555555 ',

            ),

            'hint'           => array(

                'title'   => esc_attr__('Body Typography', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify the typography settings and color for the text. It will be applied for all the text areas by default', 'dpr-adeline-extensions'),

            ),

        ),

    ),

));

Redux::setSection($opt_name, array(

    'title'      => esc_html__('Headings Typgraphy', 'dpr-adeline-extensions'),

    'subsection' => true,

    'fields'     => array(

        array(

            'id'             => 'headings_typo',

            'type'           => 'typography',

            'title'          => esc_html__('All Headdings', 'dpr-adeline-extensions'),

            'google'         => true,

            'font-style'     => true,

            'subsets'        => true,

            'font-size'      => false,

            'text-align'     => false,

            'line-height'    => false,

            'word-spacing'   => false,

            'letter-spacing' => true,

            'text-transform' => true,

            'color'          => true,

            'output'         => 'h1,h2,h3,h4,h5,h6,.theme-heading,.widget-title,.comment-reply-title,.entry-title,.sidebar-box .widget-title, .small-heading, #side-panel-wrap .sidebar-box .panel-widget-title, .price,.vc_tta-tab a, .portfolio-items .portfolio-filters li a',

            'preview'        => true,

            'all_styles'     => true,

            'units'          => 'px',

            'default'        => array(

                'font-style'     => '',

                'font-weight'    => '700',

                'font-family'    => 'Roboto',

                'google'         => true,

                'color'          => '#292933',

                'text-transform' => 'none',

            ),

            'hint'           => array(

                'title'   => esc_attr__('H1 typography', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify the typography settings and color for the H1. You can use the H1 as element tag in Visual Composer modules', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'             => 'h1_typo',

            'type'           => 'typography',

            'title'          => esc_html__('H1 typography', 'dpr-adeline-extensions'),

            'google'         => true,

            'font-style'     => true,

            'subsets'        => true,

            'font-size'      => true,

            'text-align'     => false,

            'line-height'    => true,

            'word-spacing'   => false,

            'letter-spacing' => true,

            'text-transform' => true,

            'color'          => true,

            'preview'        => true,

            'all_styles'     => true,

            'units'          => 'px',

            'output'         => array('h1'),

            'default'        => array(

                'font-style'     => '',

                'font-weight'    => '700',

                'font-family'    => 'Roboto',

                'google'         => true,

                'font-size'      => '52px',

                'line-height'    => '58px',

                'letter-spacing' => '',

                'text-transform' => 'none',

                'color'          => '#292933',

            ),

            'hint'           => array(

                'title'   => esc_attr__('H1 typography', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify the typography settings and color for the H1. You can use the H1 as element tag in Visual Composer modules', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'             => 'h2_typo',

            'type'           => 'typography',

            'title'          => esc_html__('H2 typography', 'dpr-adeline-extensions'),

            'google'         => true,

            'font-style'     => true,

            'subsets'        => true,

            'font-size'      => true,

            'text-align'     => false,

            'line-height'    => true,

            'word-spacing'   => false,

            'letter-spacing' => true,

            'text-transform' => true,

            'color'          => true,

            'preview'        => true,

            'all_styles'     => true,

            'units'          => 'px',

            'output'         => array('h2'),

            'default'        => array(

                'font-style'     => '',

                'font-weight'    => '700',

                'font-family'    => 'Roboto',

                'google'         => true,

                'font-size'      => '42px',

                'line-height'    => '47px',

                'letter-spacing' => '',

                'text-transform' => 'none',

                'color'          => '#292933',

            ),

            'hint'           => array(

                'title'   => esc_attr__('H2 typography', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify the typography settings and color for the H1. You can use the H2 as element tag in Visual Composer modules', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'             => 'h3_typo',

            'type'           => 'typography',

            'title'          => esc_html__('H3 typography', 'dpr-adeline-extensions'),

            'google'         => true,

            'font-style'     => true,

            'subsets'        => true,

            'font-size'      => true,

            'text-align'     => false,

            'line-height'    => true,

            'word-spacing'   => false,

            'letter-spacing' => true,

            'text-transform' => true,

            'color'          => true,

            'preview'        => true,

            'all_styles'     => true,

            'units'          => 'px',

            'output'         => 'h3, .dpr-heading h1, .dpr-heading h2, .dpr-heading h4, .dpr-heading h5, .dpr-heading h6',

            'default'        => array(

                'font-style'     => '',

                'font-weight'    => '700',

                'font-family'    => 'Roboto',

                'google'         => true,

                'font-size'      => '32px',

                'line-height'    => '35px',

                'letter-spacing' => '',

                'text-transform' => 'none',

                'color'          => '#292933',

            ),

            'hint'           => array(

                'title'   => esc_attr__('H3 typography', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify the typography settings and color for the H1. You can use the H3 as element tag in Visual Composer modules', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'             => 'h4_typo',

            'type'           => 'typography',

            'title'          => esc_html__('H4 typography', 'dpr-adeline-extensions'),

            'google'         => true,

            'font-style'     => true,

            'subsets'        => true,

            'font-size'      => true,

            'text-align'     => false,

            'line-height'    => true,

            'word-spacing'   => false,

            'letter-spacing' => true,

            'text-transform' => true,

            'color'          => true,

            'preview'        => true,

            'all_styles'     => true,

            'units'          => 'px',

            'output'         => array('h4'),

            'default'        => array(

                'font-style'     => '',

                'font-weight'    => '700',

                'font-family'    => 'Roboto',

                'google'         => true,

                'font-size'      => '25px',

                'line-height'    => '30px',

                'letter-spacing' => '',

                'text-transform' => 'none',

                'color'          => '#292933',

            ),

            'hint'           => array(

                'title'   => esc_attr__('H4 typography', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify the typography settings and color for the H1. You can use the H4 as element tag in Visual Composer modules', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'             => 'h5_typo',

            'type'           => 'typography',

            'title'          => esc_html__('H5 typography', 'dpr-adeline-extensions'),

            'google'         => true,

            'font-style'     => true,

            'subsets'        => true,

            'font-size'      => true,

            'text-align'     => false,

            'line-height'    => true,

            'word-spacing'   => false,

            'letter-spacing' => true,

            'text-transform' => true,

            'color'          => true,

            'preview'        => true,

            'all_styles'     => true,

            'units'          => 'px',

            'output'         => array('h5'),

            'default'        => array(

                'font-style'     => '',

                'font-weight'    => '700',

                'font-family'    => 'Roboto',

                'google'         => true,

                'font-size'      => '20px',

                'line-height'    => '25px',

                'text-transform' => 'none',

                'letter-spacing' => '',

                'color'          => '#292933',

            ),

            'hint'           => array(

                'title'   => esc_attr__('H5 typography', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify the typography settings and color for the H1. You can use the H5 as element tag in Visual Composer modules', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'             => 'h6_typo',

            'type'           => 'typography',

            'title'          => esc_html__('H6 typography', 'dpr-adeline-extensions'),

            'google'         => true,

            'font-style'     => true,

            'subsets'        => true,

            'font-size'      => true,

            'text-align'     => false,

            'line-height'    => true,

            'word-spacing'   => false,

            'letter-spacing' => true,

            'text-transform' => true,

            'color'          => true,

            'preview'        => true,

            'all_styles'     => true,

            'units'          => 'px',

            'output'         => array('h6'),

            'default'        => array(

                'font-style'     => '',

                'font-weight'    => '700',

                'font-family'    => 'Roboto',

                'google'         => true,

                'font-size'      => '15px',

                'line-height'    => '16px',

                'text-transform' => 'none',

                'letter-spacing' => '',

                'color'          => '#292933',

            ),

            'hint'           => array(

                'title'   => esc_attr__('H6 typography', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify the typography settings and color for the H1. You can use the H6 as element tag in Visual Composer modules', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'             => 'deco_typo',

            'type'           => 'typography',

            'title'          => esc_html__('Heading Decoration Font', 'dpr-adeline-extensions'),

            'google'         => true,

            'font-style'     => true,

            'subsets'        => true,

            'font-size'      => true,

            'text-align'     => false,

            'line-height'    => true,

            'word-spacing'   => false,

            'letter-spacing' => true,

            'text-transform' => true,

            'color'          => true,

            'preview'        => true,

            'all_styles'     => true,

            'units'          => 'px',

            'output'         => array('.deco-font'),

            'default'        => array(

                'font-style'     => '',

                'font-weight'    => '',

                'font-family'    => '',

                'google'         => true,

                'font-size'      => '',

                'line-height'    => '',

                'text-transform' => 'none',

                'letter-spacing' => '1px',

                'color'          => '#D3AE5F',

            ),

            'hint'           => array(

                'title'   => esc_attr__('Heading Decoration Font', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify the typography settings and color for the decoration font used in content with class deco-font. You can use the this class for any element in Visual Composer modules', 'dpr-adeline-extensions'),

            ),

        ),

    ),

));

Redux::setSection($opt_name, array(

    'title'      => esc_html__('Top Bar', 'dpr-adeline-extensions'),

    'subsection' => true,

    'fields'     => array(

        array(

            'id'             => 'top_bar_typo',

            'type'           => 'typography',

            'title'          => esc_html__('Top Bar Typography', 'dpr-adeline-extensions'),

            'google'         => true,

            'font-style'     => true,

            'subsets'        => true,

            'font-size'      => true,

            'text-align'     => false,

            'line-height'    => true,

            'word-spacing'   => false,

            'letter-spacing' => true,

            'text-transform' => true,

            'color'          => false,

            'preview'        => true,

            'all_styles'     => true,

            'output'         => array('#dpr-top-bar-content'),

            'units'          => 'px',

            'default'        => array(

                'font-style'  => '',

                'google'      => true,

                'font-size'   => '14px',

                'line-height' => '19px',

            ),

            'hint'           => array(

                'title'   => esc_attr__('Top Bar Typography', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify the typography settings and top bar.', 'dpr-adeline-extensions'),

            ),

        ),

    ),

));

Redux::setSection($opt_name, array(

    'title'      => esc_html__('Menu', 'dpr-adeline-extensions'),

    'subsection' => true,

    'fields'     => array(

        array(

            'id'             => 'main_menu_typo',

            'type'           => 'typography',

            'title'          => esc_html__('Main Menu', 'dpr-adeline-extensions'),

            'google'         => true,

            'font-style'     => true,

            'subsets'        => true,

            'font-size'      => true,

            'text-align'     => false,

            'line-height'    => false,

            'word-spacing'   => false,

            'letter-spacing' => true,

            'text-transform' => true,

            'color'          => false,

            'preview'        => true,

            'all_styles'     => true,

            'output'         => array('#dpr-navigation-wrapper .dropdown-menu > li > a', '.full_screen-header .fs-dropdown-menu > li > a', '#dpr-header.top-header #dpr-navigation-wrapper .dropdown-menu > li > a', '#dpr-header.center-header #dpr-navigation-wrapper .dropdown-menu > li > a', '#dpr-header.magazine-header #dpr-navigation-wrapper .dropdown-menu > li > a', '#dpr-adeline-mobile-menu-icon a'),

            'units'          => 'px',

            'default'        => array(

                'font-family'    => 'Roboto',

                'font-style'     => '',

                'font-weight'    => '700',

                'google'         => true,

                'font-size'      => '14px',

                'text-transform' => 'uppercase',

                'letter-spacing' => '',

            ),

            'hint'           => array(

                'title'   => esc_attr__('Main Menu', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify the typography settings for main menu.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'             => 'main_menu_dropdown_typo',

            'type'           => 'typography',

            'title'          => esc_html__('Main Menu: Dropdown', 'dpr-adeline-extensions'),

            'google'         => true,

            'font-style'     => true,

            'subsets'        => true,

            'font-size'      => true,

            'text-align'     => false,

            'line-height'    => true,

            'word-spacing'   => false,

            'letter-spacing' => true,

            'text-transform' => true,

            'color'          => false,

            'preview'        => true,

            'all_styles'     => true,

            'output'         => array('.dropdown-menu ul li a.menu-link', '.full_screen-header .fs-dropdown-menu ul.sub-menu li a'),

            'units'          => 'px',

            'default'        => array(

                'font-family'    => 'Roboto',

                'font-style'     => '',

                'google'         => true,

                'font-weight'    => '400',

                'font-size'      => '15px',

                'line-height'    => '25px',

                'text-transform' => '',

                'letter-spacing' => '',

            ),

            'hint'           => array(

                'title'   => esc_attr__('Main Menu: Dropdown', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify the typography settings for main menu dropdown.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'             => 'main_menu_dropdown_hedings_typo',

            'type'           => 'typography',

            'title'          => esc_html__('Main Menu: Megamenu Column Headings', 'dpr-adeline-extensions'),

            'google'         => true,

            'font-style'     => true,

            'subsets'        => true,

            'font-size'      => true,

            'text-align'     => false,

            'line-height'    => true,

            'word-spacing'   => false,

            'letter-spacing' => true,

            'text-transform' => true,

            'color'          => false,

            'preview'        => true,

            'all_styles'     => true,

            'output'         => array('.navigation .megamenu>li>a.menu-link '),

            'units'          => 'px',

            'default'        => array(

                'font-family'    => 'Roboto',

                'font-style'     => '',

                'google'         => true,

                'font-weight'    => '500',

                'font-size'      => '14px',

                'line-height'    => '25px',

                'text-transform' => 'uppercase',

                'letter-spacing' => '',

            ),

            'hint'           => array(

                'title'   => esc_attr__('Megamenu Column Headings', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify the typography settings for megamenu columns headings.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'             => 'fullscreen_menu_typo',

            'type'           => 'typography',

            'title'          => esc_html__('Full Screen Menu', 'dpr-adeline-extensions'),

            'google'         => true,

            'font-style'     => true,

            'subsets'        => true,

            'font-size'      => true,

            'text-align'     => false,

            'line-height'    => false,

            'word-spacing'   => false,

            'letter-spacing' => true,

            'text-transform' => true,

            'color'          => false,

            'preview'        => true,

            'all_styles'     => true,

            'output'         => array('.full_screen-header .fs-dropdown-menu > li > a'),

            'units'          => 'px',

            'default'        => array(

                'font-family'    => 'Roboto',

                'font-style'     => '',

                'font-weight'    => '700',

                'google'         => true,

                'font-size'      => '25px',

                'letter-spacing' => '',

            ),

            'hint'           => array(

                'title'   => esc_attr__('Full Screen Menu', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify the typography settings for full screen menu.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'             => 'fullscreen_menu_dropdown_typo',

            'type'           => 'typography',

            'title'          => esc_html__('Full Screen Menu: Dropdown', 'dpr-adeline-extensions'),

            'google'         => true,

            'font-style'     => true,

            'subsets'        => true,

            'font-size'      => true,

            'text-align'     => false,

            'line-height'    => true,

            'word-spacing'   => false,

            'letter-spacing' => true,

            'text-transform' => true,

            'color'          => false,

            'preview'        => true,

            'all_styles'     => true,

            'output'         => '.full_screen-header .fs-dropdown-menu ul.sub-menu li a',

            'units'          => 'px',

            'default'        => array(

                'font-family'    => 'Roboto',

                'font-style'     => '',

                'google'         => true,

                'font-weight'    => '600',

                'font-size'      => '14px',

                'line-height'    => '15px',

                'text-transform' => 'uppercase',

                'letter-spacing' => '',

            ),

            'hint'           => array(

                'title'   => esc_attr__('Full Screen Menu: Dropdown', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify the typography settings for full screen menu dropdown.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'             => 'mobile_menu_typo',

            'type'           => 'typography',

            'title'          => esc_html__('Mobile Menu', 'dpr-adeline-extensions'),

            'google'         => true,

            'font-style'     => true,

            'subsets'        => true,

            'font-size'      => true,

            'text-align'     => false,

            'line-height'    => true,

            'word-spacing'   => false,

            'letter-spacing' => true,

            'text-transform' => true,

            'color'          => false,

            'preview'        => true,

            'all_styles'     => true,

            'output'         => array('.sidr-class-dropdown-menu li a', ' a.sidr-class-toggle-sidr-close', '#mobile-dropdown ul li a', 'body #mobile-fullscreen ul li a'),

            'units'          => 'px',

            'default'        => array(

                'font-family'    => 'Roboto',

                'font-style'     => '',

                'google'         => true,

                'font-weight'    => '600',

                'font-size'      => '15px',

                'line-height'    => '27px',

                'text-transform' => 'uppercase',

            ),

            'hint'           => array(

                'title'   => esc_attr__('Mobile Menu', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify the typography settings for mobile menu.', 'dpr-adeline-extensions'),

            ),

        )),

));

Redux::setSection($opt_name, array(

    'title'      => esc_html__('Subheader', 'dpr-adeline-extensions'),

    'subsection' => true,

    'fields'     => array(

        array(

            'id'             => 'subheader_title_typo',

            'type'           => 'typography',

            'title'          => esc_html__('Title', 'dpr-adeline-extensions'),

            'google'         => true,

            'font-style'     => true,

            'subsets'        => true,

            'font-size'      => true,

            'text-align'     => false,

            'line-height'    => true,

            'word-spacing'   => false,

            'letter-spacing' => true,

            'text-transform' => true,

            'color'          => false,

            'preview'        => true,

            'all_styles'     => true,

            'output'         => array('.subheader .subheader-title'),

            'units'          => 'px',

            'default'        => array(

                'font-family'    => 'Roboto',

                'font-style'     => '',

                'google'         => true,

                'font-weight'    => '700',

                'font-size'      => '52px',

                'line-height'    => '58px',

                'text-transform' => '',

            ),

            'hint'           => array(

                'title'   => esc_attr__('Title', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify the typography settings for subheader title.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'             => 'subheader_subtitle_typo',

            'type'           => 'typography',

            'title'          => esc_html__('Subtitle', 'dpr-adeline-extensions'),

            'google'         => true,

            'font-style'     => true,

            'subsets'        => true,

            'font-size'      => true,

            'text-align'     => false,

            'line-height'    => true,

            'word-spacing'   => false,

            'letter-spacing' => true,

            'text-transform' => true,

            'color'          => false,

            'preview'        => true,

            'all_styles'     => true,

            'output'         => array('.subheader .subheader-subtitle'),

            'units'          => 'px',

            'default'        => array(

                'font-family'    => 'Roboto Slab',

                'font-style'     => '',

                'google'         => true,

                'font-weight'    => '300',

                'font-size'      => '20px',

                'line-height'    => '25px',

                'text-transform' => '',

            ),

            'hint'           => array(

                'title'   => esc_attr__('Title', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify the typography settings for subheader subtitle.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'             => 'breadcrumb_typo',

            'type'           => 'typography',

            'title'          => esc_html__('Breadcrumb', 'dpr-adeline-extensions'),

            'google'         => true,

            'font-style'     => true,

            'subsets'        => true,

            'font-size'      => true,

            'text-align'     => false,

            'line-height'    => false,

            'word-spacing'   => false,

            'letter-spacing' => true,

            'text-transform' => true,

            'color'          => false,

            'preview'        => true,

            'all_styles'     => true,

            'output'         => array('.dpr-adeline-breadcrumbs'),

            'units'          => 'px',

            'default'        => array(

                'font-family' => 'Roboto',

                'font-style'  => '',

                'google'      => true,

                'font-size'   => '13px',

            ),

            'hint'           => array(

                'title'   => esc_attr__('Title', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify the typography settings for subheader title.', 'dpr-adeline-extensions'),

            ),

        ),

    ),

));

Redux::setSection($opt_name, array(

    'title'      => esc_html__('Blog', 'dpr-adeline-extensions'),

    'subsection' => true,

    'fields'     => array(

        array(

            'id'             => 'blog_entries_titles_typo',

            'type'           => 'typography',

            'title'          => esc_html__('Blog Entries Title', 'dpr-adeline-extensions'),

            'google'         => true,

            'font-style'     => true,

            'subsets'        => true,

            'font-size'      => true,

            'text-align'     => false,

            'line-height'    => true,

            'word-spacing'   => false,

            'letter-spacing' => true,

            'text-transform' => true,

            'color'          => true,

            'preview'        => true,

            'all_styles'     => true,

            'output'         => array('.blog-item.post .blog-item-header .entry-title'),

            'units'          => 'px',

            'default'        => array(

                'font-family'    => 'Roboto',

                'font-style'     => '',

                'google'         => true,

                'font-weight'    => '700',

                'font-size'      => '42x',

                'line-height'    => '47px',

                'color'          => '#292933',

                'letter-spacing' => '',

                'text-transform' => '',

            ),

            'hint'           => array(

                'title'   => esc_attr__('Title', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify the typography settings for blog entries title. Will be used in blog view', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'             => 'blog_entries_medium_titles_typo',

            'type'           => 'typography',

            'title'          => esc_html__('Blog Entries Title (Medium Images)', 'dpr-adeline-extensions'),

            'google'         => true,

            'font-style'     => true,

            'subsets'        => true,

            'font-size'      => true,

            'text-align'     => false,

            'line-height'    => true,

            'word-spacing'   => false,

            'letter-spacing' => true,

            'text-transform' => true,

            'color'          => true,

            'preview'        => true,

            'all_styles'     => true,

            'output'         => array('.blog-item.post.small-image .blog-item-header .entry-title'),

            'units'          => 'px',

            'default'        => array(

                'font-family'    => 'Roboto',

                'font-style'     => '',

                'google'         => true,

                'font-weight'    => '700',

                'font-size'      => '25px',

                'line-height'    => '30px',

                'color'          => '#292933',

                'letter-spacing' => '',

            ),

            'hint'           => array(

                'title'   => esc_attr__('Title', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify the typography settings for blog entries. Will be used in blog grid view', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'             => 'blog_entries_grid_titles_typo',

            'type'           => 'typography',

            'title'          => esc_html__('Blog Entries Title (Grid View)', 'dpr-adeline-extensions'),

            'google'         => true,

            'font-style'     => true,

            'subsets'        => true,

            'font-size'      => true,

            'text-align'     => false,

            'line-height'    => true,

            'word-spacing'   => false,

            'letter-spacing' => true,

            'text-transform' => true,

            'color'          => true,

            'preview'        => true,

            'all_styles'     => true,

            'output'         => array('.blog-item.post.posts-grid .blog-item-header .entry-title'),

            'units'          => 'px',

            'default'        => array(

                'font-family'    => 'Roboto',

                'font-style'     => '',

                'google'         => true,

                'font-weight'    => '700',

                'font-size'      => '25px',

                'line-height'    => '30px',

                'color'          => '#292933',

                'letter-spacing' => '0px',

            ),

            'hint'           => array(

                'title'   => esc_attr__('Title', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify the typography settings for blog entries. Will be used in blog grid view', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'             => 'blog_post_title_typo',

            'type'           => 'typography',

            'title'          => esc_html__('Single Post Title', 'dpr-adeline-extensions'),

            'google'         => true,

            'font-style'     => true,

            'subsets'        => true,

            'font-size'      => true,

            'text-align'     => false,

            'line-height'    => true,

            'word-spacing'   => false,

            'letter-spacing' => true,

            'text-transform' => true,

            'color'          => false,

            'preview'        => true,

            'all_styles'     => true,

            'output'         => array('.single-post .entry-title'),

            'units'          => 'px',

            'default'        => array(

                'font-family'    => 'Roboto',

                'font-style'     => '',

                'google'         => true,

                'font-weight'    => '700',

                'font-size'      => '42px',

                'line-height'    => '47px',

                'color'          => '#292933',

                'letter-spacing' => '',

                'text-transform' => 'none',

            ),

            'hint'           => array(

                'title'   => esc_attr__('Title', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify the typography settings for single post title when is not displayed in subheader.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'             => 'blog_post_meta_typo',

            'type'           => 'typography',

            'title'          => esc_html__('Meta Data Typography', 'dpr-adeline-extensions'),

            'google'         => true,

            'font-style'     => true,

            'subsets'        => true,

            'font-size'      => true,

            'text-align'     => false,

            'line-height'    => true,

            'word-spacing'   => false,

            'letter-spacing' => true,

            'text-transform' => true,

            'color'          => true,

            'preview'        => true,

            'all_styles'     => true,

            'output'         => array('ul.meta li , ul.meta li a'),

            'units'          => 'px',

            'default'        => array(

                'font-family'    => 'Roboto',

                'font-style'     => 'normal',

                'google'         => true,

                'font-weight'    => '400',

                'font-size'      => '13px',

                'line-height'    => '18px',

                'color'          => '#666',

                'letter-spacing' => '0.2px',

                'text-transform' => 'uppercase',

            ),

            'hint'           => array(

                'title'   => esc_attr__('Meta Data Typography', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify the typography settings for blog meta data.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'      => 'meta_data_icons',

            'type'    => 'switch',

            'default' => false,

            'title'   => esc_html__('Display Meta Data Icons', 'dpr-adeline-extensions'),

        ),

        array(

            'id'             => 'blog_post_meta_icon_typo',

            'type'           => 'typography',

            'title'          => esc_html__('Meta Data Icon Typography', 'dpr-adeline-extensions'),

            'google'         => false,

            'font-family'    => false,

            'font-weight'    => false,

            'font-style'     => false,

            'subsets'        => false,

            'font-size'      => true,

            'text-align'     => false,

            'line-height'    => false,

            'word-spacing'   => false,

            'letter-spacing' => false,

            'text-transform' => false,

            'color'          => true,

            'preview'        => true,

            'all_styles'     => false,

            'output'         => array('ul.meta li i'),

            'units'          => 'px',

            'default'        => array(

                'font-size' => '13px',

                'color'     => '#c9c9ce',

            ),

            'required'       => array('meta_data_icons', 'equals', '1'),

            'hint'           => array(

                'title'   => esc_attr__('Meta Data Icon Typography', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify the color and size for meta data icons.', 'dpr-adeline-extensions'),

            ),

        ),

    ),

));

Redux::setSection($opt_name, array(

    'title'      => esc_html__('Sidebar', 'dpr-adeline-extensions'),

    'subsection' => true,

    'fields'     => array(

        array(

            'id'             => 'sidebar_widget_heading_typo',

            'type'           => 'typography',

            'title'          => esc_html__('Sidebar Widget Heading', 'dpr-adeline-extensions'),

            'google'         => true,

            'font-style'     => true,

            'subsets'        => true,

            'font-size'      => true,

            'text-align'     => false,

            'line-height'    => true,

            'word-spacing'   => false,

            'letter-spacing' => true,

            'text-transform' => true,

            'color'          => true,

            'preview'        => true,

            'all_styles'     => true,

            'output'         => array('.sidebar-box .widget-title, #side-panel-wrap .sidebar-box .panel-widget-title'),

            'units'          => 'px',

            'default'        => array(

                'font-family'    => 'Roboto',

                'font-style'     => '',

                'google'         => true,

                'font-weight'    => '700',

                'font-size'      => '25px',

                'line-height'    => '30px',

                'color'          => '#292933',

                'letter-spacing' => '',

                'text-transform' => '',

            ),

            'hint'           => array(

                'title'   => esc_attr__('Title', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify the typography settings for sidebar widgets heading.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'      => 'sidebar-link-color',

            'type'    => 'link_color',

            'output'  => array('.sidebar-container a'),

            'title'   => __('Sidebar Links Color', 'dpr-adeline-extensions'),

            'default' => array(

                'regular' => '#c9c9ce ',

                'hover'   => '#D3AE5F',

                'active'  => '#D3AE5F',

            ),

            'hint'    => array(

                'title'   => esc_attr__('Sidebar Links Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set default color for sidebar links colors', 'dpr-adeline-extensions'),

            ),

        ),

    ),

));

Redux::setSection($opt_name, array(

    'title'      => esc_html__('Footer Area', 'dpr-adeline-extensions'),

    'subsection' => true,

    'fields'     => array(

        array(

            'id'             => 'footer_widget_heading_typo',

            'type'           => 'typography',

            'title'          => esc_html__('Footer Widget Heading', 'dpr-adeline-extensions'),

            'google'         => true,

            'font-style'     => true,

            'subsets'        => true,

            'font-size'      => true,

            'text-align'     => false,

            'line-height'    => true,

            'word-spacing'   => false,

            'letter-spacing' => true,

            'text-transform' => true,

            'color'          => true,

            'preview'        => true,

            'all_styles'     => true,

            'output'         => array('#footer-widgets .footer-box .widget-title'),

            'units'          => 'px',

            'default'        => array(

                'font-family'    => 'Roboto',

                'font-style'     => '',

                'google'         => true,

                'font-weight'    => '700',

                'font-size'      => '20px',

                'line-height'    => '25px',

                'color'          => '#ffffff',

                'letter-spacing' => '0',

                'text-transform' => '',

            ),

            'hint'           => array(

                'title'   => esc_attr__('Title', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify the typography settings for footer widgets heading.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'             => 'copyright_typo',

            'type'           => 'typography',

            'title'          => esc_html__('Copyright Text', 'dpr-adeline-extensions'),

            'google'         => true,

            'font-style'     => true,

            'subsets'        => true,

            'font-size'      => true,

            'text-align'     => false,

            'line-height'    => true,

            'word-spacing'   => false,

            'letter-spacing' => true,

            'text-transform' => true,

            'color'          => false,

            'preview'        => true,

            'all_styles'     => true,

            'output'         => array('#footer #copyright-area'),

            'units'          => 'px',

            'default'        => array(

                'font-family' => 'Roboto',

                'font-style'  => '',

                'google'      => true,

                'font-size'   => '15px',

                'line-height' => '26px',

            ),

            'hint'           => array(

                'title'   => esc_attr__('Copyright Text', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify the typography settings for copright text.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'             => 'footer_menu_typo',

            'type'           => 'typography',

            'title'          => esc_html__('Footer Menu', 'dpr-adeline-extensions'),

            'google'         => true,

            'font-style'     => true,

            'subsets'        => true,

            'font-size'      => true,

            'text-align'     => false,

            'line-height'    => true,

            'word-spacing'   => false,

            'letter-spacing' => true,

            'text-transform' => true,

            'color'          => false,

            'preview'        => true,

            'all_styles'     => true,

            'output'         => array('#footer #copyright-area-menu'),

            'units'          => 'px',

            'default'        => array(

                'font-family' => 'Roboto',

                'font-style'  => '',

                'google'      => true,

                'font-weight' => '400',

                'font-size'   => '17px',

                'line-height' => '26px',

            ),

            'hint'           => array(

                'title'   => esc_attr__('Title', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify the typography settings for footer menu.', 'dpr-adeline-extensions'),

            ),

        ),

    ),

));


Redux::setSection($opt_name, array(
    'title'      => esc_html__('Custom Fonts', 'dpr-adeline-extensions'),
    'subsection' => true,
    'fields'     => array(
        array(
            'type' => 'custom_fonts',
            'id'   => 'custom_font',
        ),

    ),
));
