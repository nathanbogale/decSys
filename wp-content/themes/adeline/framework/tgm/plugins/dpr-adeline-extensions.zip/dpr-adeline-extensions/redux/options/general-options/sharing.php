<?php

/**

 * General Options -> Social Share Options

 *

 */

Redux::setSection($opt_name, array(

    'title'      => esc_html__('Social Share Options', 'dpr-adeline-extensions'),

    'id'         => 'general_social_share',

    'subsection' => true,

    'fields'     => array(

        array(

            'id'      => 'social_share_title',

            'type'    => 'text',

            'title'   => __('Share Buttons Section Title', 'dpr-adeline-extensions'),

            'default' => 'Share This Article',

            'hint'    => array(

                'title'   => esc_attr__('Share Buttons Section Title', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set title for share buttons section. If you leave this field blank title will be not displayed.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'      => 'social_share_title_position',

            'type'    => 'radio',

            'title'   => __('Share Buttons Section Title Position', 'dpr-adeline-extensions'),

            'options' => array(

                'left-side' => 'Left Side',

                'top'       => 'Top',

            ),

            'default' => 'left-side',

            'hint'    => array(

                'title'   => esc_attr__('Share Buttons Section Title Position', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set title position. ', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'      => 'sharing_buttons',

            'type'    => 'sorter',

            'title'   => 'Sharing Buttons',

            'hint'    => array(

                'title'   => esc_attr__('Sharing Buttons', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enable or disable sharing buttons for single post and set buttons order', 'dpr-adeline-extensions'),

            ),

            'options' => array(

                'enabled'  => array(

                    'twitter'     => 'Twitter',

                    'facebook'    => 'Facebook',

                    'google_plus' => 'Google Plus',

                    'pinterest'   => 'Pinterest',

                ),

                'disabled' => array(

                    'linkedin'    => 'Linkedin',

                    'blogger'     => 'Blogger',

                    'buffer'      => 'Buffer',

                    'viber'       => 'Viber',

                    'vk'          => 'VK',

                    'reddit'      => 'Reddit',

                    'stumbleupon' => 'Stumbleupon',

                    'evernote'    => 'Evernote',

                    'newsvine'    => 'Newsvine',

                    'delicious'   => 'Delicioius',

                    'digg'        => 'Digg',

                    'livejournal' => 'Livejournal',

                    'tumblr'      => 'Tumblr',

                    'viadeo'      => 'Viadeo',

                    'odnoklassniki'      => 'Odnoklassniki',

                ),

            ),

        ),

        array(

            'id'      => 'twitter_share_via_text',

            'type'    => 'text',

            'title'   => __('Twitter Via Parameter', 'dpr-adeline-extensions'),

            'default' => '',

            'hint'    => array(

                'title'   => esc_attr__('Twitter Via Parameter', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Attribute the source of a Tweet to a Twitter username using the via parameter. The attribution will appear in a Tweet as ” via @username” translated into the language of the Tweet author.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'      => 'social_share_style',

            'type'    => 'image_select',

            'title'   => __('Social Buttons Style', 'dpr-adeline-extensions'),

            'options' => array(

                'minimal'  => array(

                    'title' => esc_html__('Minimal', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/socials/minimal.jpg',

                ),

                'rounded'  => array(

                    'title' => esc_html__('Rounded', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/socials/rounded.jpg',

                ),

                'outlined' => array(

                    'title' => esc_html__('Outlined', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/socials/outlined.jpg',

                ),

                'colored'  => array(

                    'title' => esc_html__('Colored', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/socials/colored.jpg',

                ),

            ),

            'default' => 'colored',

            'hint'    => array(

                'title'   => esc_attr__('Social Buttons Style', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Choose social share icon style.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'      => 'social_share_buttons_titels',

            'type'    => 'switch',

            'default' => false,

            'title'   => esc_html__('Display Buttons Titels? ', 'dpr-adeline-extensions'),

            'hint'    => array(

                'title'   => esc_attr__('Display Buttons Titels?', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enable display social sharing services titles in buttons.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'social_share_minimal_color',

            'type'     => 'color',

            'output'   => array('color' => '.dpr-adeline-social-block ul li a, .dpr-adeline-social-menu ul li a, .dpr-share.minimal ul li a ',
            					 'fill' => '.dpr-share.minimal ul li a .dpr-share-icon'
        						),

            'validate' => 'color',

            'title'    => esc_html__('Button Icons Color Minimal Style', 'dpr-adeline-extensions'),

            'default'  => '#bbbbbb',

            'required' => array('social_share_style', 'equals', 'minimal'),

            'hint'     => array(

                'title'   => esc_attr__('Button Icons Color Minimal Style', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Select icon color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'social_share_minimal_color_hover',

            'type'     => 'color',

            'output'   => array('color' => '.dpr-adeline-social-block ul li a:hover, .dpr-adeline-social-menu ul li a:hover, .dpr-share.minimal ul li a:hover',
            					 'fill' => '.dpr-share.minimal ul li a:hover .dpr-share-icon'
            					),

            'validate' => 'color',

            'title'    => esc_html__('Button Icons Color Minimal Style: Hover', 'dpr-adeline-extensions'),

            'default'  => '#292933',

            'required' => array('social_share_style', 'equals', 'minimal'),

            'hint'     => array(

                'title'   => esc_attr__('Button Icons Color Minimal Style: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Select hover icon color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'social_share_rounded_color',

            'type'     => 'color',

            'output'   => array('background-color' => '.dpr-adeline-social-block .rounded ul li a, .dpr-adeline-social-menu .rounded ul li a,  .dpr-share.rounded ul li a '),

            'validate' => 'color',

            'title'    => esc_html__('Button Rounded Style Background Color', 'dpr-adeline-extensions'),

            'default'  => '#292933',

            'required' => array('social_share_style', 'equals', 'rounded'),

            'hint'     => array(

                'title'   => esc_attr__('Button Rounded Style Background Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Select background color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'social_share_rounded_color_hover',

            'type'     => 'color',

            'output'   => array('background-color' => '.dpr-adeline-social-block .rounded ul li a:hover, .dpr-adeline-social-menu .rounded ul li a:hover, .dpr-share.rounded ul li a:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Button Rounded Style Background Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'required' => array('social_share_style', 'equals', 'rounded'),

            'hint'     => array(

                'title'   => esc_attr__('Button Rounded Style Background Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Select hover background color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'social_share_outlined_color',

            'type'     => 'color',

            'output'   => array('color' => '.dpr-adeline-social-block .outlined ul li a, .dpr-adeline-social-menu .outlined ul li a',

                'border-color'              => '.dpr-adeline-social-block .outlined ul li a, .dpr-adeline-social-menu .outlined ul li a, .dpr-share.outlined ul li a'),

            'validate' => 'color',

            'title'    => esc_html__('Button Outlined Style Color', 'dpr-adeline-extensions'),

            'default'  => '#292933',

            'required' => array('social_share_style', 'equals', 'outlined'),

            'hint'     => array(

                'title'   => esc_attr__('Button Outlined Style Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Select outlined style button color.', 'dpr-adeline-extensions'),

            ),

        ),

    ),

));
