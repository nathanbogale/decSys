<?php

/**



 * Portfolio Options -> Portfolio Page Style



 *



 */

Redux::setSection($opt_name, array(

    'title'      => esc_html__('Portfolio Page Style', 'dpr-adeline-extensions'),

    'id'         => 'portfolio_page_style',

    'subsection' => true,

    'fields'     => array(

        array(

            'id'    => 'portfolio_entries_style_info',

            'type'  => 'info',

            'style' => 'dpr-title',

            'title' => wp_kses_post(__('<h3>Entries Style</h3>', 'dpr-adeline-extensions')),

        ),

        array(

            'id'             => 'portfolio_grid_margin',

            'type'           => 'spacing',

            'output'         => array('.portfolio-items .portfolio-item'),

            'mode'           => 'padding',

            'units'          => array('px', '%'),

            'all'            => true,

            'display_units'  => true,

            'units_extended' => false,

            'title'          => __('Items Margin', 'dpr-adeline-extensions'),

            'default'        => array(

                'padding-left'   => '10px',

                'padding-right'  => '10px',

                'padding-bottom' => '10px',

                'padding-top'    => '10px',

                'units'          => 'px',

            ),

            'hint'           => array(

                'title'   => esc_attr__('Items Margin', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set margin for items in grid', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'             => 'portfolio_grid_padding',

            'type'           => 'spacing',

            'output'         => array('.portfolio-items .portfolio-item .portfolio-item-inner'),

            'mode'           => 'padding',

            'units'          => array('px', '%'),

            'all'            => true,

            'display_units'  => true,

            'units_extended' => false,

            'title'          => __('Entry Padding', 'dpr-adeline-extensions'),

            'default'        => array(

                'padding-left'   => '0px',

                'padding-right'  => '0px',

                'padding-bottom' => '0px',

                'padding-top'    => '0px',

                'units'          => 'px',

            ),

            'hint'           => array(

                'title'   => esc_attr__('Entry Padding', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set padding for entries', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'portfolio_entry_placeholder_bg',

            'type'     => 'background',

            'title'    => __('Portfolio Placeholder Background', 'dpr-adeline-extensions'),

            'output'   => array('.portfolio-items .portfolio-item .portfolio-item-inner'),

            'hint'     => array(

                'title'   => esc_attr__('Portfolio Placeholder Background', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set background for portfolio placeholder. Is visible only when potfolio item is move animated on hover,', 'dpr-adeline-extensions'),

            )

        ),

        array(

            'id'      => 'portfolio_entry_border',

            'type'    => 'border',

            'title'   => __('Border', 'dpr-adeline-extensions'),

            'output'  => array('.portfolio-items .portfolio-item .portfolio-item-inner-mover'),

            'default' => array(

                'border-color'  => '',

                'border-style'  => 'solid',

                'border-top'    => '0',

                'border-right'  => '0',

                'border-bottom' => '0',

                'border-left'   => '0',

            ),

            'hint'    => array(

                'title'   => esc_attr__('Portfolio Entry Border', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set portfolio entry border.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'             => 'portfolio_entry_border_radius',

            'type'           => 'dpr_border_radius',

            'units'          => array('px', '%'),

            'all'            => true,

            'output'         => array('.portfolio-items .portfolio-item .portfolio-item-inner, .portfolio-items .portfolio-item .portfolio-item-inner-mover'),

            'units_extended' => false,

            'title'          => __('Entry Border Radius', 'dpr-adeline-extensions'),

            'default'        => array(

                'border-top-left-radius'     => '0',

                'border-top-right-radius'    => '0',

                'border-bottom-right-radius' => '0',

                'border-bottom-left-radius'  => '0',

                'units'                      => 'px',

            ),

            'hint'           => array(

                'title'   => esc_attr__('Entry Border Radius', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify border radius for portfolio entries.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'      => 'portfolio_entry_bg_color',

            'type'    => 'color',

            'title'   => __('Entry Background Color', 'dpr-adeline-extensions'),

            'default' => '#f1f2f4',

            'output'  => array('background-color' => ' .portfolio-items .portfolio-item .portfolio-item-inner-mover, .portfolio-items .portfolio-content'),

            'hint'    => array(

                'title'   => esc_attr__('Entry Background Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set portfolio entry background color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'      => 'portfolio_entry_content_style',

            'type'    => 'image_select',

            'title'   => __('Portfolio Item Content Position', 'dpr-adeline-extensions'),

            'options' => array(

                'outside' => array(

                    'title' => esc_html__('Outside(bellow image)', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/portfolio/grid_cotent_outside.png',

                ),

                'inside'  => array(

                    'title' => esc_html__('Inside (over image)', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/portfolio/grid_cotent_inside.png',

                ),

            ),

            'default' => 'outside',

            'hint'    => array(

                'title'   => esc_attr__('Portfolio Item Content Position', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Choose default content position for portfolio item in grid. This general settings can be overwriten for specific pages or grid.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'outside_content_style_info',

            'type'     => 'info',

            'style'    => 'dpr-title',

            'title'    => wp_kses_post(__('<h3>Outside Content Style</h3>', 'dpr-adeline-extensions')),

            'required' => array('portfolio_entry_content_style', 'equals', 'outside'),

        ),

        array(

            'id'             => 'portfolio_grid_outer_content_padding',

            'type'           => 'spacing',

            'output'         => array('.portfolio-items .portfolio-content'),

            'mode'           => 'padding',

            'units'          => array('px', '%'),

            'all'            => false,

            'display_units'  => true,

            'units_extended' => false,

            'title'          => __('Outside Content Padding', 'dpr-adeline-extensions'),

            'default'        => array(

                'padding-left'   => '25px',

                'padding-right'  => '25px',

                'padding-bottom' => '25px',

                'padding-top'    => '25px',

                'units'          => 'px',

            ),

            'hint'           => array(

                'title'   => esc_attr__('Entry Padding', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set padding for entries', 'dpr-adeline-extensions'),

            ),

            'required'       => array('portfolio_entry_content_style', 'equals', 'outside'),

        ),

        array(

            'id'       => 'portfolio_entry_outside_arrowed',

            'type'     => 'switch',

            'default'  => true,

            'title'    => esc_html__('Use Arrow For Outside Content?', 'dpr-adeline-extensions'),

            'hint'     => array(

                'title'   => esc_attr__('Use Arrow For Outside Content?', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enable or disable display of arrow over ouside portfolio content.', 'dpr-adeline-extensions'),

            ),

            'required' => array('portfolio_entry_content_style', 'equals', 'outside'),

        ),

        array(

            'id'      => 'portfolio_entry_title',

            'type'    => 'switch',

            'default' => false,

            'title'   => esc_html__('Display Entry Title', 'dpr-adeline-extensions'),

            'hint'    => array(

                'title'   => esc_attr__('Display Entry Title', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enable or disable display of portfolio entry title.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'portfolio_entry_title_color',

            'type'     => 'color',

            'title'    => __('Title Color', 'dpr-adeline-extensions'),

            'default'  => '#292933',

            'output'   => array('color' => '.portfolio-items .portfolio-item-title a'),

            'hint'     => array(

                'title'   => esc_attr__('Title Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set portfolio entry title color.', 'dpr-adeline-extensions'),

            ),

            'required' => array('portfolio_entry_content_style', 'equals', 'outside'),

        ),

        array(

            'id'       => 'portfolio_entry_title_color_hover',

            'type'     => 'color',

            'title'    => __('Title Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'output'   => array('color' => '.portfolio-items .portfolio-item-title a:hover'),

            'hint'     => array(

                'title'   => esc_attr__('Title Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set portfolio entry title color.', 'dpr-adeline-extensions'),

            ),

            'required' => array('portfolio_entry_content_style', 'equals', 'outside'),

        ),

        array(

            'id'      => 'portfolio_entry_category',

            'type'    => 'switch',

            'default' => true,

            'title'   => esc_html__('Display Entry Category', 'dpr-adeline-extensions'),

            'hint'    => array(

                'title'   => esc_attr__('Display Entry Category', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enable or disable display of portfolio entry category.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'portfolio_entry_catagory_color',

            'type'     => 'color',

            'title'    => __('Category Link Color', 'dpr-adeline-extensions'),

            'default'  => '#424251',

            'output'   => array('color' => '.portfolio-items .categories, .portfolio-items .categories a'),

            'hint'     => array(

                'title'   => esc_attr__('Category Link Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set portfolio entry category color.', 'dpr-adeline-extensions'),

            ),

            'required' => array('portfolio_entry_category', 'equals', '1'),

        ),

        array(

            'id'       => 'portfolio_entry_category_color_hover',

            'type'     => 'color',

            'title'    => __('Category Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'output'   => array('color' => '.portfolio-items .categories a:hover'),

            'hint'     => array(

                'title'   => esc_attr__('Category Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set portfolio entry category hover color.', 'dpr-adeline-extensions'),

            ),

            'required' => array('portfolio_entry_category', 'equals', '1'),

        ),

        array(

            'id'      => 'portfolio_entry_excerpt',

            'type'    => 'switch',

            'default' => false,

            'title'   => esc_html__('Display Entry Excerpt', 'dpr-secondson-extensions'),

            'hint'    => array(

                'title'   => esc_attr__('Display Entry Excerpt', 'dpr-secondson-extensions'),

                'content' => esc_attr__('Enable or disable display of portfolio entry excerpt.', 'dpr-secondson-extensions'),

            ),

        ),

        array(

            'id'       => 'portfolio_entry_excerpt_color',

            'type'     => 'color',

            'title'    => __('Excerpt Color', 'dpr-secondson-extensions'),

            'default'  => '#c9c9ce ',

            'output'   => array('color' => '.portfolio-items .categories, .portfolio-items p'),

            'hint'     => array(

                'title'   => esc_attr__('Category excerpt Color', 'dpr-secondson-extensions'),

                'content' => esc_attr__('Set portfolio entry excerpt color.', 'dpr-secondson-extensions'),

            ),

            'required' => array('portfolio_entry_excerpt', 'equals', '1'),

        ),

        array(

            'id'    => 'portfolio_entry_decoration_info',

            'type'  => 'info',

            'style' => 'dpr-subtitle',

            'title' => wp_kses_post(__('<h3>Portfolio Entry Decoration && Hover State</h3>', 'dpr-adeline-extensions')),

        ),

        array(

            'id'      => 'portfolio_entry_shadow',

            'type'    => 'select',

            'title'   => esc_html__('Entry Shadow', 'dpr-adeline-extensions'),

            'desc'    => '',

            'options' => array(

                ''       => esc_html__('None', 'dpr-adeline-extensions'),

                '1'      => esc_html__('Shadow Depth 1', 'dpr-adeline-extensions'),

                '2'      => esc_html__('Shadow Depth 2', 'dpr-adeline-extensions'),

                '3'      => esc_html__('Shadow Depth 3', 'dpr-adeline-extensions'),

                '4'      => esc_html__('Shadow Depth 4', 'dpr-adeline-extensions'),

                '5'      => esc_html__('Shadow Depth 5', 'dpr-adeline-extensions'),

                '6'      => esc_html__('Shadow Depth 6', 'dpr-adeline-extensions'),

                'custom' => esc_html__('Custom Shadow', 'dpr-adeline-extensions'),

            ),

            'default' => '',

            'hint'    => array(

                'title'   => esc_attr__('Entry Shadow', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set shadow for portfolio entry.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'portfolio_entry_custom_shadow',

            'type'     => 'dpr_box_shadow',

            'title'    => wp_kses_post(__('Custom Box Shadow', 'dpr-adeline-extensions')),

            'output'   => array('.portfolio-items .portfolio-item .portfolio-item-inner-mover'),

            'desc'     => wp_kses_post('<em> Horizontal Offset, Vertical Offset and Color are required to display shadow</em>'),

            'hint'     => array(

                'title'   => esc_attr__('Custom Box Shadow', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Create custom box shadow.Horizontal Offset, Vertical Offset and Color are required. Blur and spread are optional.', 'dpr-adeline-extensions'),

            ),

            'required' => array('portfolio_entry_shadow', 'equals', 'custom'),

        ),

        array(

            'id'      => 'portfolio_entry_shadow_hover',

            'type'    => 'select',

            'title'   => esc_html__('Entry Shadow: Hover', 'dpr-adeline-extensions'),

            'desc'    => '',

            'options' => array(

                ''       => esc_html__('None', 'dpr-adeline-extensions'),

                '1'      => esc_html__('Shadow Depth 1', 'dpr-adeline-extensions'),

                '2'      => esc_html__('Shadow Depth 2', 'dpr-adeline-extensions'),

                '3'      => esc_html__('Shadow Depth 3', 'dpr-adeline-extensions'),

                '4'      => esc_html__('Shadow Depth 4', 'dpr-adeline-extensions'),

                '5'      => esc_html__('Shadow Depth 5', 'dpr-adeline-extensions'),

                '6'      => esc_html__('Shadow Depth 6', 'dpr-adeline-extensions'),

                'custom' => esc_html__('Custom Shadow', 'dpr-adeline-extensions'),

            ),

            'default' => '',

            'hint'    => array(

                'title'   => esc_attr__('Entry Shadow: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set shadow for portfolio entry hover state.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'portfolio_entry_custom_shadow_hover',

            'type'     => 'dpr_box_shadow',

            'title'    => wp_kses_post(__('Custom Box Shadow: Hover', 'dpr-adeline-extensions')),

            'output'   => array('.portfolio-items .portfolio-item .portfolio-item-inner-mover:hover'),

            'desc'     => wp_kses_post('<em> Horizontal Offset, Vertical Offset and Color are required to display shadow</em>'),

            'hint'     => array(

                'title'   => esc_attr__('Custom Box Shadow: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Create custom box shadow for entry hover state.Horizontal Offset, Vertical Offset and Color are required. Blur and spread are optional.', 'dpr-adeline-extensions'),

            ),

            'required' => array('portfolio_entry_shadow_hover', 'equals', 'custom'),

        ),

        array(

            'id'      => 'portfolio_entry_hover_animation',

            'type'    => 'select',

            'title'   => esc_html__('Entry Hover Animation', 'dpr-adeline-extensions'),

            'desc'    => '',

            'options' => array(

                'none'                     => esc_html__('None', 'dpr-adeline-extensions'),

                'dpr-upscale-onhover-1'    => esc_html__('Scale Up 3%', 'dpr-adeline-extensions'),

                'dpr-upscale-onhover-2'    => esc_html__('Scale Up 6%', 'dpr-adeline-extensions'),

                'dpr-upscale-onhover-3'    => esc_html__('Scale Up 10%', 'dpr-adeline-extensions'),

                'dpr-upscale-onhover-4'    => esc_html__('Scale Up 15%', 'dpr-adeline-extensions'),

                'dpr-downscale-onhover-1'  => esc_html__('Scale Down 3%', 'dpr-adeline-extensions'),

                'dpr-downscale-onhover-2'  => esc_html__('Scale Down 6%', 'dpr-adeline-extensions'),

                'dpr-up-onhover-1'         => esc_html__('Move Up 5px', 'dpr-adeline-extensions'),

                'dpr-up-onhover-2'         => esc_html__('Move Up 10px', 'dpr-adeline-extensions'),

                'dpr-up-onhover-3'         => esc_html__('Move Up 15px', 'dpr-adeline-extensions'),

                'dpr-up-onhover-4'         => esc_html__('Move Up 20px', 'dpr-adeline-extensions'),

                'dpr-down-onhover-1'       => esc_html__('Move Down 5px', 'dpr-adeline-extensions'),

                'dpr-down-onhover-2'       => esc_html__('Move Down 10px', 'dpr-adeline-extensions'),

                'dpr-down-onhover-3'       => esc_html__('Move Down 15px', 'dpr-adeline-extensions'),

                'dpr-down-onhover-4'       => esc_html__('Move Down 20px', 'dpr-adeline-extensions'),

                'dpr-up-left-onhover-1'    => esc_html__('Move UpLeft 5px', 'dpr-adeline-extensions'),

                'dpr-up-left-onhover-2'    => esc_html__('Move UpLeft 10px', 'dpr-adeline-extensions'),

                'dpr-up-left-onhover-3'    => esc_html__('Move UpLeft 15px', 'dpr-adeline-extensions'),

                'dpr-up-left-onhover-4'    => esc_html__('Move UpLeft 20px', 'dpr-adeline-extensions'),

                'dpr-up-right-onhover-1'   => esc_html__('Move UpRight 5px', 'dpr-adeline-extensions'),

                'dpr-up-right-onhover-2'   => esc_html__('Move UpRight 10px', 'dpr-adeline-extensions'),

                'dpr-up-right-onhover-3'   => esc_html__('Move UpRight 15px', 'dpr-adeline-extensions'),

                'dpr-up-right-onhover-4'   => esc_html__('Move UpRight 20px', 'dpr-adeline-extensions'),

                'dpr-down-left-onhover-1'  => esc_html__('Move DownLeft 5px', 'dpr-adeline-extensions'),

                'dpr-down-left-onhover-2'  => esc_html__('Move DownLeft 10px', 'dpr-adeline-extensions'),

                'dpr-down-left-onhover-3'  => esc_html__('Move DownLeft 15px', 'dpr-adeline-extensions'),

                'dpr-down-left-onhover-4'  => esc_html__('Move DownLeft 20px', 'dpr-adeline-extensions'),

                'dpr-down-right-onhover-1' => esc_html__('Move DownRight 5px', 'dpr-adeline-extensions'),

                'dpr-down-right-onhover-2' => esc_html__('Move DownRight 10px', 'dpr-adeline-extensions'),

                'dpr-down-right-onhover-3' => esc_html__('Move DownRight 15px', 'dpr-adeline-extensions'),

                'dpr-down-right-onhover-4' => esc_html__('Move DownRight 20px', 'dpr-adeline-extensions'),

                'dpr-image-tilt' => esc_html__('Image Tilt', 'dpr-adeline-extensions'),

                'dpr-item-tilt' => esc_html__('Item Tilt', 'dpr-adeline-extensions'),

            ),

            'default' => 'none',

            'hint'    => array(

                'title'   => esc_attr__('Entry Hover Animation', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set entry hover animation.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'    => 'portfolio_entry_appear_info',

            'type'  => 'info',

            'style' => 'dpr-subtitle',

            'title' => wp_kses_post(__('<h3>Portfolio Entries Appear Effect</h3>', 'dpr-adeline-extensions')),

        ),

        array(

            'id'      => 'portfolio_entry_appear_animation_effect',

            'type'    => 'select',

            'title'   => esc_html__('Appear Animation Effect', 'dpr-adeline-extensions'),

            'desc'    => '',

            'options' => array(

                'none'            => esc_html__('None', 'dpr-adeline-extensions'),

                'fade'            => esc_html__('Fade', 'dpr-adeline-extensions'),

                'fade-up'         => esc_html__('Fade Up', 'dpr-adeline-extensions'),

                'fade-down'       => esc_html__('Fade Down', 'dpr-adeline-extensions'),

                'fade-left'       => esc_html__('Fade Left', 'dpr-adeline-extensions'),

                'fade-right'      => esc_html__('Fade Right', 'dpr-adeline-extensions'),

                'fade-up-right'   => esc_html__('Fade Up Right', 'dpr-adeline-extensions'),

                'fade-up-left'    => esc_html__('Fade Up Left', 'dpr-adeline-extensions'),

                'fade-down-right' => esc_html__('Fade Down Right', 'dpr-adeline-extensions'),

                'fade-down-left'  => esc_html__('Fade Down Left', 'dpr-adeline-extensions'),

                'flip-up'         => esc_html__('Flip Up', 'dpr-adeline-extensions'),

                'flip-down'       => esc_html__('Flip Down', 'dpr-adeline-extensions'),

                'flip-left'       => esc_html__('Flip Left', 'dpr-adeline-extensions'),

                'flip-right'      => esc_html__('Flip Right', 'dpr-adeline-extensions'),

                'slide-up'        => esc_html__('Slide Up', 'dpr-adeline-extensions'),

                'slide-down'      => esc_html__('Slide Down', 'dpr-adeline-extensions'),

                'slide-left'      => esc_html__('Slide Left', 'dpr-adeline-extensions'),

                'slide-right'     => esc_html__('Slide Right', 'dpr-adeline-extensions'),

                'zoom-in'         => esc_html__('Zoom In', 'dpr-adeline-extensions'),

                'zoom-in-up'      => esc_html__('Zoom In Up', 'dpr-adeline-extensions'),

                'zoom-in-down'    => esc_html__('Zoom In Down', 'dpr-adeline-extensions'),

                'zoom-in-left'    => esc_html__('Zoom In Left', 'dpr-adeline-extensions'),

                'zoom-in-right'   => esc_html__('Zoom In Right', 'dpr-adeline-extensions'),

                'zoom-out'        => esc_html__('Zoom Out', 'dpr-adeline-extensions'),

                'zoom-out-up'     => esc_html__('Zoom Out Up', 'dpr-adeline-extensions'),

                'zoom-out-down'   => esc_html__('Zoom Out Down', 'dpr-adeline-extensions'),

                'zoom-out-left'   => esc_html__('Zoom Out Left', 'dpr-adeline-extensions'),

                'zoom-out-right'  => esc_html__('Zoom Out Right', 'dpr-adeline-extensions'),

            ),

            'default' => 'none',

            'hint'    => array(

                'title'   => esc_attr__('Appear Animation Effect', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Select entry appear animation effect.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'portfolio_entry_appear_animation_easing',

            'type'     => 'select',

            'title'    => esc_html__('Appear Animation Easing', 'dpr-adeline-extensions'),

            'desc'     => '',

            'options'  => array(

                'linear'            => esc_html__('Linear', 'dpr-adeline-extensions'),

                'ease'              => esc_html__('Ease', 'dpr-adeline-extensions'),

                'ease-in'           => esc_html__('Ease In', 'dpr-adeline-extensions'),

                'ease-out'          => esc_html__('Ease Out', 'dpr-adeline-extensions'),

                'ease-in-out'       => esc_html__('Ease In Out', 'dpr-adeline-extensions'),

                'ease-in-back'      => esc_html__('Ease In Back', 'dpr-adeline-extensions'),

                'ease-out-back'     => esc_html__('Ease In Back', 'dpr-adeline-extensions'),

                'ease-in-out-back'  => esc_html__('Ease In Out Back', 'dpr-adeline-extensions'),

                'ease-in-sine'      => esc_html__('Ease In Sine', 'dpr-adeline-extensions'),

                'ease-out-sine'     => esc_html__('Ease Out Sine', 'dpr-adeline-extensions'),

                'ease-in-out-sine'  => esc_html__('Ease In Out Sine', 'dpr-adeline-extensions'),

                'ease-in-quad'      => esc_html__('Ease In Quad', 'dpr-adeline-extensions'),

                'ease-out-quad'     => esc_html__('Ease Out Quad', 'dpr-adeline-extensions'),

                'ease-in-out-quad'  => esc_html__('Ease In Out Quad', 'dpr-adeline-extensions'),

                'ease-in-cubic'     => esc_html__('Ease In Cubic', 'dpr-adeline-extensions'),

                'ease-out-cubic'    => esc_html__('Ease Out Cubic', 'dpr-adeline-extensions'),

                'ease-in-out-cubic' => esc_html__('Ease In Out Cubic', 'dpr-adeline-extensions'),

                'ease-in-quart'     => esc_html__('Ease In Quart', 'dpr-adeline-extensions'),

                'ease-out-quart'    => esc_html__('Ease Out Quart', 'dpr-adeline-extensions'),

                'ease-in-out-quart' => esc_html__('Ease In Out Quart', 'dpr-adeline-extensions'),

            ),

            'default'  => 'ease',

            'hint'     => array(

                'title'   => esc_attr__('Appear Animation Easing', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set entry appear animation easing.', 'dpr-adeline-extensions'),

            ),

            'required' => array('portfolio_entry_appear_animation_effect', 'not', 'none'),

        ),

        array(

            'id'       => 'portfolio_entry_appear_animation_duration',

            'type'     => 'text',

            'title'    => __('Appear Animation Duration', 'dpr-adeline-extensions'),

            'default'  => '',

            'desc'     => wp_kses_post(__('<small><i>Set appear animation duration in miliseconds.<br/>If you leave this blank will be used default value 400ms</i></small>', 'dpr-adeline-extensions')),

            'hint'     => array(

                'title'   => esc_attr__('Appear Animation Duration', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set appear animation duration in miliseconds. If you leave this blank will be used default value 400ms', 'dpr-adeline-extensions'),

            ),

            'required' => array('portfolio_entry_appear_animation_effect', 'not', 'none'),

        ),

        array(

            'id'       => 'portfolio_entry_appear_animation_delay',

            'type'     => 'text',

            'title'    => __('Appear Animation Delay', 'dpr-adeline-extensions'),

            'default'  => '',

            'desc'     => wp_kses_post(__('<small><i>Set appear animation delay in miliseconds.<br/>If you leave this blank snimstion will be dnot delayed</i></small>', 'dpr-adeline-extensions')),

            'hint'     => array(

                'title'   => esc_attr__('Appear Animation Delay', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set appear animation delay in miliseconds.<br/>If you leave this blank snimstion will be not delayed.', 'dpr-adeline-extensions'),

            ),

            'required' => array('portfolio_entry_appear_animation_effect', 'not', 'none'),

        ),

        array(

            'id'    => 'media_style_info',

            'type'  => 'info',

            'style' => 'dpr-title',

            'title' => wp_kses_post(__('<h3>Image & Overlay Content Style</h3>', 'dpr-adeline-extensions')),

        ),

        array(

            'id'      => 'portfolio_entry_img_size',

            'type'    => 'select',

            'title'   => esc_html__('Image Size', 'dpr-adeline-extensions'),

            'desc'    => '',

            'options' => array(

                'thumbnail'    => esc_html__('Thumbnail', 'dpr-adeline-extensions'),

                'medium'       => esc_html__('Medium', 'dpr-adeline-extensions'),

                'medium_large' => esc_html__('Medium Large', 'dpr-adeline-extensions'),

                'large'        => esc_html__('Large', 'dpr-adeline-extensions'),

                'full'         => esc_html__('Full', 'dpr-adeline-extensions'),

                'custom'       => esc_html__('Custom', 'dpr-adeline-extensions'),

            ),

            'default' => 'medium',

            'hint'    => array(

                'title'   => esc_attr__('Image Size', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set image size for portfolio.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'portfolio_entry_img_width',

            'type'     => 'dimensions',

            'title'    => esc_html__('Custom Image Width (px)', 'dpr-adeline-extensions'),

            'width'    => true,

            'height'   => false,

            'mode'     => array('width' => 'width', 'height' => 'height'),

            'units'    => array('px'),

            'default'  => array(

                'width' => '',

            ),

            'hint'     => array(

                'title'   => esc_attr__('Custom Image Width', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify the cusrtom image width. In combination with custom image height bellow you can set custom image aspect ratio.', 'dpr-adeline-extensions'),

            ),

            'required' => array('portfolio_entry_img_size', 'equals', 'custom'),

        ),

        array(

            'id'       => 'portfolio_entry_img_height',

            'type'     => 'dimensions',

            'title'    => esc_html__('Custom Image Height (px)', 'dpr-adeline-extensions'),

            'width'    => false,

            'height'   => true,

            'mode'     => array('width' => 'width', 'height' => 'height'),

            'units'    => array('px'),

            'default'  => array(

                'width' => '',

            ),

            'hint'     => array(

                'title'   => esc_attr__('Custom Image Height', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify the cusrtom image height. In combination with custom image width above you can set custom featured image aspect ratio.', 'dpr-adeline-extensions'),

            ),

            'required' => array('portfolio_entry_img_size', 'equals', 'custom'),

        ),

        array(

            'id'      => 'portfolio_entry_overlay_type',

            'type'    => 'radio',

            'title'   => __('Image Overlay Type', 'dpr-adeline-extensions'),

            'options' => array(

                'solid-color' => 'Solid Color',

                'gradient'    => 'Gradient',

            ),

            'default' => 'solid-color',

            'hint'    => array(

                'title'   => esc_attr__('Overlay Type', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set image overlay type', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'portfolio_entry_overlay_color',

            'type'     => 'color',

            'title'    => __('Overlay Color', 'dpr-adeline-extensions'),

            'default'  => 'rgba(0,0,0,0.4)',

            'output'   => array('background-color' => '.portfolio-items .portfolio-item-thumbnail .overlay.solid-color .inner'),

            'hint'     => array(

                'title'   => esc_attr__('Overlay Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set overlay color.', 'dpr-adeline-extensions'),

            ),

            'required' => array('portfolio_entry_overlay_type', 'equals', 'solid-color'),

        ),

        array(

            'id'       => 'portfolio_entry_overlay_gradient',

            'type'     => 'dpr_color_gradient',

            'output'   => array('.portfolio-items .portfolio-item-thumbnail .overlay.gradient .inner'),

            'title'    => esc_html__('Overlay Gradient', 'dpr-adeline-extensions'),

            'default'  => '45;0%/rgba(192, 156, 129, 0.5);99%/rgba(192, 156, 129, 0.7)',

            'hint'     => array(

                'title'   => esc_attr__('Overlay Gradient', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set gradient for image overlay.', 'dpr-adeline-extensions'),

            ),

            'required' => array('portfolio_entry_overlay_type', 'equals', 'gradient'),

        ),

        array(

            'id'             => 'portfolio_entry_overlay_spacing',

            'type'           => 'spacing',

            'output'         => array('.portfolio-items .portfolio-item-thumbnail .overlay'),

            'mode'           => 'padding',

            'units'          => array('px', '%'),

            'all'            => true,

            'display_units'  => true,

            'units_extended' => false,

            'title'          => __('Overlay Padding', 'dpr-adeline-extensions'),

            'default'        => array(

                'padding-left'   => '0px',

                'padding-right'  => '0px',

                'padding-bottom' => '0px',

                'padding-top'    => '0px',

                'units'          => 'px',

            ),

            'hint'           => array(

                'title'   => esc_attr__('Overlay Padding', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Add overlay padding if you wish overlay frame', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'      => 'portfolio_entry_overlay_icons_style',

            'type'    => 'radio',

            'title'   => __('Overlay Icons', 'dpr-adeline-extensions'),

            'options' => array(

                'none'  => 'No Icons',

                'icons' => 'Icons',

                'plus'  => 'Plus Sign',

            ),

            'default' => 'icons',

            'hint'    => array(

                'title'   => esc_attr__('Overlay Icons', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set image overlay icons style', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'portfolio_entry_overlay_icons_size',

            'type'     => 'dimensions',

            'title'    => esc_html__('Icon Dimsensinons', 'dpr-adeline-extensions'),

            'output'   => array('.portfolio-items .portfolio-item-thumbnail .portfolio-overlay-icons li a'),

            'width'    => true,

            'height'   => true,

            'mode'     => array('width' => 'width', 'height' => 'height'),

            'units'    => array('px'),

            'default'  => array(

                'width'  => '45px',

                'height' => '45px',

            ),

            'hint'     => array(

                'title'   => esc_attr__('Icon Dimmensions', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify the icon size.', 'dpr-adeline-extensions'),

            ),

            'required' => array('portfolio_entry_overlay_icons_style', 'equals', 'icons'),

        ),

        array(

            'id'          => 'portfolio_entry_overlay_icons_font_size',

            'type'        => 'typography',

            'title'       => __('Icon Font Size', 'redux-framework-demo'),

            'google'      => false,

            'font-backup' => false,

            'font-style'  => false,

            'font-weight' => false,

            'font-family' => false,

            'subsets'     => false,

            'color'       => false,

            'text-align'  => false,

            'line-height' => false,

            'text'        => '&nbsp;',

            'output'      => array('.portfolio-items .portfolio-item-thumbnail .portfolio-overlay-icons li a'),

            'units'       => 'px',

            'default'     => array(

                'font-size' => '16px',

            ),

            'hint'        => array(

                'title'   => esc_attr__('Icon Font Size', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set overlay icons font size.', 'dpr-adeline-extensions'),

            ),

            'required'    => array('portfolio_entry_overlay_icons_style', 'equals', 'icons'),

        ),

        array(

            'id'       => 'portfolio_entry_overlay_icon_link',

            'type'     => 'radio',

            'title'    => __('Link Icon', 'dpr-adeline-extensions'),

            'required' => array('portfolio_entry_overlay_icons_style', 'equals', 'icons'),

            'options'  => array(

                'none'          => 'None',

                'theme-default' => 'Theme Default',

                'custom'        => 'Custom Icon',

            ),

            'default'  => 'theme-default',

            'hint'     => array(

                'title'   => esc_attr__('Link Icon', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enable or disable link icon and eventually select custom link icon.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'portfolio_entry_custom_link_icon',

            'type'     => 'dpr_icon_selector',

            'title'    => __('Link Icon', 'dpr-adeline-extensions'),

            'required' => array('portfolio_entry_overlay_icon_link', 'equals', 'custom'),

            'default'  => '',

            'hint'     => array(

                'title'   => esc_attr__('Link Icon', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set link icon.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'portfolio_entry_overlay_icon_zoom',

            'type'     => 'radio',

            'title'    => __('Zoom Icon', 'dpr-adeline-extensions'),

            'required' => array('portfolio_entry_overlay_icons_style', 'equals', 'icons'),

            'options'  => array(

                'none'          => 'None',

                'theme-default' => 'Theme Default',

                'custom'        => 'Custom Icon',

            ),

            'default'  => 'theme-default',

            'hint'     => array(

                'title'   => esc_attr__('Zoom Icon', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enable or disable zoom icon and eventually select custom zoom icon.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'portfolio_entry_custom_zoom_icon',

            'type'     => 'dpr_icon_selector',

            'title'    => __('Zoom Icon', 'dpr-adeline-extensions'),

            'required' => array('portfolio_entry_overlay_icon_zoom', 'equals', 'custom'),

            'default'  => '',

            'hint'     => array(

                'title'   => esc_attr__('Zoom Icon', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set zoom icon.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'portfolio_entry_icon_bg',

            'type'     => 'color',

            'title'    => __('Icon Background Color', 'dpr-adeline-extensions'),

            'default'  => 'rgba(0,0,0,.4)',

            'output'   => array('background-color' => '.portfolio-items .portfolio-item-thumbnail .portfolio-overlay-icons li a'),

            'hint'     => array(

                'title'   => esc_attr__('Icon Background Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set overlay icons background color.', 'dpr-adeline-extensions'),

            ),

            'required' => array('portfolio_entry_overlay_icons_style', 'equals', 'icons'),

        ),

        array(

            'id'       => 'portfolio_entry_icon_color',

            'type'     => 'color',

            'title'    => __('Icon Color', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'output'   => array('color' => '.portfolio-items .portfolio-item-thumbnail .portfolio-overlay-icons li a'),

            'hint'     => array(

                'title'   => esc_attr__('Icon Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set overlay icons color.', 'dpr-adeline-extensions'),

            ),

            'required' => array('portfolio_entry_overlay_icons_style', 'equals', 'icons'),

        ),

        array(

            'id'       => 'portfolio_entry_icon_border',

            'type'     => 'border',

            'title'    => __('Icon Border', 'dpr-adeline-extensions'),

            'output'   => array('.portfolio-items .portfolio-item-thumbnail .portfolio-overlay-icons li a'),

            'default'  => array(

                'border-color'  => 'rgba(0,0,0,0.1)',

                'border-style'  => 'solid',

                'border-top'    => '1px',

                'border-right'  => '1px',

                'border-bottom' => '1px',

                'border-left'   => '1px',

            ),

            'hint'     => array(

                'title'   => esc_attr__('Icon Border', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set overlay icons border.', 'dpr-adeline-extensions'),

            ),

            'required' => array('portfolio_entry_overlay_icons_style', 'equals', 'icons'),

        ),

        array(

            'id'       => 'portfolio_entry_icon_bg_hover',

            'type'     => 'color',

            'title'    => __('Icon Background Color: Hover', 'dpr-adeline-extensions'),

            'default'  => 'rgba(0,0,0,0.6)',

            'output'   => array('background-color' => '.portfolio-items .portfolio-item-thumbnail .portfolio-overlay-icons li a:hover'),

            'hint'     => array(

                'title'   => esc_attr__('Icon Background Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set overlay icons background hover color.', 'dpr-adeline-extensions'),

            ),

            'required' => array('portfolio_entry_overlay_icons_style', 'equals', 'icons'),

        ),

        array(

            'id'       => 'portfolio_entry_icon_color_hover',

            'type'     => 'color',

            'title'    => __('Icon Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'output'   => array('color' => '.portfolio-items .portfolio-item-thumbnail .portfolio-overlay-icons li a:hover'),

            'hint'     => array(

                'title'   => esc_attr__('Icon Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set overlay icons hover color.', 'dpr-adeline-extensions'),

            ),

            'required' => array('portfolio_entry_overlay_icons_style', 'equals', 'icons'),

        ),

        array(

            'id'       => 'portfolio_entry_icon_border_hover',

            'type'     => 'border',

            'title'    => __('Icon Border: Hover', 'dpr-adeline-extensions'),

            'output'   => array('.portfolio-items .portfolio-item-thumbnail .portfolio-overlay-icons li a:hover'),

            'default'  => array(

                'border-color'  => 'rgba(0,0,0,0.1)',

                'border-style'  => 'solid',

                'border-top'    => '1px',

                'border-right'  => '1px',

                'border-bottom' => '1px',

                'border-left'   => '1px',

            ),

            'hint'     => array(

                'title'   => esc_attr__('Icon Border: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set overlay icons hover border.', 'dpr-adeline-extensions'),

            ),

            'required' => array('portfolio_entry_overlay_icons_style', 'equals', 'icons'),

        ),

        array(

            'id'       => 'portfolio_entry_overlay_plus_link',

            'type'     => 'radio',

            'title'    => __('Plus Sign Link', 'dpr-adeline-extensions'),

            'required' => array('portfolio_entry_overlay_icons_style', 'equals', 'plus'),

            'options'  => array(

                'item'     => 'Portfolio Item',

                'lightbox' => 'Lightbox',

            ),

            'default'  => 'lightbox',

            'hint'     => array(

                'title'   => esc_attr__('Plus Sign Link', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set link for plus sign.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'portfolio_entry_overlay_plus_size',

            'type'     => 'dimensions',

            'title'    => esc_html__('Plus Sign Dimsensinons', 'dpr-adeline-extensions'),

            'output'   => array('.portfolio-items .portfolio-item-thumbnail .portfolio-plus-sign'),

            'width'    => true,

            'height'   => true,

            'mode'     => array('width' => 'width', 'height' => 'height'),

            'units'    => array('px'),

            'default'  => array(

                'width'  => '45px',

                'height' => '45px',

            ),

            'hint'     => array(

                'title'   => esc_attr__('Plus Sign Dimsensinons', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify the plus sign size.', 'dpr-adeline-extensions'),

            ),

            'required' => array('portfolio_entry_overlay_icons_style', 'equals', 'plus'),

        ),

        array(

            'id'       => 'portfolio_entry_overlay_plus_color',

            'type'     => 'color',

            'title'    => __('Plus Sign Color', 'dpr-adeline-extensions'),

            'default'  => 'rgba(255,255,255,0.8)',

            'output'   => array('fill' => '.portfolio-items .portfolio-item-thumbnail .portfolio-plus-sign svg .to-fill '),

            'hint'     => array(

                'title'   => esc_attr__('Plus Sign Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set overlay plus sign color.', 'dpr-adeline-extensions'),

            ),

            'required' => array('portfolio_entry_overlay_icons_style', 'equals', 'plus'),

        ),

        array(

            'id'       => 'portfolio_entry_overlay_plus_color_hover',

            'type'     => 'color',

            'title'    => __('Plus Sign Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'output'   => array('fill' => '.portfolio-items .portfolio-item-thumbnail .portfolio-plus-sign:hover svg .to-fill '),

            'hint'     => array(

                'title'   => esc_attr__('Plus Sign Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set overlay plus sign hover color.', 'dpr-adeline-extensions'),

            ),

            'required' => array('portfolio_entry_overlay_icons_style', 'equals', 'plus'),

        ),

        array(

            'id'       => 'portfolio_entry_overlay_title_color',

            'type'     => 'color',

            'title'    => __('Overlay Title Color', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'output'   => array('color' => '.portfolio-items .portfolio-item-thumbnail .portfolio-inside-content .portfolio-item-title a'),

            'hint'     => array(

                'title'   => esc_attr__('Title Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set portfolio entry overlay title color.', 'dpr-adeline-extensions'),

            ),

            'required' => array('portfolio_entry_content_style', 'equals', 'inside'),

        ),

        array(

            'id'       => 'portfolio_entry_overlay_title_color_hover',

            'type'     => 'color',

            'title'    => __('Overlay Title Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'output'   => array('color' => '.portfolio-items .portfolio-item-thumbnail .portfolio-inside-content .portfolio-item-title a:hover'),

            'hint'     => array(

                'title'   => esc_attr__('Title Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set portfolio entry overlay title hover color.', 'dpr-adeline-extensions'),

            ),

            'required' => array('portfolio_entry_content_style', 'equals', 'inside'),

        ),

        array(

            'id'       => 'portfolio_entry_overlay_category_color',

            'type'     => 'color',

            'title'    => __('Overlay Category Color', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'output'   => array('color' => '.portfolio-items .portfolio-item-thumbnail .portfolio-inside-content .categories, .portfolio-items .portfolio-item-thumbnail .portfolio-inside-content .categories a'),

            'hint'     => array(

                'title'   => esc_attr__('Category Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set portfolio entry overlay category color.', 'dpr-adeline-extensions'),

            ),

            'required' => array('portfolio_entry_content_style', 'equals', 'inside'),

        ),

        array(

            'id'       => 'portfolio_entry_overlay_category_color_hover',

            'type'     => 'color',

            'title'    => __('Overlay Category Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'output'   => array('color' => '.portfolio-items .portfolio-item-thumbnail .portfolio-inside-content .categories a:hover'),

            'hint'     => array(

                'title'   => esc_attr__('Category Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set portfolio entry overlay category hover color.', 'dpr-adeline-extensions'),

            ),

            'required' => array('portfolio_entry_content_style', 'equals', 'inside'),

        ),

    ),

));
