var $j = jQuery.noConflict();



$j( document ).on( 'ready', function() {

    "use strict";


    dprInitializeScatPortfolioAnimation();

} );



/* ==============================================
FANCY LINKS

============================================== */

function dprInitializeScatPortfolioAnimation() {

   
    "use strict"

     $j('.dpr-image-tilt .portfolio-item-thumbnail').universalTilt({
		  settings: {
		    perspective:    1500
		  }
	});
  
     $j('.dpr-item-tilt').universalTilt({
		  settings: {
		    perspective:    4000
		  }
	});
  
  };