<?php

// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}

/*

* Add-on Name: DP Woo Single Product

*/



class WPBakeryShortCode_DPR_Woo_Single_Product extends WPBakeryShortCode {}



vc_map(

	array(

		'name'					=> esc_html__('DP Single Product', 'dpr-adeline-extensions'),

		'base'					=> 'dpr_woo_single_product',

		"icon"					=> 'icon-dpr-single-product',

		"class"					=> 'dpr_woo_single_product',

  		"category" =>array( esc_attr__('WooCommerce', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions')),

		'description'			=> esc_html__('Display single product tile with custom styling', 'dpr-adeline-extensions'),

		'params'				=> array(

			array(

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose style for product tile.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Style', 'dpr-adeline-extensions'),

				'type'				=> 'dpr_image_select',

				'param_name'		=> 'style',

				'value' 			=> 'compact',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'options'			=> array(

					'default'			=> array(

						'label'			=> esc_html__('Default', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'woocommerce/style-1.png'

					),

					'compact'			=> array(

						'label'			=> esc_html__('Compact', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'woocommerce/style-2.png'

					),

					'overlay'			=> array(

						'label'			=> esc_html__('Hover Overlay', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'woocommerce/style-3.png'

					),

				),

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose description alignment.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Content Alignment', 'dpr-adeline-extensions'),

				'param_name'		=> 'alignment',

				'value'				=> 'center',

				'edit_field_class'	=> 'vc_column vc_col-sm-12  ',

				'options'			=> array(

					esc_html__('Left', 'dpr-adeline-extensions')	=> 'left',

					esc_html__('Center', 'dpr-adeline-extensions')	=> 'center',

					esc_html__('Right', 'dpr-adeline-extensions')	=> 'right',

				),

				'dependency'		=> array('element' => 'style', 'value' => array('default')),

			),

			array(

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose content over image position .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Content position', 'dpr-adeline-extensions'),

				'type'				=> 'dpr_image_select',

				'param_name'		=> 'content_position',

				'value' 			=> 'lb',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'options'			=> array(

					'lb'			=> array(

						'label'			=> esc_html__('Left bottom', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'woocommerce/left-bottom.png'

					),

					'lc'			=> array(

						'label'			=> esc_html__('Left center', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'woocommerce/left-center.png'

					),

					'lt'			=> array(

						'label'			=> esc_html__('Left Top', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'woocommerce/left-top.png'

					),

					'cb'			=> array(

						'label'			=> esc_html__('Center bottom', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'woocommerce/center-bottom.png'

					),

					'cc'			=> array(

						'label'			=> esc_html__('Center', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'woocommerce/center-center.png'

					),

					'ct'			=> array(

						'label'			=> esc_html__('Center Top', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'woocommerce/center-top.png'

					),

					'rb'			=> array(

						'label'			=> esc_html__('Right bottom', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'woocommerce/right-bottom.png'

					),

					'rc'			=> array(

						'label'			=> esc_html__('Right center', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'woocommerce/right-center.png'

					),

					'rt'			=> array(

						'label'			=> esc_html__('Right Top', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'woocommerce/right-top.png'

					),

				),

				'dependency'		=> array('element' => 'style', 'value' => array('compact','overlay')),

			),

			

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Additional Settings', 'dpr-adeline-extensions' ),

				'param_name'       => 'extra_features_title',

				'edit_field_class' => 'vc_column vc_col-sm-12',

			),

			vc_map_add_css_animation( false ),

		    array(

				'type' => 'textfield',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Extra Class Name', 'dpr-adeline-extensions'),

				'param_name' => 'el_class',

			),

		    array(

				'type' => 'dpr_image_post_select',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select product.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Product', 'dpr-adeline-extensions'),

				'param_name' 	=> 'product',

				'value' 	 	=> '',

				'admin_label' => true,

				'post_type' => 'product',

				'group'			=> esc_html__('Content', 'dpr-adeline-extensions'),

			),	

			array(

				'type'				=> 'dpr_radio',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose description alignment.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Content Alignment', 'dpr-adeline-extensions'),

				'param_name'		=> 'image_type',

				'value'				=> 'thumb',

				'edit_field_class'	=> 'vc_column vc_col-sm-6  ',

				'options'			=> array(

					esc_html__('Product Thumbnail', 'dpr-adeline-extensions')	=> 'thumb',

					esc_html__('Custom Image', 'dpr-adeline-extensions')	=> 'custom'

				),

				'group'			=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'attach_image',

				'param_name'		=> 'image',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select image from media library', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Image', 'dpr-adeline-extensions'),

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'			=> esc_html__('Content', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'image_type', 'value' => array('custom')),

			),

			array(

			'type'            	=> 'dpr_title',

			'text'            	=> '',

			'class'				=> 'separator',

			'param_name'      	=> 'contentt_sep_1',

			'edit_field_class'	=> 'vc_column vc_col-sm-12',

			'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

		),

			array(

				'type' => 'number',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select the width for the image', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Image width', 'dpr-adeline-extensions'),

				'param_name' => 'image_width',

				'suffix'	=> 'px',

				'value' => 600,

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'group'			   => esc_html('Content','dpr-adeline-extensions')

			),

			array(

				'type' 				=> 'number',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select the height for the image', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Image height', 'dpr-adeline-extensions'),

				'param_name'		=> 'image_height',

				'suffix'			=> 'px',

				'value' 			=> 600,

				'edit_field_class' 	=> 'vc_column vc_col-sm-6',

				'group'			   	=> esc_html('Content','dpr-adeline-extensions')

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Cntent Elements', 'dpr-adeline-extensions' ),

				'param_name'       => 'content_title_1',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable display of product title', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Title', 'dpr-adeline-extensions'),

				'param_name'		=> 'title',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'value' => 'yes',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable display of product price', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Price', 'dpr-adeline-extensions'),

				'param_name'		=> 'price',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'value' => 'yes',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable display of product add to cart button', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Add to Cart', 'dpr-adeline-extensions'),

				'value' => 'yes',

				'param_name'		=> 'add_to_cart',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable display of product rating', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Rating', 'dpr-adeline-extensions'),

				'param_name'		=> 'rating',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable display of product onsale badge', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Onsale badge', 'dpr-adeline-extensions'),

				'param_name'		=> 'onsale',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable display of product quick view button', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Quick View Button', 'dpr-adeline-extensions'),

				'param_name'		=> 'quickview',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable display of product add to wishlist button', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('wishlist Button', 'dpr-adeline-extensions'),

				'param_name'		=> 'wishlist',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Elements Colors', 'dpr-adeline-extensions' ),

				'param_name'       => 'content_title_2',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose color for product title', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Title Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'title', 'value' => array('yes')),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose color for product price', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Price Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'price_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'price', 'value' => array('yes')),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose color for add to cart button', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Cart Button Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'add_to_cart_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'add_to_cart', 'value' => array('yes')),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose color for add to cart button hover state', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Cart Button Color: Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'add_to_cart_color_hover',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'add_to_cart', 'value' => array('yes')),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose background color for add to cart button', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Cart Button Background', 'dpr-adeline-extensions'),

				'param_name'		=> 'add_to_cart_bg',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'add_to_cart', 'value' => array('yes')),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose background color for add to cart button hover state', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Cart Button Background: Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'add_to_cart_bg_hover',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'add_to_cart', 'value' => array('yes')),

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose background type for overlay mask.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Mask Overlay Type', 'dpr-adeline-extensions'),

				'param_name'		=> 'mask_type',

				'value'				=> 'solid',

				'edit_field_class'	=> 'vc_column vc_col-sm-12  ',

				'options'			=> array(

					esc_html__('Solid', 'dpr-adeline-extensions')	=> 'solid',

					esc_html__('Gradient', 'dpr-adeline-extensions')	=> 'gradient'

				),

				'group'			=> esc_html__('Content', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'style', 'value' => array('overlay')),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose color for overlay mask in overlay style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Hover overlay mask color', 'dpr-adeline-extensions'),

				'param_name'		=> 'mask_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'mask_type', 'value' => array('solid')),

			),

			array(

				'type' => 'dpr_gradient_picker',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the gradient for mask in overlay style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Hover Overlay Mask Gradient', 'dpr-adeline-extensions'),

				'param_name' => 'mask_gradient',

				'value' => '45;0%/rgba(75, 50, 255, 0.5);100%/rgba(13, 193, 255, 0.5)',

				'group'	=> esc_html__('Content', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'mask_type', 'value' => 'gradient'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Title Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'typo_title_1',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size. If you leave this field blank will be used default size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom line height.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'title_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

	  		),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font. .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_title_google_fonts',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'title_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'dependency'		=> array('element' => 'use_title_google_fonts', 'value' => array('yes')),

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Price Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'typo_title_2',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size. If you leave this field blank will be used default size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'price_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom linne height.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'price_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom letter sapacing.', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'price_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'price_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

	  		),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font. .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_price_google_fonts',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'price_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'dependency'		=> array('element' => 'use_price_google_fonts', 'value' => array('yes')),

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'css_editor',

				'heading' => __( 'CSS box', 'dpr-adeline-extensions' ),

				'param_name' => 'css',

				'group' => __( 'Design Options', 'dpr-adeline-extensions' ),

			),

		),

	)

);