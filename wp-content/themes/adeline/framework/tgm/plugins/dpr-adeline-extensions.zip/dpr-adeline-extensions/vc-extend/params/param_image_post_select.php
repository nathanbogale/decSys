<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if(!class_exists('DPR_Image_Post_Select_Param')) {
	class DPR_Image_Post_Select_Param {
		function __construct() {	
			if(function_exists('vc_add_shortcode_param')) {
				vc_add_shortcode_param('dpr_image_post_select' , array(&$this, 'dpr_image_post_select' ), DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/admin/js/dpr_param.js' );
			}
		}
	
		function dpr_image_post_select($settings, $value) {

			$post_type      = isset( $settings['post_type'] ) ? $settings['post_type'] : '';
			$class      = isset( $settings['class'] ) ? $settings['class'] : '';

			$output = $selected = '';
			$selected_option = str_replace( '#', 'hash-', vc_get_dropdown_option( $settings, $value ) );
 		    
			$args = array(
				'post_type' => $post_type,
				'post_status' => 'publish',
				'posts_per_page' => -1,
				'ignore_sticky_posts'=> true
			  );
			$options = null;
			$options = new WP_Query($args);

			$output .= '<select name="'
			           . $settings['param_name']
			           . '" class="wpb_vc_param_value wpb-input wpb-select ' . $class
			           . ' ' .$settings['param_name']
			           . ' ' . $settings['type']
			           . ' ' . $selected_option
			           . '" data-option="' . $selected_option . '">';
			$output .= '<option data-img-label="" data-img-src="' . esc_url(dpr_empty_image_url()) . '"  value="" ' . $selected . '>';
			if( $options->have_posts() ):
			   while ($options->have_posts()) : $options->the_post();
			    	$post_id = get_the_ID();
                    $img_url = get_the_post_thumbnail_url( $post_id, 'thumbnail' );
					if(empty($img_url)) {
						$img_url = esc_url(dpr_no_image_url());
					}
					$label = esc_attr(dpr_string_limit(get_the_title(),30,'...'));
					if ($selected_option == $post_id ) {
						$selected = ' selected="selected"';
					} else {
						$selected = '';
					}
					$output .= '<option data-img-label="'.esc_html($label).'" data-img-src="' . esc_url($img_url) . '"  value="' . esc_attr($post_id) . '" ' . $selected . '>';
			  
			   endwhile; 
			endif;
			wp_reset_query();  
			
			$output .= '</select>';

			return $output;

		}
		
	}
	
	$DPR_Image_Post_Select_Param = new DPR_Image_Post_Select_Param();
}
