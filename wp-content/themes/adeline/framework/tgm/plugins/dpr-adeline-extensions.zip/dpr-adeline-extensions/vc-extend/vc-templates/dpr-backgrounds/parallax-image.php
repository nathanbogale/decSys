<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

wp_enqueue_script( 'dpr_parralax_js', DPR_EXTENSIONS_PLUGIN_URL . 'vc-extend/assets/frontend/js/dpr.parallax.js', false, true);

$bg_wrap_data_atts = '';
$uniqid = uniqid('dpr-bg-wrapper-');

if(isset($dpr_parallax_image) && !empty($dpr_parallax_image)) {
	$bg_image_src = dpr_get_attachment_image_src($dpr_parallax_image, 'full');
	$bg_image = $bg_image_src[0];
	if ($bg_image !='') {
	$custom_el_css .= '#'.$uniqid.'{background-image: url('.esc_url($bg_image).')}';
	}
}

if(isset($dpr_parallax_type) && !empty($dpr_parallax_type)) {
        $bg_wrap_data_atts .= 'data-paroller-direction="'.$dpr_parallax_type.'"';
}

if(isset($dpr_parallax_factor) && !empty($dpr_parallax_factor)) {
        $bg_wrap_data_atts .= ' data-paroller-factor="'.$dpr_parallax_factor.'"';
}



$output .= '<div class="dpr_row_bg_container">';

	$output .= '<div id="'.esc_attr($uniqid).'" class="dpr_row_bg_container_inner dpr_row_bg_image" '.$bg_wrap_data_atts.'></div>';
	$output .= $overlay_output;
	
$output .= '</div>';

