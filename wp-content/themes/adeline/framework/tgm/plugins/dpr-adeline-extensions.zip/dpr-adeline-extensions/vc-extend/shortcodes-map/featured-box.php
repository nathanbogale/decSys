<?php

// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}

/*

* Add-on Name: Featured box

*/



class WPBakeryShortCode_DPR_Featured_Box extends WPBakeryShortCode {}



vc_map(

	array(

		'name'					=> esc_html__('DP Featured Box', 'dpr-adeline-extensions'),

		'base'					=> 'dpr_featured_box',

		"icon"					=> 'icon-dpr-icon-box',

		"class"					=> 'dpr_featured_box',

  		"category" =>array( esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions')),

		'description'			=> esc_html__('Box with icon and short information', 'dpr-adeline-extensions'),

		'params'				=> array(

			array(

				'heading'			=> esc_html__('Style', 'dpr-adeline-extensions'),

				'type'				=> 'dpr_image_select',

				'param_name'		=> 'style',

				'simple_mode'		=> false,

				'options'			=> array(

					'style-classic'			=> array(

						'label'			=> esc_html__('Classic', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'icon-box/style-classic.png'

					),

					'style-badge'			=> array(

						'label'			=> esc_html__('With Badge', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'icon-box/style-badge.png'

					),

					'style-outlined'			=> array(

						'label'			=> esc_html__('Outlined', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'icon-box/style-outlined.png'

					),

					'style-framed'			=> array(

						'label'			=> esc_html__('Framed', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'icon-box/style-framed.png'

					),

					'style-bgicon'			=> array(

						'label'			=> esc_html__('Background Icon', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'icon-box/style-bgicon.png'

					),

				),

			),

			array(

				'heading'			=> esc_html__('Icon position', 'dpr-adeline-extensions'),

				'type'				=> 'dpr_image_select',

				'param_name'		=> 'icon_pos',

				'options'			=> array(

					'icon-pos-1'			=> array(

						'label'			=> esc_attr__('Top', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'icon-box/icon-pos-1.png'

					),

					'icon-pos-2'			=> array(

						'label'			=> esc_attr__('On the side', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'icon-box/icon-pos-2.png'

					),

					'icon-pos-3'			=> array(

						'label'			=> esc_attr__('Icon & title', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'icon-box/icon-pos-3.png'

					),

				),

				'dependency'		=> array('element' => 'style', 'value' => array('style-classic','style-badge','style-outlined', 'style-framed')),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('This option allows you to show the content only in hover state.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Content only on hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'content_only_hover',

				'options'			=> array(

					'only_hover'		=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to choose the horizontal alignment for the featured box.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Alignment', 'dpr-adeline-extensions'),

				'param_name'		=> 'content_alignment',

				'value'				=> 'text-center',

				'options'			=> array(

					esc_html__('Left', 'dpr-adeline-extensions')	=> 'text-left',

					esc_html__('Center', 'dpr-adeline-extensions')	=> 'text-center',

					esc_html__('Right', 'dpr-adeline-extensions')	=> 'text-right'

				),

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'dependency'		=> array('element' => 'icon_pos', 'value' => array('icon-pos-1')),

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to choose the horizontal alignment for the icon.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Alignment', 'dpr-adeline-extensions'),

				'param_name'		=> 'content_alignment_2',

				'value'				=> 'text-left',

				'options'			=> array(

					esc_html__('Left', 'dpr-adeline-extensions')	=> 'text-left',

					esc_html__('Right', 'dpr-adeline-extensions')	=> 'text-right'

				),

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'dependency'		=> array('element' => 'icon_pos', 'value' => array('icon-pos-2', 'icon-pos-3')),

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Additional Settings', 'dpr-adeline-extensions' ),

				'param_name'       => 'extra_features_title',

				'edit_field_class' => 'vc_column vc_col-sm-12',

			),

		   vc_map_add_css_animation( false ),

		    array(

				'type' => 'textfield',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Extra Class Name', 'dpr-adeline-extensions'),

				'param_name' => 'el_class',

			),

			array(

				'type'				=> 'textarea',

				'heading'			=> esc_html__('Title', 'dpr-adeline-extensions'),

				'param_name'		=> 'title',

				'value'				=> esc_html__('Box Title', 'dpr-adeline-extensions'),

				'admin_label'		=> true,

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'textfield',

				'heading'			=> esc_html__('Subtitle', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle',

				'value'				=> esc_html__('Subtitle', 'dpr-adeline-extensions'),

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'textarea',

				'heading'			=> esc_html__('Content', 'dpr-adeline-extensions'),

				'param_name'		=> 'main_content',

				'value'				=> esc_html__('Featured box content. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque mollis ex eu blandit scelerisque.', 'dpr-adeline-extensions'),

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select where the link should be applied.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Link aply to', 'dpr-adeline-extensions'),

				'param_name'		=> 'read_more',

				'value'				=> 'none',

				'options'			=> array(

					esc_html__('No Link', 'dpr-adeline-extensions')		=> 'none',

					esc_html__('Complete Box', 'dpr-adeline-extensions')	=> 'box',

					esc_html__('Box Title', 'dpr-adeline-extensions')		=> 'title',

					esc_html__('Read More', 'dpr-adeline-extensions')		=> 'more',

				),

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'vc_link',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Add a custom link or select existing page. You can remove existing link as well.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Link URL', 'dpr-adeline-extensions'),

				'param_name'		=> 'link',

				'dependency'		=> array('element' => 'read_more', 'value' => array('box','title','more')),

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to enable or disable the Read more.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Display Read more button', 'dpr-adeline-extensions'),

				'param_name'		=> 'readmore_show',

				'options'			=> array(

					'show'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'dependency'		=> array('element' => 'read_more', 'value' => array('box','title','more')),

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose read more style.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Read more style', 'dpr-adeline-extensions'),

				'param_name'		=> 'readmore_style',

				'value'				=> 'button',

				'options'			=> array(

					esc_html__('Button', 'dpr-adeline-extensions')		=> 'button',

					esc_html__('Outlined Button', 'dpr-adeline-extensions') => 'button-outlined',

					esc_html__('Minimal', 'dpr-adeline-extensions')			=> 'minimal',

					esc_html__('Custom Button', 'dpr-adeline-extensions')	=> 'custom',

				),

				'dependency'		=> array('element' => 'readmore_show', 'value'   => 'show'),

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom button size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom button size', 'dpr-adeline-extensions'),

				'param_name'		=> 'custom_button_size',

				'value'				=> 'btn-sm',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'options'			=> array(

					esc_html__('Default', 'dpr-adeline-extensions')		=> '',

					esc_html__('Large', 'dpr-adeline-extensions') => 'btn-lg',

					esc_html__('Extra Large', 'dpr-adeline-extensions')	=> 'btn-xl',

					esc_html__('Small', 'dpr-adeline-extensions')	=> 'btn-sm',

				),

				'dependency'		=> array('element' => 'readmore_style', 'value'   => 'custom'),

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom button shape.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom button shape', 'dpr-adeline-extensions'),

				'param_name'		=> 'custom_button_shape',

				'value'				=> '',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'options'			=> array(

					esc_html__('Default', 'dpr-adeline-extensions')		=> '',

					esc_html__('Rounded', 'dpr-adeline-extensions') => 'btn-round',

					esc_html__('Circle', 'dpr-adeline-extensions')	=> 'btn-circle',

					esc_html__('Square', 'dpr-adeline-extensions')	=> 'btn-square',

				),

				'dependency'		=> array('element' => 'readmore_style', 'value'   => 'custom'),

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom button text color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'custom_button_color',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'dependency'		=> array('element' => 'readmore_style', 'value'   => array('custom','minimal')),

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom button text color hover', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'custom_button_color_hover',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'dependency'		=> array('element' => 'readmore_style', 'value'   => array('custom','minimal')),

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom button background color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background', 'dpr-adeline-extensions'),

				'param_name'		=> 'custom_button_bg_color',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'dependency'		=> array('element' => 'readmore_style', 'value'   => 'custom'),

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom button background color hover', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'custom_button_bg_color_hover',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'dependency'		=> array('element' => 'readmore_style', 'value'   => 'custom'),

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom button border color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border', 'dpr-adeline-extensions'),

				'param_name'		=> 'custom_button_border_color',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'dependency'		=> array('element' => 'readmore_style', 'value'   => 'custom'),

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom button border color hover', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'custom_button_border_color_hover',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'dependency'		=> array('element' => 'readmore_style', 'value'   => 'custom'),

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'textfield',

				'heading'			=> esc_html__('Read more text', 'dpr-adeline-extensions'),

				'param_name'		=> 'readmore_text',

				'value'				=> esc_html__('Read more', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'readmore_show', 'value'   => 'show'),

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set the number in a circled background on the icon.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Number at icon', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_number',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'dependency'		=> array('element' => 'style', 'value' => array('style-badge','style-outlined', 'style-framed')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'textfield',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enter the number.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Number', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_number_text',

				'edit_field_class'	=> 'vc_col-sm-4 vc_column ',

				'dependency'		=> array('element' => 'icon_number', 'value' => 'yes'),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the color for the number. Default value is #fff.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'number_color',

				'edit_field_class'	=> 'vc_col-sm-4 vc_column ',

				'dependency'		=> array('element' => 'icon_number', 'value' => 'yes'),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the background color for the number. The default value is #38C886', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'number_bg_color',

				'edit_field_class'	=> 'vc_col-sm-4 vc_column ',

				'dependency'		=> array('element' => 'icon_number', 'value' => 'yes'),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select existing icon, upload custom image or add the text.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon container content', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_type',

				'value'				=> 'icon',

				'options'			=> array(

					esc_html__('Icon', 'dpr-adeline-extensions')	=> 'icon',

					esc_html__('Image', 'dpr-adeline-extensions')	=> 'custom',

					esc_html__('Animated SVG', 'dpr-adeline-extensions')	=> 'animated_svg',

					esc_html__('Text', 'dpr-adeline-extensions')	=> 'text',

				),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

		  array(

				"type" => "dpr_icon_selector",

				"heading" => esc_attr__("Icon", 'dpr-adeline-extensions'),

				"param_name" => "icon",

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select icon.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'icon_type', 'value' => 'icon',),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),



			array(

				'type'				=> 'attach_image',

				'heading'			=> esc_html__('Upload image', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_image_id',

				'admin_label'		=> true,

				'description'		=> esc_html__('Upload the custom image from media library', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'icon_type', 'value' => array('custom')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'attach_image',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Upload your SVG from media library.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Upload SVG', 'dpr-adeline-extensions'),

				'param_name'		=> 'svg_id',

				'admin_label'		=> true,

				'description'		=> esc_html__('You can use the amazing ', 'dpr-adeline-extensions').'<a href="https://jakearchibald.github.io/svgomg/" target="_blank">SVGOMG</a>'.esc_html__(' to clean your SVG before uploading here', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'icon_type', 'value' => array('animated_svg')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose draw animation type.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('SVG Animation Type', 'dpr-adeline-extensions'),

				'param_name'		=> 'animation_type',

				'value'				=> 'delayed',

				'options'			=> array(

					esc_html__("Delayed", 'dpr-adeline-extensions') => "delayed",

					esc_html__("Sync", 'dpr-adeline-extensions') => "sync",

					esc_html__("One-By-One", 'dpr-adeline-extensions') => "oneByOne",

					esc_html__("Scenarize", 'dpr-adeline-extensions') => "scenario-sync"

				),

				'description'		=> esc_html__('You can choose from different options of SVG draw animation. Test that here ', 'dpr-adeline-extensions').'<a href="http://maxwellito.github.io/vivus/" target="_blank">VIVUS</a>'.esc_html__(' SVG Animation Type', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'icon_type', 'value' => array('animated_svg')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set the size for the icon (image).', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Size', 'dpr-adeline-extensions'),

				'param_name'		=> 'svg_size',

				'min'				=> 12,

				'suffix'  			=> 'px',

				'value' => '50',

				'edit_field_class'	=> 'vc_column vc_col-sm-4   ',

				'dependency'		=> array('element' => 'icon_type', 'value' => array('animated_svg')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set SVG draw Animation Duration.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Animation Duration', 'dpr-adeline-extensions'),

				'param_name'		=> 'animation_duration',

				'min'				=> 1,

				'value' 			=> '1000',

				'suffix'				=> 'ms',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

				'dependency'		=> array('element' => 'icon_type', 'value' => array('animated_svg')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('You can Choose SVG&#39;s drawing color (Stroke in Normal Terms Border Color).', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Drawing Color', 'dpr-adeline-extensions'),

				'param_name' => 'draw_color',

				"value" => '#D3AE5F',

				'admin_label' => false,

				'edit_field_class'	=> 'vc_col-sm-4 vc_column ',

				'dependency'		=> array('element' => 'icon_type', 'value' => array('animated_svg')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'textarea',

				'heading'			=> esc_html__('Text', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_text',

				'dependency'		=> array('element' => 'icon_type', 'value' => array('text')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

				

			),

			array(

				'type'				=> 'number',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set the size for the icon (image).', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Size', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_size',

				'min'				=> 12,

				'edit_field_class'	=> 'vc_column vc_col-sm-4   ',

				'dependency'		=> array('element' => 'icon_type', 'value' => array('custom', 'icon')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'class'				=> '',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the icon color. The default color for the style Classic and Outlined style is main accent color set in Template Options. The default color for the badge style is #fff.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-4  ',

				'dependency'		=> array('element' => 'icon_type', 'value' => array('icon')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'class'				=> '',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the icon hover color. The default color for the style Classic and Outlined style is main accent color set in Template Options. The default color for the badge style is #fff.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_hover',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'dependency'		=> array('element' => 'icon_type', 'value' => array('icon')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable gradient for icon. Will be used instead solid colors.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Use gradient?', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_gradient_color',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'dependency'		=> array('element' => 'icon_type', 'value' => array('icon')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'dpr_gradient_picker',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the gradient background for the icon. Solid color set above will be ignored', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Gradient', 'dpr-adeline-extensions'),

				'param_name' => 'icon_gradient',

				'value' => '45;0%/rgb(77, 47, 255);100%/rgb(36, 143, 255)',

				'dependency'		=> array('element' => 'use_gradient_color', 'value' => 'yes'),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable gradient for icon. Will be used instead solid colors.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Use gradient hover?', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_gradient_color_hover',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'dependency'		=> array('element' => 'icon_type', 'value' => array('icon')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'dpr_gradient_picker',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the gradient background for the icon. Solid color set above will be ignored', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Gradient hover', 'dpr-adeline-extensions'),

				'param_name' => 'icon_gradient_hover',

				'value' => '45;0%/rgb(77, 47, 255);100%/rgb(36, 143, 255)',

				'dependency'		=> array('element' => 'use_gradient_color_hover', 'value' => 'yes'),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom text icon color. Default is #b5bdc9.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'text_icon_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'icon_type', 'value' => array('text')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'text_icon_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'icon_type', 'value' => array('text')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom linne height..', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'text_icon_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'icon_type', 'value' => array('text')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom letter spacing.', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'text_icon_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'icon_type', 'value' => array('text')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'text_icon_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'dependency'		=> array('element' => 'icon_type', 'value' => array('text')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

	  		),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to use custom Google font.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'text_icon_use_google_fonts',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'dependency'		=> array('element' => 'icon_type', 'value' => array('text')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'text_icon_custom_fonts',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'dependency'		=> array('element' => 'text_icon_use_google_fonts', 'value' => 'yes'),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set the background size for the icon. The default value is 100px.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon badge size', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_bg_size',

				'min'				=> 1,

				'edit_field_class'	=> 'vc_column vc_col-sm-4  ',

				'dependency'		=> array('element' => 'style', 'value' => array('style-badge','style-outlined', 'style-framed')),

				'group'				=> esc_html__('Icon Background', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose badge background color. Default is main accent color set in template options', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background color', 'dpr-adeline-extensions'),

				'param_name'		=> 'background_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 no-padding-top',

				'dependency'		=> array('element' => 'style', 'value' => array('style-badge', 'style-framed')),

				'group'				=> esc_html__('Icon Background', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose badge background color on hover.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background color hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'hover_background_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 no-padding-top',

				'dependency'		=> array('element' => 'style', 'value' => array('style-badge', 'style-framed')),

				'group'				=> esc_html__('Icon Background', 'dpr-adeline-extensions'),

			),



			array(

				'type'				=> 'dpr_title',

				'text'				=> '',

				'param_name'		=> 'sep_1',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'style', 'value' => array('style-badge', 'style-framed')),

				'group'				=> esc_html__('Icon Background', 'dpr-adeline-extensions'),

			),

			

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable gradient background. Will be used instead solid colors.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Use Background gradient?', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_gradient_bg',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'dependency'		=> array('element' => 'style', 'value' => array('style-badge', 'style-framed')),

				'group'				=> esc_html__('Icon Background', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'dpr_gradient_picker',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the gradient background for the icon. Solid color set above will be ignored', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Gradient background', 'dpr-adeline-extensions'),

				'param_name' => 'badge_gradient',

				'value' => '45;0%/rgb(77, 47, 255);100%/rgb(36, 143, 255)',

				'dependency'		=> array('element' => 'use_gradient_bg', 'value' => 'yes'),

				'group'				=> esc_html__('Icon Background', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable gradient background on hover. Will be used instead solid colors.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Use Background gradient hover?', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_gradient_bg_hover',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'dependency'		=> array('element' => 'style', 'value' => array('style-badge', 'style-framed')),

				'group'				=> esc_html__('Icon Background', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'dpr_gradient_picker',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the hover gradient background for the icon. Solid color set above will be ignored', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Gradient background Hover', 'dpr-adeline-extensions'),

				'param_name' => 'badge_gradient_hover',

				'value' => '45;0%/rgb(77, 47, 255);100%/rgb(36, 143, 255)',

				'dependency'		=> array('element' => 'use_gradient_bg_hover', 'value' => 'yes'),

				'group'				=> esc_html__('Icon Background', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> '',

				'param_name'		=> 'sep_3',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'style', 'value' => array('style-badge','style-outlined', 'style-framed')),

				'group'				=> esc_html__('Icon Background', 'dpr-adeline-extensions'),

			),

			

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose badge border color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border color', 'dpr-adeline-extensions'),

				'param_name'		=> 'border_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 no-padding-top',

				'dependency'		=> array('element' => 'style', 'value' => array('style-outlined', 'style-framed')),

				'group'				=> esc_html__('Icon Background', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose badge border color on hover.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border color hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'hover_border_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-4  no-padding-top',

				'dependency'		=> array('element' => 'style', 'value' => array('style-outlined', 'style-framed')),

				'group'				=> esc_html__('Icon Background', 'dpr-adeline-extensions'),

			),



			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose badge border radius.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border radius', 'dpr-adeline-extensions'),

				'param_name'		=> 'border_radius',

				'min'				=> 0,

				'edit_field_class'	=> 'vc_column vc_col-sm-4   no-padding-top',

				'dependency'		=> array('element' => 'style', 'value' => array('style-badge','style-outlined', 'style-framed')),

				'group'				=> esc_html__('Icon Background', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> '',

				'param_name'		=> 'sep_1',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'style', 'value' => array('style-badge','style-outlined', 'style-framed')),

				'group'				=> esc_html__('Icon Background', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose badge border radius on hover.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border radius Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'hover_border_radius',

				'min'				=> 0,

				'edit_field_class'	=> 'vc_column vc_col-sm-4  no-padding-top',

				'dependency'		=> array('element' => 'style', 'value' => array('style-badge','style-outlined', 'style-framed')),

				'group'				=> esc_html__('Icon Background', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set badge border width .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border width', 'dpr-adeline-extensions'),

				'param_name'		=> 'border_width',

				'min'				=> 1,

				'edit_field_class'	=> 'vc_column vc_col-sm-4 no-padding-top',

				'dependency'		=> array('element' => 'style', 'value' => array('style-outlined', 'style-framed')),

				'group'				=> esc_html__('Icon Background', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Title Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_typography_head',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'title', 'not_empty' => true),

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom ttle color. Default is headings color set in template options.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'title', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size.Default is 18px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'title', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title linne height.Default is 18px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'title', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'title', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'title_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'dependency'		=> array('element' => 'title', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

	  		),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title color in hover state.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color: Hover State', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_color_hover',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'title', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font. .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_google_fonts',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'dependency'		=> array('element' => 'title', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'title_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'dependency'		=> array('element' => 'use_google_fonts', 'value' => 'yes'),

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Subtitle Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_typography_head',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'subtitle', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom subtitle color. Default is #808080.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'subtitle', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size.Default is 13px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'subtitle', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom linne height.Default is 28px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'subtitle', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'subtitle', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'subtitle_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'dependency'		=> array('element' => 'subtitle', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

	  		),



			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom subtitle color in hover state.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__(' Color:Hover State', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_color_hover',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'dependency'		=> array('element' => 'subtitle', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),



						

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Content Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'content_typgraphy_head',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'main_content', 'not_empty' => true),

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom content color. Default is text color set in template options.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'content_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'main_content', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size.Default text font size set in template options .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'content_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'main_content', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title linne height. Default is text line height set in template options .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'content_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'main_content', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'content_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'main_content', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'content_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'dependency'		=> array('element' => 'main_content', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

	  		),



			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom content color in hover state.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color: Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'content_color_hover',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'dependency'		=> array('element' => 'main_content', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),



			array(

				'type' => 'css_editor',

				'heading' => __( 'CSS box', 'dpr-adeline-extensions' ),

				'param_name' => 'css',

				'group' => __( 'Design Options', 'dpr-adeline-extensions' ),

			),

			

			array(

				'type'				=> 'dpr_switcher',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('This option allows you to use gradient background for this box.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background Gradient', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_gradient_bg',

				'options'			=> array(

					'yes'		=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group' => __( 'Design Options', 'dpr-adeline-extensions' ),

				'edit_field_class'	=> 'vc_col-sm-4 vc_column ',

			),

			

			array(

				'type' => 'dpr_gradient_picker',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the gradient for box background', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background Gradient', 'dpr-adeline-extensions'),

				'edit_field_class' => 'vc_column vc_col-sm-8',

				'param_name' => 'box_gradient',

				'value' => '',

				'dependency'		=> array('element' => 'use_gradient_bg', 'value' => array('yes')),

				'group'	=> esc_html__('Design Options', 'dpr-adeline-extensions')

			),

			

			array(

				'type' => 'dropdown',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set shadow for featured box.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Shadow', 'dpr-adeline-extensions'),

				'param_name' => 'box_shadow',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'value' => array(

						__('None', 'dpr-adeline-extensions') => '',

						__('Shadow Depth 1', 'dpr-adeline-extensions') => '1',

						__('Shadow Depth 2', 'dpr-adeline-extensions') => '2',

						__('Shadow Depth 3', 'dpr-adeline-extensions') => '3',

						__('Shadow Depth 4', 'dpr-adeline-extensions') => '4',

						__('Shadow Depth 5', 'dpr-adeline-extensions') => '5',

						__('Shadow Depth 6', 'dpr-adeline-extensions') => '6',

						__('Custom Shadow', 'dpr-adeline-extensions') => 'custom',

					   ),

				'group'	=> esc_html__('Design Options', 'dpr-adeline-extensions'),

			),

			array(

				"type" => "dpr_shadow_picker",

				"class" => "",

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom shadow for featured box.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom Shadow', 'dpr-adeline-extensions'),

				"param_name" => "box_shadow_custom",

				"value" => "none||||||",

				'dependency'		=> array('element' => 'box_shadow', 'value' => array('custom')),

				'group'	=> esc_html__('Design Options', 'dpr-adeline-extensions'),

			),



			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Hover State Options', 'dpr-adeline-extensions' ),

				'param_name'       => 'design_option_title_1',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group'				=> esc_html__('Design Options', 'dpr-adeline-extensions'),

			),



			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom hover state border color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'box_border_color_hover',

				'edit_field_class'	=> 'vc_col-sm-4 vc_column ',

				'group'				=> esc_html__('Design Options', 'dpr-adeline-extensions'),

			),



			array(

				'type' => 'dropdown',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom border style.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border Style', 'dpr-adeline-extensions'),

				'param_name' => 'box_border_style_hover',

				'edit_field_class' => 'vc_column vc_col-sm-4',

				'value' => array(

						__('Inherit', 'dpr-adeline-extensions') => '',

						__('Solid', 'dpr-adeline-extensions') => 'solid',

						__('Dotted', 'dpr-adeline-extensions') => 'dotted',

						__('Dashed', 'dpr-adeline-extensions') => 'dashed',

						__('Hidden', 'dpr-adeline-extensions') => 'hidden',

						__('Double', 'dpr-adeline-extensions') => 'double',

						__('Groove', 'dpr-adeline-extensions') => 'groove',

						__('Ridge', 'dpr-adeline-extensions') => 'ridge',

						__('Inset', 'dpr-adeline-extensions') => 'inset',

						__('Outset', 'dpr-adeline-extensions') => 'outset',

					   ),

				'group'	=> esc_html__('Design Options', 'dpr-adeline-extensions'),

			),



			array(

				'type' => 'dropdown',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom border radius.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border Radius', 'dpr-adeline-extensions'),

				'param_name' => 'box_border_radius_hover',

				'edit_field_class' => 'vc_column vc_col-sm-4',

				'value' => array(

						__('Inherit', 'dpr-adeline-extensions') => '',

						__('1px', 'dpr-adeline-extensions') => '1px',

						__('2px', 'dpr-adeline-extensions') => '2px',

						__('3px', 'dpr-adeline-extensions') => '3px',

						__('4px', 'dpr-adeline-extensions') => '4px',

						__('5px', 'dpr-adeline-extensions') => '5px',

						__('10px', 'dpr-adeline-extensions') => '10px',

						__('15px', 'dpr-adeline-extensions') => '15px',

						__('20px', 'dpr-adeline-extensions') => '20px',

						__('25px', 'dpr-adeline-extensions') => '25px',

						__('30px', 'dpr-adeline-extensions') => '30px',

						__('35px', 'dpr-adeline-extensions') => '35px',

					   ),

				'group'	=> esc_html__('Design Options', 'dpr-adeline-extensions'),

			),



			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom hover state background color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'box_background_color_hover',

				'edit_field_class'	=> 'vc_col-sm-4 vc_column ',

				'group'				=> esc_html__('Design Options', 'dpr-adeline-extensions'),

			),

			



			array(

				'type'				=> 'attach_image',

				'param_name'		=> 'box_bg_image_hover',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select image from media library for hover background image for this box', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background Image', 'dpr-adeline-extensions'),

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'group'			   => esc_html('Design Options','dpr-adeline-extensions')

			),



			array(

				'type'				=> 'dpr_switcher',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('This option allows you to use gradient background for this box.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Use gradient background', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_gradient_bg_hover',

				'options'			=> array(

					'yes'		=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group' => __( 'Design Options', 'dpr-adeline-extensions' ),

				'edit_field_class'	=> 'vc_col-sm-4 vc_column '

			),



			array(

				'type' => 'dpr_gradient_picker',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the gradient for box background in hover state', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background Gradient', 'dpr-adeline-extensions'),

				'edit_field_class' => 'vc_column vc_col-sm-8',

				'param_name' => 'box_gradient_hover',

				'value' => '',

				'group'	=> esc_html__('Design Options', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'use_gradient_bg_hover', 'value' => array('yes')),

			),



			array(

				'type' => 'dropdown',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set shadow for featured box.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Shadow', 'dpr-adeline-extensions'),

				'param_name' => 'box_shadow_hover',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'value' => array(

						__('None', 'dpr-adeline-extensions') => '',

						__('Shadow Depth 1', 'dpr-adeline-extensions') => '1',

						__('Shadow Depth 2', 'dpr-adeline-extensions') => '2',

						__('Shadow Depth 3', 'dpr-adeline-extensions') => '3',

						__('Shadow Depth 4', 'dpr-adeline-extensions') => '4',

						__('Shadow Depth 5', 'dpr-adeline-extensions') => '5',

						__('Shadow Depth 6', 'dpr-adeline-extensions') => '6',

						__('Custom Shadow', 'dpr-adeline-extensions') => 'custom',

					   ),

				'group'	=> esc_html__('Design Options', 'dpr-adeline-extensions'),

			),

			

			array(

				"type" => "dpr_shadow_picker",

				"class" => "",

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom shadow for featured box in hover state.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom Shadow', 'dpr-adeline-extensions'),

				"param_name" => "box_shadow_custom_hover",

				"value" => "none||||||",

				'dependency'		=> array('element' => 'box_shadow_hover', 'value' => array('custom')),

				'group'	=> esc_html__('Design Options', 'dpr-adeline-extensions'),

			),



			array(

				'type' => 'dropdown',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set hover animation for ctagory tile.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Hover animation', 'dpr-adeline-extensions'),

				'param_name' => 'box_hover_animation',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'value' => array(

					__('None', 'dpr-adeline-extensions') => 'none',

                    __('Scale Up 3%', 'dpr-adeline-extensions')       => 'dpr-upscale-onhover-1',

                    __('Scale Up 6%', 'dpr-adeline-extensions')       => 'dpr-upscale-onhover-2',

                    __('Scale Up 15%', 'dpr-adeline-extensions')      => 'dpr-upscale-onhover-3',

                     __('Scale Up 10%', 'dpr-adeline-extensions')      => 'dpr-upscale-onhover-3',

                    __('Scale Down 3%', 'dpr-adeline-extensions')     => 'dpr-downscale-onhover-4',

                    __('Scale Down 6%', 'dpr-adeline-extensions')     => 'dpr-downscale-onhover-2',

                    __('Move Up 5px', 'dpr-adeline-extensions')       => 'dpr-up-onhover-1',

                    __('Move Up 10px', 'dpr-adeline-extensions')      => 'dpr-up-onhover-2',

                    __('Move Up 15px', 'dpr-adeline-extensions')      => 'dpr-up-onhover-3',

                    __('Move Up 20px', 'dpr-adeline-extensions')      => 'dpr-up-onhover-4',

                    __('Move Down 5px', 'dpr-adeline-extensions')     => 'dpr-down-onhover-1',

                    __('Move Down 10px', 'dpr-adeline-extensions')    => 'dpr-down-onhover-2',

                    __('Move Down 15px', 'dpr-adeline-extensions')    => 'dpr-down-onhover-3',

                    __('Move Down 20px', 'dpr-adeline-extensions')    => 'dpr-down-onhover-4',

                    __('Move UpLeft 5px', 'dpr-adeline-extensions')   => 'dpr-up-left-onhover-1',

                    __('Move UpLeft 10px', 'dpr-adeline-extensions')  => 'dpr-up-left-onhover-2',

                    __('Move UpLeft 15px', 'dpr-adeline-extensions')  => 'dpr-up-left-onhover-3',

                    __('Move UpLeft 20px', 'dpr-adeline-extensions')  => 'dpr-up-left-onhover-4',

                    __('Move UpRight 5px', 'dpr-adeline-extensions')  => 'dpr-up-right-onhover-1',

                    __('Move UpRight 10px', 'dpr-adeline-extensions') => 'dpr-up-right-onhover-2',

                    __('Move UpRight 15px', 'dpr-adeline-extensions')  => 'dpr-up-right-onhover-3',

                    __('Move UpRight 20px', 'dpr-adeline-extensions') => 'dpr-up-right-onhover-4',

                    __('Move DownLeft 5px', 'dpr-adeline-extensions')  => 'dpr-down-left-onhover-1',

                    __('Move DownLeft 10px', 'dpr-adeline-extensions') => 'dpr-down-left-onhover-2',

                    __('Move DownLeft 15px', 'dpr-adeline-extensions')  => 'dpr-down-left-onhover-3',

                    __('Move DownLeft 20px', 'dpr-adeline-extensions') => 'dpr-down-left-onhover-4',  

                    __('Move DownRight 5px', 'dpr-adeline-extensions')  => 'dpr-down-right-onhover-1',

                    __('Move DownRight 10px', 'dpr-adeline-extensions') => 'dpr-down-right-onhover-2',

                    __('Move DownRight 15px', 'dpr-adeline-extensions')  => 'dpr-down-right-onhover-3',

                    __('Move DownRight 20px', 'dpr-adeline-extensions') => 'dpr-down-right-onhover-4', 

                    __('Item Tilt', 'dpr-adeline-extensions') => 'dpr-item-tilt',

					   ),

				'group'	=> esc_html__('Design Options', 'dpr-adeline-extensions'),

			),



		),

	)

);