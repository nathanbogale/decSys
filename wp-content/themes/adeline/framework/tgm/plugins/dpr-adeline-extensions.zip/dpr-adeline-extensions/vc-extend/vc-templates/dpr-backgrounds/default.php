<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}


$output .= '<div class="dpr_row_bg_container">';
$output .= $overlay_output;
$output .= '</div>';

