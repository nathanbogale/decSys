<?php

// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}



//VC Inner Row VC Map modifications



if(function_exists('vc_remove_param')) {

	

	vc_remove_param('vc_row_inner','disable_element');

	vc_remove_param('vc_row_inner','el_class');

	vc_remove_param('vc_row_inner','el_id');

	vc_remove_param('vc_row_inner','equal_height');

	vc_remove_param('vc_row_inner','content_placement');

	vc_remove_param('vc_row_inner','gap');



}



	vc_add_param(

		'vc_row_inner', array(

			'type' => 'dpr_switcher',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('The row won\'t be visible on the public side of your website. You can switch it back any time.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Disable row', 'dpr-adeline-extensions'),

			'param_name' => 'disable_element',

			'edit_field_class' => 'vc_column vc_col-sm-12',

			'weight' => '1',

			'value' => '',

			'options' => array(

				'yes' => array(

						'label' => '',

						'on' => 'Yes',

						'off' => 'No',

					),

				),

		)

	);

	vc_add_param(

		'vc_row_inner', array(

			'type' => 'dpr_radio',

			'class' => '',

			'weight' => 1,

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select content width for this row.Boxed width is set in template optioins {be default 1280px) or full width.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Content Width', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_row_content_sizing',

			'value' => 'full_width_content',

			'options' => array(

				__('Boxed', 'dpr-adeline-extensions') => 'boxed',

				__('Full Width', 'dpr-adeline-extensions') => 'full_width_content',

			),

		)

	);

	vc_add_param(

		'vc_row_inner', array(

			'type' => 'dpr_switcher',

			'class' => '',

			'weight' => 1,

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set the row to full-screen.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Full height row', 'dpr-adeline-extensions'),

			'param_name' => 'full_height',

			'edit_field_class' => 'vc_column vc_col-sm-6',

			'value' => '',

			'options' => array(

				'yes' => array(

						'label' => '',

						'on' => 'Yes',

						'off' => 'No',

					),

				),

		)

	);

	vc_add_param(

		'vc_row_inner', array(

			'type' => 'dpr_switcher',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Allows you to set columns in row to equal height adjusted to the height of the bigger one.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Equal Height', 'dpr-adeline-extensions'),

			'param_name' => 'equal_height',

			'edit_field_class' => 'vc_column vc_col-sm-12',

			'weight' => '1',

			'value' => '',

			'options' => array(

				'yes' => array(

						'label' => '',

						'on' => 'Yes',

						'off' => 'No',

					),

				),

		)

	);

	vc_add_param(

		'vc_row_inner', array(

			'type' => 'dpr_radio',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select content position within columns.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Content position', 'dpr-adeline-extensions'),

			'param_name' => 'content_placement',

			'edit_field_class' => 'vc_column vc_col-sm-8',

			'weight' => 1,

			'value' => '',

			'options' => array(

				__('Default', 'dpr-adeline-extensions') => '',

				__('Top', 'dpr-adeline-extensions') => 'top',

				__('Middle', 'dpr-adeline-extensions') => 'middle',

				__('Bottom', 'dpr-adeline-extensions') => 'bottom',

			)

		)

	);

	vc_add_param(

	'vc_row_inner',array(

		'type' => 'dropdown',

		'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select gap between columns in row.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Columns gap', 'dpr-adeline-extensions'),

		'param_name' => 'gap',

		'edit_field_class' => 'vc_column vc_col-sm-4',

		'weight' => 1,

		'value' => array(

			'0px' => '0',

			'1px' => '1',

			'2px' => '2',

			'3px' => '3',

			'4px' => '4',

			'5px' => '5',

			'10px' => '10',

			'15px' => '15',

			'20px' => '20',

			'25px' => '25',

			'30px' => '30',

			'35px' => '35',

		),

		'std' => '0',

	)

	);

	vc_add_param(

		'vc_row_inner',array(

			'type' => 'textfield',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enter optional row ID. Make sure it is unique, and it is valid as w3c specification: %s (Must not have spaces).', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Row ID', 'dpr-adeline-extensions'),

			'param_name' => 'el_id',

			'weight' => 1

		)

	);

	vc_add_param(

		'vc_row_inner',array(

			'type' => 'textfield',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Extra Class Name', 'dpr-adeline-extensions'),

			'param_name' => 'el_class',

			'weight' => 1

		)

	);

	vc_add_param(

		'vc_row_inner', array(

			'type' => 'dpr_title',

			'text' => esc_html__('Background Options', 'dpr-adeline-extensions'),

			'param_name' => 'background_title',

			'class' => '',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),			

		)

	);

	vc_add_param(

		'vc_row_inner', array(

			'type' => 'dpr_radio',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the background style for the row. The text colors will be changed according to the style you choose to make it more readable.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background style', 'dpr-adeline-extensions'),

			'param_name' => 'bg_style',

			'value' => '',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),			

			'options' => array(

				__('Light', 'dpr-adeline-extensions') => '',

				__('Dark', 'dpr-adeline-extensions') => 'dark',

			)

		)

	);

	vc_add_param(

		'vc_row_inner', array(

			'type' => 'dpr_radio',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the background type for the row. Default will be use settings from Design Options for this row. Gradient allows you to set the gradient backgrouns. Parallax Image allows you to upload the image and add the parallax. Video allows you to set the video as row\'s background', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background type', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_bg_type',

			'value' => 'default',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),			

			'options' => array(

				__('Default', 'dpr-adeline-extensions') => 'default',

				__('Gradient', 'dpr-adeline-extensions') => 'gradient',

				__('Animated', 'dpr-adeline-extensions') => 'animated-bgcolor',

				__('Parallax Image', 'dpr-adeline-extensions') => 'parallax-image',

				__('Multilayers Parallax', 'dpr-adeline-extensions') => 'multilayer-parallax',

				__('Video', 'dpr-adeline-extensions') => 'video',
		
				__('Text', 'dpr-adeline-extensions') => 'text',
		
				__('Marque', 'dpr-adeline-extensions') => 'marque'

			)

		)

	);

	vc_add_param(

		'vc_row_inner', array(

				'type' => 'dpr_gradient_picker',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the gradient for the row background.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Row gradient', 'dpr-adeline-extensions'),

				'param_name' => 'dpr_row_gradient',

				'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),			

				'value' => '',

				'dependency' => array(

					'element' => 'dpr_bg_type',

					'value' => 'gradient',

				),

		)

	);

	vc_add_param(

		'vc_row_inner', array(

			'type' => 'dpr_switcher',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('This option allows you to enable or disable the row gradient animation.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Enable Gradient Animation', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_row_gradient_animate',

			'edit_field_class' => 'vc_column vc_col-sm-4',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'dependency' => array(

					'element' => 'dpr_bg_type',

					'value' => 'gradient',

				),			

			'value' => '',

			'options' => array(

				'yes' => array(

						'label' => '',

						'on' => 'Yes',

						'off' => 'No',

					),

				),

		)

	);

	vc_add_param(

		'vc_row_inner',array(

			'type' => 'number',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set the animation duration in ms.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Animation Duration (in sec)', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_row_gradient_animate_speed',

			'value' =>'10',

			'min'=>'0',

			'step' => '0.5',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'edit_field_class' => 'vc_column vc_col-sm-4',

			'dependency' => array(

					'element' => 'dpr_row_gradient_animate',

					'value' => array('yes'),

			),		

		)

	);

	vc_add_param(

		'vc_row_inner',array(

			'type' => 'number',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set the gradient background spread in % to adjust animation effect to uour needs.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background Spread (in %)', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_row_gradient_animate_spread',

			'value' =>'400',

			'min'=>'0',

			'step' => '10',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'edit_field_class' => 'vc_column vc_col-sm-4',

			'dependency' => array(

					'element' => 'dpr_row_gradient_animate',

					'value' => array('yes'),

			),		

		)

	);

	vc_add_param(

		'vc_row_inner', array(

                'type' => 'param_group',

                'value' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Add colors for background color animation.You can use multiple colors which will be fade with animation speed set bellow.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Colors', 'dpr-adeline-extensions'),

				'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

				'value' => '',

				'dependency' => array(

						'element' => 'dpr_bg_type',

						'value' => 'animated-bgcolor',

					),		

                'param_name' => 'dpr_animated_colors',

                // Note params is mapped inside param-group:

                'params' => array(			

                    array(

                        'type' => 'colorpicker',

                        'param_name' => 'dpr_animated_color',

                    ),

                )

            )

	);

	vc_add_param(

		'vc_row_inner',array(

			'type' => 'number',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set the animation duration in ms.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Animation Loop Duration (in sec)', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_animated_speed',

			'value' =>'3',

			'min'=>'0',

			'step' => '0.1',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'edit_field_class' => 'vc_column vc_col-sm-6',

			'dependency' => array(

					'element' => 'dpr_bg_type',

					'value' => 'animated-bgcolor',

			),		

		)

	);

	vc_add_param(

		'vc_row_inner', array(

			'type' => 'attach_image',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose parallax image', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Parallax image', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_parallax_image',

			'value' => '',

			'edit_field_class' => 'vc_column vc_col-sm-12',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'dependency' => array(

					'element' => 'dpr_bg_type',

					'value' => 'parallax-image',

			),		

		)

	);

	vc_add_param(

		'vc_row_inner', array(

			'type' => 'dpr_radio',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose Parallax Direction', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Parallax Direction', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_parallax_type',

			'value' => 'vertical',

			'edit_field_class' => 'vc_column vc_col-sm-6',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'dependency' => array(

					'element' => 'dpr_bg_type',

					'value' => 'parallax-image',

				),		

			'options' => array(

				__('Vertical', 'dpr-adeline-extensions') => 'vertical',

				__('Horizontal', 'dpr-adeline-extensions') => 'horizontal'

			)

		)

	);

	vc_add_param(

		'vc_row_inner',array(

			'type' => 'number',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('This attribute sets elements offset and speed. It can be positive (0.3) or negative (-0.3). Less means slower.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Parallax Factor', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_parallax_factor',

			'value' =>'0.30',

			'min'=>'-1',

			'max'=>'1',

			'step' => '0.01',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'edit_field_class' => 'vc_column vc_col-sm-6',

			'dependency' => array(

					'element' => 'dpr_bg_type',

					'value' => 'parallax-image',

			),		

		)

	);



	vc_add_param(

		'vc_row_inner', array(

                'type' => 'param_group',

                'value' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Add and order parallax layers.You can use multiple transparent or semitransparent layers and set parallax direction and factor sepratelly for each layer.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Parallax Layers', 'dpr-adeline-extensions'),

				'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

				'value' => '',

				'dependency' => array(

						'element' => 'dpr_bg_type',

						'value' => 'multilayer-parallax',

					),		

                'param_name' => 'dpr_parallax_layers',

                // Note params is mapped inside param-group:

                'params' => array(

                    array(

                        'type' => 'attach_image',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose layer image', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Layer image', 'dpr-adeline-extensions'),

                        'param_name' => 'dpr_layer_parallax_image',

                    ),

                    array(

                        'type' => 'dpr_radio',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose Parallax Direction', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Layer Parallax Direction', 'dpr-adeline-extensions'),

                        'param_name' => 'dpr_layer_parallax_type',

						'value' => 'vertical',

						'edit_field_class' => 'vc_column vc_col-sm-6',

						'options' => array(

							__('Vertical', 'dpr-adeline-extensions') => 'vertical',

							__('Horizontal', 'dpr-adeline-extensions') => 'horizontal'

						)

                    ),

                    array(

                        'type' => 'number',

                        'param_name' => 'dpr_layer_parallax_fator',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('This attribute sets elements offset and speed. It can be positive (0.3) or negative (-0.3). Less means slower.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Layer Parallax Factor', 'dpr-adeline-extensions'),

						'value' => '0.30',

						'min'=>'-1',

						'max'=>'1',

						'step' => '0.01',

						'edit_field_class' => 'vc_column vc_col-sm-6'

                    ),

                )

            )

	);

	vc_add_param(

		'vc_row_inner', array(

			'type' => 'dpr_image_select',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Chose video type', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Video Source', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_video_type',

			'value' => 'hosted',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'dependency' => array(

					'element' => 'dpr_bg_type',

					'value' => 'video',

				),		

			'options'			=> array(

				'hosted'			=> array(

					'label'			=> esc_html__('Hosted','dpr-adeline-extensions'),

					'src'				=> $module_images . 'row/self_hosted.png'

				),

				'youtube'			=> array(

					'label'			=> esc_html__('YouTube','dpr-adeline-extensions'),

					'src'				=> $module_images . 'row/youtube.png'

				),

				'vimeo'			=> array(

					'label'			=> esc_html__('Vimeo','dpr-adeline-extensions'),

					'src'				=> $module_images . 'row/vimeo.png'

				)

			),

		)

	);

	vc_add_param(

		'vc_row_inner', array(

			'type' => 'textfield',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Add the link to your video in mp4 format', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Video in MP4 format', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_mp4_url',

			'value' => '',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'dependency' => array(

					'element' => 'dpr_video_type',

					'value' => 'hosted',

				),		

		)

	);

	vc_add_param(

		'vc_row_inner', array(

			'type' => 'textfield',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Add the link to your video in WebM / Ogg format', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Video in WEBM / OGG format', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_webm_url',

			'value' => '',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'dependency' => array(

					'element' => 'dpr_video_type',

					'value' => 'hosted',

				),

			'description' => esc_attr__('IE, Chrome & Safari support MP4 format, while Firefox & Opera prefer WebM / Ogg formats. You can upload the video through WordPress Media Library.', 'dpr-adeline-extensions')

		)

	);

	vc_add_param(

		'vc_row_inner', array(

			'type' => 'textfield',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Add the video ID. Look at the URL of that page, and at the end of it, you should see a combination of numbers and letters after an equal sign (=)', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('YouTube Video ID', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_youtube_id',

			'value' => '',

			'edit_field_class' => 'vc_column vc_col-sm-12',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'dependency' => array(

					'element' => 'dpr_video_type',

					'value' => 'youtube',

				),

			'description' => esc_attr__('Add the video ID. Look at the URL of that page, and at the end of it, you should see a combination of numbers and letters after an equal sign (=).', 'dpr-adeline-extensions')

		)

	);

	vc_add_param(

		'vc_row_inner', array(

			'type' => 'textfield',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Add the video ID. Copy the numeric code that appears at the end of its URL at the top of your browser window', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Vimeo Video ID', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_vimeo_id',

			'value' => '',

			'edit_field_class' => 'vc_column vc_col-sm-12',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'dependency' => array(

					'element' => 'dpr_video_type',

					'value' => 'vimeo',

				),

			'description' => esc_attr__('Add the video ID. Copy the numeric code that appears at the end of its URL at the top of your browser window.', 'dpr-adeline-extensions')

		)

	);

	vc_add_param(

			'vc_row_inner',array(

			'type' => 'checkbox',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('These options allow you to loop and mute the video set as the background', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Video Options', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_video_options',

			'value' => array(

					__('Loop','dpr-adeline-extensions') => 'loop',

					__('Muted','dpr-adeline-extensions') => 'muted',

				),

			'dependency' => array(

					'element' => 'dpr_bg_type',

					'value' => 'video',

				),		

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

	  )

	);

	vc_add_param(

		'vc_row_inner',array(

			'type' => 'number',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set video start time in seconds.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Video Start Time', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_video_start_time',

			'value' =>'',

			'min'=>'0',

			'step' => '1',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'edit_field_class' => 'vc_column vc_col-sm-3',

			'dependency' => array(

					'element' => 'dpr_video_type',

					'value' => 'youtube',

			),		

		)

	);

	vc_add_param(

		'vc_row_inner',array(

			'type' => 'number',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set video stop time in seconds', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Video Stop Time', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_video_stop_time',

			'value' =>'',

			'min'=>'0',

			'step' => '1',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'edit_field_class' => 'vc_column vc_col-sm-3',

			'dependency' => array(

					'element' => 'dpr_video_type',

					'value' => 'youtube',

			),		

		)

	);

	vc_add_param(

		'vc_row_inner', array(

			'type' => 'attach_image',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose placeholder image', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Placeholder Image', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_video_poster',

			'value' => '',

			'edit_field_class' => 'vc_column vc_col-sm-12',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'dependency' => array(

					'element' => 'dpr_bg_type',

					'value' => 'video',

			),

			'description' => esc_attr__('Placeholder image is displayed in case background video is restricted. (For example, on mobiles).', 'dpr-adeline-extensions')		

		)

	);

	vc_add_param(

		'vc_row_inner', array(

			'type' => 'dpr_title',

			'text' => esc_html__('Overlay Options', 'dpr-adeline-extensions'),

			'param_name' => 'overlay_title',

			'class' => '',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),			

		)

	);

	vc_add_param(

		'vc_row_inner', array(

			'type' => 'dpr_switcher',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('This option allows you to enable or disable the overlay for the row.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Enable overlay', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_enable_overlay',

			'edit_field_class' => 'vc_column vc_col-sm-6',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),			

			'value' => '',

			'options' => array(

				'yes' => array(

						'label' => '',

						'on' => 'Yes',

						'off' => 'No',

					),

				),

		)

	);

	vc_add_param(

		'vc_row_inner', array(

			'type' => 'dpr_radio',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Overlay Color Type', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_overlay_color_type',

			'value' => 'solid',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'dependency' => array(

					'element' => 'dpr_enable_overlay', 

					'value' => array('yes')

			),

			'options' => array(

				__('Solid Color', 'dpr-adeline-extensions') => 'solid',

				__('Gradient', 'dpr-adeline-extensions') => 'gradient'

			)

		)

	);

	vc_add_param(

			'vc_row_inner', array(

			'type' => 'colorpicker',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the color for the overlay.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Overlay Color', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_overlay_color',

			'value' => '',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),			

			'dependency' => array(

					'element' => 'dpr_overlay_color_type', 

					'value' => array('solid')

			),

		)

	);

	vc_add_param(

		'vc_row_inner', array(

				'type' => 'dpr_gradient_picker',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the gradient for the row overlay.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Overlay Gradient', 'dpr-adeline-extensions'),

				'param_name' => 'dpr_overlay_gradient',

				'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),			

				'value' => '-45;0%/rgba(104, 89, 222, 0.4);100%/rgba(240, 55, 116, 0.4)',

				'dependency' => array(

						'element' => 'dpr_overlay_color_type', 

						'value' => array('gradient')

				),

		)

	);

	vc_add_param(

		'vc_row_inner', array(

			'type' => 'dpr_image_select',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Chose pattern for overlay. Default pattern are black, light patterna are white.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Overlay Pattern', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_overlay_pattern',

			'dependency' => array(

					'element' => 'dpr_enable_overlay', 

					'value' => array('yes')

			),

			'value' => 'transparent',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'options'			=> array(

				'transparent'			=> array(

					'label'			=> esc_html__('None','dpr-adeline-extensions'),

					'src'				=> $module_images . 'row/no-pattern.png'

				),

				'p01'			=> array(

					'label'			=> 'P01',

					'src'				=> $module_images . 'row/p01.png'

				),

				'p02'			=> array(

					'label'			=> 'P02',

					'src'				=> $module_images . 'row/p02.png'

				),

				'p03'			=> array(

					'label'			=> 'P03',

					'src'				=> $module_images . 'row/p03.png'

				),

				'p04'			=> array(

					'label'			=> 'P04',

					'src'				=> $module_images . 'row/p04.png'

				),

				'p05'			=> array(

					'label'			=> 'P05',

					'src'				=> $module_images . 'row/p05.png'

				),

				'p06'			=> array(

					'label'			=> 'P06',

					'src'				=> $module_images . 'row/p06.png'

				),

				'p07'			=> array(

					'label'			=> 'P07',

					'src'				=> $module_images . 'row/p07.png'

				),

				'p08'			=> array(

					'label'			=> 'P08',

					'src'				=> $module_images . 'row/p08.png'

				),

				'p09'			=> array(

					'label'			=> 'P09',

					'src'				=> $module_images . 'row/p09.png'

				),

				'p01-l'			=> array(

					'label'			=> 'P01 Light',

					'src'				=> $module_images . 'row/p01-l.png'

				),

				'p02-l'			=> array(

					'label'			=> 'P02 Light',

					'src'				=> $module_images . 'row/p02-l.png'

				),

				'p03-l'			=> array(

					'label'			=> 'P03 Light',

					'src'				=> $module_images . 'row/p03-l.png'

				),

				'p04-l'			=> array(

					'label'			=> 'P04 Light',

					'src'				=> $module_images . 'row/p04-l.png'

				),

				'p05-l'			=> array(

					'label'			=> 'P05 Light',

					'src'				=> $module_images . 'row/p05-l.png'

				),

				'p06-l'			=> array(

					'label'			=> 'P06 Light',

					'src'				=> $module_images . 'row/p06-l.png'

				),

				'p07-l'			=> array(

					'label'			=> 'P07 Light',

					'src'				=> $module_images . 'row/p07-l.png'

				),

				'p08-l'			=> array(

					'label'			=> 'P08 Light',

					'src'				=> $module_images . 'row/p08-l.png'

				),

				'p09-l'			=> array(

					'label'			=> 'P09 Light',

					'src'				=> $module_images . 'row/p09-l.png'

				),

				'custom'			=> array(

					'label'			=> 'Custom',

					'src'				=> $module_images . 'row/custom-pattern.png'

				),

			),

		)

	);

	vc_add_param(

		'vc_row_inner',array(

			'type' => 'textarea',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enter custom pattern style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom Pattern Style', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_overlay_custom_pattern',

			'value' =>'',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'edit_field_class' => 'vc_column vc_col-sm-12',

			'dependency' => array(

					'element' => 'dpr_overlay_pattern', 

					'value' => array('custom')

			),

			'description' => esc_attr__('Enter in this field any valid CSS code for custom pattern (For example, custom svg pattern).', 'dpr-adeline-extensions')		

		)

	);

	vc_add_param(

		'vc_row_inner',array(

			'type' => 'number',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set pattern opacity. Enter value between 0 to 100 (0 is transparent) ', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Pattern Opacity', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_overlay_pattern_opacity',

			'value' =>'100',

			'min'=>'0',

			'max' => '100',

			'step' => '1',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'edit_field_class' => 'vc_column vc_col-sm-3',

			'dependency' => array(

					'element' => 'dpr_enable_overlay', 

					'value' => array('yes')

			),

		)

	);



/* Responsive Options stuff */	

	vc_add_param(

		'vc_row_inner', array(

			'type' => 'dpr_switcher',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('This option allows you to add custom paddings, margins and border for different devices.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Responsive Custom CSS', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_enable_responsive_options',

			'edit_field_class' => 'vc_column vc_col-sm-6',

			'group' => esc_html__('DP Responsive Options', 'dpr-adeline-extensions'),			

			'value' => '',

			'options' => array(

				'yes' => array(

						'label' => '',

						'on' => 'Yes',

						'off' => 'No',

					),

				),

		)

	);

	vc_add_param(

		'vc_row_inner',array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Hide this row on certain devices', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Hide on devices', 'dpr-adeline-extensions'),

				'param_name' => 'hide_on',

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'value' => array(

						__('Desktop','dpr-adeline-extensions') => 'lg',

						__('Small Desktop','dpr-adeline-extensions') => 'md',

						__('Tablet','dpr-adeline-extensions') => 'sm',

						__('Mobile','dpr-adeline-extensions') => 'xs'

					),

				'group'				=> esc_html__('DP Responsive Options', 'dpr-adeline-extensions'),

				'dependency' => array(

					'element' => 'dpr_enable_responsive_options', 

					'value' => array('yes')

				),
	  		
	  		)
	);

	vc_add_param(

		'vc_row_inner', array(

			'type'				=> 'dpr_responsive_css',

			'heading'			=> esc_html__('Resposive settings', 'dpr-adeline-extensions'),

			'param_name'		=> 'responsive_css_panel',

			'group'				=> esc_html__('DP Responsive Options', 'dpr-adeline-extensions'),

			'dependency' => array(

					'element' => 'dpr_enable_responsive_options', 

					'value' => array('yes')

			),

		)

	);

