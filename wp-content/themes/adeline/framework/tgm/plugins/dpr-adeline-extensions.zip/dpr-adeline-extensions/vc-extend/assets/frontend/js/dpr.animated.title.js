var $j = jQuery.noConflict();

$j( document ).on( 'ready', function() {
	"use strict";
	// Custom select
	dprInitializeAnimatedTitle();
} );

/* ==============================================
ANIMATED TITLE
============================================== */
function dprInitializeAnimatedTitle() {
	"use strict"
			$j('.dpr-animated-title').each(function () {
				var $self =  $j(this);
				$j(this).on('on-in-viewport', function () {
					if (!$self.hasClass('animated')){
					$self.addClass('animated');
					}
				});
				}
			);
}