<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
/*
Tiny Post Style Blog Grid Shortcode Item
*/

// Add images size if blog grid
if ( isset($entry_img_size) && !empty($entry_img_size) ) {
	$size = $entry_img_size;
} else {
	$size = 'full';
}
// Image args
$img_args = array(
    'alt' => get_the_title(),
);
if ( adeline_get_schema_markup( 'image' ) ) {
	$img_args['itemprop'] = 'image';
} ?>
<div class="<?php echo esc_attr($image_position) ?>">
<div class="thumbnail">
	<a href="<?php the_permalink(); ?>" class="thumbnail-link">
		<?php
		// Image width
		$img_width  = $entry_img_width;
		$img_height = $entry_img_height;

		if ( ! has_post_thumbnail() ) { 
			if ($entry_img_size == 'custom') { 
			?>
            <img src="<?php echo adeline_no_image_url(); ?>" style="width:<?php echo $img_width ?>px;height:auto;"alt="<?php the_title_attribute(); ?>"/>
			<?php } else { ?>
			<img src="<?php echo adeline_no_image_url(); ?>" alt="<?php the_title_attribute(); ?>"/>
			<?php } 
		} else {
    	// Images attr
		$img_id 	= get_post_thumbnail_id( get_the_ID(), $size );
		$img_url 	= dpr_get_attachment_image_src( $img_id, $size);
		
		if ( function_exists( 'adeline_image_attributes' ) ) {
			$img_atts = adeline_image_attributes( $img_url[1], $img_url[2], $img_width, $img_height );
		}

		// If DPR Adeline Extensions is active and has a custom size
		if ( function_exists( 'adeline_resize' )
			&& ! empty( $img_atts ) ) {	
			?>
			<img src="<?php echo adeline_resize( $img_url[0], $img_atts[ 'width' ], $img_atts[ 'height' ], $img_atts[ 'crop' ], true, $img_atts[ 'upscale' ] ); ?>" alt="<?php the_title_attribute(); ?>" width="<?php echo esc_attr( $img_width ); ?>" height="<?php echo esc_attr( $img_height ); ?>"<?php adeline_schema_markup( 'image' ); ?> />
		<?php
		} else {
			// Display post thumbnail
			the_post_thumbnail( $size, $img_args );

		} } ?>

	</a>
</div>
<div class="entry-content">
<header class="blog-item-header clr">
	<h2 class="blog-item-title entry-title" <?php echo $title_typo_style ?>>
		<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" rel="bookmark"><?php the_title(); ?></a>
	</h2><!-- blog-item-title -->
</header><!-- blog-item-header -->
<?php 
    // Get meta sections
    $sections = explode(',', $meta_included);
    // Return if sections are empty
    if ( empty( $sections ) ) {
        return;
    }
    
    if ( 'post' == get_post_type() ) { ?>
    
    
        <ul class="meta clr ">
    
            <?php
            // Loop through meta sections
            foreach ( $sections as $section ) { ?>
    
                <?php if ( 'author' == $section ) { ?>
                    <li class="meta-author"<?php adeline_schema_markup( 'author_name' ); ?>><?php echo the_author_posts_link(); ?></li>
                <?php } ?>
    
                <?php if ( 'date' == $section ) { ?>
                    <li class="meta-date"<?php adeline_schema_markup( 'publish_date' ); ?>><?php echo get_the_date(); ?></li>
                <?php } ?>
    
                <?php if ( 'category' == $section ) { ?>
                    <li class="meta-cat"><?php the_category( ' , ', get_the_ID() ); ?></li>
                <?php } ?>
    
                <?php if ( 'comments' == $section && comments_open() && ! post_password_required() ) { ?>
                    <li class="meta-comments"><?php comments_popup_link( esc_html__( '0 Comments', 'dpr-adeline-extensions' ), esc_html__( '1 Comment',  'dpr-adeline-extensions' ), esc_html__( '% Comments', 'dpr-adeline-extensions' ), 'comments-link' ); ?></li>
                <?php } ?>
    
            <?php } ?> 
            
        </ul>
    
        
    <?php } ?>
	<?php  if ( $display_excerpt == 'yes') {
		?>
        <p <?php echo $content_typo_style ?>> 
        <?php  adeline_excerpt( absint(  $excerpt_length  ) ); ?>
        </p>
	<?php }?>
</div>
</div>