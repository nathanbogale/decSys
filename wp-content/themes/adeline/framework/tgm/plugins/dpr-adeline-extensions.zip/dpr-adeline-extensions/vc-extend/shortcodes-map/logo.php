<?php

// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}

/*

* Add-on Name: Countdown

*/



class WPBakeryShortCode_DPR_Logo extends WPBakeryShortCode {}



vc_map(

	array(

		'name'					=> esc_html__(' DP Logo', 'dpr-adeline-extensions'),

		'base'					=> 'dpr_logo',

		'class'					=> 'dpr_logo',

		'icon'					=> 'icon-dpr-logo',

  		"category" =>array( esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions'),esc_attr__('Header Builder', 'dpr-adeline-extensions'),),

		'description'			=> esc_html__('Display Theme Logo ', 'dpr-adeline-extensions'),

		'params'				=> array(

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Inherit with theme options or custom image.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Logo Type', 'dpr-adeline-extensions'),

				'param_name'		=> 'logo_type',

				'value'				=> 'inherit',

				'edit_field_class'	=> 'vc_column vc_col-sm-12  ',

				'options'			=> array(

					esc_html__('Inherit', 'dpr-adeline-extensions')	=> 'inherit',

					esc_html__('Custom Image', 'dpr-adeline-extensions')	=> 'custom'

				)

			),

			array(

				'type'				=> 'attach_image',

				'param_name'		=> 'image',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select image from media library', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Image', 'dpr-adeline-extensions'),

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'dependency'		=> array('element' => 'logo_type', 'value' => array('custom'))

			),

			array(

				'type' => 'number',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select the width for the image', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Image width', 'dpr-adeline-extensions'),

				'param_name' => 'image_width',

				'suffix'	=> 'px',

				'value' => 200,

				'edit_field_class' => 'vc_column vc_col-sm-4',

				'dependency'		=> array('element' => 'logo_type', 'value' => array('custom'))

			),

			array(

				'type' 				=> 'number',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select the height for the image', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Image height', 'dpr-adeline-extensions'),

				'param_name'		=> 'image_height',

				'suffix'			=> 'px',

				'value' 			=> 60,

				'edit_field_class' 	=> 'vc_column vc_col-sm-4',

				'dependency'		=> array('element' => 'logo_type', 'value' => array('custom'))

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set logo alignment in column.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Logo Alignment', 'dpr-adeline-extensions'),

				'param_name'		=> 'logo_alignment',

				'value'				=> 'left',

				'edit_field_class'	=> 'vc_column vc_col-sm-12  ',

				'options'			=> array(

					esc_html__('Left', 'dpr-adeline-extensions')	=> 'left',

					esc_html__('Center', 'dpr-adeline-extensions')	=> 'center',

					esc_html__('Right', 'dpr-adeline-extensions')	=> 'right',

				)

			),

		

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Additional Settings', 'dpr-adeline-extensions' ),

				'param_name'       => 'extra_features_title',

				'edit_field_class' => 'vc_column vc_col-sm-12',

			),

		   vc_map_add_css_animation( false ),

		    array(

				'type' => 'textfield',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Extra Class Name', 'dpr-adeline-extensions'),

				'param_name' => 'el_class',

			),







			array(

				'type' => 'css_editor',

				'heading' => __( 'CSS box', 'dpr-adeline-extensions' ),

				'param_name' => 'css',

				'group' => __( 'Design Options', 'dpr-adeline-extensions' ),

			),



		)

	)

);