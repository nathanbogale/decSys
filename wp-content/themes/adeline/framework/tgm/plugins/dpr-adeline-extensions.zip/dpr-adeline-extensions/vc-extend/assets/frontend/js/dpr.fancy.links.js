    Number.prototype.map = function(in_min, in_max, out_min, out_max) {
        return ((this - in_min) * (out_max - out_min)) / (in_max - in_min) + out_min
      }

    Number.prototype.between = function(a, b, inclusive) {
      var min = Math.min(a, b),
        max = Math.max(a, b);

      return inclusive ? this >= min && this <= max : this > min && this < max;
    }

var $j = jQuery.noConflict();



$j( document ).on( 'ready', function() {

    "use strict";


    dprInitializeFancyLinks();

} );



/* ==============================================
FANCY LINKS

============================================== */

function dprInitializeFancyLinks() {

   
    "use strict"

            $j('.dpr-fancy-links').each(function () {
            
                var $self =  $j(this),
                    $ID = $self.attr('id'),
                    $ID1 = $self.find('.dpr-fancylinks-content-wrapper').attr('id'),
                    $effect = $self.attr('data-effect'),
                    $strength = 0.25;

                    if ($self.attr('data-strength')) {
                      $strength = $self.attr('data-strength');
                    } 

                    const container = document.querySelector('#'+$ID)
                    const itemsWrapper = document.querySelector('#'+$ID1)
                    if($effect == 'rgb-shift') {
                      const effect = new RGBShiftEffect(container, itemsWrapper, { strength: $strength })
                    } else if ($effect == 'trails') {
                      const effect = new TrailsEffect(container, itemsWrapper)
                    } else if ($effect == 'stretch') {
                      const effect = new StretchEffect(container, itemsWrapper)
                    }

                }

            );

}


    //const container = document.querySelector('.dpr-fancy-links')
    //const itemsWrapper = document.querySelector('.dpr-fancylinks-content-wrapper')


    //const effect = new RGBShiftEffect(container, itemsWrapper, { strength: 0.50 })

    







