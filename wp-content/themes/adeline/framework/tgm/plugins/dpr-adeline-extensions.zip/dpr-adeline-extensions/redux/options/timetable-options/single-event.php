<?php



/**



 * Timetable Options -> Single Event Layout



 * 



 */







	Redux::setSection( $opt_name, array(



		'title' => esc_html__('Single Event Layout', 'dpr-adeline-extensions'),



		'id' => 'mp_event_layout',



		'subsection' => true,



		'fields' => array(



						array (



							'id' => 'mp_event_single_layout',



							'type' => 'image_select',



							'title' => __('General Layout', 'dpr-adeline-extensions'),



							'options' => array (



								'right-sidebar' => array (



									'title' => esc_html__('Sidebar right', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/sidebar_right.png'



								),					



								'left-sidebar' => array (



									'title' => esc_html__('Sidebar left', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/sidebar_left.png'



								),



								'both-sidebars' => array (



									'title' => esc_html__('Both sidebars', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/sidebar_both.png'



								),



	



								'full-width' => array (



									'title' => esc_html__('Full width', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/sidebar_disabled.png',	



								),



								'full-screen' => array (



									'title' => esc_html__('Full screen', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/full_screen.png',	



								),



							),



							'default' => 'right-sidebar',



							'hint' => array (



								'title' => esc_attr__('Single Event Layout', 'dpr-adeline-extensions'),



								'content' => esc_attr__('Choose default single event layoyt eg sidebar position.', 'dpr-adeline-extensions')



							)



						),



						array (



							'id' => 'mp_event_single_both_sidebars_column_order',



							'type' => 'image_select',



							'title' => __('Both Sidebars: Column Order', 'dpr-adeline-extensions'),



							'options' => array (



								'order-scs' => array (



									'title' => esc_html__('Sidebar/Content/Sidebar', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/scs.png'



								),					



								'order-ssc' => array (



									'title' => esc_html__('Sidebar/Sidebar/Content', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/ssc.png'



								),



								'order-css' => array (



									'title' => esc_html__('Content/Sidebar/Sidebar', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/css.png'



								),



							),



							'default' => 'order-scs',



							'hint' => array (



								'title' => esc_attr__('Both Sidebars: Column Order', 'dpr-adeline-extensions'),



								'content' => esc_attr__('Choose default column order. This general settings can be overwriten for specific pages.', 'dpr-adeline-extensions')



							),



							'required' => array('mp_event_single_layout','equals','both-sidebars')



						),



					array(         



						'id'       => 'timeslot_bg',



						'type'     => 'color',



						'title'    => __('Timeslot Background ', 'dpr-adeline-extensions'),



						'default'  => '#e5e5e9',



						'output'  => array( 'background-color' =>'.timeslots .timeslot'),



						'hint' => array(



							'title'   => esc_attr__('Timeslot Background','dpr-adeline-extensions'),



							'content' =>  esc_attr__('Set background color for timeslots displayed on single event page.','dpr-adeline-extensions')



						)



					),



						array(



							'id'   => 'mp_event_subheader_info',



							'type' => 'info',



							'style' => 'dpr-title',



							'title' => wp_kses_post(__('<h3>Subheader</h3>', 'dpr-adeline-extensions')),



						),



					array(



						'id'       => 'mp_event_subheader_height',



						'type'     => 'dimensions',



						'units'    => array('px'),



						'mode' => array ('width' => 'width', 'height' => 'height'),



						'width' => false,



						'output' => array('.single-mp-event .subheader, .single-mp-column .subheader'),



						'title'    => __('Subheader Height', 'dpr-adeline-extensions'),



						'default'  => array(



							'Height'  => '230px'



						),



						'hint' => array(



							'title'   => esc_attr__('Subheader Height','dpr-adeline-extensions'),



							'content' =>  esc_attr__('You can set subheader height  on woo pages.','dpr-adeline-extensions')



						)



					),



					array(



						'id'             => 'mp_event_subheader_padding',



						'type'           => 'spacing',



						'output'         => array('.single-mp-event .subheader, .single-mp-column .subheader'),



						'mode'           => 'padding',



						'units'          => array('px','em'),



						'left' => false,



						'right' => false,



						'display_units' => true,



						'units_extended' => false,



						'title'          => __('Vertical Padding', 'dpr-adeline-extensions'),



						'default'            => array(



							'padding-top'     => '0px', 



							'padding-bottom'  => '0px', 



							'units'          => 'px', 



							),



						'hint' => array(



							'title'   => esc_attr__('Vertical Padding','dpr-adeline-extensions'),



							'content' =>  esc_attr__('Using padding you can adjust vertical position of title in subheader area  on woo pages','dpr-adeline-extensions')



						)



					),



					array(         



						'id'       => 'mp_event_subheader_bg',



						'type'     => 'background',



						'title'    => __('Background', 'dpr-adeline-extensions'),



						'default'  => array(



							'background-color' => '#292933',



						),



						'output'         => array('.single-mp-event .subheader, .single-mp-column .subheader'),



						'hint' => array(



							'title'   => esc_attr__('Background','dpr-adeline-extensions'),



							'content' =>  esc_attr__('Set background for subheader area subheader area on woo pages','dpr-adeline-extensions')



						)



					),



					array(



						'id'       => 'mp_event_subheader_overlay',



						'type'     => 'switch',



						'default' => false,



						'title'    =>  esc_html__('Use Subheader Overlay','dpr-adeline-extensions'),



						'hint' => array(



							'title'   => esc_attr__('Use Subheader Overlay','dpr-adeline-extensions'),



							'content' =>  esc_attr__('Enable overlay layer over subheader background on woo pages.','dpr-adeline-extensions')



						)



					),



					array(         



						'id'       => 'mp_event_subheader_overlay_bg_color',



						'type'     => 'color',



						'title'    => __('Overlay Color', 'dpr-adeline-extensions'),



						'default'  => 'rgba(0,0,0,.5)',



						'output' => array('background-color' => '.single-mp-event .subheader-overlay, .single-mp-column .subheader-overlay'),



						'hint' => array(



							'title'   => esc_attr__('Overlay Color','dpr-adeline-extensions'),



							'content' =>  esc_attr__('Set background color for subheader overlay on woo pages.','dpr-adeline-extensions')



						),



						'required' => array('mp_event_subheader_overlay','equals','1')



					),



					array(         



						'id'       => 'mp_event_subheader_title_color',



						'type'     => 'color',



						'title'    => __('Title Color', 'dpr-adeline-extensions'),



						'default'  => '#ffffff',



						'output' => array('.single-mp-event .subheader-title, .single-mp-column .subheader-title'),



						'hint' => array(



							'title'   => esc_attr__('Title Color','dpr-adeline-extensions'),



							'content' =>  esc_attr__('Set title color on woo pages.','dpr-adeline-extensions')



						)



					),



					array(         



						'id'       => 'mp_event_subheader_subtitle_color',



						'type'     => 'color',



						'title'    => __('Subtitle Color', 'dpr-adeline-extensions'),



						'default'  => 'rgba(255,255,255,0.8)',



						'output' => array('.single-mp-event .subheader-subtitle, .single-mp-column .subheader-subtitle'),



						'hint' => array(



							'title'   => esc_attr__('Subtitle Color','dpr-adeline-extensions'),



							'content' =>  esc_attr__('Set subtitle color on woo pages.','dpr-adeline-extensions')



						)



					),



		)



	));



