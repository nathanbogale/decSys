<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$output = $unique_id = $content_position  = $css_animation = $css = $el_class = $custom_el_css  = '';
$image  = $image_width = $image_height= $title = $subtitle = $subtitle_pos = $info = $link = '';
$title_color = $subtitle_color =  $info_color = $info_bg = $info_border_radius = $use_hover_mask = $mask_type = $mask_color = $mask_gradient = $title_color_hover = $subtitle_color_hover = $shadow = $shadow_custom = $shadow_hover = $shadow_custom_hover = $hover_animation = $animate_img_on_hover = '';
$title_font_size = $title_line_height  = $title_letter_spacing = $title_font_style = $title_google_font = $title_typo_style = '';
$price_font_size = $price_line_height  = $price_letter_spacing = $price_font_style = $price_google_font = $price_typo_style =  '';
$info_font_size = $info_line_height  = $info_letter_spacing = $info_font_style = $info_google_font = $info_typo_style =  '';

$image_html = $title_html = $subtitle_html = $info_badge_html = '';

$atts = vc_map_get_attributes( 'dpr_ads_banner', $atts );
extract( $atts );

if (isset($hover_animation) && ($hover_animation == 'dpr-image-tilt' || $hover_animation == 'dpr-item-tilt')) {
    wp_enqueue_script('jquery-tilt', DPR_EXTENSIONS_PLUGIN_URL . 'vc-extend/assets/frontend/js/universal-tilt.min.js', array('jquery'), null, true);
    wp_enqueue_script('dpr-portfolio-scat-grid-hover-animations', DPR_EXTENSIONS_PLUGIN_URL . 'vc-extend/assets/frontend/js/dpr.scat.grid.anim.js', array('jquery'), null, true);
}
$unique_id = uniqid('dpr-ads-banner-').'-'.rand(1,9999);

/* CSS Classes and styles */
if ( '' !== $css_animation && 'none' !== $css_animation ) {
	dpr_enqueue_waypoint_js();
	dpr_enqueue_animate_css();
	$el_class .= ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
}

/* Output */
$css_classes = array(
	'dpr-ads-banner',
	$unique_id,
	$el_class,
	vc_shortcode_custom_css_class( $css ),
);

if(isset($content_position) && $content_position != '' ) {
	$css_classes[] = 'content-'.$content_position;
}
if ( 'custom' != $shadow && '' != $shadow ) $css_classes[] = 'dpr-shadow-'.$shadow;
if ( 'custom' != $shadow_hover && '' != $shadow_hover ) $css_classes[] = 'dpr-shadow-onhover-'.$shadow_hover;
if ( 'none' != $hover_animation && '' != $hover_animation ) $css_classes[] = $hover_animation;
if ( '' != $info ) $css_classes[] = 'info-enabled';
if ( 'yes' == $use_hover_mask ) $css_classes[] = 'mask-enabled';
if ( 'yes' == $animate_img_on_hover) $css_classes[] = 'image-animated';
if ( isset($subtitle_pos) && $subtitle_pos != '') $css_classes[] = 'title-'.$subtitle_pos;

$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->settings['base'], $atts ) );


// Custom CSS stuff
$title_typo_style = dpr_generate_typography_style('', $title_font_size, $title_line_height, $title_letter_spacing, $title_font_style,$title_google_font);

$subtitle_typo_style = dpr_generate_typography_style('', $subtitle_font_size, $subtitle_line_height, $subtitle_letter_spacing, $subtitle_font_style, $subtitle_google_font);

$info_typo_style = dpr_generate_typography_style('', $info_font_size, $info_line_height, $info_letter_spacing, $info_font_style, $info_google_font);

if ($shadow == 'custom' && dpr_shadow_param_to_css($shadow_custom) != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' {'.dpr_shadow_param_to_css($shadow_custom).'}';
}
if ($shadow_hover == 'custom' && dpr_shadow_param_to_css($shadow_custom_hover) != '') {
	$custom_el_css .= '.'.esc_js($unique_id).':hover {'.dpr_shadow_param_to_css($shadow_custom_hover).'}';
}

if(isset($title_color) && $title_color != '') {
	$custom_el_css .= '.'.esc_js($unique_id).'  h4.banner-title, .'.esc_js($unique_id).'  h4.banner-title a  {color:'.$title_color.' !important;}';
}
if(isset($title_color_hover) && $title_color_hover != '') {
	$custom_el_css .= '.'.esc_js($unique_id).'.mask-enabled .banner-inner:hover  h4.banner-title, .'.esc_js($unique_id).':hover  h4.banner-title a  {color:'.$title_color_hover.' !important;}';
}
if(isset($subtitle_color) && $subtitle_color != '') {
	$custom_el_css .= '.'.esc_js($unique_id).'  .banner-inner .banner-subtitle {color:'.$subtitle_color.' !important;}';
}
if(isset($subtitle_color_hover) && $subtitle_color_hover != '') {
	$custom_el_css .= '.'.esc_js($unique_id).'.mask-enabled  .banner-inner:hover .banner-subtitle {color:'.$subtitle_color_hover.' !important;}';
}

if(isset($info_bg) && $info_bg != '') {
	$custom_el_css .= '.'.esc_js($unique_id).'  .info {background-color:'.$info_bg.';}';
}
if(isset($info_border_radius) && $info_border_radius != '') {
	$custom_el_css .= '.'.esc_js($unique_id).'  .info {border-radius:'.$info_border_radius.'px;}';
}
if(isset($mask_color) && $mask_color != '' && $mask_type == 'solid') {
	$custom_el_css .= '.'.esc_js($unique_id).' .banner-inner .image-wrap > a:before {background-color:'.$mask_color.'!important;}';
}
if(isset($mask_gradient) && $mask_gradient != '' && $mask_type == 'gradient') {
	$custom_el_css .= '.'.esc_js($unique_id).' .banner-inner .image-wrap > a:before {'.esc_js(adeline_gradientToBgCSS ($mask_gradient)).'}';
}
/*HTML Parts */
	/* Link */
		if(isset($link) ) {
			$link = vc_build_link($link);
			$link_target = !empty($link['target']) ? 'target="'.esc_attr(preg_replace('/\s+/', '', $link['target'])).'"' : '';
		}

		/* Image */
		$w = 600;
		$h = 600;
		if(isset($image_width) && $image_width != '') {
			$w = $image_width;
		}
		if(isset($image_height) && $image_height != '') {
			$h = $image_height;
		}
		
		if(isset($image) && $image != '') {
			$img_src = dpr_get_attachment_image_src($image, 'full');
			$img_atts = adeline_image_attributes( $img_src[1], $img_src[2], $w, $h );
			$alt_text = get_post_meta($image , '_wp_attachment_image_alt', true);
			$image_html = '<img src="'. adeline_resize( $img_src[0], $img_atts[ 'width' ], $img_atts[ 'height' ], $img_atts[ 'crop' ], true, $img_atts[ 'upscale' ] ).'" alt="'.esc_attr($alt_text).'" width="'. esc_attr( $w ).'" height="'. esc_attr( $h ).'"/>';
		} else {
				$image_html = '<img src="'. dpr_adeline_no_image_url().'" alt="" width="'. esc_attr( $w ).'/>';
		}

	/* Subtitle */
                if($subtitle != '') { 
                       $subtitle_html .= '<div class="banner-subtitle" '. $subtitle_typo_style.'>'.wp_kses_post($subtitle).'</div>';               
                }
	/* Title */
                if($title != '') { 
                       $title_html .= '<h4 class="banner-title" '. $title_typo_style.'>'.wp_kses_post($title).'</h4>';               
                }
	/* Info */
				if($info != '') { 
						$info_badge_html .= '<div class="info" '.$info_typo_style.'>'.esc_html($info).'</div>';
				}
?>


<div id="<?php echo esc_attr($unique_id) ?>" class="<?php echo esc_attr($css_class) ?>">
			<div class="banner-inner">
               <div class="content-wrap">
               		<?php if ($subtitle_pos == 'bellow') { 
						echo $title_html;
						echo $subtitle_html;
					} else {
						echo $subtitle_html;
						echo $title_html;
					}
					echo $info_badge_html; ?>
                </div>


            <div class="image-wrap clr">
            <a href="<?php echo esc_url($link['url']) ?>" <?php echo $link_target?> title="<?php echo esc_attr($link['title'])?>" rel="<?php echo esc_attr($link['rel'])?>"><?php echo wp_kses_post($image_html)?></a>
            </div>
		</div>
<?php
	if(!empty($custom_el_css)) {
		$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>");'
						. '})(jQuery);'
					. '</script>';
}



echo $output;
?>
</div>

