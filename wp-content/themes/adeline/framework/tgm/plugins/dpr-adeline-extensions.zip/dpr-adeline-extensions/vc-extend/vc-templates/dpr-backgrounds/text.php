<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
$css_anim_class = ' no-animation';
if($bg_text_animation ){
wp_enqueue_script('dpr-row-bg-text', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/dpr.row.bgtext.js', array('jquery'), null, false);	
wp_enqueue_script('dpr-waypoints', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/waypoints.min.js', array('jquery'), null, true);
$css_anim_class = ' with-animation';
}
$bg_wrap_data_atts = '';
$uniqid = uniqid('dpr-bg-wrapper-');
// Add Custom CSS
if(isset($bg_text) && !empty($bg_text)) {
$bg_text_typo_style = dpr_generate_typography_style($bg_text_color, $bg_text_font_size, $bg_text_line_height, $bg_text_letter_spacing, $bg_text_font_style,$bg_text_google_font);

if(isset($bg_text_padding_left) && !empty($bg_text_padding_left)) {
	$custom_el_css .= '#'.esc_attr($uniqid).' h1 {padding-left:'.$bg_text_padding_left.';}';
}
if(isset($bg_text_padding_right) && !empty($bg_text_padding_right)) {
	$custom_el_css .= '#'.esc_attr($uniqid).' h1 {padding-right:'.$bg_text_padding_right.';}';
}
if(isset($bg_text_padding_top) && !empty($bg_text_padding_top)) {
	$custom_el_css .= '#'.esc_attr($uniqid).' h1 {padding-top:'.$bg_text_padding_top.';}';
}
if(isset($bg_text_padding_bottom) && !empty($bg_text_padding_bottom)) {
	$custom_el_css .= '#'.esc_attr($uniqid).' h1 {padding-bottom:'.$bg_text_padding_bottom.';}';
}

}
// Add responsive CSS
$responsive_unique_class_1 = uniqid('bg-text-responsive-');
if($use_bg_text_responsive_typo && isset($bg_text_reaponsive_typography) && $bg_text_reaponsive_typography != '') {
	
	$custom_el_css .= DPR_Resposive_Typography_Param::generate_css($bg_text_reaponsive_typography,'.'.$responsive_unique_class_1);
}

$output .= '<div class="dpr_row_bg_container '.esc_attr($bg_text_width).'-width valign-'.esc_attr($bg_text_vpos).' halign-'.$bg_text_hpos.'">';

	$output .= $overlay_output;

		if (isset($bg_text_width) && $bg_text_width == 'grid') {
		$output .= '<div class="container">';
		$output .= '<div class="container-inner">';
		}
		$output .= '<div id="'.esc_attr($uniqid).'" class="dpr_row_bg_container_inner dpr_row_bg_text'.$css_anim_class.'" '.$bg_wrap_data_atts.'>';
		$output .= '<h1 class="'.$responsive_unique_class_1.' call-on-in-viewport" ' . $bg_text_typo_style . '>'.wp_kses_post($bg_text).'</h1>';
		if (isset($bg_text_width) && $bg_text_width == 'grid') {
		$output .= '</div>';
		$output .= '</div>';
		}
		$output .= '</div>';
	
	
$output .= '</div>';

