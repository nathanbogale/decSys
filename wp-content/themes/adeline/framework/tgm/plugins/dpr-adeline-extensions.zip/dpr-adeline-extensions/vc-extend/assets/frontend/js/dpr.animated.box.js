

( function ( $ ) {	

	'use strict';

	$(document).ready(function(){

		dpr_animateParalax();

	});

} ( jQuery ) );

function dpr_animateParalax() {

	if(jQuery('body').find('.magic-scroll').length>0){

  var controller = new ScrollMagic.Controller();

  jQuery('.magic-scroll').each(function(index, elem){

    var tween = 'tween-'+index;

    tween = new TimelineMax();

    var lengthBox = jQuery(elem).find('.parallax-scroll').length;

    for(var i=0; i < lengthBox; i++){

        var speed = 0.5;

		var scroll_type=jQuery(elem).find('.parallax-scroll').data("scroll_type");

		var scale_scroll=jQuery(elem).find('.parallax-scroll').data("scale_scroll");

		var scroll_x=jQuery(elem).find('.parallax-scroll').data("scroll_x");

		var scroll_y=jQuery(elem).find('.parallax-scroll').data("scroll_y");

        var j1 = 0.2*(i+1);

        var k1 = 0.5*i;

		if(scroll_type=='position'){

			if(i==0) {

			  tween.to(jQuery(elem).find('.parallax-scroll:eq('+i+')'), 1, {x:-(scroll_x*speed),y:-(scroll_y*speed), ease: Linear.easeNone})

			}else {

			  tween.to(jQuery(elem).find('.parallax-scroll:eq('+i+')'), 1, {y:-(scroll_y*speed), ease: Linear.easeNone}, '-=1')

			}

		}

    }

	var lengthBox = jQuery(elem).find('.scale-scroll').length;

	  for(var i=0; i < lengthBox; i++){

        var speed = 0.5;

		var scroll_type=jQuery(elem).find('.scale-scroll').data("scroll_type");

		var scale_scroll=jQuery(elem).find('.scale-scroll').data("scale_scroll");

		

		if(scroll_type=='scale'){

			  tween.to(jQuery(elem).find('.scale-scroll:eq('+i+')'), 1, {scale:scale_scroll,opacity:1, ease: Linear.easeNone})

		}

    }

	

	var lengthBox = jQuery(elem).find('.both-scroll').length;

	  for(var i=0; i < lengthBox; i++){

        var speed = 0.5;

		var scroll_type=jQuery(elem).find('.both-scroll').data("scroll_type");

		var scale_scroll=jQuery(elem).find('.both-scroll').data("scale_scroll");

		var scroll_x=jQuery(elem).find('.both-scroll').data("scroll_x");

		var scroll_y=jQuery(elem).find('.both-scroll').data("scroll_y");

		if(scroll_type=='both'){

			  tween.to(jQuery(elem).find('.both-scroll:eq('+i+')'), 1, {scale:scale_scroll,x:-(scroll_x*speed),y:-(scroll_y*speed),opacity:1, ease: Linear.easeNone})

		}

    }

    new ScrollMagic.Scene({triggerElement: elem, duration: jQuery(this).outerHeight(), triggerHook:.7})

    .setTween(tween)

    .addTo(controller);

  })

	}

}



/*---- Mouse move parallax -----*/

( function ( $ ) {	

	'use strict';

	$(document).ready(function(){

				var $parallaxContainer 	  = $(".dpr-move-parallax");

				var $parallaxItems		    = $parallaxContainer.find(".parallax-move");

				var fixer  = 0.0008;

				

				$(".dpr-move-parallax").on("mouseleave", function(event){

					var pageX =  event.pageX - ($(this).width() * 0.5);

					var pageY =  event.pageY - ($(this).height() * 0.5);

					$(this).find(".parallax-move").each(function(){

						var item 	= $(this);

						var speedX	= item.data("move_speed_x");  				

						var speedY	= item.data("move_speed_y");

						TweenLite.to(item,0.9,{

							x: (0)*fixer,

							y: (0)*fixer

						});

					});

				});



				$parallaxContainer.on('mousemove', function(e){

					$(this).find(".parallax-move").each(function(){

						var item 	= $(this);

						var speedX	= item.data("move_speed_x");

						var speedY	= item.data("move_speed_y");

					   $(this).parallax(speedX,speedY, e);

					});

				 });

			});

} ( jQuery ) );



(function ( $ ) { 

'use strict';

$.fn.parallax = function (resistancex, resistancey, mouse ) {

	var $el = $( this );

	TweenLite.to( $el, 0.5, {

		x : -(( mouse.clientX - (window.innerWidth/2) ) / resistancex),

		y : -(( mouse.clientY - (window.innerHeight/2) ) / resistancey)

	});

};

} ( jQuery ) );



/*-------- Hover 3D animation --------*/



( function ( $ ) {	

	'use strict';

	$(window).load(function () {

			$(".hover-tilt").hover3d({

                selector: ".dpr-animation-box",

                shine: !1,

				perspective: 2e3,

                invert: !0,

				sensitivity: 35,

            });

	});

	

} ( jQuery ) );	

