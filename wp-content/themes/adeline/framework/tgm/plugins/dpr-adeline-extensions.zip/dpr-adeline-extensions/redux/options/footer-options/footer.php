<?php

/**



 * Footer Options -> Footer Widgets



 *



 */

Redux::setSection($opt_name, array(

    'title'      => esc_html__('Footer Widgets', 'dpr-adeline-extensions'),

    'id'         => 'footer_widgets',

    'subsection' => true,

    'fields'     => array(

        array(

            'id'      => 'footer_content',

            'type'    => 'radio',

            'title'   => __('Footer Content', 'dpr-adeline-extensions'),

            'options' => array(

                'widgets'  => 'Footer Widgets',

                'custom'   => 'Custom Template',

                'disabled' => 'Disable Footer',

            ),

            'default' => 'widgets',

            'hint'    => array(

                'title'   => esc_attr__('Footer Content', 'dpr-adeline-extensions'),

                'content' => esc_attr__('You can use widgets from footer widgets areas  or select custom footer template created in menu Particles', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'footer_visibility',

            'type'     => 'image_select',

            'title'    => __('Visibility', 'dpr-adeline-extensions'),

            'options'  => array(

                'all-devices'        => array(

                    'title' => esc_html__('All Devices', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/visibility/all.png',

                ),

                'hide-tablet'        => array(

                    'title' => esc_html__('Hide On Tablet', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/visibility/no_tablet.png',

                ),

                'hide-mobile'        => array(

                    'title' => esc_html__('Hide On Mobile', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/visibility/no_mobile.png',

                ),

                'hide-tablet-mobile' => array(

                    'title' => esc_html__('Hide On Tablet & Mobile', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/visibility/no_tablet_mobile.png',

                ),

            ),

            'default'  => 'all-devices',

            'hint'     => array(

                'title'   => esc_attr__('Visibility', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enable or disable display footer area on certain devices.', 'dpr-adeline-extensions'),

            ),

            'required' => array('footer_content', 'not', 'disabled'),

        ),

        array(

            'id'       => 'footer_paralax',

            'type'     => 'switch',

            'default'  => false,

            'title'    => esc_html__('Footer Parallax Effect', 'dpr-adeline-extensions'),

            'required' => array('footer_content', 'not', 'disabled'),

            'hint'     => array(

                'title'   => esc_attr__('Footer Parallax Effect', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enable or disable footer parallax effect', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'footer_fix_at_bottom',

            'type'     => 'switch',

            'default'  => false,

            'title'    => esc_html__('Footer Allways Bottom', 'dpr-adeline-extensions'),

            'required' => array('footer_content', 'not', 'disabled'),

            'hint'     => array(

                'title'   => esc_attr__('Footer Allways Bottom', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enabling this option fix footer on boottom even when page height is lower then screen height.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'force_full_width_footer',

            'type'     => 'switch',

            'default'  => false,

            'title'    => esc_html__('Force Full Width Footer', 'dpr-adeline-extensions'),

            'required' => array('footer_content', 'not', 'disabled'),

            'hint'     => array(

                'title'   => esc_attr__('Force Full Width Footer', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Force full width footer container .', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'footer_particle_selected',

            'type'     => 'select',

            'data'     => 'posts',

            'args'     => array('post_type' => array('dpr_particle'), 'posts_per_page' => -1),

            'title'    => esc_html__('Custom Footer Template', 'dpr-adeline-extensions'),

            'desc'     => __('Please note that you need first create custom template in Particles menu'),

            'hint'     => array(

                'title'   => esc_attr__('Footer Template', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Create custom footer template first.', 'dpr-adeline-extensions'),

            ),

            'required' => array('footer_content', 'equals', 'custom'),

        ),

        array(

            'id'       => 'footer_columns',

            'type'     => 'radio',

            'title'    => __('Footer Columns Count', 'dpr-adeline-extensions'),

            'required' => array('footer_content', 'equals', 'widgets'),

            'options'  => array(

                '1' => '1 Column',

                '2' => '2 Columns',

                '3' => '3 Columns',

                '4' => '4 Columns',

            ),

            'default'  => '2',

            'hint'     => array(

                'title'   => esc_attr__('Footer Columns Count', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set columns count in footer. ', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'footer_tablet_columns',

            'type'     => 'radio',

            'title'    => __('Footer Columns Count: Tablet', 'dpr-adeline-extensions'),

            'required' => array('footer_content', 'equals', 'widgets'),

            'options'  => array(

                ''  => 'Inherit',

                '1' => '1 Column',

                '2' => '2 Columns',

                '3' => '3 Columns',

                '4' => '4 Columns',

            ),

            'default'  => '',

            'hint'     => array(

                'title'   => esc_attr__('Footer Columns Count: Tablet', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set columns count in footer for tablet devices. ', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'footer_mobile_columns',

            'type'     => 'radio',

            'title'    => __('Footer Columns Count: Mobile', 'dpr-adeline-extensions'),

            'required' => array('footer_content', 'equals', 'widgets'),

            'options'  => array(

                ''  => 'Inherit',

                '1' => '1 Column',

                '2' => '2 Columns',

                '3' => '3 Columns',

                '4' => '4 Columns',

            ),

            'default'  => '',

            'hint'     => array(

                'title'   => esc_attr__('Footer Columns Count: Mobile', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set columns count in footer for mobilet devices. ', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'             => 'footer_padding',

            'type'           => 'spacing',

            'output'         => array('#footer-widgets'),

            'mode'           => 'padding',

            'units'          => array('px'),

            'display_units'  => true,

            'units_extended' => false,

            'title'          => __('Footer Padding (px)', 'dpr-adeline-extensions'),

            'default'        => array(

                'padding-left'   => '0px',

                'padding-right'  => '0px',

                'padding-bottom' => '50px',

                'padding-top'    => '50px',

                'units'          => 'px',

            ),

            'hint'           => array(

                'title'   => esc_attr__('Footer Padding', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Choose default padding for footer.', 'dpr-adeline-extensions'),

            ),

            'required'       => array('footer_content', 'equals', 'widgets'),

        ),

        array(

            'id'       => 'footer_bg',

            'type'     => 'background',

            'title'    => __('Footer Background', 'dpr-adeline-extensions'),

            'output'   => array('.dpr-footer'),

            'default'  => array(

                'background-color' => '#292933',

                'background-size'  => 'cover',

            ),

            'required' => array('footer_content', 'not', 'disabled'),

            'hint'     => array(

                'title'   => esc_attr__('Footer Background', 'dpr-adeline-extensions'),

                'content' => esc_attr__('You can set footer background', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'footer_overlay_color',

            'type'     => 'color',

            'output'   => array('background-color' => '#footer-inner'),

            'validate' => 'color',

            'title'    => esc_html__('Footer Overlay Color', 'dpr-adeline-extensions'),

            'default'  => 'rgba(0,0,0,0)',

            'required' => array('footer_content', 'not', 'disabled'),

            'hint'     => array(

                'title'   => esc_attr__('Footer Overlay Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set footer overlay color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'footer_widgets_titles_color',

            'type'     => 'color',

            'output'   => array('color' => '#footer-widgets .footer-box .widget-title'),

            'validate' => 'color',

            'title'    => esc_html__('Widget Titles Color', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'required' => array('footer_content', 'equals', 'widgets'),

            'hint'     => array(

                'title'   => esc_attr__('Widget Titles Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set widget titles color for footer.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'footer_text_color',

            'type'     => 'color',

            'output'   => array('color' => '#footer-widgets,#footer-widgets p,#footer-widgets li a:before,#footer-widgets .contact-info-widget span.dpr-adeline-contact-title,#footer-widgets .recent-posts-date,#footer-widgets .recent-posts-comments,#footer-widgets .widget-recent-posts-icons li i'),

            'validate' => 'color',

            'title'    => esc_html__('Footer Text Color', 'dpr-adeline-extensions'),

            'default'  => '#cccccc',

            'required' => array('footer_content', 'equals', 'widgets'),

            'hint'     => array(

                'title'   => esc_attr__('Footer Text Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set footer text color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'footer_borders_color',

            'type'     => 'color',

            'output'   => array('border-color' => '#footer-widgets li,#footer-widgets #wp-calendar caption,#footer-widgets #wp-calendar th,#footer-widgets table td, #footer-widgets #wp-calendar tbody,#footer-widgets .contact-info-widget i,#footer-widgets .dpr-adeline-newsletter-form-wrap input[type="email"],#footer-widgets .posts-thumbnails-widget li,#footer-widgets .social-widget li a'),

            'validate' => 'color',

            'title'    => esc_html__('Footer Borders Color', 'dpr-adeline-extensions'),

            'default'  => '#c9c9ce ',

            'required' => array('footer_content', 'equals', 'widgets'),

            'hint'     => array(

                'title'   => esc_attr__('Footer Borders Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set footer borders color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'footer_links_color',

            'type'     => 'color',

            'output'   => array('color' => '#footer-widgets .footer-box a,#footer-widgets a'),

            'validate' => 'color',

            'title'    => esc_html__('Footer Links Color', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'required' => array('footer_content', 'equals', 'widgets'),

            'hint'     => array(

                'title'   => esc_attr__('Footer Links Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set footer links color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'footer_links_color_hover',

            'type'     => 'color',

            'output'   => array('color' => '#footer-widgets .footer-box a:hover,#footer-widgets a:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Footer Links Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'required' => array('footer_content', 'equals', 'widgets'),

            'hint'     => array(

                'title'   => esc_attr__('Footer Links Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set footer links hover color.', 'dpr-adeline-extensions'),

            ),

        ),

    ),

));
