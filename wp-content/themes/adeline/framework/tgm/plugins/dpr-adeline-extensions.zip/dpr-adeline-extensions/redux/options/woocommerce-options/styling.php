<?php

/**



 * Woocoommerce Options -> Styling



 *



 */

Redux::setSection($opt_name, array(

    'title'      => esc_html__('Elements Styling', 'dpr-adeline-extensions'),

    'id'         => 'woocommerce_styling',

    'subsection' => true,

    'fields'     => array(

        array(

            'id'       => 'woo_onsale_bg',

            'type'     => 'color',

            'output'   => array('background-color' => '.woocommerce span.onsale'),

            'validate' => 'color',

            'title'    => esc_html__('On Sale Background', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'hint'     => array(

                'title'   => esc_attr__('On Sale Background', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set background color for on sale label .', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_onsale_color',

            'type'     => 'color',

            'output'   => array('color' => '.woocommerce span.onsale'),

            'validate' => 'color',

            'title'    => esc_html__('On Sale Color', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'hint'     => array(

                'title'   => esc_attr__('On Sale Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set color for on sale label .', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_outofstock_bg',

            'type'     => 'color',

            'output'   => array('background-color' => '.woocommerce ul.products li.product.outofstock .outofstock-badge'),

            'validate' => 'color',

            'title'    => esc_html__('Out of Stock Background', 'dpr-adeline-extensions'),

            'default'  => '#A67F79',

            'hint'     => array(

                'title'   => esc_attr__('Out of Stock Background', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set background color for out of stock label .', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_outofstock_color',

            'type'     => 'color',

            'output'   => array('color' => '.woocommerce ul.products li.product.outofstock .outofstock-badge'),

            'validate' => 'color',

            'title'    => esc_html__('Out of Stock Color', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'hint'     => array(

                'title'   => esc_attr__('Out of Stock Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set color for out of stock label .', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_rating_stars_empty',

            'type'     => 'color',

            'output'   => array('color' => '.woocommerce .star-rating:before'),

            'validate' => 'color',

            'title'    => esc_html__('Empty Rating Stars Color', 'dpr-adeline-extensions'),

            'default'  => '#e5e5e9',

            'hint'     => array(

                'title'   => esc_attr__('Empty Rating Stars Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set color for empty rating star.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_rating_stars_filled',

            'type'     => 'color',

            'output'   => array('color' => '.woocommerce .star-rating span'),

            'validate' => 'color',

            'title'    => esc_html__('Filled Rating Stars Color', 'dpr-adeline-extensions'),

            'default'  => '#F8C45A',

            'hint'     => array(

                'title'   => esc_attr__('Filled Rating Stars Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set color for filled rating star.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_archive_toolbar_styling_info',

            'type'     => 'info',

            'style'    => 'dpr-title',

            'required' => array('menu_cart_style', 'equals', 'drop_down'),

            'title'    => wp_kses_post(__('<h3>Shop & Archive Pages Toolbar</h3>', 'dpr-adeline-extensions')),

        ),

        array(

            'id'       => 'woo_archive_view_switcher_bg',

            'type'     => 'color',

            'output'   => array('background-color' => '.woocommerce .dpr-adeline-grid-list a'),

            'validate' => 'color',

            'title'    => esc_html__('Grid/List Switcher Background', 'dpr-adeline-extensions'),

            'default'  => 'rgba(0,0,0,0)',

            'hint'     => array(

                'title'   => esc_attr__('Grid/List Switcher Background', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set background color for view switch buttons.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_archive_view_switcher_color',

            'type'     => 'color',

            'output'   => array('color' => '.woocommerce .dpr-adeline-grid-list a'),

            'validate' => 'color',

            'title'    => esc_html__('Grid/List Switcher Color', 'dpr-adeline-extensions'),

            'default'  => '#c9c9ce',

            'hint'     => array(

                'title'   => esc_attr__('Grid/List Switcher color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set color for view switch buttons.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_archive_view_switcher_bg_active',

            'type'     => 'color',

            'output'   => array('background-color' => '.woocommerce .dpr-adeline-grid-list a.active, .woocommerce .dpr-adeline-grid-list a:hover', 'border-color' => '.woocommerce .dpr-adeline-grid-list a.active, .woocommerce .dpr-adeline-grid-list a:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Grid/List Switcher Background: Active&Hover', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'hint'     => array(

                'title'   => esc_attr__('Grid/List Switcher Background: Active&Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set background color for view switch buttons.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_archive_view_switcher_color_active',

            'type'     => 'color',

            'output'   => array('color' => '.woocommerce .dpr-adeline-grid-list a.active, .woocommerce .dpr-adeline-grid-list a:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Grid/List Switcher Color: Active&Hover', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'hint'     => array(

                'title'   => esc_attr__('Grid/List Switcher color: Active&Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set color for view switch buttons.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_archive_sorting_select_color',

            'type'     => 'color',

            'output'   => array('color' => '.woocommerce .woocommerce-ordering .theme-select,.woocommerce .woocommerce-ordering .theme-select:after'),

            'validate' => 'color',

            'title'    => esc_html__('Sorting Select Color', 'dpr-adeline-extensions'),

            'default'  => '#c9c9ce',

            'hint'     => array(

                'title'   => esc_attr__('Sorting Select Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set color for sorting select control.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_archive_sorting_select_border',

            'type'     => 'color',

            'output'   => array('border-color' => '.woocommerce .woocommerce-ordering .theme-select,.woocommerce .woocommerce-ordering .theme-select:after'),

            'validate' => 'color',

            'title'    => esc_html__('Sorting Select Border Color', 'dpr-adeline-extensions'),

            'default'  => '#DFDFE4',

            'hint'     => array(

                'title'   => esc_attr__('Sorting Select Border Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set border color for sorting select control.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_archive_number_of_products_color',

            'type'     => 'color',

            'output'   => array('color' => '.woocommerce .result-count li.view-title'),

            'validate' => 'color',

            'title'    => esc_html__('Number of Products Color', 'dpr-adeline-extensions'),

            'default'  => '#c9c9ce ',

            'hint'     => array(

                'title'   => esc_attr__('Number of Products Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set color for number of products section.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_archive_number_of_products_link_color',

            'type'     => 'color',

            'output'   => array('color' => '.woocommerce .result-count li a, .woocommerce .result-count li:after'),

            'validate' => 'color',

            'title'    => esc_html__('Number of Products Links Color', 'dpr-adeline-extensions'),

            'default'  => '#424251;',

            'hint'     => array(

                'title'   => esc_attr__('Number of Products Links Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set links color for number of products section.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_archive_number_of_products_link_color_hover',

            'type'     => 'color',

            'output'   => array('color' => '.woocommerce .result-count li a.active , .woocommerce .result-count li a:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Number of Products Links Color: Active&Hover', 'dpr-adeline-extensions'),

            'default'  => '#c9c9ce',

            'hint'     => array(

                'title'   => esc_attr__('Number of Products Links Color: Active&Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set active and hover links color for number of products section.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_archive_product_styling_info',

            'type'     => 'info',

            'style'    => 'dpr-title',

            'required' => array('menu_cart_style', 'equals', 'drop_down'),

            'title'    => wp_kses_post(__('<h3>Shop & Archive Produts</h3>', 'dpr-adeline-extensions')),

        ),

        array(

            'id'       => 'woo_archive_product_category_color',

            'type'     => 'color',

            'output'   => array('color' => '.woocommerce ul.products li.product li.category a'),

            'validate' => 'color',

            'title'    => esc_html__('Category Color', 'dpr-adeline-extensions'),

            'default'  => '#424251',

            'hint'     => array(

                'title'   => esc_attr__('Category Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set category color in product item.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_archive_product_category_color_hover',

            'type'     => 'color',

            'output'   => array('color' => '.woocommerce ul.products li.product li.category a:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Category Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'hint'     => array(

                'title'   => esc_attr__('Category Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set category hover color in product item.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_archive_product_title_color',

            'type'     => 'color',

            'output'   => array('color' => '.woocommerce ul.products li.product li.title a'),

            'validate' => 'color',

            'title'    => esc_html__('Title Color', 'dpr-adeline-extensions'),

            'default'  => '#292933',

            'hint'     => array(

                'title'   => esc_attr__('Title Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set title color in product item.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_archive_product_title_color_hover',

            'type'     => 'color',

            'output'   => array('color' => '.woocommerce ul.products li.product li.title a:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Title Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'hint'     => array(

                'title'   => esc_attr__('Title Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set title hover color in product item.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_archive_product_price_color',

            'type'     => 'color',

            'output'   => array('color' => '.woocommerce ul.products li.product .price, .woocommerce ul.products li.product .price .amount'),

            'validate' => 'color',

            'title'    => esc_html__('Price Color', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'hint'     => array(

                'title'   => esc_attr__('Price Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set price color in product item.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_archive_product_del_price_color',

            'type'     => 'color',

            'output'   => array('color' => '.woocommerce ul.products li.product .price del .amount'),

            'validate' => 'color',

            'title'    => esc_html__('Del Price Color', 'dpr-adeline-extensions'),

            'default'  => '#888888',

            'hint'     => array(

                'title'   => esc_attr__('Del Price Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set del price color in product item.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_archive_add_to_cart_bg',

            'type'     => 'color',

            'output'   => array('background-color' => '.woocommerce ul.products li.product .button', 'border-color' => '.woocommerce ul.products li.product .button'),

            'validate' => 'color',

            'title'    => esc_html__('Add to Cart Button Background Color', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'hint'     => array(

                'title'   => esc_attr__('Add to Cart Button Background Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set background color for add to cart button in product item.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_archive_add_to_cart_text',

            'type'     => 'color',

            'output'   => array('color' => '.woocommerce ul.products li.product .button'),

            'validate' => 'color',

            'title'    => esc_html__('Add to Cart Button Text Color', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'hint'     => array(

                'title'   => esc_attr__('Add to Cart Button Text Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set text color for add to cart button in product item.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_archive_add_to_cart_bg_hover',

            'type'     => 'color',

            'output'   => array('background-color' => '.woocommerce ul.products li.product .button:hover', 'border-color' => '.woocommerce ul.products li.product .button:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Add to Cart Button Background Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'hint'     => array(

                'title'   => esc_attr__('Add to Cart Button Background Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set hover background color for add to cart button in product item.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_archive_add_to_cart_text_hover',

            'type'     => 'color',

            'output'   => array('color' => '.woocommerce ul.products li.product .button:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Add to Cart Button Text Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'hint'     => array(

                'title'   => esc_attr__('Add to Cart Button Text Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set hover text color for add to cart button in product item.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_single_product_styling_info',

            'type'     => 'info',

            'style'    => 'dpr-title',

            'required' => array('menu_cart_style', 'equals', 'drop_down'),

            'title'    => wp_kses_post(__('<h3>Single Product</h3>', 'dpr-adeline-extensions')),

        ),

        array(

            'id'       => 'woo_single_product_title_color',

            'type'     => 'color',

            'output'   => array('color' => '.woocommerce div.product .product_title'),

            'validate' => 'color',

            'title'    => esc_html__('Title Color', 'dpr-adeline-extensions'),

            'default'  => '#292933',

            'hint'     => array(

                'title'   => esc_attr__('Title Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set single product title color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_single_product_price_color',

            'type'     => 'color',

            'output'   => array('color' => '.price,.amount'),

            'validate' => 'color',

            'title'    => esc_html__('Price Color', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'hint'     => array(

                'title'   => esc_attr__('Price Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set single product price color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_single_product_del_price_color',

            'type'     => 'color',

            'output'   => array('color' => '.price del,del .amount'),

            'validate' => 'color',

            'title'    => esc_html__('Del Price Color', 'dpr-adeline-extensions'),

            'default'  => '#c9c9ce ',

            'hint'     => array(

                'title'   => esc_attr__('Del Price Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set single product del price color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_single_product_description_color',

            'type'     => 'color',

            'output'   => array('color' => '.woocommerce-product-details__short-description'),

            'validate' => 'color',

            'title'    => esc_html__('Excerpt Color', 'dpr-adeline-extensions'),

            'default'  => '#c9c9ce ',

            'hint'     => array(

                'title'   => esc_attr__('Excerpt Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set single product excerpt color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_single_quantity_color',

            'type'     => 'color',

            'output'   => array('color' => '.quantity .qty, .quantity .minus, .quantity .plus, .quantity .qty-changer a, .quantity .qty-changer a:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Quantity Select Color', 'dpr-adeline-extensions'),

            'default'  => '#c9c9ce ',

            'hint'     => array(

                'title'   => esc_attr__('Quantity Select Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set single product quantity selector color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_single_quantity_border',

            'type'     => 'color',

            'output'   => array('border-color' => '.quantity .minus, .quantity .plus, .quantity .qty,.quantity .qty-changer a'),

            'validate' => 'color',

            'title'    => esc_html__('Quantity Select Border Color', 'dpr-adeline-extensions'),

            'default'  => '#DFDFE4',

            'hint'     => array(

                'title'   => esc_attr__('Quantity Select Border Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set single product quantity selector border color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_single_meta_title_color',

            'type'     => 'color',

            'output'   => array('color' => '.product_meta .posted_in,.product_meta .tagged_as'),

            'validate' => 'color',

            'title'    => esc_html__('Meta Title Color', 'dpr-adeline-extensions'),

            'default'  => '#292933',

            'hint'     => array(

                'title'   => esc_attr__('Meta Title Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set single product meta titles color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_single_meta_link_color',

            'type'     => 'color',

            'output'   => array('color' => '.product_meta .posted_in a,.product_meta .tagged_as a'),

            'validate' => 'color',

            'title'    => esc_html__('Meta Link Color', 'dpr-adeline-extensions'),

            'default'  => '#c9c9ce',

            'hint'     => array(

                'title'   => esc_attr__('Meta Link Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set single product meta link color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_single_meta_link_color_hover',

            'type'     => 'color',

            'output'   => array('color' => '.product_meta .posted_in a:hover,.product_meta .tagged_as a:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Meta Link Color', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'hint'     => array(

                'title'   => esc_attr__('Meta Link Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set single product meta link color hover.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_single_tabs_border_color',

            'type'     => 'color',

            'output'   => array('border-color' => '.woocommerce div.product .woocommerce-tabs ul.tabs'),

            'validate' => 'color',

            'title'    => esc_html__('Tabs Border', 'dpr-adeline-extensions'),

            'default'  => '#DFDFE4',

            'hint'     => array(

                'title'   => esc_attr__('Tabs Border', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set product tabs border color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_single_tabs_text_color',

            'type'     => 'color',

            'output'   => array('color' => '.woocommerce div.product .woocommerce-tabs ul.tabs li a'),

            'validate' => 'color',

            'title'    => esc_html__('Tabs Text', 'dpr-adeline-extensions'),

            'default'  => '#292933',

            'hint'     => array(

                'title'   => esc_attr__('Tabs Text', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set product tabs text color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_single_tabs_text_color_active',

            'type'     => 'color',

            'output'   => array('color' => '.woocommerce div.product .woocommerce-tabs ul.tabs li a:hover, .woocommerce div.product .woocommerce-tabs ul.tabs li.active a', 'border-color' => '.woocommerce div.product .woocommerce-tabs ul.tabs li.active a'),

            'validate' => 'color',

            'title'    => esc_html__('Tabs Text: Active&Hover', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'hint'     => array(

                'title'   => esc_attr__('Tabs Text: Active&Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set product tabs text active and hover color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_single_product_description_tab_color',

            'type'     => 'color',

            'output'   => array('color' => '.woocommerce div.product .woocommerce-tabs .panel p'),

            'validate' => 'color',

            'title'    => esc_html__('Description Color', 'dpr-adeline-extensions'),

            'default'  => '#c9c9ce ',

            'hint'     => array(

                'title'   => esc_attr__('Description Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set single product description color.', 'dpr-adeline-extensions'),

            ),

        ),

    ),

));
