<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$output = $unique_id = $type = $el_class = $custom_el_css =  $alignment = $animation_speed = $type_speed = $back_animation = $back_delay = $loop_animation = $enable_cursor = $cursor_type = '';
$before_text = $strings_list = $after_text = $before_text_color = $after_text_color = '';
$animated_text_font_size = $animated_text_line_height  = $animated_text_letter_spacing = $animated_text_font_style = $animated_text_google_font = $animated_text_typo_style = '';
$text_font_size = $text_line_height  = $text_letter_spacing = $text_font_style = $text_google_font = $before_text_typo_style = $after_text_typo_style = '';
$use_animated_text_responsive_typo = $animated_text_reaponsive_typography = $use_text_responsive_typo = $text_reaponsive_typography = '';
$before_text_html = $after_text_html = $animated_text_html = '';

$atts = vc_map_get_attributes( 'dpr_animated_text', $atts );
extract( $atts );

$unique_id = uniqid('dpr-animated-text-').'-'.rand(1,9999);

if(!isset($type) || $type == '') {
	$type = 'typing';
}
if($animation_speed == '') {
	$animation_speed = 3;
}
if($type_speed == '') {
	$type_speed = 150;
}
if($back_delay == '') {
	$back_delay = 2;
}

wp_enqueue_script('dpr-waypoints', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/waypoints.min.js', array('jquery'), null, true);
dpr_enqueue_animate_css();
wp_enqueue_script('dpr-animated-text', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/dpr.animated.text.js', array('jquery'), null, true);	

/* CSS Class and styles */
$el_class .= ' '.$unique_id;
$el_class .= ' animation-'.$type;
$el_class .= ' '.$alignment;
if ( '' !== $css_animation && 'none' !== $css_animation ) {
	$el_class .= ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
}
/* Data attributes */
$data_atts = '';
switch($type) {
	case 'typing':
		$data_atts .= ' data-type-speed="'.esc_attr( $type_speed).'"';
		$data_atts .= ' data-back-delay="'.esc_attr( $back_delay * 1000).'"';
		$data_atts .= ' data-back-animation="'.esc_attr( $back_animation ).'"';
		if($enable_cursor == 'yes') {
			$data_atts .= ' data-cursor="1"';
			$data_atts .= ' data-cursor-type="'.esc_attr( $cursor_type ).'"';
		}

		if($loop_animation == 'yes') {
			$data_atts .= ' data-loop="1"';
		}
		break;
	case 'shuffle':
		$data_atts .= ' data-speed="'.esc_attr($animation_speed * 1000).'"';
		break;
	case 'rotate-words':
		$data_atts .= ' data-speed="'.esc_attr($animation_speed * 1000).'"';
		$data_atts .= ' data-inanimation="'. esc_attr($in_animation) .'"';
		$data_atts .= ' data-outanimation="'. esc_attr($out_animation) .'"';
		break;
}


/* HTML Parts */
//Before Text
if($before_text != '') {
		$before_text_typo_style = dpr_generate_typography_style($before_text_color, $text_font_size, $text_line_height, $text_letter_spacing, $text_font_style,$text_google_font);
		$before_text_html .= '<span class="dpr-before-text" '.$before_text_typo_style.'>'.strip_tags($before_text,'<br></br>').'</span>';
}
//After Text	
if($after_text != '') {
		$after_text_typo_style = dpr_generate_typography_style($after_text_color, $text_font_size, $text_line_height, $text_letter_spacing, $text_font_style,$text_google_font);
		$after_text_html .= '<span class="dpr-after-text" '.$after_text_typo_style.'>'.strip_tags($after_text,'<br></br>').'</span>';
}
//Animated Text
$animated_text_typo_css = dpr_generate_typography_css('', $animated_text_font_size, $animated_text_line_height, $animated_text_letter_spacing, $animated_text_font_style,$animated_text_google_font);
if(!empty($strings_list)) {
	$unique_content_id = uniqid('dpr-animated-block-content-').'-'.rand(1,9999);
	$unique_block_id = uniqid('dpr-animated-block-').'-'.rand(1,9999);
	$strings_list = (array) vc_param_group_parse_atts($strings_list);
	$i = 1;
	foreach($strings_list as $string) {
		$string_style = '';
		if(isset($string['string_color'])) {
			$string_style .= 'color: '.esc_attr($string['string_color']).';';
		}
		if(isset($string['string_bg'])) {
			$string_style .= 'background: '.esc_attr($string['string_bg']).'; padding: 0 10px .1em;';
		}
		if ($animated_text_typo_css !='') {
			$string_style .= $animated_text_typo_css;
		}
		if($string_style !='') {
			$string_style = 'style="'.$string_style.'"';
		}
		if(isset($string['animated_string'])) {
			$animated_text_html .= '<span><span class="dpr-animated-text-string" '.$string_style.' data-chaffle="en" data-chaffle-speed="100" data-chaffle-delay="200">' . strip_tags($string['animated_string'],'<br></br>') . '</span></span>';
		}
		$i++;
	}

	if($type == 'typing') {
		$data_atts .= ' data-source="'.esc_attr($unique_content_id).'"';
		$animated_text_html = '<span id="'.esc_attr($unique_content_id).'" class="dpr-typing-content">' . $animated_text_html . '</span>';
		$animated_text_html .= '<span id="'.esc_attr($unique_block_id).'" class="dpr-animated-block call-on-in-viewport '.$type.'" '.$data_atts.'></span>';
	} else {
		$animated_text_html = '<span class="dpr-animated-block call-on-in-viewport '.$type.'" '.$data_atts.'>' . $animated_text_html . '</span>';
	}
}


// Custom CSS stuff


// Add responsive CSS
if($use_animated_text_responsive_typo && isset($animated_text_reaponsive_typography) && $animated_text_reaponsive_typography != '') {
	$responsive_unique_class = '.'.esc_js($unique_id) .' .dpr-headline';
	$custom_el_css .= DPR_Resposive_Typography_Param::generate_css($animated_text_reaponsive_typography,$responsive_unique_class);
}
if($use_text_responsive_typo && isset($text_reaponsive_typography) && $text_reaponsive_typography != '') {
	$responsive_unique_class = '.'.esc_js($unique_id) .' .dpr-heading-subtitle';
	$custom_el_css .= DPR_Resposive_Typography_Param::generate_css($text_reaponsive_typography,$responsive_unique_class);
}

$output .= '<div id="' . esc_attr($unique_id) . '" class="dpr-animated-text">';
$output .= '<div class="dpr-animated-text-wrapper '.esc_attr($el_class).'" '.$data_atts.'>';
$output .= $before_text_html;
$output .= $animated_text_html;
$output .= $after_text_html;
$output .= '</div>';

	if(!empty($custom_el_css)) {
		$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>");'
						. '})(jQuery);'
					. '</script>';
}

$output .= '</div>';

echo $output;