<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$unique_id = $content_pos = $number_pos = $use_fixed_height = $box_height = $height_data = $css_animation = $el_class = $css = '';
$content_padding = $content_padding_top = $content_padding_right = $content_padding_bottom = $content_padding_left = '';
$title = $subtitle =  $main_content = $read_more = $link = $readmore_show = $readmore_style = $custom_button_size  = '';
$custom_button_shape = $custom_button_color = $custom_button_color_hover = $custom_button_bg_color = $custom_button_bg_color_hover = $custom_button_border_color = $custom_button_border_color_hover = $readmore_text = $link_target = '';
$icon_type = $icon_padding = $icon_padding_top = $icon_padding_left = $icon_padding_bottom = $icon_padding_right = $scale_on_hover = $hover_scale = '';
$icon = $icon_style = $icon_image_id = $icon_size = $icon_color = $icon_hover = $icon_size = '';
$icon_text = $use_vertical_text = $text_icon_use_google_fonts = $text_icon_custom_fonts = $text_icon_typo_style = $text_icon_color = $text_icon_font_size = $text_icon_line_height = $text_icon_letter_spacing = $text_icon__font_style = '';
$title_typo_style = $title_color = $title_color_hover = $title_font_size = $title_line_height = $title_letter_spacing = $title_font_style = $use_google_fonts = $title_google_font = $title_html = '';
$subtitle_typo_style = $subtitle_color = $subtitle_color_hover = $subtitle_font_size = $subtitle_line_height = $subtitle_letter_spacing = $subtitle_font_style = $subtitle_html = '';
$content_typo_style = $content_color = $content_color = $content_font_size = $content_line_height = $content_letter_spacing = $content_font_style = $content_html = '';
$hover_bg_type = $hover_bg_image = $idle_bg_image = $hover_bg_color = $hover_bg_gradient = '';
$box_shadow = $box_shadow_custom = $box_border_color_hover = $box_border_style_hover = $box_shadow_hover = $box_shadow_custom_hover = '';
$read_more_html = $title_wrap_html = '';
$head_html = $icon_html = '';
$box_gradient = $box_shadow = $box_shadow_custom = $box_border_color_hover = $box_border_style_hover = $box_border_radius_hover = $box_background_color_hover = $box_gradient_hover = $box_shadow_hover = $box_shadow_custom_hover = $box_bg_image_hover = $box_hover_animation = '';

$output = $custom_el_css = '';

$atts = vc_map_get_attributes( 'dpr_service_box', $atts );
extract( $atts );
wp_enqueue_script('dpr-step-box', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/dpr.service.box.js', array('jquery'), null, true);	
$unique_id = uniqid('dpr-service-box-').'-'.rand(1,9999);

$el_class .= ' content-position-'.$content_pos.' number-position-'.esc_attr($number_pos);

if(isset($readmore_show) && strcmp($readmore_show, 'show') == 0) {
	$el_class .= ' show-readmore';
}

if ( '' !== $css_animation && 'none' !== $css_animation ) {
			dpr_enqueue_waypoint_js ();
			dpr_enqueue_animate_css();
			$el_class .= ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
}
/* Content */

if(isset($content_padding_top) && $content_padding_top != '') {
		$content_padding .= 'padding-top: '.$content_padding_top.'px;';
}
if(isset($content_padding_right) && $content_padding_right != '') {
		$content_padding .= 'padding-right: '.$content_padding_right.'px;';
}
if(isset($content_padding_bottom) && $content_padding_bottom != '') {
		$content_padding .= 'padding-bottom: '.$content_padding_bottom.'px;';
}
if(isset($content_padding_right) && $content_padding_right != '') {
		$content_padding .= 'padding-right: '.$content_padding_right.'px;';
}
if($content_padding != '') {
		$custom_el_css .= '.'.esc_js($unique_id).' .content-container {'.esc_js($content_padding).'}';
}


if(isset($title_color_hover) && !empty($title_color_hover)) {
	$custom_el_css .= '.'.esc_js($unique_id).':hover .icon-box-title {color: '.esc_js($title_color_hover).'!important;}';
}

if(isset($subtitle_color_hover) && !empty($subtitle_color_hover)) {
	$custom_el_css .= '.'.esc_js($unique_id).':hover .icon-box-subtitle {color: '.esc_js($subtitle_color_hover).'!important;}';
}

if(isset($content_color_hover) && !empty($content_color_hover)) {
	$custom_el_css .= '.'.esc_js($unique_id).':hover .description {color: '.esc_js($content_color_hover).'!important;}';
}
/* Number */

if(isset($icon_padding_top) && $icon_padding_top != '') {
		$icon_padding .= 'padding-top: '.$icon_padding_top.'px;';
}
if(isset($icon_padding_right) && $icon_padding_right != '') {
		$icon_padding .= 'padding-right: '.$icon_padding_right.'px;';
}
if(isset($icon_padding_bottom) && $icon_padding_bottom != '') {
		$icon_padding .= 'padding-bottom: '.$icon_padding_bottom.'px;';
}
if(isset($icon_padding_left) && $icon_padding_left != '') {
		$icon_padding .= 'padding-left: '.$icon_padding_left.'px;';
}
if($icon_padding != '') {
		$custom_el_css .= '.'.esc_js($unique_id).' .number-container {'.esc_js($icon_padding).'}';
}


if(isset($text_icon_color_hover) && !empty($text_icon_color_hover)) {
	$custom_el_css .= '.'.esc_js($unique_id).':hover .number-container .dpr-text-icon-wrap  {color: '.esc_js($text_icon_color_hover).'!important;}';
}

if(isset($icon_hover) && !empty($icon_hover)) {
	$custom_el_css .= '.'.esc_js($unique_id).':hover .module-icon i {color: '.esc_js($icon_hover).'!important;}';
}
/* Hover Background */
if($hover_bg_type == 'color') {
	if(isset($hover_bg_color) && !empty($hover_bg_color)) {
		$custom_el_css .= '.'.esc_js($unique_id).':hover .hover-bg-container  {background-color: '.esc_js($hover_bg_color).'}';
	}
}
if($hover_bg_type == 'gradient') {
	if(isset($hover_bg_gradient) && !empty($hover_bg_gradient)) {
		$custom_el_css .= '.'.esc_js($unique_id).':hover .hover-bg-container{'.esc_js(adeline_gradientToBgCSS ($hover_bg_gradient)).';}';
	}
}
/* Box */

if ( 'custom' != $box_shadow && '' != $box_shadow ) $el_class .= ' dpr-shadow-'.$box_shadow;
if ( 'custom' != $box_shadow_hover && '' != $box_shadow_hover ) $el_class .= ' dpr-shadow-onhover-'.$box_shadow_hover;

if ($box_shadow == 'custom' && dpr_shadow_param_to_css($box_shadow_custom) != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' {'.dpr_shadow_param_to_css($box_shadow_custom).'}';
}

if ($box_shadow_hover == 'custom' && dpr_shadow_param_to_css($box_shadow_custom_hover) != '') {
	$custom_el_css .= '.'.esc_js($unique_id).':hover {'.dpr_shadow_param_to_css($box_shadow_custom_hover).'}';
}

if(isset($box_border_color_hover) && !empty($box_border_color_hover)) {
	$custom_el_css .= '.'.esc_js($unique_id).':hover {border-color:'. $box_border_color_hover.'!important;}';
}

if(isset($box_border_style_hover) && !empty($box_border_style_hover)) {
	$custom_el_css .= '.'.esc_js($unique_id).':hover {border-style:'. $box_border_style_hover.'!important;}';
}

if(isset($box_height) && $box_height != '') {
	$height_data = 'data-height ="'.esc_attr($box_height).'"';
}
/* HTML Fragments */

if(!empty($title)) {
	$title_typo_style = dpr_generate_typography_style($title_color, $title_font_size, $title_line_height, $title_letter_spacing, $title_font_style,$title_google_font);
	if(isset($link) && strcmp($read_more, 'title') == 0) {
		$link = vc_build_link($link);
		$link_target = !empty($link['target']) ? 'target="'.esc_attr(preg_replace('/\s+/', '', $link['target'])).'"' : '';
		$title_html .= '<h4 class="icon-box-title " '.$title_typo_style.'><a href="'.esc_url($link['url']).'" title="'.esc_attr($link['title']).'" '.$link_target.' rel="'.esc_attr($link['rel']).'">'.wp_kses($title, array('span' => array(),'br' => array())).'</a></h4>';
	}else{
		$title_html .= '<h4 class="icon-box-title" '.$title_typo_style.'>'.wp_kses($title, array('span' => array(), 'br' => array())).'</h4>';
	}
}

if(!empty($subtitle)) {
	$subtitle_typo_style = dpr_generate_typography_style($subtitle_color, $subtitle_font_size, $subtitle_line_height, $subtitle_letter_spacing, $subtitle_font_style);
	$subtitle_html .= '<div class="icon-box-subtitle" '.$subtitle_typo_style.' >'.esc_html($subtitle).'</div>';
}

if(isset($title) &&!empty($title) || isset($subtitle) && !empty($subtitle)) {
	$title_wrap_html .= '<div class="title-wrap">';
		$title_wrap_html .= $title_html;
		$title_wrap_html .= $subtitle_html;
	$title_wrap_html .= '</div>';
}

$content_typo_style = dpr_generate_typography_style($content_color, $content_font_size, $content_line_height, $content_letter_spacing, $content_font_style);
$content_html .= '<div class="description" '.$content_typo_style.'>'.strip_tags($main_content,'<br><br/>').'</div>';

if(isset($icon_type) && $icon_type == 'icon' || ($icon_type == 'custom' && !empty($icon_image_id)) || ($icon_type == 'text' && !empty($icon_text))) {

		$icon_html .= '<div class="module-icon">';
			$icon_html .= '<div class="icon-container">';
			if ('icon' === $icon_type) {
				
				if ($icon != '') {
					
					if (!empty($icon_size) || !empty($icon_color)) {
				
						$icon_style .= 'style="';
		
						if ( ! empty( $icon_size ) ) {
							$icon_style .= 'font-size:' . $icon_size . 'px; ';
						}
		
						if ( ! empty( $icon_color ) ) {
							$icon_style .= 'color:' . $icon_color.'; ';
						}
		
						$icon_style .= '"';
						}
				
					$icon_html .= '<i class="featured-icon ' . $icon . '" ' . $icon_style . '></i>';
				
				}
			
			} elseif('custom' === $icon_type ) {
				$img_style = '';
				$image_url = dpr_get_attachment_image_src( $icon_image_id, 'full' );
				if (! empty( $icon_size )){
					
					$image_src = adeline_resize( $image_url[0], $icon_size, $icon_size, true, true, true );
					if(!$image_src) $image_src = $image_url[0];
				
				} else {
					
					$image_src = $image_url[0];
				
				}
				//$img_atts = adeline_image_attributes( $image_url[1], $image_url[2], $icon_size, $icon_size );
				if ( ! empty( $icon_size ) ) {
	
					$img_style .= 'style="';
	
					if ( isset( $icon_size ) && ! empty( $icon_size ) ) {
						$img_style .= 'width:' . esc_attr($icon_size) . 'px; ';
					}
	
					$img_style .= '"';
	
				}
				$alt_text = get_post_meta($icon_image_id , '_wp_attachment_image_alt', true);
				$icon_html .= '<img src="' . esc_url($image_src) . '" ' . $img_style . ' alt ="'.esc_attr($alt_text).'"/>';
				
			} elseif('text' === $icon_type ) {
				$text_icon_typo_style = dpr_generate_typography_style($text_icon_color, $text_icon_font_size, $text_icon_line_height, $text_icon_letter_spacing, $text_icon_font_style, $text_icon_custom_fonts);
				$icon_html .= '<span class="dpr-text-icon-wrap " '.$text_icon_typo_style.'>'.  $icon_text.'</span>';
			} 
				
			$icon_html .= '</div>';
		$icon_html .= '</div>';
}

// Readmore HTML output
$read_more_data = dpr_generate_read_more($atts);
$read_more_html .= $read_more_data[0];
$custom_el_css .= $read_more_data[1];

$head_html .= '<div class="head-wrap">';
$head_html .= $title_wrap_html;
$head_html .= '</div>';

if(isset($scale_on_hover) && $scale_on_hover == 'yes') {
	$el_class .= ' animated-number';
}
if(isset($use_vertical_text) && $use_vertical_text == 'yes') {
	$el_class .= ' vertical-number';
}
if($hover_bg_type == 'color' || $hover_bg_type == 'gradient' ) {
	$el_class .= ' no-hover-bg-image';
}
$css_classes = array(
	'dpr-featured-box dpr-service-box',
	$unique_id,
	$el_class,
	vc_shortcode_custom_css_class( $css ),
);

$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->settings['base'], $atts ) );

// Generate Output //


$output .= '<div id="'.esc_attr($unique_id).'" class="'.esc_attr($css_class).'" '.$height_data.'>';
if($hover_bg_type == 'image') {

	$bg_image_idle_url = $bg_image_hover_url = '';
	if(isset($idle_bg_image) && $idle_bg_image != '') {
		$bg_image_idle_url = dpr_get_attachment_image_src( $idle_bg_image, 'full' );
		$bg_image_idle_url = $bg_image_idle_url[0];
		$output .= '<div class="idle-bg-image"><img src="'.esc_url($bg_image_idle_url).'"></div>';
	} elseif(isset($hover_bg_image) && $hover_bg_image != '') {
		$bg_image_hover_url = dpr_get_attachment_image_src( $hover_bg_image, 'full' );
		$bg_image_hover_url = $bg_image_hover_url[0];
		$output .= '<div class="fake-bg-image" style="visibility:hidden"><img src="'.esc_url($bg_image_hover_url).'"></div>';
	}
}
$output .= '<div class="hover-bg-container">';
if($hover_bg_type == 'image') {
	if(isset($hover_bg_image) && $hover_bg_image != '') {
		$bg_image_hover_url = dpr_get_attachment_image_src( $hover_bg_image, 'full' );
		$bg_image_hover_url = $bg_image_hover_url[0];
		$output .= '<img src="'.esc_url($bg_image_hover_url).'">';
	}
}
$output .= '</div>';
$output .= '<div class="number-container">'.$icon_html.'</div>';
$output .= '<div class="content-container">';
$output .= '<div class="content-container-inner">';
	if(!empty($title_wrap_html)) {
		$output .= $head_html;
	}
	if(isset($main_content) && !empty($main_content) || isset($readmore_show) && $readmore_show == 'show') {
		$output .= '<div class="container-info">';
			$output .= '<div class="content-cell">';
				$output .= $content_html;
				$output .= $read_more_html;
			$output .= '</div>';
		$output .= '</div>';
	}

	if(isset($link) && strcmp($read_more, 'box') == 0) {
		$link = vc_build_link( $link );
		$link_target = !empty($link['target']) ? 'target="'.esc_attr(preg_replace('/\s+/', '', $link['target'])).'"' : '';
		$output .= '<a href="'.esc_url($link['url']).'" class="dpr-cover-link" title="'.esc_attr($link['title']).'" '.$link_target.' rel="'.esc_attr($link['rel']).'"></a>';
	}
$output .= '</div>';
$output .= '</div>';

	if(!empty($custom_el_css)) {
		$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>");'
						. '})(jQuery);'
					. '</script>';
	}
$output .= '</div>';

echo $output;