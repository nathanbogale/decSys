<?php

/**



 * Header Options -> Social Links



 *



 */

Redux::setSection($opt_name, array(

    'title'      => esc_html__('Social Links', 'dpr-adeline-extensions'),

    'id'         => 'header_social_links',

    'subsection' => true,

    'fields'     => array(

        array(

            'id'      => 'menu_social_display',

            'type'    => 'switch',

            'default' => false,

            'title'   => esc_html__('Display Social Links In Menu', 'dpr-adeline-extensions'),

        ),

        array(

            'id'       => 'menu_social_content_type',

            'type'     => 'radio',

            'title'    => __('Menu Social Content Type', 'dpr-adeline-extensions'),

            'options'  => array(

                'default' => 'Default',

                'html'    => 'HTML Content',

                'custom'  => 'Custom Template',

            ),

            'default'  => 'default',

            'required' => array('menu_social_display', 'equals', '1'),

            'hint'     => array(

                'title'   => esc_attr__('Menu Social Content Type', 'dpr-adeline-extensions'),

                'content' => esc_attr__('By default is used setting entered bellow but you can also use custom HTML content or template from Particles library. ', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_social_html',

            'type'     => 'textarea',

            'title'    => __('HTML Content', 'dpr-adeline-extensions'),

            'validate' => 'html',

            'desc'     => __('<i><small>HTML is allowed.</small></i>'),

            'default'  => '',

            'hint'     => array(

                'title'   => esc_attr__('HTML Content', 'dpr-adeline-extensions'),

                'content' => esc_attr__('You can enter menu social content here. HTML is allowed', 'dpr-adeline-extensions'),

            ),

            'required' => array('menu_social_content_type', 'equals', 'html'),

        ),

        array(

            'id'       => 'menu_social_particle_selected',

            'type'     => 'select',

            'data'     => 'posts',

            'args'     => array('post_type' => array('dpr_particle'), 'posts_per_page' => -1),

            'title'    => esc_html__('Custom Menu Social Template', 'dpr-adeline-extensions'),

            'desc'     => __('Please note that you need first create custom content template in Particles menu'),

            'hint'     => array(

                'title'   => esc_attr__('Custom Menu Social Template', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Select previously prepared particle to display in menu social area. ', 'dpr-adeline-extensions'),

            ),

            'required' => array('menu_social_content_type', 'equals', 'custom'),

        ),

        array(

            'id'       => 'menu_social_style',

            'type'     => 'image_select',

            'title'    => __('Social Links Style', 'dpr-adeline-extensions'),

            'options'  => array(

                'minimal'  => array(

                    'title' => esc_html__('Minimal', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/socials/minimal.jpg',

                ),

                'rounded'  => array(

                    'title' => esc_html__('Rounded', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/socials/rounded.jpg',

                ),

                'outlined' => array(

                    'title' => esc_html__('Outlined', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/socials/outlined.jpg',

                ),

                'colored'  => array(

                    'title' => esc_html__('Colored', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/socials/colored.jpg',

                ),

            ),

            'default'  => 'minimal',

            'hint'     => array(

                'title'   => esc_attr__('Social Links Style', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Choose social share icon style.', 'dpr-adeline-extensions'),

            ),

            'required' => array('menu_social_content_type', 'equals', 'default'),

        ),

        array(

            'id'       => 'menu_social_target',

            'type'     => 'select',

            'title'    => esc_html__('Social Link Target', 'dpr-adeline-extensions'),

            'desc'     => '',

            'options'  => array(

                'blank' => esc_html__('New window', 'dpr-adeline-extensions'),

                'self'  => esc_html__('Same window', 'dpr-adeline-extensions'),

            ),

            'default'  => 'blank',

            'required' => array('menu_social_content_type', 'equals', 'default'),

        ),

        array(

            'id'       => 'menu_social_minimal_color',

            'type'     => 'color',

            'output'   => array('.dpr-adeline-social-menu ul li a, .sidr-class-social-menu-inner ul li a'),

            'validate' => 'color',

            'title'    => esc_html__('Social Icons Color: Minimal Style', 'dpr-adeline-extensions'),

            'default'  => '#292933',

            'required' => array('menu_social_style', 'equals', 'minimal'),

        ),

        array(

            'id'       => 'menu_social_rounded_color',

            'type'     => 'color',

            'output'   => array('background-color' => '.dpr-adeline-social-menu .rounded ul li a,.sidr-class-social-menu-inner.sidr-class-rounded ul li a'),

            'validate' => 'color',

            'title'    => esc_html__('Social Icons Background Rounded Style', 'dpr-adeline-extensions'),

            'default'  => '#292933',

            'required' => array('menu_social_style', 'equals', 'rounded'),

        ),

        array(

            'id'       => 'menu_social_rounded_color_hover',

            'type'     => 'color',

            'output'   => array('background-color' => '.dpr-adeline-social-menu .rounded ul li a:hover, .sidr-class-social-menu-inner.sidr-class-rounded ul li a:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Social Icons Background Rounded Style: Hover', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'required' => array('menu_social_style', 'equals', 'rounded'),

        ),

        array(

            'id'       => 'menu_social_outlined_color',

            'type'     => 'color',

            'output'   => array(

                'color'        => '.dpr-adeline-social-menu .outlined ul li a, .sidr-class-social-menu-inner.sidr-class-outlined ul li a',

                'border-color' => '.dpr-adeline-social-menu .outlined ul li a, .sidr-class-social-menu-inner.sidr-class-outlined ul li a'),

            'validate' => 'color',

            'title'    => esc_html__('Social Icons Outlined Style Color', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'required' => array('menu_social_style', 'equals', 'outlined'),

        ),

        array(

            'id'             => 'menu_social_font_size',

            'type'           => 'typography',

            'title'          => esc_html__('Social Icons Font Size', 'dpr-adeline-extensions'),

            'google'         => false,

            'font-family'    => false,

            'font-weight'    => false,

            'font-style'     => false,

            'subsets'        => false,

            'font-size'      => true,

            'text-align'     => false,

            'line-height'    => false,

            'word-spacing'   => false,

            'letter-spacing' => false,

            'text-transform' => false,

            'color'          => false,

            'preview'        => false,

            'all_styles'     => false,

            'units'          => 'px',

            'output'         => array('.dpr-adeline-social-menu ul li a, .side-panel-btn .side-panel-icon'),

            'default'        => array(

                'font-size' => '12px',

            ),

            'required'       => array('menu_social_content_type', 'equals', 'default'),

        ),

        array(

            'id'             => 'menu_social_spacing',

            'type'           => 'spacing',

            'output'         => array('.dpr-adeline-social-menu ul li a'),

            'mode'           => 'margin',

            'top'            => false,

            'bottom'         => false,

            'units'          => array('px'),

            'display_units'  => true,

            'units_extended' => false,

            'title'          => __('Social Icons Spacing (px)', 'dpr-adeline-extensions'),

            'default'        => array(

                'margin-left'  => '2px',

                'margin-right' => '2px',

                'units'        => 'px',

            ),

            'required'       => array('menu_social_content_type', 'equals', 'default'),

        ),

    ),

));
