<?php

// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}

/*

* Add-on Name: DP Timetable

*/



class WPBakeryShortCode_DPR_Timetable extends WPBakeryShortCode {}





vc_map(

	array(

		'name'					=> esc_html__('DP Timetable', 'dpr-adeline-extensions'),

		'base'					=> 'dpr_timetable',

		"icon"					=> 'icon-dpr-timetable',

		"class"					=> 'dpr_timetable',

  		"category" =>array( esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions')),

		'description'			=> esc_html__('Display Timetable', 'dpr-adeline-extensions'),

		'params'				=> array(

				array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'General Settings', 'dpr-adeline-extensions' ),

				'param_name'       => 'general_title',

				'edit_field_class' => 'vc_column vc_col-sm-12',

			),

				array(

					'type' => 'dpr_post_multi_select',

					'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Select columns to include. At least one column must be included to display timetable.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Columns To Display (required)', 'dpr-adeline-extensions'),

					'param_name' => 'columns_include',

					'placeholder' => 'Select columns...',

					'edit_field_class' => 'vc_column vc_col-sm-12',

					'post_type' => 'mp-column'

				),

				array(

					'type' => 'dpr_post_multi_select',

					'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Select events to include.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Events To Include', 'dpr-adeline-extensions'),

					'param_name' => 'events_include',

					'placeholder' => 'Select events...',

					'edit_field_class' => 'vc_column vc_col-sm-12',

					'post_type' => 'mp-event'

				),

				array(

					'type' => 'dpr_tax_multi_select',

					'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select categories to include.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Categories To Include', 'dpr-adeline-extensions'),

					'param_name' => 'categories_include',

					'placeholder' => 'Select events categories...',

					'edit_field_class' => 'vc_column vc_col-sm-12',

					'taxonomy' => 'mp-event_category'

				),

				

				



/*EXTRA FEATURES */

				array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Additional Settings', 'dpr-adeline-extensions' ),

				'param_name'       => 'extra_features_title',

				'edit_field_class' => 'vc_column vc_col-sm-12',

			),

				vc_map_add_css_animation( false ),

				array(

					'type' => 'textfield',

					'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('If you use more than one table on a page specify the unique ID for a timetable. Make sure it is unique, and it is valid as w3c specification (Must not have spaces).', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Unique ID', 'dpr-adeline-extensions'),

					'param_name' => 'el_id',

					'value' => uniqid('timetable-').'-'.rand(1,9999),

					'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				),

				array(

					'type' => 'textfield',

					'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Extra Class Name', 'dpr-adeline-extensions'),

					'param_name' => 'el_class',

				),



/*LAYOUT & STYLE */

				array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Available Fields', 'dpr-adeline-extensions' ),

				'param_name'       => 'fields_title',

				'edit_field_class' => 'vc_column vc_col-sm-12',				

				'group'			=> esc_html__('Events Style', 'dpr-adeline-extensions'),),

				array(

					'type'				=> 'dpr_switcher',

					'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Display event title in timetable items.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Display Title', 'dpr-adeline-extensions'),

					'param_name'		=> 'display_title',

					'edit_field_class' => 'vc_column vc_col-sm-4',

					'value' => 'yes',

					'options'			=> array(

						'yes'				=> array(

							'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

							'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

						),

					),				

					'group'			=> esc_html__('Events Style', 'dpr-adeline-extensions'),),

				array(

					'type'				=> 'dpr_switcher',

					'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Display event time in timetable items.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Display Time', 'dpr-adeline-extensions'),

					'param_name'		=> 'display_time',

					'edit_field_class' => 'vc_column vc_col-sm-4',

					'value' => 'yes',

					'options'			=> array(

						'yes'				=> array(

							'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

							'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

						),

					),				

					'group'			=> esc_html__('Events Style', 'dpr-adeline-extensions'),),

				array(

					'type'				=> 'dpr_switcher',

					'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Display event subtitle in timetable items.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Display Subtitle', 'dpr-adeline-extensions'),

					'param_name'		=> 'display_subtitle',

					'edit_field_class' => 'vc_column vc_col-sm-4',

					'value' => 'yes',

					'options'			=> array(

						'yes'				=> array(

							'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

							'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

						),

					),				

					'group'			=> esc_html__('Events Style', 'dpr-adeline-extensions'),),

				array(

					'type'				=> 'dpr_switcher',

					'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Display event description in timetable items.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Display Description', 'dpr-adeline-extensions'),

					'param_name'		=> 'display_description',

					'edit_field_class' => 'vc_column vc_col-sm-4',

					'value' => 'no',

					'options'			=> array(

						'yes'				=> array(

							'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

							'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

						),

					),				

					'group'			=> esc_html__('Events Style', 'dpr-adeline-extensions'),),

				array(

					'type'				=> 'dpr_switcher',

					'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Display event user in timetable items.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Display User', 'dpr-adeline-extensions'),

					'param_name'		=> 'display_user',

					'edit_field_class' => 'vc_column vc_col-sm-4',

					'value' => 'no',

					'options'			=> array(

						'yes'				=> array(

							'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

							'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

						),

					),

					'group'			=> esc_html__('Events Style', 'dpr-adeline-extensions'),),

				array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Event Block Style', 'dpr-adeline-extensions' ),

				'param_name'       => 'style_title',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group'			=> esc_html__('Events Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set horizontal align.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Horizontal Align', 'dpr-adeline-extensions'),

				'param_name'		=> 'horizontal_align',

				'value'				=> 'center',

				'options'			=> array(

					esc_html__('Left', 'dpr-adeline-extensions')	=> 'left',

					esc_html__('Center', 'dpr-adeline-extensions')	=> 'center',

					esc_html__('Right', 'dpr-adeline-extensions')	=> 'right'

				),

				'edit_field_class'	=> 'vc_col-sm-12 vc_column ',				

				'group'			=> esc_html__('Events Style', 'dpr-adeline-extensions'),),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set vertical align.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Vertical Align', 'dpr-adeline-extensions'),

				'param_name'		=> 'vertical_align',

				'value'				=> '',

				'options'			=> array(

					esc_html__('Default', 'dpr-adeline-extensions')	=> '',

					esc_html__('Top', 'dpr-adeline-extensions')	=> 'top',

					esc_html__('Middle', 'dpr-adeline-extensions')	=> 'middle',

					esc_html__('Bottom', 'dpr-adeline-extensions')	=> 'bottom'

				),

				'edit_field_class'	=> 'vc_col-sm-12 vc_column ',				

				'group'			=> esc_html__('Events Style', 'dpr-adeline-extensions'),),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set block height.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Block Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'block_height',

				'min'				=> 10,

				'value'   			=> 45,

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',				

				'group'			=> esc_html__('Events Style', 'dpr-adeline-extensions'),),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set time front for events.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Timeframe for events', 'dpr-adeline-extensions'),

				'param_name'		=> 'event_timeframe',

				'value'				=> '1',

				'options'			=> array(

					esc_html__('Hour', 'dpr-adeline-extensions')	=> 1,

					esc_html__('Half hour', 'dpr-adeline-extensions')	=> 0.5,

					esc_html__('Quarter hour', 'dpr-adeline-extensions')	=> 0.25

				),

				'edit_field_class'	=> 'vc_col-sm-8 vc_column ',				

				'group'			=> esc_html__('Events Style', 'dpr-adeline-extensions'),),

				array(

					'type'	=> 'dpr_switcher',

					'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Display or hide hours columns.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Display Hours Columns', 'dpr-adeline-extensions'),

					'param_name'		=> 'display_hours',

					'edit_field_class' => 'vc_column vc_col-sm-4',

					'value' => 'yes',

					'options'			=> array(

						'yes'				=> array(

							'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

							'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

						),

					),				

					'group'			=> esc_html__('Events Style', 'dpr-adeline-extensions'),),

				array(

					'type'	=> 'dpr_switcher',

					'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Display or hide emty rows.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Display Empty Rows', 'dpr-adeline-extensions'),

					'param_name'		=> 'display_empty_rows',

					'edit_field_class' => 'vc_column vc_col-sm-4',

					'value' => 'no',

					'options'			=> array(

						'yes'				=> array(

							'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

							'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

						),

					),				

					'group'			=> esc_html__('Events Style', 'dpr-adeline-extensions'),),

				array(

					'type'	=> 'dpr_switcher',

					'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Merge Cells With Common Events.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Merge Cells', 'dpr-adeline-extensions'),

					'param_name'		=> 'merge_cells',

					'edit_field_class' => 'vc_column vc_col-sm-4',

					'value' => 'no',

					'options'			=> array(

						'yes'				=> array(

							'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

							'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

						),

					),				

					'group'			=> esc_html__('Events Style', 'dpr-adeline-extensions'),),

				array(

					'type'	=> 'dpr_switcher',

					'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Disable Event Link.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Disable Event Link', 'dpr-adeline-extensions'),

					'param_name'		=> 'disable_link',

					'edit_field_class' => 'vc_column vc_col-sm-4',

					'value' => 'no',

					'options'			=> array(

						'yes'				=> array(

							'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

							'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

						),

					),				

					'group'			=> esc_html__('Events Style', 'dpr-adeline-extensions'),),

/* Table */

				array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Header Style', 'dpr-adeline-extensions' ),

				'param_name'       => 'table_header_title',

				'edit_field_class' => 'vc_column vc_col-sm-12',				

				'group'			=> esc_html__('Table Style', 'dpr-adeline-extensions'),

				),

				array(

					'type'				=> 'colorpicker',

					'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose background color for table heading', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background Color', 'dpr-adeline-extensions'),

					'param_name'		=> 'th_bg_color',

					'edit_field_class'	=> 'vc_column vc_col-sm-6',

					'value'  => '',

				'group'			=> esc_html__('Table Style', 'dpr-adeline-extensions'),

				),

				array(

					'type'				=> 'colorpicker',

					'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose border color for table heading', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border Color', 'dpr-adeline-extensions'),

					'param_name'		=> 'th_border_color',

					'edit_field_class'	=> 'vc_column vc_col-sm-6',

					'value'  => '',

				'group'			=> esc_html__('Table Style', 'dpr-adeline-extensions'),

				),

				

				

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Header Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'header_typography_title',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'			=> esc_html__('Table Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom headline color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'th_color',

				'edit_field_class'	=> 'vc_col-sm-3 vc_column ',

				'group'			=> esc_html__('Table Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size. If you leave this field blank will be used default size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'th_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'			=> esc_html__('Table Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title linne height.Default is 18px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'th_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'			=> esc_html__('Table Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'th_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'			=> esc_html__('Table Style', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'th_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'group'			=> esc_html__('Table Style', 'dpr-adeline-extensions'),

	  		),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font. .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_th_google_fonts',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'			=> esc_html__('Table Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'th_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'dependency'		=> array('element' => 'use_th_google_fonts', 'value' => array('yes')),

				'group'			=> esc_html__('Table Style', 'dpr-adeline-extensions'),

			),

				

				

				array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Rows Style', 'dpr-adeline-extensions' ),

				'param_name'       => 'table_rows_title',

				'edit_field_class' => 'vc_column vc_col-sm-12',				

				'group'			=> esc_html__('Table Style', 'dpr-adeline-extensions'),

				),

				array(

					'type'				=> 'colorpicker',

					'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose border color for table heading', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background Color', 'dpr-adeline-extensions'),

					'param_name'		=> 'tr_bg_color',

					'edit_field_class'	=> 'vc_column vc_col-sm-6',

					'value'  => '',

				'group'			=> esc_html__('Table Style', 'dpr-adeline-extensions'),

				),

				array(

					'type'				=> 'colorpicker',

					'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose background color for table heading', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border Color', 'dpr-adeline-extensions'),

					'param_name'		=> 'tr_border_color',

					'edit_field_class'	=> 'vc_column vc_col-sm-6',

					'value'  => '',

				'group'			=> esc_html__('Table Style', 'dpr-adeline-extensions'),

				),

				array(

					'type'				=> 'colorpicker',

					'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose background color for table heading', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background Color: Even', 'dpr-adeline-extensions'),

					'param_name'		=> 'tr_bg_color_even',

					'edit_field_class'	=> 'vc_column vc_col-sm-6',

					'value'  => '',

				'group'			=> esc_html__('Table Style', 'dpr-adeline-extensions'),

				),

				array(

					'type'				=> 'colorpicker',

					'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose border color for table heading', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Borderd Color: Even', 'dpr-adeline-extensions'),

					'param_name'		=> 'tr_border_color_even',

					'edit_field_class'	=> 'vc_column vc_col-sm-6',

					'value'  => '',

				'group'			=> esc_html__('Table Style', 'dpr-adeline-extensions'),

				),



			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Rows Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'rows_typography_title',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'			=> esc_html__('Table Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom headline color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'tr_color',

				'edit_field_class'	=> 'vc_col-sm-3 vc_column ',

				'group'			=> esc_html__('Table Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size. If you leave this field blank will be used default size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'tr_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'			=> esc_html__('Table Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title linne height.Default is 18px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'tr_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'			=> esc_html__('Table Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'tr_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'			=> esc_html__('Table Style', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'tr_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'group'			=> esc_html__('Table Style', 'dpr-adeline-extensions'),

	  		),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font. .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_tr_google_fonts',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'			=> esc_html__('Table Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'tr_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'dependency'		=> array('element' => 'use_tr_google_fonts', 'value' => array('yes')),

				'group'			=> esc_html__('Table Style', 'dpr-adeline-extensions'),

			),





/* Filters */

			array (

				'type' => 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set filter position.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Filter Position', 'dpr-adeline-extensions'),

				'param_name' => 'filter_type',

				'value' => 'none',

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'options' => array (

					esc_attr__('None', 'dpr-adeline-extensions') => 'none',			

					esc_attr__('Tabs', 'dpr-adeline-extensions') => 'tabs',

					esc_attr__('Dropdown', 'dpr-adeline-extensions') => 'dropdown_list'

				),

				'group'				=> esc_html__('Filter', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'dpr_switcher',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('This option allows you to enable ALL button in filter for this grid.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Enable All Button', 'dpr-adeline-extensions'),

				'param_name' => 'enable_all',

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'value' => 'yes',

				'options' => array(

					'yes' => array(

							'label' => '',

							'on' => 'Yes',

							'off' => 'No',

						),

					),

				'group'				=> esc_html__('Filter', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'filter_type', 'value' => 'tabs'),

			),

		    array(

				'type' => 'textfield',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set text for all button.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('All button text', 'dpr-adeline-extensions'),

				'param_name' => 'all_text',

				'value' => 'All Events',

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Filter', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'enable_all', 'value' => 'yes'),

			),

			array(

				'type'             => 'dpr_title',

				'class' => 'separator',

				'text'             => '',

				'param_name'       => 'filer_sep_1',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group'				=> esc_html__('Filter', 'dpr-adeline-extensions'),

			),

			array (

				'type' => 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set filter position.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Filter Position', 'dpr-adeline-extensions'),

				'param_name' => 'filter_position',

				'value' => 'center',

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'options' => array (

					esc_attr__('Left', 'dpr-adeline-extensions') => 'left',			

					esc_attr__('Center', 'dpr-adeline-extensions') => 'center',

					esc_attr__('Right', 'dpr-adeline-extensions') => 'right',

					esc_attr__('Full', 'dpr-adeline-extensions') => 'full',

				),

				'group'				=> esc_html__('Filter', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'filter_type', 'value' => 'tabs'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set filter bar bottom margin.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Filter Bar bottom margin', 'dpr-adeline-extensions'),

				'param_name'		=> 'filter_bar_margin',

				'value' => 25,

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Filter', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'filter_type', 'value' => 'tabs'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set filter buttons spacing.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Filter Buttons Spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'filter_buttons_spacing',

				'value' => 5,

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Filter', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'filter_type', 'value' => 'tabs'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set filter buttons top and bottom padding.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Filter Buttons Top/Bottom Padding', 'dpr-adeline-extensions'),

				'param_name'		=> 'filter_buttons_vertical_padding',

				'value' => 8,

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Filter', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'filter_type', 'value' => 'tabs'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set filter buttons left and right padding.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Filter Buttons Left/Right Padding', 'dpr-adeline-extensions'),

				'param_name'		=> 'filter_buttons_horizontal_padding',

				'value' => 12,

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Filter', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'filter_type', 'value' => 'tabs'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set filter buttons border radius.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Filter Buttons Border Radius', 'dpr-adeline-extensions'),

				'param_name'		=> 'filter_buttons_border_radius',

				'value' => 5,

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Filter', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'filter_type', 'value' => 'tabs'),

			),

			array(

				'type'             => 'dpr_title',

				'class' => 'separator',

				'text'             => '',

				'param_name'       => 'filer_sep_2',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group'				=> esc_html__('Filter', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose filter buttons background color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Buttons Background', 'dpr-adeline-extensions'),

				'param_name'		=> 'filter_buttons_bg_color',

				'value'  => '#f1f2f4',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Filter', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'filter_type', 'value' => 'tabs'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose filter buttons background hover color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Buttons Background: Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'filter_buttons_bg_color_hover',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'value'  => '#D3AE5F',

				'group'				=> esc_html__('Filter', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'filter_type', 'value' => 'tabs'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose filter buttons text color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Buttons Text Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'filter_buttons_color',

				'value'  => '#292933',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Filter', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'filter_type', 'value' => 'tabs'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose filter buttons text hover color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Buttons Text Color: Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'filter_buttons_color_hover',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'value'  => '#ffffff',

				'group'				=> esc_html__('Filter', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'filter_type', 'value' => 'tabs'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose filter buttons border color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Buttons Border Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'filter_border_color',

				'value'  => '#f1f2f4',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Filter', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'filter_type', 'value' => 'tabs'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose filter buttons border hover color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Buttons Border Color: Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'filter_border_color_hover',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'value'  => '#D3AE5F',

				'group'				=> esc_html__('Filter', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'filter_type', 'value' => 'tabs'),

			),

			array (

				'type' => 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set dropdown filter width.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Dropdown Filter Width', 'dpr-adeline-extensions'),

				'param_name' => 'dropdown_width',

				'value' => 'auto',

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'options' => array (

					esc_attr__('Auto', 'dpr-adeline-extensions') => 'auto',			

					esc_attr__('Fullwidth', 'dpr-adeline-extensions') => 'full'

				),

				'group'				=> esc_html__('Filter', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'filter_type', 'value' => 'dropdown_list'),

			),

			array (

				'type' => 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set dropdown filter position.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Dropdown Filter Position', 'dpr-adeline-extensions'),

				'param_name' => 'dropdown_position',

				'value' => 'left',

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'options' => array (

					esc_attr__('Left', 'dpr-adeline-extensions') => 'left',			

					esc_attr__('Right', 'dpr-adeline-extensions') => 'right',

				),

				'group'				=> esc_html__('Filter', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'dropdown_width', 'value' => 'auto'),

			),

/* RESPONSIVE */

			array (

				'type' => 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set mobile view for timetable.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Mobile View', 'dpr-adeline-extensions'),

				'param_name' => 'mobile_view',

				'value' => 'list',

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'options' => array (

					esc_attr__('List', 'dpr-adeline-extensions') => 'list',			

					esc_attr__('Table', 'dpr-adeline-extensions') => 'table'

				),

				'group'				=> esc_html__('Responsive', 'dpr-adeline-extensions'),

			),

			



/* CSS */			

			array(

				'type' => 'css_editor',

				'heading' => __( 'CSS box', 'dpr-adeline-extensions' ),

				'param_name' => 'css',

				'group' => __( 'Design Options', 'dpr-adeline-extensions' ),

			),

		),

	)

);