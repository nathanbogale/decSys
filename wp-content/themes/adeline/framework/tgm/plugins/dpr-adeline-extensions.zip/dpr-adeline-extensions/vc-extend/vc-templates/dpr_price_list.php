<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$unique_id = $css_animation = $el_class = $output = $custom_el_css = $style = $list_items = '';
$symbol_position = $line_style = $line_thickness = $line_color = $img_width = $img_height = $img_radius = $item_spacing = '';
$title_color = $title_font_size = $title_line_height  = $title_letter_spacing = $title_font_style = $title_google_font = $title_typo_style = '';
$subtitle_color = $subtitle_font_size = $subtitle_line_height  = $subtitle_letter_spacing = $subtitle_font_style = $subtitle_google_font = $subtitle_typo_style = '';
$price_color = $price_font_size = $price_line_height  = $price_letter_spacing = $price_font_style = $price_google_font = $price_typo_style = '';



$atts = vc_map_get_attributes( 'dpr_price_list', $atts );
extract( $atts );

$el_class = $this->getExtraClass( $el_class );
if ( '' !== $css_animation && 'none' !== $css_animation ) {
	dpr_enqueue_waypoint_js();
	dpr_enqueue_animate_css();
	$el_class .= ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
}
$unique_id = uniqid('dpr-price-list').'-'.rand(1,9999);

/* Element classes */

$css_classes = array(
	'dpr-price-list',
	$unique_id,
	$el_class,
);

$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->settings['base'], $atts ) );

/* Styles and custom CSS*/
if(isset($line_style) && !empty($line_style)) {
	$custom_el_css .= '.'. esc_js($unique_id).' .price-line {border-bottom-style: '.esc_attr($line_style).' !important;}';
}
if(isset($line_thickness) && $line_thickness != '') {
	$custom_el_css .= '.'. esc_js($unique_id).' .price-line {border-bottom-width: '.esc_attr($line_thickness).'px !important;}';
}
if(isset($line_color) && !empty($line_color)){
	$custom_el_css .= '.'. esc_js($unique_id).' .price-line {border-color: '.esc_attr($line_color).' !important;}';
}

if(isset($item_spacing) && !empty($item_spacing)){
	$custom_el_css .= '.'.esc_js($unique_id).' .dpr-price-list-item {margin-top: '.esc_attr($item_spacing).'px;}';
}
if(!isset($img_width) || $img_width == '') {
	$img_width = 80;
}

$custom_el_css .= '.'. esc_js($unique_id).' .img-wrap img {width: '.esc_js($img_width).'px;}';


if($img_height < 0) {
	$img_height = 0;
}

$custom_el_css .= '.'. esc_js($unique_id).' .img-wrap img {height: '.esc_js($img_height).'px;}';

if(isset($img_radius ) && !empty($img_radius)){
	$custom_el_css .= '.'.esc_js($unique_id).' .img-wrap img {border-radius: '.esc_attr($img_radius).'px;}';
}



/* Output */
$output .= '<div id="'.esc_attr($unique_id).'" class="'.esc_attr($css_class).'">';

if(isset($list_items) && !empty($list_items) && function_exists('vc_param_group_parse_atts')) {
		$list_items = vc_param_group_parse_atts($list_items);
		
		foreach ($list_items as $item) {
			$image_html = '';
			$output .= '<div class="dpr-price-list-item">';
				
				if(isset($item['image_id']) && !empty($item['image_id'])) {
					$image_url = dpr_get_attachment_image_src($item['image_id'], 'full');
					$image_src = adeline_resize( $image_url[0], $img_width, $img_height, true, true, true );
					if(!$image_src) $image_src = $image_url[0];
					$alt_text = get_post_meta($item['image_id'] , '_wp_attachment_image_alt', true);
					$image_html = '<img src="'.esc_url($image_src).'" width="'.esc_attr($img_width).'" height="'.esc_attr($img_height).'" alt ="'.esc_attr($alt_text).'"/>';
					$output .= '<div class="img-wrap">'.$image_html.'</div>';
				}
				$output .= '<div class="text-wrap">';
					$output .= '<div class="text-title-box  clear-fix">';
					if(isset($item['title']) && !empty($item['title'])){
						$title_typo_style = dpr_generate_typography_style($title_color, $title_font_size, $title_line_height, $title_letter_spacing, $title_font_style,$title_google_font);
						$output .= '<h5 class="title" '.$title_typo_style.'>' . esc_html($item['title']) . '</h5>';
					}
					$output .= '<div class="price-line"></div>';
					if(isset($item['price']) && !empty($item['price']) || isset($item['currency_symbol']) && !empty($item['currency_symbol'])){
						$price_html = '';
						if(isset($symbol_position) && $symbol_position == 'after') {
							$price_html = esc_html($item['price']).''.esc_html($item['currency_symbol']);
						}else{
							$price_html = esc_html($item['currency_symbol']).''.esc_html($item['price']);
						}
						$price_typo_style = dpr_generate_typography_style($price_color, $price_font_size, $price_line_height, $price_letter_spacing, $price_font_style,$price_google_font);
						$output .= '<h5 class="price-wrap" '.$price_typo_style.'>' . $price_html . '</h5>';
					}
					$output .= '</div>';
					if(isset($item['description']) && !empty($item['description'])){
						$desc_typo_style = dpr_generate_typography_style($subtitle_color, $subtitle_font_size, $subtitle_line_height, $subtitle_letter_spacing, $subtitle_font_style,$subtitle_google_font);
						$output .= '<div class="text-desc-box"><div '.$desc_typo_style.'>' . wp_kses_post( $item['description']) . '</div></div>';
					}
				$output .= '</div>';
				
		
			$output .= '</div>';	
		}
}



if(!empty($custom_el_css)) {
		$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>");'
						. '})(jQuery);'
					. '</script>';
}
$output .= '</div>';

echo $output;