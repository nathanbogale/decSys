<?php

/**



 * General Options -> Buttons & Submit



 *



 */

Redux::setSection($opt_name, array(

    'title'      => esc_html__('Button & Submit', 'dpr-adeline-extensions'),

    'subsection' => true,

    'id='        => 'general_buttons',

    'fields'     => array(

        array(

            'id'             => 'button_font-size',

            'type'           => 'typography',

            'title'          => esc_html__('Font', 'dpr-adeline-extensions'),

            'output'         => array('input[type="button"]', 'input[type="reset"]', 'input[type="submit"]', '.button, .button,.btn, btn-link'),

            'google'         => false,

            'subsets'        => false,

            'font-size'      => true,

            'font-family'    => false,

            'text-align'     => false,

            'line-height'    => true,

            'word-spacing'   => false,

            'letter-spacing' => true,

            'text-transform' => true,

            'color'          => false,

            'preview'        => false,

            'all_styles'     => false,

            'units'          => 'px',

            'default'        => array(

                'font-size'      => '12px',

                'line-height'    => '18px',

                'font-weight'    => '700',

                'text-transform' => 'uppercase',

                'letter-spacing' => '1px',

            ),

            'hint'           => array(

                'title'   => esc_attr__('Font Size', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify font size and style for button and submit field', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'             => 'button_input_padding',

            'type'           => 'spacing',

            'output'         => array('input[type="button"],input[type="reset"],input[type="submit"],.button, .button,.btn, btn-link'),

            'mode'           => 'padding',

            'units'          => array('px'),

            'display_units'  => true,

            'units_extended' => false,

            'title'          => __('Padding (px)', 'dpr-adeline-extensions'),

            'default'        => array(

                'padding-top'    => '16px',

                'padding-bottom' => '16px',

                'padding-left'   => '30px',

                'padding-right'  => '30px',

                'units'          => 'px',

            ),

            'hint'           => array(

                'title'   => esc_attr__('Padding', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Choose default padding for for button and submit field.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'             => 'button_border_radius',

            'type'           => 'dpr_border_radius',

            'units'          => array('px', '%'),

            'all'            => true,

            'output'         => array('input[type="button"],input[type="reset"],input[type="submit"],.button, .button,.btn, btn-link'),

            'units_extended' => false,

            'title'          => __('Border Radius', 'dpr-adeline-extensions'),

            'default'        => array(

                'border-top-left-radius'     => '5px',

                'border-top-right-radius'    => '5px',

                'border-bottom-right-radius' => '5px',

                'border-bottom-left-radius'  => '5px',

                'units'                      => 'px',

            ),

            'hint'           => array(

                'title'   => esc_attr__('Border Radius', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify border radius for button and submit field.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'button_background',

            'type'     => 'color',

            'output'   => array('background-color' => 'input[type="button"],input[type="reset"],input[type="submit"],.button,.btn, btn-link, .dpr-subscribe .submit',

                'color'                                => '.btn.btn-outlined, btn-link.btn-outlined'),

            'validate' => 'color',

            'title'    => esc_html__('Background Color', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'hint'     => array(

                'title'   => esc_attr__('Background Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set background color for default button and submit field.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'button_background_hover',

            'type'     => 'color',

            'output'   => array('background-color' => 'input[type="button"]:hover,input[type="reset"]:hover,input[type="submit"]:hover,input[type="submit"]:focus,.button:hover, .btn:hover, btn-link:hover, .dpr-subscribe .submit:hover',

                'color'                                => '.btn.btn-outlined:hover, .btn-link.btn-outlined:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Background Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '#424251',

            'hint'     => array(

                'title'   => esc_attr__('Background Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set background color for default button and submit field hover state.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'button_color',

            'type'     => 'color',

            'output'   => array('color' => 'input[type="button"],input[type="reset"],input[type="submit"],.button, .btn, btn-link'),

            'validate' => 'color',

            'title'    => esc_html__('Color', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'hint'     => array(

                'title'   => esc_attr__('Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set color for default button and submit field.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'button_color_hover',

            'type'     => 'color',

            'output'   => array('color' => 'input[type="button"]:hover,input[type="reset"]:hover,input[type="submit"]:hover,.button:hover, .btn:hover, btn-link:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'hint'     => array(

                'title'   => esc_attr__('Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set color for default button and submit field hover state.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'      => 'button_border',

            'type'    => 'border',

            'title'   => __('Button Border', 'dpr-adeline-extensions'),

            'all'     => true,

            'output'  => array('border-color' => 'input[type="button"]:hover,input[type="reset"],input[type="submit"],.button, .btn, btn-link, .dpr-subscribe .submit'),

            'default' => array(

                'border-color'  => '#D3AE5F',

                'border-style'  => 'solid',

                'border-top'    => '2px',

                'border-right'  => '2px',

                'border-bottom' => '2px',

                'border-left'   => '2px',

            ),

            'hint'    => array(

                'title'   => esc_attr__('Button Border', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set border color and style for default button and submit field.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'button_border_color_hover',

            'type'     => 'color',

            'output'   => array('border-color' => 'input[type="button"]:hover,input[type="reset"]:hover,input[type="submit"]:hover,input[type="submit"]:focus,.button:hover, .btn:hover, btn-link:hover, .dpr-subscribe .submit:hover',

                'color'                            => '.btn.btn-outlined:hover, .btn-link.btn-outlined:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Border Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '#424251',

            'hint'     => array(

                'title'   => esc_attr__('Border Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set border color for default button and submit field hover state.', 'dpr-adeline-extensions'),

            ),

        ),

    ),

));
