<?php

/**



 * General Options -> General Styling



 *



 */

Redux::setSection($opt_name, array(

    'title'      => esc_html__('General Styling', 'dpr-adeline-extensions'),

    'id'         => 'general_general_styling',

    'subsection' => true,

    'fields'     => array(

        array(

            'id'       => 'primary_accent_color',

            'type'     => 'color',

            'output'   => array('color' => '.primary-accent-color, .dpr-proof-gallery .proof-gallery-filters li.active a h6,.dpr-proof-gallery .proof-gallery-filters li a:hover h6', 'background-color' => '.primary-accent-bg, .primary-accent-bg-hover:hover, .post-quote-wrapper, .post-link-wrapper, .widget-area .tagcloud a:hover, .single .post-tags a:hover, .woocommerce .widget_price_filter .ui-slider .ui-slider-range, .woocommerce .widget_price_filter .ui-slider .ui-slider-handle', 'border-color' => ' blockquote, .widget-area .tagcloud a:hover, .single .post-tags a:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Primary Site Color', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'hint'     => array(

                'title'   => esc_attr__('Primary Site Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('This color is used as main accent color for many VC elements.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'secondary_accent_color',

            'type'     => 'color',

            'output'   => array('color' => '.secondary-accent-color', 'background-color' => '.secondary-accent-bg, .secondary-accent-bg-hover:hover, .post-quote-wrapper:hover, .post-link-wrapper:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Secondary Site Color', 'dpr-adeline-extensions'),

            'default'  => '#424251',

            'hint'     => array(

                'title'   => esc_attr__('Secondary Site Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('This color is used ... .', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'tertiary_accent_color',

            'type'     => 'color',

            'output'   => array('color' => '.tertiary-accent-color', 'background-color' => '.tertiary-accent-bg, .tertiary-accent-bg-hover:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Tertiary Site Color', 'dpr-adeline-extensions'),

            'default'  => '#A67F79',

            'hint'     => array(

                'title'   => esc_attr__('Tertiary Site Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('This color is used ... .', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'      => 'link-color',

            'type'    => 'link_color',

            'output'  => array('a, .btn.btn-min, .blog-item-readmore'),

            'title'   => __('Default Links Color', 'dpr-adeline-extensions'),

            'default' => array(

                'regular' => '#D3AE5F',

                'hover'   => '#9e895d',

                'active'  => '#9e895d',

                'visited' => '#9e895d',

            ),

            'hint'    => array(

                'title'   => esc_attr__('Default Links Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set default links colors .', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'      => 'headers-link-color',

            'type'    => 'link_color',

            'output'  => array(' h1 a, h2 a, h3 a, h4 a, h5 a , h6 a'),

            'title'   => __('Headers Links Color', 'dpr-adeline-extensions'),

            'default' => array(

                'regular' => '#292933',

                'hover'   => '#D3AE5F',

                'active'  => '#292933',

            ),

            'hint'    => array(

                'title'   => esc_attr__('Headers Links Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set default color for headers links colors eg post titltles etc.', 'dpr-adeline-extensions'),

            ),

        ),

    ),

));
