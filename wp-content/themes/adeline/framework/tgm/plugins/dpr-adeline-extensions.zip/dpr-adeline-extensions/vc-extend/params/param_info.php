<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if(!class_exists('DPR_Info_Param')) {
	class DPR_Info_Param {
		function __construct() {
			if(function_exists('vc_add_shortcode_param')) {
				vc_add_shortcode_param('dpr_info' , array($this, 'dpr_info'));
			}
		}
	
		function dpr_info($settings, $value) {
			$param_name = isset($settings['param_name']) ? $settings['param_name'] : '';
			$class = isset($settings['class']) ? $settings['class'] : '';
			$title = isset($settings['title']) ? $settings['title'] : '';
			$text = isset($settings['text']) ? $settings['text'] : '';
			$icon = isset($settings['icon']) ? $settings['icon'] : '';
			$output = '<div class="dpr-info-param">';
			if ($icon != '') {
			$output .= '<div class="info-icon '.esc_html($icon).'"></div>';
			}
			$output .= '<div class="info-text">';
			if ($title != '') {
			$output .= '<h5>'.esc_html($title).'</h5>';
			}
			$output .= '<span >'.esc_html($text).'</span>';
			$output .= '</div>';
			$output .= '</div>';
			return $output;
		}
		
	}
	
	$DPR_Info_Param = new DPR_Info_Param();
}
