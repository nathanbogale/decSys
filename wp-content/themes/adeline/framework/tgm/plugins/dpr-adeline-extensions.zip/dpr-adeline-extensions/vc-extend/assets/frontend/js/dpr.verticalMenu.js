var $j = jQuery.noConflict();



// On ready

$j( document ).on( 'ready', function() {

	"use strict";

	// Vertical menu style

	dpradelineVerticalMenu();



} );



/* ==============================================

VERTICAL MENU STYLE

============================================== */

function dpradelineVerticalMenu() {

	"use strict"






	// Vars

	var $siteHeader = $j( '.dpr-builder-menu-vertical #dpr-header-inner' ),

		$hasChildren = $j( '.dpr-builder-menu-vertical li.menu-item-has-children' );



	// Add dropdown toggle (plus)

	$hasChildren.children( 'a' ).append( '<span class="dropdown-toggle"></span>' );



	// Toggle dropdowns

	var $dropdownTarget = $j( '.dropdown-toggle' );





	// Add toggle click event

	$dropdownTarget.on( 'tap click', function() {





			var $toggleParentLink = $j( this ).parent( 'a' ),

				$toggleParentLi   = $toggleParentLink.parent( 'li' );



		// Get parent items and dropdown

		var $allParentLis = $toggleParentLi.parents( 'li' ),

			$dropdown     = $toggleParentLi.children( 'ul' );



		// Toogle items

		if ( ! $toggleParentLi.hasClass( 'active' ) ) {

			$hasChildren.not( $allParentLis ).removeClass( 'active' ).children( 'ul' ).slideUp( 'fast' );

			$toggleParentLi.addClass( 'active' ).children( 'ul' ).slideDown( 'fast', function() {

				$siteHeader.getNiceScroll().resize();

			} );

		} else {

			$toggleParentLi.removeClass( 'active' ).children( 'ul' ).slideUp( 'fast', function() {

				$siteHeader.getNiceScroll().resize();

			} );

		}



		// Return false

		return false;



	} );






}