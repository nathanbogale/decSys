<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">



<?php 

	$absolute_path = explode('wp-content', $_SERVER['SCRIPT_FILENAME']);

 	$wp_load = $absolute_path[0] . 'wp-load.php';

	require_once($wp_load);

?>

<head>

<style>

body {padding-top:15px;}

#smile_icon_search {height:500px!important;}

.smile_icon p { font-family:Arial, Helvetica, sans-serif; font-size:15px;}

.smile_icon {padding-left:2px;}

#submiticon {

	background-color:#6B6ECE;

	-moz-border-radius:20px;

	-webkit-border-radius:20px;

	border-radius:20px;

	display:inline-block;

	cursor:pointer;

	color:#ffffff;

	font-family:arial;

	font-size:11px;

	padding:10px 20px;

	text-transform:uppercase;

	font-weight:bold;

	text-decoration:none;

	margin-top:10px;

	margin-bottom:10px;

	float:right;

	border:none !important;

	margin-right:10px;

	box-shadow:none!important;

	

}

#submiticon:hover {

	background-color:#497bbe;

}

#submiticon:active {

	position:relative;

	top:1px;

}

.search-icon {

    font-size: 13px;

    color: #232323;

    background: #f2f2f2;

    border: 1px solid #e2e2e2;

    border-radius: 3px;

    -webkit-box-shadow: none!important;

    -moz-box-shadow: none!important;

    box-shadow: none!important;

	outline-color: transparent !important;

    -webkit-transition: background .3s ease 0s, border-color .3s ease-in-out 0s;

    -moz-transition: background .3s ease 0s, border-color .3s ease-in-out 0s;

    -o-transition: background .3s ease 0s, border-color .3s ease-in-out 0s;

    transition: background .3s ease 0s, border-color .3s ease-in-out 0s;

}

#smile_icon_search {

width:100% !important;

max-height:440px !important;

}

</style>

<link rel="stylesheet" id="vc-icon-manager-css" href="<?php echo plugins_url(); ?>/dpr-adeline-extensions/inc/font_icon_manager/assets/css/icon-manager.css" type="text/css" media="all" />

<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js" ></script>

  <script>

   jQuery(document).ready(function(){

	var parentid = '#' + jQuery('#parentid').val();

	var parentpreview = '#'+jQuery('#parentpreviewid').val();

	var saveid = '#widget-'+jQuery('#widgetid').val()+'-savewidget';

	jQuery(".icons-list li").click(function() {

	var icon = jQuery(this).data('icon');

	jQuery(parentid,top.document).val(icon);

	jQuery(parentid,top.document).trigger( 'change' );

	jQuery(".preview-icon").html("<i class=\'"+icon+"\'></i>");

	jQuery(parentpreviewid,top.document).html("<i class=\'"+icon+"\'></i>");

	jQuery(saveid,top.document).val("Save");

	jQuery(saveid,top.document).removeAttr('disabled')

	});

	jQuery("#submiticon").click(function() {

	var icon = jQuery(".preview-icon").find(">:first-child").attr('class')

	jQuery(parentpreview,top.document).html('<i class="'+ icon + '"></i>');	 

	self.parent.tb_remove();	

	});

  });



	</script>

<?php $fonts = get_option('dpr_font_icons');

				$upload_dir = wp_upload_dir(); 



				if(is_array($fonts))

				{

					foreach($fonts as $font => $info)

					{

					echo '<link rel="stylesheet" href="'.$upload_dir['baseurl'].'/dpr_font_icons/'.$info['style'].'">';	

					}

				}

?>



</head>

<body>

    <?php echo ' <input type ="hidden" name="parentid" id="parentid" value="'.$_GET ["parentid"].'">';

	 	  echo ' <input type ="hidden" name="parentpreviewid" id="parentpreviewid" value="'.$_GET ["parentpreviewid"].'">';	

	 	  echo ' <input type ="hidden" name="widgetid" id="widgetid" value="'.$_GET ["widgetid"].'">';	

				$manager = new DPR_Icon_Manager();

				$manager->admin_scripts();

				$output = $manager->dpr_icon_selector('selector', $_GET ["currenticon"]);

			

				$output .= '<a id="submiticon">Submit</a>';

				print ($output) ?>

</body>

</html>