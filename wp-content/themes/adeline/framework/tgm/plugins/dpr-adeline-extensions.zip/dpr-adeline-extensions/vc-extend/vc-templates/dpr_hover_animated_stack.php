<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$output = $uniqid = $el_class = $css =  $custom_el_css  = $stack_layers = '';

$readmore_show = $link_target = '';

$static_content_show = $title_typo_style = $title_color = $title_color_hover = $title_font_size = $title_line_height = $title_letter_spacing = $title_font_style = $use_google_fonts = $title_google_font = $title_html = '';
$subtitle_typo_style = $subtitle_color = $subtitle_color_hover = $subtitle_font_size = $subtitle_line_height = $subtitle_letter_spacing = $subtitle_font_style = $subtitle_html = '';
$content_typo_style = $content_color = $content_color_hover = $content_font_size = $content_line_height = $content_letter_spacing = $content_font_style = $content_html = '';
$read_more_html =  $title_wrap_html = '';
$content_wrap_html = $static_content_alignment = '';

$min_height = 100;

$atts = vc_map_get_attributes(  $this->getShortcode(), $atts  );

extract( $atts );

$unique_id = uniqid('dpr-hover-animated-stack-').'-'.rand(1,9999);

$el_class = $this->getExtraClass( $el_class );

$css_classes = array(
	'dpr-hover-animated-stack',
	esc_attr($unique_id),
	$el_class
);


$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->settings['base'], $atts ) );


$custom_el_css .= '.'.esc_js($unique_id).' {min-height:'.$min_height.'px}';

if($static_content_show == 'show') {
	if(!empty($title)) {
		$title_typo_style = dpr_generate_typography_style($title_color, $title_font_size, $title_line_height, $title_letter_spacing, $title_font_style,$title_google_font);
		if(isset($link) && strcmp($read_more, 'title') == 0) {
			$link = vc_build_link($link);
			$link_target = !empty($link['target']) ? 'target="'.esc_attr(preg_replace('/\s+/', '', $link['target'])).'"' : '';
			$title_html .= '<h4 class="icon-box-title " '.$title_typo_style.'><a href="'.esc_url($link['url']).'" title="'.esc_attr($link['title']).'" '.$link_target.' rel="'.esc_attr($link['rel']).'">'.wp_kses($title, array('span' => array(),'br' => array())).'</a></h4>';
		}else{
			$title_html .= '<h4 class="icon-box-title" '.$title_typo_style.'>'.wp_kses($title, array('span' => array(), 'br' => array())).'</h4>';
		}
	}
	if(!empty($subtitle)) {
		$subtitle_typo_style = dpr_generate_typography_style($subtitle_color, $subtitle_font_size, $subtitle_line_height, $subtitle_letter_spacing, $subtitle_font_style);
		$subtitle_html .= '<div class="icon-box-subtitle" '.$subtitle_typo_style.' >'.esc_html($subtitle).'</div>';
	}

	if(isset($title) &&!empty($title) || isset($subtitle) && !empty($subtitle)) {
		$title_wrap_html .= '<div class="title-wrap">';
			$title_wrap_html .= $title_html;
			$title_wrap_html .= $subtitle_html;
		$title_wrap_html .= '</div>';
	}
	
	$content_typo_style = dpr_generate_typography_style($content_color, $content_font_size, $content_line_height, $content_letter_spacing, $content_font_style);
	$content_html .= '<div class="description" '.$content_typo_style.'>'.strip_tags($main_content,'<br><br/>').'</div>';	
	
	if(isset($title_color_hover) && !empty($title_color_hover)) {
		$custom_el_css .= '.'.esc_js($unique_id).':hover .icon-box-title {color: '.esc_js($title_color_hover).'!important;}';
	}

	if(isset($subtitle_color_hover) && !empty($subtitle_color_hover)) {
		$custom_el_css .= '.'.esc_js($unique_id).':hover .icon-box-subtitle {color: '.esc_js($subtitle_color_hover).'!important;}';
	}

	if(isset($content_color_hover) && !empty($content_color_hover)) {
		$custom_el_css .= '.'.esc_js($unique_id).':hover .description {color: '.esc_js($content_color_hover).'!important;}';
	}

	// Readmore HTML output
	$read_more_data = dpr_generate_read_more($atts);
	$read_more_html .= $read_more_data[0];
	$custom_el_css .= $read_more_data[1];
	
	
}
	if($static_content_show == 'show') {

	$output .= '<div id="'.esc_attr($unique_id).'" class="dpr-featured-box '.esc_attr($static_content_alignment).' '.vc_shortcode_custom_css_class( $css ).'">';
	
	$output .= '<div class="'.esc_attr($css_class).'">';
	
	} else {

	$output .= '<div id="'.esc_attr($unique_id).'" class="'.esc_attr($css_class).'">';	
	
	}

	if(isset($stack_layers) && !empty($stack_layers) && function_exists('vc_param_group_parse_atts')) {
		$stack_layers = (array) vc_param_group_parse_atts($stack_layers);
		
		foreach($stack_layers as $layer) {
				$layer_class = $layer_typo_style = $transform_hover_text = $image_html = $icon_html = $svg_html = '';
			
				if ($layer['layer_type'] == 'text') {
					$layer_typo_style = dpr_generate_typography_style('', $layer['text_font_size'], $layer['text_line_height'], $layer['text_spacing'], $layer['text_font_style'],$layer['text_google_font']);
				}
				$layer_unique_id = uniqid('hover-animated-layer-').'-'.rand(1,9999);
			
				$layer_type = $layer['layer_type'];
				
				$layer_class .= 'hover-animated-layer layer-type-'.$layer_type;
			
				$layer_class .= ' horizontal-align-'.$layer['content_alignment'];
			
				$layer_class .= ' vertical-align-'.$layer['content_valignment'];
				
				
				if (isset($layer['custom_layer_class']) && $layer['custom_layer_class'] != '') {
					$layer_class .= ' '.$layer['custom_layer_class'].';';
				}
				
				$custom_el_css .= '#'.esc_js($layer_unique_id ).' { transition-property: all;';
			
				if (isset($layer['duration']) && $layer['duration'] != '') {
					$custom_el_css .= 'transition-duration: '.$layer['duration'].'s;';
				}
				if (isset($layer['timing_function']) && $layer['timing_function'] != '') {
					$custom_el_css .= 'transition-timing-function: '.$layer['timing_function'].';';
				}
				if (isset($layer['delay']) && $layer['delay'] != '') {
					$custom_el_css .= 'transition-delay: '.$layer['delay'].'s;';
				}
				if (isset($layer['color_idle']) && $layer['color_idle'] != '') {
					$custom_el_css .= 'color: '.$layer['color_idle'].';';
				}			
				if (isset($layer['opacity_idle']) && $layer['opacity_idle'] != '') {
					$custom_el_css .= 'opacity: '.$layer['opacity_idle'].';';
					
					
				}
				
				$custom_el_css .= '}';
			
				$custom_el_css .= '#'.esc_js($unique_id ).':hover #'.esc_js($layer_unique_id ).' { transition-property: all;';
			

				if (isset($layer['color_hover']) && $layer['color_hover'] != '') {
					$custom_el_css .= 'color: '.$layer['color_hover'].';';
				}			
				if (isset($layer['opacity_hover']) && $layer['opacity_hover'] != '') {
					$custom_el_css .= 'opacity: '.$layer['opacity_hover'].';';
				}
				
				if (isset($layer['rotate_hover']) && $layer['rotate_hover'] != '') {
					$transform_hover_text .= ' rotate('.$layer['rotate_hover'].'deg)';
				}
				if (isset($layer['scale_hover']) && $layer['scale_hover'] != '') {
					$transform_hover_text .= ' scale('.$layer['scale_hover'].')';
				}
				if (isset($layer['translatex_hover']) && $layer['translatex_hover'] != '') {
					$transform_hover_text .= ' translateX( '.$layer['translatex_hover'].$layer['translatex_units_hover'].')';
				}
				if (isset($layer['translatey_hover']) && $layer['translatey_hover'] != '') {
					$transform_hover_text .= ' translateY( '.$layer['translatey_hover'].$layer['translatey_units_hover'].')';
				}
				if ($transform_hover_text != '') {
					$custom_el_css .= 'transform: '.$transform_hover_text.';';
				}
				$custom_el_css .= '}';			
			
			
				$output .= '<div id="'.esc_attr($layer_unique_id).'" class= "'.esc_attr($layer_class).'">';
					
						switch ($layer['layer_type']) {
							case 'image':
								
								if (isset($layer['image_id']) && $layer['image_id'] != '') {
								$img_style = '';
								$image_url = dpr_get_attachment_image_src( $layer['image_id'], 'full' );
								if (! empty( $layer['img_size'] )){

									$image_src = adeline_resize( $image_url[0], $layer['img_size'], $layer['img_size'], true, true, true );
									if(!$image_src) $image_src = $image_url[0];

								} else {

									$image_src = $image_url[0];

								}
								
								if ( ! empty( $layer['img_size'] ) ) {

									$img_style .= 'style="';

									if ( isset( $layer['img_size'] ) && ! empty( $layer['img_size'] ) ) {
										$img_style .= 'width:' . esc_attr($layer['img_size']) . 'px; ';
									}

									$img_style .= '"';

								}
								
								$output .=  '<div class="layer-inner-wrap"><img src="' . esc_url($image_src) . '" ' . $img_style . '  alt=""/></div>';								
								
								}
								break;
								
							case 'text':
								if (isset($layer['layer_text']) && $layer['layer_text'] != '') {
								$output .= '<div class="layer-inner-wrap" '. $layer_typo_style.'>'.$layer['layer_text'].'</div>';
								}
								break;

							case 'icon':
								if (isset($layer['icon']) && $layer['icon'] != '') {
									$icon_inline_style = '';
									if ( isset( $layer['icon_size'] ) && ! empty( $layer['icon_size'] ) ) {
										$icon_inline_style .= 'style="font-size: ' . esc_attr($layer['icon_size']) . 'px;" ';
									}
									$output .= '<div class="layer-inner-wrap"><i class="'.$layer['icon'].'" '.$icon_inline_style.'></i></div>';
								}
						
								break;								

							
							case 'svg':
								if (isset($layer['inline_svg']) && $layer['inline_svg'] != '') {
									$svg_inline_style = '';
									if ( isset( $layer['svg_size'] ) && ! empty( $layer['svg_size'] ) ) {
										$svg_inline_style .= 'style="max-width: ' . esc_attr($layer['svg_size']) . 'px;" ';
									}
									$output .= '<div class="layer-inner-wrap" '.$svg_inline_style.'>'.rawurldecode(base64_decode($layer['inline_svg'])).'</div>';
									if (isset($layer['color_idle']) && $layer['color_idle'] != '') {
										$custom_el_css .= '#'.esc_js($layer_unique_id ).' svg path { fill: '.$layer['color_idle'].';}';
										$custom_el_css .= '#'.esc_js($layer_unique_id ).' svg path { transition: fill .4s ease;  }';
										}
									if (isset($layer['color_hover']) && $layer['color_hover'] != '') {
										$custom_el_css .= '#'.esc_js($unique_id ).':hover #'.esc_js($layer_unique_id ).' svg path {fill: '.$layer['color_hover'].' !important;}';
									}
								}
								break;
							
							case 'html':
								if (isset($layer['html_code']) && $layer['html_code'] != '') {
									$html_inline_style = '';
									if ( isset( $layer['html_size'] ) && ! empty( $layer['html_size'] ) ) {
										$html_inline_style .= 'style="max-width: ' . esc_attr($layer['html_size']) . 'px;" ';
									}
									$output .= '<div class="layer-inner-wrap" '.$html_inline_style.'>'.rawurldecode(base64_decode($layer['html_code'])).'</div>';

								}
								break;								
						}
		
			$output .= '</div>';
				
			}
		}
		

$output .= '</div>';

if($static_content_show == 'show') {

	$output .= '<div class="head-wrap">';
	$output .= $title_wrap_html;
	$output .= '</div>';
	if(isset($main_content) && !empty($main_content) || isset($readmore_show) && $readmore_show == 'show') {
				$output .= '<div class="container-info">';
					$output .= '<div class="content-cell">';
						$output .= $content_html;
						$output .= $read_more_html;
					$output .= '</div>';
				$output .= '</div>';
			}	

	if(isset($link) && strcmp($read_more, 'box') == 0) {
		$link = vc_build_link( $link );
		$link_target = !empty($link['target']) ? 'target="'.esc_attr(preg_replace('/\s+/', '', $link['target'])).'"' : '';
		$output .= '<a href="'.esc_url($link['url']).'" class="dpr-cover-link" title="'.esc_attr($link['title']).'" '.$link_target.' rel="'.esc_attr($link['rel']).'"></a>';
	}	
	
	
	$output .= '</div>';

}	

if(!empty($custom_el_css)) {
		$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>");'
						. '})(jQuery);'
					. '</script>';
}

echo $output;