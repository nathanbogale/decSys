<?php

// Way to set menu, import revolution slider, set blog page and set home page

if (!function_exists('dpr_wbc_extended')):

    add_action('wbc_importer_after_content_import', 'dpr_wbc_extended', 10, 2);

    function dpr_wbc_extended($demo_active_import, $demo_directory_path)
{

        reset($demo_active_import);

        $current_key = key($demo_active_import);

        if (isset($demo_active_import[$current_key]['directory']) && !empty($demo_active_import[$current_key]['directory'])):

            /**

             * Import icons

             *

             */

            // Set icons zip name

            $wbc_icons_array = array(

                '01_main_demo' => array('adeline-icons.zip'),

            );

            if (array_key_exists($demo_active_import[$current_key]['directory'], $wbc_icons_array)):

                $icon_font_manager = new DPR_Font_Icon_Manager;

                $icon_font_manager->DPR_icon_manager_init();

                $icon_manager = new DPR_Icon_Manager;

                $wbc_icon_imports = $wbc_icons_array[$demo_active_import[$current_key]['directory']];

                if (is_array($wbc_icon_imports)):

                    foreach ($wbc_icon_imports as $wbc_icon_import):

                        if (file_exists($demo_directory_path . $wbc_icon_import)):

                            $icon_manager->import_icon_font1($demo_directory_path . $wbc_icon_import);

                        endif;

                    endforeach;

                endif;

            endif; // end Import icons

            /**

             * Import revslider(s)

             *

             */

            if (class_exists('RevSlider')):

                // Set sliders zip name

                $wbc_sliders_array = array(

                    '01_main_demo' => array('home-1.zip', 'home-4.zip', 'home-5.zip', 'home-6-inner.zip', 'home-6.zip', 'home-7.zip', 'home-8.zip'),

                );

                if (array_key_exists($demo_active_import[$current_key]['directory'], $wbc_sliders_array)):

                    $wbc_slider_imports = $wbc_sliders_array[$demo_active_import[$current_key]['directory']];

                    if (is_array($wbc_slider_imports)):

                        foreach ($wbc_slider_imports as $wbc_slider_import):

                            if (file_exists($demo_directory_path . $wbc_slider_import)):

                                $slider = new RevSlider();

                                $slider->importSliderFromPost(true, true, $demo_directory_path . $wbc_slider_import);

                            endif;

                        endforeach;

                    endif;

                endif;

            endif; // end Import slider(s)

            /**

             * Import essential grids(s)

             *

             */

            if (class_exists('Essential_Grid')):

                // Set essential grid json name

                require_once ABSPATH . 'wp-content/plugins/essential-grid/essential-grid.php';
                require_once ABSPATH . 'wp-admin/includes/file.php';
                WP_Filesystem();
                global $wp_filesystem;

                $wbc_esgrids_array = array(

                    '01_main_demo' => array('ess_grid.json'),

                );

                if (array_key_exists($demo_active_import[$current_key]['directory'], $wbc_esgrids_array)):

                    $wbc_esgrid_imports = $wbc_esgrids_array[$demo_active_import[$current_key]['directory']];

                    if (is_array($wbc_esgrid_imports)):

                        foreach ($wbc_esgrid_imports as $wbc_esgrid_import):

                            if (file_exists($demo_directory_path . $wbc_esgrid_import)):
                                $file    = $demo_directory_path . $wbc_esgrid_import;
                                $es_data = json_decode($wp_filesystem->get_contents($file), true);
                                $im      = new Essential_Grid_Import();

                                $overwriteData = array(
                                    'global-styles-overwrite' => 'overwrite',
                                );

                                // Create Overwrite & Ids data
                                $skins        = @$es_data['skins'];
                                $export_skins = array();
                                if (!empty($skins) && is_array($skins)) {
                                    foreach ($skins as $skin) {
                                        $export_skins[]                                 = $skin['id'];
                                        $overwriteData['skin-overwrite-' . $skin['id']] = 'overwrite';
                                    }
                                }

                                $export_navigation_skins = array();
                                $navigation_skins        = @$es_data['navigation-skins'];

                                foreach ((array) $navigation_skins as $nav_skin) {
                                    $export_navigation_skins[]                              = $nav_skin['id'];
                                    $overwriteData['nav-skin-overwrite-' . $nav_skin['id']] = 'overwrite';
                                }

                                $export_grids = array();
                                $grids        = @$es_data['grids'];
                                if (!empty($grids) && is_array($grids)) {
                                    foreach ($grids as $grid) {
                                        $export_grids[]                                 = $grid['id'];
                                        $overwriteData['grid-overwrite-' . $grid['id']] = 'overwrite';
                                    }
                                }

                                $export_elements = array();
                                $elements        = @$es_data['elements'];
                                if (!empty($elements) && is_array($elements)) {
                                    foreach ($elements as $element) {
                                        $export_elements[]                                     = $element['id'];
                                        $overwriteData['elements-overwrite-' . $element['id']] = 'overwrite';
                                    }
                                }

                                $export_custom_meta = array();
                                $custom_metas       = @$es_data['custom-meta'];
                                if (!empty($custom_metas) && is_array($custom_metas)) {
                                    foreach ($custom_metas as $custom_meta) {
                                        $export_custom_meta[]                                             = $custom_meta['handle'];
                                        $overwriteData['custom-meta-overwrite-' . $custom_meta['handle']] = 'overwrite';
                                    }
                                }

                                $export_punch_fonts = array();
                                $custom_fonts       = @$es_data['punch-fonts'];
                                if (!empty($custom_fonts) && is_array($custom_fonts)) {
                                    foreach ($custom_fonts as $custom_font) {
                                        $export_punch_fonts[]                                             = $custom_font['handle'];
                                        $overwriteData['punch-fonts-overwrite-' . $custom_font['handle']] = 'overwrite';
                                    }
                                }

                                $im->set_overwrite_data($overwriteData); //set overwrite data global to class

                                // Import data
                                $skins = @$es_data['skins'];
                                if (!empty($skins) && is_array($skins)) {
                                    if (!empty($skins)) {
                                        $skins_imported = $im->import_skins($skins, $export_skins,$check_append = true);
                                    }
                                }

                                $navigation_skins = @$es_data['navigation-skins'];
                                if (!empty($navigation_skins) && is_array($navigation_skins)) {
                                    if (!empty($navigation_skins)) {
                                        $navigation_skins_imported = $im->import_navigation_skins(@$navigation_skins, $export_navigation_skins);
                                    }
                                }

                                $grids = @$es_data['grids'];
                                if (!empty($grids) && is_array($grids)) {
                                    if (!empty($grids)) {
                                        $grids_imported = $im->import_grids($grids, $export_grids);
                                    }
                                }

                                $elements = @$es_data['elements'];
                                if (!empty($elements) && is_array($elements)) {
                                    if (!empty($elements)) {
                                        $elements_imported = $im->import_elements(@$elements, $export_elements);
                                    }
                                }

                                $custom_metas = @$es_data['custom-meta'];
                                if (!empty($custom_metas) && is_array($custom_metas)) {
                                    if (!empty($custom_metas)) {
                                        $custom_metas_imported = $im->import_custom_meta($custom_metas, $export_custom_meta);
                                    }
                                }

                                $custom_fonts = @$es_data['punch-fonts'];
                                if (!empty($custom_fonts) && is_array($custom_fonts)) {
                                    if (!empty($custom_fonts)) {
                                        $custom_fonts_imported = $im->import_punch_fonts($custom_fonts, $export_punch_fonts);
                                    }
                                }

                                if (@$es_data['import-global-styles'] == 'on') {
                                    $global_css = @$es_data['global-css'];

                                    $tglobal_css = stripslashes($global_css);
                                    if (empty($tglobal_css)) {
                                        $tglobal_css = $global_css;
                                    }

                                    $global_styles_imported = $im->import_global_styles($tglobal_css);
                                }

                            endif;

                        endforeach;

                    endif;

                    global $table_prefix,$wpdb;
                    $myrows = $wpdb->get_results('SELECT id, postparams, params FROM ' . $table_prefix . 'eg_grids');
                    foreach ($myrows as $myrow) {
                        $postparams = json_decode($myrow->postparams);
                        if (isset($postparams->post_category) && ($postparams->post_category != "")) {
                            $categories                  = explode(',', $postparams->post_category);
                            $params                      = json_decode($myrow->params);
                            $params->{'filter-selected'} = $categories;
                            $wpdb->update(
                                $table_prefix . 'eg_grids',
                                array(
                                    'params' => json_encode($params),
                                ),
                                array('ID' => $myrow->id),
                                array(
                                    '%s',
                                ),
                                array('%d')
                            );
                        }
                    }

                endif;

            endif; // end Import esgrid(s)

            /**

             * Set HomePage

             *

             */

            $wbc_home_pages = array(

                '01_main_demo' => 'Home 1',

            );

            if (array_key_exists($demo_active_import[$current_key]['directory'], $wbc_home_pages)):

                $home_page = get_page_by_title($wbc_home_pages[$demo_active_import[$current_key]['directory']]);

                if (isset($home_page->ID)):

                    update_option('page_on_front', $home_page->ID);

                    update_option('show_on_front', 'page');

                endif;

            endif; // end set home page page

            /**

             * Set BlogPage

             *

             */

            $wbc_blog_pages = array(

                '01_main_demo' => 'Blog',

            );

            if (array_key_exists($demo_active_import[$current_key]['directory'], $wbc_blog_pages)):

                $blog_page = get_page_by_title($wbc_blog_pages[$demo_active_import[$current_key]['directory']]);

                if (isset($blog_page->ID)):

                    update_option('page_for_posts', $blog_page->ID);

                endif;

            endif; // end set blog page

            /**

             * Assign menus to right menu positions

             *

             */

            switch ($demo_active_import[$current_key]['directory']) {

                case '01_main_demo':

                    $theme_menus = array(

                        array("name" => "Main menu", "location" => "main_menu"),

                        array("name" => "Main left", "location" => "centered_menu_left"),

                        array("name" => "Main right", "location" => "centered_menu_right"),

                        array("name" => "Full screen menu", "location" => "fullscreen_menu"),

                    );

                    break;

                default:

                    $theme_menus = array();

            }

            $locations = get_theme_mod('nav_menu_locations');

            foreach ($theme_menus as $menu) {

                $term = get_term_by('name', $menu['name'], 'nav_menu');

                $locations[$menu['location']] = $term->term_id;

            }

            set_theme_mod('nav_menu_locations', $locations);

        endif;

    } // end easyweb_wbc_extended function

endif;
