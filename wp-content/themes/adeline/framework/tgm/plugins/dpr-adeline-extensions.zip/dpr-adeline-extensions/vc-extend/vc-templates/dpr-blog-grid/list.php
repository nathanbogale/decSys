<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
/*
List Style Blog Grid Shortcode Item
*/
?>
<div class="entry-content <?php echo esc_attr($conent_alignment) ?>"">
<header class="blog-item-header clr">
	<h2 class="blog-item-title entry-title" <?php echo $title_typo_style ?>>
		<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" rel="bookmark"><?php the_title(); ?></a>
	</h2><!-- blog-item-title -->
</header><!-- blog-item-header -->
<?php
    // Get meta sections
    $sections = explode(',', $meta_included);
    // Return if sections are empty
    if ( empty( $sections ) ) {
        return;
    }
    
    if ( 'post' == get_post_type() ) { ?>
    
    
        <ul class="meta clr ">
    
            <?php
            // Loop through meta sections
            foreach ( $sections as $section ) { ?>
    
                <?php if ( 'author' == $section ) { ?>
                    <li class="meta-author"<?php adeline_schema_markup( 'author_name' ); ?>><?php echo the_author_posts_link(); ?></li>
                <?php } ?>
    
                <?php if ( 'date' == $section ) { ?>
                    <li class="meta-date"<?php adeline_schema_markup( 'publish_date' ); ?>><?php echo get_the_date(); ?></li>
                <?php } ?>
    
                <?php if ( 'category' == $section ) { ?>
                    <li class="meta-cat"><?php the_category( ' , ', get_the_ID() ); ?></li>
                <?php } ?>
    
                <?php if ( 'comments' == $section && comments_open() && ! post_password_required() ) { ?>
                    <li class="meta-comments"><?php comments_popup_link( esc_html__( '0 Comments', 'dpr-adeline-extensions' ), esc_html__( '1 Comment',  'dpr-adeline-extensions' ), esc_html__( '% Comments', 'dpr-adeline-extensions' ), 'comments-link' ); ?></li>
                <?php } ?>
    
            <?php } ?> 
            
        </ul>
    
        
    <?php } ?>
</div>
