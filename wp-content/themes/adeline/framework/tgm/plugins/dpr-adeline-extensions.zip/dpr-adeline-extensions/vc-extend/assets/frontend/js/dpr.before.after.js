!function(t){"function"==typeof define&&define.amd?define([],t):"undefined"!=typeof module&&null!==module&&module.exports?module.exports=t:t()}(function(){var t=Object.assign||window.jQuery&&jQuery.extend,e=8,n=window.requestAnimationFrame||window.webkitRequestAnimationFrame||window.mozRequestAnimationFrame||window.oRequestAnimationFrame||window.msRequestAnimationFrame||function(t,e){return window.setTimeout(function(){t()},25)},i={textarea:!0,input:!0,select:!0,button:!0},a={move:"mousemove",cancel:"mouseup dragstart",end:"mouseup"},o={move:"touchmove",cancel:"touchend",end:"touchend"},c=/\s+/,r={bubbles:!0,cancelable:!0},u=Symbol("events");function d(t){return t[u]||(t[u]={})}function s(t,e,n,i,a){e=e.split(c);var o,r=d(t),u=e.length;function s(t){n(t,i)}for(;u--;)(r[o=e[u]]||(r[o]=[])).push([n,s]),t.addEventListener(o,s)}function f(t,e,n,i){e=e.split(c);var a,o,r,u=d(t),s=e.length;if(u)for(;s--;)if(o=u[a=e[s]])for(r=o.length;r--;)o[r][0]===n&&(t.removeEventListener(a,o[r][1]),o.splice(r,1))}function v(e,n,i){var a=function(t){return new CustomEvent(t,r)}(n);i&&t(a,i),e.dispatchEvent(a)}function l(){}function m(t){t.preventDefault()}function p(t,e){var n,i;if(t.identifiedTouch)return t.identifiedTouch(e);for(n=-1,i=t.length;++n<i;)if(t[n].identifier===e)return t[n]}function h(t,e){var n=p(t.changedTouches,e.identifier);if(n&&(n.pageX!==e.pageX||n.pageY!==e.pageY))return n}function g(t,e){Y(t,e,t,y)}function w(t,e){y()}function y(){f(document,a.move,g),f(document,a.cancel,w)}function X(t){f(document,o.move,t.touchmove),f(document,o.cancel,t.touchend)}function Y(t,n,i,a){var o=i.pageX-n.pageX,c=i.pageY-n.pageY;o*o+c*c<e*e||function(t,e,n,i,a,o){var c=t.targetTouches,r=t.timeStamp-e.timeStamp,u={altKey:t.altKey,ctrlKey:t.ctrlKey,shiftKey:t.shiftKey,startX:e.pageX,startY:e.pageY,distX:i,distY:a,deltaX:i,deltaY:a,pageX:n.pageX,pageY:n.pageY,velocityX:i/r,velocityY:a/r,identifier:e.identifier,targetTouches:c,finger:c?c.length:1,enableMove:function(){this.moveEnabled=!0,this.enableMove=l,t.preventDefault()}};v(e.target,"movestart",u),o(e)}(t,n,i,o,c,a)}function b(t,e){var n=e.timer;e.touch=t,e.timeStamp=t.timeStamp,n.kick()}function T(t,e){var n=e.target,i=e.event,o=e.timer;f(document,a.move,b),f(document,a.end,T),_(n,i,o,function(){setTimeout(function(){f(n,"click",m)},0)})}function S(t,e){var n=e.target,i=e.event,a=e.timer;p(t.changedTouches,i.identifier)&&(!function(t){f(document,o.move,t.activeTouchmove),f(document,o.end,t.activeTouchend)}(e),_(n,i,a))}function _(t,e,n,i){n.end(function(){return v(t,"moveend",e),i&&i()})}if(s(document,"mousedown",function(t){(function(t){return 1===t.which&&!t.ctrlKey&&!t.altKey})(t)&&(function(t){return!!i[t.target.tagName.toLowerCase()]}(t)||(s(document,a.move,g,t),s(document,a.cancel,w,t)))}),s(document,"touchstart",function(t){if(!i[t.target.tagName.toLowerCase()]){var e=t.changedTouches[0],n={target:e.target,pageX:e.pageX,pageY:e.pageY,identifier:e.identifier,touchmove:function(t,e){!function(t,e){var n=h(t,e);n&&Y(t,e,n,X)}(t,e)},touchend:function(t,e){!function(t,e){p(t.changedTouches,e.identifier)&&X(e)}(t,e)}};s(document,o.move,n.touchmove,n),s(document,o.cancel,n.touchend,n)}}),s(document,"movestart",function(t){if(!t.defaultPrevented&&t.moveEnabled){var e={startX:t.startX,startY:t.startY,pageX:t.pageX,pageY:t.pageY,distX:t.distX,distY:t.distY,deltaX:t.deltaX,deltaY:t.deltaY,velocityX:t.velocityX,velocityY:t.velocityY,identifier:t.identifier,targetTouches:t.targetTouches,finger:t.finger},i={target:t.target,event:e,timer:new function(t){var e=t,i=!1,a=!1;function o(t){i?(e(),n(o),a=!0,i=!1):a=!1}this.kick=function(t){i=!0,a||o()},this.end=function(t){var n=e;t&&(a?(e=i?function(){n(),t()}:t,i=!0):t())}}(function(t){(function(t,e,n){var i=n-t.timeStamp;t.distX=e.pageX-t.startX,t.distY=e.pageY-t.startY,t.deltaX=e.pageX-t.pageX,t.deltaY=e.pageY-t.pageY,t.velocityX=.3*t.velocityX+.7*t.deltaX/i,t.velocityY=.3*t.velocityY+.7*t.deltaY/i,t.pageX=e.pageX,t.pageY=e.pageY})(e,i.touch,i.timeStamp),v(i.target,"move",e)}),touch:void 0,timeStamp:t.timeStamp};void 0===t.identifier?(s(t.target,"click",m),s(document,a.move,b,i),s(document,a.end,T,i)):(i.activeTouchmove=function(t,e){!function(t,e){var n=e.event,i=e.timer,a=h(t,n);a&&(t.preventDefault(),n.targetTouches=t.targetTouches,e.touch=a,e.timeStamp=t.timeStamp,i.kick())}(t,e)},i.activeTouchend=function(t,e){S(t,e)},s(document,o.move,i.activeTouchmove,i),s(document,o.end,i.activeTouchend,i))}}),window.jQuery){var k="startX startY pageX pageY distX distY deltaX deltaY velocityX velocityY".split(" ");jQuery.event.special.movestart={setup:function(){return s(this,"movestart",x),!1},teardown:function(){return f(this,"movestart",x),!1},add:K},jQuery.event.special.move={setup:function(){return s(this,"movestart",C),!1},teardown:function(){return f(this,"movestart",C),!1},add:K},jQuery.event.special.moveend={setup:function(){return s(this,"movestart",j),!1},teardown:function(){return f(this,"movestart",j),!1},add:K}}function x(t){t.enableMove()}function C(t){t.enableMove()}function j(t){t.enableMove()}function K(t){var e=t.handler;t.handler=function(t){for(var n,i=k.length;i--;)t[n=k[i]]=t.originalEvent[n];e.apply(this,arguments)}}}),function(t){t.fn.twentytwenty=function(e){e=t.extend({default_offset_pct:.5,orientation:"horizontal",before_label:"Before",after_label:"After",no_overlay:!1},e);return this.each(function(){var n=e.default_offset_pct,i=t(this),a=e.orientation,o="vertical"===a?"down":"left",c="vertical"===a?"up":"right";i.wrap("<div class='twentytwenty-wrapper twentytwenty-"+a+"'></div>"),e.no_overlay||i.append("<div class='twentytwenty-overlay'></div>");var r=i.find("img:first"),u=i.find("img:last");i.append("<div class='twentytwenty-handle'></div>");var d=i.find(".twentytwenty-handle");d.append("<span class='twentytwenty-"+o+"-arrow'></span>"),d.append("<span class='twentytwenty-"+c+"-arrow'></span>"),i.addClass("twentytwenty-container"),r.addClass("twentytwenty-before"),u.addClass("twentytwenty-after");var s=i.find(".twentytwenty-overlay");s.append("<div class='twentytwenty-before-label' data-content='"+e.before_label+"'></div>"),s.append("<div class='twentytwenty-after-label' data-content='"+e.after_label+"'></div>");var f=function(t){var e,n,o,c=(e=t,n=r.width(),o=r.height(),{w:n+"px",h:o+"px",cw:e*n+"px",ch:e*o+"px"});d.css("vertical"===a?"top":"left","vertical"===a?c.ch:c.cw),function(t){"vertical"===a?(r.css("clip","rect(0,"+t.w+","+t.ch+",0)"),u.css("clip","rect("+t.ch+","+t.w+","+t.h+",0)")):(r.css("clip","rect(0,"+t.cw+","+t.h+",0)"),u.css("clip","rect(0,"+t.w+","+t.h+","+t.cw+")")),i.css("height",t.h)}(c)};t(window).on("resize.twentytwenty",function(t){f(n)});var v=0,l=0,m=0,p=0;d.on("movestart",function(t){(t.distX>t.distY&&t.distX<-t.distY||t.distX<t.distY&&t.distX>-t.distY)&&"vertical"!==a?t.preventDefault():(t.distX<t.distY&&t.distX<-t.distY||t.distX>t.distY&&t.distX>-t.distY)&&"vertical"===a&&t.preventDefault(),i.addClass("active"),v=i.offset().left,l=i.offset().top,m=r.width(),p=r.height()}),d.on("moveend",function(t){i.removeClass("active")}),d.on("move",function(t){i.hasClass("active")&&((n="vertical"===a?(t.pageY-l)/p:(t.pageX-v)/m)<0&&(n=0),n>1&&(n=1),f(n))}),i.find("img").on("mousedown",function(t){t.preventDefault()}),t(window).trigger("resize.twentytwenty")})}}(jQuery);

var $j = jQuery.noConflict();

$j( document ).on( 'ready', function() {
	"use strict";
	// Custom select
	dprInitializeBeforeAfter();
} );

/* ==============================================
BEFORE AFTER
============================================== */
function dprInitializeBeforeAfter() {
	"use strict"
    $j(function(){

      $j(".dpr-before-after-images").each(function(){
        var container = this;
        var options = {
          before_label : '',
          after_label  : '',
          orientation  : 'horizontal',
          default_offset_pct : 0.5 
        };
        if( $j(container).data('offset') ){
          options.default_offset_pct = Number( $j(container).data('offset') );
        }
        if( $j(container).data('orientation') ){
          options.orientation = $j(container).data('orientation');
        }
        if( $j(container).data('label-before') ){
          options.before_label = $j(container).data('label-before');
        }
        if( $j(container).data('label-after') ){
          options.after_label = $j(container).data('label-after');
        }
        $j(container).imagesLoaded( function() {
          $j(container).twentytwenty(options);
        });
      });



    });
}