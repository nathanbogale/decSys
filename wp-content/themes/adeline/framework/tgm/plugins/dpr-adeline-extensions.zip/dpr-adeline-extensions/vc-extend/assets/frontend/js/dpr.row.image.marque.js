var $j = jQuery.noConflict();



$j( document ).on( 'ready', function() {

	"use strict";

	// Custom select

	dprInitializeImageMarque();

} );



/* ==============================================

ROW IMAGE MARQUE

============================================== */

function dprInitializeImageMarque() {

	

			$j('.dpr_row_image_marque').each(function () {

				var $self =  $j(this),
					$onhoveropt = '',
					$speed = $self.attr('data-speed'), 
					$direction = $self.attr('data-direction'),
					$onhover = $self.attr('data-onhover'),
					$marque = $self.find('.simply-scroll-list');
				    
				 if($self.attr('data-onhover') == 'yes') {
					$onhoveropt = true;
					} else {
					$onhoveropt = false;	
					}
				$speed = parseInt($speed/24);
				
				$marque.simplyScroll({
					speed: $speed,
					direction:$direction,
					pauseOnHover:$onhoveropt

				});



			});

}
			
										