<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$unique_id = $css_animation = $el_class = $output = $custom_el_css = $style = $use_link = $box_link = $flip_box_height = $flip_box_radius = '';
$front_title = $title_color = $title_font_size = $title_line_height  = $title_letter_spacing = $title_font_style = $title_google_font = $title_typo_style = '';
$front_subtitle = $subtitle_color = $subtitle_font_size = $subtitle_line_height  = $subtitle_letter_spacing = $subtitle_font_style = $subtitle_google_font = $subtitle_typo_style = '';
$label_text = $label_color = $label_font_size = $label_line_height  = $label_letter_spacing = $label_font_style = $label_google_font = $label_typo_style = '';
$back_description = $content_color = $content_font_size = $content_line_height  = $content_letter_spacing = $content_font_style = $content_google_font = $content_typo_style = '';
$front_bg_type = $front_bg_color = $front_image_id = $front_content_alignment = $back_bg_type = $back_bg_color = $back_image_id = $back_content_alignment = $front_add_class = $back_add_class = '';
$enable_label = $label_position = $label_size = $label_bg_color = $label_bg_radius = $enable_label_shadow = $label_shadow = $label_content_type = $label_text = $icon = $icon_color = $icon_font_size = $label_image_id = $label_image_width = '';
$title_html = $subtitle_html = $description_html = $label_html = $box_link_html = '';


$atts = vc_map_get_attributes( 'dpr_flip_box', $atts );
extract( $atts );

$el_class = $this->getExtraClass( $el_class );
if ( '' !== $css_animation && 'none' !== $css_animation ) {
	dpr_enqueue_waypoint_js();
	dpr_enqueue_animate_css();
	$el_class .= ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
}
$unique_id = uniqid('dpr-flip-box-').'-'.rand(1,9999);

/* Element classes */
if(isset($style)) {
	$el_class .= ' '.$style;
}


$css_classes = array(
	'dpr-flip-box dpr-flip-item',
	$unique_id,
	$el_class,
);

$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->settings['base'], $atts ) );

/* Styles and custom CSS*/

if(isset($front_content_alignment) && $front_content_alignment !='') {
	$front_add_class .= 'text-'.$front_content_alignment;
}
if(isset($back_content_alignment) && $back_content_alignment !='') {
	$back_add_class .= 'text-'.$back_content_alignment;
}
if(isset($flip_box_height) && $flip_box_height !='') {
	$custom_el_css .= '.'.esc_js($unique_id).' .flip-wrap-front, .'.esc_js($unique_id).' .flip-wrap-back {min-height: '.esc_js($flip_box_height).'px;}';
}
if(isset($flip_box_radius) && $flip_box_radius !='') {
	$custom_el_css .= '.'.esc_js($unique_id).' .flip-wrap {border-radius: '.esc_js($flip_box_radius).'px;}';
}
if(isset($front_bg_type) && $front_bg_type =='color') {
	if(isset($front_bg_color) && $front_bg_color !='') {
		$custom_el_css .= '.'.esc_js($unique_id).' .flip-wrap-front {background-color: '.esc_js($front_bg_color).';}';
	}
}
if(isset($front_bg_type) && $front_bg_type =='image') {
	if(isset($front_image_id) && $front_image_id  !='') {
		$img_style = '';
		$image_url = dpr_get_attachment_image_src( $front_image_id, 'full' );
		$image_src = $image_url[0];
		$custom_el_css .= '.'.esc_js($unique_id).' .flip-wrap-front {background-image: url('.esc_url($image_src).');background-size: cover;}';
	}
}

if(isset($back_bg_type) && $back_bg_type =='color') {
	if(isset($back_bg_color) && $back_bg_color !='') {
		$custom_el_css .= '.'.esc_js($unique_id).' .flip-wrap .flip-wrap-back {background-color: '.esc_js($back_bg_color).';}';
}
}
if(isset($back_bg_type) && $back_bg_type =='image') {
	if(isset($back_image_id) && $back_image_id  !='') {
		$image_url = dpr_get_attachment_image_src( $back_image_id, 'full' );
		$image_src = $image_url[0];
		$custom_el_css .= '.'.esc_js($unique_id).' .flip-wrap-back {background-image: url('.esc_url($image_src).');background-size: cover;}';
	}
}
if(isset($enable_label) && $enable_label =='yes') {
	if(isset($label_size) && $label_size !='') {	
		$custom_el_css .= '.'.esc_js($unique_id).' .label-wrap {width:'.$label_size.'px;height:'.$label_size.'px;line-height:'.$label_size.'px;}';
	}
	if(isset($label_bg_color) && $label_bg_color !='') {	
		$custom_el_css .= '.'.esc_js($unique_id).' .label-wrap {background-color:'.$label_bg_color.';}';
	}
	if(isset($label_bg_radius) && $label_bg_radius !='') {	
		$custom_el_css .= '.'.esc_js($unique_id).' .label-wrap {border-radius:'.$label_bg_radius.'px;}';
	}
	if(isset($enable_label_shadow) && $enable_label_shadow == 'yes') {
		if(dpr_shadow_param_to_css($label_shadow) != '') {
			$custom_el_css .= '.'.esc_js($unique_id) .' .label-wrap {'.dpr_shadow_param_to_css($label_shadow).'}';
		}
	}
}


/* HTML Parts */
if(!empty($front_title)) {
	$title_typo_style = dpr_generate_typography_style($title_color, $title_font_size, $title_line_height, $title_letter_spacing, $title_font_style,$title_google_font);
	$title_html .= '<div class="box-title"><h4 class="title" ' . $title_typo_style . '>' . $front_title . '</h4></div>';
}

if(!empty($front_subtitle)) {
	$subtitle_typo_style = dpr_generate_typography_style($subtitle_color, $subtitle_font_size, $subtitle_line_height, $subtitle_letter_spacing, $subtitle_font_style,$subtitle_google_font);
	$subtitle_html .= '<div class="box-subtitle"><div class="title" ' . $subtitle_typo_style . '>' . $front_subtitle . '</div></div>';
}
if(!empty($back_description)) {
	$content_typo_style = dpr_generate_typography_style($content_color, $content_font_size, $content_line_height, $content_letter_spacing, $content_font_style,$content_google_font);
	$description_html .= '<div class="box-content" ' . $content_typo_style . '>' . wp_kses_post($back_description) . '</div>';
}


if(isset($enable_label) && $enable_label == 'yes') {
	$label_class ='type-'.$label_content_type.' '.$label_position;
	$label_html = '<div class="label-wrap '.$label_class.'">';
			if ('icon' === $label_content_type) {
				
				if ($icon != '') {
					$icon_style = '';
					if (!empty($icon_font_size) || !empty($icon_color)) {
				
						$icon_style .= 'style="';
		
						if ( ! empty( $icon_font_size ) ) {
							$icon_style .= 'font-size:' . $icon_font_size . 'px; ';
						}
		
						if ( ! empty( $icon_color ) ) {
							$icon_style .= 'color:' . $icon_color.'; ';
						}
		
						$icon_style .= '"';
						}
				
					$label_html .= '<i class="featured-icon ' . $icon . '" ' . $icon_style . '></i>';
				
				}
			
			} elseif('image' === $label_content_type ) {
				$img_style = '';
				if(isset($label_image_width) && $label_image_width != '') {
				$img_style = ' width:'.$label_image_width.'px';
				}
				$image_url = dpr_get_attachment_image_src( $label_image_id, 'full' );
				$image_src = $image_url[0];
				$alt_text = get_post_meta($label_image_id , '_wp_attachment_image_alt', true);
				$label_html .= '<img src="' . esc_url($image_src) . '"'.$img_style.' alt ="'.esc_attr($alt_text).'"/>';
				
			} elseif('text' === $label_content_type ) {
				$label_typo_style = dpr_generate_typography_style($label_color, $label_font_size, $label_line_height, $label_letter_spacing, $label_font_style,$label_google_font);
				$label_html .= '<span class="label-text" '.$label_typo_style.'>'.  esc_html($label_text).'</span>';
			} 
				
			$label_html .= '</div>';
}
if(isset($use_link) && $use_link  == 'yes') {
	$box_link_attributes    = array();
	if (function_exists('vc_build_link')) {
		$box_link = ( '||' === $box_link ) ? '' : $box_link;
		$box_link = vc_build_link( $box_link );
	
		$link_href   = $box_link['url'];
		$link_title  = $box_link['title'];
		$link_rel  = $box_link['rel'];
		$link_target = strlen($box_link['target']) > 0 ? $box_link['target'] : '_self';
	
		$box_link_attributes[] = 'href="' . esc_url( trim( $link_href ) ) . '"';
		$box_link_attributes[] = 'title="' . esc_attr( trim( $link_title ) ) . '"';
		$box_link_attributes[] = 'target="' . esc_attr( trim( $link_target ) ) . '"';
		$box_link_attributes[] = 'rel="' . esc_attr( trim( $link_rel ) ) . '"';
	}
	if($box_link['url'] != '') {
			$box_link_html .= '<a class="dpr-cover-link" '.implode(' ',$box_link_attributes).'></a>';
	}
}
/* Output */
$output .= '<div id="'.esc_attr($unique_id).'" class="'.esc_attr($css_class).'">';

$output .= '<div class="flip-wrap">';

$output .= '<div class="flip-wrap-front">';
$output .= '<div class="content-wrap '.$front_add_class.'">';
$output .= $title_html;
$output .= $subtitle_html;
$output .= '</div>';
$output .= '</div>';

$output .= '<div class="flip-wrap-back">';
$output .= '<div class="content-wrap '.$back_add_class.'">';
$output .= $description_html;
$output .= '</div>';
$output .= '</div>';
$output .= $box_link_html;	
$output .= $label_html;
$output .= '</div>';
if(!empty($custom_el_css)) {
		$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>");'
						. '})(jQuery);'
					. '</script>';
}

$output .= '</div>';



echo $output;