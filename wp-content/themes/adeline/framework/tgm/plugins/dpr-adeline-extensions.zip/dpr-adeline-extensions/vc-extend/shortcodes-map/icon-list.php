<?php

// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}

/*

* Add-on Name: Icon list

*/



class WPBakeryShortCode_DPR_List extends WPBakeryShortCode {}





vc_map(

	array(

		'name'					=> esc_html__('DP Icon List', 'dpr-adeline-extensions'),

		'base'					=> 'dpr_list',

		"icon"					=> 'icon-dpr-list',

		"class"					=> 'dpr_list',

  		"category" =>array( esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions')),

		'description'			=> esc_html__('Styled list with iconic bullets', 'dpr-adeline-extensions'),

		'params'				=> array(

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to choose line style.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Style', 'dpr-adeline-extensions'),

				'param_name'		=> 'alignment',

				'value'				=> 'left',

				'options'			=> array(

					esc_html__('Left', 'dpr-adeline-extensions')	=> 'left',

					esc_html__('Justified', 'dpr-adeline-extensions')	=> 'justify',

					esc_html__('Right', 'dpr-adeline-extensions')	=> 'right'

				),

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to choose list item separator.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('List Separator', 'dpr-adeline-extensions'),

				'param_name'		=> 'separator_type',

				'value'				=> '',

				'options'			=> array(

					esc_html__('None', 'dpr-adeline-extensions')	=> '',

					esc_html__('Full Width', 'dpr-adeline-extensions')	=> 'long',

					esc_html__('Small', 'dpr-adeline-extensions')	=> 'small'

				),

				'edit_field_class'	=> 'vc_col-sm-6 vc_column no-padding-top ',

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Additional Settings', 'dpr-adeline-extensions' ),

				'param_name'       => 'extra_features_title',

				'edit_field_class' => 'vc_column vc_col-sm-12',

			),

		   vc_map_add_css_animation( false ),

		    array(

				'type' => 'textfield',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Extra Class Name', 'dpr-adeline-extensions'),

				'param_name' => 'el_class',

			),





			array(

				'type'				=> 'param_group',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Add list item, set content and icons.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('List items', 'dpr-adeline-extensions'),

				'param_name'		=> 'list_items',

				'params'			=> array(

						array(

							'type'				=> 'dpr_radio',

							'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select bullet type for this list item.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Bullet type', 'dpr-adeline-extensions'),

							'param_name'		=> 'bullet_type',

							'value'				=> 'with-icon',

							'options'			=> array(

								esc_html__('Icon', 'dpr-adeline-extensions')	=> 'with-icon',

								esc_html__('Dot', 'dpr-adeline-extensions')	=> 'with-dot',

								esc_html__('No Bullet', 'dpr-adeline-extensions')	=> 'no-icon'

							),

							'edit_field_class'	=> 'vc_col-sm-12 vc_column no-padding-top ',

						),

						array(

							'type' => 'dropdown',

							'heading' => __( 'Icon library', 'dpr-adeline-extensions' ),

							'value' => array(

								__( 'Font Awesome', 'dpr-adeline-extensions' ) => 'fontawesome',

								__( 'Open Iconic', 'dpr-adeline-extensions' ) => 'openiconic',

								__( 'Typicons', 'dpr-adeline-extensions' ) => 'typicons',

								__( 'Entypo', 'dpr-adeline-extensions' ) => 'entypo',

								__( 'Linecons', 'dpr-adeline-extensions' ) => 'linecons',

								__( 'Pixel', 'dpr-adeline-extensions' ) => 'pixelicons',

								__( 'Mono Social', 'dpr-adeline-extensions' ) => 'monosocial',

								__( 'Theme Icons', 'dpr-adeline-extensions' ) => 'themeicons',

							),

							'param_name' => 'icon_type',

							'description' => __( 'Select icon library.', 'dpr-adeline-extensions' ),

							'dependency' => array(

								'element' => 'bullet_type',

								'value' => 'with-icon',

							),

						),

						array(

							'type' => 'iconpicker',

							'heading' => __( 'Icon', 'dpr-adeline-extensions' ),

							'param_name' => 'icon_fontawesome',

							'value' => 'fa fa-angle-double-right',

							'settings' => array(

								'emptyIcon' => false,

								// default true, display an "EMPTY" icon?

								'iconsPerPage' => 4000,

								// default 100, how many icons per/page to display

							),

							'dependency' => array(

								'element' => 'icon_type',

								'value' => 'fontawesome',

							),

							'description' => __( 'Select icon from library.', 'dpr-adeline-extensions' ),

						),

						array(

							'type' => 'iconpicker',

							'heading' => __( 'Icon', 'dpr-adeline-extensions' ),

							'param_name' => 'icon_openiconic',

							'value' => 'vc-oi vc-oi-ok',

							'settings' => array(

								'emptyIcon' => false,

								// default true, display an "EMPTY" icon?

								'type' => 'openiconic',

								'iconsPerPage' => 4000,

								// default 100, how many icons per/page to display

							),

							'dependency' => array(

								'element' => 'icon_type',

								'value' => 'openiconic',

							),

							'description' => __( 'Select icon from library.', 'dpr-adeline-extensions' ),

						),

						array(

							'type' => 'iconpicker',

							'heading' => __( 'Icon', 'dpr-adeline-extensions' ),

							'param_name' => 'icon_typicons',

							'value' => 'typcn typcn-arrow-right',

							'settings' => array(

								'emptyIcon' => false,

								// default true, display an "EMPTY" icon?

								'type' => 'typicons',

								'iconsPerPage' => 4000,

								// default 100, how many icons per/page to display

							),

							'dependency' => array(

								'element' => 'icon_type',

								'value' => 'typicons',

							),

							'description' => __( 'Select icon from library.', 'dpr-adeline-extensions' ),

						),

						array(

							'type' => 'iconpicker',

							'heading' => __( 'Icon', 'dpr-adeline-extensions' ),

							'param_name' => 'icon_entypo',

							'value' => 'entypo-icon entypo-icon-right-open',

							'settings' => array(

								'emptyIcon' => false,

								// default true, display an "EMPTY" icon?

								'type' => 'entypo',

								'iconsPerPage' => 4000,

								// default 100, how many icons per/page to display

							),

							'dependency' => array(

								'element' => 'icon_type',

								'value' => 'entypo',

							),

						),

						array(

							'type' => 'iconpicker',

							'heading' => __( 'Icon', 'dpr-adeline-extensions' ),

							'param_name' => 'icon_linecons',

							'settings' => array(

								'emptyIcon' => false,

								// default true, display an "EMPTY" icon?

								'type' => 'linecons',

								'iconsPerPage' => 4000,

								// default 100, how many icons per/page to display

							),

							'dependency' => array(

								'element' => 'icon_type',

								'value' => 'linecons',

							),

							'description' => __( 'Select icon from library.', 'dpr-adeline-extensions' ),

						),

						array(

							'type' => 'iconpicker',

							'heading' => __( 'Icon', 'dpr-adeline-extensions' ),

							'param_name' => 'icon_pixelicons',

							'value' => 'vc_pixel_icon vc_pixel_icon-tick',

							'settings' => array(

								'emptyIcon' => false,

								// default true, display an "EMPTY" icon?

								'type' => 'pixelicons',

								'source' => array(

												array( 'vc_pixel_icon vc_pixel_icon-alert' => __( 'Alert', 'dpr-adeline-extensions' ) ),

												array( 'vc_pixel_icon vc_pixel_icon-info' => __( 'Info', 'dpr-adeline-extensions' ) ),

												array( 'vc_pixel_icon vc_pixel_icon-tick' => __( 'Tick', 'dpr-adeline-extensions' ) ),

												array( 'vc_pixel_icon vc_pixel_icon-explanation' => __( 'Explanation', 'dpr-adeline-extensions' ) ),

												array( 'vc_pixel_icon vc_pixel_icon-address_book' => __( 'Address book', 'dpr-adeline-extensions' ) ),

												array( 'vc_pixel_icon vc_pixel_icon-alarm_clock' => __( 'Alarm clock', 'dpr-adeline-extensions' ) ),

												array( 'vc_pixel_icon vc_pixel_icon-anchor' => __( 'Anchor', 'dpr-adeline-extensions' ) ),

												array( 'vc_pixel_icon vc_pixel_icon-application_image' => __( 'Application Image', 'dpr-adeline-extensions' ) ),

												array( 'vc_pixel_icon vc_pixel_icon-arrow' => __( 'Arrow', 'dpr-adeline-extensions' ) ),

												array( 'vc_pixel_icon vc_pixel_icon-asterisk' => __( 'Asterisk', 'dpr-adeline-extensions' ) ),

												array( 'vc_pixel_icon vc_pixel_icon-hammer' => __( 'Hammer', 'dpr-adeline-extensions' ) ),

												array( 'vc_pixel_icon vc_pixel_icon-balloon' => __( 'Balloon', 'dpr-adeline-extensions' ) ),

												array( 'vc_pixel_icon vc_pixel_icon-balloon_buzz' => __( 'Balloon Buzz', 'dpr-adeline-extensions' ) ),

												array( 'vc_pixel_icon vc_pixel_icon-balloon_facebook' => __( 'Balloon Facebook', 'dpr-adeline-extensions' ) ),

												array( 'vc_pixel_icon vc_pixel_icon-balloon_twitter' => __( 'Balloon Twitter', 'dpr-adeline-extensions' ) ),

												array( 'vc_pixel_icon vc_pixel_icon-battery' => __( 'Battery', 'dpr-adeline-extensions' ) ),

												array( 'vc_pixel_icon vc_pixel_icon-binocular' => __( 'Binocular', 'dpr-adeline-extensions' ) ),

												array( 'vc_pixel_icon vc_pixel_icon-document_excel' => __( 'Document Excel', 'dpr-adeline-extensions' ) ),

												array( 'vc_pixel_icon vc_pixel_icon-document_image' => __( 'Document Image', 'dpr-adeline-extensions' ) ),

												array( 'vc_pixel_icon vc_pixel_icon-document_music' => __( 'Document Music', 'dpr-adeline-extensions' ) ),

												array( 'vc_pixel_icon vc_pixel_icon-document_office' => __( 'Document Office', 'dpr-adeline-extensions' ) ),

												array( 'vc_pixel_icon vc_pixel_icon-document_pdf' => __( 'Document PDF', 'dpr-adeline-extensions' ) ),

												array( 'vc_pixel_icon vc_pixel_icon-document_powerpoint' => __( 'Document Powerpoint', 'dpr-adeline-extensions' ) ),

												array( 'vc_pixel_icon vc_pixel_icon-document_word' => __( 'Document Word', 'dpr-adeline-extensions' ) ),

												array( 'vc_pixel_icon vc_pixel_icon-bookmark' => __( 'Bookmark', 'dpr-adeline-extensions' ) ),

												array( 'vc_pixel_icon vc_pixel_icon-camcorder' => __( 'Camcorder', 'dpr-adeline-extensions' ) ),

												array( 'vc_pixel_icon vc_pixel_icon-camera' => __( 'Camera', 'dpr-adeline-extensions' ) ),

												array( 'vc_pixel_icon vc_pixel_icon-chart' => __( 'Chart', 'dpr-adeline-extensions' ) ),

												array( 'vc_pixel_icon vc_pixel_icon-chart_pie' => __( 'Chart pie', 'dpr-adeline-extensions' ) ),

												array( 'vc_pixel_icon vc_pixel_icon-clock' => __( 'Clock', 'dpr-adeline-extensions' ) ),

												array( 'vc_pixel_icon vc_pixel_icon-fire' => __( 'Fire', 'dpr-adeline-extensions' ) ),

												array( 'vc_pixel_icon vc_pixel_icon-heart' => __( 'Heart', 'dpr-adeline-extensions' ) ),

												array( 'vc_pixel_icon vc_pixel_icon-mail' => __( 'Mail', 'dpr-adeline-extensions' ) ),

												array( 'vc_pixel_icon vc_pixel_icon-play' => __( 'Play', 'dpr-adeline-extensions' ) ),

												array( 'vc_pixel_icon vc_pixel_icon-shield' => __( 'Shield', 'dpr-adeline-extensions' ) ),

												array( 'vc_pixel_icon vc_pixel_icon-video' => __( 'Video', 'dpr-adeline-extensions' ) ),

											),

							),

							'dependency' => array(

								'element' => 'icon_type',

								'value' => 'pixelicons',

							),

							'description' => __( 'Select icon from library.', 'dpr-adeline-extensions' ),

						),

						array(

							'type' => 'iconpicker',

							'heading' => __( 'Icon', 'dpr-adeline-extensions' ),

							'param_name' => 'icon_monosocial',

							'value' => 'vc-mono vc-mono-fivehundredpx',

							// default value to backend editor admin_label

							'settings' => array(

								'emptyIcon' => false,

								// default true, display an "EMPTY" icon?

								'type' => 'monosocial',

								'iconsPerPage' => 4000,

								// default 100, how many icons per/page to display

							),

							'dependency' => array(

								'element' => 'icon_type',

								'value' => 'monosocial',

							),

							'description' => __( 'Select icon from library.', 'dpr-adeline-extensions' ),

						),

					  array(

							"type" => "dpr_icon_selector",

							"heading" => esc_attr__("Icon", 'dpr-adeline-extensions'),

							"param_name" => "icon_theme",

							'dependency' => array(

								'element' => 'icon_type',

								'value' => 'themeicons',

							),

						),

					 array(

						  "type" => "textarea",

						  "class" => "",

						  "heading" => __( "List Item Content", "dpr-adeline-extensions" ),

						  "param_name" => "item_text",

						  "value" => __( "", "dpr-adeline-extensions" ),

						  "description" => __( "Enter list item content.", "dpr-adeline-extensions" )

						),

					array(

						'type'				=> 'dpr_switcher',

						'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable linking for this list item.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Use link for this item?', 'dpr-adeline-extensions'),

						'param_name'		=> 'use_link',

						'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

						'options'			=> array(

							'yes'				=> array(

								'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

								'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

							),

						),

						'dependency'		=> array('element' => 'style', 'value' => array('icon','totop')),

					),

					array(

						'type'				=> 'vc_link',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Add a custom link or select existing page. You can remove existing link as well.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Link URL', 'dpr-adeline-extensions'),

						'param_name'		=> 'link',

						'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

						'dependency'		=> array('element' => 'use_link', 'value' => array('yes')),

					),

				

				),

				'group'				=> esc_html__('List Items', 'dpr-adeline-extensions'),

			),



			

			array(

				'type'				=> 'dpr_title',

				'text'				=> 'Icon Style',

				'param_name'		=> 'title_style_1',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'style', 'value' => array('icon')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set the size for the icon.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon Size', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_size',

				'min'				=> 12,

				'suffix' 			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4   ',

				'dependency'		=> array('element' => 'style', 'value' => array('icon','totop')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'class'				=> '',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the icon color. The default color is main acent color set in Template Options.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-4  ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable icon background badge.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Enable Icon Badge', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_badge',

				'edit_field_class'	=> 'vc_column vc_col-sm-4  ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> 'Icon Badge Style',

				'param_name'		=> 'title_style_2',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'use_badge', 'value' => array('yes')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose icon background color. Default is main accent color set in Template Options', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Badge color', 'dpr-adeline-extensions'),

				'param_name'		=> 'badge_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'dependency'		=> array('element' => 'use_badge', 'value' => array('yes')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose border color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border color', 'dpr-adeline-extensions'),

				'param_name'		=> 'border_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'dependency'		=> array('element' => 'use_badge', 'value' => array('yes')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose background border width default is 0.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border width', 'dpr-adeline-extensions'),

				'param_name'		=> 'border_width',

				'min'				=> 0,

				'suffix' 			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'dependency'		=> array('element' => 'use_badge', 'value' => array('yes')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose background border radius, default is 50%.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border radius', 'dpr-adeline-extensions'),

				'param_name'		=> 'border_radius',

				'min'				=> 0,

				'suffix' 			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'dependency'		=> array('element' => 'use_badge', 'value' => array('yes')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> 'Separator style',

				'param_name'		=> 'title_style_3',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'separator_type', 'value' => array('long','small')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to choose separator style.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Separator Style', 'dpr-adeline-extensions'),

				'param_name'		=> 'separator_style',

				'value'				=> 'solid',

				'options'			=> array(

					esc_html__('Solid', 'dpr-adeline-extensions')	=> 'solid',

					esc_html__('Dotted', 'dpr-adeline-extensions')	=> 'dotted',

					esc_html__('Dashed', 'dpr-adeline-extensions')	=> 'dashed',

					esc_html__('Double', 'dpr-adeline-extensions')	=> 'double'

				),

				'edit_field_class'	=> 'vc_col-sm-12 vc_column ',

				'dependency'		=> array('element' => 'separator_type', 'value' => array('long','small')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose separator thicknes, default is 1px.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Separator thicknes', 'dpr-adeline-extensions'),

				'param_name'		=> 'separator_height',

				'min'				=> 0,

				'value' 			=> 1,

				'suffix' 			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'dependency'		=> array('element' => 'separator_type', 'value' => array('long','small')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose seprator color, default is #d2d7de.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Seprator color', 'dpr-adeline-extensions'),

				'param_name'		=> 'separator_color',

				'value'				=> '#e1e4e9',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'dependency'		=> array('element' => 'separator_type', 'value' => array('long','small')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> 'Offsets Settings',

				'param_name'		=> 'title_style_4',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Offset between icon and content default is 18px.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon offset', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_offset',

				'min'				=> 0,

				'value' 			=> 18,

				'suffix' 			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose vertical offset between list items.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Items gape', 'dpr-adeline-extensions'),

				'param_name'		=> 'item_gape',

				'min'				=> 0,

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> 'Text Style',

				'param_name'		=> 'title_typo_1',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom ttle color. Default is #97a3b3.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'text_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size.Default is 12px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'text_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title linne height.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'text_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'text_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'text_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

	  		),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_google_fonts',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'text_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'dependency'		=> array('element' => 'use_google_fonts', 'value' => array('yes')),

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'css_editor',

				'heading' => __( 'CSS box', 'dpr-adeline-extensions' ),

				'param_name' => 'css',

				'group' => __( 'Design Options', 'dpr-adeline-extensions' ),

			),

			

		),

	)

);