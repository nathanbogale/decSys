<?php

// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}



if ( ! defined( 'ABSPATH' ) ) { exit; }

if(!class_exists('DPR_Resposive_Typography_Param')) {

	class DPR_Resposive_Typography_Param {

		/**

		 * @var array

		 */

		protected $settings = array();

		/**

		 * @var string

		 */

		protected $value = '';



		function __construct() {



			if(function_exists('vc_add_shortcode_param')) {

				vc_add_shortcode_param('dpr_responsive_typo', array($this, 'responsive_typo'), DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/admin/js/dpr_responsive_typo_param.js');

			}

		}

		

		public static function generate_css($value, $class = '') {

			if(!$value || empty($value)) return;

			

			$css_output = '';

			

			$devices = array( 'desktop', 'tablet', 'mobile');

			

			$values = vc_parse_multi_attribute($value, array(

				'desktop_font_size' => '',

				'desktop_line_height' => '',

				'desktop_letter_spacing' => '',

				'tablet_font_size' => '',

				'tablet_line_height' => '',

				'tablet_letter_spacing' => '',

				'mobile_font_size' => '',

				'mobile_line_height' => '',

				'mobile_letter_spacing' => '',

			));

			

			

			$devices_queries = array(

				'desktop' => '@media (max-width: 1280px) and (min-width: 1024px)',

				'tablet' => '@media (max-width: 1023px) and (min-width: 800px)',

				'mobile' => '@media (max-width: 799px)',

			);

			

			foreach($devices as $device) {

				$single_css = '';



				if(isset($values[$device.'_font_size']) && $values[$device.'_font_size'] != '') {

					$single_css .= 'font-size: '.esc_attr($values[$device.'_font_size']).'px !important;';

				}

				if(isset($values[$device.'_line_height']) && $values[$device.'_line_height'] != '') {

					$single_css .= 'line-height: '.esc_attr($values[$device.'_line_height']).'px !important;';

				}

				if(isset($values[$device.'_letter_spacing']) && $values[$device.'_letter_spacing'] != '') {

					$single_css .= 'letter-spacing: '.esc_attr($values[$device.'_letter_spacing']).'px !important;';

				}

				

				if($single_css != '') {

					$css_output .= $devices_queries[$device].'{'.$class.'{'.$single_css.'}}';

				}

			}

			

			return $css_output;

		}



		

		

		function responsive_typo($settings, $value) {

			$unique_id = uniqid(rand(1,9999));

					

			$param_name = isset($settings['param_name']) ? $settings['param_name'] : '';

			$type = isset($settings['type']) ? $settings['type'] : '';

			$class = isset($settings['class']) ? $settings['class'] : '';

			

			$output  = '<div class="dpr-responsive-typo-param-container">';

			$output .= '<div class="vc_column vc_col-sm-3 vc_column no-padding-top"><div class="wpb_element_label"><span class="dp-vc-tip" data-balloon-length="medium" data-balloon="Screen resolutions from 1280px to 1025px" data-balloon-pos="right"><span></span></span></div><div class="edit_form_line"><span class="desktop_typo_icon"></span></div></div>';

			$output .= '<div class="vc_column vc_col-sm-3 vc_column no-padding-top"><div class="wpb_element_label">Font size</div><div class="edit_form_line"><input type="number" min="1" max="" step="" class="wpb_vc_param_value desktop_font_size number css-input '.$unique_id.'" name="desktop_font_size" value="" style="max-width:100px; margin-right: 10px;">px</div></div>';

			$output .= '<div class="vc_column vc_col-sm-3 vc_column no-padding-top"><div class="wpb_element_label">Line height</div><div class="edit_form_line"><input type="number" min="1" max="" step="" class="wpb_vc_param_value desktop_line_height number css-input '.$unique_id.'" name="desktop_line_height" value="" style="max-width:100px; margin-right: 10px;">px</div></div>';

			$output .= '<div class="vc_column vc_col-sm-3 vc_column no-padding-top"><div class="wpb_element_label">Letter spacing</div><div class="edit_form_line"><input type="number" min="1" max="" step="" class="wpb_vc_param_value desktop_letter_spacing number css-input '.$unique_id.'" name="desktop_letter_spacing" value="" style="max-width:100px; margin-right: 10px;">px</div></div>';

			$output .= '<div class="vc_clearfix"></div>';



			$output .= '<div class="vc_column vc_col-sm-3 vc_column no-padding-top"><div class="wpb_element_label"><span class="dp-vc-tip" data-balloon-length="medium" data-balloon="Screen resolutions from 1024px to 800px" data-balloon-pos="right"><span></span></span></div><div class="edit_form_line"><span class="tablet_typo_icon"></span></div></div>';

			$output .= '<div class="vc_column vc_col-sm-3 vc_column no-padding-top"><div class="wpb_element_label">Font size</div><div class="edit_form_line"><input type="number" min="1" max="" step="" class="wpb_vc_param_value tablet_font_size number css-input '.$unique_id.'" name="tablet_font_size" value="" style="max-width:100px; margin-right: 10px;">px</div></div>';

			$output .= '<div class="vc_column vc_col-sm-3 vc_column no-padding-top"><div class="wpb_element_label">Line height</div><div class="edit_form_line"><input type="number" min="1" max="" step="" class="wpb_vc_param_value tablet_line_height number css-input '.$unique_id.'" name="tablet_line_height" value="" style="max-width:100px; margin-right: 10px;">px</div></div>';

			$output .= '<div class="vc_column vc_col-sm-3 vc_column no-padding-top"><div class="wpb_element_label">Letter spacing</div><div class="edit_form_line"><input type="number" min="1" max="" step="" class="wpb_vc_param_value tablet_letter_spacing number css-input '.$unique_id.'" name="tablet_letter_spacing" value="" style="max-width:100px; margin-right: 10px;">px</div></div>';

			$output .= '<div class="vc_clearfix"></div>';

			

			$output .= '<div class="vc_column vc_col-sm-3 vc_column no-padding-top"><div class="wpb_element_label"><span class="dp-vc-tip" data-balloon-length="medium" data-balloon="Screen resolutions less than 800px" data-balloon-pos="right"><span></span></span></div><div class="edit_form_line"><span class="mobile_typo_icon"></span></div></div>';

			$output .= '<div class="vc_column vc_col-sm-3 vc_column no-padding-top"><div class="wpb_element_label">Font size</div><div class="edit_form_line"><input type="number" min="1" max="" step="" class="wpb_vc_param_value mobile_font_size number css-input '.$unique_id.'" name="mobile_font_size" value="" style="max-width:100px; margin-right: 10px;">px</div></div>';

			$output .= '<div class="vc_column vc_col-sm-3 vc_column no-padding-top"><div class="wpb_element_label">Line height</div><div class="edit_form_line"><input type="number" min="1" max="" step="" class="wpb_vc_param_value mobile_line_height number css-input '.$unique_id.'" name="mobile_line_height" value="" style="max-width:100px; margin-right: 10px;">px</div></div>';

			$output .= '<div class="vc_column vc_col-sm-3 vc_column no-padding-top"><div class="wpb_element_label">Letter spacing</div><div class="edit_form_line"><input type="number" min="1" max="" step="" class="wpb_vc_param_value mobile_letter_spacing number css-input '.$unique_id.'" name="mobile_letter_spacing" value="" style="max-width:100px; margin-right: 10px;">px</div></div>';

			$output .= '<div class="vc_clearfix"></div>';

			$output .= '<input type="hidden" id="'.$unique_id.'" class="wpb_vc_param_value ' . $param_name . ' ' . $type . ' ' . $class . '" name="' . $param_name . '" value="'.$value.'"/>';

			

			$output .= '</div>';

			$output .= '<div class="vc_clearfix"></div>';

			

			return $output;

		}

	}

	$DPR_Resposive_Typography_Param = new DPR_Resposive_Typography_Param();

}