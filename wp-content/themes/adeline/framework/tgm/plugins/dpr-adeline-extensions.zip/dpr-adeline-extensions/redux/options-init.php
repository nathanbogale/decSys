<?php

if (!class_exists('Redux')) {

    return;

}

$opt_name = 'dpr_adeline';

/**



 * ---> SET ARGUMENTS



 * All the possible arguments for Redux.



 * For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments



 * */

$theme = wp_get_theme(); // For use with some settings. Not necessary.

$args = array(

    'opt_name'             => $opt_name,

    'display_name'         => $theme->get('Name'),

    'display_version'      => $theme->get('Version'),

    'use_cdn'              => true,

    'page_slug'            => 'dpr_adeline',

    'page_title'           => esc_html__('Theme Options', 'dpr-adeline-extensions'),

    'update_notice'        => true,

    'menu_type'            => 'menu',

    'menu_title'           => esc_html__('Theme Options', 'dpr-adeline-extensions'),

    'allow_sub_menu'       => true,

    'async_typography'     => true,

    'google_api_key'       => '',

    'google_update_weekly' => false,

    'async_typography'     => false,

    'admin_bar'            => true,

    'admin_bar_icon'       => 'dashicons dashicons-admin-settings',

    'admin_bar_priority'   => 50,

    'hide_reset'           => true,

    'global_variable'      => 'dpr_adeline',

    'dev_mode'             => false,

    'update_notice'        => false,

    'customizer'           => false,

    'forced_dev_mode_off'  => true,

    'page_priority'        => 2,

    'page_parent'          => 'themes.php',

    'page_permissions'     => 'manage_options',

    'menu_icon'            => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/menu_icon.png',

    'last_tab'             => '',

    'page_icon'            => 'icon-themes',

    'save_defaults'        => true,

    'default_show'         => false,

    'default_mark'         => '',

    'show_import_export'   => true,

    'allow_tracking'       => false,

    'output'               => true,

    'output_tag'           => true,

    'transient_time'       => '3600',

    'system_info'          => true,

    'database'             => '',

    'disable_tracking'     => true,

    'hints'                => array(

        'icon'          => 'el el-question-sign',

        'icon_position' => 'left',

        'icon_color'    => 'lightgray',

        'icon_size'     => 'normal',

        'tip_style'     => array(

            'color'   => 'light',

            'shadow'  => false,

            'rounded' => false,

            'style'   => 'tipsy',

        ),

        'tip_position'  => array(

            'my' => 'top left',

            'at' => 'bottom right',

        ),

        'tip_effect'    => array(

            'show' => array(

                'effect'   => 'slide',

                'duration' => '500',

                'event'    => 'mouseover',

            ),

            'hide' => array(

                'effect'   => 'slide',

                'duration' => '500',

                'event'    => 'mouseleave unfocus',

            ),

        ),

    ),

    'ajax_save'            => true,

    'settings_api'         => true,

    'cdn_check_time'       => '1440',

    'compiler'             => true,

    'network_sites'        => false,

    'show_options_object'  => false,

);

Redux::setArgs($opt_name, $args);

/*

 * ---> END ARGUMENTS

 */

/*

 * ---> START HELP TABS

 */

$tabs = array(

    array(

        'id'      => 'redux-help-tab-1',

        'title'   => __('Theme Information 1', 'admin_folder'),

        'content' => __('<p>This is the tab content, HTML is allowed.</p>', 'admin_folder'),

    ),

    array(

        'id'      => 'redux-help-tab-2',

        'title'   => __('Theme Information 2', 'admin_folder'),

        'content' => __('<p>This is the tab content, HTML is allowed.</p>', 'admin_folder'),

    ),

);

Redux::setHelpTab($opt_name, $tabs);

// Set the help sidebar

$content = __('<p>This is the sidebar content, HTML is allowed.</p>', 'admin_folder');

Redux::setHelpSidebar($opt_name, $content);

/*

 * <--- END HELP TABS

 */

/*

 *

 * ---> START SECTIONS

 *

 */

$options = array();

$options = array('general', 'typography', 'topbar', 'header', 'subheader', 'blog', 'portfolio', 'sidebar', 'expandable-panel', 'footer', 'branding');

if (!function_exists('is_plugin_active')) {

    require_once ABSPATH . '/wp-admin/includes/plugin.php';

}

if (is_plugin_active('woocommerce/woocommerce.php')) {

    array_push($options, 'woocommerce');

}

if (is_plugin_active('the-events-calendar/the-events-calendar.php')) {

    array_push($options, 'tribe');

}

if (is_plugin_active('dpr-timetable/dpr-timetable.php')) {

    array_push($options, 'timetable');

}

if (is_plugin_active('dpr-proofgallery/dprproof.php')) {

    array_push($options, 'proofgallery');

}

array_push($options, 'icons');

$options_dir = dirname(__FILE__) . '/options';

$assets_folder = get_template_directory_uri() . '/assets/';

foreach ($options as $option) {

    $options_file = $option . '-options.php';

    require_once $options_dir . '/' . $options_file;

}

/*

 * <--- END SECTIONS

 */

/**



 * Removes the demo link and the notice of integrated demo from the redux-framework plugin



 */

if (!function_exists('remove_redux_menu')) {

    function remove_redux_menu()
    {

        remove_submenu_page('tools.php', 'redux-about');

    }

}

add_action('admin_menu', 'remove_redux_menu', 12);

if (!function_exists('remove_demo')) {

    function remove_demo()
    {

        // Used to hide the demo mode link from the plugin page. Only used when Redux is a plugin.

        if (class_exists('ReduxFrameworkPlugin')) {

            remove_filter('plugin_row_meta', array(

                ReduxFrameworkPlugin::instance(),

                'plugin_metalinks',

            ), null, 2);

            // Used to hide the activation notice informing users of the demo panel. Only used when Redux is a plugin.

            remove_action('admin_notices', array(ReduxFrameworkPlugin::instance(), 'admin_notices'));

        }

    }

}
