<?php

// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}



/*

  Shortcode: Vertical Split Slider

 */



class WPBakeryShortCode_DPR_Split_Slider extends WPBakeryShortCodesContainer {

	

}

vc_map(

	array(

		'name' => esc_html__('DP Split Slider', 'dpr-adeline-extensions'),

		'base' => 'dpr_split_slider',

		'icon' => 'icon-dpr-split-slider',

		'class' => 'dpr-split-slider',

		'as_parent' => array('only' =>'dpr_split_slider_left,dpr_split_slider_right'),

		'content_element' => true,

		'controls' => 'full',

		'show_settings_on_create' => true,

  		"category" =>array( esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions')),

		'description' => 'Display vertical split slider',

		'params' => array_merge(array(

			array(

				'heading'			=> '',

				'type'				=> 'dpr_info',

				'param_name'		=> 'info_1',

				'title' => 'NOTE',

				'icon' => 'info',

				'text' => esc_html('This is only shortode container for Vertical Split Slider slidings panels. Add Left and Right slidings panels inside here.'),

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

			),



		)),

		'js_view' => 'VcColumnView'

	)

);



/*** Vertical Split Slider Left Panel ***/



class WPBakeryShortCode_DPR_Split_Slider_Left  extends WPBakeryShortCodesContainer {}

vc_map( 

	array(

		"name" =>  __( 'Left Sliding Panel', 'dpr-adeline-extensions' ),

		"base" => "dpr_split_slider_left",

		"as_parent" => array('only' => 'dpr_split_slider_item'),

		"as_child" => array('only' => 'dpr_split_slider'),

		"content_element" => true,

		"category" =>array( esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions')),

		'icon' => 'icon-dpr-split-slider-left',

		"show_settings_on_create" => false,

		"js_view" => 'VcColumnView',

		'description' => 'Split slider left column container',

		"params" => array(

			array(

				'heading'			=> '',

				'type'				=> 'dpr_info',

				'param_name'		=> 'info_1',

				'title' => 'NOTE',

				'icon' => 'info',

				'text' => esc_html('This is only Left Sliding Panel shortcode container. Add content of this panel inside here.'),

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

			),

		)

	) 

);





/*** Vertical Split Slider Right Panel ***/



class WPBakeryShortCode_DPR_Split_Slider_Right  extends WPBakeryShortCodesContainer {}

vc_map( 

	array(

		"name" =>  __( 'Right Sliding Panel', 'dpr-adeline-extensions' ),

		"base" => "dpr_split_slider_right",

		"as_parent" => array('only' => 'dpr_split_slider_item'),

		"as_child" => array('only' => 'dpr_split_slider'),

		"content_element" => true,

		"category" =>array( esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions')),

		'icon' => 'icon-dpr-split-slider-right',

		"show_settings_on_create" => false,

		"js_view" => 'VcColumnView',

		'description' => 'Split slider right column container',

		"params" => array(

			array(

				'heading'			=> '',

				'type'				=> 'dpr_info',

				'param_name'		=> 'info_1',

				'title' => 'NOTE',

				'icon' => 'info',

				'text' => esc_html('This is only Right Sliding Panel shortcode container. Add content of this panel inside here.'),

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

			),

		)

	) 

);



/*** Vertical Split Slider Content Item ***/



class WPBakeryShortCode_DPR_Split_Slider_Item  extends WPBakeryShortCodesContainer {}

vc_map( 

	array(

		"name" =>  __( 'Slide Content Item', 'dpr-adeline-extensions' ),

		"base" => "dpr_split_slider_item",

		"as_parent" => array('except' => 'vc_accordion'),

		"as_child" => array('only' => 'dpr_split_slider_right, dpr_split_slider_left'),

		"content_element" => true,

		"category" =>array( esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions')),

		"icon" => "icon-dpr-split-slider-item",

		"show_settings_on_create" => true,

		"js_view" => 'VcColumnView',

		'description' => 'Split slider column content item',

		"params" => array(

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Item General Settings', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_1',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

			),

			array(

				'type'				=> 'colorpicker',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom background color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'background_color',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

			),

			array(

				'type'				=> 'attach_image',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the image from the media library', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background Image', 'dpr-adeline-extensions'),

				'param_name'		=> 'background_image',

				'edit_field_class'	=> 'vc_column vc_col-sm-6  ',

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set item hprizontal padding.Default is 100px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Padding Left / Right', 'dpr-adeline-extensions'),

				'param_name'		=> 'item_padding',

				'min'				=> 0,

				'value'				=> 100,

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

			),

			

			array(

				'type'				=> 'dpr_radio',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose content alignment.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Content Alignment', 'dpr-adeline-extensions'),

				'param_name'		=> 'alignment',

				'value'				=> 'left',

				'edit_field_class'	=> 'vc_column vc_col-sm-6  ',

				'options'			=> array(

					esc_html__('Left', 'dpr-adeline-extensions')	=> 'left',

					esc_html__('Center', 'dpr-adeline-extensions')	=> 'center',

					esc_html__('Right', 'dpr-adeline-extensions')	=> 'right',

				),

			),

		)

	) 

);

