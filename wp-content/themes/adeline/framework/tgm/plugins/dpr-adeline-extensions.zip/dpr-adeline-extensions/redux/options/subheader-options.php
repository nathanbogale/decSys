<?php

/**



 * Subheader Options



 *



 */

Redux::setSection($opt_name, array(

    'title' => __('Subheader', 'dpr-adeline-extensions'),

    'id'    => 'subheader_tab',

    'desc'  => __('Basic subheader settings are configured here.', 'dpr-adeline-extensions'),

    'icon'  => 'el el-website',

));

Redux::setSection($opt_name, array(

    'title'      => esc_html__('General', 'dpr-adeline-extensions'),

    'subsection' => true,

    'fields'     => array(

        array(

            'id'      => 'subheader_display',

            'type'    => 'switch',

            'default' => true,

            'title'   => esc_html__('Display Subheader', 'dpr-adeline-extensions'),

            'hint'    => array(

                'title'   => esc_attr__('Display Subheader', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enable or disable display subheader area.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'subheader_visibility',

            'type'     => 'image_select',

            'title'    => __('Visibility', 'dpr-adeline-extensions'),

            'options'  => array(

                'all-devices'        => array(

                    'title' => esc_html__('All Devices', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/visibility/all.png',

                ),

                'hide-tablet'        => array(

                    'title' => esc_html__('Hide On Tablet', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/visibility/no_tablet.png',

                ),

                'hide-mobile'        => array(

                    'title' => esc_html__('Hide On Mobile', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/visibility/no_mobile.png',

                ),

                'hide-tablet-mobile' => array(

                    'title' => esc_html__('Hide On Tablet & Mobile', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/visibility/no_tablet_mobile.png',

                ),

            ),

            'default'  => 'all-devices',

            'hint'     => array(

                'title'   => esc_attr__('Visibility', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enable or disable display subheader area on certain devices.', 'dpr-adeline-extensions'),

            ),

            'required' => array('subheader_display', 'equals', '1'),

        ),

        array(

            'id'       => 'subheader_title_tag',

            'type'     => 'select',

            'title'    => esc_html__('Title Tag', 'dpr-adeline-extensions'),

            'desc'     => '',

            'options'  => array(

                'h1'   => esc_html__('H1', 'dpr-adeline-extensions'),

                'h2'   => esc_html__('H2', 'dpr-adeline-extensions'),

                'h3'   => esc_html__('H3', 'dpr-adeline-extensions'),

                'h4'   => esc_html__('H4', 'dpr-adeline-extensions'),

                'h5'   => esc_html__('H5', 'dpr-adeline-extensions'),

                'h6'   => esc_html__('H6', 'dpr-adeline-extensions'),

                'span' => esc_html__('span', 'dpr-adeline-extensions'),

                'p'    => esc_html__('p', 'dpr-adeline-extensions'),

                'div'  => esc_html__('div', 'dpr-adeline-extensions'),

            ),

            'default'  => 'h1',

            'hint'     => array(

                'title'   => esc_attr__('Title Tag', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Default tiltle is closed in H1 tag but you can select other tag . This options can be useful for SEO adjustement ', 'dpr-adeline-extensions'),

            ),

            'required' => array('subheader_display', 'equals', '1'),

        ),

        array(

            'id'       => 'subheader_alignment',

            'type'     => 'select',

            'title'    => esc_html__('Alignment', 'dpr-adeline-extensions'),

            'desc'     => '',

            'options'  => array(

                'lefted'   => esc_html__('Left', 'dpr-adeline-extensions'),

                'centered' => esc_html__('Centered', 'dpr-adeline-extensions'),

            ),

            'default'  => 'centered',

            'hint'     => array(

                'title'   => esc_attr__('Alignment', 'dpr-adeline-extensions'),

                'content' => esc_attr__('You can use default left alignment or center subheader content.', 'dpr-adeline-extensions'),

            ),

            'required' => array('subheader_display', 'equals', '1'),

        ),

        array(

            'id'       => 'subheader_height',

            'type'     => 'dimensions',

            'units'    => array('px'),

            'mode'     => array('width' => 'width', 'height' => 'min-height'),

            'width'    => false,

            'output'   => array('.subheader'),

            'title'    => __('Subheader Height', 'dpr-adeline-extensions'),

            'default'  => array(

                'Height' => '230px',

            ),

            'hint'     => array(

                'title'   => esc_attr__('Subheader Height', 'dpr-adeline-extensions'),

                'content' => esc_attr__('You can set subheader height.', 'dpr-adeline-extensions'),

            ),

            'required' => array('subheader_display', 'equals', '1'),

        ),

        array(

            'id'             => 'subheader_padding',

            'type'           => 'spacing',

            'output'         => array('.subheader'),

            'mode'           => 'padding',

            'units'          => array('px', 'em'),

            'left'           => false,

            'right'          => false,

            'display_units'  => true,

            'units_extended' => false,

            'title'          => __('Vertical Padding', 'dpr-adeline-extensions'),

            'default'        => array(

                'padding-top'    => '0px',

                'padding-bottom' => '0px',

                'units'          => 'px',

            ),

            'hint'           => array(

                'title'   => esc_attr__('Vertical Padding', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Using padding you can adjust vertical position of title in subheader area', 'dpr-adeline-extensions'),

            ),

            'required'       => array('subheader_display', 'equals', '1'),

        ),

        array(

            'id'       => 'use_featured_image_as_bg',

            'type'     => 'switch',

            'title'    => esc_html__('Use featured image as subheader background?', 'dpr-adeline-extensions'),

            'hint'     => array(

                'title'   => esc_attr__('Use featured image as subheader background?', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enable usage featured image of this post as subheader background.', 'dpr-adeline-extensions'),

            ),

            'required' => array('subheader_display', 'equals', '1'),

        ),

        array(

            'id'       => 'subheader_bg',

            'type'     => 'background',

            'title'    => __('Background', 'dpr-adeline-extensions'),

            'default'  => array(

                'background-color' => '#424251',

            ),

            'output'   => array('.subheader'),

            'hint'     => array(

                'title'   => esc_attr__('Background', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set background for subheader area subheader area', 'dpr-adeline-extensions'),

            ),

            'required' => array('use_featured_image_as_bg', 'not', '1'),

        ),

        array(

            'id'       => 'subheader_overlay',

            'type'     => 'switch',

            'default'  => false,

            'title'    => esc_html__('Use Subheader Overlay', 'dpr-adeline-extensions'),

            'hint'     => array(

                'title'   => esc_attr__('Use Subheader Overlay', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enable overlay layer over subheader background.', 'dpr-adeline-extensions'),

            ),

            'required' => array('subheader_display', 'equals', '1'),

        ),

        array(

            'id'       => 'subheader_overlay_bg_color',

            'type'     => 'color',

            'title'    => __('Overlay Color', 'dpr-adeline-extensions'),

            'default'  => 'rgba(0,0,0,.5)',

            'output'   => array('background-color' => '.subheader-overlay'),

            'hint'     => array(

                'title'   => esc_attr__('Overlay Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set background color for subheader overlay.', 'dpr-adeline-extensions'),

            ),

            'required' => array('subheader_overlay', 'equals', '1'),

        ),

        array(

            'id'       => 'subheader_title_color',

            'type'     => 'color',

            'title'    => __('Title Color', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'output'   => array('.subheader-title'),

            'hint'     => array(

                'title'   => esc_attr__('Title Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set title color.', 'dpr-adeline-extensions'),

            ),

            'required' => array('subheader_display', 'equals', '1'),

        ),

        array(

            'id'       => 'subtitle_color',

            'type'     => 'color',

            'title'    => __('Subtitle Color', 'dpr-adeline-extensions'),

            'default'  => 'rgba(255, 255, 255, 0.8)',

            'output'   => array('.subheader-subtitle'),

            'hint'     => array(

                'title'   => esc_attr__('Subtitle Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set subtitle color.', 'dpr-adeline-extensions'),

            ),

            'required' => array('subheader_display', 'equals', '1'),

        ),

        array(

            'id'       => 'subheader_subtitle',

            'type'     => 'text',

            'title'    => __('Subheader Subtitle Text', 'dpr-adeline-extensions'),

            'default'  => '',

            'required' => array('subheader_display', 'equals', '1'),

            'hint'     => array(

                'title'   => esc_attr__('Subtitle', 'dpr-adeline-extensions'),

                'content' => esc_attr__('This text will be displayed bellow title. By default is empty but can be overwriten per post or per page.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'subheader_title_animation',

            'type'     => 'switch',

            'default'  => false,

            'title'    => esc_html__('Use Subheader Title Animation', 'dpr-adeline-extensions'),

            'hint'     => array(

                'title'   => esc_attr__('Use Subheader Title Animation', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enable subheader title animation (vanishing by scroll down).', 'dpr-adeline-extensions'),

            ),

            'required' => array('subheader_display', 'equals', '1'),

        ),

    ),

));

Redux::setSection($opt_name, array(

    'title'      => esc_html__('Breadcrumb', 'dpr-adeline-extensions'),

    'subsection' => true,

    'fields'     => array(

        array(

            'id'      => 'breadcrumb_display',

            'type'    => 'switch',

            'default' => true,

            'title'   => esc_html__('Display Breadcrumb', 'dpr-adeline-extensions'),

            'hint'    => array(

                'title'   => esc_attr__('Display Breadcrumb', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enable or disable display breadcrumb in subheader area.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'breadcrumbs_position',

            'type'     => 'radio',

            'title'    => __('Breadcrumb Position', 'dpr-adeline-extensions'),

            'options'  => array(

                'default'     => 'Right Bottom',

                'under-title' => 'Under Title',

            ),

            'default'  => 'default',

            'hint'     => array(

                'title'   => esc_attr__('Breadcrumb Position', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set breadcrumb position', 'dpr-adeline-extensions'),

            ),

            'required' => array('breadcrumb_display', 'equals', '1'),

        ),

        array(

            'id'       => 'breadcrumb_color',

            'type'     => 'color',

            'title'    => __('Breadcrumb Color', 'dpr-adeline-extensions'),

            'default'  => '#292933',

            'output'   => array('.dpr-adeline-breadcrumbs'),

            'hint'     => array(

                'title'   => esc_attr__('Breadcrumb Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set breadcrumb color.', 'dpr-adeline-extensions'),

            ),

            'required' => array('breadcrumb_display', 'equals', '1'),

        ),

        array(

            'id'       => 'breadcrumb_separator_color',

            'type'     => 'color',

            'title'    => __('Breadcrumb Separators Color', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'output'   => array('.dpr-adeline-breadcrumbs ul li:after'),

            'hint'     => array(

                'title'   => esc_attr__('Breadcrumb Separators Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set breadcrumb separators color.', 'dpr-adeline-extensions'),

            ),

            'required' => array('breadcrumb_display', 'equals', '1'),

        ),

        array(

            'id'       => 'breadcrumb_link_color',

            'type'     => 'color',

            'title'    => __('Breadcrumb Links Color', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'output'   => array('.dpr-adeline-breadcrumbs a'),

            'hint'     => array(

                'title'   => esc_attr__('Breadcrumb Links Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set breadcrumb links color.', 'dpr-adeline-extensions'),

            ),

            'required' => array('breadcrumb_display', 'equals', '1'),

        ),

        array(

            'id'       => 'breadcrumb_link_color_hover',

            'type'     => 'color',

            'title'    => __('Breadcrumb Links Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'output'   => array('.dpr-adeline-breadcrumbs a:hover'),

            'hint'     => array(

                'title'   => esc_attr__('Breadcrumb Links Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set breadcrumb hover links color.', 'dpr-adeline-extensions'),

            ),

            'required' => array('breadcrumb_display', 'equals', '1'),

        ),

    ),

));
