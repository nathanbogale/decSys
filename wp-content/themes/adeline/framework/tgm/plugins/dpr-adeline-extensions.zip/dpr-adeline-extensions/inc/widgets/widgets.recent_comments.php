<?php



/**

 * 

 * Recent Comments Widget

 *

 **/



class DPR_Comments_Widget extends WP_Widget {

	/**

	 *

	 * Constructor

	 *

	 * @return void

	 *

	 **/

	function __construct() {

		parent::__construct(

			'widget_dpr_comments', 

			esc_attr__( 'DPR Comments', 'dpr-adeline-extensions' ), 

			array( 

				'classname' => 'widget_dpr_comments', 

				'description' => esc_attr__( 'Use this widget to show recent comments with avatars', 'dpr-adeline-extensions') 

			)

		);

		

		$this->alt_option_name = 'widget_dpr_comments';



		add_action( 'comment_post', array(&$this, 'refresh_cache' ) );

		add_action( 'comment_unapproved_to_approved', array(&$this, 'refresh_cache' ) );

		add_action( 'comment_approved_to_unapproved', array(&$this, 'refresh_cache' ) );

		add_action( 'trashed_comment', array(&$this, 'refresh_cache' ));

		// Post actions

		add_action('delete_post', array(&$this, 'refresh_cache'));

		add_action('trashed_post', array(&$this, 'refresh_cache'));

	}



	/**

	 *

	 * Outputs the HTML code of this widget.

	 *

	 * @param array An array of standard parameters for widgets in this theme

	 * @param array An array of settings for this widget instance

	 * @return void

	 *

	 **/

	function widget($args, $instance) {

		

		// the part with the title and widget wrappers cannot be cached! 

		// in order to avoid problems with the calculating columns

		//

		extract($args, EXTR_SKIP);

		$title = isset( $instance['title'] ) ? apply_filters( 'widget_title', $instance['title'] ) : '';

		

		echo $before_widget;

		echo $before_title;

		echo $title;

		echo $after_title;

		//

		$avatar_size = empty($instance['avatar_size']) ? 42 : $instance['avatar_size'];

		$word_count = empty($instance['word_count']) ? 10 : $instance['word_count'];

		$number = empty($instance['number']) ? 3 : $instance['number'];

		$show_avatar = empty($instance['show_avatar']) ? 3 : $instance['show_avatar'];

		$show_author = empty($instance['show_author']) ? 3 : $instance['show_author'];

		$show_title = empty($instance['show_title']) ? 3 : $instance['show_title'];

		$show_excerpt = empty($instance['show_excerpt']) ? 3 : $instance['show_excerpt'];

		$comments_args = array(

			'status' => 'approve',

			'order' => 'DESC',

			'number' => $number

		);

		$comments = get_comments($comments_args);

		//

		$padding = 0;

		if ( $show_avatar == 'on' ) {

			$padding = $avatar_size +15;

		}

		if (count($comments)) {			

			if(count($comments) > 0) { ?>

			<ul class="dpr-recent-comments clr">	

			<?php	

				for($i = 0; $i < count($comments); $i++) { ?>

					<li class="clr">

                    	<?php if ( $show_avatar == 'on') { ?>

							<a href="<?php echo get_comment_link($comments[$i]->comment_ID) ?>" class="recent-comments-avatar" style="width:<?php echo $avatar_size?>px"><?php echo get_avatar($comments[$i]->comment_author_email, $avatar_size);?></a>

                        <?php } ?>

                    

                        <div class="recent-comments-details clr" style="padding-left:<?php echo esc_attr($padding)?>px;">

                        	

                            <div class="recent-comments-details-inner clr">

                            	<?php if ( $show_author == 'on') { ?>

                                <span class="recent-comments-author"><?php echo $comments[$i]->comment_author; ?></span>

                                <?php } ?>

                                <?php if ( $show_title == 'on') { ?>

                                <span class="recent-comments-title">on <a href="<?php echo get_comment_link($comments[$i]->comment_ID) ?>"><?php echo get_the_title( $comments[$i]->comment_post_ID )?></a></span>

                                <?php } ?>

                                <?php if ( $show_excerpt == 'on') { ?>

                                <div class="recent-comments-excerpt">

                                <a href="<?php echo get_comment_link($comments[$i]->comment_ID) ?>"><?php echo $this->comment_text($comments[$i]->comment_content, $word_count) ?></a>

                                </div>

								<?php } ?>

                            </div>

                        

                        </div>

                                            

                    </li>

                    

                    <?php

					

				} ?>

			</ul>	

			<?php }

		} ?>

		

		<?php

		// 

		echo $after_widget;

	}



	/**

	 *

	 * Used in the back-end to update the module options

	 *

	 * @param array new instance of the widget settings

	 * @param array old instance of the widget settings

	 * @return updated instance of the widget settings

	 *

	 **/

	function update( $new_instance, $old_instance ) {

		$instance = $old_instance;

		$instance['title'] = strip_tags( $new_instance['title'] );

		$instance['avatar_size'] = strip_tags( $new_instance['avatar_size'] );

		$instance['word_count'] = strip_tags( $new_instance['word_count'] );

		$instance['number'] = strip_tags( $new_instance['number'] );

		$instance['show_avatar'] = strip_tags( $new_instance['show_avatar'] );

		$instance['show_author'] = strip_tags( $new_instance['show_author'] );

		$instance['show_title'] = strip_tags( $new_instance['show_title'] );

		$instance['show_excerpt'] = strip_tags( $new_instance['show_excerpt'] );

		$this->refresh_cache();



		$alloptions = wp_cache_get('alloptions', 'options');

		if(isset($alloptions['widget_dpr_comments'])) {

			delete_option( 'widget_dpr_comments' );

		}



		return $instance;

	}



	/**

	 *

	 * Refreshes the widget cache data

	 *

	 * @return void

	 *

	 **/



	function refresh_cache() {

		if(is_array(get_option('widget_widget_dpr_comments'))) {

	    	$ids = array_keys(get_option('widget_widget_dpr_comments'));

	    } else {

	    	$ids = array();

	    }

		    for($i = 0; $i < count($ids); $i++) {

		        if(is_numeric($ids[$i])) {

		            delete_transient(md5('widget_dpr_comments-' . $ids[$i]));

		        }

		    }

		}

	

	/**

	 *

	 * Limits the comment text to specified words amount

	 *

	 * @param string input text

	 * @param int amount of words

	 * @return string the cutted text

	 *

	 **/

	

	function comment_text($input, $amount = 10) {

		$output = '';

		$input = strip_tags($input);

		$input = explode(' ', $input);

		

		for($i = 0; $i < $amount; $i++) {

			if(isset($input[$i])) {

				$output .= $input[$i] . ' ';

			}

		}

	

		if(count($input) > $amount) {

			$output .= '&hellip;';

		}

	

		return $output;

	}



	/**

	 *

	 * Outputs the HTML code of the widget in the back-end

	 *

	 * @param array instance of the widget settings

	 * @return void - HTML output

	 *

	 **/

	function form($instance) {

		$title = isset($instance['title']) ? esc_attr($instance['title']) : '';

		$avatar_size = isset($instance['avatar_size']) ? esc_attr($instance['avatar_size']) : 42;

		$word_count = isset($instance['word_count']) ? esc_attr($instance['word_count']) : 10;

		$number = isset($instance['number']) ? esc_attr($instance['number']) : 5;

		$show_avatar = isset($instance['show_avatar']) ? esc_attr($instance['show_avatar']) : 'on';

		$show_author = isset($instance['show_author']) ? esc_attr($instance['show_author']) : 'on';

		$show_title = isset($instance['show_title']) ? esc_attr($instance['show_title']) : '';

		$show_excerpt = isset($instance['show_excerpt']) ? esc_attr($instance['show_excerpt']) : 'on';

	?>

		<p>

			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php _e( 'Title:', 'dpr-adeline-extensions' ); ?></label>

			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />

		</p>

		<p>

			<label for="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>"><?php _e( 'Number of comments:', 'dpr-adeline-extensions' ); ?></label>

			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'number' ) ); ?>" type="text" value="<?php echo esc_attr( $number ); ?>" />

		</p>

		

		<p>

			<label for="<?php echo esc_attr( $this->get_field_id( 'avatar_size' ) ); ?>"><?php _e( 'Avatar size (px):', 'dpr-adeline-extensions' ); ?></label>

			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'avatar_size' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'avatar_size' ) ); ?>" type="text" value="<?php echo esc_attr( $avatar_size ); ?>" />

		</p>

		

		<p>

			<label for="<?php echo esc_attr( $this->get_field_id( 'word_count' ) ); ?>"><?php _e( 'Word count in excerpt:', 'dpr-adeline-extensions' ); ?></label>

			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'word_count' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'word_count' ) ); ?>" type="text" value="<?php echo esc_attr( $word_count ); ?>" />

		</p>



        <div class="dpr-widget-inner-block">

            <h2><?php esc_html_e('Display Options', 'dpr-adeline-extensions'); ?></h2>



        <p>

            <label for="<?php echo esc_attr( $this->get_field_id( 'show_avatar' ) ); ?>">

                <input type="checkbox" name="<?php echo esc_attr( $this->get_field_name( 'show_avatar' ) ); ?>" id="<?php echo esc_attr( $this->get_field_id( 'show_avatar' ) ); ?>" <?php checked( $show_avatar , 'on' ); ?> />

                <?php esc_html_e( 'Show Avatars', 'dpr-adeline-extensions' ); ?>

            </label>

        </p>



        <p>

            <label for="<?php echo esc_attr( $this->get_field_id( 'show_author' ) ); ?>">

                <input type="checkbox" name="<?php echo esc_attr( $this->get_field_name( 'show_author' ) ); ?>" id="<?php echo esc_attr( $this->get_field_id( 'show_author' ) ); ?>" <?php checked( $show_author , 'on' ); ?> />

                <?php esc_html_e( 'Show Author Name', 'dpr-adeline-extensions' ); ?>

            </label>

        </p>



        <p>

            <label for="<?php echo esc_attr( $this->get_field_id( 'show_title' ) ); ?>">

                <input type="checkbox" name="<?php echo esc_attr( $this->get_field_name( 'show_title' ) ); ?>" id="<?php echo esc_attr( $this->get_field_id( 'show_title' ) ); ?>" <?php checked( $show_title , 'on' ); ?> />

                <?php esc_html_e( 'Show Post Title', 'dpr-adeline-extensions' ); ?>

            </label>

        </p>



        <p>

            <label for="<?php echo esc_attr( $this->get_field_id( 'show_excerpt' ) ); ?>">

                <input type="checkbox" name="<?php echo esc_attr( $this->get_field_name( 'show_excerpt' ) ); ?>" id="<?php echo esc_attr( $this->get_field_id( 'show_excerpt' ) ); ?>" <?php checked( $show_excerpt , 'on' ); ?> />

                <?php esc_html_e( 'Show Comment Excerpt', 'dpr-adeline-extensions' ); ?>

            </label>

        </p>

        

        </div>



	<?php

	}

}



// EOF