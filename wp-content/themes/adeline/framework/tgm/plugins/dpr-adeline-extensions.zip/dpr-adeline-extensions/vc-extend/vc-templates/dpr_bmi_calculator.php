<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$output = $unique_id = $id = $style = $css_animation = $css = $el_class = $custom_el_css  = '';
$title = $unit_type = $allow_unit_switch = $display_table = $table_position = $table_title = '';
$input_color = $placeholder_color =  $border_color = $border_color_focus = $bg_color = $bg_color_focus = $field_border_radius = $radio_color = '';
$button_title = $button_style = $button_size = $button_shape = $button_alignment = $full_width = $button_border_width = $button_border_radius = $button_color = $button_color_hover = $button_bg_color = $button_bg_color_hover = $button_border_color = $button_border_color_hover = '';
$result_bg = $result_color = $result_icon_color = $th_color = $th_bg = $td_color = $td_bg = $td_color_odd = $td_bg_odd = $table_border_color = $table_border_width = $table_border_radius = '';
$input_font_size = $input_line_height  = $input_letter_spacing = $input_font_style = $input_google_font = $input_typo_css = '';
$description_font_size = $description_line_height  = $description_letter_spacing = $description_font_style = $description_google_font = $description_typo_css =  '';
$table_font_size = $table_line_height  = $table_letter_spacing = $table_font_style = $table_google_font = $table_typo_css =   '';
$result_html = $form_html = $button_html = $table_html = '';

$atts = vc_map_get_attributes( 'dpr_bmi_calculator', $atts );
extract( $atts );
wp_enqueue_script('dpr-bmi-calculator', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/dpr.bmicalculator.js', array('jquery'), null, true);	

$unique_id = uniqid('dpr-bmi-calc-').'-'.rand(1,9999);

/* CSS Classes and styles */
if ( '' !== $css_animation && 'none' !== $css_animation ) {
	dpr_enqueue_waypoint_js();
	dpr_enqueue_animate_css();
	$el_class .= ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
}

if ($display_table == "yes") { 
	$el_class .= ' table-position-'.$table_position;
}
/* Output */
$css_classes = array(
	'dpr-bmi-calculator',
	$unique_id,
	$el_class,
	vc_shortcode_custom_css_class( $css ),
);


$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->settings['base'], $atts ) );


// Custom CSS stuff
$title_typo_css = dpr_generate_typography_css($title_color, $title_font_size, $title_line_height, $title_letter_spacing, $title_font_style,$title_google_font);

$input_typo_css = dpr_generate_typography_css('', $input_font_size, $input_line_height, $input_letter_spacing, $input_font_style,$input_google_font);

$description_typo_css = dpr_generate_typography_css($description_color, $description_font_size, $description_line_height, $description_letter_spacing, $description_font_style, $description_google_font);

$table_typo_css = dpr_generate_typography_css($table_color, $table_font_size, $table_line_height, $table_letter_spacing, $table_font_style, $table_google_font);

if(isset($input_color) && $input_color != '' ) {
		$custom_el_css .= ".".esc_js($unique_id)." form input:not([type='submit']), .".esc_js($unique_id)." form textarea, .".esc_js($unique_id)." form select {color:".$input_color.";".$input_typo_css."}";
}
if(isset($input_typo_css) && $input_typo_css != '' ) {
		$custom_el_css .= ".".esc_js($unique_id)." form input:not([type='submit']), .".esc_js($unique_id)." form textarea, .".esc_js($unique_id)." form select {".$input_typo_css."}";
}

if(isset($placeholder_color) && $placeholder_color != '') {
		$custom_el_css .= ".".esc_js($unique_id)." form input::placeholder, .".esc_js($unique_id)." form textarea::placeholder, .".esc_js($unique_id)." form select::placeholder {color:".$placeholder_color.";}";
}
if(isset( $border_color) &&  $border_color != '') {
		$custom_el_css .= ".".esc_js($unique_id)." form input:not([type='submit']), .".esc_js($unique_id)." form textarea, .".esc_js($unique_id)." form select {border-color:". $border_color.";}";
}
if(isset( $border_color_focus) &&  $border_color_focus != '') {
		$custom_el_css .= ".".esc_js($unique_id)." form input:not([type='submit']):focus, .".esc_js($unique_id)." form textarea:focus, .".esc_js($unique_id)." form select:focus {border-color:". $border_color_focus.";}";
}
if(isset( $bg_color) &&  $bg_color != '') {
		$custom_el_css .= ".".esc_js($unique_id)." form input:not([type='submit']), .".esc_js($unique_id)." form textarea, .".esc_js($unique_id)." form select {background-color:". $bg_color.";}";
}
if(isset( $bg_color_focus) &&  $bg_color_focus != '') {
		$custom_el_css .= ".".esc_js($unique_id)." form input:not([type='submit']):focus, .".esc_js($unique_id)." form textarea:focus, .".esc_js($unique_id)." form select:focus {background-color:". $bg_color_focus.";}";
}
if(isset( $bg_color) &&  $bg_color != '') {
		$custom_el_css .= ".".esc_js($unique_id)." form input:not([type='submit']), .".esc_js($unique_id)." form textarea, .".esc_js($unique_id)." form select {background-color:". $bg_color.";}";
}
if(isset( $field_border_radius) &&  $field_border_radius != '') {
		$custom_el_css .= ".".esc_js($unique_id)." form input:not([type='submit']) {border-radius:". $field_border_radius."px;}";
}

if(isset( $radio_color) &&  $radio_color != '') {
		$custom_el_css .= ".".esc_js($unique_id)." .pure-checkbox input[type='radio']:focus + label:before, .".esc_js($unique_id)." .pure-checkbox input[type='radio']:hover + label:before, .".esc_js($unique_id)." .pure-radiobutton input[type='radio']:hover + label:before, .".esc_js($unique_id)." form textarea, .".esc_js($unique_id)." .pure-radiobutton input[type='radio']:focus + label:before, .".esc_js($unique_id)." .pure-checkbox input[type='radio'] + label:before, .".esc_js($unique_id)." .pure-radiobutton input[type='radio'] + label:before {border-color:". $radio_color.";}";
		$custom_el_css .= ".".esc_js($unique_id)." .pure-checkbox input[type='radio'] + label:after, .".esc_js($unique_id)." .pure-radiobutton input[type='radio'] + label:after {background-color:". $radio_color.";}";
}

if ($button_color != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .dpr-bmi-submit {color:'.$button_color.' !important}' ;
}
if ($button_bg_color != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .dpr-bmi-submit {background-color:'.$button_bg_color.' !important}' ;
}
if ($button_border_color != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .dpr-bmi-submit {border-color:'.$button_border_color.' !important}' ;
}
if ($button_color_hover != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .dpr-bmi-submit:hover {color:'.$button_color_hover.' !important}' ;
}
if ($button_bg_color_hover != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .dpr-bmi-submit:hover {background-color:'.$button_bg_color_hover.' !important}' ;
}
if ($button_border_color_hover != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .dpr-bmi-submit:hover {border-color:'.$button_border_color_hover.' !important}' ;
}
if ($button_border_radius != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .dpr-bmi-submit {border-radius:'.$button_border_radius.'px !important}' ;
}
if ($button_border_width != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .dpr-bmi-submit {border-width:'.$button_border_width.'px !important}' ;
}
if ($title_typo_css != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .dpr-bmi-calc-title {'.$title_typo_css.'}' ;
}
if ($description_typo_css != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .dpr-bmi-calc-desc {'.$description_typo_css.'}' ;
}

if ($th_color != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .bmi-chart th  {color:'.$th_color.'}' ;
}
if ($th_bg != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .bmi-chart th  {background-color:'.$th_bg.'}' ;
}
if ($td_color != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .bmi-chart tr:nth-child(even) td  {color:'.$td_color.'}' ;
}
if ($td_bg != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .bmi-chart tr:nth-child(even) td  {background-color:'.$td_bg.'}' ;
}
if ($td_color_odd != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .bmi-chart tr:nth-child(odd) td  {color:'.$td_color_odd.'}' ;
}
if ($td_bg_odd != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .bmi-chart tr:nth-child(odd) td  {background-color:'.$td_bg_odd.'}' ;
}
if ($table_border_width != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .bmi-chart tr td, .'.esc_js($unique_id).' .bmi-chart tr th  {border-bottom-width:'.$table_border_width.'px}' ;
}
if ($table_border_color != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .bmi-chart tr td, .'.esc_js($unique_id).' .bmi-chart tr th  {border-bottom-color:'.$table_border_color.'}' ;
}
if ($table_border_radius != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .bmi-chart {border-radius:'.$table_border_radius.'px;}' ;
}
if ($result_bg != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .dpr-bmi-result {background-color:'.$result_bg.';}' ;
}
if ($result_color != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .dpr-bmi-result {color:'.$result_color.';}' ;
}
if ($result_icon_color != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .dpr-bmi-result .dpr-bmi-icon {color:'.$result_icon_color.';}' ;
}







/* HTML Parts */
$metric_checked = $imperial_checked = $metric_style = $imperial_style = '';
if ( $unit_type == 'imperial' ) {
	$imperial_checked = ' checked';
	$metric_style = ' style="display:none;"';
}
else {
	$metric_checked = ' checked';
	$imperial_style = ' style="display:none;"';
}

$metric_radio_html = '<div class="pure-radiobutton"><input id="dpr-bmi-metric-' . $unique_id . '" type="radio" name="dpr-bmi-unit" value="metric"' . $metric_checked . '><label for="dpr-bmi-metric-' . $unique_id . '">' . __( 'Metric Units', 'dpr-adeline-extensions' ) . '</label></div>';
$imperial_radio_html = '<div class="pure-radiobutton"><input id="dpr-bmi-imperial-' . $unique_id . '" type="radio" name="dpr-bmi-unit" value="imperial"' . $imperial_checked . '><label for="dpr-bmi-imperial-' . $unique_id. '">' . __( 'Imperial Units', 'dpr-adeline-extensions' ) . '</label></div>';

if ( $unit_type == 'imperial' ) {
	$radio_html = $imperial_radio_html . $metric_radio_html;
}
else {
	$radio_html = $metric_radio_html . $imperial_radio_html;	
}
$bmi_result = array(
	array( __( 'Below 18.5', 'dpr-adeline-extensions' ),   __( 'Underweight', 'dpr-adeline-extensions' ),'bmi-icon-underweight' ),
	array( __( '18.5 - 24.9', 'dpr-adeline-extensions' ),  __( 'Normal', 'dpr-adeline-extensions' ),'bmi-icon-normal' ),
	array( __( '25 - 29.9', 'dpr-adeline-extensions' ),  __( 'Overweight', 'dpr-adeline-extensions' ),'bmi-icon-overweight' ),
	array( __( '30 -35', 'dpr-adeline-extensions' ), __( 'Obese', 'dpr-adeline-extensions' ),'bmi-icon-obese' ),
	array( __( '35 and Above', 'dpr-adeline-extensions' ), __( 'Extremely Obese', 'dpr-adeline-extensions' ),'bmi-icon-extremely-obese' ),
);
$bmi_result_encoded = json_encode( $bmi_result );




$btn_class = 'btn dpr-bmi-submit '.$button_style.' '.$button_size.' '.$button_shape;
if( $full_width == 'yes') {
$btn_class .= ' btn-block';
}
$button_html .= '<div class="'.$button_alignment.'">';
$button_html .= '<button class="'.$btn_class.'"><span class="button-text ">'.esc_html($button_title).'</span></button>';
$button_html .= '</div>';

/* Form HTML */
if ($title != '') {
	$form_html .= '<h3 class="dpr-bmi-calc-title">'.$title.'</h3>';
}
$form_html .= '<div class="dpr-bmi-calc-desc">'.do_shortcode($content).'</div>';


$form_html .= '<form class="dpr-bmi-form">';
if ($allow_unit_switch == 'yes') {
$form_html .= '<div class="dpr-bmi-radio">';
$form_html .= $radio_html;
$form_html .= '</div>';
}
$form_html .= '<div class="dpr-bmi-fields">';
$form_html .= '<div class="dpr-adeline-row clr dpr-bmi-fields-metric"'.$metric_style.'>';
$form_html .= '<div class="col span_1_of_2">';
$form_html .= '<input type="text" name="dpr-bmi-weight" placeholder="'.__( 'Weight / kg', 'dpr-adeline-extensions' ).'">';
$form_html .= '</div>';
$form_html .= '<div class="col span_1_of_2">';
$form_html .= '<input type="text" name="dpr-bmi-height" placeholder="'. __( 'Height / cm', 'dpr-adeline-extensions' ).'">';
$form_html .= '</div>';
$form_html .= '</div>';
$form_html .= '<div class="dpr-adeline-row clr dpr-bmi-fields-imperial"'.$imperial_style.'>';
$form_html .= '<div class="col span_1_of_3">';
$form_html .= '<input type="text" name="dpr-bmi-pound" placeholder="'.__( 'Weight / lbs', 'dpr-adeline-extensions' ).'">';
$form_html .= '</div>';
$form_html .= '<div class="col span_1_of_3">';
$form_html .= '<input type="text" name="dpr-bmi-feet" placeholder="'.__( 'Height / feet', 'dpr-adeline-extensions' ).'">';
$form_html .= '</div>';
$form_html .= '<div class="col span_1_of_3">';
$form_html .= '<input type="text" name="dpr-bmi-inch" placeholder="'.__( 'Height / inch', 'dpr-adeline-extensions' ).'">';
$form_html .= '</div>';
$form_html .= '</div>';
$form_html .= '</div>';
$form_html .= $button_html;
$form_html .= '</form>';

/* Result HTML */
$result_html .= '<div class="dpr-bmi-error" data-emptymsg="'.__( 'Error: One or more fields are empty', 'dpr-adeline-extensions' ).'" data-numbermsg="'. __( 'Error: All field values must be a number', 'dpr-adeline-extensions' ).'"><p></p><a class="close"></a></div>';

$result_html .= '<div class="dpr-bmi-result" style="display:none;" data-chart="'. esc_attr( $bmi_result_encoded ).'"><span class="dpr-bmi-icon"></span><p>'. __( 'Your BMI is:', 'dpr-adeline-extensions' ).' <span class="dpr-bmi-val"></span> '. __( ', and weight status is:', 'dpr-adeline-extensions' ).' <span class="dpr-bmi-status"></span></p><a class="close"></a></div>';

/* Table HTML */

if ( $display_table  == 'yes') {
	if ($table_title != '') {
		$table_html .= '<h3 class="dpr-bmi-calc-title">'.$table_title.'</h3>';
	}

				$table_html .= '<table class="bmi-chart">';
				$table_html .= '<tr>';
				$table_html .= '<th>'. __( 'BMI', 'gymedge-core' ).'</th>';
				$table_html .= '<th>'. __( 'Weight Status', 'gymedge-core' ).'</th>';
				$table_html .= '</tr>';
				foreach ( $bmi_result as $result ): 
				$table_html .= '<tr>';
				$table_html .= '<td>'. $result[0].'</td>';
				$table_html .= '<td>'. $result[1].'</td>';
				$table_html .= '</tr>';						
				endforeach; 
				$table_html .= '</table>';

}

?>

<div id="<?php echo esc_attr($unique_id) ?>" class="<?php echo esc_attr($css_class) ?>">
<div class="dpr-adeline-row clr">
<?php if ($display_table == 'yes') { ?>
<div class="col span_1_of_2 first-column">
	<?php if ($table_position == 'left') { 
    echo $table_html;
   } else { 
     echo $form_html;
   } ?>

</div>
<div class="col span_1_of_2">
	<?php if ($table_position == 'left') { 
    echo $form_html;
     } else { 
    echo $table_html;
    } ?>

</div>
<?php } else { ?>
<div class="col span_1_of_1">
<?php echo $form_html; ?>
</div>
<?php } ?>
</div>
<div class="dpr-adeline-row clr">
    <div class="col span_1_of_1">
    <?php echo $result_html ; ?>
    </div>
</div>

<?php
	if(!empty($custom_el_css)) {
		$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>");'
						. '})(jQuery);'
					. '</script>';
}



echo $output;
?>
</div>
