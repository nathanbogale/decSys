<?php







if ( !function_exists( "dpr_post_format_audio_sections " ) ):



    function dpr_post_format_audio_sections() {



		/*



     	* ---> START POST FORMAT AUDIO METABOX SECTIONS



		*/







		$post_format_audio_sections = array();



		$post_format_audio_sections[] = array(



			'fields'   => array(



								array(



									'id'       => 'audio_post_oembed_audio_url',



									'type'     => 'text',



									'title'    => __('oEmbed Audio URL ', 'dpr-adeline-extensions'), 



									'desc'     => __('Enter a audio URL that is compatible with WordPress built-in oEmbed feature.<br/><a href="http://codex.wordpress.org/Embeds" target="_blank">Learn More</a>', 'dpr-adeline-extensions'),



									'default' => '',



								),



								array(



									'id' => 'audio_post_self_hosted_audio_url',



									'type' => 'media',



									'title' => esc_html__('Self Hosted Audio', 'dpr-adeline-extensions'),



									'url' => true,



									'mode' => false,



									'readonly' => false,



									'preview' => false,



									'desc'     => __('Enter your self hosted audio URL<br/><a href="http://make.wordpress.org/core/2013/04/08/audio-video-support-in-core/" target="_blank">Learn More</a>', 'dpr-adeline-extensions'),



								),



								array(



									'id'       => 'audio_post_embed_code',



									'title'    =>  __( 'Embed Code', 'dpr-adeline-extensions' ),



									'type'     => 'textarea',



									'default'  => '',



									'desc'     => __('Enter your embed/iframe code<br/><a href="https://wordpress.org/plugins/iframe/" target="_blank">Learn More</a>', 'dpr-adeline-extensions'),



								),



								array(



									'id'       => 'audio_single_view_thumb',



									'type'     => 'switch',



									'title'    =>  esc_html__('Single Post View Thumbnail?','dpr-adeline-extensions'),



									'hint' => array(



										'title'   => esc_attr__('Single Post View Thumbnail?','dpr-adeline-extensions'),



										'content' =>  esc_attr__('Enable display featured image in single post view','dpr-adeline-extensions')



									)







								),



								array(



									'id'       => 'audio_archive_view_thumb',



									'type'     => 'switch',



									'title'    =>  esc_html__('Archive Page Thumbnail?','dpr-adeline-extensions'),



									'hint' => array(



										'title'   => esc_attr__('Archive Page Thumbnail?','dpr-adeline-extensions'),



										'content' =>  esc_attr__('Enable display featured image on archive pages','dpr-adeline-extensions')



									)



								),



			)



		);



		



		/*



     	* ---> END POST FORMAT AUDIO METABOX SECTIONS



		*/



		







        return $post_format_audio_sections;



    }



endif;