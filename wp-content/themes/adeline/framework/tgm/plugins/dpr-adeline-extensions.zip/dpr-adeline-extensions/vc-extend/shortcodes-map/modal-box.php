<?php

// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}

/*

* Add-on Name: Modal Box

*/



class WPBakeryShortCode_DPR_Modal_Box extends WPBakeryShortCodesContainer { }

new dpr_hide_frontend("dpr_modal_box");



vc_map(

	array(

		'name'					=> esc_html__('DP Modal Box', 'dpr-adeline-extensions'),

		'base'					=> 'dpr_modal_box',

		'class'					=> 'dpr_modal_box',

		'icon'					=> 'icon-dpr-modal-box',

		'content_element'		=> true,

		'js_view'				=> 'VcColumnView',

		'controls'				=> 'full',

		'as_parent'				=> array('except' => array('dpr_modal_box')),

  		"category" 				=>array( esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions')),

		'description' 			=> esc_html__('Display modal box','dpr-adeline-extensions'),

		'params'				=> array(

			array(

				'type'				=> 'dpr_radio',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Delay: modal box appear after predefined time out. On Click: modal box appear on button click. On scroll: modal box appear on scroll','dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Appearance Options', 'dpr-adeline-extensions'),

				'param_name'		=> 'apear_options',

				'value'				=> 'on-click',

				'options'			=> array(

					esc_html__('On Click', 'dpr-adeline-extensions')	=> 'on-click',

					esc_html__('Delay', 'dpr-adeline-extensions')		=> 'delay',

					esc_html__('On Scroll', 'dpr-adeline-extensions')	=> 'on-scroll'

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

			),

			array(

				 "type" => "dropdown",

				 "holder" => "",

				 'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set animation type for modal box display.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Animation of Appearance', 'dpr-adeline-extensions'),

			     "param_name" => "animation",

			  	 "value" => array ("Fade in scale" => "md-style-1",

								"Slide in right" => "md-style-2",

								"Slide in bottom" => "md-style-3",

								"Rotate in" => "md-style-4",

								"Fall in" => "md-style-5",

								"Fall from side" => "md-style-6",

								"Sticky up" => "md-style-7",

								"Flip horizontal" => "md-style-8",

								"Flip vertical" => "md-style-9",

								"Sign" => "md-style-10",

								"Super scaled" => "md-style-11"

								),

				'edit_field_class' => 'vc_column vc_col-sm-6 no-padding-top',

			),

			array(

				'type' => 'number',

				'class' => '',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set delay for modal box display after page load.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Timeout', 'dpr-adeline-extensions'),

				'param_name' => 'delay_time',

				'value' => '3000',

				'suffix' => 'ms',

				'min' => '0',

				'step' => '10',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'apear_options', 'value' => 'delay'),

			),

			array(

				'type'				=> 'dpr_radio',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Set display frequency.Only once or set time after which the modal will be displayed again.','dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Display Frequency', 'dpr-adeline-extensions'),

				'param_name'		=> 'display_frequency',

				'value'				=> 'once-per-session',

				'options'			=> array(

					esc_html__('Every Page View', 'dpr-adeline-extensions')		=> 'allways',

					esc_html__('Once Per Session', 'dpr-adeline-extensions')	=> 'once-per-session',

					esc_html__('Every Few Days', 'dpr-adeline-extensions')		=> 'every-few-day'

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'apear_options', 'value' => array('delay','on-scroll')),

			),

			array(

				'type'				=> 'textfield',

				'heading'			=> esc_html__('Cookie Name', 'dpr-adeline-extensions'),

				'param_name'		=> 'cookie_name',

				'value'				=> uniqid('dpr-cookie-').'-'.rand(1,9999),

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'dependency'		=> array('element' => 'display_frequency', 'value' => array('every-few-day','once-per-session')),

			),

			array(

				'type' => 'number',

				'class' => '',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set days count after which the modal will be displayed again.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Display Again After', 'dpr-adeline-extensions'),

				'param_name' => 'repeat_after',

				'value' => '3',

				'suffix' => 'days',

				'min' => '0',

				'step' => '1',

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'dependency'		=> array('element' => 'display_frequency', 'value' => array('every-few-day')),

			),

			

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Additional Settings', 'dpr-adeline-extensions' ),

				'param_name'       => 'extra_features_title',

				'edit_field_class' => 'vc_column vc_col-sm-12',

			),

		   vc_map_add_css_animation( false ),

		    array(

				'type' => 'textfield',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Extra Class Name', 'dpr-adeline-extensions'),

				'param_name' => 'el_class',

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Overlay Settings', 'dpr-adeline-extensions' ),

				'param_name'       => 'style_title_1',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the color for overlay background.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Overlay Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'overlay_background',

				'value' 			=> 'rgba(0,0,0,0.8)',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),



			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the color for modal close button.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Close Button Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'close_color',

				'value' 			=> '#fff',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the background color for modal close button .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Close Button Background', 'dpr-adeline-extensions'),

				'param_name'		=> 'close_bg',

				'value' 			=> '#D3AE5F',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			

			

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Modal Box Settings', 'dpr-adeline-extensions' ),

				'param_name'       => 'style_title_2',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Specify the width of the modal box', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Modal Box Size', 'dpr-adeline-extensions'),

				'param_name' => 'box_width',

				'suffix' => 'px',

				'min' => 0,

				'value' => 640,

				'edit_field_class' => 'vc_column vc_col-sm-4',

				'group' => esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Specify the top and bottom padding for modal box. Default is 30px.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Top/Bottom Padding', 'dpr-adeline-extensions'),

				'param_name' => 'box_vertical_padding',

				'suffix' => 'px',

				'min' => 0,

				'edit_field_class' => 'vc_column vc_col-sm-4',

				'group' => esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Specify the left and right padding for modal box. Default is 30px.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Left/Right Padding', 'dpr-adeline-extensions'),

				'param_name' => 'box_horizontal_padding',

				'suffix' => 'px',

				'min' => 0,

				'edit_field_class' => 'vc_column vc_col-sm-4',

				'group' => esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_radio',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Choose background style for the modal box content','dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Box Background Type', 'dpr-adeline-extensions'),

				'param_name'		=> 'box_bg_type',

				'value'				=> 'color',

				'options'			=> array(

					esc_html__('Color', 'dpr-adeline-extensions')		=> 'color',

					esc_html__('Image', 'dpr-adeline-extensions')		=> 'image'

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group' => esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the color for the box background.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'box_bg_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'dependency'		=> array('element' => 'box_bg_type', 'value' => array('color')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'attach_image',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Upload the image which will be set as box background.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background Image', 'dpr-adeline-extensions'),

				'param_name' => 'box_bg_image',

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'dependency'		=> array('element' => 'box_bg_type', 'value' => array('image')),

				'group'			   => esc_html('Style','dpr-adeline-extensions')

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose modal box border style.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Box Border Style', 'dpr-adeline-extensions'),

				'param_name'		=> 'box_border_style',

				'value'				=> '',

				'options'		=> array(

						esc_html__('None', 'dpr-adeline-extensions') 	=> '',

						esc_html__('Solid', 'dpr-adeline-extensions') 	=> 'solid',

						esc_html__('Dashed', 'dpr-adeline-extensions') 	=> 'dashed',

						esc_html__('Dotted', 'dpr-adeline-extensions')	=> 'dotted',

						esc_html__('Outset', 'dpr-adeline-extensions') 	=> 'outset',

						esc_html__('Inset', 'dpr-adeline-extensions') 	=> 'inset',

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'			   => esc_html('Style','dpr-adeline-extensions')

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set border width', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border width', 'dpr-adeline-extensions'),

				'param_name'		=> 'box_border_width',

				'suffix' 			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'dependency'		=> array('element' => 'box_border_style', 'not_empty' => true),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the color for box border.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border color', 'dpr-adeline-extensions'),

				'param_name'		=> 'box_border_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'dependency'		=> array('element' => 'box_border_style', 'not_empty' => true),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Button Settings', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_button_1',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'apear_options', 'value'   => 'on-click'),

				'group'				=> esc_html__('Button Settings', 'dpr-adeline-extensions'),

			),

			array(

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose button type.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Type', 'dpr-adeline-extensions'),

				'type'				=> 'dpr_image_select',

				'param_name'		=> 'btn_type',

				'simple_mode'		=> false,

				'value' 			=> 'type-1',

				'options'			=> array(

					'type-1'			=> array(

						'label'			=> esc_html__('No Icon', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'button/type-1.png'

					),

					'type-2'			=> array(

						'label'			=> esc_html__('Icon Left', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'button/type-2.png'

					),

					'type-3'			=> array(

						'label'			=> esc_html__('Icon Right', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'button/type-3.png'

					),

					'type-4'			=> array(

						'label'			=> esc_html__('Icon on Hover Left', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'button/type-4.png'

					),

					'type-5'			=> array(

						'label'			=> esc_html__('Icon on hover Right', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'button/type-5.png'

					),

					'type-6'			=> array(

						'label'			=> esc_html__('Only icon on hover', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'button/type-6.png'

					),

				),

				'dependency'		=> array('element' => 'apear_options', 'value'   => 'on-click'),

				'group'				=> esc_html__('Button Settings', 'dpr-adeline-extensions'),

			),

			array(

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose button style.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Style', 'dpr-adeline-extensions'),

				'type'				=> 'dpr_image_select',

				'param_name'		=> 'btn_style',

				'value' 			=> 'flat',

				'dependency'		=> array('element' => 'apear_options', 'value'   => 'on-click'),

				'group'				=> esc_html__('Button Settings', 'dpr-adeline-extensions'),

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'options'			=> array(

					'flat'			=> array(

						'label'			=> esc_html__('Flat', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'button/flat.png'

					),

					'btn-outlined'			=> array(

						'label'			=> esc_html__('Outlined', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'button/outlined.png'

					)

				)

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to choose the horizontal alignment for the button.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Alignment', 'dpr-adeline-extensions'),

				'param_name'		=> 'button_alignment',

				'value'				=> '',

				'options'			=> array(

					esc_html__('Left', 'dpr-adeline-extensions')	=> '',

					esc_html__('Center', 'dpr-adeline-extensions')	=> 'text-center',

					esc_html__('Right', 'dpr-adeline-extensions')	=> 'text-right'

				),

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'dependency'		=> array('element' => 'apear_options', 'value'   => 'on-click'),

				'group'				=> esc_html__('Button Settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom button size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom button size', 'dpr-adeline-extensions'),

				'param_name'		=> 'size',

				'value'				=> 'btn-sm',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'options'			=> array(

					esc_html__('Default', 'dpr-adeline-extensions')		=> '',

					esc_html__('Large', 'dpr-adeline-extensions') => 'btn-lg',

					esc_html__('Extra Large', 'dpr-adeline-extensions')	=> 'btn-xl',

					esc_html__('Small', 'dpr-adeline-extensions')	=> 'btn-sm',

				),

				'dependency'		=> array('element' => 'apear_options', 'value'   => 'on-click'),

				'group'				=> esc_html__('Button Settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom button shape.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom button shape', 'dpr-adeline-extensions'),

				'param_name'		=> 'shape',

				'value'				=> '',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'options'			=> array(

					esc_html__('Default', 'dpr-adeline-extensions')		=> '',

					esc_html__('Rounded', 'dpr-adeline-extensions') => 'btn-round',

					esc_html__('Circle', 'dpr-adeline-extensions')	=> 'btn-circle',

					esc_html__('Square', 'dpr-adeline-extensions')	=> 'btn-square',

				),

				'dependency'		=> array('element' => 'apear_options', 'value'   => 'on-click'),

				'group'				=> esc_html__('Button Settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'textfield',

				'heading'			=> esc_html__('Button text', 'dpr-adeline-extensions'),

				'param_name'		=> 'title',

				'value'				=> esc_html__('Button Text', 'dpr-adeline-extensions'),

				'edit_field_class'	=> 'vc_col-sm-12 vc_column ',

				'dependency'		=> array('element' => 'apear_options', 'value'   => 'on-click'),

				'group'				=> esc_html__('Button Settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Button Icon', 'dpr-adeline-extensions'),

				'param_name'		=> 'button_title_2',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'btn_type', 'value' => array('type-2', 'type-3', 'type-4', 'type-5', 'type-6')),

				'group'				=> esc_html__('Button Settings', 'dpr-adeline-extensions'),

			),

		  array(

				"type" => "dpr_icon_selector",

				"heading" => esc_attr__("Icon", 'dpr-adeline-extensions'),

				"param_name" => "icon",

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select icon.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'btn_type', 'value' => array('type-2', 'type-3', 'type-4', 'type-5', 'type-6')),

				'group'				=> esc_html__('Button Settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set the custom size for the icon. The default value is 12px.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon size', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_size',

				'min'				=> 1,

				'suffix'   			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4  ',

				'dependency'		=> array('element' => 'btn_type', 'value' => array('type-2', 'type-3', 'type-4', 'type-5', 'type-6')),

				'group'				=> esc_html__('Button Settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom icon color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_color',

				'edit_field_class'	=> 'vc_col-sm-4 vc_column ',

				'dependency'		=> array('element' => 'btn_type', 'value' => array('type-2', 'type-3', 'type-4', 'type-5', 'type-6')),

				'group'				=> esc_html__('Button Settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom icon color on hover', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon Color Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_color_hover',

				'edit_field_class'	=> 'vc_col-sm-4 vc_column ',

				'dependency'		=> array('element' => 'btn_type', 'value' => array('type-2', 'type-3', 'type-4', 'type-5', 'type-6')),

				'group'				=> esc_html__('Button Settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Button Custom Style', 'dpr-adeline-extensions'),

				'param_name'		=> 'button_title_3',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'apear_options', 'value'   => 'on-click'),

				'group'				=> esc_html__('Button Settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom button text color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'button_color',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'dependency'		=> array('element' => 'apear_options', 'value'   => 'on-click'),

				'group'				=> esc_html__('Button Settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom button text color hover', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'button_color_hover',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'dependency'		=> array('element' => 'apear_options', 'value'   => 'on-click'),

				'group'				=> esc_html__('Button Settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom button background color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background', 'dpr-adeline-extensions'),

				'param_name'		=> 'button_bg_color',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'dependency'		=> array('element' => 'apear_options', 'value'   => 'on-click'),

				'group'				=> esc_html__('Button Settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom button background color hover', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'button_bg_color_hover',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'dependency'		=> array('element' => 'apear_options', 'value'   => 'on-click'),

				'group'				=> esc_html__('Button Settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom button border color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border', 'dpr-adeline-extensions'),

				'param_name'		=> 'button_border_color',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'dependency'		=> array('element' => 'apear_options', 'value'   => 'on-click'),

				'group'				=> esc_html__('Button Settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom button border color hover', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'button_border_color_hover',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'dependency'		=> array('element' => 'apear_options', 'value'   => 'on-click'),

				'group'				=> esc_html__('Button Settings', 'dpr-adeline-extensions'),

			),

			array(

				"type" => "dpr_shadow_picker",

				"class" => "",

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set shadow for this button.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Shadow', 'dpr-adeline-extensions'),

				"param_name" => "button_shadow",

				"value" => "none||||||",

				'dependency'		=> array('element' => 'apear_options', 'value'   => 'on-click'),

				'group'				=> esc_html__('Button Settings', 'dpr-adeline-extensions'),

			),

			array(

				"type" => "dpr_shadow_picker",

				"class" => "",

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set shadow for this button in hover state.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Shadow Hover', 'dpr-adeline-extensions'),

				"param_name" => "button_shadow_hover",

				"value" => "none||||||",

				'dependency'		=> array('element' => 'apear_options', 'value'   => 'on-click'),

				'group'				=> esc_html__('Button Settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Button Text Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'button_title_4',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'apear_options', 'value'   => 'on-click'),

				'group'				=> esc_html__('Button Settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom text font size. If you leave this field blank will be used default size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

				'dependency'		=> array('element' => 'apear_options', 'value'   => 'on-click'),

				'group'				=> esc_html__('Button Settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom button text line height.Default is 18px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

				'dependency'		=> array('element' => 'apear_options', 'value'   => 'on-click'),

				'group'				=> esc_html__('Button Settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom button text letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

				'dependency'		=> array('element' => 'apear_options', 'value'   => 'on-click'),

				'group'				=> esc_html__('Button Settings', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom button text font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'title_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'dependency'		=> array('element' => 'apear_options', 'value'   => 'on-click'),

				'group'				=> esc_html__('Button Settings', 'dpr-adeline-extensions'),

	  		),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font. .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_google_fonts',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'dependency'		=> array('element' => 'apear_options', 'value'   => 'on-click'),

				'group'				=> esc_html__('Button Settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'title_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'dependency'		=> array('element' => 'use_google_fonts', 'value' => 'yes'),

			),



		),

	)

);