<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$unique_id = $css_animation = $el_class = $css = $output = $custom_el_css = $style = $layout = $button_size = $rounded_style = $alignment = $force_full_width = '';
$use_block_title = $block_title = $facebook_link = $twitter_link = $google_link = $pinterest_link = $linkedin_link = $title_html = ''; 
$icon_size =  $button_padding = $button_gapping = $button_border_color = $button_border_radius = $icon_idle_color = $text_idle_color = $use_hover_anim = $use_hover_shadow = $button_hover_shadow = '';
$title_color = $title_font_size = $title_line_height  = $title_letter_spacing = $title_font_style = $use_title_google_font = $title_typo_style = '';
$button_font_size = $button_line_height  = $button_letter_spacing = $button_font_style = $use_button_google_font = $button_typo_style = '';

$site_url = get_page_link();
$data_media = adeline_no_image_url();
$atts = vc_map_get_attributes( 'dpr_share', $atts );
extract( $atts );

$el_class = $this->getExtraClass( $el_class );
if ( '' !== $css_animation && 'none' !== $css_animation ) {
	dpr_enqueue_waypoint_js();
	dpr_enqueue_animate_css();
	$el_class .= ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
}
$unique_id = uniqid('dpr-share-').'-'.rand(1,9999);

if(isset($layout) && $layout !='') {
	$el_class .= ' '.$layout;
}

if(isset($style) && $style !='') {
	$el_class .= ' '.$style;
}

if(isset($button_size) && $button_size !='') {
	$el_class .= ' '.$button_size;
}

if(isset($rounded_style) && $rounded_style !='') {
	$el_class .= ' '.$rounded_style;
}

if(isset($alignment) && $alignment !='') {
	$el_class .= ' '.$alignment;
}

if($force_full_width == 'yes') {
	$el_class .= ' force-full-width';
}

if($use_hover_anim == 'yes') {
	$el_class .= ' animate-on-hover';
}
if($use_hover_shadow == 'yes' && dpr_shadow_param_to_css($button_hover_shadow) != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' li:hover {'.dpr_shadow_param_to_css($button_hover_shadow).'}';
}


$css_classes = array(
	'dpr-share-block',
	$unique_id,
	$el_class,
	vc_shortcode_custom_css_class( $css ),
);

if (!empty($title)) {
	$title_typo_style = dpr_generate_typography_style('', $title_font_size, $title_line_height, $title_letter_spacing, $title_font_style,$use_title_google_font);
	$title_html .= '<div class="dpr-share-title" ' . $title_typo_style . '>' . esc_html($title) . '</div>';
}


$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->settings['base'], $atts ) );

if(isset($icon_size) && $icon_size !='') {
	$custom_el_css .= '.'.esc_js($unique_id).' .dpr-share-icon  {font-size:'.$icon_size.'px;}';
}
if(isset($icon_idle_color) && $icon_idle_color !='') {
	$custom_el_css .= '.'.esc_js($unique_id).' li:not(:hover) .dpr-share-icon  {color:'.$icon_idle_color.';}';
}
if(isset($button_border_color) && $button_border_color !='') {
	$custom_el_css .= '.'.esc_js($unique_id).' li:not(:hover)  {border-color:'.$button_border_color.' !important;}';
}

if(isset($button_border_radius) && $button_border_radius !='') {
	$custom_el_css .= '.'.esc_js($unique_id).' ul li  {border-radius:'.$button_border_radius.'px;}';
}

if(isset($button_padding) && $button_padding !='') {
	$custom_el_css .= '.'.esc_js($unique_id).' li {margin-right:'.$button_padding.'px}';
}

if(isset($button_gapping) && $button_gapping !='') {
	$custom_el_css .= '.'.esc_js($unique_id).' li {margin-bottom:'.$button_gapping.'px}';
}

if ($use_block_title == 'yes' && !empty($block_title)) {
	$title_typo_style = dpr_generate_typography_style($title_color, $title_font_size, $title_line_height, $title_letter_spacing, $title_font_style,$use_title_google_font);
	$title_html .= '<h4 class="dpr-share-title" ' . $title_typo_style . '>' . esc_html($block_title) . '</h4>';
}

$button_typo_style = dpr_generate_typography_style('', $button_font_size, $button_line_height, $button_letter_spacing, $button_font_style,$use_button_google_font);


$output .= '<div id="'.esc_attr($unique_id).'" class="'.esc_attr($css_class).'">';
$output .= $title_html;
$output .= '<ul>';
if($facebook_link == 'yes') {
$output .= '
<li class="facebook-share"><a href="https://www.facebook.com/sharer/sharer.php?u=' . $site_url.'" title="Share on Facebook" onclick="dprShare_onClick( this.href );return false;"><span class="dpr-share-icon dpr-icon-facebook"></span><span class="dpr-share-text" '.$button_typo_style.'>Facebook</span></a></li>
';
}
if($twitter_link == 'yes') {
$output .= '
<li class="twitter-share"><a href="https://twitter.com/intent/tweet?text=' . $site_url.'" title="Share on Twitter" onclick="dprShare_onClick( this.href );return false;"><span class="dpr-share-icon dpr-icon-twitter"></span><span class="dpr-share-text" '.$button_typo_style.'>Twitter</span></a></li>
';
}
if($google_link == 'yes') {
$output .= '
<li class="google-share"><a href="https://plus.google.com/share?url=' . $site_url.'" title="Share on Google+" onclick="dprShare_onClick( this.href );return false;"><span class="dpr-share-icon dpr-icon-google-plus"></span><span class="dpr-share-text" '.$button_typo_style.'>Google+</span></a></li>
';
}
if($pinterest_link == 'yes') {
$output .= '
<li class="pinterest-share"><a href="http://pinterest.com/pin/create/button/?url=' . $site_url.'&amp;media='. esc_url($data_media).'" title="Share on Pinterest" onclick="dprShare_onClick( this.href );return false;"><span class="dpr-share-icon dpr-icon-pinterest-p"></span><span class="dpr-share-text" '.$button_typo_style.'>Pinterest</span></a></li>
';
}
if($linkedin_link == 'yes') {
$output .= '
<li class="linkedin-share"><a href="http://www.linkedin.com/shareArticle?mini=true&amp;url=' . $site_url.'" title="Share on LinkedIn" onclick="dprShare_onClick( this.href );return false;"><span class="dpr-share-icon dpr-icon-linkedin-square"></span><span class="dpr-share-text" '.$button_typo_style.'>LinkedIn</span></a></li>
';
}
$output .= '</ul>';


if(!empty($custom_el_css)) {
		$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>");'
						. '})(jQuery);'
					. '</script>';
}
$output .= '</div>';


echo $output;