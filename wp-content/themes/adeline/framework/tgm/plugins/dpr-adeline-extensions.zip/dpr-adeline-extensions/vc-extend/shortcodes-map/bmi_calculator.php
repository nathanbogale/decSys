<?php

// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}

/*

* Add-on Name: BMI Calculator

*/



class WPBakeryShortCode_DPR_Bmi_Calculator extends WPBakeryShortCode {}



vc_map(

	array(

		'name'					=> esc_html__(' DP BMI Calculator', 'dpr-adeline-extensions'),

		'base'					=> 'dpr_bmi_calculator',

		'class'					=> 'dpr_bmi_calculator',

		'icon'					=> 'icon-dpr-bmi-calculator',

  		"category" =>array( esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions')),

		'description'			=> esc_html__('Display BMI Calculator', 'dpr-adeline-extensions'),

		'params'				=> array(

		

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Content', 'dpr-adeline-extensions' ),

				'param_name'       => 'content_title',

				'edit_field_class' => 'vc_column vc_col-sm-12',

			),

		

			array(

				"type" => "textfield",

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set calculator title.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Title', 'dpr-adeline-extensions'),

				"param_name" => "title",

				"value" =>  __( 'CALCULATE YOUR BMI', 'dpr-adeline-extensions' ),

				'admin_label'		=> true,

			),

			array(

				'type'				=> 'textarea_html',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set calculator description.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Description', 'dpr-adeline-extensions'),

				'param_name'		=> 'content',

				'value'				=> __('Lorem ipsum dolor sit amet, consectet ad elit sed diam nonummy nibh euismod tincidunt ut laoreet dolore magnaLorem ipsum dolor sit amet','dpr-adeline-extensions'),

				'admin_label'		=> true,

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select default calculation units (metric or imperial).', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Default Calculation Unit', 'dpr-adeline-extensions'),

				'param_name'		=> 'unit_type',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value'				=> 'metric',

				'options'				=> array(

					esc_html__('Metric', 'dpr-adeline-extensions')	=> 'metric',

					esc_html__('Imperial', 'dpr-adeline-extensions')	=> 'imperial'

				)

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allow users to change between Calculation Units?.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Allow Change Calculation Units?', 'dpr-adeline-extensions'),

				'param_name'		=> 'allow_unit_switch',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => 'no',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				)

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows to display BMI table.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Display BMI Values Table?', 'dpr-adeline-extensions'),

				'param_name'		=> 'display_table',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => 'yes',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				)

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select table position.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Table Position', 'dpr-adeline-extensions'),

				'param_name'		=> 'table_position',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value'				=> 'left',

				'options'				=> array(

					esc_html__('Left', 'dpr-adeline-extensions')	=> 'left',

					esc_html__('Right', 'dpr-adeline-extensions')	=> 'right'

				),

				'dependency'		=> array('element' => 'display_table', 'value' => 'yes'),

			),

			array(

				"type" => "textfield",

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set button title.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Button Title', 'dpr-adeline-extensions'),

				"param_name" => "button_title",

				"value" =>  __( 'CALCULATE', 'dpr-adeline-extensions' ),

			),

			array(

				"type" => "textfield",

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set BMI table title.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('BMI Table Title', 'dpr-adeline-extensions'),

				"param_name" => "table_title",

				"value" =>  __( 'BMI CALCULATOR CHART', 'dpr-adeline-extensions' ),

				'dependency'		=> array('element' => 'display_table', 'value' => 'yes'),

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Additional Settings', 'dpr-adeline-extensions' ),

				'param_name'       => 'extra_features_title',

				'edit_field_class' => 'vc_column vc_col-sm-12',

			),

		   vc_map_add_css_animation( false ),

		    array(

				'type' => 'textfield',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Extra Class Name', 'dpr-adeline-extensions'),

				'param_name' => 'el_class',

			),



			/*

			* Style

			*/

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Calculator Fields Style', 'dpr-adeline-extensions'),

				'param_name'		=> 'style_title_1',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose color for input texts', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Input Text Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'input_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions')

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose color for placeholders', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Placeholder Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'placeholder_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions')

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose border color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Fields Border Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'border_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions')

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose border color on focus', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Fields Border Color: Focus', 'dpr-adeline-extensions'),

				'param_name'		=> 'border_color_focus',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions')

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose field background color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Fields Background Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'bg_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions')

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose firld background color on focus', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Fields Background Color: Focus', 'dpr-adeline-extensions'),

				'param_name'		=> 'bg_color_focus',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions')

			),

			array(

				'type' 				=> 'number',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select border radius inputs', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Fields border radius', 'dpr-adeline-extensions'),

				'param_name'		=> 'field_border_radius',

				'suffix'			=> 'px',

				'value' 			=> '',

				'edit_field_class' 	=> 'vc_column vc_col-sm-6',

				'group'			   	=> esc_html('Style','dpr-adeline-extensions')

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose color for radio buttons', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Radio Buttons Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'radio_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions')

			),



			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Button Style', 'dpr-adeline-extensions' ),

				'param_name'       => 'style_title_2',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose button style.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Button style', 'dpr-adeline-extensions'),

				'param_name'		=> 'button_style',

				'value'				=> 'flat',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'options'			=> array(

					esc_html__('Flat', 'dpr-adeline-extensions')		=> 'flat',

					esc_html__('Outlined Button', 'dpr-adeline-extensions') => 'btn-outlined',

					esc_html__('Minimal', 'dpr-adeline-extensions')			=> 'btn-min'

				),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom button size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Button size', 'dpr-adeline-extensions'),

				'param_name'		=> 'button_size',

				'value'				=> '',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'options'			=> array(

					esc_html__('Default', 'dpr-adeline-extensions')		=> '',

					esc_html__('Large', 'dpr-adeline-extensions') => 'btn-lg',

					esc_html__('Extra Large', 'dpr-adeline-extensions')	=> 'btn-xl',

					esc_html__('Small', 'dpr-adeline-extensions')	=> 'btn-sm',

				),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),			

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose button shape.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Button shape', 'dpr-adeline-extensions'),

				'param_name'		=> 'button_shape',

				'value'				=> '',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'options'			=> array(

					esc_html__('Default', 'dpr-adeline-extensions')		=> '',

					esc_html__('Rounded', 'dpr-adeline-extensions') => 'btn-round',

					esc_html__('Circle', 'dpr-adeline-extensions')	=> 'btn-circle',

					esc_html__('Square', 'dpr-adeline-extensions')	=> 'btn-square',

				),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),			

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to choose the horizontal alignment for the button.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Button Alignment', 'dpr-adeline-extensions'),

				'param_name'		=> 'button_alignment',

				'value'				=> '',

				'options'			=> array(

					esc_html__('Left', 'dpr-adeline-extensions')	=> '',

					esc_html__('Center', 'dpr-adeline-extensions')	=> 'text-center',

					esc_html__('Right', 'dpr-adeline-extensions')	=> 'text-right'

				),

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom button border radius. If you leave this field blank will be used default value.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border Radius', 'dpr-adeline-extensions'),

				'param_name'		=> 'button_border_radius',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom button border width. If you leave this field blank will be used default value.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border Width', 'dpr-adeline-extensions'),

				'param_name'		=> 'button_border_width',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('This option allows you to make button full width of parent container.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Force full width button?', 'dpr-adeline-extensions'),

				'param_name'		=> 'full_width',

				'value' => 'no',

				'options'			=> array(

						esc_attr__('No', 'dpr-adeline-extensions')	=> 'no',

						esc_attr__('Yes', 'dpr-adeline-extensions')	=> 'yes',

				),

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

			'type'            	=> 'dpr_title',

			'class'			  	=> 'small',

			'text'            	=> esc_html__( 'Button Custom Colors', 'dpr-adeline-extensions' ),

			'param_name'       	=> 'style_title_4',

			'edit_field_class' 	=> 'vc_column vc_col-sm-12',

			'group'	=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom button text color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'button_color',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),			

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom button text color hover', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'button_color_hover',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),			

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom button background color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background', 'dpr-adeline-extensions'),

				'param_name'		=> 'button_bg_color',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),			

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom button background color hover', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'button_bg_color_hover',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),			

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom button border color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border', 'dpr-adeline-extensions'),

				'param_name'		=> 'button_border_color',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),			

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom button border color hover', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'button_border_color_hover',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),			

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Result Style', 'dpr-adeline-extensions' ),

				'param_name'       => 'style_title_3',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose color for result backgroundt', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Result Background Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'result_bg',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions')

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose color for result text', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Result Text Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'result_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions')

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose color for result icon', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Result Icon Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'result_icon_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions')

			),





			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('BMI Table Style', 'dpr-adeline-extensions'),

				'param_name'		=> 'style_title_4',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose header color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Table Header Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'th_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions')

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose header background color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Table Header Background Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'th_bg',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions')

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose table color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Table Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'td_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions')

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose table bacground color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Table Background Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'td_bg',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions')

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose table color odd', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Table Color: Odd', 'dpr-adeline-extensions'),

				'param_name'		=> 'td_color_odd',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions')

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose table background color odd', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Table Background Color: Odd', 'dpr-adeline-extensions'),

				'param_name'		=> 'td_bg_odd',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions')

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose table border color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Table Border Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'table_border_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions')

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom table border width.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border Width', 'dpr-adeline-extensions'),

				'param_name'		=> 'table_border_width',

				'min'				=> 0,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set table border radius.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Table Border Radius', 'dpr-adeline-extensions'),

				'param_name'		=> 'table_border_radius',

				'min'				=> 0,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),



			/*

			* Typography

			*/

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Title Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_typography_head',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'title', 'not_empty' => true),

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose title color. The default color is #292933', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Title Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-3  ',

				'dependency'		=> array('element' => 'title', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size. If you leave this field blank will be used default size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'title', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title linne height.Default is 18px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'title', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'title', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'title_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'dependency'		=> array('element' => 'title', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

	  		),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font. .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_use_google_fonts',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'dependency'		=> array('element' => 'title', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'title_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'dependency'		=> array('element' => 'title_use_google_fonts', 'value' => 'yes'),

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),



			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Description Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'description_typography_head',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose description color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Description Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'description_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-3  ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size. If you leave this field blank will be used default size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'description_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title linne height.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'description_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'description_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'description_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

	  		),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font. .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'description_use_google_fonts',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'description_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'description_use_google_fonts', 'value' => 'yes'),

			),

			



			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('BMI Chart Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'table_typography_head',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose table color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Table Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'table_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-3  ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size. If you leave this field blank will be used default size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'table_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title linne height.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'table_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'table_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'table_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

	  		),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font. .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'table_use_google_fonts',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'table_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'table_use_google_fonts', 'value' => 'yes'),

			),







			

			array(

				'type' => 'css_editor',

				'heading' => __( 'CSS box', 'dpr-adeline-extensions' ),

				'param_name' => 'css',

				'group' => __( 'Design Options', 'dpr-adeline-extensions' ),

			),











		)

	)

);