<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$output = $unique_id = $type = $css_animation = $el_class = $custom_el_css = '';
$tag = $headline = $subtitle = $alignment = $headline_top_margin = $headline_bottom_margin = $subtitle_top_margin = $subtitle_bottom_margin = '';
$use_separator = $separator_type = $line_style = $line_width = $line_height = $line_width_hover = $line_height_hover = $line_color_hover = $separator_image = $separator_top_margin = $separator_bottom_margin = $separator_image_width = $separator_image_height = '';
$headline_color = $headline_font_size = $headline_line_height  = $headline_letter_spacing = $headline_font_style = $headline_google_font = $headline_typo_style = '';
$subtitle_color = $subtitle_font_size = $subtitle_line_height  = $subtitle_letter_spacing = $subtitle_font_style = $subtitle_google_font = $subtitle_typo_style = '';
$use_hedline_responsive_typo = $headline_reaponsive_typography = $use_subtitle_responsive_typo = $subtitle_reaponsive_typography = '';
$headline_html = $subtitle_html = $separator_html = '';

$atts = vc_map_get_attributes( 'dpr_heading', $atts );
extract( $atts );

$unique_id = uniqid('dpr-heading-').'-'.rand(1,9999);

$template_file = DPR_EXTENSIONS_PLUGIN_PATH.'vc-extend/vc-templates/dpr-headings/' . $type . '.php';

if ( '' !== $css_animation && 'none' !== $css_animation ) {
	dpr_enqueue_waypoint_js();
	dpr_enqueue_animate_css();
	$el_class .= ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
}

$el_class .= ' '.$unique_id.' '.$type;

// Alignment class

if (!empty($alignment)) {
	$el_class .= ' '.$alignment;
}

// Headline HTML
if (!empty($content)) {
	if ($tag == '') $tag = 'h3';
	$headline_typo_style = dpr_generate_typography_style($headline_color, $headline_font_size, $headline_line_height, $headline_letter_spacing, $headline_font_style,$headline_google_font);
	$headline_html .= '<'.$tag.' class="dpr-headline" ' . $headline_typo_style . '>' . wpb_js_remove_wpautop($content) . '</'.$tag.'>';
}

// Subtitle HTML
if (!empty($subtitle)) {
	$subtitle_typo_style = dpr_generate_typography_style($subtitle_color, $subtitle_font_size, $subtitle_line_height, $subtitle_letter_spacing, $subtitle_font_style,$subtitle_google_font);
	$subtitle_html .= '<div class="dpr-heading-subtitle" ' . $subtitle_typo_style . '>' . wpb_js_remove_wpautop($subtitle) . '</div>';
}


// Separator HTML.
if ( $use_separator == 'yes' && isset($separator_type) ) {
	
	$separator_html .= '<div class="dpr-heading-separator">';
	switch ($separator_type) {
    case 'line':
		$separator_html .= '<div class ="heading-line"></div>';
		break;
    case 'image':
		$separator_img_src = dpr_get_attachment_image_src($separator_image, 'full');
		if($separator_img_src[0] !='') {
		$separator_img_style = '';
		if($separator_image_width != '') {
		$separator_img_style .= ' width:'.$separator_image_width.'px;';	
		}
		if($separator_image_height != '') {
		$separator_img_style .= ' height:'.$separator_image_height.'px;';	
		}
		if ($separator_img_style !='') {
		$separator_img_style = ' style="'.$separator_img_style.'"';
		}
		$alt_text = get_post_meta($separator_image , '_wp_attachment_image_alt', true);
		$separator_html .= '<div class="heding-image"><img src="'.$separator_img_src[0].'"'.$separator_img_style.' alt ="'.esc_attr($alt_text).'"/></div>';
		}
        break;
	}
	$separator_html .= '</div>';
}




// Custom CSS stuff
//Extra paddings for subtitle
if($use_separator == 'yes' && ($type == 'type-07' || $type == 'type-08' || $type == 'type-09')) {
	$add_subtitle_padding = '';
	switch ($type) {
	case "type-07":
		if ($separator_type == 'line') {
		$add_subtitle_padding = "padding-left:45px;";
			if($line_width != '') {
			$add_subtitle_padding = 'padding-left:'.($line_width +10).'px;';
			}
		}
		if ($separator_type == 'image') {
		$add_subtitle_padding = 'padding-left:45px;';
			if($separator_image_width != '') {
			$add_subtitle_padding = 'padding-leftt:'.($separator_image_width +10).'px;';
			}
		}
		break;
	case "type-09":
		if ($separator_type == 'line') {
		$add_subtitle_padding = 'padding-right:45px;';
			if($line_width != '') {
			$add_subtitle_padding = 'padding-right:'.($line_width +10).'px;';
			}
		}
		if ($separator_type == 'image') {
		$add_subtitle_padding = 'padding-right:45px;';
			if($separator_image_width != '') {
			$add_subtitle_padding = 'padding-right:'.($separator_image_width +10).'px;';
			}
		}
		break;
	case "type-08":
		if ($separator_type == 'line') {
		$add_subtitle_padding = 'padding-left:45px;padding-right:45px;';
			if($line_width != '') {
			$add_subtitle_padding = 'padding-left:'.($line_width +10).'px; padding-right:'.($line_width +10).'px;';
			}
		}
		if ($separator_type == 'image') {
		$add_subtitle_padding = 'padding-left:45px;padding-right:45px;';
			if($separator_image_width != '') {
			$add_subtitle_padding = 'padding-left:'.($separator_image_width +10).'px; padding-right:'.($separator_image_width +10).'px;';
			}
		}
		break;

	default:
		break;
	
}
$custom_el_css .= '.'. esc_attr($unique_id).' .dpr-heading-subtitle{'.$add_subtitle_padding.'}';
}

// Custom margins

if(isset($headline_top_margin) && !empty($headline_top_margin)) {
	$custom_el_css .= '.'.esc_js($unique_id) .' .dpr-headline{margin-top:'.$headline_top_margin.'px;}';
}
if(isset($headline_bottom_margin) && !empty($headline_bottom_margin)) {
	$custom_el_css .= '.'.esc_js($unique_id) .' .dpr-headline{margin-bottom:'.$headline_bottom_margin.'px;}';
}
if(isset($subtitle_top_margin) && !empty($subtitle_top_margin)) {
	$custom_el_css .= '.'.esc_js($unique_id) .' .dpr-heading-subtitle{margin-top:'.$subtitle_top_margin.'px;}';
}
if(isset($subtitle_bottom_margin) && !empty($subtitle_bottom_margin)) {
	$custom_el_css .= '.'.esc_js($unique_id) .' .dpr-heading-subtitle{margin-bottom:'.$subtitle_bottom_margin.'px;}';
}
if(isset($separator_top_margin) && !empty($separator_top_margin)) {
	$custom_el_css .= '.'.esc_js($unique_id) .' .dpr-heading-separator{margin-top:'.$separator_top_margin.'px;}';
}
if(isset($separator_bottom_margin) && !empty($separator_bottom_margin)) {
	$custom_el_css .= '.'.esc_js($unique_id) .' .dpr-heading-separator{margin-bottom:'.$separator_bottom_margin.'px;}';
}

//separator styling
if(isset($line_color) && !empty($line_color)) {
	$custom_el_css .= '.'.esc_js($unique_id) .' .dpr-heading-separator .heading-line{border-bottom-color:'.$line_color.';}';
}
if(isset($line_style) && !empty($line_style)) {
	$custom_el_css .= '.'.esc_js($unique_id) .' .dpr-heading-separator .heading-line{border-bottom-style:'.$line_style.';}';
}
if(isset($line_width) && !empty($line_width)) {
	$custom_el_css .= '.'.esc_js($unique_id) .' .dpr-heading-separator .heading-line {width:'.$line_width.'px;}';
}
if(isset($line_height) && !empty($line_height)) {
	$custom_el_css .= '.'.esc_js($unique_id) .' .dpr-heading-separator .heading-line{border-bottom-width:'.$line_height.'px;}';
}

if(isset($line_color_hover) && !empty($line_color_hover)) {
	$custom_el_css .= '.'.esc_js($unique_id) .':hover .dpr-heading-separator .heading-line{border-bottom-color:'.$line_color_hover.';}';
}
if(isset($line_width_hover) && !empty($line_width_hover)) {
	$custom_el_css .= '.'.esc_js($unique_id) .':hover .dpr-heading-separator .heading-line {width:'.$line_width_hover.'px;}';
}
if(isset($line_height_hover) && !empty($line_height_hover)) {
	$custom_el_css .= '.'.esc_js($unique_id) .':hover .dpr-heading-separator .heading-line{border-bottom-width:'.$line_height_hover.'px;}';
}

// Add responsive CSS

if($use_hedline_responsive_typo && isset($headline_reaponsive_typography) && $headline_reaponsive_typography != '') {
	$responsive_unique_class = '.'.esc_js($unique_id) .' .dpr-headline';
	$custom_el_css .= DPR_Resposive_Typography_Param::generate_css($headline_reaponsive_typography,$responsive_unique_class);
}
if($use_subtitle_responsive_typo && isset($subtitle_reaponsive_typography) && $subtitle_reaponsive_typography != '') {
	$responsive_unique_class = '.'.esc_js($unique_id) .' .dpr-heading-subtitle';
	$custom_el_css .= DPR_Resposive_Typography_Param::generate_css($subtitle_reaponsive_typography,$responsive_unique_class);
}

$output .= '<div id="' . esc_attr($unique_id) . '" class="dpr-heading-wrapper '.esc_attr($el_class).'">';
$output .= '<div class="dpr-heading-inner-wrapper">';
$output .= '<div class="dpr-heading">';
if(file_exists($template_file)) {
	include($template_file);
}

$output .= '</div>';
$output .= '</div>';

	if(!empty($custom_el_css)) {
		$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>");'
						. '})(jQuery);'
					. '</script>';
}


$output .= '</div>';

echo $output;