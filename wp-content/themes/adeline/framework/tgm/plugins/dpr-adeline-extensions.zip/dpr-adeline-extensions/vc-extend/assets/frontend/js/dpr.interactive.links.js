var $j = jQuery.noConflict();



$j( document ).on( 'ready', function() {

	"use strict";

	// Custom select

	dprInitializeInteractiveLinks();

} );



/* ==============================================

BEFORE AFTER

============================================== */

function dprInitializeInteractiveLinks() {

	"use strict";

	var interactiveLinks = $j('.dpr-ilinks-wrapper');
	
	if (interactiveLinks.length) {
		interactiveLinks.each(function(){
				var thisinteractiveLinks = $j(this),
				    singleImage = thisinteractiveLinks.find('.dpr-ilinks-item-image'),
				    singleLink  = thisinteractiveLinks.find('.dpr-ilinks-item-link'),
					imageOverlay = thisinteractiveLinks.find('.dpr-ilinks-image-overlay');
			    
					singleImage.eq(0).addClass('dpr-active');
					thisinteractiveLinks.find('.dpr-ilinks-item-link[data-index="0"]').addClass('dpr-active');
					
					if (thisinteractiveLinks.hasClass('reveal-effect')) {
						singleLink.children().on('touchstart mouseenter', function() {
							var thisLink = $j(this).parent(),
							index = parseInt( thisLink.data('index'), 10 );

							if (!thisLink.hasClass('dpr-active')){
								imageOverlay.addClass('dpr-animate');
								imageOverlay.one('webkitTransitionEnd otransitionend oTransitionEnd msTransitionEnd transitionend',   
								function() {
									imageOverlay.removeClass('dpr-animate');
									singleImage.removeClass('dpr-active').eq(index).addClass('dpr-active');
								});
							}					
							
							singleLink.removeClass('dpr-active');
							thisinteractiveLinks.find('.dpr-ilinks-item-link[data-index="'+index+'"]').addClass('dpr-active');

						});
					} else if (thisinteractiveLinks.hasClass('style-satelite-image')) {
						singleLink.children().on('touchstart mouseenter', function() {
							var thisLink = $j(this).parent(),
							index = parseInt( thisLink.data('index'), 10 );
							singleImage.removeClass('dpr-active').eq(index).addClass('dpr-active');
							singleLink.removeClass('dpr-active');
							thisinteractiveLinks.find('.dpr-ilinks-item-link[data-index="'+index+'"]').addClass('dpr-active');
							thisLink.mousefollow({
								html: '<div class="dpr-shadow-6">'+singleImage.eq(index).html()+'</div>',
								speed: 300,
								zIndex: 10000
							});
						});

					} else {
						singleLink.children().on('touchstart mouseenter', function() {
							var thisLink = $j(this).parent(),
							index = parseInt( thisLink.data('index'), 10 );
				
							singleImage.removeClass('dpr-active').eq(index).addClass('dpr-active');
							singleLink.removeClass('dpr-active');
							thisinteractiveLinks.find('.dpr-ilinks-item-link[data-index="'+index+'"]').addClass('dpr-active');

						});
							  
					}

					
			
		});
	}

}
