<?php $icons = array();
$icons['Default']['double_tick'] = array("class"=>'double_tick',"tags"=>'double-tick-indicator',"unicode"=>'');
$icons['Default']['bees'] = array("class"=>'bees',"tags"=>'bees,honey',"unicode"=>'');
$icons['Default']['health'] = array("class"=>'health',"tags"=>'heart,pulse,rate,health',"unicode"=>'');
$icons['Default']['heart_health'] = array("class"=>'heart_health',"tags"=>'heart,vitals,pulse,rate,health',"unicode"=>'');
$icons['Default']['basket_ball'] = array("class"=>'basket_ball',"tags"=>'basket,ball,sports',"unicode"=>'');
$icons['Default']['golf'] = array("class"=>'golf',"tags"=>'golf,course,sports',"unicode"=>'');
$icons['Default']['football'] = array("class"=>'football',"tags"=>'football,soccer,sports',"unicode"=>'');
$icons['Default']['eating'] = array("class"=>'eating',"tags"=>'eating,spoon,fork,knife',"unicode"=>'');
$icons['Default']['coffee_cup'] = array("class"=>'coffee_cup',"tags"=>'tea,coffee,hot',"unicode"=>'');
$icons['Default']['cocktail'] = array("class"=>'cocktail',"tags"=>'martini,cocktail,drink',"unicode"=>'');
$icons['Default']['vine2'] = array("class"=>'vine2',"tags"=>'vine,glass,drink',"unicode"=>'');
$icons['Default']['margarita'] = array("class"=>'margarita',"tags"=>'margarita,cocktail,drink',"unicode"=>'');
$icons['Default']['food'] = array("class"=>'food',"tags"=>'glass,fork,knife,restaurant,food',"unicode"=>'');
$icons['Default']['pizza'] = array("class"=>'pizza',"tags"=>'pizza,slice',"unicode"=>'');
$icons['Default']['cake'] = array("class"=>'cake',"tags"=>'cake,birthday,anniversary',"unicode"=>'');
$icons['Default']['cake2'] = array("class"=>'cake2',"tags"=>'cake,birthday,anniversary',"unicode"=>'');
$icons['Default']['ice_cream'] = array("class"=>'ice_cream',"tags"=>'ice,cream,stick',"unicode"=>'');
$icons['Default']['ice_cream2'] = array("class"=>'ice_cream2',"tags"=>'ice,cream,corn',"unicode"=>'');
$icons['Default']['cupcake'] = array("class"=>'cupcake',"tags"=>'cupcake,desert,sweets',"unicode"=>'');
$icons['Default']['croissant'] = array("class"=>'croissant',"tags"=>'french,croissant,breakfast,sweets',"unicode"=>'');
$icons['Default']['coffee_beans'] = array("class"=>'coffee_beans',"tags"=>'coffee,beans',"unicode"=>'');
$icons['Default']['shoes'] = array("class"=>'shoes',"tags"=>'foot,shoe,steps',"unicode"=>'');
$icons['Default']['animal_steps'] = array("class"=>'animal_steps',"tags"=>'animal,foot,steps',"unicode"=>'');
$icons['Default']['power'] = array("class"=>'power',"tags"=>'power,on,off',"unicode"=>'');
$icons['Default']['plug2'] = array("class"=>'plug2',"tags"=>'plug,power,electricity',"unicode"=>'');
$icons['Default']['fish'] = array("class"=>'fish',"tags"=>'fish,bowl,goldfish',"unicode"=>'');
$icons['Default']['family'] = array("class"=>'family',"tags"=>'family,relationship,father,mother,child',"unicode"=>'');
$icons['Default']['family2'] = array("class"=>'family2',"tags"=>'family,relationship,mother,child',"unicode"=>'');
$icons['Default']['couple'] = array("class"=>'couple',"tags"=>'relationship,couple,love,marriage',"unicode"=>'');
$icons['Default']['puzzle3'] = array("class"=>'puzzle3',"tags"=>'puzzle,module,part',"unicode"=>'');
$icons['Default']['masks'] = array("class"=>'masks',"tags"=>'masks,theater,play',"unicode"=>'');
$icons['Default']['guitar'] = array("class"=>'guitar',"tags"=>'guitar,playing,music,band',"unicode"=>'');
$icons['Default']['sunglasses'] = array("class"=>'sunglasses',"tags"=>'sunglasses',"unicode"=>'');
$icons['Default']['nuclear'] = array("class"=>'nuclear',"tags"=>'atom,nuclear,learning,physics',"unicode"=>'');
$icons['Default']['root'] = array("class"=>'root',"tags"=>'mathematics,root,equation',"unicode"=>'');
$icons['Default']['curve'] = array("class"=>'curve',"tags"=>'mathematics,curve,coordinate,system',"unicode"=>'');
$icons['Default']['planet'] = array("class"=>'planet',"tags"=>'space,moon,planet,galaxy,saturn',"unicode"=>'');
$icons['Default']['bluetooth2'] = array("class"=>'bluetooth2',"tags"=>'bluetooth',"unicode"=>'');
$icons['Default']['wireless2'] = array("class"=>'wireless2',"tags"=>'connection,wireless',"unicode"=>'');
$icons['Default']['world'] = array("class"=>'world',"tags"=>'connection,world,internet,worldwide',"unicode"=>'');
$icons['Default']['world2'] = array("class"=>'world2',"tags"=>'connection,world,internet,worldwide',"unicode"=>'');
$icons['Default']['graph1'] = array("class"=>'graph1',"tags"=>'screen,analytics,line,graph',"unicode"=>'');
$icons['Default']['graph2'] = array("class"=>'graph2',"tags"=>'analytics,presentation,statistics,graph',"unicode"=>'');
$icons['Default']['suitcase2'] = array("class"=>'suitcase2',"tags"=>'business,suitcase',"unicode"=>'');
$icons['Default']['graph3'] = array("class"=>'graph3',"tags"=>'graph,columns,statistics',"unicode"=>'');
$icons['Default']['graph4'] = array("class"=>'graph4',"tags"=>'graph,columns,growth,statistics',"unicode"=>'');
$icons['Default']['graph5'] = array("class"=>'graph5',"tags"=>'graph,columns,drop,statistics',"unicode"=>'');
$icons['Default']['graph6'] = array("class"=>'graph6',"tags"=>'graph,pie,chart,statistics',"unicode"=>'');
$icons['Default']['hammer'] = array("class"=>'hammer',"tags"=>'gavel,hammer,law,judge,court',"unicode"=>'');
$icons['Default']['scale'] = array("class"=>'scale',"tags"=>'scale,justice,law,attorney',"unicode"=>'');
$icons['Default']['scale2'] = array("class"=>'scale2',"tags"=>'scale,justice,law,attorney',"unicode"=>'');
$icons['Default']['handshake'] = array("class"=>'handshake',"tags"=>'business,handshake,deal,contract,sign',"unicode"=>'');
$icons['Default']['graph7'] = array("class"=>'graph7',"tags"=>'analytics,graph,line,statistics',"unicode"=>'');
$icons['Default']['graph8'] = array("class"=>'graph8',"tags"=>'analytics,graph,line,statistics,stock',"unicode"=>'');
$icons['Default']['graph9'] = array("class"=>'graph9',"tags"=>'graph,growth,money,stock,inflation',"unicode"=>'');
$icons['Default']['stock'] = array("class"=>'stock',"tags"=>'stock,money,growth,inflation',"unicode"=>'');
$icons['Default']['dollar2'] = array("class"=>'dollar2',"tags"=>'money,usa,dollar',"unicode"=>'');
$icons['Default']['euro2'] = array("class"=>'euro2',"tags"=>'money,europe,euro',"unicode"=>'');
$icons['Default']['dollar22'] = array("class"=>'dollar22',"tags"=>'money,bag,dollar',"unicode"=>'');
$icons['Default']['money2'] = array("class"=>'money2',"tags"=>'money,dollar,euro,currency,exchange,cash',"unicode"=>'');
$icons['Default']['credit'] = array("class"=>'credit',"tags"=>'credit,card',"unicode"=>'');
$icons['Default']['wallet'] = array("class"=>'wallet',"tags"=>'wallet,money,payment',"unicode"=>'');
$icons['Default']['wallet2'] = array("class"=>'wallet2',"tags"=>'wallet,credit,card,money,payment',"unicode"=>'');
$icons['Default']['invoice'] = array("class"=>'invoice',"tags"=>'invoice,dollar,bill,payment',"unicode"=>'');
$icons['Default']['free'] = array("class"=>'free',"tags"=>'free',"unicode"=>'');
$icons['Default']['coins'] = array("class"=>'coins',"tags"=>'money,coins,jettons,chips',"unicode"=>'');
$icons['Default']['coins2'] = array("class"=>'coins2',"tags"=>'money,cash,coins,payment',"unicode"=>'');
$icons['Default']['piggy'] = array("class"=>'piggy',"tags"=>'saving,sale,discount,piggy,bank,pig',"unicode"=>'');
$icons['Default']['calculator2'] = array("class"=>'calculator2',"tags"=>'calculator',"unicode"=>'');
$icons['Default']['cashless'] = array("class"=>'cashless',"tags"=>'payment,mobile,nfc,apple,pay,cashless',"unicode"=>'');
$icons['Default']['cash'] = array("class"=>'cash',"tags"=>'money,cash,coins,payment,dollars',"unicode"=>'');
$icons['Default']['credit2'] = array("class"=>'credit2',"tags"=>'money,credit,card,coins,payment',"unicode"=>'');
$icons['Default']['cash2'] = array("class"=>'cash2',"tags"=>'money,payment,dollar,cash',"unicode"=>'');
$icons['Default']['cash3'] = array("class"=>'cash3',"tags"=>'money,payment,dollars,coins,cash',"unicode"=>'');
$icons['Default']['coins3'] = array("class"=>'coins3',"tags"=>'money,payment,dollar,coins,chips',"unicode"=>'');
$icons['Default']['dollar3'] = array("class"=>'dollar3',"tags"=>'money,payment,dollar,bag,cash',"unicode"=>'');
$icons['Default']['euro22'] = array("class"=>'euro22',"tags"=>'money,payment,euro,bag,cash',"unicode"=>'');
$icons['Default']['cash4'] = array("class"=>'cash4',"tags"=>'money,payment,dollar,coins,cash',"unicode"=>'');
$icons['Default']['cash5'] = array("class"=>'cash5',"tags"=>'money,atm,machine,withdrawal,cash',"unicode"=>'');
$icons['Default']['credit3'] = array("class"=>'credit3',"tags"=>'atm,machine,withdrawal,credit,card',"unicode"=>'');
$icons['Default']['currency'] = array("class"=>'currency',"tags"=>'money,currency,exchange',"unicode"=>'');
$icons['Default']['bitcoin2'] = array("class"=>'bitcoin2',"tags"=>'bitcoin,money',"unicode"=>'');
$icons['Default']['bitcoin22'] = array("class"=>'bitcoin22',"tags"=>'bitcoin,wallet,payment',"unicode"=>'');
$icons['Default']['pound'] = array("class"=>'pound',"tags"=>'pound,britain,currency,money',"unicode"=>'');
$icons['Default']['pound2'] = array("class"=>'pound2',"tags"=>'pound,britain,currency,money',"unicode"=>'');
$icons['Default']['tag2'] = array("class"=>'tag2',"tags"=>'tag,price,sale',"unicode"=>'');
$icons['Default']['tag22'] = array("class"=>'tag22',"tags"=>'tag,price,sale,discount',"unicode"=>'');
$icons['Default']['cart'] = array("class"=>'cart',"tags"=>'shopping,cart,basket,store',"unicode"=>'');
$icons['Default']['cart2'] = array("class"=>'cart2',"tags"=>'shopping,cart,basket,store',"unicode"=>'');
$icons['Default']['cart3'] = array("class"=>'cart3',"tags"=>'full,shopping,cart,basket,store',"unicode"=>'');
$icons['Default']['basket'] = array("class"=>'basket',"tags"=>'shopping,cart,basket,store',"unicode"=>'');
$icons['Default']['basket2'] = array("class"=>'basket2',"tags"=>'shopping,cart,basket,store',"unicode"=>'');
$icons['Default']['discount'] = array("class"=>'discount',"tags"=>'price,discount,sale,coupon',"unicode"=>'');
$icons['Default']['gift2'] = array("class"=>'gift2',"tags"=>'gift,wrapping',"unicode"=>'');
$icons['Default']['box'] = array("class"=>'box',"tags"=>'shipping,box,delivery',"unicode"=>'');
$icons['Default']['box4'] = array("class"=>'box4',"tags"=>'archive,shipping,box,delivery',"unicode"=>'');
$icons['Default']['van'] = array("class"=>'van',"tags"=>'delivery,van,shipping',"unicode"=>'');
$icons['Default']['open'] = array("class"=>'open',"tags"=>'store,shop,open',"unicode"=>'');
$icons['Default']['closed'] = array("class"=>'closed',"tags"=>'store,shop,closed',"unicode"=>'');
$icons['Default']['nonstop'] = array("class"=>'nonstop',"tags"=>'store,shop,open,nonstop',"unicode"=>'');
$icons['Default']['new'] = array("class"=>'new',"tags"=>'new',"unicode"=>'');
$icons['Default']['van2'] = array("class"=>'van2',"tags"=>'fast,delivery,van,shipping,transport',"unicode"=>'');
$icons['Default']['box3'] = array("class"=>'box3',"tags"=>'shipping,box,delivery',"unicode"=>'');
$icons['Default']['car2'] = array("class"=>'car2',"tags"=>'car,transport,vehicle',"unicode"=>'');
$icons['Default']['ship2'] = array("class"=>'ship2',"tags"=>'ship,naval,sea,marine,transport',"unicode"=>'');
$icons['Default']['anchor2'] = array("class"=>'anchor2',"tags"=>'anchor,ship,sea,naval',"unicode"=>'');
$icons['Default']['bike'] = array("class"=>'bike',"tags"=>'bike,bycicle,transport',"unicode"=>'');
$icons['Default']['wheel'] = array("class"=>'wheel',"tags"=>'steering,wheel,car,navigation,driving',"unicode"=>'');
$icons['Default']['plane2'] = array("class"=>'plane2',"tags"=>'plane,air',"unicode"=>'');
$icons['Default']['van3'] = array("class"=>'van3',"tags"=>'van,truck,transport,vehicle',"unicode"=>'');
$icons['Default']['sign'] = array("class"=>'sign',"tags"=>'car,turn,sign,right,left',"unicode"=>'');
$icons['Default']['suitcase22'] = array("class"=>'suitcase22',"tags"=>'suitcase,travel,baggage,luggage',"unicode"=>'');
$icons['Default']['suitcase3'] = array("class"=>'suitcase3',"tags"=>'suitcase,travel,baggage,luggage',"unicode"=>'');
$icons['Default']['globus'] = array("class"=>'globus',"tags"=>'globus,world,travel,regional',"unicode"=>'');
$icons['Default']['paris'] = array("class"=>'paris',"tags"=>'paris,city,travel,honeymoon,love,romantic',"unicode"=>'');
$icons['Default']['pyramid'] = array("class"=>'pyramid',"tags"=>'ancient,egypt,pyramid',"unicode"=>'');
$icons['Default']['pin'] = array("class"=>'pin',"tags"=>'navigation,location,drop,pin,map',"unicode"=>'');
$icons['Default']['pin2'] = array("class"=>'pin2',"tags"=>'navigation,location,drop,pin,map',"unicode"=>'');
$icons['Default']['compass2'] = array("class"=>'compass2',"tags"=>'navigation,compass,orientation',"unicode"=>'');
$icons['Default']['location'] = array("class"=>'location',"tags"=>'map,path,navigation,location',"unicode"=>'');
$icons['Default']['earth2'] = array("class"=>'earth2',"tags"=>'world,earth,worldwide,location,travel',"unicode"=>'');
$icons['Default']['earth'] = array("class"=>'earth',"tags"=>'world,earth,worldwide,international,language',"unicode"=>'');
$icons['Default']['distance'] = array("class"=>'distance',"tags"=>'map,travel,distance,directions',"unicode"=>'');
$icons['Default']['location2'] = array("class"=>'location2',"tags"=>'map,travel,destination,location,world',"unicode"=>'');
$icons['Default']['question2'] = array("class"=>'question2',"tags"=>'about,question,faq,help',"unicode"=>'');
$icons['Default']['restroom2'] = array("class"=>'restroom2',"tags"=>'men,women,toilet,wc,restroom',"unicode"=>'');
$icons['Default']['restroom'] = array("class"=>'restroom',"tags"=>'men,women,toilet,wc,restroom',"unicode"=>'');
$icons['Default']['down'] = array("class"=>'down',"tags"=>'down',"unicode"=>'');
$icons['Default']['up'] = array("class"=>'up',"tags"=>'up',"unicode"=>'');
$icons['Default']['camera2'] = array("class"=>'camera2',"tags"=>'hd,movie,video,camera,recording',"unicode"=>'');
$icons['Default']['camera22'] = array("class"=>'camera22',"tags"=>'movie,video,camera,recording',"unicode"=>'');
$icons['Default']['video'] = array("class"=>'video',"tags"=>'movie,video,cinema,flm',"unicode"=>'');
$icons['Default']['video2'] = array("class"=>'video2',"tags"=>'play,movie,video,cinema,flm',"unicode"=>'');
$icons['Default']['movie'] = array("class"=>'movie',"tags"=>'movie,recording,play,director,cut',"unicode"=>'');
$icons['Default']['video3'] = array("class"=>'video3',"tags"=>'presentation,video,play,beamer',"unicode"=>'');
$icons['Default']['tv2'] = array("class"=>'tv2',"tags"=>'tv,televison,movie,news',"unicode"=>'');
$icons['Default']['video4'] = array("class"=>'video4',"tags"=>'video,play,youtube',"unicode"=>'');
$icons['Default']['music2'] = array("class"=>'music2',"tags"=>'music,note,playing,sound,song',"unicode"=>'');
$icons['Default']['music22'] = array("class"=>'music22',"tags"=>'music,note,playing,sound,song',"unicode"=>'');
$icons['Default']['playlist'] = array("class"=>'playlist',"tags"=>'playlist,music,note,playing,sound,song',"unicode"=>'');
$icons['Default']['ipod'] = array("class"=>'ipod',"tags"=>'music,ipod,playing,player,playlist',"unicode"=>'');
$icons['Default']['album'] = array("class"=>'album',"tags"=>'music,playing,song,album',"unicode"=>'');
$icons['Default']['cloud2'] = array("class"=>'cloud2',"tags"=>'music,cloud,song,streaming',"unicode"=>'');
$icons['Default']['casette'] = array("class"=>'casette',"tags"=>'casette,music,song,radio',"unicode"=>'');
$icons['Default']['dj'] = array("class"=>'dj',"tags"=>'dj,music,disc,disco',"unicode"=>'');
$icons['Default']['radio'] = array("class"=>'radio',"tags"=>'radio,song,listening',"unicode"=>'');
$icons['Default']['ringer'] = array("class"=>'ringer',"tags"=>'ringer,alarm,sound',"unicode"=>'');
$icons['Default']['mute'] = array("class"=>'mute',"tags"=>'ringer,alarm,sound,silent,mute',"unicode"=>'');
$icons['Default']['speaker4'] = array("class"=>'speaker4',"tags"=>'ringer,sound,speaker,laud',"unicode"=>'');
$icons['Default']['speaker2'] = array("class"=>'speaker2',"tags"=>'ringer,sound,speaker,laud',"unicode"=>'');
$icons['Default']['speaker'] = array("class"=>'speaker',"tags"=>'ringer,sound,speaker,laud',"unicode"=>'');
$icons['Default']['silent'] = array("class"=>'silent',"tags"=>'ringer,sound,speaker,mute,silent',"unicode"=>'');
$icons['Default']['microphone2'] = array("class"=>'microphone2',"tags"=>'microphone,mic,voice,recording',"unicode"=>'');
$icons['Default']['microphone3'] = array("class"=>'microphone3',"tags"=>'microphone,mic,voice,recording',"unicode"=>'');
$icons['Default']['voice'] = array("class"=>'voice',"tags"=>'voice,laud,announcement,news',"unicode"=>'');
$icons['Default']['speaker3'] = array("class"=>'speaker3',"tags"=>'speaker,music,sound,playing',"unicode"=>'');
$icons['Default']['silent2'] = array("class"=>'silent2',"tags"=>'ringer,silent,sleeping',"unicode"=>'');
$icons['Default']['headphones2'] = array("class"=>'headphones2',"tags"=>'headphones,headset,speaker,beats',"unicode"=>'');
$icons['Default']['picture'] = array("class"=>'picture',"tags"=>'picture,image,photo',"unicode"=>'');
$icons['Default']['album2'] = array("class"=>'album2',"tags"=>'album,picture,image,photo',"unicode"=>'');
$icons['Default']['album3'] = array("class"=>'album3',"tags"=>'album,picture,image,photo',"unicode"=>'');
$icons['Default']['picture2'] = array("class"=>'picture2',"tags"=>'picture,image,photo,desk',"unicode"=>'');
$icons['Default']['picture3'] = array("class"=>'picture3',"tags"=>'polaroid,picture,image,photo',"unicode"=>'');
$icons['Default']['photo2'] = array("class"=>'photo2',"tags"=>'wall,picture,image,photo',"unicode"=>'');
$icons['Default']['camera3'] = array("class"=>'camera3',"tags"=>'photo,camera',"unicode"=>'');
$icons['Default']['camera4'] = array("class"=>'camera4',"tags"=>'photo,camera',"unicode"=>'');
$icons['Default']['tripod'] = array("class"=>'tripod',"tags"=>'photo,camera,tripod,stand',"unicode"=>'');
$icons['Default']['lock2'] = array("class"=>'lock2',"tags"=>'security,lock',"unicode"=>'');
$icons['Default']['unlocked'] = array("class"=>'unlocked',"tags"=>'security,lock,unlocked',"unicode"=>'');
$icons['Default']['key2'] = array("class"=>'key2',"tags"=>'security,lock,key',"unicode"=>'');
$icons['Default']['shield2'] = array("class"=>'shield2',"tags"=>'anti,virus,protection,shield',"unicode"=>'');
$icons['Default']['fingerprint'] = array("class"=>'fingerprint',"tags"=>'fingerprint,scan,security,access',"unicode"=>'');
$icons['Default']['lock22'] = array("class"=>'lock22',"tags"=>'security,lock,protected',"unicode"=>'');
$icons['Default']['keypad'] = array("class"=>'keypad',"tags"=>'atm,passcode,keypad,password,access',"unicode"=>'');
$icons['Default']['keypad2'] = array("class"=>'keypad2',"tags"=>'secret,passcode,keypad,password,access',"unicode"=>'');
$icons['Default']['fingerprint2'] = array("class"=>'fingerprint2',"tags"=>'fingerprint,iphone,scan,access',"unicode"=>'');
$icons['Default']['star2'] = array("class"=>'star2',"tags"=>'star,favorite,rating',"unicode"=>'');
$icons['Default']['rating'] = array("class"=>'rating',"tags"=>'star,favorite,rating',"unicode"=>'');
$icons['Default']['like2'] = array("class"=>'like2',"tags"=>'like,heart,favorite,rating,love',"unicode"=>'');
$icons['Default']['rating2'] = array("class"=>'rating2',"tags"=>'like,heart,favorite,rating,love',"unicode"=>'');
$icons['Default']['medal'] = array("class"=>'medal',"tags"=>'medal,award,rating,prize,achievement',"unicode"=>'');
$icons['Default']['medal2'] = array("class"=>'medal2',"tags"=>'medal,award,rating,prize,achievement',"unicode"=>'');
$icons['Default']['cup'] = array("class"=>'cup',"tags"=>'cup,place,winner,award,prize,achievement',"unicode"=>'');
$icons['Default']['award'] = array("class"=>'award',"tags"=>'medal,first,place,winner,award,prize,achievement',"unicode"=>'');
$icons['Default']['like5'] = array("class"=>'like5',"tags"=>'like,thumb,up,vote',"unicode"=>'');
$icons['Default']['dislike'] = array("class"=>'dislike',"tags"=>'dislike,thumb,down,vote',"unicode"=>'');
$icons['Default']['like3'] = array("class"=>'like3',"tags"=>'like,thumb,up,vote',"unicode"=>'');
$icons['Default']['dislike2'] = array("class"=>'dislike2',"tags"=>'dislike,thumb,down,vote',"unicode"=>'');
$icons['Default']['vote'] = array("class"=>'vote',"tags"=>'vote,ticket,paper,voting',"unicode"=>'');
$icons['Default']['award2'] = array("class"=>'award2',"tags"=>'award,achievement,prize,medal',"unicode"=>'');
$icons['Default']['star22'] = array("class"=>'star22',"tags"=>'star,rating,favorite,point',"unicode"=>'');
$icons['Default']['diamond2'] = array("class"=>'diamond2',"tags"=>'diamond,prize,award,jewellery,ring',"unicode"=>'');
$icons['Default']['crop2'] = array("class"=>'crop2',"tags"=>'crop,image',"unicode"=>'');
$icons['Default']['ruller'] = array("class"=>'ruller',"tags"=>'ruller,dimension,length',"unicode"=>'');
$icons['Default']['scissors2'] = array("class"=>'scissors2',"tags"=>'cut,scissors',"unicode"=>'');
$icons['Default']['brush'] = array("class"=>'brush',"tags"=>'paint,brush,color',"unicode"=>'');
$icons['Default']['color'] = array("class"=>'color',"tags"=>'eyedropper,color',"unicode"=>'');
$icons['Default']['wheel2'] = array("class"=>'wheel2',"tags"=>'color,wheel,rgb',"unicode"=>'');
$icons['Default']['brush2'] = array("class"=>'brush2',"tags"=>'paint,brush',"unicode"=>'');
$icons['Default']['pencil2'] = array("class"=>'pencil2',"tags"=>'pencil,ruller,drawing',"unicode"=>'');
$icons['Default']['pencil22'] = array("class"=>'pencil22',"tags"=>'pencil',"unicode"=>'');
$icons['Default']['pen'] = array("class"=>'pen',"tags"=>'pen',"unicode"=>'');
$icons['Default']['brush3'] = array("class"=>'brush3',"tags"=>'paint,brush',"unicode"=>'');
$icons['Default']['text'] = array("class"=>'text',"tags"=>'marker,text',"unicode"=>'');
$icons['Default']['knife'] = array("class"=>'knife',"tags"=>'cut,knife',"unicode"=>'');
$icons['Default']['book2'] = array("class"=>'book2',"tags"=>'pantone,color,guide,samples,book',"unicode"=>'');
$icons['Default']['bucket'] = array("class"=>'bucket',"tags"=>'paint,bucket,color',"unicode"=>'');
$icons['Default']['bucket2'] = array("class"=>'bucket2',"tags"=>'paint,bucket,color',"unicode"=>'');
$icons['Default']['paint'] = array("class"=>'paint',"tags"=>'wall,paint,color',"unicode"=>'');
$icons['Default']['paper'] = array("class"=>'paper',"tags"=>'paper,layers',"unicode"=>'');
$icons['Default']['avatar'] = array("class"=>'avatar',"tags"=>'user,profile,avatar,man,male',"unicode"=>'');
$icons['Default']['avatar2'] = array("class"=>'avatar2',"tags"=>'user,profile,avatar,woman,female',"unicode"=>'');
$icons['Default']['avatar3'] = array("class"=>'avatar3',"tags"=>'user,profile,avatar,man,male',"unicode"=>'');
$icons['Default']['avatar4'] = array("class"=>'avatar4',"tags"=>'user,profile,avatar,woman,female',"unicode"=>'');
$icons['Default']['profile'] = array("class"=>'profile',"tags"=>'users,profile,group,two',"unicode"=>'');
$icons['Default']['profile2'] = array("class"=>'profile2',"tags"=>'users,profile,group,couple,man,woman',"unicode"=>'');
$icons['Default']['profile3'] = array("class"=>'profile3',"tags"=>'user,profile,security,password,permissions',"unicode"=>'');
$icons['Default']['profile4'] = array("class"=>'profile4',"tags"=>'user,profile,add,new',"unicode"=>'');
$icons['Default']['profile5'] = array("class"=>'profile5',"tags"=>'user,profile,remove,delete',"unicode"=>'');
$icons['Default']['user2'] = array("class"=>'user2',"tags"=>'user,profile',"unicode"=>'');
$icons['Default']['user22'] = array("class"=>'user22',"tags"=>'user,profile,add,new',"unicode"=>'');
$icons['Default']['user3'] = array("class"=>'user3',"tags"=>'user,profile,remove,delete',"unicode"=>'');
$icons['Default']['user4'] = array("class"=>'user4',"tags"=>'user,profile,successful,check,verified',"unicode"=>'');
$icons['Default']['group2'] = array("class"=>'group2',"tags"=>'group,users,circle',"unicode"=>'');
$icons['Default']['support2'] = array("class"=>'support2',"tags"=>'support,male,phone',"unicode"=>'');
$icons['Default']['support5'] = array("class"=>'support5',"tags"=>'support,female,phone',"unicode"=>'');
$icons['Default']['sun'] = array("class"=>'sun',"tags"=>'weather,sun,summer',"unicode"=>'');
$icons['Default']['cloud22'] = array("class"=>'cloud22',"tags"=>'weather,cloud',"unicode"=>'');
$icons['Default']['cloud3'] = array("class"=>'cloud3',"tags"=>'weather,rain,cloud',"unicode"=>'');
$icons['Default']['moon'] = array("class"=>'moon',"tags"=>'weather,moon,stars,night,sleep',"unicode"=>'');
$icons['Default']['drop'] = array("class"=>'drop',"tags"=>'weather,rain,water,drop',"unicode"=>'');
$icons['Default']['umbrella2'] = array("class"=>'umbrella2',"tags"=>'weather,rain,umbrella',"unicode"=>'');
$icons['Default']['winter'] = array("class"=>'winter',"tags"=>'weather,snow,flake,winter',"unicode"=>'');
$icons['Default']['mountains2'] = array("class"=>'mountains2',"tags"=>'mountains,nature',"unicode"=>'');
$icons['Default']['mountains'] = array("class"=>'mountains',"tags"=>'mountains,nature',"unicode"=>'');
$icons['Default']['luck'] = array("class"=>'luck',"tags"=>'horseshoe,luck',"unicode"=>'');
$icons['Default']['pencil3'] = array("class"=>'pencil3',"tags"=>'compose,write,pencil,new',"unicode"=>'');
$icons['Default']['pencil4'] = array("class"=>'pencil4',"tags"=>'write,pencil,new,edit',"unicode"=>'');
$icons['Default']['pencil5'] = array("class"=>'pencil5',"tags"=>'write,pencil,new,edit',"unicode"=>'');
$icons['Default']['ruler'] = array("class"=>'ruler',"tags"=>'pencil,ruler,drawing',"unicode"=>'');
$icons['Default']['book22'] = array("class"=>'book22',"tags"=>'book,writing,reading,read,manual',"unicode"=>'');
$icons['Default']['book3'] = array("class"=>'book3',"tags"=>'book,reading,read,bookmark',"unicode"=>'');
$icons['Default']['book4'] = array("class"=>'book4',"tags"=>'book,reading,read,manual',"unicode"=>'');
$icons['Default']['book5'] = array("class"=>'book5',"tags"=>'book,reading,read,manual',"unicode"=>'');
$icons['Default']['newspaper'] = array("class"=>'newspaper',"tags"=>'newspaper,reading,news',"unicode"=>'');
$icons['Default']['glasses'] = array("class"=>'glasses',"tags"=>'reading,glasses',"unicode"=>'');
$icons['Default']['book6'] = array("class"=>'book6',"tags"=>'bookmarks,reading,book',"unicode"=>'');
$icons['Default']['archive2'] = array("class"=>'archive2',"tags"=>'office,archive',"unicode"=>'');
$icons['Default']['iphone'] = array("class"=>'iphone',"tags"=>'mobile,iphone',"unicode"=>'');
$icons['Default']['calendar2'] = array("class"=>'calendar2',"tags"=>'calendar,month,day,planner',"unicode"=>'');
$icons['Default']['calendar22'] = array("class"=>'calendar22',"tags"=>'calendar,month,day,planner',"unicode"=>'');
$icons['Default']['calendar3'] = array("class"=>'calendar3',"tags"=>'calendar,month,day,planner,events',"unicode"=>'');
$icons['Default']['alarm'] = array("class"=>'alarm',"tags"=>'alarm,clock,ringer,time,morning',"unicode"=>'');
$icons['Default']['clock'] = array("class"=>'clock',"tags"=>'time,watch,clock',"unicode"=>'');
$icons['Default']['timer'] = array("class"=>'timer',"tags"=>'stopwatch,timer,running,time',"unicode"=>'');
$icons['Default']['clock2'] = array("class"=>'clock2',"tags"=>'time,watch,clock,wall',"unicode"=>'');
$icons['Default']['clock3'] = array("class"=>'clock3',"tags"=>'time,watch,clock,wall',"unicode"=>'');
$icons['Default']['watch'] = array("class"=>'watch',"tags"=>'wrist,watch,clock,time',"unicode"=>'');
$icons['Default']['pin3'] = array("class"=>'pin3',"tags"=>'pin,bookmark',"unicode"=>'');
$icons['Default']['flag2'] = array("class"=>'flag2',"tags"=>'flag',"unicode"=>'');
$icons['Default']['search2'] = array("class"=>'search2',"tags"=>'search,find,zoom',"unicode"=>'');
$icons['Default']['search22'] = array("class"=>'search22',"tags"=>'search,find,zoom',"unicode"=>'');
$icons['Default']['attachment2'] = array("class"=>'attachment2',"tags"=>'attachment',"unicode"=>'');
$icons['Default']['eye2'] = array("class"=>'eye2',"tags"=>'eye,visibility,show,visible',"unicode"=>'');
$icons['Default']['invisible'] = array("class"=>'invisible',"tags"=>'eye,visibility,hide,invisible',"unicode"=>'');
$icons['Default']['house'] = array("class"=>'house',"tags"=>'home,house',"unicode"=>'');
$icons['Default']['house2'] = array("class"=>'house2',"tags"=>'home,house',"unicode"=>'');
$icons['Default']['gear2'] = array("class"=>'gear2',"tags"=>'settings,gear,preferences',"unicode"=>'');
$icons['Default']['gearbox'] = array("class"=>'gearbox',"tags"=>'settings,gears,preferences,gearbox',"unicode"=>'');
$icons['Default']['tools2'] = array("class"=>'tools2',"tags"=>'settings,tools,pipe',"unicode"=>'');
$icons['Default']['tools3'] = array("class"=>'tools3',"tags"=>'settings,tools,configuration,preferences',"unicode"=>'');
$icons['Default']['tools'] = array("class"=>'tools',"tags"=>'settings,tools,configuration,preferences',"unicode"=>'');
$icons['Default']['trash2'] = array("class"=>'trash2',"tags"=>'bin,trash,recycle,delete,garbage,empty',"unicode"=>'');
$icons['Default']['trash22'] = array("class"=>'trash22',"tags"=>'bin,trash,recycle,delete,garbage,full',"unicode"=>'');
$icons['Default']['trash3'] = array("class"=>'trash3',"tags"=>'bin,trash,recycle,delete,garbage',"unicode"=>'');
$icons['Default']['stop2'] = array("class"=>'stop2',"tags"=>'error,warning,danger,stop',"unicode"=>'');
$icons['Default']['exit'] = array("class"=>'exit',"tags"=>'error,warning,danger,stop,delete,exit',"unicode"=>'');
$icons['Default']['alert'] = array("class"=>'alert',"tags"=>'error,warning,alert,attention',"unicode"=>'');
$icons['Default']['error'] = array("class"=>'error',"tags"=>'unable,unavailable,error',"unicode"=>'');
$icons['Default']['text2'] = array("class"=>'text2',"tags"=>'text,line,view',"unicode"=>'');
$icons['Default']['list2'] = array("class"=>'list2',"tags"=>'bullet,list,view',"unicode"=>'');
$icons['Default']['list22'] = array("class"=>'list22',"tags"=>'bullet,list,view',"unicode"=>'');
$icons['Default']['grid'] = array("class"=>'grid',"tags"=>'grid,view',"unicode"=>'');
$icons['Default']['line'] = array("class"=>'line',"tags"=>'line,thumb,view',"unicode"=>'');
$icons['Default']['text3'] = array("class"=>'text3',"tags"=>'text,image,article,view',"unicode"=>'');
$icons['Default']['module'] = array("class"=>'module',"tags"=>'box,load,package,module',"unicode"=>'');
$icons['Default']['paper2'] = array("class"=>'paper2',"tags"=>'paper,role',"unicode"=>'');
$icons['Default']['paper3'] = array("class"=>'paper3',"tags"=>'document,file,paper',"unicode"=>'');
$icons['Default']['text4'] = array("class"=>'text4',"tags"=>'document,file,paper,text',"unicode"=>'');
$icons['Default']['copy2'] = array("class"=>'copy2',"tags"=>'documents,files,paper,text,archive,copy',"unicode"=>'');
$icons['Default']['delete'] = array("class"=>'delete',"tags"=>'document,file,delete,remove,error',"unicode"=>'');
$icons['Default']['template'] = array("class"=>'template',"tags"=>'document,file,paper,text,article,blog,template',"unicode"=>'');
$icons['Default']['zip'] = array("class"=>'zip',"tags"=>'document,file,zip,archive,compressed,rar',"unicode"=>'');
$icons['Default']['pdf'] = array("class"=>'pdf',"tags"=>'document,file,pdf,adobe,acrobat',"unicode"=>'');
$icons['Default']['doc'] = array("class"=>'doc',"tags"=>'document,file,word,office,doc,text',"unicode"=>'');
$icons['Default']['cloud4'] = array("class"=>'cloud4',"tags"=>'document,file,cloud,sync,backup',"unicode"=>'');
$icons['Default']['code2'] = array("class"=>'code2',"tags"=>'file,code,programming,dev,binary',"unicode"=>'');
$icons['Default']['player'] = array("class"=>'player',"tags"=>'video,movie,file,player',"unicode"=>'');
$icons['Default']['image2'] = array("class"=>'image2',"tags"=>'image,photo,file',"unicode"=>'');
$icons['Default']['text5'] = array("class"=>'text5',"tags"=>'font,file,ttf,otf,type,text',"unicode"=>'');
$icons['Default']['settings'] = array("class"=>'settings',"tags"=>'file,preferences,settings',"unicode"=>'');
$icons['Default']['zoom'] = array("class"=>'zoom',"tags"=>'file,search,find,replace,zoom,view',"unicode"=>'');
$icons['Default']['load'] = array("class"=>'load',"tags"=>'import,file,load',"unicode"=>'');
$icons['Default']['export'] = array("class"=>'export',"tags"=>'export,file',"unicode"=>'');
$icons['Default']['download2'] = array("class"=>'download2',"tags"=>'download,file',"unicode"=>'');
$icons['Default']['upload2'] = array("class"=>'upload2',"tags"=>'upload,file',"unicode"=>'');
$icons['Default']['cv'] = array("class"=>'cv',"tags"=>'cv,curriculum,vitae,job,life',"unicode"=>'');
$icons['Default']['profile6'] = array("class"=>'profile6',"tags"=>'file,profile,user,personal',"unicode"=>'');
$icons['Default']['profile7'] = array("class"=>'profile7',"tags"=>'file,profile,user,personal',"unicode"=>'');
$icons['Default']['text6'] = array("class"=>'text6',"tags"=>'file,text,long',"unicode"=>'');
$icons['Default']['text7'] = array("class"=>'text7',"tags"=>'file,document,legal,text',"unicode"=>'');
$icons['Default']['license'] = array("class"=>'license',"tags"=>'legal,document,law,license',"unicode"=>'');
$icons['Default']['list3'] = array("class"=>'list3',"tags"=>'to,do,list,reminder,done',"unicode"=>'');
$icons['Default']['box2'] = array("class"=>'box2',"tags"=>'box,clipboard',"unicode"=>'');
$icons['Default']['upload22'] = array("class"=>'upload22',"tags"=>'load,upload,clipboard,box',"unicode"=>'');
$icons['Default']['download6'] = array("class"=>'download6',"tags"=>'download,clipboard,box',"unicode"=>'');
$icons['Default']['zoom2'] = array("class"=>'zoom2',"tags"=>'zoom,in',"unicode"=>'');
$icons['Default']['zoom3'] = array("class"=>'zoom3',"tags"=>'zoom,out',"unicode"=>'');
$icons['Default']['search3'] = array("class"=>'search3',"tags"=>'search,find,files,folder',"unicode"=>'');
$icons['Default']['folder2'] = array("class"=>'folder2',"tags"=>'folder',"unicode"=>'');
$icons['Default']['folder22'] = array("class"=>'folder22',"tags"=>'folder,files,documents',"unicode"=>'');
$icons['Default']['folder3'] = array("class"=>'folder3',"tags"=>'folder,password,protected,secure,private',"unicode"=>'');
$icons['Default']['download5'] = array("class"=>'download5',"tags"=>'download,file',"unicode"=>'');
$icons['Default']['download3'] = array("class"=>'download3',"tags"=>'download,file,computer,drive',"unicode"=>'');
$icons['Default']['download4'] = array("class"=>'download4',"tags"=>'download,cloud,file,sync',"unicode"=>'');
$icons['Default']['upload3'] = array("class"=>'upload3',"tags"=>'upload,cloud,file,sync,backup',"unicode"=>'');
$icons['Default']['cloud5'] = array("class"=>'cloud5',"tags"=>'cloud,sync',"unicode"=>'');
$icons['Default']['upload4'] = array("class"=>'upload4',"tags"=>'cloud,upload,backup',"unicode"=>'');
$icons['Default']['cloud6'] = array("class"=>'cloud6',"tags"=>'cloud,sync,error',"unicode"=>'');
$icons['Default']['upload5'] = array("class"=>'upload5',"tags"=>'upload,load,share',"unicode"=>'');
$icons['Default']['download7'] = array("class"=>'download7',"tags"=>'download',"unicode"=>'');
$icons['Default']['rotate4'] = array("class"=>'rotate4',"tags"=>'arrow,rotate,left,counter,clockwise',"unicode"=>'');
$icons['Default']['rotate3'] = array("class"=>'rotate3',"tags"=>'arrow,rotate,right,clockwise',"unicode"=>'');
$icons['Default']['rotation'] = array("class"=>'rotation',"tags"=>'rotation,lock',"unicode"=>'');
$icons['Default']['expand2'] = array("class"=>'expand2',"tags"=>'zoom,expand,maximize,window',"unicode"=>'');
$icons['Default']['expand22'] = array("class"=>'expand22',"tags"=>'expand,move,window,full,screen',"unicode"=>'');
$icons['Default']['plus2'] = array("class"=>'plus2',"tags"=>'plus,add,new',"unicode"=>'');
$icons['Default']['minus2'] = array("class"=>'minus2',"tags"=>'minus,delete,remove',"unicode"=>'');
$icons['Default']['close2'] = array("class"=>'close2',"tags"=>'delete,exit,remove,close',"unicode"=>'');
$icons['Default']['check2'] = array("class"=>'check2',"tags"=>'ok,successful,check',"unicode"=>'');
$icons['Default']['close22'] = array("class"=>'close22',"tags"=>'delete,remove,exit,close,checkbox',"unicode"=>'');
$icons['Default']['checkbox'] = array("class"=>'checkbox',"tags"=>'checkbox,ok,successful',"unicode"=>'');
$icons['Default']['arrow'] = array("class"=>'arrow',"tags"=>'arrow,back,left',"unicode"=>'');
$icons['Default']['arrow2'] = array("class"=>'arrow2',"tags"=>'arrow,next,right',"unicode"=>'');
$icons['Default']['arrow3'] = array("class"=>'arrow3',"tags"=>'arrow,back,left',"unicode"=>'');
$icons['Default']['arrow4'] = array("class"=>'arrow4',"tags"=>'arrow,next,right',"unicode"=>'');
$icons['Default']['switch3'] = array("class"=>'switch3',"tags"=>'on,off,switch,toggle,settings,preferences',"unicode"=>'');
$icons['Default']['switch4'] = array("class"=>'switch4',"tags"=>'on,off,switch,toggle,settings,preferences',"unicode"=>'');
$icons['Default']['switch5'] = array("class"=>'switch5',"tags"=>'on,off,switch,toggle,settings,preferences',"unicode"=>'');
$icons['Default']['delete2'] = array("class"=>'delete2',"tags"=>'back,delete,backspace',"unicode"=>'');
$icons['Default']['plus3'] = array("class"=>'plus3',"tags"=>'plus,minus',"unicode"=>'');
$icons['Default']['check22'] = array("class"=>'check22',"tags"=>'check,ok,yes,no',"unicode"=>'');
$icons['Default']['target'] = array("class"=>'target',"tags"=>'target,circles',"unicode"=>'');
$icons['Default']['puzzle'] = array("class"=>'puzzle',"tags"=>'puzzle,modules,build',"unicode"=>'');
$icons['Default']['filter2'] = array("class"=>'filter2',"tags"=>'filter,funnel',"unicode"=>'');
$icons['Default']['plugin'] = array("class"=>'plugin',"tags"=>'module,connection,plugin',"unicode"=>'');
$icons['Default']['puzzle2'] = array("class"=>'puzzle2',"tags"=>'puzzle,module,connect',"unicode"=>'');
$icons['Default']['layers2'] = array("class"=>'layers2',"tags"=>'add,more,layers,slides',"unicode"=>'');
$icons['Default']['layers'] = array("class"=>'layers',"tags"=>'layers,slides',"unicode"=>'');
$icons['Default']['website'] = array("class"=>'website',"tags"=>'www,website,address,url,browser',"unicode"=>'');
$icons['Default']['select'] = array("class"=>'select',"tags"=>'dropdown,menu,select,option,form',"unicode"=>'');
$icons['Default']['screen'] = array("class"=>'screen',"tags"=>'screen,ok,success',"unicode"=>'');
$icons['Default']['screen2'] = array("class"=>'screen2',"tags"=>'screen,text',"unicode"=>'');
$icons['Default']['screen3'] = array("class"=>'screen3',"tags"=>'screen,text,images,presentation',"unicode"=>'');
$icons['Default']['screen4'] = array("class"=>'screen4',"tags"=>'screen,grid,images',"unicode"=>'');
$icons['Default']['text8'] = array("class"=>'text8',"tags"=>'window,text,images',"unicode"=>'');
$icons['Default']['graph'] = array("class"=>'graph',"tags"=>'window,graph,analytics',"unicode"=>'');
$icons['Default']['window'] = array("class"=>'window',"tags"=>'window,text,msg,box',"unicode"=>'');
$icons['Default']['alert2'] = array("class"=>'alert2',"tags"=>'window,alert,notification,warning,error',"unicode"=>'');
$icons['Default']['error2'] = array("class"=>'error2',"tags"=>'window,error,danger,stop',"unicode"=>'');
$icons['Default']['bullets'] = array("class"=>'bullets',"tags"=>'bullets,list,radiobuttons',"unicode"=>'');
$icons['Default']['bullets2'] = array("class"=>'bullets2',"tags"=>'bullets,list',"unicode"=>'');
$icons['Default']['checkbox2'] = array("class"=>'checkbox2',"tags"=>'list,checkbox,todo',"unicode"=>'');
$icons['Default']['checkbox3'] = array("class"=>'checkbox3',"tags"=>'list,checkbox,todo,done',"unicode"=>'');
$icons['Default']['grid2'] = array("class"=>'grid2',"tags"=>'grid,view',"unicode"=>'');
$icons['Default']['bullets3'] = array("class"=>'bullets3',"tags"=>'radiobuttons,bullets,lines',"unicode"=>'');
$icons['Default']['check3'] = array("class"=>'check3',"tags"=>'checkboxes,lines,check',"unicode"=>'');
$icons['Default']['hand'] = array("class"=>'hand',"tags"=>'hand,touch,one,finger',"unicode"=>'');
$icons['Default']['click'] = array("class"=>'click',"tags"=>'hand,touch,click,one,finger',"unicode"=>'');
$icons['Default']['click2'] = array("class"=>'click2',"tags"=>'hand,touch,click,press,one,finger',"unicode"=>'');
$icons['Default']['right'] = array("class"=>'right',"tags"=>'hand,finger,show,right',"unicode"=>'');
$icons['Default']['left'] = array("class"=>'left',"tags"=>'hand,finger,show,left',"unicode"=>'');
$icons['Default']['hand2'] = array("class"=>'hand2',"tags"=>'hand,fingers,grab,touch',"unicode"=>'');
$icons['Default']['link2'] = array("class"=>'link2',"tags"=>'link,url,chain,hyperlink',"unicode"=>'');
$icons['Default']['unlink2'] = array("class"=>'unlink2',"tags"=>'unlink,url,unchain,hyperlink',"unicode"=>'');
$icons['Default']['comment2'] = array("class"=>'comment2',"tags"=>'chat,message,comment,bubble',"unicode"=>'');
$icons['Default']['comment22'] = array("class"=>'comment22',"tags"=>'chat,message,comment,bubble,typing',"unicode"=>'');
$icons['Default']['reply2'] = array("class"=>'reply2',"tags"=>'chat,message,comment,bubble,reply,quote',"unicode"=>'');
$icons['Default']['message'] = array("class"=>'message',"tags"=>'chat,message,discussion,bubble,reply,conversation',"unicode"=>'');
$icons['Default']['chat4'] = array("class"=>'chat4',"tags"=>'chat,message,comment,bubble,cloud',"unicode"=>'');
$icons['Default']['message2'] = array("class"=>'message2',"tags"=>'chat,message,comment,bubble,cloud',"unicode"=>'');
$icons['Default']['like'] = array("class"=>'like',"tags"=>'message,text,like,favorite',"unicode"=>'');
$icons['Default']['quote'] = array("class"=>'quote',"tags"=>'chat,message,quote,reply',"unicode"=>'');
$icons['Default']['sms2'] = array("class"=>'sms2',"tags"=>'mobile,message,sms',"unicode"=>'');
$icons['Default']['sms'] = array("class"=>'sms',"tags"=>'mobile,message,sms',"unicode"=>'');
$icons['Default']['call4'] = array("class"=>'call4',"tags"=>'mobile,phone,call',"unicode"=>'');
$icons['Default']['call3'] = array("class"=>'call3',"tags"=>'mobile,phone,call,ringing,nfc',"unicode"=>'');
$icons['Default']['phone3'] = array("class"=>'phone3',"tags"=>'phone,telephone,contact',"unicode"=>'');
$icons['Default']['phone2'] = array("class"=>'phone2',"tags"=>'phone,mobile,contact',"unicode"=>'');
$icons['Default']['phone4'] = array("class"=>'phone4',"tags"=>'phone,contact',"unicode"=>'');
$icons['Default']['dialer'] = array("class"=>'dialer',"tags"=>'phone,call,number,dialer',"unicode"=>'');
$icons['Default']['call2'] = array("class"=>'call2',"tags"=>'phone,call,ringing',"unicode"=>'');
$icons['Default']['call'] = array("class"=>'call',"tags"=>'phone,hold,call',"unicode"=>'');
$icons['Default']['contact'] = array("class"=>'contact',"tags"=>'phone,call,contact',"unicode"=>'');
$icons['Default']['contacts'] = array("class"=>'contacts',"tags"=>'address,book,contacts',"unicode"=>'');
$icons['Default']['contacts3'] = array("class"=>'contacts3',"tags"=>'address,book,contacts',"unicode"=>'');
$icons['Default']['contacts4'] = array("class"=>'contacts4',"tags"=>'address,book,contacts',"unicode"=>'');
$icons['Default']['contacts2'] = array("class"=>'contacts2',"tags"=>'address,book,contacts',"unicode"=>'');
$icons['Default']['contacts5'] = array("class"=>'contacts5',"tags"=>'address,book,contacts',"unicode"=>'');
$icons['Default']['sim'] = array("class"=>'sim',"tags"=>'sim,card',"unicode"=>'');
$icons['Default']['badge'] = array("class"=>'badge',"tags"=>'notification,badge',"unicode"=>'');
$icons['Default']['chat3'] = array("class"=>'chat3',"tags"=>'chat,contact,support,help,conversation',"unicode"=>'');
$icons['Default']['bubble'] = array("class"=>'bubble',"tags"=>'chat,message,discussion,bubble,conversation',"unicode"=>'');
$icons['Default']['chat2'] = array("class"=>'chat2',"tags"=>'chat,message,discussion,bubble,conversation',"unicode"=>'');
$icons['Default']['chat'] = array("class"=>'chat',"tags"=>'chat,discussion,yes,no,pro,contra,conversation',"unicode"=>'');
$icons['Default']['help2'] = array("class"=>'help2',"tags"=>'support,help',"unicode"=>'');
$icons['Default']['help'] = array("class"=>'help',"tags"=>'support,help,talk,call',"unicode"=>'');
$icons['Default']['support3'] = array("class"=>'support3',"tags"=>'support,help,talk,call',"unicode"=>'');
$icons['Default']['stamp2'] = array("class"=>'stamp2',"tags"=>'stamp',"unicode"=>'');
$icons['Default']['stamp'] = array("class"=>'stamp',"tags"=>'post,stamp',"unicode"=>'');
$icons['Default']['email'] = array("class"=>'email',"tags"=>'email,at,sign',"unicode"=>'');
$icons['Default']['mail3'] = array("class"=>'mail3',"tags"=>'email,mail,post,card',"unicode"=>'');
$icons['Default']['mail2'] = array("class"=>'mail2',"tags"=>'email,mail,post,send',"unicode"=>'');
$icons['Default']['mail'] = array("class"=>'mail',"tags"=>'email,mail,post,open',"unicode"=>'');
$icons['Default']['plane3'] = array("class"=>'plane3',"tags"=>'thin-0317_send_post_paper_plane',"unicode"=>'');
$icons['Default']['attachment'] = array("class"=>'attachment',"tags"=>'email,attachment',"unicode"=>'');
$icons['Default']['mail4'] = array("class"=>'mail4',"tags"=>'email,mail,post,card',"unicode"=>'');
$icons['Default']['mail5'] = array("class"=>'mail5',"tags"=>'email,mail,post,card,sent,successful',"unicode"=>'');
$icons['Default']['mail6'] = array("class"=>'mail6',"tags"=>'email,mail,post,at',"unicode"=>'');
$icons['Default']['computer2'] = array("class"=>'computer2',"tags"=>'computer,screen',"unicode"=>'');
$icons['Default']['computer'] = array("class"=>'computer',"tags"=>'computer,screen,settings,preferences',"unicode"=>'');
$icons['Default']['computer3'] = array("class"=>'computer3',"tags"=>'computer,screen,locked,password,protected,security',"unicode"=>'');
$icons['Default']['download8'] = array("class"=>'download8',"tags"=>'computer,laptop,download',"unicode"=>'');
$icons['Default']['dvd'] = array("class"=>'dvd',"tags"=>'cd,dvd,disc,software',"unicode"=>'');
$icons['Default']['save2'] = array("class"=>'save2',"tags"=>'disc,floppy,save,software',"unicode"=>'');
$icons['Default']['keyboard'] = array("class"=>'keyboard',"tags"=>'keyboard,connect',"unicode"=>'');
$icons['Default']['mouse'] = array("class"=>'mouse',"tags"=>'mouse',"unicode"=>'');
$icons['Default']['wireless'] = array("class"=>'wireless',"tags"=>'mouse,wireless',"unicode"=>'');
$icons['Default']['tablet2'] = array("class"=>'tablet2',"tags"=>'ipad,tablet',"unicode"=>'');
$icons['Default']['mobile2'] = array("class"=>'mobile2',"tags"=>'iphone,mobile',"unicode"=>'');
$icons['Default']['internet'] = array("class"=>'internet',"tags"=>'wi-fi,wlan,connect,internet',"unicode"=>'');
$icons['Default']['wi-fi'] = array("class"=>'wi-fi',"tags"=>'wi-fi,wlan,connect,internet',"unicode"=>'');
$icons['Default']['network'] = array("class"=>'network',"tags"=>'network,connection,lan,computers',"unicode"=>'');
$icons['Default']['wlan'] = array("class"=>'wlan',"tags"=>'wi-fi,wlan,connect,internet,signal,antenna',"unicode"=>'');
$icons['Default']['Aquarius'] = array("class"=>'Aquarius',"tags"=>'Aquarius',"unicode"=>'');
$icons['Default']['Add-Window'] = array("class"=>'Add-Window',"tags"=>'Add-Window',"unicode"=>'');
$icons['Default']['Approved-Window'] = array("class"=>'Approved-Window',"tags"=>'Approved-Window',"unicode"=>'');
$icons['Default']['Block-Window'] = array("class"=>'Block-Window',"tags"=>'Block-Window',"unicode"=>'');
$icons['Default']['Close-Window'] = array("class"=>'Close-Window',"tags"=>'Close-Window',"unicode"=>'');
$icons['Default']['Code-Window'] = array("class"=>'Code-Window',"tags"=>'Code-Window',"unicode"=>'');
$icons['Default']['Delete-Window'] = array("class"=>'Delete-Window',"tags"=>'Delete-Window',"unicode"=>'');
$icons['Default']['Download-Window'] = array("class"=>'Download-Window',"tags"=>'Download-Window',"unicode"=>'');
$icons['Default']['Duplicate-Window'] = array("class"=>'Duplicate-Window',"tags"=>'Duplicate-Window',"unicode"=>'');
$icons['Default']['Error-404Window'] = array("class"=>'Error-404Window',"tags"=>'Error-404Window',"unicode"=>'');
$icons['Default']['Favorite-Window'] = array("class"=>'Favorite-Window',"tags"=>'Favorite-Window',"unicode"=>'');
$icons['Default']['Font-Window'] = array("class"=>'Font-Window',"tags"=>'Font-Window',"unicode"=>'');
$icons['Default']['Full-ViewWindow'] = array("class"=>'Full-ViewWindow',"tags"=>'Full-ViewWindow',"unicode"=>'');
$icons['Default']['Height-Window'] = array("class"=>'Height-Window',"tags"=>'Height-Window',"unicode"=>'');
$icons['Default']['Home-Window'] = array("class"=>'Home-Window',"tags"=>'Home-Window',"unicode"=>'');
$icons['Default']['Info-Window'] = array("class"=>'Info-Window',"tags"=>'Info-Window',"unicode"=>'');
$icons['Default']['Loading-Window'] = array("class"=>'Loading-Window',"tags"=>'Loading-Window',"unicode"=>'');
$icons['Default']['Lock-Window'] = array("class"=>'Lock-Window',"tags"=>'Lock-Window',"unicode"=>'');
$icons['Default']['Love-Window'] = array("class"=>'Love-Window',"tags"=>'Love-Window',"unicode"=>'');
$icons['Default']['Maximize-Window'] = array("class"=>'Maximize-Window',"tags"=>'Maximize-Window',"unicode"=>'');
$icons['Default']['Minimize-Maximize-Close-Window'] = array("class"=>'Minimize-Maximize-Close-Window',"tags"=>'Minimize-Maximize-Close-Window',"unicode"=>'');
$icons['Default']['Minimize-Window'] = array("class"=>'Minimize-Window',"tags"=>'Minimize-Window',"unicode"=>'');
$icons['Default']['Navigation-LeftWindow'] = array("class"=>'Navigation-LeftWindow',"tags"=>'Navigation-LeftWindow',"unicode"=>'');
$icons['Default']['Navigation-RightWindow'] = array("class"=>'Navigation-RightWindow',"tags"=>'Navigation-RightWindow',"unicode"=>'');
$icons['Default']['Network-Window'] = array("class"=>'Network-Window',"tags"=>'Network-Window',"unicode"=>'');
$icons['Default']['New-Tab'] = array("class"=>'New-Tab',"tags"=>'New-Tab',"unicode"=>'');
$icons['Default']['One-Window'] = array("class"=>'One-Window',"tags"=>'One-Window',"unicode"=>'');
$icons['Default']['Refresh-Window'] = array("class"=>'Refresh-Window',"tags"=>'Refresh-Window',"unicode"=>'');
$icons['Default']['Remove-Window'] = array("class"=>'Remove-Window',"tags"=>'Remove-Window',"unicode"=>'');
$icons['Default']['Restore-Window'] = array("class"=>'Restore-Window',"tags"=>'Restore-Window',"unicode"=>'');
$icons['Default']['Save-Window'] = array("class"=>'Save-Window',"tags"=>'Save-Window',"unicode"=>'');
$icons['Default']['Settings-Window'] = array("class"=>'Settings-Window',"tags"=>'Settings-Window',"unicode"=>'');
$icons['Default']['Share-Window'] = array("class"=>'Share-Window',"tags"=>'Share-Window',"unicode"=>'');
$icons['Default']['Sidebar-Window'] = array("class"=>'Sidebar-Window',"tags"=>'Sidebar-Window',"unicode"=>'');
$icons['Default']['Split-FourSquareWindow'] = array("class"=>'Split-FourSquareWindow',"tags"=>'Split-FourSquareWindow',"unicode"=>'');
$icons['Default']['Split-Horizontal'] = array("class"=>'Split-Horizontal',"tags"=>'Split-Horizontal',"unicode"=>'');
$icons['Default']['Split-Horizontal2Window'] = array("class"=>'Split-Horizontal2Window',"tags"=>'Split-Horizontal2Window',"unicode"=>'');
$icons['Default']['Split-Vertical'] = array("class"=>'Split-Vertical',"tags"=>'Split-Vertical',"unicode"=>'');
$icons['Default']['Split-Vertical2'] = array("class"=>'Split-Vertical2',"tags"=>'Split-Vertical2',"unicode"=>'');
$icons['Default']['Split-Window'] = array("class"=>'Split-Window',"tags"=>'Split-Window',"unicode"=>'');
$icons['Default']['Time-Window'] = array("class"=>'Time-Window',"tags"=>'Time-Window',"unicode"=>'');
$icons['Default']['Touch-Window'] = array("class"=>'Touch-Window',"tags"=>'Touch-Window',"unicode"=>'');
$icons['Default']['Two-Windows'] = array("class"=>'Two-Windows',"tags"=>'Two-Windows',"unicode"=>'');
$icons['Default']['Upload-Window'] = array("class"=>'Upload-Window',"tags"=>'Upload-Window',"unicode"=>'');
$icons['Default']['URL-Window'] = array("class"=>'URL-Window',"tags"=>'URL-Window',"unicode"=>'');
$icons['Default']['Warning-Window'] = array("class"=>'Warning-Window',"tags"=>'Warning-Window',"unicode"=>'');
$icons['Default']['Width-Window'] = array("class"=>'Width-Window',"tags"=>'Width-Window',"unicode"=>'');
$icons['Default']['Window-2'] = array("class"=>'Window-2',"tags"=>'Window-2',"unicode"=>'');
$icons['Default']['Windows-2'] = array("class"=>'Windows-2',"tags"=>'Windows-2',"unicode"=>'');
$icons['Default']['Celsius'] = array("class"=>'Celsius',"tags"=>'Celsius',"unicode"=>'');
$icons['Default']['Cloud-Hail'] = array("class"=>'Cloud-Hail',"tags"=>'Cloud-Hail',"unicode"=>'');
$icons['Default']['Cloud-Moon'] = array("class"=>'Cloud-Moon',"tags"=>'Cloud-Moon',"unicode"=>'');
$icons['Default']['Cloud-Rain'] = array("class"=>'Cloud-Rain',"tags"=>'Cloud-Rain',"unicode"=>'');
$icons['Default']['Cloud-Snow'] = array("class"=>'Cloud-Snow',"tags"=>'Cloud-Snow',"unicode"=>'');
$icons['Default']['Cloud-Sun'] = array("class"=>'Cloud-Sun',"tags"=>'Cloud-Sun',"unicode"=>'');
$icons['Default']['Clouds-Weather'] = array("class"=>'Clouds-Weather',"tags"=>'Clouds-Weather',"unicode"=>'');
$icons['Default']['Cloud-Weather'] = array("class"=>'Cloud-Weather',"tags"=>'Cloud-Weather',"unicode"=>'');
$icons['Default']['Drop'] = array("class"=>'Drop',"tags"=>'Drop',"unicode"=>'');
$icons['Default']['Fahrenheit'] = array("class"=>'Fahrenheit',"tags"=>'Fahrenheit',"unicode"=>'');
$icons['Default']['Fog-Day'] = array("class"=>'Fog-Day',"tags"=>'Fog-Day',"unicode"=>'');
$icons['Default']['Fog-Night'] = array("class"=>'Fog-Night',"tags"=>'Fog-Night',"unicode"=>'');
$icons['Default']['Full-Moon'] = array("class"=>'Full-Moon',"tags"=>'Full-Moon',"unicode"=>'');
$icons['Default']['Half-Moon'] = array("class"=>'Half-Moon',"tags"=>'Half-Moon',"unicode"=>'');
$icons['Default']['No-Drop'] = array("class"=>'No-Drop',"tags"=>'No-Drop',"unicode"=>'');
$icons['Default']['Rainbow'] = array("class"=>'Rainbow',"tags"=>'Rainbow',"unicode"=>'');
$icons['Default']['Rainbow-2'] = array("class"=>'Rainbow-2',"tags"=>'Rainbow-2',"unicode"=>'');
$icons['Default']['Rain-Drop'] = array("class"=>'Rain-Drop',"tags"=>'Rain-Drop',"unicode"=>'');
$icons['Default']['Sleet'] = array("class"=>'Sleet',"tags"=>'Sleet',"unicode"=>'');
$icons['Default']['Snow-Storm'] = array("class"=>'Snow-Storm',"tags"=>'Snow-Storm',"unicode"=>'');
$icons['Default']['Spring'] = array("class"=>'Spring',"tags"=>'Spring',"unicode"=>'');
$icons['Default']['Storm'] = array("class"=>'Storm',"tags"=>'Storm',"unicode"=>'');
$icons['Default']['Summer'] = array("class"=>'Summer',"tags"=>'Summer',"unicode"=>'');
$icons['Default']['Sun'] = array("class"=>'Sun',"tags"=>'Sun',"unicode"=>'');
$icons['Default']['Sun-CloudyRain'] = array("class"=>'Sun-CloudyRain',"tags"=>'Sun-CloudyRain',"unicode"=>'');
$icons['Default']['Sunrise'] = array("class"=>'Sunrise',"tags"=>'Sunrise',"unicode"=>'');
$icons['Default']['Sunset'] = array("class"=>'Sunset',"tags"=>'Sunset',"unicode"=>'');
$icons['Default']['Temperature'] = array("class"=>'Temperature',"tags"=>'Temperature',"unicode"=>'');
$icons['Default']['Temperature-2'] = array("class"=>'Temperature-2',"tags"=>'Temperature-2',"unicode"=>'');
$icons['Default']['Thunder'] = array("class"=>'Thunder',"tags"=>'Thunder',"unicode"=>'');
$icons['Default']['Thunderstorm'] = array("class"=>'Thunderstorm',"tags"=>'Thunderstorm',"unicode"=>'');
$icons['Default']['Twister'] = array("class"=>'Twister',"tags"=>'Twister',"unicode"=>'');
$icons['Default']['Umbrella-2'] = array("class"=>'Umbrella-2',"tags"=>'Umbrella-2',"unicode"=>'');
$icons['Default']['Umbrella-3'] = array("class"=>'Umbrella-3',"tags"=>'Umbrella-3',"unicode"=>'');
$icons['Default']['Wave'] = array("class"=>'Wave',"tags"=>'Wave',"unicode"=>'');
$icons['Default']['Windy'] = array("class"=>'Windy',"tags"=>'Windy',"unicode"=>'');
$icons['Default']['Clapperboard-Open'] = array("class"=>'Clapperboard-Open',"tags"=>'Clapperboard-Open',"unicode"=>'');
$icons['Default']['Film'] = array("class"=>'Film',"tags"=>'Film',"unicode"=>'');
$icons['Default']['Film-Strip'] = array("class"=>'Film-Strip',"tags"=>'Film-Strip',"unicode"=>'');
$icons['Default']['Film-Video'] = array("class"=>'Film-Video',"tags"=>'Film-Video',"unicode"=>'');
$icons['Default']['Flash-Video'] = array("class"=>'Flash-Video',"tags"=>'Flash-Video',"unicode"=>'');
$icons['Default']['HD-Video'] = array("class"=>'HD-Video',"tags"=>'HD-Video',"unicode"=>'');
$icons['Default']['Movie'] = array("class"=>'Movie',"tags"=>'Movie',"unicode"=>'');
$icons['Default']['Old-TV'] = array("class"=>'Old-TV',"tags"=>'Old-TV',"unicode"=>'');
$icons['Default']['Reel'] = array("class"=>'Reel',"tags"=>'Reel',"unicode"=>'');
$icons['Default']['Video'] = array("class"=>'Video',"tags"=>'Video',"unicode"=>'');
$icons['Default']['Video-2'] = array("class"=>'Video-2',"tags"=>'Video-2',"unicode"=>'');
$icons['Default']['Video-3'] = array("class"=>'Video-3',"tags"=>'Video-3',"unicode"=>'');
$icons['Default']['Video-4'] = array("class"=>'Video-4',"tags"=>'Video-4',"unicode"=>'');
$icons['Default']['Video-5'] = array("class"=>'Video-5',"tags"=>'Video-5',"unicode"=>'');
$icons['Default']['Video-6'] = array("class"=>'Video-6',"tags"=>'Video-6',"unicode"=>'');
$icons['Default']['Video-Len2'] = array("class"=>'Video-Len2',"tags"=>'Video-Len2',"unicode"=>'');
$icons['Default']['Video-Photographer'] = array("class"=>'Video-Photographer',"tags"=>'Video-Photographer',"unicode"=>'');
$icons['Default']['Video-Tripod'] = array("class"=>'Video-Tripod',"tags"=>'Video-Tripod',"unicode"=>'');
$icons['Default']['Affiliate'] = array("class"=>'Affiliate',"tags"=>'Affiliate',"unicode"=>'');
$icons['Default']['Background'] = array("class"=>'Background',"tags"=>'Background',"unicode"=>'');
$icons['Default']['Billing'] = array("class"=>'Billing',"tags"=>'Billing',"unicode"=>'');
$icons['Default']['Control'] = array("class"=>'Control',"tags"=>'Control',"unicode"=>'');
$icons['Default']['Control-2'] = array("class"=>'Control-2',"tags"=>'Control-2',"unicode"=>'');
$icons['Default']['Crop-2'] = array("class"=>'Crop-2',"tags"=>'Crop-2',"unicode"=>'');
$icons['Default']['Dashboard'] = array("class"=>'Dashboard',"tags"=>'Dashboard',"unicode"=>'');
$icons['Default']['Duplicate-Layer'] = array("class"=>'Duplicate-Layer',"tags"=>'Duplicate-Layer',"unicode"=>'');
$icons['Default']['Filter-2'] = array("class"=>'Filter-2',"tags"=>'Filter-2',"unicode"=>'');
$icons['Default']['Gear'] = array("class"=>'Gear',"tags"=>'Gear',"unicode"=>'');
$icons['Default']['Gear-2'] = array("class"=>'Gear-2',"tags"=>'Gear-2',"unicode"=>'');
$icons['Default']['Gears'] = array("class"=>'Gears',"tags"=>'Gears',"unicode"=>'');
$icons['Default']['Gears-2'] = array("class"=>'Gears-2',"tags"=>'Gears-2',"unicode"=>'');
$icons['Default']['Information'] = array("class"=>'Information',"tags"=>'Information',"unicode"=>'');
$icons['Default']['Layer-Backward'] = array("class"=>'Layer-Backward',"tags"=>'Layer-Backward',"unicode"=>'');
$icons['Default']['Layer-Forward'] = array("class"=>'Layer-Forward',"tags"=>'Layer-Forward',"unicode"=>'');
$icons['Default']['Library'] = array("class"=>'Library',"tags"=>'Library',"unicode"=>'');
$icons['Default']['Loading'] = array("class"=>'Loading',"tags"=>'Loading',"unicode"=>'');
$icons['Default']['Loading-2'] = array("class"=>'Loading-2',"tags"=>'Loading-2',"unicode"=>'');
$icons['Default']['Loading-3'] = array("class"=>'Loading-3',"tags"=>'Loading-3',"unicode"=>'');
$icons['Default']['Magnifi-Glass'] = array("class"=>'Magnifi-Glass',"tags"=>'Magnifi-Glass',"unicode"=>'');
$icons['Default']['Magnifi-Glass2'] = array("class"=>'Magnifi-Glass2',"tags"=>'Magnifi-Glass2',"unicode"=>'');
$icons['Default']['Magnifi-Glass22'] = array("class"=>'Magnifi-Glass22',"tags"=>'Magnifi-Glass22',"unicode"=>'');
$icons['Default']['Mouse-Pointer'] = array("class"=>'Mouse-Pointer',"tags"=>'Mouse-Pointer',"unicode"=>'');
$icons['Default']['On-off'] = array("class"=>'On-off',"tags"=>'On-off',"unicode"=>'');
$icons['Default']['Pricing'] = array("class"=>'Pricing',"tags"=>'Pricing',"unicode"=>'');
$icons['Default']['Profile'] = array("class"=>'Profile',"tags"=>'Profile',"unicode"=>'');
$icons['Default']['Project'] = array("class"=>'Project',"tags"=>'Project',"unicode"=>'');
$icons['Default']['Rename'] = array("class"=>'Rename',"tags"=>'Rename',"unicode"=>'');
$icons['Default']['Save'] = array("class"=>'Save',"tags"=>'Save',"unicode"=>'');
$icons['Default']['Scroller'] = array("class"=>'Scroller',"tags"=>'Scroller',"unicode"=>'');
$icons['Default']['Share'] = array("class"=>'Share',"tags"=>'Share',"unicode"=>'');
$icons['Default']['Statistic'] = array("class"=>'Statistic',"tags"=>'Statistic',"unicode"=>'');
$icons['Default']['Support'] = array("class"=>'Support',"tags"=>'Support',"unicode"=>'');
$icons['Default']['Switch'] = array("class"=>'Switch',"tags"=>'Switch',"unicode"=>'');
$icons['Default']['Upgrade'] = array("class"=>'Upgrade',"tags"=>'Upgrade',"unicode"=>'');
$icons['Default']['User'] = array("class"=>'User',"tags"=>'User',"unicode"=>'');
$icons['Default']['Bicycle'] = array("class"=>'Bicycle',"tags"=>'Bicycle',"unicode"=>'');
$icons['Default']['Bus'] = array("class"=>'Bus',"tags"=>'Bus',"unicode"=>'');
$icons['Default']['Bus-2'] = array("class"=>'Bus-2',"tags"=>'Bus-2',"unicode"=>'');
$icons['Default']['Car'] = array("class"=>'Car',"tags"=>'Car',"unicode"=>'');
$icons['Default']['Car-3'] = array("class"=>'Car-3',"tags"=>'Car-3',"unicode"=>'');
$icons['Default']['Car-Wheel'] = array("class"=>'Car-Wheel',"tags"=>'Car-Wheel',"unicode"=>'');
$icons['Default']['Gaugage'] = array("class"=>'Gaugage',"tags"=>'Gaugage',"unicode"=>'');
$icons['Default']['Gaugage-2'] = array("class"=>'Gaugage-2',"tags"=>'Gaugage-2',"unicode"=>'');
$icons['Default']['Helmet'] = array("class"=>'Helmet',"tags"=>'Helmet',"unicode"=>'');
$icons['Default']['Jeep'] = array("class"=>'Jeep',"tags"=>'Jeep',"unicode"=>'');
$icons['Default']['Jeep-2'] = array("class"=>'Jeep-2',"tags"=>'Jeep-2',"unicode"=>'');
$icons['Default']['Jet'] = array("class"=>'Jet',"tags"=>'Jet',"unicode"=>'');
$icons['Default']['Motorcycle'] = array("class"=>'Motorcycle',"tags"=>'Motorcycle',"unicode"=>'');
$icons['Default']['Plane'] = array("class"=>'Plane',"tags"=>'Plane',"unicode"=>'');
$icons['Default']['Plane-2'] = array("class"=>'Plane-2',"tags"=>'Plane-2',"unicode"=>'');
$icons['Default']['Road'] = array("class"=>'Road',"tags"=>'Road',"unicode"=>'');
$icons['Default']['Road-2'] = array("class"=>'Road-2',"tags"=>'Road-2',"unicode"=>'');
$icons['Default']['Rocket'] = array("class"=>'Rocket',"tags"=>'Rocket',"unicode"=>'');
$icons['Default']['Sailing-Ship'] = array("class"=>'Sailing-Ship',"tags"=>'Sailing-Ship',"unicode"=>'');
$icons['Default']['Scooter'] = array("class"=>'Scooter',"tags"=>'Scooter',"unicode"=>'');
$icons['Default']['Scooter-Front'] = array("class"=>'Scooter-Front',"tags"=>'Scooter-Front',"unicode"=>'');
$icons['Default']['Ship'] = array("class"=>'Ship',"tags"=>'Ship',"unicode"=>'');
$icons['Default']['Ship-2'] = array("class"=>'Ship-2',"tags"=>'Ship-2',"unicode"=>'');
$icons['Default']['Skateboard-2'] = array("class"=>'Skateboard-2',"tags"=>'Skateboard-2',"unicode"=>'');
$icons['Default']['Taxi'] = array("class"=>'Taxi',"tags"=>'Taxi',"unicode"=>'');
$icons['Default']['Taxi-2'] = array("class"=>'Taxi-2',"tags"=>'Taxi-2',"unicode"=>'');
$icons['Default']['Taxi-Sign'] = array("class"=>'Taxi-Sign',"tags"=>'Taxi-Sign',"unicode"=>'');
$icons['Default']['Tractor'] = array("class"=>'Tractor',"tags"=>'Tractor',"unicode"=>'');
$icons['Default']['traffic-Light'] = array("class"=>'traffic-Light',"tags"=>'traffic-Light',"unicode"=>'');
$icons['Default']['Traffic-Light2'] = array("class"=>'Traffic-Light2',"tags"=>'Traffic-Light2',"unicode"=>'');
$icons['Default']['Train'] = array("class"=>'Train',"tags"=>'Train',"unicode"=>'');
$icons['Default']['Train-2'] = array("class"=>'Train-2',"tags"=>'Train-2',"unicode"=>'');
$icons['Default']['Tram'] = array("class"=>'Tram',"tags"=>'Tram',"unicode"=>'');
$icons['Default']['Truck'] = array("class"=>'Truck',"tags"=>'Truck',"unicode"=>'');
$icons['Default']['Double-Tap'] = array("class"=>'Double-Tap',"tags"=>'Double-Tap',"unicode"=>'');
$icons['Default']['Drag'] = array("class"=>'Drag',"tags"=>'Drag',"unicode"=>'');
$icons['Default']['Drag-Down'] = array("class"=>'Drag-Down',"tags"=>'Drag-Down',"unicode"=>'');
$icons['Default']['Drag-Left'] = array("class"=>'Drag-Left',"tags"=>'Drag-Left',"unicode"=>'');
$icons['Default']['Drag-Right'] = array("class"=>'Drag-Right',"tags"=>'Drag-Right',"unicode"=>'');
$icons['Default']['Drag-Up'] = array("class"=>'Drag-Up',"tags"=>'Drag-Up',"unicode"=>'');
$icons['Default']['Finger-DragFourSides'] = array("class"=>'Finger-DragFourSides',"tags"=>'Finger-DragFourSides',"unicode"=>'');
$icons['Default']['Finger-DragTwoSides'] = array("class"=>'Finger-DragTwoSides',"tags"=>'Finger-DragTwoSides',"unicode"=>'');
$icons['Default']['Five-Fingers'] = array("class"=>'Five-Fingers',"tags"=>'Five-Fingers',"unicode"=>'');
$icons['Default']['Five-FingersDrag'] = array("class"=>'Five-FingersDrag',"tags"=>'Five-FingersDrag',"unicode"=>'');
$icons['Default']['Five-FingersDrag2'] = array("class"=>'Five-FingersDrag2',"tags"=>'Five-FingersDrag2',"unicode"=>'');
$icons['Default']['Five-FingersTouch'] = array("class"=>'Five-FingersTouch',"tags"=>'Five-FingersTouch',"unicode"=>'');
$icons['Default']['Four-Fingers'] = array("class"=>'Four-Fingers',"tags"=>'Four-Fingers',"unicode"=>'');
$icons['Default']['Four-FingersDrag'] = array("class"=>'Four-FingersDrag',"tags"=>'Four-FingersDrag',"unicode"=>'');
$icons['Default']['Four-FingersDrag2'] = array("class"=>'Four-FingersDrag2',"tags"=>'Four-FingersDrag2',"unicode"=>'');
$icons['Default']['Four-FingersTouch'] = array("class"=>'Four-FingersTouch',"tags"=>'Four-FingersTouch',"unicode"=>'');
$icons['Default']['Hand-Touch'] = array("class"=>'Hand-Touch',"tags"=>'Hand-Touch',"unicode"=>'');
$icons['Default']['Hand-Touch2'] = array("class"=>'Hand-Touch2',"tags"=>'Hand-Touch2',"unicode"=>'');
$icons['Default']['Hand-TouchSmartphone'] = array("class"=>'Hand-TouchSmartphone',"tags"=>'Hand-TouchSmartphone',"unicode"=>'');
$icons['Default']['One-Finger'] = array("class"=>'One-Finger',"tags"=>'One-Finger',"unicode"=>'');
$icons['Default']['One-FingerTouch'] = array("class"=>'One-FingerTouch',"tags"=>'One-FingerTouch',"unicode"=>'');
$icons['Default']['Pinch'] = array("class"=>'Pinch',"tags"=>'Pinch',"unicode"=>'');
$icons['Default']['Press'] = array("class"=>'Press',"tags"=>'Press',"unicode"=>'');
$icons['Default']['Rotate-Gesture'] = array("class"=>'Rotate-Gesture',"tags"=>'Rotate-Gesture',"unicode"=>'');
$icons['Default']['Rotate-Gesture2'] = array("class"=>'Rotate-Gesture2',"tags"=>'Rotate-Gesture2',"unicode"=>'');
$icons['Default']['Rotate-Gesture3'] = array("class"=>'Rotate-Gesture3',"tags"=>'Rotate-Gesture3',"unicode"=>'');
$icons['Default']['Scroll'] = array("class"=>'Scroll',"tags"=>'Scroll',"unicode"=>'');
$icons['Default']['Scroll-Fast'] = array("class"=>'Scroll-Fast',"tags"=>'Scroll-Fast',"unicode"=>'');
$icons['Default']['Spread'] = array("class"=>'Spread',"tags"=>'Spread',"unicode"=>'');
$icons['Default']['Star-Track'] = array("class"=>'Star-Track',"tags"=>'Star-Track',"unicode"=>'');
$icons['Default']['Tap'] = array("class"=>'Tap',"tags"=>'Tap',"unicode"=>'');
$icons['Default']['Three-Fingers'] = array("class"=>'Three-Fingers',"tags"=>'Three-Fingers',"unicode"=>'');
$icons['Default']['Three-FingersDrag'] = array("class"=>'Three-FingersDrag',"tags"=>'Three-FingersDrag',"unicode"=>'');
$icons['Default']['Three-FingersDrag2'] = array("class"=>'Three-FingersDrag2',"tags"=>'Three-FingersDrag2',"unicode"=>'');
$icons['Default']['Three-FingersTouch'] = array("class"=>'Three-FingersTouch',"tags"=>'Three-FingersTouch',"unicode"=>'');
$icons['Default']['Thumb'] = array("class"=>'Thumb',"tags"=>'Thumb',"unicode"=>'');
$icons['Default']['Two-Fingers'] = array("class"=>'Two-Fingers',"tags"=>'Two-Fingers',"unicode"=>'');
$icons['Default']['Two-FingersDrag'] = array("class"=>'Two-FingersDrag',"tags"=>'Two-FingersDrag',"unicode"=>'');
$icons['Default']['Two-FingersDrag2'] = array("class"=>'Two-FingersDrag2',"tags"=>'Two-FingersDrag2',"unicode"=>'');
$icons['Default']['Two-FingersScroll'] = array("class"=>'Two-FingersScroll',"tags"=>'Two-FingersScroll',"unicode"=>'');
$icons['Default']['Two-FingersTouch'] = array("class"=>'Two-FingersTouch',"tags"=>'Two-FingersTouch',"unicode"=>'');
$icons['Default']['Zoom-Gesture'] = array("class"=>'Zoom-Gesture',"tags"=>'Zoom-Gesture',"unicode"=>'');
$icons['Default']['Alarm-Clock'] = array("class"=>'Alarm-Clock',"tags"=>'Alarm-Clock',"unicode"=>'');
$icons['Default']['Alarm-Clock2'] = array("class"=>'Alarm-Clock2',"tags"=>'Alarm-Clock2',"unicode"=>'');
$icons['Default']['Calendar-Clock'] = array("class"=>'Calendar-Clock',"tags"=>'Calendar-Clock',"unicode"=>'');
$icons['Default']['Clock'] = array("class"=>'Clock',"tags"=>'Clock',"unicode"=>'');
$icons['Default']['Clock-3'] = array("class"=>'Clock-3',"tags"=>'Clock-3',"unicode"=>'');
$icons['Default']['Clock-4'] = array("class"=>'Clock-4',"tags"=>'Clock-4',"unicode"=>'');
$icons['Default']['Clock-Back'] = array("class"=>'Clock-Back',"tags"=>'Clock-Back',"unicode"=>'');
$icons['Default']['Clock-Forward'] = array("class"=>'Clock-Forward',"tags"=>'Clock-Forward',"unicode"=>'');
$icons['Default']['Hour'] = array("class"=>'Hour',"tags"=>'Hour',"unicode"=>'');
$icons['Default']['Old-Clock'] = array("class"=>'Old-Clock',"tags"=>'Old-Clock',"unicode"=>'');
$icons['Default']['Over-Time'] = array("class"=>'Over-Time',"tags"=>'Over-Time',"unicode"=>'');
$icons['Default']['Over-Time2'] = array("class"=>'Over-Time2',"tags"=>'Over-Time2',"unicode"=>'');
$icons['Default']['Sand-watch'] = array("class"=>'Sand-watch',"tags"=>'Sand-watch',"unicode"=>'');
$icons['Default']['Sand-watch2'] = array("class"=>'Sand-watch2',"tags"=>'Sand-watch2',"unicode"=>'');
$icons['Default']['Stopwatch'] = array("class"=>'Stopwatch',"tags"=>'Stopwatch',"unicode"=>'');
$icons['Default']['Stopwatch-2'] = array("class"=>'Stopwatch-2',"tags"=>'Stopwatch-2',"unicode"=>'');
$icons['Default']['Time-Backup'] = array("class"=>'Time-Backup',"tags"=>'Time-Backup',"unicode"=>'');
$icons['Default']['Time-Machine'] = array("class"=>'Time-Machine',"tags"=>'Time-Machine',"unicode"=>'');
$icons['Default']['Timer'] = array("class"=>'Timer',"tags"=>'Timer',"unicode"=>'');
$icons['Default']['Watch'] = array("class"=>'Watch',"tags"=>'Watch',"unicode"=>'');
$icons['Default']['Watch-2'] = array("class"=>'Watch-2',"tags"=>'Watch-2',"unicode"=>'');
$icons['Default']['Watch-3'] = array("class"=>'Watch-3',"tags"=>'Watch-3',"unicode"=>'');
$icons['Default']['A-Z'] = array("class"=>'A-Z',"tags"=>'A-Z',"unicode"=>'');
$icons['Default']['Bold-Text'] = array("class"=>'Bold-Text',"tags"=>'Bold-Text',"unicode"=>'');
$icons['Default']['Bulleted-List'] = array("class"=>'Bulleted-List',"tags"=>'Bulleted-List',"unicode"=>'');
$icons['Default']['Font-Color'] = array("class"=>'Font-Color',"tags"=>'Font-Color',"unicode"=>'');
$icons['Default']['Font-Name'] = array("class"=>'Font-Name',"tags"=>'Font-Name',"unicode"=>'');
$icons['Default']['Font-Size'] = array("class"=>'Font-Size',"tags"=>'Font-Size',"unicode"=>'');
$icons['Default']['Font-Style'] = array("class"=>'Font-Style',"tags"=>'Font-Style',"unicode"=>'');
$icons['Default']['Font-StyleSubscript'] = array("class"=>'Font-StyleSubscript',"tags"=>'Font-StyleSubscript',"unicode"=>'');
$icons['Default']['Font-StyleSuperscript'] = array("class"=>'Font-StyleSuperscript',"tags"=>'Font-StyleSuperscript',"unicode"=>'');
$icons['Default']['Function'] = array("class"=>'Function',"tags"=>'Function',"unicode"=>'');
$icons['Default']['Italic-Text'] = array("class"=>'Italic-Text',"tags"=>'Italic-Text',"unicode"=>'');
$icons['Default']['Line-SpacingText'] = array("class"=>'Line-SpacingText',"tags"=>'Line-SpacingText',"unicode"=>'');
$icons['Default']['Normal-Text'] = array("class"=>'Normal-Text',"tags"=>'Normal-Text',"unicode"=>'');
$icons['Default']['Numbering-List'] = array("class"=>'Numbering-List',"tags"=>'Numbering-List',"unicode"=>'');
$icons['Default']['Strikethrough-Text'] = array("class"=>'Strikethrough-Text',"tags"=>'Strikethrough-Text',"unicode"=>'');
$icons['Default']['Sum'] = array("class"=>'Sum',"tags"=>'Sum',"unicode"=>'');
$icons['Default']['Text-Box'] = array("class"=>'Text-Box',"tags"=>'Text-Box',"unicode"=>'');
$icons['Default']['Text-Effect'] = array("class"=>'Text-Effect',"tags"=>'Text-Effect',"unicode"=>'');
$icons['Default']['Text-HighlightColor'] = array("class"=>'Text-HighlightColor',"tags"=>'Text-HighlightColor',"unicode"=>'');
$icons['Default']['Text-Paragraph'] = array("class"=>'Text-Paragraph',"tags"=>'Text-Paragraph',"unicode"=>'');
$icons['Default']['Archery'] = array("class"=>'Archery',"tags"=>'Archery',"unicode"=>'');
$icons['Default']['Archery-2'] = array("class"=>'Archery-2',"tags"=>'Archery-2',"unicode"=>'');
$icons['Default']['Bowling'] = array("class"=>'Bowling',"tags"=>'Bowling',"unicode"=>'');
$icons['Default']['Chess'] = array("class"=>'Chess',"tags"=>'Chess',"unicode"=>'');
$icons['Default']['Cricket'] = array("class"=>'Cricket',"tags"=>'Cricket',"unicode"=>'');
$icons['Default']['Football'] = array("class"=>'Football',"tags"=>'Football',"unicode"=>'');
$icons['Default']['Football-2'] = array("class"=>'Football-2',"tags"=>'Football-2',"unicode"=>'');
$icons['Default']['Footprint'] = array("class"=>'Footprint',"tags"=>'Footprint',"unicode"=>'');
$icons['Default']['Footprint-2'] = array("class"=>'Footprint-2',"tags"=>'Footprint-2',"unicode"=>'');
$icons['Default']['Speach-Bubble'] = array("class"=>'Speach-Bubble',"tags"=>'Speach-Bubble',"unicode"=>'');
$icons['Default']['Speach-Bubble2'] = array("class"=>'Speach-Bubble2',"tags"=>'Speach-Bubble2',"unicode"=>'');
$icons['Default']['Speach-Bubble3'] = array("class"=>'Speach-Bubble3',"tags"=>'Speach-Bubble3',"unicode"=>'');
$icons['Default']['Speach-Bubble4'] = array("class"=>'Speach-Bubble4',"tags"=>'Speach-Bubble4',"unicode"=>'');
$icons['Default']['Speach-Bubble5'] = array("class"=>'Speach-Bubble5',"tags"=>'Speach-Bubble5',"unicode"=>'');
$icons['Default']['Speach-Bubble6'] = array("class"=>'Speach-Bubble6',"tags"=>'Speach-Bubble6',"unicode"=>'');
$icons['Default']['Speach-Bubble7'] = array("class"=>'Speach-Bubble7',"tags"=>'Speach-Bubble7',"unicode"=>'');
$icons['Default']['Speach-Bubble8'] = array("class"=>'Speach-Bubble8',"tags"=>'Speach-Bubble8',"unicode"=>'');
$icons['Default']['Speach-Bubble9'] = array("class"=>'Speach-Bubble9',"tags"=>'Speach-Bubble9',"unicode"=>'');
$icons['Default']['Speach-Bubble10'] = array("class"=>'Speach-Bubble10',"tags"=>'Speach-Bubble10',"unicode"=>'');
$icons['Default']['Speach-Bubble11'] = array("class"=>'Speach-Bubble11',"tags"=>'Speach-Bubble11',"unicode"=>'');
$icons['Default']['Speach-Bubble12'] = array("class"=>'Speach-Bubble12',"tags"=>'Speach-Bubble12',"unicode"=>'');
$icons['Default']['Speach-Bubble13'] = array("class"=>'Speach-Bubble13',"tags"=>'Speach-Bubble13',"unicode"=>'');
$icons['Default']['Speach-BubbleAsking'] = array("class"=>'Speach-BubbleAsking',"tags"=>'Speach-BubbleAsking',"unicode"=>'');
$icons['Default']['Speach-BubbleComic'] = array("class"=>'Speach-BubbleComic',"tags"=>'Speach-BubbleComic',"unicode"=>'');
$icons['Default']['Speach-BubbleComic2'] = array("class"=>'Speach-BubbleComic2',"tags"=>'Speach-BubbleComic2',"unicode"=>'');
$icons['Default']['Speach-BubbleComic3'] = array("class"=>'Speach-BubbleComic3',"tags"=>'Speach-BubbleComic3',"unicode"=>'');
$icons['Default']['Speach-BubbleComic4'] = array("class"=>'Speach-BubbleComic4',"tags"=>'Speach-BubbleComic4',"unicode"=>'');
$icons['Default']['Speach-BubbleDialog'] = array("class"=>'Speach-BubbleDialog',"tags"=>'Speach-BubbleDialog',"unicode"=>'');
$icons['Default']['Speach-Bubbles'] = array("class"=>'Speach-Bubbles',"tags"=>'Speach-Bubbles',"unicode"=>'');
$icons['Default']['Aim'] = array("class"=>'Aim',"tags"=>'Aim',"unicode"=>'');
$icons['Default']['Ask'] = array("class"=>'Ask',"tags"=>'Ask',"unicode"=>'');
$icons['Default']['Bebo'] = array("class"=>'Bebo',"tags"=>'Bebo',"unicode"=>'');
$icons['Default']['Behance'] = array("class"=>'Behance',"tags"=>'Behance',"unicode"=>'');
$icons['Default']['Betvibes'] = array("class"=>'Betvibes',"tags"=>'Betvibes',"unicode"=>'');
$icons['Default']['Bing'] = array("class"=>'Bing',"tags"=>'Bing',"unicode"=>'');
$icons['Default']['Blinklist'] = array("class"=>'Blinklist',"tags"=>'Blinklist',"unicode"=>'');
$icons['Default']['Blogger'] = array("class"=>'Blogger',"tags"=>'Blogger',"unicode"=>'');
$icons['Default']['Brightkite'] = array("class"=>'Brightkite',"tags"=>'Brightkite',"unicode"=>'');
$icons['Default']['Delicious'] = array("class"=>'Delicious',"tags"=>'Delicious',"unicode"=>'');
$icons['Default']['Deviantart'] = array("class"=>'Deviantart',"tags"=>'Deviantart',"unicode"=>'');
$icons['Default']['Digg'] = array("class"=>'Digg',"tags"=>'Digg',"unicode"=>'');
$icons['Default']['Diigo'] = array("class"=>'Diigo',"tags"=>'Diigo',"unicode"=>'');
$icons['Default']['Dribble'] = array("class"=>'Dribble',"tags"=>'Dribble',"unicode"=>'');
$icons['Default']['Email'] = array("class"=>'Email',"tags"=>'Email',"unicode"=>'');
$icons['Default']['Evernote'] = array("class"=>'Evernote',"tags"=>'Evernote',"unicode"=>'');
$icons['Default']['Facebook'] = array("class"=>'Facebook',"tags"=>'Facebook',"unicode"=>'');
$icons['Default']['Facebook-2'] = array("class"=>'Facebook-2',"tags"=>'Facebook-2',"unicode"=>'');
$icons['Default']['Feedburner'] = array("class"=>'Feedburner',"tags"=>'Feedburner',"unicode"=>'');
$icons['Default']['Flickr'] = array("class"=>'Flickr',"tags"=>'Flickr',"unicode"=>'');
$icons['Default']['Formspring'] = array("class"=>'Formspring',"tags"=>'Formspring',"unicode"=>'');
$icons['Default']['Forsquare'] = array("class"=>'Forsquare',"tags"=>'Forsquare',"unicode"=>'');
$icons['Default']['Friendfeed'] = array("class"=>'Friendfeed',"tags"=>'Friendfeed',"unicode"=>'');
$icons['Default']['Friendster'] = array("class"=>'Friendster',"tags"=>'Friendster',"unicode"=>'');
$icons['Default']['Furl'] = array("class"=>'Furl',"tags"=>'Furl',"unicode"=>'');
$icons['Default']['Google'] = array("class"=>'Google',"tags"=>'Google',"unicode"=>'');
$icons['Default']['Google-Buzz'] = array("class"=>'Google-Buzz',"tags"=>'Google-Buzz',"unicode"=>'');
$icons['Default']['Google-Plus'] = array("class"=>'Google-Plus',"tags"=>'Google-Plus',"unicode"=>'');
$icons['Default']['Gowalla'] = array("class"=>'Gowalla',"tags"=>'Gowalla',"unicode"=>'');
$icons['Default']['ICQ'] = array("class"=>'ICQ',"tags"=>'ICQ',"unicode"=>'');
$icons['Default']['ImDB'] = array("class"=>'ImDB',"tags"=>'ImDB',"unicode"=>'');
$icons['Default']['Instagram'] = array("class"=>'Instagram',"tags"=>'Instagram',"unicode"=>'');
$icons['Default']['Last-FM'] = array("class"=>'Last-FM',"tags"=>'Last-FM',"unicode"=>'');
$icons['Default']['Like'] = array("class"=>'Like',"tags"=>'Like',"unicode"=>'');
$icons['Default']['Like-2'] = array("class"=>'Like-2',"tags"=>'Like-2',"unicode"=>'');
$icons['Default']['Linkedin'] = array("class"=>'Linkedin',"tags"=>'Linkedin',"unicode"=>'');
$icons['Default']['Linkedin-2'] = array("class"=>'Linkedin-2',"tags"=>'Linkedin-2',"unicode"=>'');
$icons['Default']['Livejournal'] = array("class"=>'Livejournal',"tags"=>'Livejournal',"unicode"=>'');
$icons['Default']['Metacafe'] = array("class"=>'Metacafe',"tags"=>'Metacafe',"unicode"=>'');
$icons['Default']['Mixx'] = array("class"=>'Mixx',"tags"=>'Mixx',"unicode"=>'');
$icons['Default']['Myspace'] = array("class"=>'Myspace',"tags"=>'Myspace',"unicode"=>'');
$icons['Default']['Newsvine'] = array("class"=>'Newsvine',"tags"=>'Newsvine',"unicode"=>'');
$icons['Default']['Orkut'] = array("class"=>'Orkut',"tags"=>'Orkut',"unicode"=>'');
$icons['Default']['Picasa'] = array("class"=>'Picasa',"tags"=>'Picasa',"unicode"=>'');
$icons['Default']['Pinterest'] = array("class"=>'Pinterest',"tags"=>'Pinterest',"unicode"=>'');
$icons['Default']['Plaxo'] = array("class"=>'Plaxo',"tags"=>'Plaxo',"unicode"=>'');
$icons['Default']['Plurk'] = array("class"=>'Plurk',"tags"=>'Plurk',"unicode"=>'');
$icons['Default']['Posterous'] = array("class"=>'Posterous',"tags"=>'Posterous',"unicode"=>'');
$icons['Default']['QIK'] = array("class"=>'QIK',"tags"=>'QIK',"unicode"=>'');
$icons['Default']['Reddit'] = array("class"=>'Reddit',"tags"=>'Reddit',"unicode"=>'');
$icons['Default']['Reverbnation'] = array("class"=>'Reverbnation',"tags"=>'Reverbnation',"unicode"=>'');
$icons['Default']['RSS'] = array("class"=>'RSS',"tags"=>'RSS',"unicode"=>'');
$icons['Default']['Sharethis'] = array("class"=>'Sharethis',"tags"=>'Sharethis',"unicode"=>'');
$icons['Default']['Shoutwire'] = array("class"=>'Shoutwire',"tags"=>'Shoutwire',"unicode"=>'');
$icons['Default']['Skype'] = array("class"=>'Skype',"tags"=>'Skype',"unicode"=>'');
$icons['Default']['Soundcloud'] = array("class"=>'Soundcloud',"tags"=>'Soundcloud',"unicode"=>'');
$icons['Default']['Spurl'] = array("class"=>'Spurl',"tags"=>'Spurl',"unicode"=>'');
$icons['Default']['Stumbleupon'] = array("class"=>'Stumbleupon',"tags"=>'Stumbleupon',"unicode"=>'');
$icons['Default']['Technorati'] = array("class"=>'Technorati',"tags"=>'Technorati',"unicode"=>'');
$icons['Default']['Tumblr'] = array("class"=>'Tumblr',"tags"=>'Tumblr',"unicode"=>'');
$icons['Default']['Twitter'] = array("class"=>'Twitter',"tags"=>'Twitter',"unicode"=>'');
$icons['Default']['Twitter-2'] = array("class"=>'Twitter-2',"tags"=>'Twitter-2',"unicode"=>'');
$icons['Default']['Unlike'] = array("class"=>'Unlike',"tags"=>'Unlike',"unicode"=>'');
$icons['Default']['Unlike-2'] = array("class"=>'Unlike-2',"tags"=>'Unlike-2',"unicode"=>'');
$icons['Default']['Ustream'] = array("class"=>'Ustream',"tags"=>'Ustream',"unicode"=>'');
$icons['Default']['Viddler'] = array("class"=>'Viddler',"tags"=>'Viddler',"unicode"=>'');
$icons['Default']['Vimeo'] = array("class"=>'Vimeo',"tags"=>'Vimeo',"unicode"=>'');
$icons['Default']['Wordpress'] = array("class"=>'Wordpress',"tags"=>'Wordpress',"unicode"=>'');
$icons['Default']['Xanga'] = array("class"=>'Xanga',"tags"=>'Xanga',"unicode"=>'');
$icons['Default']['Xing'] = array("class"=>'Xing',"tags"=>'Xing',"unicode"=>'');
$icons['Default']['Yahoo'] = array("class"=>'Yahoo',"tags"=>'Yahoo',"unicode"=>'');
$icons['Default']['Yahoo-Buzz'] = array("class"=>'Yahoo-Buzz',"tags"=>'Yahoo-Buzz',"unicode"=>'');
$icons['Default']['Yelp'] = array("class"=>'Yelp',"tags"=>'Yelp',"unicode"=>'');
$icons['Default']['Youtube'] = array("class"=>'Youtube',"tags"=>'Youtube',"unicode"=>'');
$icons['Default']['Bisexual'] = array("class"=>'Bisexual',"tags"=>'Bisexual',"unicode"=>'');
$icons['Default']['Cancer2'] = array("class"=>'Cancer2',"tags"=>'Cancer2',"unicode"=>'');
$icons['Default']['Couple-Sign'] = array("class"=>'Couple-Sign',"tags"=>'Couple-Sign',"unicode"=>'');
$icons['Default']['David-Star'] = array("class"=>'David-Star',"tags"=>'David-Star',"unicode"=>'');
$icons['Default']['Family-Sign'] = array("class"=>'Family-Sign',"tags"=>'Family-Sign',"unicode"=>'');
$icons['Default']['Female-2'] = array("class"=>'Female-2',"tags"=>'Female-2',"unicode"=>'');
$icons['Default']['Gey'] = array("class"=>'Gey',"tags"=>'Gey',"unicode"=>'');
$icons['Default']['Heart'] = array("class"=>'Heart',"tags"=>'Heart',"unicode"=>'');
$icons['Default']['Homosexual'] = array("class"=>'Homosexual',"tags"=>'Homosexual',"unicode"=>'');
$icons['Default']['Inifity'] = array("class"=>'Inifity',"tags"=>'Inifity',"unicode"=>'');
$icons['Default']['Lesbian'] = array("class"=>'Lesbian',"tags"=>'Lesbian',"unicode"=>'');
$icons['Default']['Lesbians'] = array("class"=>'Lesbians',"tags"=>'Lesbians',"unicode"=>'');
$icons['Default']['Love'] = array("class"=>'Love',"tags"=>'Love',"unicode"=>'');
$icons['Default']['Male-2'] = array("class"=>'Male-2',"tags"=>'Male-2',"unicode"=>'');
$icons['Default']['Men'] = array("class"=>'Men',"tags"=>'Men',"unicode"=>'');
$icons['Default']['No-Smoking'] = array("class"=>'No-Smoking',"tags"=>'No-Smoking',"unicode"=>'');
$icons['Default']['Paw'] = array("class"=>'Paw',"tags"=>'Paw',"unicode"=>'');
$icons['Default']['Quotes'] = array("class"=>'Quotes',"tags"=>'Quotes',"unicode"=>'');
$icons['Default']['Quotes-2'] = array("class"=>'Quotes-2',"tags"=>'Quotes-2',"unicode"=>'');
$icons['Default']['Redirect'] = array("class"=>'Redirect',"tags"=>'Redirect',"unicode"=>'');
$icons['Default']['Retweet'] = array("class"=>'Retweet',"tags"=>'Retweet',"unicode"=>'');
$icons['Default']['Ribbon-2'] = array("class"=>'Ribbon-2',"tags"=>'Ribbon-2',"unicode"=>'');
$icons['Default']['Smoking-Area'] = array("class"=>'Smoking-Area',"tags"=>'Smoking-Area',"unicode"=>'');
$icons['Default']['Venn-Diagram'] = array("class"=>'Venn-Diagram',"tags"=>'Venn-Diagram',"unicode"=>'');
$icons['Default']['Wheelchair'] = array("class"=>'Wheelchair',"tags"=>'Wheelchair',"unicode"=>'');
$icons['Default']['Women'] = array("class"=>'Women',"tags"=>'Women',"unicode"=>'');
$icons['Default']['Ying-Yang'] = array("class"=>'Ying-Yang',"tags"=>'Ying-Yang',"unicode"=>'');
$icons['Default']['Add-Bag'] = array("class"=>'Add-Bag',"tags"=>'Add-Bag',"unicode"=>'');
$icons['Default']['Add-Basket'] = array("class"=>'Add-Basket',"tags"=>'Add-Basket',"unicode"=>'');
$icons['Default']['Add-Cart'] = array("class"=>'Add-Cart',"tags"=>'Add-Cart',"unicode"=>'');
$icons['Default']['Bag-Coins'] = array("class"=>'Bag-Coins',"tags"=>'Bag-Coins',"unicode"=>'');
$icons['Default']['Bag-Items'] = array("class"=>'Bag-Items',"tags"=>'Bag-Items',"unicode"=>'');
$icons['Default']['Bag-Quantity'] = array("class"=>'Bag-Quantity',"tags"=>'Bag-Quantity',"unicode"=>'');
$icons['Default']['Bar-Code'] = array("class"=>'Bar-Code',"tags"=>'Bar-Code',"unicode"=>'');
$icons['Default']['Basket-Coins'] = array("class"=>'Basket-Coins',"tags"=>'Basket-Coins',"unicode"=>'');
$icons['Default']['Basket-Items'] = array("class"=>'Basket-Items',"tags"=>'Basket-Items',"unicode"=>'');
$icons['Default']['Basket-Quantity'] = array("class"=>'Basket-Quantity',"tags"=>'Basket-Quantity',"unicode"=>'');
$icons['Default']['Bitcoin'] = array("class"=>'Bitcoin',"tags"=>'Bitcoin',"unicode"=>'');
$icons['Default']['Car-Coins'] = array("class"=>'Car-Coins',"tags"=>'Car-Coins',"unicode"=>'');
$icons['Default']['Car-Items'] = array("class"=>'Car-Items',"tags"=>'Car-Items',"unicode"=>'');
$icons['Default']['CartQuantity'] = array("class"=>'CartQuantity',"tags"=>'CartQuantity',"unicode"=>'');
$icons['Default']['Cash-Register'] = array("class"=>'Cash-Register',"tags"=>'Cash-Register',"unicode"=>'');
$icons['Default']['Cash-register2'] = array("class"=>'Cash-register2',"tags"=>'Cash-register2',"unicode"=>'');
$icons['Default']['Checkout'] = array("class"=>'Checkout',"tags"=>'Checkout',"unicode"=>'');
$icons['Default']['Checkout-Bag'] = array("class"=>'Checkout-Bag',"tags"=>'Checkout-Bag',"unicode"=>'');
$icons['Default']['Checkout-Basket'] = array("class"=>'Checkout-Basket',"tags"=>'Checkout-Basket',"unicode"=>'');
$icons['Default']['Full-Basket'] = array("class"=>'Full-Basket',"tags"=>'Full-Basket',"unicode"=>'');
$icons['Default']['Full-Cart'] = array("class"=>'Full-Cart',"tags"=>'Full-Cart',"unicode"=>'');
$icons['Default']['Fyll-Bag'] = array("class"=>'Fyll-Bag',"tags"=>'Fyll-Bag',"unicode"=>'');
$icons['Default']['Home'] = array("class"=>'Home',"tags"=>'Home',"unicode"=>'');
$icons['Default']['Receipt-2'] = array("class"=>'Receipt-2',"tags"=>'Receipt-2',"unicode"=>'');
$icons['Default']['Receipt-3'] = array("class"=>'Receipt-3',"tags"=>'Receipt-3',"unicode"=>'');
$icons['Default']['Receipt-4'] = array("class"=>'Receipt-4',"tags"=>'Receipt-4',"unicode"=>'');
$icons['Default']['Remove-Bag'] = array("class"=>'Remove-Bag',"tags"=>'Remove-Bag',"unicode"=>'');
$icons['Default']['Remove-Basket'] = array("class"=>'Remove-Basket',"tags"=>'Remove-Basket',"unicode"=>'');
$icons['Default']['Remove-Cart'] = array("class"=>'Remove-Cart',"tags"=>'Remove-Cart',"unicode"=>'');
$icons['Default']['Shop'] = array("class"=>'Shop',"tags"=>'Shop',"unicode"=>'');
$icons['Default']['Shop-2'] = array("class"=>'Shop-2',"tags"=>'Shop-2',"unicode"=>'');
$icons['Default']['Shop-3'] = array("class"=>'Shop-3',"tags"=>'Shop-3',"unicode"=>'');
$icons['Default']['Shop-4'] = array("class"=>'Shop-4',"tags"=>'Shop-4',"unicode"=>'');
$icons['Default']['Shopping-Bag'] = array("class"=>'Shopping-Bag',"tags"=>'Shopping-Bag',"unicode"=>'');
$icons['Default']['Shopping-Basket'] = array("class"=>'Shopping-Basket',"tags"=>'Shopping-Basket',"unicode"=>'');
$icons['Default']['Shopping-Cart'] = array("class"=>'Shopping-Cart',"tags"=>'Shopping-Cart',"unicode"=>'');
$icons['Default']['Tag-2'] = array("class"=>'Tag-2',"tags"=>'Tag-2',"unicode"=>'');
$icons['Default']['Tag-3'] = array("class"=>'Tag-3',"tags"=>'Tag-3',"unicode"=>'');
$icons['Default']['Tag-4'] = array("class"=>'Tag-4',"tags"=>'Tag-4',"unicode"=>'');
$icons['Default']['Tag-5'] = array("class"=>'Tag-5',"tags"=>'Tag-5',"unicode"=>'');
$icons['Default']['This-SideUp'] = array("class"=>'This-SideUp',"tags"=>'This-SideUp',"unicode"=>'');
$icons['Default']['Broke-Link2'] = array("class"=>'Broke-Link2',"tags"=>'Broke-Link2',"unicode"=>'');
$icons['Default']['Coding'] = array("class"=>'Coding',"tags"=>'Coding',"unicode"=>'');
$icons['Default']['Consulting'] = array("class"=>'Consulting',"tags"=>'Consulting',"unicode"=>'');
$icons['Default']['Copyright'] = array("class"=>'Copyright',"tags"=>'Copyright',"unicode"=>'');
$icons['Default']['Idea-2'] = array("class"=>'Idea-2',"tags"=>'Idea-2',"unicode"=>'');
$icons['Default']['Idea-3'] = array("class"=>'Idea-3',"tags"=>'Idea-3',"unicode"=>'');
$icons['Default']['Idea-4'] = array("class"=>'Idea-4',"tags"=>'Idea-4',"unicode"=>'');
$icons['Default']['Internet'] = array("class"=>'Internet',"tags"=>'Internet',"unicode"=>'');
$icons['Default']['Link-2'] = array("class"=>'Link-2',"tags"=>'Link-2',"unicode"=>'');
$icons['Default']['Management'] = array("class"=>'Management',"tags"=>'Management',"unicode"=>'');
$icons['Default']['Monitor-Analytics'] = array("class"=>'Monitor-Analytics',"tags"=>'Monitor-Analytics',"unicode"=>'');
$icons['Default']['Optimization'] = array("class"=>'Optimization',"tags"=>'Optimization',"unicode"=>'');
$icons['Default']['Tag'] = array("class"=>'Tag',"tags"=>'Tag',"unicode"=>'');
$icons['Default']['Target'] = array("class"=>'Target',"tags"=>'Target',"unicode"=>'');
$icons['Default']['Target-Market'] = array("class"=>'Target-Market',"tags"=>'Target-Market',"unicode"=>'');
$icons['Default']['Testimonal'] = array("class"=>'Testimonal',"tags"=>'Testimonal',"unicode"=>'');
$icons['Default']['Computer-Secure'] = array("class"=>'Computer-Secure',"tags"=>'Computer-Secure',"unicode"=>'');
$icons['Default']['Eye-Scan'] = array("class"=>'Eye-Scan',"tags"=>'Eye-Scan',"unicode"=>'');
$icons['Default']['Finger-Print'] = array("class"=>'Finger-Print',"tags"=>'Finger-Print',"unicode"=>'');
$icons['Default']['Firewall'] = array("class"=>'Firewall',"tags"=>'Firewall',"unicode"=>'');
$icons['Default']['Key-Lock'] = array("class"=>'Key-Lock',"tags"=>'Key-Lock',"unicode"=>'');
$icons['Default']['Laptop-Secure'] = array("class"=>'Laptop-Secure',"tags"=>'Laptop-Secure',"unicode"=>'');
$icons['Default']['Layer-1532'] = array("class"=>'Layer-1532',"tags"=>'Layer-1532',"unicode"=>'');
$icons['Default']['Lock'] = array("class"=>'Lock',"tags"=>'Lock',"unicode"=>'');
$icons['Default']['Lock-2'] = array("class"=>'Lock-2',"tags"=>'Lock-2',"unicode"=>'');
$icons['Default']['Lock-3'] = array("class"=>'Lock-3',"tags"=>'Lock-3',"unicode"=>'');
$icons['Default']['Password-Field'] = array("class"=>'Password-Field',"tags"=>'Password-Field',"unicode"=>'');
$icons['Default']['Police'] = array("class"=>'Police',"tags"=>'Police',"unicode"=>'');
$icons['Default']['Safe-Box'] = array("class"=>'Safe-Box',"tags"=>'Safe-Box',"unicode"=>'');
$icons['Default']['Security-Block'] = array("class"=>'Security-Block',"tags"=>'Security-Block',"unicode"=>'');
$icons['Default']['Security-Check'] = array("class"=>'Security-Check',"tags"=>'Security-Check',"unicode"=>'');
$icons['Default']['Security-Settings'] = array("class"=>'Security-Settings',"tags"=>'Security-Settings',"unicode"=>'');
$icons['Default']['Securiy-Remove'] = array("class"=>'Securiy-Remove',"tags"=>'Securiy-Remove',"unicode"=>'');
$icons['Default']['Shield'] = array("class"=>'Shield',"tags"=>'Shield',"unicode"=>'');
$icons['Default']['Smartphone-Secure'] = array("class"=>'Smartphone-Secure',"tags"=>'Smartphone-Secure',"unicode"=>'');
$icons['Default']['SSL'] = array("class"=>'SSL',"tags"=>'SSL',"unicode"=>'');
$icons['Default']['Tablet-Secure'] = array("class"=>'Tablet-Secure',"tags"=>'Tablet-Secure',"unicode"=>'');
$icons['Default']['Unlock'] = array("class"=>'Unlock',"tags"=>'Unlock',"unicode"=>'');
$icons['Default']['Unlock-2'] = array("class"=>'Unlock-2',"tags"=>'Unlock-2',"unicode"=>'');
$icons['Default']['Unlock-3'] = array("class"=>'Unlock-3',"tags"=>'Unlock-3',"unicode"=>'');
$icons['Default']['Ambulance'] = array("class"=>'Ambulance',"tags"=>'Ambulance',"unicode"=>'');
$icons['Default']['Atom'] = array("class"=>'Atom',"tags"=>'Atom',"unicode"=>'');
$icons['Default']['Band-Aid'] = array("class"=>'Band-Aid',"tags"=>'Band-Aid',"unicode"=>'');
$icons['Default']['Bio-Hazard'] = array("class"=>'Bio-Hazard',"tags"=>'Bio-Hazard',"unicode"=>'');
$icons['Default']['Biotech'] = array("class"=>'Biotech',"tags"=>'Biotech',"unicode"=>'');
$icons['Default']['Chemical'] = array("class"=>'Chemical',"tags"=>'Chemical',"unicode"=>'');
$icons['Default']['Chemical-2'] = array("class"=>'Chemical-2',"tags"=>'Chemical-2',"unicode"=>'');
$icons['Default']['Chemical-3'] = array("class"=>'Chemical-3',"tags"=>'Chemical-3',"unicode"=>'');
$icons['Default']['Chemical-4'] = array("class"=>'Chemical-4',"tags"=>'Chemical-4',"unicode"=>'');
$icons['Default']['Chemical-5'] = array("class"=>'Chemical-5',"tags"=>'Chemical-5',"unicode"=>'');
$icons['Default']['Clinic'] = array("class"=>'Clinic',"tags"=>'Clinic',"unicode"=>'');
$icons['Default']['Cube-Molecule'] = array("class"=>'Cube-Molecule',"tags"=>'Cube-Molecule',"unicode"=>'');
$icons['Default']['Cube-Molecule2'] = array("class"=>'Cube-Molecule2',"tags"=>'Cube-Molecule2',"unicode"=>'');
$icons['Default']['Danger'] = array("class"=>'Danger',"tags"=>'Danger',"unicode"=>'');
$icons['Default']['DNA'] = array("class"=>'DNA',"tags"=>'DNA',"unicode"=>'');
$icons['Default']['DNA-2'] = array("class"=>'DNA-2',"tags"=>'DNA-2',"unicode"=>'');
$icons['Default']['DNA-Helix'] = array("class"=>'DNA-Helix',"tags"=>'DNA-Helix',"unicode"=>'');
$icons['Default']['First-Aid'] = array("class"=>'First-Aid',"tags"=>'First-Aid',"unicode"=>'');
$icons['Default']['Flask'] = array("class"=>'Flask',"tags"=>'Flask',"unicode"=>'');
$icons['Default']['Flask-2'] = array("class"=>'Flask-2',"tags"=>'Flask-2',"unicode"=>'');
$icons['Default']['Helix-2'] = array("class"=>'Helix-2',"tags"=>'Helix-2',"unicode"=>'');
$icons['Default']['Microscope'] = array("class"=>'Microscope',"tags"=>'Microscope',"unicode"=>'');
$icons['Default']['Neutron'] = array("class"=>'Neutron',"tags"=>'Neutron',"unicode"=>'');
$icons['Default']['Plasmid'] = array("class"=>'Plasmid',"tags"=>'Plasmid',"unicode"=>'');
$icons['Default']['Pulse'] = array("class"=>'Pulse',"tags"=>'Pulse',"unicode"=>'');
$icons['Default']['Radioactive'] = array("class"=>'Radioactive',"tags"=>'Radioactive',"unicode"=>'');
$icons['Default']['Temperature2'] = array("class"=>'Temperature2',"tags"=>'Temperature2',"unicode"=>'');
$icons['Default']['Test-Tube2'] = array("class"=>'Test-Tube2',"tags"=>'Test-Tube2',"unicode"=>'');
$icons['Default']['Virus'] = array("class"=>'Virus',"tags"=>'Virus',"unicode"=>'');
$icons['Default']['X-ray'] = array("class"=>'X-ray',"tags"=>'X-ray',"unicode"=>'');
$icons['Default']['Auto-Flash'] = array("class"=>'Auto-Flash',"tags"=>'Auto-Flash',"unicode"=>'');
$icons['Default']['Camera'] = array("class"=>'Camera',"tags"=>'Camera',"unicode"=>'');
$icons['Default']['Camera-2'] = array("class"=>'Camera-2',"tags"=>'Camera-2',"unicode"=>'');
$icons['Default']['Camera-3'] = array("class"=>'Camera-3',"tags"=>'Camera-3',"unicode"=>'');
$icons['Default']['Camera-4'] = array("class"=>'Camera-4',"tags"=>'Camera-4',"unicode"=>'');
$icons['Default']['Camera-5'] = array("class"=>'Camera-5',"tags"=>'Camera-5',"unicode"=>'');
$icons['Default']['Camera-Back'] = array("class"=>'Camera-Back',"tags"=>'Camera-Back',"unicode"=>'');
$icons['Default']['Crop'] = array("class"=>'Crop',"tags"=>'Crop',"unicode"=>'');
$icons['Default']['Daylight'] = array("class"=>'Daylight',"tags"=>'Daylight',"unicode"=>'');
$icons['Default']['Edit'] = array("class"=>'Edit',"tags"=>'Edit',"unicode"=>'');
$icons['Default']['Eye'] = array("class"=>'Eye',"tags"=>'Eye',"unicode"=>'');
$icons['Default']['Film2'] = array("class"=>'Film2',"tags"=>'Film2',"unicode"=>'');
$icons['Default']['Film-Cartridge'] = array("class"=>'Film-Cartridge',"tags"=>'Film-Cartridge',"unicode"=>'');
$icons['Default']['Filter'] = array("class"=>'Filter',"tags"=>'Filter',"unicode"=>'');
$icons['Default']['Flash'] = array("class"=>'Flash',"tags"=>'Flash',"unicode"=>'');
$icons['Default']['Flash-2'] = array("class"=>'Flash-2',"tags"=>'Flash-2',"unicode"=>'');
$icons['Default']['Fluorescent'] = array("class"=>'Fluorescent',"tags"=>'Fluorescent',"unicode"=>'');
$icons['Default']['Gopro'] = array("class"=>'Gopro',"tags"=>'Gopro',"unicode"=>'');
$icons['Default']['Landscape'] = array("class"=>'Landscape',"tags"=>'Landscape',"unicode"=>'');
$icons['Default']['Len'] = array("class"=>'Len',"tags"=>'Len',"unicode"=>'');
$icons['Default']['Len-2'] = array("class"=>'Len-2',"tags"=>'Len-2',"unicode"=>'');
$icons['Default']['Len-3'] = array("class"=>'Len-3',"tags"=>'Len-3',"unicode"=>'');
$icons['Default']['Macro'] = array("class"=>'Macro',"tags"=>'Macro',"unicode"=>'');
$icons['Default']['Memory-Card'] = array("class"=>'Memory-Card',"tags"=>'Memory-Card',"unicode"=>'');
$icons['Default']['Memory-Card2'] = array("class"=>'Memory-Card2',"tags"=>'Memory-Card2',"unicode"=>'');
$icons['Default']['Memory-Card3'] = array("class"=>'Memory-Card3',"tags"=>'Memory-Card3',"unicode"=>'');
$icons['Default']['No-Flash'] = array("class"=>'No-Flash',"tags"=>'No-Flash',"unicode"=>'');
$icons['Default']['Panorama'] = array("class"=>'Panorama',"tags"=>'Panorama',"unicode"=>'');
$icons['Default']['Photo'] = array("class"=>'Photo',"tags"=>'Photo',"unicode"=>'');
$icons['Default']['Photo-2'] = array("class"=>'Photo-2',"tags"=>'Photo-2',"unicode"=>'');
$icons['Default']['Photo-3'] = array("class"=>'Photo-3',"tags"=>'Photo-3',"unicode"=>'');
$icons['Default']['Photo-Album'] = array("class"=>'Photo-Album',"tags"=>'Photo-Album',"unicode"=>'');
$icons['Default']['Photo-Album2'] = array("class"=>'Photo-Album2',"tags"=>'Photo-Album2',"unicode"=>'');
$icons['Default']['Photo-Album3'] = array("class"=>'Photo-Album3',"tags"=>'Photo-Album3',"unicode"=>'');
$icons['Default']['Photos'] = array("class"=>'Photos',"tags"=>'Photos',"unicode"=>'');
$icons['Default']['Portrait'] = array("class"=>'Portrait',"tags"=>'Portrait',"unicode"=>'');
$icons['Default']['Retouching'] = array("class"=>'Retouching',"tags"=>'Retouching',"unicode"=>'');
$icons['Default']['Retro-Camera'] = array("class"=>'Retro-Camera',"tags"=>'Retro-Camera',"unicode"=>'');
$icons['Default']['secound'] = array("class"=>'secound',"tags"=>'secound',"unicode"=>'');
$icons['Default']['secound2'] = array("class"=>'secound2',"tags"=>'secound2',"unicode"=>'');
$icons['Default']['Shutter'] = array("class"=>'Shutter',"tags"=>'Shutter',"unicode"=>'');
$icons['Default']['Signal'] = array("class"=>'Signal',"tags"=>'Signal',"unicode"=>'');
$icons['Default']['Snow2'] = array("class"=>'Snow2',"tags"=>'Snow2',"unicode"=>'');
$icons['Default']['Timer2'] = array("class"=>'Timer2',"tags"=>'Timer2',"unicode"=>'');
$icons['Default']['Tripod-withCamera'] = array("class"=>'Tripod-withCamera',"tags"=>'Tripod-withCamera',"unicode"=>'');
$icons['Default']['Tripod-withGopro'] = array("class"=>'Tripod-withGopro',"tags"=>'Tripod-withGopro',"unicode"=>'');
$icons['Default']['Add-User'] = array("class"=>'Add-User',"tags"=>'Add-User',"unicode"=>'');
$icons['Default']['Add-UserStar'] = array("class"=>'Add-UserStar',"tags"=>'Add-UserStar',"unicode"=>'');
$icons['Default']['Administrator'] = array("class"=>'Administrator',"tags"=>'Administrator',"unicode"=>'');
$icons['Default']['Assistant'] = array("class"=>'Assistant',"tags"=>'Assistant',"unicode"=>'');
$icons['Default']['Boy'] = array("class"=>'Boy',"tags"=>'Boy',"unicode"=>'');
$icons['Default']['Business-Man'] = array("class"=>'Business-Man',"tags"=>'Business-Man',"unicode"=>'');
$icons['Default']['Business-ManWoman'] = array("class"=>'Business-ManWoman',"tags"=>'Business-ManWoman',"unicode"=>'');
$icons['Default']['Business-Mens'] = array("class"=>'Business-Mens',"tags"=>'Business-Mens',"unicode"=>'');
$icons['Default']['Business-Woman'] = array("class"=>'Business-Woman',"tags"=>'Business-Woman',"unicode"=>'');
$icons['Default']['Checked-User'] = array("class"=>'Checked-User',"tags"=>'Checked-User',"unicode"=>'');
$icons['Default']['Chef'] = array("class"=>'Chef',"tags"=>'Chef',"unicode"=>'');
$icons['Default']['Conference'] = array("class"=>'Conference',"tags"=>'Conference',"unicode"=>'');
$icons['Default']['Cool-Guy'] = array("class"=>'Cool-Guy',"tags"=>'Cool-Guy',"unicode"=>'');
$icons['Default']['Dj'] = array("class"=>'Dj',"tags"=>'Dj',"unicode"=>'');
$icons['Default']['Doctor'] = array("class"=>'Doctor',"tags"=>'Doctor',"unicode"=>'');
$icons['Default']['Engineering'] = array("class"=>'Engineering',"tags"=>'Engineering',"unicode"=>'');
$icons['Default']['Female'] = array("class"=>'Female',"tags"=>'Female',"unicode"=>'');
$icons['Default']['Female-22'] = array("class"=>'Female-22',"tags"=>'Female-22',"unicode"=>'');
$icons['Default']['Find-User'] = array("class"=>'Find-User',"tags"=>'Find-User',"unicode"=>'');
$icons['Default']['Geek'] = array("class"=>'Geek',"tags"=>'Geek',"unicode"=>'');
$icons['Default']['Genius'] = array("class"=>'Genius',"tags"=>'Genius',"unicode"=>'');
$icons['Default']['Girl'] = array("class"=>'Girl',"tags"=>'Girl',"unicode"=>'');
$icons['Default']['Headphone'] = array("class"=>'Headphone',"tags"=>'Headphone',"unicode"=>'');
$icons['Default']['Headset'] = array("class"=>'Headset',"tags"=>'Headset',"unicode"=>'');
$icons['Default']['ID-2'] = array("class"=>'ID-2',"tags"=>'ID-2',"unicode"=>'');
$icons['Default']['ID-3'] = array("class"=>'ID-3',"tags"=>'ID-3',"unicode"=>'');
$icons['Default']['ID-Card'] = array("class"=>'ID-Card',"tags"=>'ID-Card',"unicode"=>'');
$icons['Default']['Lock-User'] = array("class"=>'Lock-User',"tags"=>'Lock-User',"unicode"=>'');
$icons['Default']['Love-User'] = array("class"=>'Love-User',"tags"=>'Love-User',"unicode"=>'');
$icons['Default']['Male'] = array("class"=>'Male',"tags"=>'Male',"unicode"=>'');
$icons['Default']['Male-22'] = array("class"=>'Male-22',"tags"=>'Male-22',"unicode"=>'');
$icons['Default']['MaleFemale'] = array("class"=>'MaleFemale',"tags"=>'MaleFemale',"unicode"=>'');
$icons['Default']['Man-Sign'] = array("class"=>'Man-Sign',"tags"=>'Man-Sign',"unicode"=>'');
$icons['Default']['Professor'] = array("class"=>'Professor',"tags"=>'Professor',"unicode"=>'');
$icons['Default']['Punker'] = array("class"=>'Punker',"tags"=>'Punker',"unicode"=>'');
$icons['Default']['Queen-2'] = array("class"=>'Queen-2',"tags"=>'Queen-2',"unicode"=>'');
$icons['Default']['Remove-User'] = array("class"=>'Remove-User',"tags"=>'Remove-User',"unicode"=>'');
$icons['Default']['Spy'] = array("class"=>'Spy',"tags"=>'Spy',"unicode"=>'');
$icons['Default']['Student-Female'] = array("class"=>'Student-Female',"tags"=>'Student-Female',"unicode"=>'');
$icons['Default']['Student-Male'] = array("class"=>'Student-Male',"tags"=>'Student-Male',"unicode"=>'');
$icons['Default']['Student-MaleFemale'] = array("class"=>'Student-MaleFemale',"tags"=>'Student-MaleFemale',"unicode"=>'');
$icons['Default']['Students'] = array("class"=>'Students',"tags"=>'Students',"unicode"=>'');
$icons['Default']['Superman'] = array("class"=>'Superman',"tags"=>'Superman',"unicode"=>'');
$icons['Default']['Talk-Man'] = array("class"=>'Talk-Man',"tags"=>'Talk-Man',"unicode"=>'');
$icons['Default']['Teacher'] = array("class"=>'Teacher',"tags"=>'Teacher',"unicode"=>'');
$icons['Default']['WomanMan'] = array("class"=>'WomanMan',"tags"=>'WomanMan',"unicode"=>'');
$icons['Default']['Woman-Sign'] = array("class"=>'Woman-Sign',"tags"=>'Woman-Sign',"unicode"=>'');
$icons['Default']['Wonder-Woman'] = array("class"=>'Wonder-Woman',"tags"=>'Wonder-Woman',"unicode"=>'');
$icons['Default']['Worker'] = array("class"=>'Worker',"tags"=>'Worker',"unicode"=>'');
$icons['Default']['Barricade'] = array("class"=>'Barricade',"tags"=>'Barricade',"unicode"=>'');
$icons['Default']['Chair'] = array("class"=>'Chair',"tags"=>'Chair',"unicode"=>'');
$icons['Default']['Coffee-Machine'] = array("class"=>'Coffee-Machine',"tags"=>'Coffee-Machine',"unicode"=>'');
$icons['Default']['Door-Hanger'] = array("class"=>'Door-Hanger',"tags"=>'Door-Hanger',"unicode"=>'');
$icons['Default']['Drill'] = array("class"=>'Drill',"tags"=>'Drill',"unicode"=>'');
$icons['Default']['Feather'] = array("class"=>'Feather',"tags"=>'Feather',"unicode"=>'');
$icons['Default']['Flag'] = array("class"=>'Flag',"tags"=>'Flag',"unicode"=>'');
$icons['Default']['Flag-2'] = array("class"=>'Flag-2',"tags"=>'Flag-2',"unicode"=>'');
$icons['Default']['Footprint2'] = array("class"=>'Footprint2',"tags"=>'Footprint2',"unicode"=>'');
$icons['Default']['Gas-Pump'] = array("class"=>'Gas-Pump',"tags"=>'Gas-Pump',"unicode"=>'');
$icons['Default']['Gift-Box'] = array("class"=>'Gift-Box',"tags"=>'Gift-Box',"unicode"=>'');
$icons['Default']['Identification-Badge'] = array("class"=>'Identification-Badge',"tags"=>'Identification-Badge',"unicode"=>'');
$icons['Default']['Key'] = array("class"=>'Key',"tags"=>'Key',"unicode"=>'');
$icons['Default']['Key-2'] = array("class"=>'Key-2',"tags"=>'Key-2',"unicode"=>'');
$icons['Default']['Lego'] = array("class"=>'Lego',"tags"=>'Lego',"unicode"=>'');
$icons['Default']['Life-Safer'] = array("class"=>'Life-Safer',"tags"=>'Life-Safer',"unicode"=>'');
$icons['Default']['Light-Bulb'] = array("class"=>'Light-Bulb',"tags"=>'Light-Bulb',"unicode"=>'');
$icons['Default']['Light-Bulb2'] = array("class"=>'Light-Bulb2',"tags"=>'Light-Bulb2',"unicode"=>'');
$icons['Default']['Luggafe-Front'] = array("class"=>'Luggafe-Front',"tags"=>'Luggafe-Front',"unicode"=>'');
$icons['Default']['Luggage-2'] = array("class"=>'Luggage-2',"tags"=>'Luggage-2',"unicode"=>'');
$icons['Default']['Magic-Wand'] = array("class"=>'Magic-Wand',"tags"=>'Magic-Wand',"unicode"=>'');
$icons['Default']['Magnet'] = array("class"=>'Magnet',"tags"=>'Magnet',"unicode"=>'');
$icons['Default']['Mirror'] = array("class"=>'Mirror',"tags"=>'Mirror',"unicode"=>'');
$icons['Default']['Movie-Ticket'] = array("class"=>'Movie-Ticket',"tags"=>'Movie-Ticket',"unicode"=>'');
$icons['Default']['Office-Lamp'] = array("class"=>'Office-Lamp',"tags"=>'Office-Lamp',"unicode"=>'');
$icons['Default']['Paint-Brush'] = array("class"=>'Paint-Brush',"tags"=>'Paint-Brush',"unicode"=>'');
$icons['Default']['Paint-Bucket'] = array("class"=>'Paint-Bucket',"tags"=>'Paint-Bucket',"unicode"=>'');
$icons['Default']['Paper-Plane'] = array("class"=>'Paper-Plane',"tags"=>'Paper-Plane',"unicode"=>'');
$icons['Default']['Post-Sign'] = array("class"=>'Post-Sign',"tags"=>'Post-Sign',"unicode"=>'');
$icons['Default']['Post-Sign2ways'] = array("class"=>'Post-Sign2ways',"tags"=>'Post-Sign2ways',"unicode"=>'');
$icons['Default']['Puzzle'] = array("class"=>'Puzzle',"tags"=>'Puzzle',"unicode"=>'');
$icons['Default']['Razzor-Blade'] = array("class"=>'Razzor-Blade',"tags"=>'Razzor-Blade',"unicode"=>'');
$icons['Default']['Scale'] = array("class"=>'Scale',"tags"=>'Scale',"unicode"=>'');
$icons['Default']['Screwdriver'] = array("class"=>'Screwdriver',"tags"=>'Screwdriver',"unicode"=>'');
$icons['Default']['Sewing-Machine'] = array("class"=>'Sewing-Machine',"tags"=>'Sewing-Machine',"unicode"=>'');
$icons['Default']['Stroller'] = array("class"=>'Stroller',"tags"=>'Stroller',"unicode"=>'');
$icons['Default']['Suitcase'] = array("class"=>'Suitcase',"tags"=>'Suitcase',"unicode"=>'');
$icons['Default']['Telescope'] = array("class"=>'Telescope',"tags"=>'Telescope',"unicode"=>'');
$icons['Default']['Thread'] = array("class"=>'Thread',"tags"=>'Thread',"unicode"=>'');
$icons['Default']['Ticket'] = array("class"=>'Ticket',"tags"=>'Ticket',"unicode"=>'');
$icons['Default']['Time-Bomb'] = array("class"=>'Time-Bomb',"tags"=>'Time-Bomb',"unicode"=>'');
$icons['Default']['Tourch'] = array("class"=>'Tourch',"tags"=>'Tourch',"unicode"=>'');
$icons['Default']['Vase'] = array("class"=>'Vase',"tags"=>'Vase',"unicode"=>'');
$icons['Default']['Conservation'] = array("class"=>'Conservation',"tags"=>'Conservation',"unicode"=>'');
$icons['Default']['Environmental'] = array("class"=>'Environmental',"tags"=>'Environmental',"unicode"=>'');
$icons['Default']['Environmental-2'] = array("class"=>'Environmental-2',"tags"=>'Environmental-2',"unicode"=>'');
$icons['Default']['Environmental-3'] = array("class"=>'Environmental-3',"tags"=>'Environmental-3',"unicode"=>'');
$icons['Default']['Fire-Flame'] = array("class"=>'Fire-Flame',"tags"=>'Fire-Flame',"unicode"=>'');
$icons['Default']['Fire-Flame2'] = array("class"=>'Fire-Flame2',"tags"=>'Fire-Flame2',"unicode"=>'');
$icons['Default']['Forest'] = array("class"=>'Forest',"tags"=>'Forest',"unicode"=>'');
$icons['Default']['Green-House'] = array("class"=>'Green-House',"tags"=>'Green-House',"unicode"=>'');
$icons['Default']['Leafs'] = array("class"=>'Leafs',"tags"=>'Leafs',"unicode"=>'');
$icons['Default']['Leafs-2'] = array("class"=>'Leafs-2',"tags"=>'Leafs-2',"unicode"=>'');
$icons['Default']['Light-BulbLeaf'] = array("class"=>'Light-BulbLeaf',"tags"=>'Light-BulbLeaf',"unicode"=>'');
$icons['Default']['Palm-Tree'] = array("class"=>'Palm-Tree',"tags"=>'Palm-Tree',"unicode"=>'');
$icons['Default']['Plant'] = array("class"=>'Plant',"tags"=>'Plant',"unicode"=>'');
$icons['Default']['Recycling'] = array("class"=>'Recycling',"tags"=>'Recycling',"unicode"=>'');
$icons['Default']['Recycling-2'] = array("class"=>'Recycling-2',"tags"=>'Recycling-2',"unicode"=>'');
$icons['Default']['Seed'] = array("class"=>'Seed',"tags"=>'Seed',"unicode"=>'');
$icons['Default']['Trash-withMen'] = array("class"=>'Trash-withMen',"tags"=>'Trash-withMen',"unicode"=>'');
$icons['Default']['Tree'] = array("class"=>'Tree',"tags"=>'Tree',"unicode"=>'');
$icons['Default']['Tree-2'] = array("class"=>'Tree-2',"tags"=>'Tree-2',"unicode"=>'');
$icons['Default']['Tree-3'] = array("class"=>'Tree-3',"tags"=>'Tree-3',"unicode"=>'');
$icons['Default']['Audio'] = array("class"=>'Audio',"tags"=>'Audio',"unicode"=>'');
$icons['Default']['Back-Music'] = array("class"=>'Back-Music',"tags"=>'Back-Music',"unicode"=>'');
$icons['Default']['Bell'] = array("class"=>'Bell',"tags"=>'Bell',"unicode"=>'');
$icons['Default']['Casette-Tape'] = array("class"=>'Casette-Tape',"tags"=>'Casette-Tape',"unicode"=>'');
$icons['Default']['CD-2'] = array("class"=>'CD-2',"tags"=>'CD-2',"unicode"=>'');
$icons['Default']['CD-Cover'] = array("class"=>'CD-Cover',"tags"=>'CD-Cover',"unicode"=>'');
$icons['Default']['Clef'] = array("class"=>'Clef',"tags"=>'Clef',"unicode"=>'');
$icons['Default']['Drum'] = array("class"=>'Drum',"tags"=>'Drum',"unicode"=>'');
$icons['Default']['Electric-Guitar'] = array("class"=>'Electric-Guitar',"tags"=>'Electric-Guitar',"unicode"=>'');
$icons['Default']['Equalizer'] = array("class"=>'Equalizer',"tags"=>'Equalizer',"unicode"=>'');
$icons['Default']['First'] = array("class"=>'First',"tags"=>'First',"unicode"=>'');
$icons['Default']['Headphones'] = array("class"=>'Headphones',"tags"=>'Headphones',"unicode"=>'');
$icons['Default']['Keyboard3'] = array("class"=>'Keyboard3',"tags"=>'Keyboard3',"unicode"=>'');
$icons['Default']['Last'] = array("class"=>'Last',"tags"=>'Last',"unicode"=>'');
$icons['Default']['Loud'] = array("class"=>'Loud',"tags"=>'Loud',"unicode"=>'');
$icons['Default']['Loudspeaker'] = array("class"=>'Loudspeaker',"tags"=>'Loudspeaker',"unicode"=>'');
$icons['Default']['Mic'] = array("class"=>'Mic',"tags"=>'Mic',"unicode"=>'');
$icons['Default']['Microphone'] = array("class"=>'Microphone',"tags"=>'Microphone',"unicode"=>'');
$icons['Default']['Microphone-2'] = array("class"=>'Microphone-2',"tags"=>'Microphone-2',"unicode"=>'');
$icons['Default']['Microphone-4'] = array("class"=>'Microphone-4',"tags"=>'Microphone-4',"unicode"=>'');
$icons['Default']['Microphone-5'] = array("class"=>'Microphone-5',"tags"=>'Microphone-5',"unicode"=>'');
$icons['Default']['Microphone-6'] = array("class"=>'Microphone-6',"tags"=>'Microphone-6',"unicode"=>'');
$icons['Default']['Microphone-7'] = array("class"=>'Microphone-7',"tags"=>'Microphone-7',"unicode"=>'');
$icons['Default']['Mixer'] = array("class"=>'Mixer',"tags"=>'Mixer',"unicode"=>'');
$icons['Default']['Mp3-File'] = array("class"=>'Mp3-File',"tags"=>'Mp3-File',"unicode"=>'');
$icons['Default']['Music-Note'] = array("class"=>'Music-Note',"tags"=>'Music-Note',"unicode"=>'');
$icons['Default']['Music-Note2'] = array("class"=>'Music-Note2',"tags"=>'Music-Note2',"unicode"=>'');
$icons['Default']['Music-Note3'] = array("class"=>'Music-Note3',"tags"=>'Music-Note3',"unicode"=>'');
$icons['Default']['Music-Note4'] = array("class"=>'Music-Note4',"tags"=>'Music-Note4',"unicode"=>'');
$icons['Default']['Music-Player'] = array("class"=>'Music-Player',"tags"=>'Music-Player',"unicode"=>'');
$icons['Default']['Mute'] = array("class"=>'Mute',"tags"=>'Mute',"unicode"=>'');
$icons['Default']['Next-Music'] = array("class"=>'Next-Music',"tags"=>'Next-Music',"unicode"=>'');
$icons['Default']['Old-Radio'] = array("class"=>'Old-Radio',"tags"=>'Old-Radio',"unicode"=>'');
$icons['Default']['Piano'] = array("class"=>'Piano',"tags"=>'Piano',"unicode"=>'');
$icons['Default']['Play-Music'] = array("class"=>'Play-Music',"tags"=>'Play-Music',"unicode"=>'');
$icons['Default']['Radio'] = array("class"=>'Radio',"tags"=>'Radio',"unicode"=>'');
$icons['Default']['Record'] = array("class"=>'Record',"tags"=>'Record',"unicode"=>'');
$icons['Default']['Record-Music'] = array("class"=>'Record-Music',"tags"=>'Record-Music',"unicode"=>'');
$icons['Default']['Sound'] = array("class"=>'Sound',"tags"=>'Sound',"unicode"=>'');
$icons['Default']['Sound-Wave'] = array("class"=>'Sound-Wave',"tags"=>'Sound-Wave',"unicode"=>'');
$icons['Default']['Speaker'] = array("class"=>'Speaker',"tags"=>'Speaker',"unicode"=>'');
$icons['Default']['Stop-Music'] = array("class"=>'Stop-Music',"tags"=>'Stop-Music',"unicode"=>'');
$icons['Default']['Trumpet'] = array("class"=>'Trumpet',"tags"=>'Trumpet',"unicode"=>'');
$icons['Default']['Voice'] = array("class"=>'Voice',"tags"=>'Voice',"unicode"=>'');
$icons['Default']['Volume-Down'] = array("class"=>'Volume-Down',"tags"=>'Volume-Down',"unicode"=>'');
$icons['Default']['Volume-Up'] = array("class"=>'Volume-Up',"tags"=>'Volume-Up',"unicode"=>'');
$icons['Default']['Back'] = array("class"=>'Back',"tags"=>'Back',"unicode"=>'');
$icons['Default']['Back-2'] = array("class"=>'Back-2',"tags"=>'Back-2',"unicode"=>'');
$icons['Default']['Eject'] = array("class"=>'Eject',"tags"=>'Eject',"unicode"=>'');
$icons['Default']['Eject-2'] = array("class"=>'Eject-2',"tags"=>'Eject-2',"unicode"=>'');
$icons['Default']['End'] = array("class"=>'End',"tags"=>'End',"unicode"=>'');
$icons['Default']['End-2'] = array("class"=>'End-2',"tags"=>'End-2',"unicode"=>'');
$icons['Default']['Next'] = array("class"=>'Next',"tags"=>'Next',"unicode"=>'');
$icons['Default']['Next-2'] = array("class"=>'Next-2',"tags"=>'Next-2',"unicode"=>'');
$icons['Default']['Pause'] = array("class"=>'Pause',"tags"=>'Pause',"unicode"=>'');
$icons['Default']['Pause-2'] = array("class"=>'Pause-2',"tags"=>'Pause-2',"unicode"=>'');
$icons['Default']['Power-2'] = array("class"=>'Power-2',"tags"=>'Power-2',"unicode"=>'');
$icons['Default']['Power-3'] = array("class"=>'Power-3',"tags"=>'Power-3',"unicode"=>'');
$icons['Default']['Record2'] = array("class"=>'Record2',"tags"=>'Record2',"unicode"=>'');
$icons['Default']['Record-2'] = array("class"=>'Record-2',"tags"=>'Record-2',"unicode"=>'');
$icons['Default']['Repeat'] = array("class"=>'Repeat',"tags"=>'Repeat',"unicode"=>'');
$icons['Default']['Repeat-2'] = array("class"=>'Repeat-2',"tags"=>'Repeat-2',"unicode"=>'');
$icons['Default']['Shuffle'] = array("class"=>'Shuffle',"tags"=>'Shuffle',"unicode"=>'');
$icons['Default']['Shuffle-2'] = array("class"=>'Shuffle-2',"tags"=>'Shuffle-2',"unicode"=>'');
$icons['Default']['Start'] = array("class"=>'Start',"tags"=>'Start',"unicode"=>'');
$icons['Default']['Start-2'] = array("class"=>'Start-2',"tags"=>'Start-2',"unicode"=>'');
$icons['Default']['Stop'] = array("class"=>'Stop',"tags"=>'Stop',"unicode"=>'');
$icons['Default']['Stop-2'] = array("class"=>'Stop-2',"tags"=>'Stop-2',"unicode"=>'');
$icons['Default']['Compass'] = array("class"=>'Compass',"tags"=>'Compass',"unicode"=>'');
$icons['Default']['Compass-2'] = array("class"=>'Compass-2',"tags"=>'Compass-2',"unicode"=>'');
$icons['Default']['Compass-Rose'] = array("class"=>'Compass-Rose',"tags"=>'Compass-Rose',"unicode"=>'');
$icons['Default']['Direction-East'] = array("class"=>'Direction-East',"tags"=>'Direction-East',"unicode"=>'');
$icons['Default']['Direction-North'] = array("class"=>'Direction-North',"tags"=>'Direction-North',"unicode"=>'');
$icons['Default']['Direction-South'] = array("class"=>'Direction-South',"tags"=>'Direction-South',"unicode"=>'');
$icons['Default']['Direction-West'] = array("class"=>'Direction-West',"tags"=>'Direction-West',"unicode"=>'');
$icons['Default']['Edit-Map'] = array("class"=>'Edit-Map',"tags"=>'Edit-Map',"unicode"=>'');
$icons['Default']['Geo'] = array("class"=>'Geo',"tags"=>'Geo',"unicode"=>'');
$icons['Default']['Geo2'] = array("class"=>'Geo2',"tags"=>'Geo2',"unicode"=>'');
$icons['Default']['Geo3'] = array("class"=>'Geo3',"tags"=>'Geo3',"unicode"=>'');
$icons['Default']['Geo22'] = array("class"=>'Geo22',"tags"=>'Geo22',"unicode"=>'');
$icons['Default']['Geo23'] = array("class"=>'Geo23',"tags"=>'Geo23',"unicode"=>'');
$icons['Default']['Geo24'] = array("class"=>'Geo24',"tags"=>'Geo24',"unicode"=>'');
$icons['Default']['Geo2-Close'] = array("class"=>'Geo2-Close',"tags"=>'Geo2-Close',"unicode"=>'');
$icons['Default']['Geo2-Love'] = array("class"=>'Geo2-Love',"tags"=>'Geo2-Love',"unicode"=>'');
$icons['Default']['Geo2-Number'] = array("class"=>'Geo2-Number',"tags"=>'Geo2-Number',"unicode"=>'');
$icons['Default']['Geo2-Star'] = array("class"=>'Geo2-Star',"tags"=>'Geo2-Star',"unicode"=>'');
$icons['Default']['Geo32'] = array("class"=>'Geo32',"tags"=>'Geo32',"unicode"=>'');
$icons['Default']['Geo33'] = array("class"=>'Geo33',"tags"=>'Geo33',"unicode"=>'');
$icons['Default']['Geo34'] = array("class"=>'Geo34',"tags"=>'Geo34',"unicode"=>'');
$icons['Default']['Geo3-Close'] = array("class"=>'Geo3-Close',"tags"=>'Geo3-Close',"unicode"=>'');
$icons['Default']['Geo3-Love'] = array("class"=>'Geo3-Love',"tags"=>'Geo3-Love',"unicode"=>'');
$icons['Default']['Geo3-Number'] = array("class"=>'Geo3-Number',"tags"=>'Geo3-Number',"unicode"=>'');
$icons['Default']['Geo3-Star'] = array("class"=>'Geo3-Star',"tags"=>'Geo3-Star',"unicode"=>'');
$icons['Default']['Geo-Close'] = array("class"=>'Geo-Close',"tags"=>'Geo-Close',"unicode"=>'');
$icons['Default']['Geo-Love'] = array("class"=>'Geo-Love',"tags"=>'Geo-Love',"unicode"=>'');
$icons['Default']['Geo-Number'] = array("class"=>'Geo-Number',"tags"=>'Geo-Number',"unicode"=>'');
$icons['Default']['Geo-Star'] = array("class"=>'Geo-Star',"tags"=>'Geo-Star',"unicode"=>'');
$icons['Default']['Global-Position'] = array("class"=>'Global-Position',"tags"=>'Global-Position',"unicode"=>'');
$icons['Default']['Globe'] = array("class"=>'Globe',"tags"=>'Globe',"unicode"=>'');
$icons['Default']['Globe-2'] = array("class"=>'Globe-2',"tags"=>'Globe-2',"unicode"=>'');
$icons['Default']['Location'] = array("class"=>'Location',"tags"=>'Location',"unicode"=>'');
$icons['Default']['Location-2'] = array("class"=>'Location-2',"tags"=>'Location-2',"unicode"=>'');
$icons['Default']['Map'] = array("class"=>'Map',"tags"=>'Map',"unicode"=>'');
$icons['Default']['Map2'] = array("class"=>'Map2',"tags"=>'Map2',"unicode"=>'');
$icons['Default']['Map-Marker'] = array("class"=>'Map-Marker',"tags"=>'Map-Marker',"unicode"=>'');
$icons['Default']['Map-Marker2'] = array("class"=>'Map-Marker2',"tags"=>'Map-Marker2',"unicode"=>'');
$icons['Default']['Satelite'] = array("class"=>'Satelite',"tags"=>'Satelite',"unicode"=>'');
$icons['Default']['Satelite-2'] = array("class"=>'Satelite-2',"tags"=>'Satelite-2',"unicode"=>'');
$icons['Default']['Street-View'] = array("class"=>'Street-View',"tags"=>'Street-View',"unicode"=>'');
$icons['Default']['Street-View2'] = array("class"=>'Street-View2',"tags"=>'Street-View2',"unicode"=>'');
$icons['Default']['Android-Store'] = array("class"=>'Android-Store',"tags"=>'Android-Store',"unicode"=>'');
$icons['Default']['Dropbox'] = array("class"=>'Dropbox',"tags"=>'Dropbox',"unicode"=>'');
$icons['Default']['Google-Drive'] = array("class"=>'Google-Drive',"tags"=>'Google-Drive',"unicode"=>'');
$icons['Default']['Google-Play'] = array("class"=>'Google-Play',"tags"=>'Google-Play',"unicode"=>'');
$icons['Default']['Paypal'] = array("class"=>'Paypal',"tags"=>'Paypal',"unicode"=>'');
$icons['Default']['Skrill'] = array("class"=>'Skrill',"tags"=>'Skrill',"unicode"=>'');
$icons['Default']['X-Box'] = array("class"=>'X-Box',"tags"=>'X-Box',"unicode"=>'');
$icons['Default']['Add'] = array("class"=>'Add',"tags"=>'Add',"unicode"=>'');
$icons['Default']['Back2'] = array("class"=>'Back2',"tags"=>'Back2',"unicode"=>'');
$icons['Default']['Broken-Link'] = array("class"=>'Broken-Link',"tags"=>'Broken-Link',"unicode"=>'');
$icons['Default']['Check'] = array("class"=>'Check',"tags"=>'Check',"unicode"=>'');
$icons['Default']['Check-2'] = array("class"=>'Check-2',"tags"=>'Check-2',"unicode"=>'');
$icons['Default']['Circular-Point'] = array("class"=>'Circular-Point',"tags"=>'Circular-Point',"unicode"=>'');
$icons['Default']['Close'] = array("class"=>'Close',"tags"=>'Close',"unicode"=>'');
$icons['Default']['Cursor'] = array("class"=>'Cursor',"tags"=>'Cursor',"unicode"=>'');
$icons['Default']['Cursor-Click'] = array("class"=>'Cursor-Click',"tags"=>'Cursor-Click',"unicode"=>'');
$icons['Default']['Cursor-Click2'] = array("class"=>'Cursor-Click2',"tags"=>'Cursor-Click2',"unicode"=>'');
$icons['Default']['Cursor-Move'] = array("class"=>'Cursor-Move',"tags"=>'Cursor-Move',"unicode"=>'');
$icons['Default']['Cursor-Move2'] = array("class"=>'Cursor-Move2',"tags"=>'Cursor-Move2',"unicode"=>'');
$icons['Default']['Cursor-Select'] = array("class"=>'Cursor-Select',"tags"=>'Cursor-Select',"unicode"=>'');
$icons['Default']['Down'] = array("class"=>'Down',"tags"=>'Down',"unicode"=>'');
$icons['Default']['Download'] = array("class"=>'Download',"tags"=>'Download',"unicode"=>'');
$icons['Default']['Downward'] = array("class"=>'Downward',"tags"=>'Downward',"unicode"=>'');
$icons['Default']['Endways'] = array("class"=>'Endways',"tags"=>'Endways',"unicode"=>'');
$icons['Default']['Forward'] = array("class"=>'Forward',"tags"=>'Forward',"unicode"=>'');
$icons['Default']['Left'] = array("class"=>'Left',"tags"=>'Left',"unicode"=>'');
$icons['Default']['Link'] = array("class"=>'Link',"tags"=>'Link',"unicode"=>'');
$icons['Default']['Next2'] = array("class"=>'Next2',"tags"=>'Next2',"unicode"=>'');
$icons['Default']['Orientation'] = array("class"=>'Orientation',"tags"=>'Orientation',"unicode"=>'');
$icons['Default']['Pointer'] = array("class"=>'Pointer',"tags"=>'Pointer',"unicode"=>'');
$icons['Default']['Previous'] = array("class"=>'Previous',"tags"=>'Previous',"unicode"=>'');
$icons['Default']['Redo'] = array("class"=>'Redo',"tags"=>'Redo',"unicode"=>'');
$icons['Default']['Refresh'] = array("class"=>'Refresh',"tags"=>'Refresh',"unicode"=>'');
$icons['Default']['Reload'] = array("class"=>'Reload',"tags"=>'Reload',"unicode"=>'');
$icons['Default']['Remove'] = array("class"=>'Remove',"tags"=>'Remove',"unicode"=>'');
$icons['Default']['Repeat2'] = array("class"=>'Repeat2',"tags"=>'Repeat2',"unicode"=>'');
$icons['Default']['Reset'] = array("class"=>'Reset',"tags"=>'Reset',"unicode"=>'');
$icons['Default']['Rewind'] = array("class"=>'Rewind',"tags"=>'Rewind',"unicode"=>'');
$icons['Default']['Right'] = array("class"=>'Right',"tags"=>'Right',"unicode"=>'');
$icons['Default']['Rotation'] = array("class"=>'Rotation',"tags"=>'Rotation',"unicode"=>'');
$icons['Default']['Rotation-390'] = array("class"=>'Rotation-390',"tags"=>'Rotation-390',"unicode"=>'');
$icons['Default']['Spot'] = array("class"=>'Spot',"tags"=>'Spot',"unicode"=>'');
$icons['Default']['Start-ways'] = array("class"=>'Start-ways',"tags"=>'Start-ways',"unicode"=>'');
$icons['Default']['Synchronize'] = array("class"=>'Synchronize',"tags"=>'Synchronize',"unicode"=>'');
$icons['Default']['Synchronize-2'] = array("class"=>'Synchronize-2',"tags"=>'Synchronize-2',"unicode"=>'');
$icons['Default']['Undo'] = array("class"=>'Undo',"tags"=>'Undo',"unicode"=>'');
$icons['Default']['Up'] = array("class"=>'Up',"tags"=>'Up',"unicode"=>'');
$icons['Default']['Upload'] = array("class"=>'Upload',"tags"=>'Upload',"unicode"=>'');
$icons['Default']['Upward'] = array("class"=>'Upward',"tags"=>'Upward',"unicode"=>'');
$icons['Default']['Yes'] = array("class"=>'Yes',"tags"=>'Yes',"unicode"=>'');
$icons['Default']['Barricade2'] = array("class"=>'Barricade2',"tags"=>'Barricade2',"unicode"=>'');
$icons['Default']['Crane'] = array("class"=>'Crane',"tags"=>'Crane',"unicode"=>'');
$icons['Default']['Dam'] = array("class"=>'Dam',"tags"=>'Dam',"unicode"=>'');
$icons['Default']['Drill2'] = array("class"=>'Drill2',"tags"=>'Drill2',"unicode"=>'');
$icons['Default']['Electricity'] = array("class"=>'Electricity',"tags"=>'Electricity',"unicode"=>'');
$icons['Default']['Explode'] = array("class"=>'Explode',"tags"=>'Explode',"unicode"=>'');
$icons['Default']['Factory'] = array("class"=>'Factory',"tags"=>'Factory',"unicode"=>'');
$icons['Default']['Fuel'] = array("class"=>'Fuel',"tags"=>'Fuel',"unicode"=>'');
$icons['Default']['Oil'] = array("class"=>'Oil',"tags"=>'Oil',"unicode"=>'');
$icons['Default']['Petrol'] = array("class"=>'Petrol',"tags"=>'Petrol',"unicode"=>'');
$icons['Default']['Pipe'] = array("class"=>'Pipe',"tags"=>'Pipe',"unicode"=>'');
$icons['Default']['Power-Station'] = array("class"=>'Power-Station',"tags"=>'Power-Station',"unicode"=>'');
$icons['Default']['Refinery'] = array("class"=>'Refinery',"tags"=>'Refinery',"unicode"=>'');
$icons['Default']['Saw'] = array("class"=>'Saw',"tags"=>'Saw',"unicode"=>'');
$icons['Default']['Shovel'] = array("class"=>'Shovel',"tags"=>'Shovel',"unicode"=>'');
$icons['Default']['Solar'] = array("class"=>'Solar',"tags"=>'Solar',"unicode"=>'');
$icons['Default']['Aa'] = array("class"=>'Aa',"tags"=>'Aa',"unicode"=>'');
$icons['Default']['Add-File'] = array("class"=>'Add-File',"tags"=>'Add-File',"unicode"=>'');
$icons['Default']['Address-Book'] = array("class"=>'Address-Book',"tags"=>'Address-Book',"unicode"=>'');
$icons['Default']['Address-Book2'] = array("class"=>'Address-Book2',"tags"=>'Address-Book2',"unicode"=>'');
$icons['Default']['Add-SpaceAfterParagraph'] = array("class"=>'Add-SpaceAfterParagraph',"tags"=>'Add-SpaceAfterParagraph',"unicode"=>'');
$icons['Default']['Add-SpaceBeforeParagraph'] = array("class"=>'Add-SpaceBeforeParagraph',"tags"=>'Add-SpaceBeforeParagraph',"unicode"=>'');
$icons['Default']['Align-Center'] = array("class"=>'Align-Center',"tags"=>'Align-Center',"unicode"=>'');
$icons['Default']['Align-JustifyAll'] = array("class"=>'Align-JustifyAll',"tags"=>'Align-JustifyAll',"unicode"=>'');
$icons['Default']['Align-JustifyCenter'] = array("class"=>'Align-JustifyCenter',"tags"=>'Align-JustifyCenter',"unicode"=>'');
$icons['Default']['Align-JustifyLeft'] = array("class"=>'Align-JustifyLeft',"tags"=>'Align-JustifyLeft',"unicode"=>'');
$icons['Default']['Align-JustifyRight'] = array("class"=>'Align-JustifyRight',"tags"=>'Align-JustifyRight',"unicode"=>'');
$icons['Default']['Align-Left'] = array("class"=>'Align-Left',"tags"=>'Align-Left',"unicode"=>'');
$icons['Default']['Align-Right'] = array("class"=>'Align-Right',"tags"=>'Align-Right',"unicode"=>'');
$icons['Default']['Anchor2'] = array("class"=>'Anchor2',"tags"=>'Anchor2',"unicode"=>'');
$icons['Default']['Apple'] = array("class"=>'Apple',"tags"=>'Apple',"unicode"=>'');
$icons['Default']['Arrow-Around'] = array("class"=>'Arrow-Around',"tags"=>'Arrow-Around',"unicode"=>'');
$icons['Default']['Arrow-Back'] = array("class"=>'Arrow-Back',"tags"=>'Arrow-Back',"unicode"=>'');
$icons['Default']['Arrow-Back2'] = array("class"=>'Arrow-Back2',"tags"=>'Arrow-Back2',"unicode"=>'');
$icons['Default']['Arrow-Back3'] = array("class"=>'Arrow-Back3',"tags"=>'Arrow-Back3',"unicode"=>'');
$icons['Default']['Arrow-Barrier'] = array("class"=>'Arrow-Barrier',"tags"=>'Arrow-Barrier',"unicode"=>'');
$icons['Default']['Arrow-Circle'] = array("class"=>'Arrow-Circle',"tags"=>'Arrow-Circle',"unicode"=>'');
$icons['Default']['Arrow-Cross'] = array("class"=>'Arrow-Cross',"tags"=>'Arrow-Cross',"unicode"=>'');
$icons['Default']['Arrow-Down'] = array("class"=>'Arrow-Down',"tags"=>'Arrow-Down',"unicode"=>'');
$icons['Default']['Arrow-Down2'] = array("class"=>'Arrow-Down2',"tags"=>'Arrow-Down2',"unicode"=>'');
$icons['Default']['Arrow-Down3'] = array("class"=>'Arrow-Down3',"tags"=>'Arrow-Down3',"unicode"=>'');
$icons['Default']['Arrow-DowninCircle'] = array("class"=>'Arrow-DowninCircle',"tags"=>'Arrow-DowninCircle',"unicode"=>'');
$icons['Default']['Arrow-Fork'] = array("class"=>'Arrow-Fork',"tags"=>'Arrow-Fork',"unicode"=>'');
$icons['Default']['Arrow-Forward'] = array("class"=>'Arrow-Forward',"tags"=>'Arrow-Forward',"unicode"=>'');
$icons['Default']['Arrow-Forward2'] = array("class"=>'Arrow-Forward2',"tags"=>'Arrow-Forward2',"unicode"=>'');
$icons['Default']['Arrow-From'] = array("class"=>'Arrow-From',"tags"=>'Arrow-From',"unicode"=>'');
$icons['Default']['Arrow-Inside'] = array("class"=>'Arrow-Inside',"tags"=>'Arrow-Inside',"unicode"=>'');
$icons['Default']['Arrow-Inside45'] = array("class"=>'Arrow-Inside45',"tags"=>'Arrow-Inside45',"unicode"=>'');
$icons['Default']['Arrow-InsideGap'] = array("class"=>'Arrow-InsideGap',"tags"=>'Arrow-InsideGap',"unicode"=>'');
$icons['Default']['Arrow-InsideGap45'] = array("class"=>'Arrow-InsideGap45',"tags"=>'Arrow-InsideGap45',"unicode"=>'');
$icons['Default']['Arrow-Into'] = array("class"=>'Arrow-Into',"tags"=>'Arrow-Into',"unicode"=>'');
$icons['Default']['Arrow-Join'] = array("class"=>'Arrow-Join',"tags"=>'Arrow-Join',"unicode"=>'');
$icons['Default']['Arrow-Junction'] = array("class"=>'Arrow-Junction',"tags"=>'Arrow-Junction',"unicode"=>'');
$icons['Default']['Arrow-Left'] = array("class"=>'Arrow-Left',"tags"=>'Arrow-Left',"unicode"=>'');
$icons['Default']['Arrow-Left2'] = array("class"=>'Arrow-Left2',"tags"=>'Arrow-Left2',"unicode"=>'');
$icons['Default']['Arrow-LeftinCircle'] = array("class"=>'Arrow-LeftinCircle',"tags"=>'Arrow-LeftinCircle',"unicode"=>'');
$icons['Default']['Arrow-Loop'] = array("class"=>'Arrow-Loop',"tags"=>'Arrow-Loop',"unicode"=>'');
$icons['Default']['Arrow-Merge'] = array("class"=>'Arrow-Merge',"tags"=>'Arrow-Merge',"unicode"=>'');
$icons['Default']['Arrow-Mix'] = array("class"=>'Arrow-Mix',"tags"=>'Arrow-Mix',"unicode"=>'');
$icons['Default']['Arrow-Next'] = array("class"=>'Arrow-Next',"tags"=>'Arrow-Next',"unicode"=>'');
$icons['Default']['Arrow-OutLeft'] = array("class"=>'Arrow-OutLeft',"tags"=>'Arrow-OutLeft',"unicode"=>'');
$icons['Default']['Arrow-OutRight'] = array("class"=>'Arrow-OutRight',"tags"=>'Arrow-OutRight',"unicode"=>'');
$icons['Default']['Arrow-Outside'] = array("class"=>'Arrow-Outside',"tags"=>'Arrow-Outside',"unicode"=>'');
$icons['Default']['Arrow-Outside45'] = array("class"=>'Arrow-Outside45',"tags"=>'Arrow-Outside45',"unicode"=>'');
$icons['Default']['Arrow-OutsideGap'] = array("class"=>'Arrow-OutsideGap',"tags"=>'Arrow-OutsideGap',"unicode"=>'');
$icons['Default']['Arrow-OutsideGap45'] = array("class"=>'Arrow-OutsideGap45',"tags"=>'Arrow-OutsideGap45',"unicode"=>'');
$icons['Default']['Arrow-Over'] = array("class"=>'Arrow-Over',"tags"=>'Arrow-Over',"unicode"=>'');
$icons['Default']['Arrow-Refresh'] = array("class"=>'Arrow-Refresh',"tags"=>'Arrow-Refresh',"unicode"=>'');
$icons['Default']['Arrow-Refresh2'] = array("class"=>'Arrow-Refresh2',"tags"=>'Arrow-Refresh2',"unicode"=>'');
$icons['Default']['Arrow-Right'] = array("class"=>'Arrow-Right',"tags"=>'Arrow-Right',"unicode"=>'');
$icons['Default']['Arrow-Right2'] = array("class"=>'Arrow-Right2',"tags"=>'Arrow-Right2',"unicode"=>'');
$icons['Default']['Arrow-RightinCircle'] = array("class"=>'Arrow-RightinCircle',"tags"=>'Arrow-RightinCircle',"unicode"=>'');
$icons['Default']['Arrow-Shuffle'] = array("class"=>'Arrow-Shuffle',"tags"=>'Arrow-Shuffle',"unicode"=>'');
$icons['Default']['Arrow-Squiggly'] = array("class"=>'Arrow-Squiggly',"tags"=>'Arrow-Squiggly',"unicode"=>'');
$icons['Default']['Arrow-Through'] = array("class"=>'Arrow-Through',"tags"=>'Arrow-Through',"unicode"=>'');
$icons['Default']['Arrow-To'] = array("class"=>'Arrow-To',"tags"=>'Arrow-To',"unicode"=>'');
$icons['Default']['Arrow-TurnLeft'] = array("class"=>'Arrow-TurnLeft',"tags"=>'Arrow-TurnLeft',"unicode"=>'');
$icons['Default']['Arrow-TurnRight'] = array("class"=>'Arrow-TurnRight',"tags"=>'Arrow-TurnRight',"unicode"=>'');
$icons['Default']['Arrow-Up'] = array("class"=>'Arrow-Up',"tags"=>'Arrow-Up',"unicode"=>'');
$icons['Default']['Arrow-Up2'] = array("class"=>'Arrow-Up2',"tags"=>'Arrow-Up2',"unicode"=>'');
$icons['Default']['Arrow-Up3'] = array("class"=>'Arrow-Up3',"tags"=>'Arrow-Up3',"unicode"=>'');
$icons['Default']['Arrow-UpinCircle'] = array("class"=>'Arrow-UpinCircle',"tags"=>'Arrow-UpinCircle',"unicode"=>'');
$icons['Default']['Arrow-XLeft'] = array("class"=>'Arrow-XLeft',"tags"=>'Arrow-XLeft',"unicode"=>'');
$icons['Default']['Arrow-XRight'] = array("class"=>'Arrow-XRight',"tags"=>'Arrow-XRight',"unicode"=>'');
$icons['Default']['ATM'] = array("class"=>'ATM',"tags"=>'ATM',"unicode"=>'');
$icons['Default']['At-Sign'] = array("class"=>'At-Sign',"tags"=>'At-Sign',"unicode"=>'');
$icons['Default']['Bag'] = array("class"=>'Bag',"tags"=>'Bag',"unicode"=>'');
$icons['Default']['Bakelite'] = array("class"=>'Bakelite',"tags"=>'Bakelite',"unicode"=>'');
$icons['Default']['Bank'] = array("class"=>'Bank',"tags"=>'Bank',"unicode"=>'');
$icons['Default']['Bar-Chart'] = array("class"=>'Bar-Chart',"tags"=>'Bar-Chart',"unicode"=>'');
$icons['Default']['Bar-Chart2'] = array("class"=>'Bar-Chart2',"tags"=>'Bar-Chart2',"unicode"=>'');
$icons['Default']['Bar-Chart3'] = array("class"=>'Bar-Chart3',"tags"=>'Bar-Chart3',"unicode"=>'');
$icons['Default']['Bar-Chart4'] = array("class"=>'Bar-Chart4',"tags"=>'Bar-Chart4',"unicode"=>'');
$icons['Default']['Bar-Chart5'] = array("class"=>'Bar-Chart5',"tags"=>'Bar-Chart5',"unicode"=>'');
$icons['Default']['Battery-0'] = array("class"=>'Battery-0',"tags"=>'Battery-0',"unicode"=>'');
$icons['Default']['Battery-25'] = array("class"=>'Battery-25',"tags"=>'Battery-25',"unicode"=>'');
$icons['Default']['Battery-50'] = array("class"=>'Battery-50',"tags"=>'Battery-50',"unicode"=>'');
$icons['Default']['Battery-75'] = array("class"=>'Battery-75',"tags"=>'Battery-75',"unicode"=>'');
$icons['Default']['Battery-100'] = array("class"=>'Battery-100',"tags"=>'Battery-100',"unicode"=>'');
$icons['Default']['Battery-Charge'] = array("class"=>'Battery-Charge',"tags"=>'Battery-Charge',"unicode"=>'');
$icons['Default']['Bee'] = array("class"=>'Bee',"tags"=>'Bee',"unicode"=>'');
$icons['Default']['Beer'] = array("class"=>'Beer',"tags"=>'Beer',"unicode"=>'');
$icons['Default']['Beer-Glass'] = array("class"=>'Beer-Glass',"tags"=>'Beer-Glass',"unicode"=>'');
$icons['Default']['Bell2'] = array("class"=>'Bell2',"tags"=>'Bell2',"unicode"=>'');
$icons['Default']['Big-Data'] = array("class"=>'Big-Data',"tags"=>'Big-Data',"unicode"=>'');
$icons['Default']['Bilk-Bottle2'] = array("class"=>'Bilk-Bottle2',"tags"=>'Bilk-Bottle2',"unicode"=>'');
$icons['Default']['Blackboard'] = array("class"=>'Blackboard',"tags"=>'Blackboard',"unicode"=>'');
$icons['Default']['Block-Cloud'] = array("class"=>'Block-Cloud',"tags"=>'Block-Cloud',"unicode"=>'');
$icons['Default']['Blueprint'] = array("class"=>'Blueprint',"tags"=>'Blueprint',"unicode"=>'');
$icons['Default']['Board'] = array("class"=>'Board',"tags"=>'Board',"unicode"=>'');
$icons['Default']['Book'] = array("class"=>'Book',"tags"=>'Book',"unicode"=>'');
$icons['Default']['Bookmark'] = array("class"=>'Bookmark',"tags"=>'Bookmark',"unicode"=>'');
$icons['Default']['Books'] = array("class"=>'Books',"tags"=>'Books',"unicode"=>'');
$icons['Default']['Books-2'] = array("class"=>'Books-2',"tags"=>'Books-2',"unicode"=>'');
$icons['Default']['Bottom-ToTop'] = array("class"=>'Bottom-ToTop',"tags"=>'Bottom-ToTop',"unicode"=>'');
$icons['Default']['Box-Close'] = array("class"=>'Box-Close',"tags"=>'Box-Close',"unicode"=>'');
$icons['Default']['Box-Full'] = array("class"=>'Box-Full',"tags"=>'Box-Full',"unicode"=>'');
$icons['Default']['Box-Open'] = array("class"=>'Box-Open',"tags"=>'Box-Open',"unicode"=>'');
$icons['Default']['Box-withFolders'] = array("class"=>'Box-withFolders',"tags"=>'Box-withFolders',"unicode"=>'');
$icons['Default']['Brush'] = array("class"=>'Brush',"tags"=>'Brush',"unicode"=>'');
$icons['Default']['Bug'] = array("class"=>'Bug',"tags"=>'Bug',"unicode"=>'');
$icons['Default']['Building'] = array("class"=>'Building',"tags"=>'Building',"unicode"=>'');
$icons['Default']['Butterfly'] = array("class"=>'Butterfly',"tags"=>'Butterfly',"unicode"=>'');
$icons['Default']['Calculator'] = array("class"=>'Calculator',"tags"=>'Calculator',"unicode"=>'');
$icons['Default']['Calculator-2'] = array("class"=>'Calculator-2',"tags"=>'Calculator-2',"unicode"=>'');
$icons['Default']['Calculator-3'] = array("class"=>'Calculator-3',"tags"=>'Calculator-3',"unicode"=>'');
$icons['Default']['Calendar'] = array("class"=>'Calendar',"tags"=>'Calendar',"unicode"=>'');
$icons['Default']['Calendar-2'] = array("class"=>'Calendar-2',"tags"=>'Calendar-2',"unicode"=>'');
$icons['Default']['Calendar-3'] = array("class"=>'Calendar-3',"tags"=>'Calendar-3',"unicode"=>'');
$icons['Default']['Calendar-4'] = array("class"=>'Calendar-4',"tags"=>'Calendar-4',"unicode"=>'');
$icons['Default']['Can-2'] = array("class"=>'Can-2',"tags"=>'Can-2',"unicode"=>'');
$icons['Default']['Candle'] = array("class"=>'Candle',"tags"=>'Candle',"unicode"=>'');
$icons['Default']['Candy'] = array("class"=>'Candy',"tags"=>'Candy',"unicode"=>'');
$icons['Default']['Cap-3'] = array("class"=>'Cap-3',"tags"=>'Cap-3',"unicode"=>'');
$icons['Default']['Cardiovascular'] = array("class"=>'Cardiovascular',"tags"=>'Cardiovascular',"unicode"=>'');
$icons['Default']['CD'] = array("class"=>'CD',"tags"=>'CD',"unicode"=>'');
$icons['Default']['Charger'] = array("class"=>'Charger',"tags"=>'Charger',"unicode"=>'');
$icons['Default']['Cheese'] = array("class"=>'Cheese',"tags"=>'Cheese',"unicode"=>'');
$icons['Default']['Chef-Hat'] = array("class"=>'Chef-Hat',"tags"=>'Chef-Hat',"unicode"=>'');
$icons['Default']['Chef-Hat2'] = array("class"=>'Chef-Hat2',"tags"=>'Chef-Hat2',"unicode"=>'');
$icons['Default']['Chip'] = array("class"=>'Chip',"tags"=>'Chip',"unicode"=>'');
$icons['Default']['Christmas-Tree'] = array("class"=>'Christmas-Tree',"tags"=>'Christmas-Tree',"unicode"=>'');
$icons['Default']['Chrome'] = array("class"=>'Chrome',"tags"=>'Chrome',"unicode"=>'');
$icons['Default']['Clamp'] = array("class"=>'Clamp',"tags"=>'Clamp',"unicode"=>'');
$icons['Default']['Cloud'] = array("class"=>'Cloud',"tags"=>'Cloud',"unicode"=>'');
$icons['Default']['Cloud2'] = array("class"=>'Cloud2',"tags"=>'Cloud2',"unicode"=>'');
$icons['Default']['Cloud3'] = array("class"=>'Cloud3',"tags"=>'Cloud3',"unicode"=>'');
$icons['Default']['Cloud-Camera'] = array("class"=>'Cloud-Camera',"tags"=>'Cloud-Camera',"unicode"=>'');
$icons['Default']['Cloud-Computer'] = array("class"=>'Cloud-Computer',"tags"=>'Cloud-Computer',"unicode"=>'');
$icons['Default']['Cloud-Email'] = array("class"=>'Cloud-Email',"tags"=>'Cloud-Email',"unicode"=>'');
$icons['Default']['Cloud-Laptop'] = array("class"=>'Cloud-Laptop',"tags"=>'Cloud-Laptop',"unicode"=>'');
$icons['Default']['Cloud-Lock'] = array("class"=>'Cloud-Lock',"tags"=>'Cloud-Lock',"unicode"=>'');
$icons['Default']['Cloud-Music'] = array("class"=>'Cloud-Music',"tags"=>'Cloud-Music',"unicode"=>'');
$icons['Default']['Cloud-Picture'] = array("class"=>'Cloud-Picture',"tags"=>'Cloud-Picture',"unicode"=>'');
$icons['Default']['Cloud-Remove'] = array("class"=>'Cloud-Remove',"tags"=>'Cloud-Remove',"unicode"=>'');
$icons['Default']['Clouds'] = array("class"=>'Clouds',"tags"=>'Clouds',"unicode"=>'');
$icons['Default']['Cloud-Secure'] = array("class"=>'Cloud-Secure',"tags"=>'Cloud-Secure',"unicode"=>'');
$icons['Default']['Cloud-Settings'] = array("class"=>'Cloud-Settings',"tags"=>'Cloud-Settings',"unicode"=>'');
$icons['Default']['Cloud-Smartphone'] = array("class"=>'Cloud-Smartphone',"tags"=>'Cloud-Smartphone',"unicode"=>'');
$icons['Default']['Cloud-Tablet'] = array("class"=>'Cloud-Tablet',"tags"=>'Cloud-Tablet',"unicode"=>'');
$icons['Default']['CMYK'] = array("class"=>'CMYK',"tags"=>'CMYK',"unicode"=>'');
$icons['Default']['Cocktail'] = array("class"=>'Cocktail',"tags"=>'Cocktail',"unicode"=>'');
$icons['Default']['Coffee'] = array("class"=>'Coffee',"tags"=>'Coffee',"unicode"=>'');
$icons['Default']['Coffee-2'] = array("class"=>'Coffee-2',"tags"=>'Coffee-2',"unicode"=>'');
$icons['Default']['Coffee-toGo'] = array("class"=>'Coffee-toGo',"tags"=>'Coffee-toGo',"unicode"=>'');
$icons['Default']['Coin'] = array("class"=>'Coin',"tags"=>'Coin',"unicode"=>'');
$icons['Default']['Coins'] = array("class"=>'Coins',"tags"=>'Coins',"unicode"=>'');
$icons['Default']['Communication-Tower'] = array("class"=>'Communication-Tower',"tags"=>'Communication-Tower',"unicode"=>'');
$icons['Default']['Communication-Tower2'] = array("class"=>'Communication-Tower2',"tags"=>'Communication-Tower2',"unicode"=>'');
$icons['Default']['Compass2'] = array("class"=>'Compass2',"tags"=>'Compass2',"unicode"=>'');
$icons['Default']['Compass-22'] = array("class"=>'Compass-22',"tags"=>'Compass-22',"unicode"=>'');
$icons['Default']['Computer'] = array("class"=>'Computer',"tags"=>'Computer',"unicode"=>'');
$icons['Default']['Computer-2'] = array("class"=>'Computer-2',"tags"=>'Computer-2',"unicode"=>'');
$icons['Default']['Computer-3'] = array("class"=>'Computer-3',"tags"=>'Computer-3',"unicode"=>'');
$icons['Default']['Contrast'] = array("class"=>'Contrast',"tags"=>'Contrast',"unicode"=>'');
$icons['Default']['CPU'] = array("class"=>'CPU',"tags"=>'CPU',"unicode"=>'');
$icons['Default']['Credit-Card'] = array("class"=>'Credit-Card',"tags"=>'Credit-Card',"unicode"=>'');
$icons['Default']['Credit-Card2'] = array("class"=>'Credit-Card2',"tags"=>'Credit-Card2',"unicode"=>'');
$icons['Default']['Credit-Card3'] = array("class"=>'Credit-Card3',"tags"=>'Credit-Card3',"unicode"=>'');
$icons['Default']['Croissant'] = array("class"=>'Croissant',"tags"=>'Croissant',"unicode"=>'');
$icons['Default']['Danemark'] = array("class"=>'Danemark',"tags"=>'Danemark',"unicode"=>'');
$icons['Default']['Data'] = array("class"=>'Data',"tags"=>'Data',"unicode"=>'');
$icons['Default']['Data-Backup'] = array("class"=>'Data-Backup',"tags"=>'Data-Backup',"unicode"=>'');
$icons['Default']['Data-Block'] = array("class"=>'Data-Block',"tags"=>'Data-Block',"unicode"=>'');
$icons['Default']['Data-Center'] = array("class"=>'Data-Center',"tags"=>'Data-Center',"unicode"=>'');
$icons['Default']['Data-Clock'] = array("class"=>'Data-Clock',"tags"=>'Data-Clock',"unicode"=>'');
$icons['Default']['Data-Cloud'] = array("class"=>'Data-Cloud',"tags"=>'Data-Cloud',"unicode"=>'');
$icons['Default']['Data-Compress'] = array("class"=>'Data-Compress',"tags"=>'Data-Compress',"unicode"=>'');
$icons['Default']['Data-Copy'] = array("class"=>'Data-Copy',"tags"=>'Data-Copy',"unicode"=>'');
$icons['Default']['Data-Download'] = array("class"=>'Data-Download',"tags"=>'Data-Download',"unicode"=>'');
$icons['Default']['Data-Financial'] = array("class"=>'Data-Financial',"tags"=>'Data-Financial',"unicode"=>'');
$icons['Default']['Data-Key'] = array("class"=>'Data-Key',"tags"=>'Data-Key',"unicode"=>'');
$icons['Default']['Data-Lock'] = array("class"=>'Data-Lock',"tags"=>'Data-Lock',"unicode"=>'');
$icons['Default']['Data-Network'] = array("class"=>'Data-Network',"tags"=>'Data-Network',"unicode"=>'');
$icons['Default']['Data-Password'] = array("class"=>'Data-Password',"tags"=>'Data-Password',"unicode"=>'');
$icons['Default']['Data-Power'] = array("class"=>'Data-Power',"tags"=>'Data-Power',"unicode"=>'');
$icons['Default']['Data-Refresh'] = array("class"=>'Data-Refresh',"tags"=>'Data-Refresh',"unicode"=>'');
$icons['Default']['Data-Save'] = array("class"=>'Data-Save',"tags"=>'Data-Save',"unicode"=>'');
$icons['Default']['Data-Search'] = array("class"=>'Data-Search',"tags"=>'Data-Search',"unicode"=>'');
$icons['Default']['Data-Security'] = array("class"=>'Data-Security',"tags"=>'Data-Security',"unicode"=>'');
$icons['Default']['Data-Settings'] = array("class"=>'Data-Settings',"tags"=>'Data-Settings',"unicode"=>'');
$icons['Default']['Data-Sharing'] = array("class"=>'Data-Sharing',"tags"=>'Data-Sharing',"unicode"=>'');
$icons['Default']['Data-Shield'] = array("class"=>'Data-Shield',"tags"=>'Data-Shield',"unicode"=>'');
$icons['Default']['Data-Signal'] = array("class"=>'Data-Signal',"tags"=>'Data-Signal',"unicode"=>'');
$icons['Default']['Data-Storage'] = array("class"=>'Data-Storage',"tags"=>'Data-Storage',"unicode"=>'');
$icons['Default']['Data-Stream'] = array("class"=>'Data-Stream',"tags"=>'Data-Stream',"unicode"=>'');
$icons['Default']['Data-Transfer'] = array("class"=>'Data-Transfer',"tags"=>'Data-Transfer',"unicode"=>'');
$icons['Default']['Data-Unlock'] = array("class"=>'Data-Unlock',"tags"=>'Data-Unlock',"unicode"=>'');
$icons['Default']['Data-Upload'] = array("class"=>'Data-Upload',"tags"=>'Data-Upload',"unicode"=>'');
$icons['Default']['Data-Yes'] = array("class"=>'Data-Yes',"tags"=>'Data-Yes',"unicode"=>'');
$icons['Default']['Debian'] = array("class"=>'Debian',"tags"=>'Debian',"unicode"=>'');
$icons['Default']['Dec'] = array("class"=>'Dec',"tags"=>'Dec',"unicode"=>'');
$icons['Default']['Decrase-Inedit'] = array("class"=>'Decrase-Inedit',"tags"=>'Decrase-Inedit',"unicode"=>'');
$icons['Default']['Delete-File'] = array("class"=>'Delete-File',"tags"=>'Delete-File',"unicode"=>'');
$icons['Default']['Device-SyncwithCloud'] = array("class"=>'Device-SyncwithCloud',"tags"=>'Device-SyncwithCloud',"unicode"=>'');
$icons['Default']['Diamond'] = array("class"=>'Diamond',"tags"=>'Diamond',"unicode"=>'');
$icons['Default']['Digital-Drawing'] = array("class"=>'Digital-Drawing',"tags"=>'Digital-Drawing',"unicode"=>'');
$icons['Default']['Diploma'] = array("class"=>'Diploma',"tags"=>'Diploma',"unicode"=>'');
$icons['Default']['Diploma-2'] = array("class"=>'Diploma-2',"tags"=>'Diploma-2',"unicode"=>'');
$icons['Default']['Disk'] = array("class"=>'Disk',"tags"=>'Disk',"unicode"=>'');
$icons['Default']['Dollar'] = array("class"=>'Dollar',"tags"=>'Dollar',"unicode"=>'');
$icons['Default']['Dollar-Sign'] = array("class"=>'Dollar-Sign',"tags"=>'Dollar-Sign',"unicode"=>'');
$icons['Default']['Dollar-Sign2'] = array("class"=>'Dollar-Sign2',"tags"=>'Dollar-Sign2',"unicode"=>'');
$icons['Default']['Door'] = array("class"=>'Door',"tags"=>'Door',"unicode"=>'');
$icons['Default']['Double-Circle'] = array("class"=>'Double-Circle',"tags"=>'Double-Circle',"unicode"=>'');
$icons['Default']['Doughnut'] = array("class"=>'Doughnut',"tags"=>'Doughnut',"unicode"=>'');
$icons['Default']['Dove'] = array("class"=>'Dove',"tags"=>'Dove',"unicode"=>'');
$icons['Default']['Down2'] = array("class"=>'Down2',"tags"=>'Down2',"unicode"=>'');
$icons['Default']['Down-2'] = array("class"=>'Down-2',"tags"=>'Down-2',"unicode"=>'');
$icons['Default']['Down-3'] = array("class"=>'Down-3',"tags"=>'Down-3',"unicode"=>'');
$icons['Default']['Download2'] = array("class"=>'Download2',"tags"=>'Download2',"unicode"=>'');
$icons['Default']['Download-fromCloud'] = array("class"=>'Download-fromCloud',"tags"=>'Download-fromCloud',"unicode"=>'');
$icons['Default']['DVD'] = array("class"=>'DVD',"tags"=>'DVD',"unicode"=>'');
$icons['Default']['Empty-Box'] = array("class"=>'Empty-Box',"tags"=>'Empty-Box',"unicode"=>'');
$icons['Default']['End2'] = array("class"=>'End2',"tags"=>'End2',"unicode"=>'');
$icons['Default']['Envelope'] = array("class"=>'Envelope',"tags"=>'Envelope',"unicode"=>'');
$icons['Default']['Envelope-2'] = array("class"=>'Envelope-2',"tags"=>'Envelope-2',"unicode"=>'');
$icons['Default']['Eraser'] = array("class"=>'Eraser',"tags"=>'Eraser',"unicode"=>'');
$icons['Default']['Eraser-2'] = array("class"=>'Eraser-2',"tags"=>'Eraser-2',"unicode"=>'');
$icons['Default']['Eraser-3'] = array("class"=>'Eraser-3',"tags"=>'Eraser-3',"unicode"=>'');
$icons['Default']['Euro-Sign'] = array("class"=>'Euro-Sign',"tags"=>'Euro-Sign',"unicode"=>'');
$icons['Default']['Euro-Sign2'] = array("class"=>'Euro-Sign2',"tags"=>'Euro-Sign2',"unicode"=>'');
$icons['Default']['Eye2'] = array("class"=>'Eye2',"tags"=>'Eye2',"unicode"=>'');
$icons['Default']['Eye-Blind'] = array("class"=>'Eye-Blind',"tags"=>'Eye-Blind',"unicode"=>'');
$icons['Default']['Eye-Invisible'] = array("class"=>'Eye-Invisible',"tags"=>'Eye-Invisible',"unicode"=>'');
$icons['Default']['Eye-Visible'] = array("class"=>'Eye-Visible',"tags"=>'Eye-Visible',"unicode"=>'');
$icons['Default']['Factory2'] = array("class"=>'Factory2',"tags"=>'Factory2',"unicode"=>'');
$icons['Default']['Fan'] = array("class"=>'Fan',"tags"=>'Fan',"unicode"=>'');
$icons['Default']['Fashion'] = array("class"=>'Fashion',"tags"=>'Fashion',"unicode"=>'');
$icons['Default']['Fax'] = array("class"=>'Fax',"tags"=>'Fax',"unicode"=>'');
$icons['Default']['File'] = array("class"=>'File',"tags"=>'File',"unicode"=>'');
$icons['Default']['File-Block'] = array("class"=>'File-Block',"tags"=>'File-Block',"unicode"=>'');
$icons['Default']['File-Bookmark'] = array("class"=>'File-Bookmark',"tags"=>'File-Bookmark',"unicode"=>'');
$icons['Default']['File-Chart'] = array("class"=>'File-Chart',"tags"=>'File-Chart',"unicode"=>'');
$icons['Default']['File-Clipboard'] = array("class"=>'File-Clipboard',"tags"=>'File-Clipboard',"unicode"=>'');
$icons['Default']['File-ClipboardFileText'] = array("class"=>'File-ClipboardFileText',"tags"=>'File-ClipboardFileText',"unicode"=>'');
$icons['Default']['File-ClipboardTextImage'] = array("class"=>'File-ClipboardTextImage',"tags"=>'File-ClipboardTextImage',"unicode"=>'');
$icons['Default']['File-Cloud'] = array("class"=>'File-Cloud',"tags"=>'File-Cloud',"unicode"=>'');
$icons['Default']['File-Copy'] = array("class"=>'File-Copy',"tags"=>'File-Copy',"unicode"=>'');
$icons['Default']['File-Copy2'] = array("class"=>'File-Copy2',"tags"=>'File-Copy2',"unicode"=>'');
$icons['Default']['File-CSV'] = array("class"=>'File-CSV',"tags"=>'File-CSV',"unicode"=>'');
$icons['Default']['File-Download'] = array("class"=>'File-Download',"tags"=>'File-Download',"unicode"=>'');
$icons['Default']['File-Edit'] = array("class"=>'File-Edit',"tags"=>'File-Edit',"unicode"=>'');
$icons['Default']['File-Excel'] = array("class"=>'File-Excel',"tags"=>'File-Excel',"unicode"=>'');
$icons['Default']['File-Favorite'] = array("class"=>'File-Favorite',"tags"=>'File-Favorite',"unicode"=>'');
$icons['Default']['File-Fire'] = array("class"=>'File-Fire',"tags"=>'File-Fire',"unicode"=>'');
$icons['Default']['File-Graph'] = array("class"=>'File-Graph',"tags"=>'File-Graph',"unicode"=>'');
$icons['Default']['File-Hide'] = array("class"=>'File-Hide',"tags"=>'File-Hide',"unicode"=>'');
$icons['Default']['File-Horizontal'] = array("class"=>'File-Horizontal',"tags"=>'File-Horizontal',"unicode"=>'');
$icons['Default']['File-HorizontalText'] = array("class"=>'File-HorizontalText',"tags"=>'File-HorizontalText',"unicode"=>'');
$icons['Default']['File-HTML'] = array("class"=>'File-HTML',"tags"=>'File-HTML',"unicode"=>'');
$icons['Default']['File-JPG'] = array("class"=>'File-JPG',"tags"=>'File-JPG',"unicode"=>'');
$icons['Default']['File-Link'] = array("class"=>'File-Link',"tags"=>'File-Link',"unicode"=>'');
$icons['Default']['File-Loading'] = array("class"=>'File-Loading',"tags"=>'File-Loading',"unicode"=>'');
$icons['Default']['File-Lock'] = array("class"=>'File-Lock',"tags"=>'File-Lock',"unicode"=>'');
$icons['Default']['File-Love'] = array("class"=>'File-Love',"tags"=>'File-Love',"unicode"=>'');
$icons['Default']['File-Music'] = array("class"=>'File-Music',"tags"=>'File-Music',"unicode"=>'');
$icons['Default']['File-Network'] = array("class"=>'File-Network',"tags"=>'File-Network',"unicode"=>'');
$icons['Default']['File-Pictures'] = array("class"=>'File-Pictures',"tags"=>'File-Pictures',"unicode"=>'');
$icons['Default']['File-Pie'] = array("class"=>'File-Pie',"tags"=>'File-Pie',"unicode"=>'');
$icons['Default']['File-Presentation'] = array("class"=>'File-Presentation',"tags"=>'File-Presentation',"unicode"=>'');
$icons['Default']['File-Refresh'] = array("class"=>'File-Refresh',"tags"=>'File-Refresh',"unicode"=>'');
$icons['Default']['Files'] = array("class"=>'Files',"tags"=>'Files',"unicode"=>'');
$icons['Default']['File-Search'] = array("class"=>'File-Search',"tags"=>'File-Search',"unicode"=>'');
$icons['Default']['File-Settings'] = array("class"=>'File-Settings',"tags"=>'File-Settings',"unicode"=>'');
$icons['Default']['File-Share'] = array("class"=>'File-Share',"tags"=>'File-Share',"unicode"=>'');
$icons['Default']['File-TextImage'] = array("class"=>'File-TextImage',"tags"=>'File-TextImage',"unicode"=>'');
$icons['Default']['File-Trash'] = array("class"=>'File-Trash',"tags"=>'File-Trash',"unicode"=>'');
$icons['Default']['File-TXT'] = array("class"=>'File-TXT',"tags"=>'File-TXT',"unicode"=>'');
$icons['Default']['File-Upload'] = array("class"=>'File-Upload',"tags"=>'File-Upload',"unicode"=>'');
$icons['Default']['File-Video'] = array("class"=>'File-Video',"tags"=>'File-Video',"unicode"=>'');
$icons['Default']['File-Word'] = array("class"=>'File-Word',"tags"=>'File-Word',"unicode"=>'');
$icons['Default']['File-Zip'] = array("class"=>'File-Zip',"tags"=>'File-Zip',"unicode"=>'');
$icons['Default']['Financial'] = array("class"=>'Financial',"tags"=>'Financial',"unicode"=>'');
$icons['Default']['Finger'] = array("class"=>'Finger',"tags"=>'Finger',"unicode"=>'');
$icons['Default']['Fingerprint'] = array("class"=>'Fingerprint',"tags"=>'Fingerprint',"unicode"=>'');
$icons['Default']['Fingerprint-2'] = array("class"=>'Fingerprint-2',"tags"=>'Fingerprint-2',"unicode"=>'');
$icons['Default']['Firefox'] = array("class"=>'Firefox',"tags"=>'Firefox',"unicode"=>'');
$icons['Default']['Fit-To'] = array("class"=>'Fit-To',"tags"=>'Fit-To',"unicode"=>'');
$icons['Default']['Fit-To2'] = array("class"=>'Fit-To2',"tags"=>'Fit-To2',"unicode"=>'');
$icons['Default']['Flag2'] = array("class"=>'Flag2',"tags"=>'Flag2',"unicode"=>'');
$icons['Default']['Flag-22'] = array("class"=>'Flag-22',"tags"=>'Flag-22',"unicode"=>'');
$icons['Default']['Flag-3'] = array("class"=>'Flag-3',"tags"=>'Flag-3',"unicode"=>'');
$icons['Default']['Flag-4'] = array("class"=>'Flag-4',"tags"=>'Flag-4',"unicode"=>'');
$icons['Default']['Folder'] = array("class"=>'Folder',"tags"=>'Folder',"unicode"=>'');
$icons['Default']['Folder-Add'] = array("class"=>'Folder-Add',"tags"=>'Folder-Add',"unicode"=>'');
$icons['Default']['Folder-Archive'] = array("class"=>'Folder-Archive',"tags"=>'Folder-Archive',"unicode"=>'');
$icons['Default']['Folder-Binder'] = array("class"=>'Folder-Binder',"tags"=>'Folder-Binder',"unicode"=>'');
$icons['Default']['Folder-Binder2'] = array("class"=>'Folder-Binder2',"tags"=>'Folder-Binder2',"unicode"=>'');
$icons['Default']['Folder-Block'] = array("class"=>'Folder-Block',"tags"=>'Folder-Block',"unicode"=>'');
$icons['Default']['Folder-Bookmark'] = array("class"=>'Folder-Bookmark',"tags"=>'Folder-Bookmark',"unicode"=>'');
$icons['Default']['Folder-Close'] = array("class"=>'Folder-Close',"tags"=>'Folder-Close',"unicode"=>'');
$icons['Default']['Folder-Cloud'] = array("class"=>'Folder-Cloud',"tags"=>'Folder-Cloud',"unicode"=>'');
$icons['Default']['Folder-Delete'] = array("class"=>'Folder-Delete',"tags"=>'Folder-Delete',"unicode"=>'');
$icons['Default']['Folder-Download'] = array("class"=>'Folder-Download',"tags"=>'Folder-Download',"unicode"=>'');
$icons['Default']['Folder-Edit'] = array("class"=>'Folder-Edit',"tags"=>'Folder-Edit',"unicode"=>'');
$icons['Default']['Folder-Favorite'] = array("class"=>'Folder-Favorite',"tags"=>'Folder-Favorite',"unicode"=>'');
$icons['Default']['Folder-Fire'] = array("class"=>'Folder-Fire',"tags"=>'Folder-Fire',"unicode"=>'');
$icons['Default']['Folder-Hide'] = array("class"=>'Folder-Hide',"tags"=>'Folder-Hide',"unicode"=>'');
$icons['Default']['Folder-Link'] = array("class"=>'Folder-Link',"tags"=>'Folder-Link',"unicode"=>'');
$icons['Default']['Folder-Loading'] = array("class"=>'Folder-Loading',"tags"=>'Folder-Loading',"unicode"=>'');
$icons['Default']['Folder-Lock'] = array("class"=>'Folder-Lock',"tags"=>'Folder-Lock',"unicode"=>'');
$icons['Default']['Folder-Love'] = array("class"=>'Folder-Love',"tags"=>'Folder-Love',"unicode"=>'');
$icons['Default']['Folder-Music'] = array("class"=>'Folder-Music',"tags"=>'Folder-Music',"unicode"=>'');
$icons['Default']['Folder-Network'] = array("class"=>'Folder-Network',"tags"=>'Folder-Network',"unicode"=>'');
$icons['Default']['Folder-Open'] = array("class"=>'Folder-Open',"tags"=>'Folder-Open',"unicode"=>'');
$icons['Default']['Folder-Open2'] = array("class"=>'Folder-Open2',"tags"=>'Folder-Open2',"unicode"=>'');
$icons['Default']['Folder-Organizing'] = array("class"=>'Folder-Organizing',"tags"=>'Folder-Organizing',"unicode"=>'');
$icons['Default']['Folder-Pictures'] = array("class"=>'Folder-Pictures',"tags"=>'Folder-Pictures',"unicode"=>'');
$icons['Default']['Folder-Refresh'] = array("class"=>'Folder-Refresh',"tags"=>'Folder-Refresh',"unicode"=>'');
$icons['Default']['Folder-Remove'] = array("class"=>'Folder-Remove',"tags"=>'Folder-Remove',"unicode"=>'');
$icons['Default']['Folders'] = array("class"=>'Folders',"tags"=>'Folders',"unicode"=>'');
$icons['Default']['Folder-Search'] = array("class"=>'Folder-Search',"tags"=>'Folder-Search',"unicode"=>'');
$icons['Default']['Folder-Settings'] = array("class"=>'Folder-Settings',"tags"=>'Folder-Settings',"unicode"=>'');
$icons['Default']['Folder-Share'] = array("class"=>'Folder-Share',"tags"=>'Folder-Share',"unicode"=>'');
$icons['Default']['Folder-Trash'] = array("class"=>'Folder-Trash',"tags"=>'Folder-Trash',"unicode"=>'');
$icons['Default']['Folder-Upload'] = array("class"=>'Folder-Upload',"tags"=>'Folder-Upload',"unicode"=>'');
$icons['Default']['Folder-Video'] = array("class"=>'Folder-Video',"tags"=>'Folder-Video',"unicode"=>'');
$icons['Default']['Folder-WithDocument'] = array("class"=>'Folder-WithDocument',"tags"=>'Folder-WithDocument',"unicode"=>'');
$icons['Default']['Folder-Zip'] = array("class"=>'Folder-Zip',"tags"=>'Folder-Zip',"unicode"=>'');
$icons['Default']['Formula'] = array("class"=>'Formula',"tags"=>'Formula',"unicode"=>'');
$icons['Default']['Fountain-Pen'] = array("class"=>'Fountain-Pen',"tags"=>'Fountain-Pen',"unicode"=>'');
$icons['Default']['French-Fries'] = array("class"=>'French-Fries',"tags"=>'French-Fries',"unicode"=>'');
$icons['Default']['Fruits'] = array("class"=>'Fruits',"tags"=>'Fruits',"unicode"=>'');
$icons['Default']['Full-Screen'] = array("class"=>'Full-Screen',"tags"=>'Full-Screen',"unicode"=>'');
$icons['Default']['Full-Screen2'] = array("class"=>'Full-Screen2',"tags"=>'Full-Screen2',"unicode"=>'');
$icons['Default']['Full-View'] = array("class"=>'Full-View',"tags"=>'Full-View',"unicode"=>'');
$icons['Default']['Full-View2'] = array("class"=>'Full-View2',"tags"=>'Full-View2',"unicode"=>'');
$icons['Default']['Funny-Bicycle'] = array("class"=>'Funny-Bicycle',"tags"=>'Funny-Bicycle',"unicode"=>'');
$icons['Default']['Gamepad'] = array("class"=>'Gamepad',"tags"=>'Gamepad',"unicode"=>'');
$icons['Default']['Gamepad-2'] = array("class"=>'Gamepad-2',"tags"=>'Gamepad-2',"unicode"=>'');
$icons['Default']['Glass-Water'] = array("class"=>'Glass-Water',"tags"=>'Glass-Water',"unicode"=>'');
$icons['Default']['Go-Bottom'] = array("class"=>'Go-Bottom',"tags"=>'Go-Bottom',"unicode"=>'');
$icons['Default']['Go-Top'] = array("class"=>'Go-Top',"tags"=>'Go-Top',"unicode"=>'');
$icons['Default']['Halloween-HalfMoon'] = array("class"=>'Halloween-HalfMoon',"tags"=>'Halloween-HalfMoon',"unicode"=>'');
$icons['Default']['Hamburger'] = array("class"=>'Hamburger',"tags"=>'Hamburger',"unicode"=>'');
$icons['Default']['Hand'] = array("class"=>'Hand',"tags"=>'Hand',"unicode"=>'');
$icons['Default']['Handshake'] = array("class"=>'Handshake',"tags"=>'Handshake',"unicode"=>'');
$icons['Default']['HD'] = array("class"=>'HD',"tags"=>'HD',"unicode"=>'');
$icons['Default']['HDD'] = array("class"=>'HDD',"tags"=>'HDD',"unicode"=>'');
$icons['Default']['Heart2'] = array("class"=>'Heart2',"tags"=>'Heart2',"unicode"=>'');
$icons['Default']['Hipster-Headphones'] = array("class"=>'Hipster-Headphones',"tags"=>'Hipster-Headphones',"unicode"=>'');
$icons['Default']['Holly'] = array("class"=>'Holly',"tags"=>'Holly',"unicode"=>'');
$icons['Default']['Home2'] = array("class"=>'Home2',"tags"=>'Home2',"unicode"=>'');
$icons['Default']['Home-2'] = array("class"=>'Home-2',"tags"=>'Home-2',"unicode"=>'');
$icons['Default']['Home-3'] = array("class"=>'Home-3',"tags"=>'Home-3',"unicode"=>'');
$icons['Default']['Home-4'] = array("class"=>'Home-4',"tags"=>'Home-4',"unicode"=>'');
$icons['Default']['Hospital2'] = array("class"=>'Hospital2',"tags"=>'Hospital2',"unicode"=>'');
$icons['Default']['Hotel'] = array("class"=>'Hotel',"tags"=>'Hotel',"unicode"=>'');
$icons['Default']['Hub'] = array("class"=>'Hub',"tags"=>'Hub',"unicode"=>'');
$icons['Default']['Ice-Cream'] = array("class"=>'Ice-Cream',"tags"=>'Ice-Cream',"unicode"=>'');
$icons['Default']['Idea'] = array("class"=>'Idea',"tags"=>'Idea',"unicode"=>'');
$icons['Default']['Inbox'] = array("class"=>'Inbox',"tags"=>'Inbox',"unicode"=>'');
$icons['Default']['Inbox-Empty'] = array("class"=>'Inbox-Empty',"tags"=>'Inbox-Empty',"unicode"=>'');
$icons['Default']['Inbox-Forward'] = array("class"=>'Inbox-Forward',"tags"=>'Inbox-Forward',"unicode"=>'');
$icons['Default']['Inbox-Full'] = array("class"=>'Inbox-Full',"tags"=>'Inbox-Full',"unicode"=>'');
$icons['Default']['Inbox-Into'] = array("class"=>'Inbox-Into',"tags"=>'Inbox-Into',"unicode"=>'');
$icons['Default']['Inbox-Out'] = array("class"=>'Inbox-Out',"tags"=>'Inbox-Out',"unicode"=>'');
$icons['Default']['Inbox-Reply'] = array("class"=>'Inbox-Reply',"tags"=>'Inbox-Reply',"unicode"=>'');
$icons['Default']['Increase-Inedit'] = array("class"=>'Increase-Inedit',"tags"=>'Increase-Inedit',"unicode"=>'');
$icons['Default']['Indent-FirstLine'] = array("class"=>'Indent-FirstLine',"tags"=>'Indent-FirstLine',"unicode"=>'');
$icons['Default']['Indent-LeftMargin'] = array("class"=>'Indent-LeftMargin',"tags"=>'Indent-LeftMargin',"unicode"=>'');
$icons['Default']['Indent-RightMargin'] = array("class"=>'Indent-RightMargin',"tags"=>'Indent-RightMargin',"unicode"=>'');
$icons['Default']['Internet-Explorer'] = array("class"=>'Internet-Explorer',"tags"=>'Internet-Explorer',"unicode"=>'');
$icons['Default']['iOS-Apple'] = array("class"=>'iOS-Apple',"tags"=>'iOS-Apple',"unicode"=>'');
$icons['Default']['Juice'] = array("class"=>'Juice',"tags"=>'Juice',"unicode"=>'');
$icons['Default']['Keypad'] = array("class"=>'Keypad',"tags"=>'Keypad',"unicode"=>'');
$icons['Default']['Knife'] = array("class"=>'Knife',"tags"=>'Knife',"unicode"=>'');
$icons['Default']['Knight'] = array("class"=>'Knight',"tags"=>'Knight',"unicode"=>'');
$icons['Default']['Lantern'] = array("class"=>'Lantern',"tags"=>'Lantern',"unicode"=>'');
$icons['Default']['Laptop'] = array("class"=>'Laptop',"tags"=>'Laptop',"unicode"=>'');
$icons['Default']['Laptop-2'] = array("class"=>'Laptop-2',"tags"=>'Laptop-2',"unicode"=>'');
$icons['Default']['Laptop-3'] = array("class"=>'Laptop-3',"tags"=>'Laptop-3',"unicode"=>'');
$icons['Default']['Laptop-Phone'] = array("class"=>'Laptop-Phone',"tags"=>'Laptop-Phone',"unicode"=>'');
$icons['Default']['Laptop-Tablet'] = array("class"=>'Laptop-Tablet',"tags"=>'Laptop-Tablet',"unicode"=>'');
$icons['Default']['Left2'] = array("class"=>'Left2',"tags"=>'Left2',"unicode"=>'');
$icons['Default']['Left-2'] = array("class"=>'Left-2',"tags"=>'Left-2',"unicode"=>'');
$icons['Default']['Left-3'] = array("class"=>'Left-3',"tags"=>'Left-3',"unicode"=>'');
$icons['Default']['Left--Right'] = array("class"=>'Left--Right',"tags"=>'Left--Right',"unicode"=>'');
$icons['Default']['Left--Right3'] = array("class"=>'Left--Right3',"tags"=>'Left--Right3',"unicode"=>'');
$icons['Default']['Left-ToRight'] = array("class"=>'Left-ToRight',"tags"=>'Left-ToRight',"unicode"=>'');
$icons['Default']['Lemon'] = array("class"=>'Lemon',"tags"=>'Lemon',"unicode"=>'');
$icons['Default']['Letter-Close'] = array("class"=>'Letter-Close',"tags"=>'Letter-Close',"unicode"=>'');
$icons['Default']['Letter-Open'] = array("class"=>'Letter-Open',"tags"=>'Letter-Open',"unicode"=>'');
$icons['Default']['Letter-Sent'] = array("class"=>'Letter-Sent',"tags"=>'Letter-Sent',"unicode"=>'');
$icons['Default']['Library2'] = array("class"=>'Library2',"tags"=>'Library2',"unicode"=>'');
$icons['Default']['Lighthouse'] = array("class"=>'Lighthouse',"tags"=>'Lighthouse',"unicode"=>'');
$icons['Default']['Line-Chart'] = array("class"=>'Line-Chart',"tags"=>'Line-Chart',"unicode"=>'');
$icons['Default']['Line-Chart2'] = array("class"=>'Line-Chart2',"tags"=>'Line-Chart2',"unicode"=>'');
$icons['Default']['Line-Chart3'] = array("class"=>'Line-Chart3',"tags"=>'Line-Chart3',"unicode"=>'');
$icons['Default']['Line-Chart4'] = array("class"=>'Line-Chart4',"tags"=>'Line-Chart4',"unicode"=>'');
$icons['Default']['Line-Spacing'] = array("class"=>'Line-Spacing',"tags"=>'Line-Spacing',"unicode"=>'');
$icons['Default']['Lollipop'] = array("class"=>'Lollipop',"tags"=>'Lollipop',"unicode"=>'');
$icons['Default']['Loop'] = array("class"=>'Loop',"tags"=>'Loop',"unicode"=>'');
$icons['Default']['Mail'] = array("class"=>'Mail',"tags"=>'Mail',"unicode"=>'');
$icons['Default']['Mail-2'] = array("class"=>'Mail-2',"tags"=>'Mail-2',"unicode"=>'');
$icons['Default']['Mail-3'] = array("class"=>'Mail-3',"tags"=>'Mail-3',"unicode"=>'');
$icons['Default']['Mail-Add'] = array("class"=>'Mail-Add',"tags"=>'Mail-Add',"unicode"=>'');
$icons['Default']['Mail-Attachement'] = array("class"=>'Mail-Attachement',"tags"=>'Mail-Attachement',"unicode"=>'');
$icons['Default']['Mail-Block'] = array("class"=>'Mail-Block',"tags"=>'Mail-Block',"unicode"=>'');
$icons['Default']['Mailbox-Empty'] = array("class"=>'Mailbox-Empty',"tags"=>'Mailbox-Empty',"unicode"=>'');
$icons['Default']['Mail-Delete'] = array("class"=>'Mail-Delete',"tags"=>'Mail-Delete',"unicode"=>'');
$icons['Default']['Mail-Favorite'] = array("class"=>'Mail-Favorite',"tags"=>'Mail-Favorite',"unicode"=>'');
$icons['Default']['Mail-Forward'] = array("class"=>'Mail-Forward',"tags"=>'Mail-Forward',"unicode"=>'');
$icons['Default']['Mail-Gallery'] = array("class"=>'Mail-Gallery',"tags"=>'Mail-Gallery',"unicode"=>'');
$icons['Default']['Mail-Inbox'] = array("class"=>'Mail-Inbox',"tags"=>'Mail-Inbox',"unicode"=>'');
$icons['Default']['Mail-Link'] = array("class"=>'Mail-Link',"tags"=>'Mail-Link',"unicode"=>'');
$icons['Default']['Mail-Lock'] = array("class"=>'Mail-Lock',"tags"=>'Mail-Lock',"unicode"=>'');
$icons['Default']['Mail-Love'] = array("class"=>'Mail-Love',"tags"=>'Mail-Love',"unicode"=>'');
$icons['Default']['Mail-Money'] = array("class"=>'Mail-Money',"tags"=>'Mail-Money',"unicode"=>'');
$icons['Default']['Mail-Open'] = array("class"=>'Mail-Open',"tags"=>'Mail-Open',"unicode"=>'');
$icons['Default']['Mail-Outbox'] = array("class"=>'Mail-Outbox',"tags"=>'Mail-Outbox',"unicode"=>'');
$icons['Default']['Mail-Password'] = array("class"=>'Mail-Password',"tags"=>'Mail-Password',"unicode"=>'');
$icons['Default']['Mail-Photo'] = array("class"=>'Mail-Photo',"tags"=>'Mail-Photo',"unicode"=>'');
$icons['Default']['Mail-Read'] = array("class"=>'Mail-Read',"tags"=>'Mail-Read',"unicode"=>'');
$icons['Default']['Mail-Removex'] = array("class"=>'Mail-Removex',"tags"=>'Mail-Removex',"unicode"=>'');
$icons['Default']['Mail-Reply'] = array("class"=>'Mail-Reply',"tags"=>'Mail-Reply',"unicode"=>'');
$icons['Default']['Mail-ReplyAll'] = array("class"=>'Mail-ReplyAll',"tags"=>'Mail-ReplyAll',"unicode"=>'');
$icons['Default']['Mail-Search'] = array("class"=>'Mail-Search',"tags"=>'Mail-Search',"unicode"=>'');
$icons['Default']['Mail-Send'] = array("class"=>'Mail-Send',"tags"=>'Mail-Send',"unicode"=>'');
$icons['Default']['Mail-Settings'] = array("class"=>'Mail-Settings',"tags"=>'Mail-Settings',"unicode"=>'');
$icons['Default']['Mail-Unread'] = array("class"=>'Mail-Unread',"tags"=>'Mail-Unread',"unicode"=>'');
$icons['Default']['Mail-Video'] = array("class"=>'Mail-Video',"tags"=>'Mail-Video',"unicode"=>'');
$icons['Default']['Mail-withAtSign'] = array("class"=>'Mail-withAtSign',"tags"=>'Mail-withAtSign',"unicode"=>'');
$icons['Default']['Mail-WithCursors'] = array("class"=>'Mail-WithCursors',"tags"=>'Mail-WithCursors',"unicode"=>'');
$icons['Default']['Marker'] = array("class"=>'Marker',"tags"=>'Marker',"unicode"=>'');
$icons['Default']['Marker-2'] = array("class"=>'Marker-2',"tags"=>'Marker-2',"unicode"=>'');
$icons['Default']['Marker-3'] = array("class"=>'Marker-3',"tags"=>'Marker-3',"unicode"=>'');
$icons['Default']['Martini-Glass'] = array("class"=>'Martini-Glass',"tags"=>'Martini-Glass',"unicode"=>'');
$icons['Default']['Maximize'] = array("class"=>'Maximize',"tags"=>'Maximize',"unicode"=>'');
$icons['Default']['Megaphone'] = array("class"=>'Megaphone',"tags"=>'Megaphone',"unicode"=>'');
$icons['Default']['Milk-Bottle'] = array("class"=>'Milk-Bottle',"tags"=>'Milk-Bottle',"unicode"=>'');
$icons['Default']['Minimize'] = array("class"=>'Minimize',"tags"=>'Minimize',"unicode"=>'');
$icons['Default']['Money-2'] = array("class"=>'Money-2',"tags"=>'Money-2',"unicode"=>'');
$icons['Default']['Money-Bag'] = array("class"=>'Money-Bag',"tags"=>'Money-Bag',"unicode"=>'');
$icons['Default']['Monitor'] = array("class"=>'Monitor',"tags"=>'Monitor',"unicode"=>'');
$icons['Default']['Monitor-2'] = array("class"=>'Monitor-2',"tags"=>'Monitor-2',"unicode"=>'');
$icons['Default']['Monitor-3'] = array("class"=>'Monitor-3',"tags"=>'Monitor-3',"unicode"=>'');
$icons['Default']['Monitor-4'] = array("class"=>'Monitor-4',"tags"=>'Monitor-4',"unicode"=>'');
$icons['Default']['Monitor-5'] = array("class"=>'Monitor-5',"tags"=>'Monitor-5',"unicode"=>'');
$icons['Default']['Monitor-Laptop'] = array("class"=>'Monitor-Laptop',"tags"=>'Monitor-Laptop',"unicode"=>'');
$icons['Default']['Monitor-phone'] = array("class"=>'Monitor-phone',"tags"=>'Monitor-phone',"unicode"=>'');
$icons['Default']['Monitor-Tablet'] = array("class"=>'Monitor-Tablet',"tags"=>'Monitor-Tablet',"unicode"=>'');
$icons['Default']['Monitor-Vertical'] = array("class"=>'Monitor-Vertical',"tags"=>'Monitor-Vertical',"unicode"=>'');
$icons['Default']['Mouse-2'] = array("class"=>'Mouse-2',"tags"=>'Mouse-2',"unicode"=>'');
$icons['Default']['Mouse-3'] = array("class"=>'Mouse-3',"tags"=>'Mouse-3',"unicode"=>'');
$icons['Default']['Museum'] = array("class"=>'Museum',"tags"=>'Museum',"unicode"=>'');
$icons['Default']['Navigate-End'] = array("class"=>'Navigate-End',"tags"=>'Navigate-End',"unicode"=>'');
$icons['Default']['Navigat-Start'] = array("class"=>'Navigat-Start',"tags"=>'Navigat-Start',"unicode"=>'');
$icons['Default']['Netscape'] = array("class"=>'Netscape',"tags"=>'Netscape',"unicode"=>'');
$icons['Default']['New-Mail'] = array("class"=>'New-Mail',"tags"=>'New-Mail',"unicode"=>'');
$icons['Default']['Newspaper'] = array("class"=>'Newspaper',"tags"=>'Newspaper',"unicode"=>'');
$icons['Default']['Newspaper-2'] = array("class"=>'Newspaper-2',"tags"=>'Newspaper-2',"unicode"=>'');
$icons['Default']['No-Battery'] = array("class"=>'No-Battery',"tags"=>'No-Battery',"unicode"=>'');
$icons['Default']['Note'] = array("class"=>'Note',"tags"=>'Note',"unicode"=>'');
$icons['Default']['Notepad'] = array("class"=>'Notepad',"tags"=>'Notepad',"unicode"=>'');
$icons['Default']['Notepad-2'] = array("class"=>'Notepad-2',"tags"=>'Notepad-2',"unicode"=>'');
$icons['Default']['Old-Camera'] = array("class"=>'Old-Camera',"tags"=>'Old-Camera',"unicode"=>'');
$icons['Default']['Old-Telephone'] = array("class"=>'Old-Telephone',"tags"=>'Old-Telephone',"unicode"=>'');
$icons['Default']['Open-Book'] = array("class"=>'Open-Book',"tags"=>'Open-Book',"unicode"=>'');
$icons['Default']['Opera'] = array("class"=>'Opera',"tags"=>'Opera',"unicode"=>'');
$icons['Default']['Orientation2'] = array("class"=>'Orientation2',"tags"=>'Orientation2',"unicode"=>'');
$icons['Default']['Orientation-2'] = array("class"=>'Orientation-2',"tags"=>'Orientation-2',"unicode"=>'');
$icons['Default']['Paintbrush'] = array("class"=>'Paintbrush',"tags"=>'Paintbrush',"unicode"=>'');
$icons['Default']['Palette'] = array("class"=>'Palette',"tags"=>'Palette',"unicode"=>'');
$icons['Default']['Pantheon'] = array("class"=>'Pantheon',"tags"=>'Pantheon',"unicode"=>'');
$icons['Default']['Pantone'] = array("class"=>'Pantone',"tags"=>'Pantone',"unicode"=>'');
$icons['Default']['Paper'] = array("class"=>'Paper',"tags"=>'Paper',"unicode"=>'');
$icons['Default']['Pen'] = array("class"=>'Pen',"tags"=>'Pen',"unicode"=>'');
$icons['Default']['Pen-2'] = array("class"=>'Pen-2',"tags"=>'Pen-2',"unicode"=>'');
$icons['Default']['Pen-3'] = array("class"=>'Pen-3',"tags"=>'Pen-3',"unicode"=>'');
$icons['Default']['Pen-4'] = array("class"=>'Pen-4',"tags"=>'Pen-4',"unicode"=>'');
$icons['Default']['Pen-5'] = array("class"=>'Pen-5',"tags"=>'Pen-5',"unicode"=>'');
$icons['Default']['Pen-6'] = array("class"=>'Pen-6',"tags"=>'Pen-6',"unicode"=>'');
$icons['Default']['Pencil'] = array("class"=>'Pencil',"tags"=>'Pencil',"unicode"=>'');
$icons['Default']['Pencil-Ruler'] = array("class"=>'Pencil-Ruler',"tags"=>'Pencil-Ruler',"unicode"=>'');
$icons['Default']['Pentagon'] = array("class"=>'Pentagon',"tags"=>'Pentagon',"unicode"=>'');
$icons['Default']['People-onCloud'] = array("class"=>'People-onCloud',"tags"=>'People-onCloud',"unicode"=>'');
$icons['Default']['Phone'] = array("class"=>'Phone',"tags"=>'Phone',"unicode"=>'');
$icons['Default']['Phone-2'] = array("class"=>'Phone-2',"tags"=>'Phone-2',"unicode"=>'');
$icons['Default']['Phone-3'] = array("class"=>'Phone-3',"tags"=>'Phone-3',"unicode"=>'');
$icons['Default']['Phone-3G'] = array("class"=>'Phone-3G',"tags"=>'Phone-3G',"unicode"=>'');
$icons['Default']['Phone-4G'] = array("class"=>'Phone-4G',"tags"=>'Phone-4G',"unicode"=>'');
$icons['Default']['Phone-Simcard'] = array("class"=>'Phone-Simcard',"tags"=>'Phone-Simcard',"unicode"=>'');
$icons['Default']['Phone-SMS'] = array("class"=>'Phone-SMS',"tags"=>'Phone-SMS',"unicode"=>'');
$icons['Default']['Phone-Wifi'] = array("class"=>'Phone-Wifi',"tags"=>'Phone-Wifi',"unicode"=>'');
$icons['Default']['Pie-Chart'] = array("class"=>'Pie-Chart',"tags"=>'Pie-Chart',"unicode"=>'');
$icons['Default']['Pie-Chart2'] = array("class"=>'Pie-Chart2',"tags"=>'Pie-Chart2',"unicode"=>'');
$icons['Default']['Pie-Chart3'] = array("class"=>'Pie-Chart3',"tags"=>'Pie-Chart3',"unicode"=>'');
$icons['Default']['Pipette'] = array("class"=>'Pipette',"tags"=>'Pipette',"unicode"=>'');
$icons['Default']['Pizza'] = array("class"=>'Pizza',"tags"=>'Pizza',"unicode"=>'');
$icons['Default']['Pizza-Slice'] = array("class"=>'Pizza-Slice',"tags"=>'Pizza-Slice',"unicode"=>'');
$icons['Default']['Plastic-CupPhone'] = array("class"=>'Plastic-CupPhone',"tags"=>'Plastic-CupPhone',"unicode"=>'');
$icons['Default']['Plastic-CupPhone2'] = array("class"=>'Plastic-CupPhone2',"tags"=>'Plastic-CupPhone2',"unicode"=>'');
$icons['Default']['Plate'] = array("class"=>'Plate',"tags"=>'Plate',"unicode"=>'');
$icons['Default']['Plates'] = array("class"=>'Plates',"tags"=>'Plates',"unicode"=>'');
$icons['Default']['Plug-In'] = array("class"=>'Plug-In',"tags"=>'Plug-In',"unicode"=>'');
$icons['Default']['Plug-In2'] = array("class"=>'Plug-In2',"tags"=>'Plug-In2',"unicode"=>'');
$icons['Default']['Post-Office'] = array("class"=>'Post-Office',"tags"=>'Post-Office',"unicode"=>'');
$icons['Default']['Pound-Sign'] = array("class"=>'Pound-Sign',"tags"=>'Pound-Sign',"unicode"=>'');
$icons['Default']['Power-Cable'] = array("class"=>'Power-Cable',"tags"=>'Power-Cable',"unicode"=>'');
$icons['Default']['Present'] = array("class"=>'Present',"tags"=>'Present',"unicode"=>'');
$icons['Default']['Presents'] = array("class"=>'Presents',"tags"=>'Presents',"unicode"=>'');
$icons['Default']['Printer'] = array("class"=>'Printer',"tags"=>'Printer',"unicode"=>'');
$icons['Default']['Projector-2'] = array("class"=>'Projector-2',"tags"=>'Projector-2',"unicode"=>'');
$icons['Default']['Quill'] = array("class"=>'Quill',"tags"=>'Quill',"unicode"=>'');
$icons['Default']['Quill-2'] = array("class"=>'Quill-2',"tags"=>'Quill-2',"unicode"=>'');
$icons['Default']['Quill-3'] = array("class"=>'Quill-3',"tags"=>'Quill-3',"unicode"=>'');
$icons['Default']['Reload2'] = array("class"=>'Reload2',"tags"=>'Reload2',"unicode"=>'');
$icons['Default']['Reload-2'] = array("class"=>'Reload-2',"tags"=>'Reload-2',"unicode"=>'');
$icons['Default']['Remote-Controll2'] = array("class"=>'Remote-Controll2',"tags"=>'Remote-Controll2',"unicode"=>'');
$icons['Default']['Remove-File'] = array("class"=>'Remove-File',"tags"=>'Remove-File',"unicode"=>'');
$icons['Default']['Repeat3'] = array("class"=>'Repeat3',"tags"=>'Repeat3',"unicode"=>'');
$icons['Default']['Repeat-22'] = array("class"=>'Repeat-22',"tags"=>'Repeat-22',"unicode"=>'');
$icons['Default']['Repeat-3'] = array("class"=>'Repeat-3',"tags"=>'Repeat-3',"unicode"=>'');
$icons['Default']['Repeat-4'] = array("class"=>'Repeat-4',"tags"=>'Repeat-4',"unicode"=>'');
$icons['Default']['Resize'] = array("class"=>'Resize',"tags"=>'Resize',"unicode"=>'');
$icons['Default']['Retro'] = array("class"=>'Retro',"tags"=>'Retro',"unicode"=>'');
$icons['Default']['RGB'] = array("class"=>'RGB',"tags"=>'RGB',"unicode"=>'');
$icons['Default']['Right2'] = array("class"=>'Right2',"tags"=>'Right2',"unicode"=>'');
$icons['Default']['Right-2'] = array("class"=>'Right-2',"tags"=>'Right-2',"unicode"=>'');
$icons['Default']['Right-3'] = array("class"=>'Right-3',"tags"=>'Right-3',"unicode"=>'');
$icons['Default']['Right-ToLeft'] = array("class"=>'Right-ToLeft',"tags"=>'Right-ToLeft',"unicode"=>'');
$icons['Default']['Robot2'] = array("class"=>'Robot2',"tags"=>'Robot2',"unicode"=>'');
$icons['Default']['Roller'] = array("class"=>'Roller',"tags"=>'Roller',"unicode"=>'');
$icons['Default']['Roof'] = array("class"=>'Roof',"tags"=>'Roof',"unicode"=>'');
$icons['Default']['Router'] = array("class"=>'Router',"tags"=>'Router',"unicode"=>'');
$icons['Default']['Router-2'] = array("class"=>'Router-2',"tags"=>'Router-2',"unicode"=>'');
$icons['Default']['Ruler'] = array("class"=>'Ruler',"tags"=>'Ruler',"unicode"=>'');
$icons['Default']['Ruler-2'] = array("class"=>'Ruler-2',"tags"=>'Ruler-2',"unicode"=>'');
$icons['Default']['Safari'] = array("class"=>'Safari',"tags"=>'Safari',"unicode"=>'');
$icons['Default']['Safe-Box2'] = array("class"=>'Safe-Box2',"tags"=>'Safe-Box2',"unicode"=>'');
$icons['Default']['Scarf'] = array("class"=>'Scarf',"tags"=>'Scarf',"unicode"=>'');
$icons['Default']['Scissor'] = array("class"=>'Scissor',"tags"=>'Scissor',"unicode"=>'');
$icons['Default']['Search-onCloud'] = array("class"=>'Search-onCloud',"tags"=>'Search-onCloud',"unicode"=>'');
$icons['Default']['Server'] = array("class"=>'Server',"tags"=>'Server',"unicode"=>'');
$icons['Default']['Server-2'] = array("class"=>'Server-2',"tags"=>'Server-2',"unicode"=>'');
$icons['Default']['Servers'] = array("class"=>'Servers',"tags"=>'Servers',"unicode"=>'');
$icons['Default']['Share-onCloud'] = array("class"=>'Share-onCloud',"tags"=>'Share-onCloud',"unicode"=>'');
$icons['Default']['Shuffle2'] = array("class"=>'Shuffle2',"tags"=>'Shuffle2',"unicode"=>'');
$icons['Default']['Shuffle-22'] = array("class"=>'Shuffle-22',"tags"=>'Shuffle-22',"unicode"=>'');
$icons['Default']['Smartphone'] = array("class"=>'Smartphone',"tags"=>'Smartphone',"unicode"=>'');
$icons['Default']['Smartphone-2'] = array("class"=>'Smartphone-2',"tags"=>'Smartphone-2',"unicode"=>'');
$icons['Default']['Smartphone-3'] = array("class"=>'Smartphone-3',"tags"=>'Smartphone-3',"unicode"=>'');
$icons['Default']['Smartphone-4'] = array("class"=>'Smartphone-4',"tags"=>'Smartphone-4',"unicode"=>'');
$icons['Default']['Smoking-Pipe'] = array("class"=>'Smoking-Pipe',"tags"=>'Smoking-Pipe',"unicode"=>'');
$icons['Default']['Soup'] = array("class"=>'Soup',"tags"=>'Soup',"unicode"=>'');
$icons['Default']['Spam-Mail'] = array("class"=>'Spam-Mail',"tags"=>'Spam-Mail',"unicode"=>'');
$icons['Default']['Speaker2'] = array("class"=>'Speaker2',"tags"=>'Speaker2',"unicode"=>'');
$icons['Default']['Spell-Check'] = array("class"=>'Spell-Check',"tags"=>'Spell-Check',"unicode"=>'');
$icons['Default']['Spell-CheckABC'] = array("class"=>'Spell-CheckABC',"tags"=>'Spell-CheckABC',"unicode"=>'');
$icons['Default']['Spider'] = array("class"=>'Spider',"tags"=>'Spider',"unicode"=>'');
$icons['Default']['Spiderweb'] = array("class"=>'Spiderweb',"tags"=>'Spiderweb',"unicode"=>'');
$icons['Default']['Spray'] = array("class"=>'Spray',"tags"=>'Spray',"unicode"=>'');
$icons['Default']['Stamp'] = array("class"=>'Stamp',"tags"=>'Stamp',"unicode"=>'');
$icons['Default']['Stamp-2'] = array("class"=>'Stamp-2',"tags"=>'Stamp-2',"unicode"=>'');
$icons['Default']['Star'] = array("class"=>'Star',"tags"=>'Star',"unicode"=>'');
$icons['Default']['Starfish'] = array("class"=>'Starfish',"tags"=>'Starfish',"unicode"=>'');
$icons['Default']['Start2'] = array("class"=>'Start2',"tags"=>'Start2',"unicode"=>'');
$icons['Default']['Structure'] = array("class"=>'Structure',"tags"=>'Structure',"unicode"=>'');
$icons['Default']['Student-Hat'] = array("class"=>'Student-Hat',"tags"=>'Student-Hat',"unicode"=>'');
$icons['Default']['Student-Hat2'] = array("class"=>'Student-Hat2',"tags"=>'Student-Hat2',"unicode"=>'');
$icons['Default']['Sum2'] = array("class"=>'Sum2',"tags"=>'Sum2',"unicode"=>'');
$icons['Default']['Surprise'] = array("class"=>'Surprise',"tags"=>'Surprise',"unicode"=>'');
$icons['Default']['Sync'] = array("class"=>'Sync',"tags"=>'Sync',"unicode"=>'');
$icons['Default']['Sync-Cloud'] = array("class"=>'Sync-Cloud',"tags"=>'Sync-Cloud',"unicode"=>'');
$icons['Default']['Tablet'] = array("class"=>'Tablet',"tags"=>'Tablet',"unicode"=>'');
$icons['Default']['Tablet-2'] = array("class"=>'Tablet-2',"tags"=>'Tablet-2',"unicode"=>'');
$icons['Default']['Tablet-3'] = array("class"=>'Tablet-3',"tags"=>'Tablet-3',"unicode"=>'');
$icons['Default']['Tablet-Orientation'] = array("class"=>'Tablet-Orientation',"tags"=>'Tablet-Orientation',"unicode"=>'');
$icons['Default']['Tablet-Phone'] = array("class"=>'Tablet-Phone',"tags"=>'Tablet-Phone',"unicode"=>'');
$icons['Default']['Tablet-Vertical'] = array("class"=>'Tablet-Vertical',"tags"=>'Tablet-Vertical',"unicode"=>'');
$icons['Default']['Tactic'] = array("class"=>'Tactic',"tags"=>'Tactic',"unicode"=>'');
$icons['Default']['Teapot'] = array("class"=>'Teapot',"tags"=>'Teapot',"unicode"=>'');
$icons['Default']['Tee-Mug'] = array("class"=>'Tee-Mug',"tags"=>'Tee-Mug',"unicode"=>'');
$icons['Default']['Telephone'] = array("class"=>'Telephone',"tags"=>'Telephone',"unicode"=>'');
$icons['Default']['Telephone-2'] = array("class"=>'Telephone-2',"tags"=>'Telephone-2',"unicode"=>'');
$icons['Default']['Three-ArrowFork'] = array("class"=>'Three-ArrowFork',"tags"=>'Three-ArrowFork',"unicode"=>'');
$icons['Default']['Tie'] = array("class"=>'Tie',"tags"=>'Tie',"unicode"=>'');
$icons['Default']['Tie-2'] = array("class"=>'Tie-2',"tags"=>'Tie-2',"unicode"=>'');
$icons['Default']['Tie-3'] = array("class"=>'Tie-3',"tags"=>'Tie-3',"unicode"=>'');
$icons['Default']['Time-Clock'] = array("class"=>'Time-Clock',"tags"=>'Time-Clock',"unicode"=>'');
$icons['Default']['To-Bottom'] = array("class"=>'To-Bottom',"tags"=>'To-Bottom',"unicode"=>'');
$icons['Default']['To-Bottom2'] = array("class"=>'To-Bottom2',"tags"=>'To-Bottom2',"unicode"=>'');
$icons['Default']['Token'] = array("class"=>'Token',"tags"=>'Token',"unicode"=>'');
$icons['Default']['To-Left'] = array("class"=>'To-Left',"tags"=>'To-Left',"unicode"=>'');
$icons['Default']['Tooth'] = array("class"=>'Tooth',"tags"=>'Tooth',"unicode"=>'');
$icons['Default']['Tooth-2'] = array("class"=>'Tooth-2',"tags"=>'Tooth-2',"unicode"=>'');
$icons['Default']['Transform'] = array("class"=>'Transform',"tags"=>'Transform',"unicode"=>'');
$icons['Default']['Transform-2'] = array("class"=>'Transform-2',"tags"=>'Transform-2',"unicode"=>'');
$icons['Default']['Transform-3'] = array("class"=>'Transform-3',"tags"=>'Transform-3',"unicode"=>'');
$icons['Default']['Transform-4'] = array("class"=>'Transform-4',"tags"=>'Transform-4',"unicode"=>'');
$icons['Default']['Tree2'] = array("class"=>'Tree2',"tags"=>'Tree2',"unicode"=>'');
$icons['Default']['Tree-22'] = array("class"=>'Tree-22',"tags"=>'Tree-22',"unicode"=>'');
$icons['Default']['Triangle-ArrowDown'] = array("class"=>'Triangle-ArrowDown',"tags"=>'Triangle-ArrowDown',"unicode"=>'');
$icons['Default']['Triangle-ArrowLeft'] = array("class"=>'Triangle-ArrowLeft',"tags"=>'Triangle-ArrowLeft',"unicode"=>'');
$icons['Default']['Triangle-ArrowRight'] = array("class"=>'Triangle-ArrowRight',"tags"=>'Triangle-ArrowRight',"unicode"=>'');
$icons['Default']['Triangle-ArrowUp'] = array("class"=>'Triangle-ArrowUp',"tags"=>'Triangle-ArrowUp',"unicode"=>'');
$icons['Default']['T-Shirt'] = array("class"=>'T-Shirt',"tags"=>'T-Shirt',"unicode"=>'');
$icons['Default']['Up2'] = array("class"=>'Up2',"tags"=>'Up2',"unicode"=>'');
$icons['Default']['Up-3'] = array("class"=>'Up-3',"tags"=>'Up-3',"unicode"=>'');
$icons['Default']['Up--Down'] = array("class"=>'Up--Down',"tags"=>'Up--Down',"unicode"=>'');
$icons['Default']['Up--Down3'] = array("class"=>'Up--Down3',"tags"=>'Up--Down3',"unicode"=>'');
$icons['Default']['Upload2'] = array("class"=>'Upload2',"tags"=>'Upload2',"unicode"=>'');
$icons['Default']['Upload-toCloud'] = array("class"=>'Upload-toCloud',"tags"=>'Upload-toCloud',"unicode"=>'');
$icons['Default']['Usb'] = array("class"=>'Usb',"tags"=>'Usb',"unicode"=>'');
$icons['Default']['Usb-2'] = array("class"=>'Usb-2',"tags"=>'Usb-2',"unicode"=>'');
$icons['Default']['Usb-Cable'] = array("class"=>'Usb-Cable',"tags"=>'Usb-Cable',"unicode"=>'');
$icons['Default']['Vector'] = array("class"=>'Vector',"tags"=>'Vector',"unicode"=>'');
$icons['Default']['Vector-2'] = array("class"=>'Vector-2',"tags"=>'Vector-2',"unicode"=>'');
$icons['Default']['Vector-3'] = array("class"=>'Vector-3',"tags"=>'Vector-3',"unicode"=>'');
$icons['Default']['Vector-4'] = array("class"=>'Vector-4',"tags"=>'Vector-4',"unicode"=>'');
$icons['Default']['Vector-5'] = array("class"=>'Vector-5',"tags"=>'Vector-5',"unicode"=>'');
$icons['Default']['View-Height'] = array("class"=>'View-Height',"tags"=>'View-Height',"unicode"=>'');
$icons['Default']['View-Width'] = array("class"=>'View-Width',"tags"=>'View-Width',"unicode"=>'');
$icons['Default']['Visa'] = array("class"=>'Visa',"tags"=>'Visa',"unicode"=>'');
$icons['Default']['Voicemail'] = array("class"=>'Voicemail',"tags"=>'Voicemail',"unicode"=>'');
$icons['Default']['VPN'] = array("class"=>'VPN',"tags"=>'VPN',"unicode"=>'');
$icons['Default']['Wacom-Tablet'] = array("class"=>'Wacom-Tablet',"tags"=>'Wacom-Tablet',"unicode"=>'');
$icons['Default']['Wallet'] = array("class"=>'Wallet',"tags"=>'Wallet',"unicode"=>'');
$icons['Default']['Warehouse'] = array("class"=>'Warehouse',"tags"=>'Warehouse',"unicode"=>'');
$icons['Default']['Webcam'] = array("class"=>'Webcam',"tags"=>'Webcam',"unicode"=>'');
$icons['Default']['Wifi'] = array("class"=>'Wifi',"tags"=>'Wifi',"unicode"=>'');
$icons['Default']['Wifi-2'] = array("class"=>'Wifi-2',"tags"=>'Wifi-2',"unicode"=>'');
$icons['Default']['Window'] = array("class"=>'Window',"tags"=>'Window',"unicode"=>'');
$icons['Default']['Windows'] = array("class"=>'Windows',"tags"=>'Windows',"unicode"=>'');
$icons['Default']['Windows-Microsoft'] = array("class"=>'Windows-Microsoft',"tags"=>'Windows-Microsoft',"unicode"=>'');
$icons['Default']['Wine-Bottle'] = array("class"=>'Wine-Bottle',"tags"=>'Wine-Bottle',"unicode"=>'');
$icons['Default']['Wine-Glass'] = array("class"=>'Wine-Glass',"tags"=>'Wine-Glass',"unicode"=>'');
$icons['Default']['Wireless'] = array("class"=>'Wireless',"tags"=>'Wireless',"unicode"=>'');
$icons['Default']['asterisk'] = array("class"=>'asterisk',"tags"=>'asterisk',"unicode"=>'');
$icons['Default']['plus'] = array("class"=>'plus',"tags"=>'plus',"unicode"=>'');
$icons['Default']['question'] = array("class"=>'question',"tags"=>'question',"unicode"=>'');
$icons['Default']['minus'] = array("class"=>'minus',"tags"=>'minus',"unicode"=>'');
$icons['Default']['glass'] = array("class"=>'glass',"tags"=>'glass',"unicode"=>'');
$icons['Default']['music'] = array("class"=>'music',"tags"=>'music',"unicode"=>'');
$icons['Default']['search'] = array("class"=>'search',"tags"=>'search',"unicode"=>'');
$icons['Default']['envelope-o'] = array("class"=>'envelope-o',"tags"=>'envelope-o',"unicode"=>'');
$icons['Default']['heart'] = array("class"=>'heart',"tags"=>'heart',"unicode"=>'');
$icons['Default']['star'] = array("class"=>'star',"tags"=>'star',"unicode"=>'');
$icons['Default']['star-o'] = array("class"=>'star-o',"tags"=>'star-o',"unicode"=>'');
$icons['Default']['user'] = array("class"=>'user',"tags"=>'user',"unicode"=>'');
$icons['Default']['film'] = array("class"=>'film',"tags"=>'film',"unicode"=>'');
$icons['Default']['th-large'] = array("class"=>'th-large',"tags"=>'th-large',"unicode"=>'');
$icons['Default']['th'] = array("class"=>'th',"tags"=>'th',"unicode"=>'');
$icons['Default']['th-list'] = array("class"=>'th-list',"tags"=>'th-list',"unicode"=>'');
$icons['Default']['check'] = array("class"=>'check',"tags"=>'check',"unicode"=>'');
$icons['Default']['close'] = array("class"=>'close',"tags"=>'close,remove,times',"unicode"=>'');
$icons['Default']['search-plus'] = array("class"=>'search-plus',"tags"=>'search-plus',"unicode"=>'');
$icons['Default']['search-minus'] = array("class"=>'search-minus',"tags"=>'search-minus',"unicode"=>'');
$icons['Default']['power-off'] = array("class"=>'power-off',"tags"=>'power-off',"unicode"=>'');
$icons['Default']['signal'] = array("class"=>'signal',"tags"=>'signal',"unicode"=>'');
$icons['Default']['cog'] = array("class"=>'cog',"tags"=>'cog,gear',"unicode"=>'');
$icons['Default']['trash-o'] = array("class"=>'trash-o',"tags"=>'trash-o',"unicode"=>'');
$icons['Default']['home'] = array("class"=>'home',"tags"=>'home',"unicode"=>'');
$icons['Default']['file-o'] = array("class"=>'file-o',"tags"=>'file-o',"unicode"=>'');
$icons['Default']['clock-o'] = array("class"=>'clock-o',"tags"=>'clock-o',"unicode"=>'');
$icons['Default']['road'] = array("class"=>'road',"tags"=>'road',"unicode"=>'');
$icons['Default']['download'] = array("class"=>'download',"tags"=>'download',"unicode"=>'');
$icons['Default']['arrow-circle-o-down'] = array("class"=>'arrow-circle-o-down',"tags"=>'arrow-circle-o-down',"unicode"=>'');
$icons['Default']['arrow-circle-o-up'] = array("class"=>'arrow-circle-o-up',"tags"=>'arrow-circle-o-up',"unicode"=>'');
$icons['Default']['inbox'] = array("class"=>'inbox',"tags"=>'inbox',"unicode"=>'');
$icons['Default']['play-circle-o'] = array("class"=>'play-circle-o',"tags"=>'play-circle-o',"unicode"=>'');
$icons['Default']['repeat'] = array("class"=>'repeat',"tags"=>'repeat,rotate-right',"unicode"=>'');
$icons['Default']['refresh'] = array("class"=>'refresh',"tags"=>'refresh',"unicode"=>'');
$icons['Default']['list-alt'] = array("class"=>'list-alt',"tags"=>'list-alt',"unicode"=>'');
$icons['Default']['lock'] = array("class"=>'lock',"tags"=>'lock',"unicode"=>'');
$icons['Default']['flag'] = array("class"=>'flag',"tags"=>'flag',"unicode"=>'');
$icons['Default']['headphones'] = array("class"=>'headphones',"tags"=>'headphones',"unicode"=>'');
$icons['Default']['volume-off'] = array("class"=>'volume-off',"tags"=>'volume-off',"unicode"=>'');
$icons['Default']['volume-down'] = array("class"=>'volume-down',"tags"=>'volume-down',"unicode"=>'');
$icons['Default']['volume-up'] = array("class"=>'volume-up',"tags"=>'volume-up',"unicode"=>'');
$icons['Default']['qrcode'] = array("class"=>'qrcode',"tags"=>'qrcode',"unicode"=>'');
$icons['Default']['barcode'] = array("class"=>'barcode',"tags"=>'barcode',"unicode"=>'');
$icons['Default']['tag'] = array("class"=>'tag',"tags"=>'tag',"unicode"=>'');
$icons['Default']['tags'] = array("class"=>'tags',"tags"=>'tags',"unicode"=>'');
$icons['Default']['book'] = array("class"=>'book',"tags"=>'book',"unicode"=>'');
$icons['Default']['bookmark'] = array("class"=>'bookmark',"tags"=>'bookmark',"unicode"=>'');
$icons['Default']['print'] = array("class"=>'print',"tags"=>'print',"unicode"=>'');
$icons['Default']['camera'] = array("class"=>'camera',"tags"=>'camera',"unicode"=>'');
$icons['Default']['font'] = array("class"=>'font',"tags"=>'font',"unicode"=>'');
$icons['Default']['bold'] = array("class"=>'bold',"tags"=>'bold',"unicode"=>'');
$icons['Default']['italic'] = array("class"=>'italic',"tags"=>'italic',"unicode"=>'');
$icons['Default']['text-height'] = array("class"=>'text-height',"tags"=>'text-height',"unicode"=>'');
$icons['Default']['text-width'] = array("class"=>'text-width',"tags"=>'text-width',"unicode"=>'');
$icons['Default']['align-left'] = array("class"=>'align-left',"tags"=>'align-left',"unicode"=>'');
$icons['Default']['align-center'] = array("class"=>'align-center',"tags"=>'align-center',"unicode"=>'');
$icons['Default']['align-right'] = array("class"=>'align-right',"tags"=>'align-right',"unicode"=>'');
$icons['Default']['align-justify'] = array("class"=>'align-justify',"tags"=>'align-justify',"unicode"=>'');
$icons['Default']['list'] = array("class"=>'list',"tags"=>'list',"unicode"=>'');
$icons['Default']['dedent'] = array("class"=>'dedent',"tags"=>'dedent,outdent',"unicode"=>'');
$icons['Default']['indent'] = array("class"=>'indent',"tags"=>'indent',"unicode"=>'');
$icons['Default']['video-camera'] = array("class"=>'video-camera',"tags"=>'video-camera',"unicode"=>'');
$icons['Default']['image'] = array("class"=>'image',"tags"=>'image,photo,picture-o',"unicode"=>'');
$icons['Default']['pencil'] = array("class"=>'pencil',"tags"=>'pencil',"unicode"=>'');
$icons['Default']['map-marker'] = array("class"=>'map-marker',"tags"=>'map-marker',"unicode"=>'');
$icons['Default']['adjust'] = array("class"=>'adjust',"tags"=>'adjust',"unicode"=>'');
$icons['Default']['tint'] = array("class"=>'tint',"tags"=>'tint',"unicode"=>'');
$icons['Default']['edit'] = array("class"=>'edit',"tags"=>'edit,pencil-square-o',"unicode"=>'');
$icons['Default']['share-square-o'] = array("class"=>'share-square-o',"tags"=>'share-square-o',"unicode"=>'');
$icons['Default']['check-square-o'] = array("class"=>'check-square-o',"tags"=>'check-square-o',"unicode"=>'');
$icons['Default']['arrows'] = array("class"=>'arrows',"tags"=>'arrows',"unicode"=>'');
$icons['Default']['step-backward'] = array("class"=>'step-backward',"tags"=>'step-backward',"unicode"=>'');
$icons['Default']['fast-backward'] = array("class"=>'fast-backward',"tags"=>'fast-backward',"unicode"=>'');
$icons['Default']['backward'] = array("class"=>'backward',"tags"=>'backward',"unicode"=>'');
$icons['Default']['play'] = array("class"=>'play',"tags"=>'play',"unicode"=>'');
$icons['Default']['pause'] = array("class"=>'pause',"tags"=>'pause',"unicode"=>'');
$icons['Default']['stop'] = array("class"=>'stop',"tags"=>'stop',"unicode"=>'');
$icons['Default']['forward'] = array("class"=>'forward',"tags"=>'forward',"unicode"=>'');
$icons['Default']['fast-forward'] = array("class"=>'fast-forward',"tags"=>'fast-forward',"unicode"=>'');
$icons['Default']['step-forward'] = array("class"=>'step-forward',"tags"=>'step-forward',"unicode"=>'');
$icons['Default']['eject'] = array("class"=>'eject',"tags"=>'eject',"unicode"=>'');
$icons['Default']['chevron-left'] = array("class"=>'chevron-left',"tags"=>'chevron-left',"unicode"=>'');
$icons['Default']['chevron-right'] = array("class"=>'chevron-right',"tags"=>'chevron-right',"unicode"=>'');
$icons['Default']['plus-circle'] = array("class"=>'plus-circle',"tags"=>'plus-circle',"unicode"=>'');
$icons['Default']['minus-circle'] = array("class"=>'minus-circle',"tags"=>'minus-circle',"unicode"=>'');
$icons['Default']['times-circle'] = array("class"=>'times-circle',"tags"=>'times-circle',"unicode"=>'');
$icons['Default']['check-circle'] = array("class"=>'check-circle',"tags"=>'check-circle',"unicode"=>'');
$icons['Default']['question-circle'] = array("class"=>'question-circle',"tags"=>'question-circle',"unicode"=>'');
$icons['Default']['info-circle'] = array("class"=>'info-circle',"tags"=>'info-circle',"unicode"=>'');
$icons['Default']['crosshairs'] = array("class"=>'crosshairs',"tags"=>'crosshairs',"unicode"=>'');
$icons['Default']['times-circle-o'] = array("class"=>'times-circle-o',"tags"=>'times-circle-o',"unicode"=>'');
$icons['Default']['check-circle-o'] = array("class"=>'check-circle-o',"tags"=>'check-circle-o',"unicode"=>'');
$icons['Default']['ban'] = array("class"=>'ban',"tags"=>'ban',"unicode"=>'');
$icons['Default']['arrow-left'] = array("class"=>'arrow-left',"tags"=>'arrow-left',"unicode"=>'');
$icons['Default']['arrow-right'] = array("class"=>'arrow-right',"tags"=>'arrow-right',"unicode"=>'');
$icons['Default']['arrow-up'] = array("class"=>'arrow-up',"tags"=>'arrow-up',"unicode"=>'');
$icons['Default']['arrow-down'] = array("class"=>'arrow-down',"tags"=>'arrow-down',"unicode"=>'');
$icons['Default']['mail-forward'] = array("class"=>'mail-forward',"tags"=>'mail-forward,share',"unicode"=>'');
$icons['Default']['expand'] = array("class"=>'expand',"tags"=>'expand',"unicode"=>'');
$icons['Default']['compress'] = array("class"=>'compress',"tags"=>'compress',"unicode"=>'');
$icons['Default']['exclamation-circle'] = array("class"=>'exclamation-circle',"tags"=>'exclamation-circle',"unicode"=>'');
$icons['Default']['gift'] = array("class"=>'gift',"tags"=>'gift',"unicode"=>'');
$icons['Default']['leaf'] = array("class"=>'leaf',"tags"=>'leaf',"unicode"=>'');
$icons['Default']['fire'] = array("class"=>'fire',"tags"=>'fire',"unicode"=>'');
$icons['Default']['eye'] = array("class"=>'eye',"tags"=>'eye',"unicode"=>'');
$icons['Default']['eye-slash'] = array("class"=>'eye-slash',"tags"=>'eye-slash',"unicode"=>'');
$icons['Default']['exclamation-triangle'] = array("class"=>'exclamation-triangle',"tags"=>'exclamation-triangle,warning',"unicode"=>'');
$icons['Default']['plane'] = array("class"=>'plane',"tags"=>'plane',"unicode"=>'');
$icons['Default']['calendar'] = array("class"=>'calendar',"tags"=>'calendar',"unicode"=>'');
$icons['Default']['random'] = array("class"=>'random',"tags"=>'random',"unicode"=>'');
$icons['Default']['comment'] = array("class"=>'comment',"tags"=>'comment',"unicode"=>'');
$icons['Default']['magnet'] = array("class"=>'magnet',"tags"=>'magnet',"unicode"=>'');
$icons['Default']['chevron-up'] = array("class"=>'chevron-up',"tags"=>'chevron-up',"unicode"=>'');
$icons['Default']['chevron-down'] = array("class"=>'chevron-down',"tags"=>'chevron-down',"unicode"=>'');
$icons['Default']['retweet'] = array("class"=>'retweet',"tags"=>'retweet',"unicode"=>'');
$icons['Default']['shopping-cart'] = array("class"=>'shopping-cart',"tags"=>'shopping-cart',"unicode"=>'');
$icons['Default']['folder'] = array("class"=>'folder',"tags"=>'folder',"unicode"=>'');
$icons['Default']['folder-open'] = array("class"=>'folder-open',"tags"=>'folder-open',"unicode"=>'');
$icons['Default']['arrows-v'] = array("class"=>'arrows-v',"tags"=>'arrows-v',"unicode"=>'');
$icons['Default']['arrows-h'] = array("class"=>'arrows-h',"tags"=>'arrows-h',"unicode"=>'');
$icons['Default']['bar-chart'] = array("class"=>'bar-chart',"tags"=>'bar-chart,bar-chart-o',"unicode"=>'');
$icons['Default']['twitter-square'] = array("class"=>'twitter-square',"tags"=>'twitter-square',"unicode"=>'');
$icons['Default']['facebook-square'] = array("class"=>'facebook-square',"tags"=>'facebook-square',"unicode"=>'');
$icons['Default']['camera-retro'] = array("class"=>'camera-retro',"tags"=>'camera-retro',"unicode"=>'');
$icons['Default']['key'] = array("class"=>'key',"tags"=>'key',"unicode"=>'');
$icons['Default']['cogs'] = array("class"=>'cogs',"tags"=>'cogs,gears',"unicode"=>'');
$icons['Default']['comments'] = array("class"=>'comments',"tags"=>'comments',"unicode"=>'');
$icons['Default']['thumbs-o-up'] = array("class"=>'thumbs-o-up',"tags"=>'thumbs-o-up',"unicode"=>'');
$icons['Default']['thumbs-o-down'] = array("class"=>'thumbs-o-down',"tags"=>'thumbs-o-down',"unicode"=>'');
$icons['Default']['star-half'] = array("class"=>'star-half',"tags"=>'star-half',"unicode"=>'');
$icons['Default']['heart-o'] = array("class"=>'heart-o',"tags"=>'heart-o',"unicode"=>'');
$icons['Default']['sign-out'] = array("class"=>'sign-out',"tags"=>'sign-out',"unicode"=>'');
$icons['Default']['linkedin-square'] = array("class"=>'linkedin-square',"tags"=>'linkedin-square',"unicode"=>'');
$icons['Default']['thumb-tack'] = array("class"=>'thumb-tack',"tags"=>'thumb-tack',"unicode"=>'');
$icons['Default']['external-link'] = array("class"=>'external-link',"tags"=>'external-link',"unicode"=>'');
$icons['Default']['sign-in'] = array("class"=>'sign-in',"tags"=>'sign-in',"unicode"=>'');
$icons['Default']['trophy'] = array("class"=>'trophy',"tags"=>'trophy',"unicode"=>'');
$icons['Default']['github-square'] = array("class"=>'github-square',"tags"=>'github-square',"unicode"=>'');
$icons['Default']['upload'] = array("class"=>'upload',"tags"=>'upload',"unicode"=>'');
$icons['Default']['lemon-o'] = array("class"=>'lemon-o',"tags"=>'lemon-o',"unicode"=>'');
$icons['Default']['phone'] = array("class"=>'phone',"tags"=>'phone',"unicode"=>'');
$icons['Default']['square-o'] = array("class"=>'square-o',"tags"=>'square-o',"unicode"=>'');
$icons['Default']['bookmark-o'] = array("class"=>'bookmark-o',"tags"=>'bookmark-o',"unicode"=>'');
$icons['Default']['phone-square'] = array("class"=>'phone-square',"tags"=>'phone-square',"unicode"=>'');
$icons['Default']['twitter'] = array("class"=>'twitter',"tags"=>'twitter',"unicode"=>'');
$icons['Default']['facebook'] = array("class"=>'facebook',"tags"=>'facebook,facebook-f',"unicode"=>'');
$icons['Default']['github'] = array("class"=>'github',"tags"=>'github',"unicode"=>'');
$icons['Default']['unlock'] = array("class"=>'unlock',"tags"=>'unlock',"unicode"=>'');
$icons['Default']['credit-card'] = array("class"=>'credit-card',"tags"=>'credit-card',"unicode"=>'');
$icons['Default']['feed'] = array("class"=>'feed',"tags"=>'feed,rss',"unicode"=>'');
$icons['Default']['hdd-o'] = array("class"=>'hdd-o',"tags"=>'hdd-o',"unicode"=>'');
$icons['Default']['bullhorn'] = array("class"=>'bullhorn',"tags"=>'bullhorn',"unicode"=>'');
$icons['Default']['bell-o'] = array("class"=>'bell-o',"tags"=>'bell-o',"unicode"=>'');
$icons['Default']['certificate'] = array("class"=>'certificate',"tags"=>'certificate',"unicode"=>'');
$icons['Default']['hand-o-right'] = array("class"=>'hand-o-right',"tags"=>'hand-o-right',"unicode"=>'');
$icons['Default']['hand-o-left'] = array("class"=>'hand-o-left',"tags"=>'hand-o-left',"unicode"=>'');
$icons['Default']['hand-o-up'] = array("class"=>'hand-o-up',"tags"=>'hand-o-up',"unicode"=>'');
$icons['Default']['hand-o-down'] = array("class"=>'hand-o-down',"tags"=>'hand-o-down',"unicode"=>'');
$icons['Default']['arrow-circle-left'] = array("class"=>'arrow-circle-left',"tags"=>'arrow-circle-left',"unicode"=>'');
$icons['Default']['arrow-circle-right'] = array("class"=>'arrow-circle-right',"tags"=>'arrow-circle-right',"unicode"=>'');
$icons['Default']['arrow-circle-up'] = array("class"=>'arrow-circle-up',"tags"=>'arrow-circle-up',"unicode"=>'');
$icons['Default']['arrow-circle-down'] = array("class"=>'arrow-circle-down',"tags"=>'arrow-circle-down',"unicode"=>'');
$icons['Default']['globe'] = array("class"=>'globe',"tags"=>'globe',"unicode"=>'');
$icons['Default']['wrench'] = array("class"=>'wrench',"tags"=>'wrench',"unicode"=>'');
$icons['Default']['tasks'] = array("class"=>'tasks',"tags"=>'tasks',"unicode"=>'');
$icons['Default']['filter'] = array("class"=>'filter',"tags"=>'filter',"unicode"=>'');
$icons['Default']['briefcase'] = array("class"=>'briefcase',"tags"=>'briefcase',"unicode"=>'');
$icons['Default']['arrows-alt'] = array("class"=>'arrows-alt',"tags"=>'arrows-alt',"unicode"=>'');
$icons['Default']['group'] = array("class"=>'group',"tags"=>'group,users',"unicode"=>'');
$icons['Default']['chain'] = array("class"=>'chain',"tags"=>'chain,link',"unicode"=>'');
$icons['Default']['cloud'] = array("class"=>'cloud',"tags"=>'cloud',"unicode"=>'');
$icons['Default']['flask'] = array("class"=>'flask',"tags"=>'flask',"unicode"=>'');
$icons['Default']['cut'] = array("class"=>'cut',"tags"=>'cut,scissors',"unicode"=>'');
$icons['Default']['copy'] = array("class"=>'copy',"tags"=>'copy,files-o',"unicode"=>'');
$icons['Default']['paperclip'] = array("class"=>'paperclip',"tags"=>'paperclip',"unicode"=>'');
$icons['Default']['floppy-o'] = array("class"=>'floppy-o',"tags"=>'floppy-o,save',"unicode"=>'');
$icons['Default']['square'] = array("class"=>'square',"tags"=>'square',"unicode"=>'');
$icons['Default']['bars'] = array("class"=>'bars',"tags"=>'bars,navicon,reorder',"unicode"=>'');
$icons['Default']['list-ul'] = array("class"=>'list-ul',"tags"=>'list-ul',"unicode"=>'');
$icons['Default']['list-ol'] = array("class"=>'list-ol',"tags"=>'list-ol',"unicode"=>'');
$icons['Default']['strikethrough'] = array("class"=>'strikethrough',"tags"=>'strikethrough',"unicode"=>'');
$icons['Default']['underline'] = array("class"=>'underline',"tags"=>'underline',"unicode"=>'');
$icons['Default']['table'] = array("class"=>'table',"tags"=>'table',"unicode"=>'');
$icons['Default']['magic'] = array("class"=>'magic',"tags"=>'magic',"unicode"=>'');
$icons['Default']['truck'] = array("class"=>'truck',"tags"=>'truck',"unicode"=>'');
$icons['Default']['pinterest'] = array("class"=>'pinterest',"tags"=>'pinterest',"unicode"=>'');
$icons['Default']['pinterest-square'] = array("class"=>'pinterest-square',"tags"=>'pinterest-square',"unicode"=>'');
$icons['Default']['google-plus-square'] = array("class"=>'google-plus-square',"tags"=>'google-plus-square',"unicode"=>'');
$icons['Default']['google-plus'] = array("class"=>'google-plus',"tags"=>'google-plus',"unicode"=>'');
$icons['Default']['money'] = array("class"=>'money',"tags"=>'money',"unicode"=>'');
$icons['Default']['caret-down'] = array("class"=>'caret-down',"tags"=>'caret-down',"unicode"=>'');
$icons['Default']['caret-up'] = array("class"=>'caret-up',"tags"=>'caret-up',"unicode"=>'');
$icons['Default']['caret-left'] = array("class"=>'caret-left',"tags"=>'caret-left',"unicode"=>'');
$icons['Default']['caret-right'] = array("class"=>'caret-right',"tags"=>'caret-right',"unicode"=>'');
$icons['Default']['columns'] = array("class"=>'columns',"tags"=>'columns',"unicode"=>'');
$icons['Default']['sort'] = array("class"=>'sort',"tags"=>'sort,unsorted',"unicode"=>'');
$icons['Default']['sort-desc'] = array("class"=>'sort-desc',"tags"=>'sort-desc,sort-down',"unicode"=>'');
$icons['Default']['sort-asc'] = array("class"=>'sort-asc',"tags"=>'sort-asc,sort-up',"unicode"=>'');
$icons['Default']['envelope'] = array("class"=>'envelope',"tags"=>'envelope',"unicode"=>'');
$icons['Default']['linkedin'] = array("class"=>'linkedin',"tags"=>'linkedin',"unicode"=>'');
$icons['Default']['rotate-left'] = array("class"=>'rotate-left',"tags"=>'rotate-left,undo',"unicode"=>'');
$icons['Default']['gavel'] = array("class"=>'gavel',"tags"=>'gavel,legal',"unicode"=>'');
$icons['Default']['dashboard'] = array("class"=>'dashboard',"tags"=>'dashboard,tachometer',"unicode"=>'');
$icons['Default']['comment-o'] = array("class"=>'comment-o',"tags"=>'comment-o',"unicode"=>'');
$icons['Default']['comments-o'] = array("class"=>'comments-o',"tags"=>'comments-o',"unicode"=>'');
$icons['Default']['bolt'] = array("class"=>'bolt',"tags"=>'bolt,flash',"unicode"=>'');
$icons['Default']['sitemap'] = array("class"=>'sitemap',"tags"=>'sitemap',"unicode"=>'');
$icons['Default']['umbrella'] = array("class"=>'umbrella',"tags"=>'umbrella',"unicode"=>'');
$icons['Default']['clipboard'] = array("class"=>'clipboard',"tags"=>'clipboard,paste',"unicode"=>'');
$icons['Default']['lightbulb-o'] = array("class"=>'lightbulb-o',"tags"=>'lightbulb-o',"unicode"=>'');
$icons['Default']['exchange'] = array("class"=>'exchange',"tags"=>'exchange',"unicode"=>'');
$icons['Default']['cloud-download'] = array("class"=>'cloud-download',"tags"=>'cloud-download',"unicode"=>'');
$icons['Default']['cloud-upload'] = array("class"=>'cloud-upload',"tags"=>'cloud-upload',"unicode"=>'');
$icons['Default']['user-md'] = array("class"=>'user-md',"tags"=>'user-md',"unicode"=>'');
$icons['Default']['stethoscope'] = array("class"=>'stethoscope',"tags"=>'stethoscope',"unicode"=>'');
$icons['Default']['suitcase'] = array("class"=>'suitcase',"tags"=>'suitcase',"unicode"=>'');
$icons['Default']['bell'] = array("class"=>'bell',"tags"=>'bell',"unicode"=>'');
$icons['Default']['coffee'] = array("class"=>'coffee',"tags"=>'coffee',"unicode"=>'');
$icons['Default']['cutlery'] = array("class"=>'cutlery',"tags"=>'cutlery',"unicode"=>'');
$icons['Default']['file-text-o'] = array("class"=>'file-text-o',"tags"=>'file-text-o',"unicode"=>'');
$icons['Default']['building-o'] = array("class"=>'building-o',"tags"=>'building-o',"unicode"=>'');
$icons['Default']['hospital-o'] = array("class"=>'hospital-o',"tags"=>'hospital-o',"unicode"=>'');
$icons['Default']['ambulance'] = array("class"=>'ambulance',"tags"=>'ambulance',"unicode"=>'');
$icons['Default']['medkit'] = array("class"=>'medkit',"tags"=>'medkit',"unicode"=>'');
$icons['Default']['fighter-jet'] = array("class"=>'fighter-jet',"tags"=>'fighter-jet',"unicode"=>'');
$icons['Default']['beer'] = array("class"=>'beer',"tags"=>'beer',"unicode"=>'');
$icons['Default']['h-square'] = array("class"=>'h-square',"tags"=>'h-square',"unicode"=>'');
$icons['Default']['plus-square'] = array("class"=>'plus-square',"tags"=>'plus-square',"unicode"=>'');
$icons['Default']['angle-double-left'] = array("class"=>'angle-double-left',"tags"=>'angle-double-left',"unicode"=>'');
$icons['Default']['angle-double-right'] = array("class"=>'angle-double-right',"tags"=>'angle-double-right',"unicode"=>'');
$icons['Default']['angle-double-up'] = array("class"=>'angle-double-up',"tags"=>'angle-double-up',"unicode"=>'');
$icons['Default']['angle-double-down'] = array("class"=>'angle-double-down',"tags"=>'angle-double-down',"unicode"=>'');
$icons['Default']['angle-left'] = array("class"=>'angle-left',"tags"=>'angle-left',"unicode"=>'');
$icons['Default']['angle-right'] = array("class"=>'angle-right',"tags"=>'angle-right',"unicode"=>'');
$icons['Default']['angle-up'] = array("class"=>'angle-up',"tags"=>'angle-up',"unicode"=>'');
$icons['Default']['angle-down'] = array("class"=>'angle-down',"tags"=>'angle-down',"unicode"=>'');
$icons['Default']['desktop'] = array("class"=>'desktop',"tags"=>'desktop',"unicode"=>'');
$icons['Default']['laptop'] = array("class"=>'laptop',"tags"=>'laptop',"unicode"=>'');
$icons['Default']['tablet'] = array("class"=>'tablet',"tags"=>'tablet',"unicode"=>'');
$icons['Default']['mobile'] = array("class"=>'mobile',"tags"=>'mobile,mobile-phone',"unicode"=>'');
$icons['Default']['circle-o'] = array("class"=>'circle-o',"tags"=>'circle-o',"unicode"=>'');
$icons['Default']['quote-left'] = array("class"=>'quote-left',"tags"=>'quote-left',"unicode"=>'');
$icons['Default']['quote-right'] = array("class"=>'quote-right',"tags"=>'quote-right',"unicode"=>'');
$icons['Default']['spinner'] = array("class"=>'spinner',"tags"=>'spinner',"unicode"=>'');
$icons['Default']['circle'] = array("class"=>'circle',"tags"=>'circle',"unicode"=>'');
$icons['Default']['mail-reply'] = array("class"=>'mail-reply',"tags"=>'mail-reply,reply',"unicode"=>'');
$icons['Default']['github-alt'] = array("class"=>'github-alt',"tags"=>'github-alt',"unicode"=>'');
$icons['Default']['folder-o'] = array("class"=>'folder-o',"tags"=>'folder-o',"unicode"=>'');
$icons['Default']['folder-open-o'] = array("class"=>'folder-open-o',"tags"=>'folder-open-o',"unicode"=>'');
$icons['Default']['smile-o'] = array("class"=>'smile-o',"tags"=>'smile-o',"unicode"=>'');
$icons['Default']['frown-o'] = array("class"=>'frown-o',"tags"=>'frown-o',"unicode"=>'');
$icons['Default']['meh-o'] = array("class"=>'meh-o',"tags"=>'meh-o',"unicode"=>'');
$icons['Default']['gamepad'] = array("class"=>'gamepad',"tags"=>'gamepad',"unicode"=>'');
$icons['Default']['keyboard-o'] = array("class"=>'keyboard-o',"tags"=>'keyboard-o',"unicode"=>'');
$icons['Default']['flag-o'] = array("class"=>'flag-o',"tags"=>'flag-o',"unicode"=>'');
$icons['Default']['flag-checkered'] = array("class"=>'flag-checkered',"tags"=>'flag-checkered',"unicode"=>'');
$icons['Default']['terminal'] = array("class"=>'terminal',"tags"=>'terminal',"unicode"=>'');
$icons['Default']['code'] = array("class"=>'code',"tags"=>'code',"unicode"=>'');
$icons['Default']['mail-reply-all'] = array("class"=>'mail-reply-all',"tags"=>'mail-reply-all,reply-all',"unicode"=>'');
$icons['Default']['star-half-empty'] = array("class"=>'star-half-empty',"tags"=>'star-half-empty,star-half-full,star-half-o',"unicode"=>'');
$icons['Default']['location-arrow'] = array("class"=>'location-arrow',"tags"=>'location-arrow',"unicode"=>'');
$icons['Default']['crop'] = array("class"=>'crop',"tags"=>'crop',"unicode"=>'');
$icons['Default']['code-fork'] = array("class"=>'code-fork',"tags"=>'code-fork',"unicode"=>'');
$icons['Default']['chain-broken'] = array("class"=>'chain-broken',"tags"=>'chain-broken,unlink',"unicode"=>'');
$icons['Default']['info'] = array("class"=>'info',"tags"=>'info',"unicode"=>'');
$icons['Default']['exclamation'] = array("class"=>'exclamation',"tags"=>'exclamation',"unicode"=>'');
$icons['Default']['superscript'] = array("class"=>'superscript',"tags"=>'superscript',"unicode"=>'');
$icons['Default']['subscript'] = array("class"=>'subscript',"tags"=>'subscript',"unicode"=>'');
$icons['Default']['eraser'] = array("class"=>'eraser',"tags"=>'eraser',"unicode"=>'');
$icons['Default']['puzzle-piece'] = array("class"=>'puzzle-piece',"tags"=>'puzzle-piece',"unicode"=>'');
$icons['Default']['microphone'] = array("class"=>'microphone',"tags"=>'microphone',"unicode"=>'');
$icons['Default']['microphone-slash'] = array("class"=>'microphone-slash',"tags"=>'microphone-slash',"unicode"=>'');
$icons['Default']['shield'] = array("class"=>'shield',"tags"=>'shield',"unicode"=>'');
$icons['Default']['calendar-o'] = array("class"=>'calendar-o',"tags"=>'calendar-o',"unicode"=>'');
$icons['Default']['fire-extinguisher'] = array("class"=>'fire-extinguisher',"tags"=>'fire-extinguisher',"unicode"=>'');
$icons['Default']['rocket'] = array("class"=>'rocket',"tags"=>'rocket',"unicode"=>'');
$icons['Default']['maxcdn'] = array("class"=>'maxcdn',"tags"=>'maxcdn',"unicode"=>'');
$icons['Default']['chevron-circle-left'] = array("class"=>'chevron-circle-left',"tags"=>'chevron-circle-left',"unicode"=>'');
$icons['Default']['chevron-circle-right'] = array("class"=>'chevron-circle-right',"tags"=>'chevron-circle-right',"unicode"=>'');
$icons['Default']['chevron-circle-up'] = array("class"=>'chevron-circle-up',"tags"=>'chevron-circle-up',"unicode"=>'');
$icons['Default']['chevron-circle-down'] = array("class"=>'chevron-circle-down',"tags"=>'chevron-circle-down',"unicode"=>'');
$icons['Default']['html5'] = array("class"=>'html5',"tags"=>'html5',"unicode"=>'');
$icons['Default']['css3'] = array("class"=>'css3',"tags"=>'css3',"unicode"=>'');
$icons['Default']['anchor'] = array("class"=>'anchor',"tags"=>'anchor',"unicode"=>'');
$icons['Default']['unlock-alt'] = array("class"=>'unlock-alt',"tags"=>'unlock-alt',"unicode"=>'');
$icons['Default']['bullseye'] = array("class"=>'bullseye',"tags"=>'bullseye',"unicode"=>'');
$icons['Default']['ellipsis-h'] = array("class"=>'ellipsis-h',"tags"=>'ellipsis-h',"unicode"=>'');
$icons['Default']['ellipsis-v'] = array("class"=>'ellipsis-v',"tags"=>'ellipsis-v',"unicode"=>'');
$icons['Default']['rss-square'] = array("class"=>'rss-square',"tags"=>'rss-square',"unicode"=>'');
$icons['Default']['play-circle'] = array("class"=>'play-circle',"tags"=>'play-circle',"unicode"=>'');
$icons['Default']['ticket'] = array("class"=>'ticket',"tags"=>'ticket',"unicode"=>'');
$icons['Default']['minus-square'] = array("class"=>'minus-square',"tags"=>'minus-square',"unicode"=>'');
$icons['Default']['minus-square-o'] = array("class"=>'minus-square-o',"tags"=>'minus-square-o',"unicode"=>'');
$icons['Default']['level-up'] = array("class"=>'level-up',"tags"=>'level-up',"unicode"=>'');
$icons['Default']['level-down'] = array("class"=>'level-down',"tags"=>'level-down',"unicode"=>'');
$icons['Default']['check-square'] = array("class"=>'check-square',"tags"=>'check-square',"unicode"=>'');
$icons['Default']['pencil-square'] = array("class"=>'pencil-square',"tags"=>'pencil-square',"unicode"=>'');
$icons['Default']['external-link-square'] = array("class"=>'external-link-square',"tags"=>'external-link-square',"unicode"=>'');
$icons['Default']['share-square'] = array("class"=>'share-square',"tags"=>'share-square',"unicode"=>'');
$icons['Default']['compass'] = array("class"=>'compass',"tags"=>'compass',"unicode"=>'');
$icons['Default']['caret-square-o-down'] = array("class"=>'caret-square-o-down',"tags"=>'caret-square-o-down,toggle-down',"unicode"=>'');
$icons['Default']['caret-square-o-up'] = array("class"=>'caret-square-o-up',"tags"=>'caret-square-o-up,toggle-up',"unicode"=>'');
$icons['Default']['caret-square-o-right'] = array("class"=>'caret-square-o-right',"tags"=>'caret-square-o-right,toggle-right',"unicode"=>'');
$icons['Default']['eur'] = array("class"=>'eur',"tags"=>'eur,euro',"unicode"=>'');
$icons['Default']['gbp'] = array("class"=>'gbp',"tags"=>'gbp',"unicode"=>'');
$icons['Default']['dollar'] = array("class"=>'dollar',"tags"=>'dollar,usd',"unicode"=>'');
$icons['Default']['inr'] = array("class"=>'inr',"tags"=>'inr,rupee',"unicode"=>'');
$icons['Default']['cny'] = array("class"=>'cny',"tags"=>'cny,jpy,rmb,yen',"unicode"=>'');
$icons['Default']['rouble'] = array("class"=>'rouble',"tags"=>'rouble,rub,ruble',"unicode"=>'');
$icons['Default']['krw'] = array("class"=>'krw',"tags"=>'krw,won',"unicode"=>'');
$icons['Default']['bitcoin'] = array("class"=>'bitcoin',"tags"=>'bitcoin,btc',"unicode"=>'');
$icons['Default']['file'] = array("class"=>'file',"tags"=>'file',"unicode"=>'');
$icons['Default']['file-text'] = array("class"=>'file-text',"tags"=>'file-text',"unicode"=>'');
$icons['Default']['sort-alpha-asc'] = array("class"=>'sort-alpha-asc',"tags"=>'sort-alpha-asc',"unicode"=>'');
$icons['Default']['sort-alpha-desc'] = array("class"=>'sort-alpha-desc',"tags"=>'sort-alpha-desc',"unicode"=>'');
$icons['Default']['sort-amount-asc'] = array("class"=>'sort-amount-asc',"tags"=>'sort-amount-asc',"unicode"=>'');
$icons['Default']['sort-amount-desc'] = array("class"=>'sort-amount-desc',"tags"=>'sort-amount-desc',"unicode"=>'');
$icons['Default']['sort-numeric-asc'] = array("class"=>'sort-numeric-asc',"tags"=>'sort-numeric-asc',"unicode"=>'');
$icons['Default']['sort-numeric-desc'] = array("class"=>'sort-numeric-desc',"tags"=>'sort-numeric-desc',"unicode"=>'');
$icons['Default']['thumbs-up'] = array("class"=>'thumbs-up',"tags"=>'thumbs-up',"unicode"=>'');
$icons['Default']['thumbs-down'] = array("class"=>'thumbs-down',"tags"=>'thumbs-down',"unicode"=>'');
$icons['Default']['youtube-square'] = array("class"=>'youtube-square',"tags"=>'youtube-square',"unicode"=>'');
$icons['Default']['youtube'] = array("class"=>'youtube',"tags"=>'youtube',"unicode"=>'');
$icons['Default']['xing'] = array("class"=>'xing',"tags"=>'xing',"unicode"=>'');
$icons['Default']['xing-square'] = array("class"=>'xing-square',"tags"=>'xing-square',"unicode"=>'');
$icons['Default']['youtube-play'] = array("class"=>'youtube-play',"tags"=>'youtube-play',"unicode"=>'');
$icons['Default']['dropbox'] = array("class"=>'dropbox',"tags"=>'dropbox',"unicode"=>'');
$icons['Default']['stack-overflow'] = array("class"=>'stack-overflow',"tags"=>'stack-overflow',"unicode"=>'');
$icons['Default']['instagram'] = array("class"=>'instagram',"tags"=>'instagram',"unicode"=>'');
$icons['Default']['flickr'] = array("class"=>'flickr',"tags"=>'flickr',"unicode"=>'');
$icons['Default']['adn'] = array("class"=>'adn',"tags"=>'adn',"unicode"=>'');
$icons['Default']['bitbucket'] = array("class"=>'bitbucket',"tags"=>'bitbucket',"unicode"=>'');
$icons['Default']['bitbucket-square'] = array("class"=>'bitbucket-square',"tags"=>'bitbucket-square',"unicode"=>'');
$icons['Default']['tumblr'] = array("class"=>'tumblr',"tags"=>'tumblr',"unicode"=>'');
$icons['Default']['tumblr-square'] = array("class"=>'tumblr-square',"tags"=>'tumblr-square',"unicode"=>'');
$icons['Default']['long-arrow-down'] = array("class"=>'long-arrow-down',"tags"=>'long-arrow-down',"unicode"=>'');
$icons['Default']['long-arrow-up'] = array("class"=>'long-arrow-up',"tags"=>'long-arrow-up',"unicode"=>'');
$icons['Default']['long-arrow-left'] = array("class"=>'long-arrow-left',"tags"=>'long-arrow-left',"unicode"=>'');
$icons['Default']['long-arrow-right'] = array("class"=>'long-arrow-right',"tags"=>'long-arrow-right',"unicode"=>'');
$icons['Default']['apple'] = array("class"=>'apple',"tags"=>'apple',"unicode"=>'');
$icons['Default']['windows'] = array("class"=>'windows',"tags"=>'windows',"unicode"=>'');
$icons['Default']['android'] = array("class"=>'android',"tags"=>'android',"unicode"=>'');
$icons['Default']['linux'] = array("class"=>'linux',"tags"=>'linux',"unicode"=>'');
$icons['Default']['dribble'] = array("class"=>'dribble',"tags"=>'dribble',"unicode"=>'');
$icons['Default']['skype'] = array("class"=>'skype',"tags"=>'skype',"unicode"=>'');
$icons['Default']['foursquare'] = array("class"=>'foursquare',"tags"=>'foursquare',"unicode"=>'');
$icons['Default']['trello'] = array("class"=>'trello',"tags"=>'trello',"unicode"=>'');
$icons['Default']['female'] = array("class"=>'female',"tags"=>'female',"unicode"=>'');
$icons['Default']['male'] = array("class"=>'male',"tags"=>'male',"unicode"=>'');
$icons['Default']['gittip'] = array("class"=>'gittip',"tags"=>'gittip,gratipay',"unicode"=>'');
$icons['Default']['sun-o'] = array("class"=>'sun-o',"tags"=>'sun-o',"unicode"=>'');
$icons['Default']['moon-o'] = array("class"=>'moon-o',"tags"=>'moon-o',"unicode"=>'');
$icons['Default']['archive'] = array("class"=>'archive',"tags"=>'archive',"unicode"=>'');
$icons['Default']['bug'] = array("class"=>'bug',"tags"=>'bug',"unicode"=>'');
$icons['Default']['vk'] = array("class"=>'vk',"tags"=>'vk',"unicode"=>'');
$icons['Default']['weibo'] = array("class"=>'weibo',"tags"=>'weibo',"unicode"=>'');
$icons['Default']['renren'] = array("class"=>'renren',"tags"=>'renren',"unicode"=>'');
$icons['Default']['pagelines'] = array("class"=>'pagelines',"tags"=>'pagelines',"unicode"=>'');
$icons['Default']['stack-exchange'] = array("class"=>'stack-exchange',"tags"=>'stack-exchange',"unicode"=>'');
$icons['Default']['arrow-circle-o-right'] = array("class"=>'arrow-circle-o-right',"tags"=>'arrow-circle-o-right',"unicode"=>'');
$icons['Default']['arrow-circle-o-left'] = array("class"=>'arrow-circle-o-left',"tags"=>'arrow-circle-o-left',"unicode"=>'');
$icons['Default']['caret-square-o-left'] = array("class"=>'caret-square-o-left',"tags"=>'caret-square-o-left,toggle-left',"unicode"=>'');
$icons['Default']['dot-circle-o'] = array("class"=>'dot-circle-o',"tags"=>'dot-circle-o',"unicode"=>'');
$icons['Default']['wheelchair'] = array("class"=>'wheelchair',"tags"=>'wheelchair',"unicode"=>'');
$icons['Default']['vimeo-square'] = array("class"=>'vimeo-square',"tags"=>'vimeo-square',"unicode"=>'');
$icons['Default']['try'] = array("class"=>'try',"tags"=>'try,turkish-lira',"unicode"=>'');
$icons['Default']['plus-square-o'] = array("class"=>'plus-square-o',"tags"=>'plus-square-o',"unicode"=>'');
$icons['Default']['space-shuttle'] = array("class"=>'space-shuttle',"tags"=>'space-shuttle',"unicode"=>'');
$icons['Default']['slack'] = array("class"=>'slack',"tags"=>'slack',"unicode"=>'');
$icons['Default']['envelope-square'] = array("class"=>'envelope-square',"tags"=>'envelope-square',"unicode"=>'');
$icons['Default']['wordpress'] = array("class"=>'wordpress',"tags"=>'wordpress',"unicode"=>'');
$icons['Default']['openid'] = array("class"=>'openid',"tags"=>'openid',"unicode"=>'');
$icons['Default']['bank'] = array("class"=>'bank',"tags"=>'bank,institution,university',"unicode"=>'');
$icons['Default']['graduation-cap'] = array("class"=>'graduation-cap',"tags"=>'graduation-cap,mortar-board',"unicode"=>'');
$icons['Default']['yahoo'] = array("class"=>'yahoo',"tags"=>'yahoo',"unicode"=>'');
$icons['Default']['google'] = array("class"=>'google',"tags"=>'google',"unicode"=>'');
$icons['Default']['reddit'] = array("class"=>'reddit',"tags"=>'reddit',"unicode"=>'');
$icons['Default']['reddit-square'] = array("class"=>'reddit-square',"tags"=>'reddit-square',"unicode"=>'');
$icons['Default']['stumbleupon-circle'] = array("class"=>'stumbleupon-circle',"tags"=>'stumbleupon-circle',"unicode"=>'');
$icons['Default']['stumbleupon'] = array("class"=>'stumbleupon',"tags"=>'stumbleupon',"unicode"=>'');
$icons['Default']['delicious'] = array("class"=>'delicious',"tags"=>'delicious',"unicode"=>'');
$icons['Default']['digg'] = array("class"=>'digg',"tags"=>'digg',"unicode"=>'');
$icons['Default']['pied-piper-pp'] = array("class"=>'pied-piper-pp',"tags"=>'pied-piper-pp',"unicode"=>'');
$icons['Default']['pied-piper-alt'] = array("class"=>'pied-piper-alt',"tags"=>'pied-piper-alt',"unicode"=>'');
$icons['Default']['drupal'] = array("class"=>'drupal',"tags"=>'drupal',"unicode"=>'');
$icons['Default']['joomla'] = array("class"=>'joomla',"tags"=>'joomla',"unicode"=>'');
$icons['Default']['language'] = array("class"=>'language',"tags"=>'language',"unicode"=>'');
$icons['Default']['fax'] = array("class"=>'fax',"tags"=>'fax',"unicode"=>'');
$icons['Default']['building'] = array("class"=>'building',"tags"=>'building',"unicode"=>'');
$icons['Default']['child'] = array("class"=>'child',"tags"=>'child',"unicode"=>'');
$icons['Default']['paw'] = array("class"=>'paw',"tags"=>'paw',"unicode"=>'');
$icons['Default']['spoon'] = array("class"=>'spoon',"tags"=>'spoon',"unicode"=>'');
$icons['Default']['cube'] = array("class"=>'cube',"tags"=>'cube',"unicode"=>'');
$icons['Default']['cubes'] = array("class"=>'cubes',"tags"=>'cubes',"unicode"=>'');
$icons['Default']['behance'] = array("class"=>'behance',"tags"=>'behance',"unicode"=>'');
$icons['Default']['behance-square'] = array("class"=>'behance-square',"tags"=>'behance-square',"unicode"=>'');
$icons['Default']['steam'] = array("class"=>'steam',"tags"=>'steam',"unicode"=>'');
$icons['Default']['steam-square'] = array("class"=>'steam-square',"tags"=>'steam-square',"unicode"=>'');
$icons['Default']['recycle'] = array("class"=>'recycle',"tags"=>'recycle',"unicode"=>'');
$icons['Default']['automobile'] = array("class"=>'automobile',"tags"=>'automobile,car',"unicode"=>'');
$icons['Default']['cab'] = array("class"=>'cab',"tags"=>'cab,taxi',"unicode"=>'');
$icons['Default']['tree'] = array("class"=>'tree',"tags"=>'tree',"unicode"=>'');
$icons['Default']['spotify'] = array("class"=>'spotify',"tags"=>'spotify',"unicode"=>'');
$icons['Default']['deviantart'] = array("class"=>'deviantart',"tags"=>'deviantart',"unicode"=>'');
$icons['Default']['soundcloud'] = array("class"=>'soundcloud',"tags"=>'soundcloud',"unicode"=>'');
$icons['Default']['database'] = array("class"=>'database',"tags"=>'database',"unicode"=>'');
$icons['Default']['file-pdf-o'] = array("class"=>'file-pdf-o',"tags"=>'file-pdf-o',"unicode"=>'');
$icons['Default']['file-word-o'] = array("class"=>'file-word-o',"tags"=>'file-word-o',"unicode"=>'');
$icons['Default']['file-excel-o'] = array("class"=>'file-excel-o',"tags"=>'file-excel-o',"unicode"=>'');
$icons['Default']['file-powerpoint-o'] = array("class"=>'file-powerpoint-o',"tags"=>'file-powerpoint-o',"unicode"=>'');
$icons['Default']['file-image-o'] = array("class"=>'file-image-o',"tags"=>'file-image-o,file-photo-o,file-picture-o',"unicode"=>'');
$icons['Default']['file-archive-o'] = array("class"=>'file-archive-o',"tags"=>'file-archive-o,file-zip-o',"unicode"=>'');
$icons['Default']['file-audio-o'] = array("class"=>'file-audio-o',"tags"=>'file-audio-o,file-sound-o',"unicode"=>'');
$icons['Default']['file-movie-o'] = array("class"=>'file-movie-o',"tags"=>'file-movie-o,file-video-o',"unicode"=>'');
$icons['Default']['file-code-o'] = array("class"=>'file-code-o',"tags"=>'file-code-o',"unicode"=>'');
$icons['Default']['vine'] = array("class"=>'vine',"tags"=>'vine',"unicode"=>'');
$icons['Default']['codepen'] = array("class"=>'codepen',"tags"=>'codepen',"unicode"=>'');
$icons['Default']['jsfiddle'] = array("class"=>'jsfiddle',"tags"=>'jsfiddle',"unicode"=>'');
$icons['Default']['life-bouy'] = array("class"=>'life-bouy',"tags"=>'life-bouy,life-buoy,life-ring,life-saver,support',"unicode"=>'');
$icons['Default']['circle-o-notch'] = array("class"=>'circle-o-notch',"tags"=>'circle-o-notch',"unicode"=>'');
$icons['Default']['ra'] = array("class"=>'ra',"tags"=>'ra,rebel,resistance',"unicode"=>'');
$icons['Default']['empire'] = array("class"=>'empire',"tags"=>'empire,ge',"unicode"=>'');
$icons['Default']['git-square'] = array("class"=>'git-square',"tags"=>'git-square',"unicode"=>'');
$icons['Default']['git'] = array("class"=>'git',"tags"=>'git',"unicode"=>'');
$icons['Default']['hacker-news'] = array("class"=>'hacker-news',"tags"=>'hacker-news,y-combinator-square,yc-square',"unicode"=>'');
$icons['Default']['tencent-weibo'] = array("class"=>'tencent-weibo',"tags"=>'tencent-weibo',"unicode"=>'');
$icons['Default']['qq'] = array("class"=>'qq',"tags"=>'qq',"unicode"=>'');
$icons['Default']['wechat'] = array("class"=>'wechat',"tags"=>'wechat,weixin',"unicode"=>'');
$icons['Default']['paper-plane'] = array("class"=>'paper-plane',"tags"=>'paper-plane,send',"unicode"=>'');
$icons['Default']['paper-plane-o'] = array("class"=>'paper-plane-o',"tags"=>'paper-plane-o,send-o',"unicode"=>'');
$icons['Default']['history'] = array("class"=>'history',"tags"=>'history',"unicode"=>'');
$icons['Default']['circle-thin'] = array("class"=>'circle-thin',"tags"=>'circle-thin',"unicode"=>'');
$icons['Default']['header'] = array("class"=>'header',"tags"=>'header',"unicode"=>'');
$icons['Default']['paragraph'] = array("class"=>'paragraph',"tags"=>'paragraph',"unicode"=>'');
$icons['Default']['sliders'] = array("class"=>'sliders',"tags"=>'sliders',"unicode"=>'');
$icons['Default']['share-alt'] = array("class"=>'share-alt',"tags"=>'share-alt',"unicode"=>'');
$icons['Default']['share-alt-square'] = array("class"=>'share-alt-square',"tags"=>'share-alt-square',"unicode"=>'');
$icons['Default']['bomb'] = array("class"=>'bomb',"tags"=>'bomb',"unicode"=>'');
$icons['Default']['futbol-o'] = array("class"=>'futbol-o',"tags"=>'futbol-o,soccer-ball-o',"unicode"=>'');
$icons['Default']['tty'] = array("class"=>'tty',"tags"=>'tty',"unicode"=>'');
$icons['Default']['binoculars'] = array("class"=>'binoculars',"tags"=>'binoculars',"unicode"=>'');
$icons['Default']['plug'] = array("class"=>'plug',"tags"=>'plug',"unicode"=>'');
$icons['Default']['slideshare'] = array("class"=>'slideshare',"tags"=>'slideshare',"unicode"=>'');
$icons['Default']['twitch'] = array("class"=>'twitch',"tags"=>'twitch',"unicode"=>'');
$icons['Default']['yelp'] = array("class"=>'yelp',"tags"=>'yelp',"unicode"=>'');
$icons['Default']['newspaper-o'] = array("class"=>'newspaper-o',"tags"=>'newspaper-o',"unicode"=>'');
$icons['Default']['wifi'] = array("class"=>'wifi',"tags"=>'wifi',"unicode"=>'');
$icons['Default']['calculator'] = array("class"=>'calculator',"tags"=>'calculator',"unicode"=>'');
$icons['Default']['paypal'] = array("class"=>'paypal',"tags"=>'paypal',"unicode"=>'');
$icons['Default']['google-wallet'] = array("class"=>'google-wallet',"tags"=>'google-wallet',"unicode"=>'');
$icons['Default']['cc-visa'] = array("class"=>'cc-visa',"tags"=>'cc-visa',"unicode"=>'');
$icons['Default']['cc-mastercard'] = array("class"=>'cc-mastercard',"tags"=>'cc-mastercard',"unicode"=>'');
$icons['Default']['cc-discover'] = array("class"=>'cc-discover',"tags"=>'cc-discover',"unicode"=>'');
$icons['Default']['cc-amex'] = array("class"=>'cc-amex',"tags"=>'cc-amex',"unicode"=>'');
$icons['Default']['cc-paypal'] = array("class"=>'cc-paypal',"tags"=>'cc-paypal',"unicode"=>'');
$icons['Default']['cc-stripe'] = array("class"=>'cc-stripe',"tags"=>'cc-stripe',"unicode"=>'');
$icons['Default']['bell-slash'] = array("class"=>'bell-slash',"tags"=>'bell-slash',"unicode"=>'');
$icons['Default']['bell-slash-o'] = array("class"=>'bell-slash-o',"tags"=>'bell-slash-o',"unicode"=>'');
$icons['Default']['trash'] = array("class"=>'trash',"tags"=>'trash',"unicode"=>'');
$icons['Default']['copyright'] = array("class"=>'copyright',"tags"=>'copyright',"unicode"=>'');
$icons['Default']['at'] = array("class"=>'at',"tags"=>'at',"unicode"=>'');
$icons['Default']['eyedropper'] = array("class"=>'eyedropper',"tags"=>'eyedropper',"unicode"=>'');
$icons['Default']['paint-brush'] = array("class"=>'paint-brush',"tags"=>'paint-brush',"unicode"=>'');
$icons['Default']['birthday-cake'] = array("class"=>'birthday-cake',"tags"=>'birthday-cake',"unicode"=>'');
$icons['Default']['area-chart'] = array("class"=>'area-chart',"tags"=>'area-chart',"unicode"=>'');
$icons['Default']['pie-chart'] = array("class"=>'pie-chart',"tags"=>'pie-chart',"unicode"=>'');
$icons['Default']['line-chart'] = array("class"=>'line-chart',"tags"=>'line-chart',"unicode"=>'');
$icons['Default']['lastfm'] = array("class"=>'lastfm',"tags"=>'lastfm',"unicode"=>'');
$icons['Default']['lastfm-square'] = array("class"=>'lastfm-square',"tags"=>'lastfm-square',"unicode"=>'');
$icons['Default']['toggle-off'] = array("class"=>'toggle-off',"tags"=>'toggle-off',"unicode"=>'');
$icons['Default']['toggle-on'] = array("class"=>'toggle-on',"tags"=>'toggle-on',"unicode"=>'');
$icons['Default']['bicycle'] = array("class"=>'bicycle',"tags"=>'bicycle',"unicode"=>'');
$icons['Default']['bus'] = array("class"=>'bus',"tags"=>'bus',"unicode"=>'');
$icons['Default']['ioxhost'] = array("class"=>'ioxhost',"tags"=>'ioxhost',"unicode"=>'');
$icons['Default']['angellist'] = array("class"=>'angellist',"tags"=>'angellist',"unicode"=>'');
$icons['Default']['cc'] = array("class"=>'cc',"tags"=>'cc',"unicode"=>'');
$icons['Default']['ils'] = array("class"=>'ils',"tags"=>'ils,shekel,sheqel',"unicode"=>'');
$icons['Default']['meanpath'] = array("class"=>'meanpath',"tags"=>'meanpath',"unicode"=>'');
$icons['Default']['buysellads'] = array("class"=>'buysellads',"tags"=>'buysellads',"unicode"=>'');
$icons['Default']['connectdevelop'] = array("class"=>'connectdevelop',"tags"=>'connectdevelop',"unicode"=>'');
$icons['Default']['dashcube'] = array("class"=>'dashcube',"tags"=>'dashcube',"unicode"=>'');
$icons['Default']['forumbee'] = array("class"=>'forumbee',"tags"=>'forumbee',"unicode"=>'');
$icons['Default']['leanpub'] = array("class"=>'leanpub',"tags"=>'leanpub',"unicode"=>'');
$icons['Default']['sellsy'] = array("class"=>'sellsy',"tags"=>'sellsy',"unicode"=>'');
$icons['Default']['shirtsinbulk'] = array("class"=>'shirtsinbulk',"tags"=>'shirtsinbulk',"unicode"=>'');
$icons['Default']['simplybuilt'] = array("class"=>'simplybuilt',"tags"=>'simplybuilt',"unicode"=>'');
$icons['Default']['skyatlas'] = array("class"=>'skyatlas',"tags"=>'skyatlas',"unicode"=>'');
$icons['Default']['cart-plus'] = array("class"=>'cart-plus',"tags"=>'cart-plus',"unicode"=>'');
$icons['Default']['cart-arrow-down'] = array("class"=>'cart-arrow-down',"tags"=>'cart-arrow-down',"unicode"=>'');
$icons['Default']['diamond'] = array("class"=>'diamond',"tags"=>'diamond',"unicode"=>'');
$icons['Default']['ship'] = array("class"=>'ship',"tags"=>'ship',"unicode"=>'');
$icons['Default']['user-secret'] = array("class"=>'user-secret',"tags"=>'user-secret',"unicode"=>'');
$icons['Default']['motorcycle'] = array("class"=>'motorcycle',"tags"=>'motorcycle',"unicode"=>'');
$icons['Default']['street-view'] = array("class"=>'street-view',"tags"=>'street-view',"unicode"=>'');
$icons['Default']['heartbeat'] = array("class"=>'heartbeat',"tags"=>'heartbeat',"unicode"=>'');
$icons['Default']['venus'] = array("class"=>'venus',"tags"=>'venus',"unicode"=>'');
$icons['Default']['mars'] = array("class"=>'mars',"tags"=>'mars',"unicode"=>'');
$icons['Default']['mercury'] = array("class"=>'mercury',"tags"=>'mercury',"unicode"=>'');
$icons['Default']['intersex'] = array("class"=>'intersex',"tags"=>'intersex,transgender',"unicode"=>'');
$icons['Default']['transgender-alt'] = array("class"=>'transgender-alt',"tags"=>'transgender-alt',"unicode"=>'');
$icons['Default']['venus-double'] = array("class"=>'venus-double',"tags"=>'venus-double',"unicode"=>'');
$icons['Default']['mars-double'] = array("class"=>'mars-double',"tags"=>'mars-double',"unicode"=>'');
$icons['Default']['venus-mars'] = array("class"=>'venus-mars',"tags"=>'venus-mars',"unicode"=>'');
$icons['Default']['mars-stroke'] = array("class"=>'mars-stroke',"tags"=>'mars-stroke',"unicode"=>'');
$icons['Default']['mars-stroke-v'] = array("class"=>'mars-stroke-v',"tags"=>'mars-stroke-v',"unicode"=>'');
$icons['Default']['mars-stroke-h'] = array("class"=>'mars-stroke-h',"tags"=>'mars-stroke-h',"unicode"=>'');
$icons['Default']['neuter'] = array("class"=>'neuter',"tags"=>'neuter',"unicode"=>'');
$icons['Default']['genderless'] = array("class"=>'genderless',"tags"=>'genderless',"unicode"=>'');
$icons['Default']['facebook-official'] = array("class"=>'facebook-official',"tags"=>'facebook-official',"unicode"=>'');
$icons['Default']['pinterest-p'] = array("class"=>'pinterest-p',"tags"=>'pinterest-p',"unicode"=>'');
$icons['Default']['whatsapp'] = array("class"=>'whatsapp',"tags"=>'whatsapp',"unicode"=>'');
$icons['Default']['server'] = array("class"=>'server',"tags"=>'server',"unicode"=>'');
$icons['Default']['user-plus'] = array("class"=>'user-plus',"tags"=>'user-plus',"unicode"=>'');
$icons['Default']['user-times'] = array("class"=>'user-times',"tags"=>'user-times',"unicode"=>'');
$icons['Default']['bed'] = array("class"=>'bed',"tags"=>'bed,hotel',"unicode"=>'');
$icons['Default']['viacoin'] = array("class"=>'viacoin',"tags"=>'viacoin',"unicode"=>'');
$icons['Default']['train'] = array("class"=>'train',"tags"=>'train',"unicode"=>'');
$icons['Default']['subway'] = array("class"=>'subway',"tags"=>'subway',"unicode"=>'');
$icons['Default']['medium'] = array("class"=>'medium',"tags"=>'medium',"unicode"=>'');
$icons['Default']['y-combinator'] = array("class"=>'y-combinator',"tags"=>'y-combinator,yc',"unicode"=>'');
$icons['Default']['optin-monster'] = array("class"=>'optin-monster',"tags"=>'optin-monster',"unicode"=>'');
$icons['Default']['opencart'] = array("class"=>'opencart',"tags"=>'opencart',"unicode"=>'');
$icons['Default']['expeditedssl'] = array("class"=>'expeditedssl',"tags"=>'expeditedssl',"unicode"=>'');
$icons['Default']['battery'] = array("class"=>'battery',"tags"=>'battery,battery-4,battery-full',"unicode"=>'');
$icons['Default']['battery-3'] = array("class"=>'battery-3',"tags"=>'battery-3,battery-three-quarters',"unicode"=>'');
$icons['Default']['battery-2'] = array("class"=>'battery-2',"tags"=>'battery-2,battery-half',"unicode"=>'');
$icons['Default']['battery-1'] = array("class"=>'battery-1',"tags"=>'battery-1,battery-quarter',"unicode"=>'');
$icons['Default']['battery-0'] = array("class"=>'battery-0',"tags"=>'battery-0,battery-empty',"unicode"=>'');
$icons['Default']['mouse-pointer'] = array("class"=>'mouse-pointer',"tags"=>'mouse-pointer',"unicode"=>'');
$icons['Default']['i-cursor'] = array("class"=>'i-cursor',"tags"=>'i-cursor',"unicode"=>'');
$icons['Default']['object-group'] = array("class"=>'object-group',"tags"=>'object-group',"unicode"=>'');
$icons['Default']['object-ungroup'] = array("class"=>'object-ungroup',"tags"=>'object-ungroup',"unicode"=>'');
$icons['Default']['sticky-note'] = array("class"=>'sticky-note',"tags"=>'sticky-note',"unicode"=>'');
$icons['Default']['sticky-note-o'] = array("class"=>'sticky-note-o',"tags"=>'sticky-note-o',"unicode"=>'');
$icons['Default']['cc-jcb'] = array("class"=>'cc-jcb',"tags"=>'cc-jcb',"unicode"=>'');
$icons['Default']['cc-diners-club'] = array("class"=>'cc-diners-club',"tags"=>'cc-diners-club',"unicode"=>'');
$icons['Default']['clone'] = array("class"=>'clone',"tags"=>'clone',"unicode"=>'');
$icons['Default']['balance-scale'] = array("class"=>'balance-scale',"tags"=>'balance-scale',"unicode"=>'');
$icons['Default']['hourglass-o'] = array("class"=>'hourglass-o',"tags"=>'hourglass-o',"unicode"=>'');
$icons['Default']['hourglass-1'] = array("class"=>'hourglass-1',"tags"=>'hourglass-1,hourglass-start',"unicode"=>'');
$icons['Default']['hourglass-2'] = array("class"=>'hourglass-2',"tags"=>'hourglass-2,hourglass-half',"unicode"=>'');
$icons['Default']['hourglass-3'] = array("class"=>'hourglass-3',"tags"=>'hourglass-3,hourglass-end',"unicode"=>'');
$icons['Default']['hourglass'] = array("class"=>'hourglass',"tags"=>'hourglass',"unicode"=>'');
$icons['Default']['hand-grab-o'] = array("class"=>'hand-grab-o',"tags"=>'hand-grab-o,hand-rock-o',"unicode"=>'');
$icons['Default']['hand-paper-o'] = array("class"=>'hand-paper-o',"tags"=>'hand-paper-o,hand-stop-o',"unicode"=>'');
$icons['Default']['hand-scissors-o'] = array("class"=>'hand-scissors-o',"tags"=>'hand-scissors-o',"unicode"=>'');
$icons['Default']['hand-lizard-o'] = array("class"=>'hand-lizard-o',"tags"=>'hand-lizard-o',"unicode"=>'');
$icons['Default']['hand-spock-o'] = array("class"=>'hand-spock-o',"tags"=>'hand-spock-o',"unicode"=>'');
$icons['Default']['hand-pointer-o'] = array("class"=>'hand-pointer-o',"tags"=>'hand-pointer-o',"unicode"=>'');
$icons['Default']['hand-peace-o'] = array("class"=>'hand-peace-o',"tags"=>'hand-peace-o',"unicode"=>'');
$icons['Default']['trademark'] = array("class"=>'trademark',"tags"=>'trademark',"unicode"=>'');
$icons['Default']['registered'] = array("class"=>'registered',"tags"=>'registered',"unicode"=>'');
$icons['Default']['creative-commons'] = array("class"=>'creative-commons',"tags"=>'creative-commons',"unicode"=>'');
$icons['Default']['gg'] = array("class"=>'gg',"tags"=>'gg',"unicode"=>'');
$icons['Default']['gg-circle'] = array("class"=>'gg-circle',"tags"=>'gg-circle',"unicode"=>'');
$icons['Default']['tripadvisor'] = array("class"=>'tripadvisor',"tags"=>'tripadvisor',"unicode"=>'');
$icons['Default']['odnoklassniki'] = array("class"=>'odnoklassniki',"tags"=>'odnoklassniki',"unicode"=>'');
$icons['Default']['odnoklassniki-square'] = array("class"=>'odnoklassniki-square',"tags"=>'odnoklassniki-square',"unicode"=>'');
$icons['Default']['get-pocket'] = array("class"=>'get-pocket',"tags"=>'get-pocket',"unicode"=>'');
$icons['Default']['wikipedia-w'] = array("class"=>'wikipedia-w',"tags"=>'wikipedia-w',"unicode"=>'');
$icons['Default']['safari'] = array("class"=>'safari',"tags"=>'safari',"unicode"=>'');
$icons['Default']['chrome'] = array("class"=>'chrome',"tags"=>'chrome',"unicode"=>'');
$icons['Default']['firefox'] = array("class"=>'firefox',"tags"=>'firefox',"unicode"=>'');
$icons['Default']['opera'] = array("class"=>'opera',"tags"=>'opera',"unicode"=>'');
$icons['Default']['internet-explorer'] = array("class"=>'internet-explorer',"tags"=>'internet-explorer',"unicode"=>'');
$icons['Default']['television'] = array("class"=>'television',"tags"=>'television,tv',"unicode"=>'');
$icons['Default']['contao'] = array("class"=>'contao',"tags"=>'contao',"unicode"=>'');
$icons['Default']['500px'] = array("class"=>'500px',"tags"=>'500px',"unicode"=>'');
$icons['Default']['amazon'] = array("class"=>'amazon',"tags"=>'amazon',"unicode"=>'');
$icons['Default']['calendar-plus-o'] = array("class"=>'calendar-plus-o',"tags"=>'calendar-plus-o',"unicode"=>'');
$icons['Default']['calendar-minus-o'] = array("class"=>'calendar-minus-o',"tags"=>'calendar-minus-o',"unicode"=>'');
$icons['Default']['calendar-times-o'] = array("class"=>'calendar-times-o',"tags"=>'calendar-times-o',"unicode"=>'');
$icons['Default']['calendar-check-o'] = array("class"=>'calendar-check-o',"tags"=>'calendar-check-o',"unicode"=>'');
$icons['Default']['industry'] = array("class"=>'industry',"tags"=>'industry',"unicode"=>'');
$icons['Default']['map-pin'] = array("class"=>'map-pin',"tags"=>'map-pin',"unicode"=>'');
$icons['Default']['map-signs'] = array("class"=>'map-signs',"tags"=>'map-signs',"unicode"=>'');
$icons['Default']['map-o'] = array("class"=>'map-o',"tags"=>'map-o',"unicode"=>'');
$icons['Default']['map'] = array("class"=>'map',"tags"=>'map',"unicode"=>'');
$icons['Default']['commenting'] = array("class"=>'commenting',"tags"=>'commenting',"unicode"=>'');
$icons['Default']['commenting-o'] = array("class"=>'commenting-o',"tags"=>'commenting-o',"unicode"=>'');
$icons['Default']['houzz'] = array("class"=>'houzz',"tags"=>'houzz',"unicode"=>'');
$icons['Default']['vimeo'] = array("class"=>'vimeo',"tags"=>'vimeo',"unicode"=>'');
$icons['Default']['black-tie'] = array("class"=>'black-tie',"tags"=>'black-tie',"unicode"=>'');
$icons['Default']['fonticons'] = array("class"=>'fonticons',"tags"=>'fonticons',"unicode"=>'');
$icons['Default']['reddit-alien'] = array("class"=>'reddit-alien',"tags"=>'reddit-alien',"unicode"=>'');
$icons['Default']['edge'] = array("class"=>'edge',"tags"=>'edge',"unicode"=>'');
$icons['Default']['credit-card-alt'] = array("class"=>'credit-card-alt',"tags"=>'credit-card-alt',"unicode"=>'');
$icons['Default']['codiepie'] = array("class"=>'codiepie',"tags"=>'codiepie',"unicode"=>'');
$icons['Default']['modx'] = array("class"=>'modx',"tags"=>'modx',"unicode"=>'');
$icons['Default']['fort-awesome'] = array("class"=>'fort-awesome',"tags"=>'fort-awesome',"unicode"=>'');
$icons['Default']['usb'] = array("class"=>'usb',"tags"=>'usb',"unicode"=>'');
$icons['Default']['product-hunt'] = array("class"=>'product-hunt',"tags"=>'product-hunt',"unicode"=>'');
$icons['Default']['mixcloud'] = array("class"=>'mixcloud',"tags"=>'mixcloud',"unicode"=>'');
$icons['Default']['scribd'] = array("class"=>'scribd',"tags"=>'scribd',"unicode"=>'');
$icons['Default']['pause-circle'] = array("class"=>'pause-circle',"tags"=>'pause-circle',"unicode"=>'');
$icons['Default']['pause-circle-o'] = array("class"=>'pause-circle-o',"tags"=>'pause-circle-o',"unicode"=>'');
$icons['Default']['stop-circle'] = array("class"=>'stop-circle',"tags"=>'stop-circle',"unicode"=>'');
$icons['Default']['stop-circle-o'] = array("class"=>'stop-circle-o',"tags"=>'stop-circle-o',"unicode"=>'');
$icons['Default']['shopping-bag'] = array("class"=>'shopping-bag',"tags"=>'shopping-bag',"unicode"=>'');
$icons['Default']['shopping-basket'] = array("class"=>'shopping-basket',"tags"=>'shopping-basket',"unicode"=>'');
$icons['Default']['hashtag'] = array("class"=>'hashtag',"tags"=>'hashtag',"unicode"=>'');
$icons['Default']['bluetooth'] = array("class"=>'bluetooth',"tags"=>'bluetooth',"unicode"=>'');
$icons['Default']['bluetooth-b'] = array("class"=>'bluetooth-b',"tags"=>'bluetooth-b',"unicode"=>'');
$icons['Default']['percent'] = array("class"=>'percent',"tags"=>'percent',"unicode"=>'');
$icons['Default']['gitlab'] = array("class"=>'gitlab',"tags"=>'gitlab',"unicode"=>'');
$icons['Default']['wpbeginner'] = array("class"=>'wpbeginner',"tags"=>'wpbeginner',"unicode"=>'');
$icons['Default']['wpforms'] = array("class"=>'wpforms',"tags"=>'wpforms',"unicode"=>'');
$icons['Default']['envira'] = array("class"=>'envira',"tags"=>'envira',"unicode"=>'');
$icons['Default']['universal-access'] = array("class"=>'universal-access',"tags"=>'universal-access',"unicode"=>'');
$icons['Default']['wheelchair-alt'] = array("class"=>'wheelchair-alt',"tags"=>'wheelchair-alt',"unicode"=>'');
$icons['Default']['question-circle-o'] = array("class"=>'question-circle-o',"tags"=>'question-circle-o',"unicode"=>'');
$icons['Default']['blind'] = array("class"=>'blind',"tags"=>'blind',"unicode"=>'');
$icons['Default']['audio-description'] = array("class"=>'audio-description',"tags"=>'audio-description',"unicode"=>'');
$icons['Default']['volume-control-phone'] = array("class"=>'volume-control-phone',"tags"=>'volume-control-phone',"unicode"=>'');
$icons['Default']['braille'] = array("class"=>'braille',"tags"=>'braille',"unicode"=>'');
$icons['Default']['assistive-listening-systems'] = array("class"=>'assistive-listening-systems',"tags"=>'assistive-listening-systems',"unicode"=>'');
$icons['Default']['american-sign-language-interpreting'] = array("class"=>'american-sign-language-interpreting',"tags"=>'american-sign-language-interpreting,asl-interpreting',"unicode"=>'');
$icons['Default']['deaf'] = array("class"=>'deaf',"tags"=>'deaf,deafness,hard-of-hearing',"unicode"=>'');
$icons['Default']['glide'] = array("class"=>'glide',"tags"=>'glide',"unicode"=>'');
$icons['Default']['glide-g'] = array("class"=>'glide-g',"tags"=>'glide-g',"unicode"=>'');
$icons['Default']['sign-language'] = array("class"=>'sign-language',"tags"=>'sign-language,signing',"unicode"=>'');
$icons['Default']['low-vision'] = array("class"=>'low-vision',"tags"=>'low-vision',"unicode"=>'');
$icons['Default']['viadeo'] = array("class"=>'viadeo',"tags"=>'viadeo',"unicode"=>'');
$icons['Default']['viadeo-square'] = array("class"=>'viadeo-square',"tags"=>'viadeo-square',"unicode"=>'');
$icons['Default']['snapchat'] = array("class"=>'snapchat',"tags"=>'snapchat',"unicode"=>'');
$icons['Default']['snapchat-ghost'] = array("class"=>'snapchat-ghost',"tags"=>'snapchat-ghost',"unicode"=>'');
$icons['Default']['snapchat-square'] = array("class"=>'snapchat-square',"tags"=>'snapchat-square',"unicode"=>'');
$icons['Default']['pied-piper'] = array("class"=>'pied-piper',"tags"=>'pied-piper',"unicode"=>'');
$icons['Default']['first-order'] = array("class"=>'first-order',"tags"=>'first-order',"unicode"=>'');
$icons['Default']['yoast'] = array("class"=>'yoast',"tags"=>'yoast',"unicode"=>'');
$icons['Default']['themeisle'] = array("class"=>'themeisle',"tags"=>'themeisle',"unicode"=>'');
$icons['Default']['google-plus-circle'] = array("class"=>'google-plus-circle',"tags"=>'google-plus-circle,google-plus-official',"unicode"=>'');
$icons['Default']['fa'] = array("class"=>'fa',"tags"=>'fa,font-awesome',"unicode"=>'');
$icons['Default']['handshake-o'] = array("class"=>'handshake-o',"tags"=>'handshake-o',"unicode"=>'');
$icons['Default']['envelope-open'] = array("class"=>'envelope-open',"tags"=>'envelope-open',"unicode"=>'');
$icons['Default']['envelope-open-o'] = array("class"=>'envelope-open-o',"tags"=>'envelope-open-o',"unicode"=>'');
$icons['Default']['linode'] = array("class"=>'linode',"tags"=>'linode',"unicode"=>'');
$icons['Default']['address-book'] = array("class"=>'address-book',"tags"=>'address-book',"unicode"=>'');
$icons['Default']['address-book-o'] = array("class"=>'address-book-o',"tags"=>'address-book-o',"unicode"=>'');
$icons['Default']['address-card'] = array("class"=>'address-card',"tags"=>'address-card,vcard',"unicode"=>'');
$icons['Default']['address-card-o'] = array("class"=>'address-card-o',"tags"=>'address-card-o,vcard-o',"unicode"=>'');
$icons['Default']['user-circle'] = array("class"=>'user-circle',"tags"=>'user-circle',"unicode"=>'');
$icons['Default']['user-circle-o'] = array("class"=>'user-circle-o',"tags"=>'user-circle-o',"unicode"=>'');
$icons['Default']['user-o'] = array("class"=>'user-o',"tags"=>'user-o',"unicode"=>'');
$icons['Default']['id-badge'] = array("class"=>'id-badge',"tags"=>'id-badge',"unicode"=>'');
$icons['Default']['drivers-license'] = array("class"=>'drivers-license',"tags"=>'drivers-license,id-card',"unicode"=>'');
$icons['Default']['drivers-license-o'] = array("class"=>'drivers-license-o',"tags"=>'drivers-license-o,id-card-o',"unicode"=>'');
$icons['Default']['quora'] = array("class"=>'quora',"tags"=>'quora',"unicode"=>'');
$icons['Default']['free-code-camp'] = array("class"=>'free-code-camp',"tags"=>'free-code-camp',"unicode"=>'');
$icons['Default']['telegram'] = array("class"=>'telegram',"tags"=>'telegram',"unicode"=>'');
$icons['Default']['thermometer'] = array("class"=>'thermometer',"tags"=>'thermometer,thermometer-4,thermometer-full',"unicode"=>'');
$icons['Default']['thermometer-3'] = array("class"=>'thermometer-3',"tags"=>'thermometer-3,thermometer-three-quarters',"unicode"=>'');
$icons['Default']['thermometer-2'] = array("class"=>'thermometer-2',"tags"=>'thermometer-2,thermometer-half',"unicode"=>'');
$icons['Default']['thermometer-1'] = array("class"=>'thermometer-1',"tags"=>'thermometer-1,thermometer-quarter',"unicode"=>'');
$icons['Default']['thermometer-0'] = array("class"=>'thermometer-0',"tags"=>'thermometer-0,thermometer-empty',"unicode"=>'');
$icons['Default']['shower'] = array("class"=>'shower',"tags"=>'shower',"unicode"=>'');
$icons['Default']['bath'] = array("class"=>'bath',"tags"=>'bath,bathtub,s15',"unicode"=>'');
$icons['Default']['podcast'] = array("class"=>'podcast',"tags"=>'podcast',"unicode"=>'');
$icons['Default']['window-maximize'] = array("class"=>'window-maximize',"tags"=>'window-maximize',"unicode"=>'');
$icons['Default']['window-minimize'] = array("class"=>'window-minimize',"tags"=>'window-minimize',"unicode"=>'');
$icons['Default']['window-restore'] = array("class"=>'window-restore',"tags"=>'window-restore',"unicode"=>'');
$icons['Default']['times-rectangle'] = array("class"=>'times-rectangle',"tags"=>'times-rectangle,window-close',"unicode"=>'');
$icons['Default']['times-rectangle-o'] = array("class"=>'times-rectangle-o',"tags"=>'times-rectangle-o,window-close-o',"unicode"=>'');
$icons['Default']['bandcamp'] = array("class"=>'bandcamp',"tags"=>'bandcamp',"unicode"=>'');
$icons['Default']['grav'] = array("class"=>'grav',"tags"=>'grav',"unicode"=>'');
$icons['Default']['etsy'] = array("class"=>'etsy',"tags"=>'etsy',"unicode"=>'');
$icons['Default']['imdb'] = array("class"=>'imdb',"tags"=>'imdb',"unicode"=>'');
$icons['Default']['ravelry'] = array("class"=>'ravelry',"tags"=>'ravelry',"unicode"=>'');
$icons['Default']['eercast'] = array("class"=>'eercast',"tags"=>'eercast',"unicode"=>'');
$icons['Default']['microchip'] = array("class"=>'microchip',"tags"=>'microchip',"unicode"=>'');
$icons['Default']['snowflake-o'] = array("class"=>'snowflake-o',"tags"=>'snowflake-o',"unicode"=>'');
$icons['Default']['superpowers'] = array("class"=>'superpowers',"tags"=>'superpowers',"unicode"=>'');
$icons['Default']['wpexplorer'] = array("class"=>'wpexplorer',"tags"=>'wpexplorer',"unicode"=>'');
$icons['Default']['meetup'] = array("class"=>'meetup',"tags"=>'meetup',"unicode"=>'');