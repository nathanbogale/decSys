var $j = jQuery.noConflict();



$j( document ).on( 'ready', function() {

    "use strict";


    dprInitializeScatPortfolioParalax();

} );


function dprInitializeScatPortfolioParalax() {

  if(jQuery('body').find('.scroll-paralax').length>0){

  var controller = new ScrollMagic.Controller();

  jQuery('.scroll-paralax').each(function(index, elem){

    var tween = 'tween-'+index;

    tween = new TimelineMax();

    var lengthBox = jQuery(elem).find('.portfolio-item').length;
   
    for(var i=0; i < lengthBox; i++){

        var speed = 0.5;

		

		var scroll_x= 0;

		var scroll_y= -80;

		tween.to(jQuery(elem).find('.portfolio-item:eq('+i+')'), 1, {x:-(scroll_x*speed),y:-(scroll_y*speed), ease: Linear.easeNone})

		
    }


    new ScrollMagic.Scene({triggerElement: elem, duration: jQuery(this).outerHeight(), triggerHook:.7})

    .setTween(tween)

    .addTo(controller);

  })

	}

}