<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$output = $navigation_style = $el_id = $el_class =  $custom_el_css = $link = "";

$box_link_html = $section_atts = '';

$atts = vc_map_get_attributes( 'dpr_fp_slider_section', $atts );
extract( $atts );

$el_class = $this->getExtraClass( $el_class );
$css_classes = array(
	'dpr-fps-section',
	$el_class,
);
$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->settings['base'], $atts ) );

$unique_id = uniqid('dpr-fps-section-').'-'.rand(1,9999);

if ($el_id != '') {
	$unique_id = $el_id;
}

/* * ************************
 * Styles and custom CSS
 * *********************** */
if(isset($navigation_style) && $navigation_style != '') {
	$section_atts .= ' data-navigation="overlapping-style-'.$navigation_style.'"';
}

/* * ************************
 * Partial HTML.
 * *********************** */

if(isset($link) && $link  != '') {
	$box_link_attributes    = array();
	if (function_exists('vc_build_link')) {
		$box_link = ( '||' === $link ) ? '' : $link;
		$box_link = vc_build_link( $link );
	
		$link_href   = $box_link['url'];
		$link_title  = $box_link['title'];
		$link_rel  = $box_link['rel'];
		$link_target = strlen($box_link['target']) > 0 ? $box_link['target'] : '_self';
	
		$box_link_attributes[] = 'href="' . esc_url( trim( $link_href ) ) . '"';
		$box_link_attributes[] = 'title="' . esc_attr( trim( $link_title ) ) . '"';
		$box_link_attributes[] = 'target="' . esc_attr( trim( $link_target ) ) . '"';
		$box_link_attributes[] = 'rel="' . esc_attr( trim( $link_rel ) ) . '"';
	}
	if($box_link['url'] != '') {
			$box_link_html .= '<a class="dpr-cover-link" '.implode(' ',$box_link_attributes).'></a>';
	}
}

$output .= '<div id="'.esc_attr($unique_id).'" class="'.esc_attr($css_class).'"'.$section_atts.'>';
$output .= do_shortcode($content);
$output .= $box_link_html;
if(!empty($custom_el_css)) {
		$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>");'
						. '})(jQuery);'
					. '</script>';
}
$output .= "</div>";

echo $output;

