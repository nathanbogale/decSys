<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$output = $item_style = "";

$atts = vc_map_get_attributes( 'dpr_split_slider_item', $atts );
extract( $atts );


$background_color = esc_attr($background_color);
$item_padding = esc_attr($item_padding);

if($background_color != '' || $background_image != '' || $item_padding != '') {
    $item_style .= "style='";

    if ($background_color != '') {
        $item_style .= 'background-color:'.$background_color.';';
    }

    if ($background_image != '') {
        $background_image_src = wp_get_attachment_url( $background_image );
        $item_style .= 'background-image:url("'.$background_image_src.'");';
    }

    if ($alignment != '') {
        $item_style .= 'text-align:'.$alignment.';';
    }

    if ($item_padding != '') {
        $item_style .= 'padding:0px '.$item_padding.'px;';
    }

    $item_style .= "'";
}


$output .= "<div class='ms-section' ".$item_style.">";
$output .= do_shortcode($content);
$output .= "</div>";

echo $output;

