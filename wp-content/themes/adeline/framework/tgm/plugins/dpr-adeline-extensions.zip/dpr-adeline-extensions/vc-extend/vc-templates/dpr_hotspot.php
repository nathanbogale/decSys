<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$output = $id = $el_class = $custom_el_css = $data_atts = '';

$atts = vc_map_get_attributes($this->getShortcode(), $atts);
extract( $atts );

if(isset($image) && !empty($image)) {
	
	$id = uniqid('dpr-hotspoted-image');
		wp_enqueue_style('dpr-hotspot-css', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/css/hotspot.css');
		wp_enqueue_script('dpr-hotspot', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/jquery.hotspot.js', array('jquery'), null, true);	
		wp_enqueue_script('velocity', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/velocity.js', array('jquery'), null, false);	
		wp_enqueue_script('dpr-waypoints', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/waypoints.min.js', array('jquery'), null, true);
	
	$add_classes = 	$this->getExtraClass( $el_class ) . $this->getCSSAnimation( $css_animation ) ;

	/*Data attributes*/
	if(!empty($module_animation)) {
		$data_atts .= ' data-animate="1"  data-animate-type="'.esc_attr($module_animation).'" ';
	}
	
	if(!empty($hotspot_data)) {
		$data_atts .= ' data-hotspot-content="'.esc_attr($hotspot_data).'" ';
	}
	
	if(!empty($hotspot_action)) {
		$el_class .= ' dpr-action-'.$hotspot_action;
		$data_atts .= ' data-action="'.esc_attr($hotspot_action).'" ';
	}
	$custom_el_css = '';
	
	/*Marker CSS*/
	
	if(isset($marker_style) && $marker_style == 'image' && isset($marker_image) && !empty($marker_image)) {
		$data_atts .= ' data-hotspot-class="HotspotPlugin_Hotspot dpHotspotImageMarker" ';
		$marker_img_src = dpr_get_attachment_image_src($marker_image, 'full');
		$custom_el_css .= '#'.esc_js($id).' .dpr-hotspot-wrapper .HotspotPlugin_Hotspot.dpHotspotImageMarker {'
							. 'width: '.esc_js($marker_img_src[1]).'px;'
							. 'height: '.esc_js($marker_img_src[2]).'px;'
							. 'margin-left: -'.esc_js($marker_img_src[1] / 2).'px;'
							. 'margin-top: -'.esc_js($marker_img_src[2] / 2).'px;'
							. 'background-image: url('.esc_url($marker_img_src[0]).');'
					. '}';
	}
	
	/*Tooltip class*/
	if(isset($tooltip_position) && !empty($tooltip_position)) {
		$el_class .= ' dpr-tooltip-position-'.$tooltip_position;
	}
	
	if(isset($tooltip_content_align) && !empty($tooltip_content_align)) {
		$el_class .= ' dpr-tooltip-text-align-'.$tooltip_content_align;
	}
	
	/*Dynamic css*/
	if(isset($tooltip_width) && $tooltip_width != '') {
		$custom_el_css .= '.'.$id.' .dpr-hotspot-wrapper .HotspotPlugin_Hotspot  div { min-width: '.esc_js($tooltip_width).'px;}';
	}
	
	if(isset($tooltip_bg_color) && $tooltip_bg_color != '') {
		$custom_el_css .= '.'.esc_js($id).' .dpr-hotspot-wrapper .HotspotPlugin_Hotspot  div { background: '.esc_js($tooltip_bg_color).';}';
	}
	if(isset($tooltip_text_color) && $tooltip_text_color != '') {
		$custom_el_css .= '.'.esc_js($id).' .dpr-hotspot-wrapper .HotspotPlugin_Hotspot  div, .'.esc_js($id).' .dpr-hotspot-wrapper .HotspotPlugin_Hotspot > div > .Hotspot_Title, .'.esc_js($id).' .dpr-hotspot-wrapper .HotspotPlugin_Hotspot > div > .Hotspot_Message { color: '.esc_js($tooltip_text_color).';}';
	}
	if(isset($marker_bg) && $marker_bg != '') {
		$custom_el_css .= '.'.esc_js($id).' .dpr-hotspot-wrapper .HotspotPlugin_Hotspot:not(.dpHotspotImageMarker):before { background: '.esc_js($marker_bg).';}';
	}
	
	if(isset($marker_inner_bg) && $marker_inner_bg != '') {
		$custom_el_css .= '.'.esc_js($id).' .dpr-hotspot-wrapper .HotspotPlugin_Hotspot:not(.dpHotspotImageMarker):after { background: '.esc_js($marker_inner_bg).';}';
	}
	if ($custom_el_css !='') { 
	$custom_el_css = esc_js($custom_el_css);
	}
	
	$img_src = dpr_get_attachment_image_src($image, 'full');
	
	$alt_text = get_post_meta($image , '_wp_attachment_image_alt', true);
	
	$img_html = '<img src="'.esc_attr($img_src[0]).'" alt ="'.esc_attr($alt_text).'" width="'.esc_attr($img_src[1]).'" height="'.esc_attr($img_src[2]).'"/>';
	
	$output .= '<div id="'.esc_attr($id).'" class="dpr-hotspot-wrapper-wrapper '.$add_classes.' '.$el_class.' '.esc_attr($id).'">';
		$output .= '<div class="dpr-hotspot-wrapper" '.$data_atts.'>';
			$output .= '<div class="dpr-hotspot-image-cover '.esc_attr($el_class).'">';
				$output .= $img_html;
			$output .= '</div>';
	$output .= '</div>';
		if($custom_el_css != '') {
			$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>")'
						. '})(jQuery);'
					. '</script>';
		}
	
}
	$output .= '</div>';

echo $output;