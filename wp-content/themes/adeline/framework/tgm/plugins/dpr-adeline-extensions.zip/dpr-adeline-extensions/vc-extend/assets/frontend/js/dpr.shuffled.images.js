var $j = jQuery.noConflict();



$j( document ).on( 'ready', function() {

	"use strict";

	// Custom select

	dprInitializeShuffledImages();

} );



/* ==============================================

SHUFFLED IMAGES

============================================== */

function dprInitializeShuffledImages() {

	"use strict"


	if($j(".dpr-shuffled-images").length) {
      $j(".dpr-shuffled-images").each(function(){

        var $self = $j(this),
			$animationStarter = $self.find('.animation-starter'),
			$shuffleItems = $self.find(".dpr-si-item");
		  
		    $shuffleItems.each(function() {
                var $item = $j(this);
                $item.on("click", function() {
                    if (!$shuffleItems.last().is($item)) return $item.addClass("dpr-out dpr-animating").siblings().addClass("dpr-animating-siblings"), $item.detach(), $item.insertAfter($shuffleItems.last()), setTimeout(function() {
                        $item.removeClass("dpr-out")
                    }, 200), setTimeout(function() {
                        $item.removeClass("dpr-animating").siblings().removeClass("dpr-animating-siblings")
                    }, 1200), $shuffleItems = $self.find(".dpr-si-item"), !1
                })
            });
		
		if($self.hasClass('dpr-appear-animation')) {
		$animationStarter.on('on-in-viewport', function () {
			 $self.addClass("dpr-appeared");
			 $self.find("img").one("animationend webkitAnimationEnd MSAnimationEnd oAnimationEnd", function() {
                    $j(this).addClass("dpr-animation-done")
                })

		});
		}



      });
	}


}