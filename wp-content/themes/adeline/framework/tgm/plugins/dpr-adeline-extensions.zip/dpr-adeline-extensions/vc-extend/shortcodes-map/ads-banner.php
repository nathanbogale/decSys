<?php

// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}

/*

* Add-on Name: DP Add Banner

*/



class WPBakeryShortCode_DPR_Ads_Banner extends WPBakeryShortCode {}



vc_map(

	array(

		'name'					=> esc_html__('DP Ads Banner', 'dpr-adeline-extensions'),

		'base'					=> 'dpr_ads_banner',

		"icon"					=> 'icon-dpr-ads-banner',

		"class"					=> 'dpr_ads_banner',

  		"category" =>array( esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions')),

		'description'			=> esc_html__('Display simple ads image banner', 'dpr-adeline-extensions'),

		'params'				=> array(

			array(

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose content over image position .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Content position', 'dpr-adeline-extensions'),

				'type'				=> 'dpr_image_select',

				'param_name'		=> 'content_position',

				'value' 			=> 'lb',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'options'			=> array(

					'lb'			=> array(

						'label'			=> esc_html__('Left bottom', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'ads-banner/left-bottom.png'

					),

					'lc'			=> array(

						'label'			=> esc_html__('Left center', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'ads-banner/left-center.png'

					),

					'lt'			=> array(

						'label'			=> esc_html__('Left Top', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'ads-banner/left-top.png'

					),

					'cb'			=> array(

						'label'			=> esc_html__('Center bottom', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'ads-banner/center-bottom.png'

					),

					'cc'			=> array(

						'label'			=> esc_html__('Center', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'ads-banner/center-center.png'

					),

					'ct'			=> array(

						'label'			=> esc_html__('Center Top', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'ads-banner/center-top.png'

					),

					'rb'			=> array(

						'label'			=> esc_html__('Right bottom', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'ads-banner/right-bottom.png'

					),

					'rc'			=> array(

						'label'			=> esc_html__('Right center', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'ads-banner/right-center.png'

					),

					'rt'			=> array(

						'label'			=> esc_html__('Right Top', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'ads-banner/right-top.png'

					),

				)

			),

/*EXTRA FEATURES */

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Additional Settings', 'dpr-adeline-extensions' ),

				'param_name'       => 'extra_features_title',

				'edit_field_class' => 'vc_column vc_col-sm-12',

			),

			vc_map_add_css_animation( false ),

		    array(

				'type' => 'textfield',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Extra Class Name', 'dpr-adeline-extensions'),

				'param_name' => 'el_class',

			),

/*CONTENT */

			array(

				'type'				=> 'attach_image',

				'param_name'		=> 'image',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select image from media library', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Image', 'dpr-adeline-extensions'),

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'group'			   => esc_html('Content','dpr-adeline-extensions')

			),

			array(

				'type' => 'number',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select the width for the image', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Image width', 'dpr-adeline-extensions'),

				'param_name' => 'image_width',

				'suffix'	=> 'px',

				'value' => 600,

				'edit_field_class' => 'vc_column vc_col-sm-4',

				'group'			   => esc_html('Content','dpr-adeline-extensions')

			),

			array(

				'type' 				=> 'number',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select the height for the image', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Image height', 'dpr-adeline-extensions'),

				'param_name'		=> 'image_height',

				'suffix'			=> 'px',

				'value' 			=> 600,

				'edit_field_class' 	=> 'vc_column vc_col-sm-4',

				'group'			   	=> esc_html('Content','dpr-adeline-extensions')

			),

		    array(

				'type' => 'textarea',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set ads title.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Title', 'dpr-adeline-extensions'),

				'param_name' => 'title',

				'group'			   	=> esc_html('Content','dpr-adeline-extensions')

			),

		    array(

				'type' => 'textarea',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set ads subtitle.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Subtitle', 'dpr-adeline-extensions'),

				'param_name' => 'subtitle',

				'group'			   	=> esc_html('Content','dpr-adeline-extensions')

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose subtitle position.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Subtitle Position', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_pos',

				'value'				=> 'above',

				'edit_field_class'	=> 'vc_column vc_col-sm-12  ',

				'options'			=> array(

					esc_html__('Above Title', 'dpr-adeline-extensions')	=> 'above',

					esc_html__('Bellow', 'dpr-adeline-extensions')	=> 'bellow'

				),

				'group'			   	=> esc_html('Content','dpr-adeline-extensions')

			),

		    array(

				'type' => 'textfield',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set ads info badge content.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Info Badge', 'dpr-adeline-extensions'),

				'param_name' => 'info',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'group'			   	=> esc_html('Content','dpr-adeline-extensions')

			),

			array(

				'type'				=> 'vc_link',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Add a custom link or select existing page. You can remove existing link as well.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Link URL', 'dpr-adeline-extensions'),

				'param_name'		=> 'link',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'group'			   	=> esc_html('Content','dpr-adeline-extensions')

			),

/* STYLE */			

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Colors Settings', 'dpr-adeline-extensions' ),

				'param_name'       => 'style_title_1',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose color for title', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Title Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions')

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose color for subtitle', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Subtitle Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions')

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose color for info badge', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Info badge background', 'dpr-adeline-extensions'),

				'param_name'		=> 'info_bg',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions')

			),

			array(

				'type' 				=> 'number',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select border radius info badge', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Info badge border radius', 'dpr-adeline-extensions'),

				'param_name'		=> 'info_border_radius',

				'suffix'			=> 'px',

				'value' 			=> '',

				'edit_field_class' 	=> 'vc_column vc_col-sm-6',

				'group'			   	=> esc_html('Style','dpr-adeline-extensions')

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Hover Mask Settings', 'dpr-adeline-extensions' ),

				'param_name'       => 'style_title_2',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable colored mask on hover', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Use Mask on Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_hover_mask',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose hover overlay mask style.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Overlay Mask Type', 'dpr-adeline-extensions'),

				'param_name'		=> 'mask_type',

				'value'				=> 'solid',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'options'			=> array(

					esc_html__('Solid', 'dpr-adeline-extensions')	=> 'solid',

					esc_html__('Gradient', 'dpr-adeline-extensions')	=> 'gradient'

				),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'use_hover_mask', 'value' => array('yes')),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose color for hover mask overlay', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Mask Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'mask_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'mask_type', 'value' => array('solid')),

			),

			array(

				'type' => 'dpr_gradient_picker',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the gradient for mask in overlay style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Hover Overlay Mask Gradient', 'dpr-adeline-extensions'),

				'param_name' => 'mask_gradient',

				'value' => '45;0%/rgba(75, 50, 255, 0.5);100%/rgba(13, 193, 255, 0.5)',

				'group'	=> esc_html__('Style', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'mask_type', 'value' => 'gradient'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose color for title', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Title Color: Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_color_hover',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'use_hover_mask', 'value' => array('yes')),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose color for subtitle', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Subtitle Color: Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_color_hover',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'use_hover_mask', 'value' => array('yes')),

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Shadows & Animation', 'dpr-adeline-extensions' ),

				'param_name'       => 'style_title_3',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable scale up image animation on hover', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Animate Image on Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'animate_img_on_hover',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => 'yes',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'dropdown',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set shadow for banner.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Shadow', 'dpr-adeline-extensions'),

				'param_name' => 'shadow',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'value' => array(

						__('None', 'dpr-adeline-extensions') => '',

						__('Shadow Depth 1', 'dpr-adeline-extensions') => '1',

						__('Shadow Depth 2', 'dpr-adeline-extensions') => '2',

						__('Shadow Depth 3', 'dpr-adeline-extensions') => '3',

						__('Shadow Depth 4', 'dpr-adeline-extensions') => '4',

						__('Shadow Depth 5', 'dpr-adeline-extensions') => '5',

						__('Shadow Depth 6', 'dpr-adeline-extensions') => '6',

						__('Custom Shadow', 'dpr-adeline-extensions') => 'custom',

					   ),

				'group'	=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				"type" => "dpr_shadow_picker",

				"class" => "",

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom shadow for banner.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom Shadow', 'dpr-adeline-extensions'),

				"param_name" => "shadow_custom",

				"value" => "none||||||",

				'dependency'		=> array('element' => 'shadow', 'value' => array('custom')),

				'group'	=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'dropdown',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set shadow for category tile in hover state.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Shadow: Hover', 'dpr-adeline-extensions'),

				'param_name' => 'shadow_hover',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'value' => array(

						__('None', 'dpr-adeline-extensions') => '',

						__('Shadow Depth 1', 'dpr-adeline-extensions') => '1',

						__('Shadow Depth 2', 'dpr-adeline-extensions') => '2',

						__('Shadow Depth 3', 'dpr-adeline-extensions') => '3',

						__('Shadow Depth 4', 'dpr-adeline-extensions') => '4',

						__('Shadow Depth 5', 'dpr-adeline-extensions') => '5',

						__('Shadow Depth 6', 'dpr-adeline-extensions') => '6',

						__('Custom Shadow', 'dpr-adeline-extensions') => 'custom',

					   ),

				'group'	=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				"type" => "dpr_shadow_picker",

				"class" => "",

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom shadow for category tile in hover state.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom Shadow', 'dpr-adeline-extensions'),

				"param_name" => "shadow_custom_hover",

				"value" => "none||||||",

				'dependency'		=> array('element' => 'shadow_hover', 'value' => array('custom')),

				'group'	=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'dropdown',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set hover animation for ctagory tile.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Hover animation', 'dpr-adeline-extensions'),

				'param_name' => 'hover_animation',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'value' => array(

					__('None', 'dpr-adeline-extensions') => 'none',

                    __('Scale Up 3%', 'dpr-adeline-extensions')       => 'dpr-upscale-onhover-1',

                    __('Scale Up 6%', 'dpr-adeline-extensions')       => 'dpr-upscale-onhover-2',

                    __('Scale Up 15%', 'dpr-adeline-extensions')      => 'dpr-upscale-onhover-3',

                     __('Scale Up 10%', 'dpr-adeline-extensions')      => 'dpr-upscale-onhover-3',

                    __('Scale Down 3%', 'dpr-adeline-extensions')     => 'dpr-downscale-onhover-4',

                    __('Scale Down 6%', 'dpr-adeline-extensions')     => 'dpr-downscale-onhover-2',

                    __('Move Up 5px', 'dpr-adeline-extensions')       => 'dpr-up-onhover-1',

                    __('Move Up 10px', 'dpr-adeline-extensions')      => 'dpr-up-onhover-2',

                    __('Move Up 15px', 'dpr-adeline-extensions')      => 'dpr-up-onhover-3',

                    __('Move Up 20px', 'dpr-adeline-extensions')      => 'dpr-up-onhover-4',

                    __('Move Down 5px', 'dpr-adeline-extensions')     => 'dpr-down-onhover-1',

                    __('Move Down 10px', 'dpr-adeline-extensions')    => 'dpr-down-onhover-2',

                    __('Move Down 15px', 'dpr-adeline-extensions')    => 'dpr-down-onhover-3',

                    __('Move Down 20px', 'dpr-adeline-extensions')    => 'dpr-down-onhover-4',

                    __('Move UpLeft 5px', 'dpr-adeline-extensions')   => 'dpr-up-left-onhover-1',

                    __('Move UpLeft 10px', 'dpr-adeline-extensions')  => 'dpr-up-left-onhover-2',

                    __('Move UpLeft 15px', 'dpr-adeline-extensions')  => 'dpr-up-left-onhover-3',

                    __('Move UpLeft 20px', 'dpr-adeline-extensions')  => 'dpr-up-left-onhover-4',

                    __('Move UpRight 5px', 'dpr-adeline-extensions')  => 'dpr-up-right-onhover-1',

                    __('Move UpRight 10px', 'dpr-adeline-extensions') => 'dpr-up-right-onhover-2',

                    __('Move UpRight 15px', 'dpr-adeline-extensions')  => 'dpr-up-right-onhover-3',

                    __('Move UpRight 20px', 'dpr-adeline-extensions') => 'dpr-up-right-onhover-4',

                    __('Move DownLeft 5px', 'dpr-adeline-extensions')  => 'dpr-down-left-onhover-1',

                    __('Move DownLeft 10px', 'dpr-adeline-extensions') => 'dpr-down-left-onhover-2',

                    __('Move DownLeft 15px', 'dpr-adeline-extensions')  => 'dpr-down-left-onhover-3',

                    __('Move DownLeft 20px', 'dpr-adeline-extensions') => 'dpr-down-left-onhover-4',  

                    __('Move DownRight 5px', 'dpr-adeline-extensions')  => 'dpr-down-right-onhover-1',

                    __('Move DownRight 10px', 'dpr-adeline-extensions') => 'dpr-down-right-onhover-2',

                    __('Move DownRight 15px', 'dpr-adeline-extensions')  => 'dpr-down-right-onhover-3',

                    __('Move DownRight 20px', 'dpr-adeline-extensions') => 'dpr-down-right-onhover-4', 

                    __('Item Tilt', 'dpr-adeline-extensions') => 'dpr-item-tilt',

					   ),

				'group'	=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Title Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'typo_title_1',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size. If you leave this field blank will be used default size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom line height.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'title_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

	  		),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font. .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_title_google_fonts',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'title_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'dependency'		=> array('element' => 'use_title_google_fonts', 'value' => array('yes')),

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Subtitle Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'typo_title_2',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size. If you leave this field blank will be used default size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom linne height.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom letter sapacing.', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'subtitle_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

	  		),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font. .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_subtitle_google_fonts',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'subtitle_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'dependency'		=> array('element' => 'use_subtitle_google_fonts', 'value' => array('yes')),

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Info Badge  Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'typo_title_3',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size. If you leave this field blank will be used default size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'info_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom linne height.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'info_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom letter sapacing.', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'info_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'info_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

	  		),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font. .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_info_google_fonts',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'info_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'dependency'		=> array('element' => 'use_info_google_fonts', 'value' => array('yes')),

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'css_editor',

				'heading' => __( 'CSS box', 'dpr-adeline-extensions' ),

				'param_name' => 'css',

				'group' => __( 'Design Options', 'dpr-adeline-extensions' ),

			),

		),

	)

);