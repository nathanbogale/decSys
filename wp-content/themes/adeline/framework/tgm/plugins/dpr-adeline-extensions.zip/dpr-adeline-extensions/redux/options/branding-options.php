<?php



/**



 * Branding Theme Options



 * 



 */







    Redux::setSection( $opt_name, array(



        'title'  => __( 'Branding', 'dpr-adeline-extensions' ),



        'id'     => 'branding_tab',



        'desc'   => __( 'Backend branding options is configured here.', 'dpr-adeline-extensions' ),



        'icon'   => 'dashicons dashicons-image-filter',



		'fields' => array(



			array(



				'id' => 'branding_panel_logo',



				'type' => 'media',



				'title' => esc_html__('Options panel logo', 'dpr-adeline-extensions'),



				'default' => array(



				'url' => $assets_folder . 'img/logo/redux_logo.png'



				),



				'hint' => array(



					'title'   => esc_attr__('Options panel logo','dpr-adeline-extensions'),



					'content' => esc_attr__('Select image for the options panel branding logo','dpr-adeline-extensions')



				)



			),



			array(



				'id'=>'branding_panel_name',



				'type'     => 'text',



				'title' => __('Name displayed in Options panel', 'dpr-adeline-extensions'), 



				'default' => '',



				'hint' => array(



					'title'   => esc_attr__('Name displayed in Options panel','dpr-adeline-extensions'),



					'content' => esc_attr__('You can set here own name displayed in Options Panel header. If you leave it blank will be displayed actual theme name.','dpr-adeline-extensions')



				)



			),



			array(



				'id'=>'branding_panel_version',



				'type'     => 'text',



				'title' => __('Version number displayed in Options Panel', 'dpr-adeline-extensions'), 



				'default' => '',



				'hint' => array(



					'title'   => esc_attr__('Version number displayed in Options Panel','dpr-adeline-extensions'),



					'content' => esc_attr__('You can set here own version number displayed in Options Panel header. If you leave it blank will be displayed actual theme version.','dpr-adeline-extensions')



				)



			),



			array(



				'id' => 'branding_admin_icon',



				'type' => 'media',



				'title' => esc_html__('Options menu icon', 'dpr-adeline-extensions'),



				'hint' => array(



					'title'   => esc_attr__('Options panel icon','dpr-adeline-extensions'),



					'content' => esc_attr__('Select image to display as options panel menu icon','dpr-adeline-extensions')



				)



			),



		)



    ) );