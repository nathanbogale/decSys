<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$uniqid = uniqid('dpr-bg-wrapper-');

if ( ! empty( $dpr_row_gradient ) ) {
$custom_el_css .= '#'.$uniqid.'{'.esc_attr(adeline_gradientToBgCSS ($dpr_row_gradient)).'}';
	if($dpr_row_gradient_animate) {
		$dpr_row_gradient_animate_speed = $dpr_row_gradient_animate_speed ? $dpr_row_gradient_animate_speed : '10';
		$dpr_row_gradient_animate_spread = $dpr_row_gradient_animate_spread ? $dpr_row_gradient_animate_spread : '400';
		$custom_el_css .= '#'.$uniqid.'{animation: animatedGradient '.esc_attr($dpr_row_gradient_animate_speed).'s ease infinite; background-size: '.esc_attr($dpr_row_gradient_animate_spread).'% '.esc_attr($dpr_row_gradient_animate_spread).'% !important;}';
	}
}

$output .= '<div id="'.$uniqid.'" class="dpr_row_bg_container">';
$output .= $overlay_output;
$output .= '</div>';

