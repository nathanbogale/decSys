<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$unique_id = $css_animation = $el_class = $css = $output = $custom_el_css = $layout = $animation_disable = $anticlockwise = '';
$size = $bar_color_type = $bar_color = $gradient_colors_pallete = $bar_width = $circle_color = $circle_width = '';
$use_icon = $icon_size = $icon_color = $icon_image_id = $icon_text = $icon_text_color = $icon_text_font_size = $icon_text_line_height = $icon_text_letter_spacing = $icon_text_font_style = $icon_text_use_google_fonts = $icon_text_google_font = $icon_text_typo_style = $icon_html = '';
$title = $title_color = $title_font_size = $title_line_height = $title_letter_spacing = $title_font_style = $title_use_google_fonts = $title_google_font = $title_typo_style = $title_html = '';
$subtitle = $subtitle_color = $subtitle_font_size = $subtitle_line_height = $subtitle_letter_spacing = $subtitle_font_style = $subtitle_use_google_fonts = $subtitle_google_font = $subtitle_typo_style = $subtitle_html = '';
$number = $unit = $number_color = $number_font_size = $number_line_height = $number_letter_spacing = $number_font_style = $number_use_google_fonts = $number_google_font = $number_typo_style = $number_html = '';


$atts = vc_map_get_attributes( 'dpr_piechart', $atts );
extract( $atts );

$el_class = $this->getExtraClass( $el_class );
wp_enqueue_script('dpr-waypoints', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/waypoints.min.js', array('jquery'), null, true);	
if ( '' !== $css_animation && 'none' !== $css_animation ) {
	dpr_enqueue_animate_css();
	$el_class .= ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
}
$unique_id = uniqid('dpr-piechart-').'-'.rand(1,9999);

if(isset($layout)) {
	$el_class .= ' '.$layout;
}

if($use_icon != 'yes') {
	$el_class .= ' no-icon';
}

if(isset($number) && !empty($number)) {
	$number_to_display = '0';
	if($animation_disable == 'yes') {
		$el_class .= ' no-animation';
		$number_to_display = esc_attr($number).'<span>'.esc_attr($unit).'</span>';
	}
}else{
	$number = 0;
}

if( $counterclockwise == 'yes') {
	$el_class .= ' counterclock-wise-animation';
}
$value = $number / 100;


$css_classes = array(
	'dpr-piechart',
	$unique_id,
	$el_class,
	vc_shortcode_custom_css_class( $css ),
);

$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->settings['base'], $atts ) );

if(isset($size) && !empty($size)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .bg-circle {width: '.esc_attr($size).'px; height: '.esc_attr($size).'px; line-height: '.esc_attr($size).'px;}';
}else{
	$size = 160;
}

if(isset($circle_color) && !empty($circle_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .bg-circle:before {border-color: '.esc_attr($circle_color).';}';
}

if(isset($circle_width) && !empty($circle_width)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .bg-circle:before {border-width: '.esc_attr($circle_width).'px;}';
}


if(isset($icon_size) && $icon_size !='') {
	$custom_el_css .= '.'.esc_js($unique_id).' .featured-icon {font-size:'.$icon_size.'px;}';
}
if(isset($icon_color) && $icon_color !='') {
	$custom_el_css .= '.'.esc_js($unique_id).' .featured-icon {color:'.$icon_color.'!important;}';
}
$data_attr = '';
if(isset($bar_width) && !empty($bar_width)) {
	$data_attr .= ' data-thickness="'.esc_attr($bar_width).'"';
}else{
	$data_attr .= ' data-thickness="7"';
}

if($bar_color_type == 'solid') {
	$bar_fill_color = '#D3AE5F';
		if(isset($bar_color) && !empty($bar_color)) {
			$bar_fill_color = $bar_color;
			
		}
	$data_attr .= ' data-fill="{&quot;color&quot;: &quot;' . esc_attr($bar_fill_color) . '&quot;}" ';
}

if($bar_color_type == 'gradient') {
		$gradient_colors_array = array();
		if(isset($gradient_colors_pallete) && !empty($gradient_colors_pallete) && function_exists('vc_param_group_parse_atts')) {
		$gradient_colors = (array) vc_param_group_parse_atts($gradient_colors_pallete);
			foreach($gradient_colors as $item) {
				if(isset($item['color']) && !empty($item['color'])) {
					$gradient_colors_array[] .= '&quot;'.$item['color'].'&quot;';
				}
				
			}
		}
	if(!empty($gradient_colors_array)){
		$gradient_json = implode (", ", $gradient_colors_array);
		$data_attr .= ' data-fill="{&quot;gradient&quot;: ['.$gradient_json.']}" ';
	}
}
$data_attr .= ' data-emptyfill = "transparent"';
$data_attr .= ' data-value="'.esc_attr($value).'"';
$data_attr .= ' data-size="'.esc_attr($size).'"';
$data_attr .= ' data-animation-start-value="0"';
$data_attr .= ' data-reverse="true"';


$title_typo_style = dpr_generate_typography_style($title_color, $title_font_size, $title_line_height, $title_letter_spacing, $title_font_style,$title_google_font);
$subtitle_typo_style = dpr_generate_typography_style($subtitle_color, $subtitle_font_size, $subtitle_line_height, $subtitle_letter_spacing, $subtitle_font_style,$subtitle_google_font);	
$number_typo_style = dpr_generate_typography_style($number_color, $number_font_size, $number_line_height, $number_letter_spacing, $number_font_style,$number_google_font);	

if($use_icon == 'yes') {
	if($icon_type == 'icon' && $icon != '' && $icon != 'none') {
		$icon_html .= '<i class="featured-icon '.$icon.'"></i>';
	} elseif('image' === $icon_type ) {
				$img_style = '';
				$image_url = dpr_get_attachment_image_src( $icon_image_id, 'full' );
				if (! empty( $icon_size )){
					
					$image_src = adeline_resize( $image_url[0], $icon_size, $icon_size, true, true, true );
					if(!$image_src) $image_src = $image_url[0];
				
				} else {
					
					$image_src = $image_url[0];
				
				}
				if ( ! empty( $icon_size ) ) {
	
					$img_style .= 'style="';
	
					if ( isset( $icon_size ) && ! empty( $icon_size ) ) {
						$img_style .= 'width:' . esc_attr($icon_size) . 'px; ';
					}
	
					$img_style .= '"';
	
				}
				$alt_text = get_post_meta($icon_image_id , '_wp_attachment_image_alt', true);
				$icon_html .= '<img src="' . esc_url($image_src) . '"' . $img_style . ' alt ="'.esc_attr($alt_text).'"/>';
				
			} elseif('text' === $icon_type && $icon_text != '' ) {
				$icon_text_typo_style = dpr_generate_typography_style($icon_text_color, $icon_text_font_size, $icon_text_line_height, $icon_text_letter_spacing, $icon_text_font_style, $icon_text_google_font);
				$icon_html .= '<span class="dpr-text-icon-wrap" '.$icon_text_typo_style.'>'.  esc_html($icon_text).'</span>';
			} 
}

$title_html .= '<span class="title-wrap">';
	if (isset($title) && !empty($title)) {
		$title_html .= '<h4 class="piechart-title" '.$title_typo_style.'>'.esc_html($title).'</h4>';
	}
	if (isset($subtitle) && !empty($subtitle)) {
		$title_html .= '<span class="piechart-subtitle" '.$subtitle_typo_style.'>'.esc_html($subtitle).'</span>';
	}
$title_html .= '</span>';

$number_html .= '<span class="number-wrap">';
		$number_html .= '<span class="piechart-number" data-max="'.esc_attr($number).'" data-units="'.esc_attr($unit).'" '.$number_typo_style.'>';
			$number_html .= wp_kses_post($number_to_display);
		$number_html .= '</span>';
$number_html .= '</span>';



$output .= '<div id="'.esc_attr($unique_id).'" class="'.esc_attr($css_class).' call-on-in-viewport" '.$data_attr.'>';

switch($layout)
{
    case 'layout-1';
		$output .= '<div class="bg-circle">';
		$output .= $number_html;
		$output .= '</div>';
		$output .= $title_html;
	break;
    case 'layout-2';
		$output .= '<div class="bg-circle">';
		$output .= $icon_html;
		$output .= '</div>';
		$output .= '<div class="title-container">';
		$output .= $number_html;
		$output .= $title_html;
		$output .= '</div>';
	break;
    case 'layout-3';
		$output .= '<div class="bg-circle">';
		$output .= '<div class="circle-container">';
		$output .= $icon_html;
		$output .= $number_html;
		$output .= '</div>';
		$output .= '</div>';
		$output .= '<div class="title-container">';
        $output .= $title_html;
		$output .= '</div>';
    break;
    case 'layout-4';
		$output .= '<div class="bg-circle">';
		$output .= $number_html;
		$output .= '</div>';
		$output .= '<div class="title-container">';
		$output .= $icon_html;
		$output .= $title_html;
		$output .= '</div>';
    break;
}


if(!empty($custom_el_css)) {
		$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>");'
						. '})(jQuery);'
					. '</script>';
}
$output .= '</div>';


echo $output;