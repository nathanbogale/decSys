<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$unique_id = $css_animation = $el_class = $output = $custom_el_css = $style = '';
$text_alignment = $content_bg_color = $content_border_color = $image_id = $image_hover_effect = $img_border_radius = $enable_shadow = $image_shadow = $image_shadow_hover = '';
$title = $title_color = $title_font_size = $title_line_height  = $title_letter_spacing = $title_font_style = $title_google_font = $title_typo_style = '';
$subtitle = $subtitle_color = $subtitle_font_size = $subtitle_line_height  = $subtitle_letter_spacing = $subtitle_font_style = $subtitle_google_font = $subtitle_typo_style = '';
$description = $content_color = $content_font_size = $content_line_height  = $content_letter_spacing = $content_font_style = $content_google_font = $content_typo_style = '';
$read_more = $link = $readmore_show = $readmore_style = $custom_button_size = $custom_button_shape = $custom_button_color = $custom_button_color_hover = $custom_button_bg_color = $custom_button_bg_color_hover = $custom_button_border_color = $custom_button_border_color_hover = $readmore_text = '';
$enable_label = $label_position = $label_size = $label_bg_color = $label_bg_radius = $enable_label_shadow = $label_shadow = $label_content_type = $label_text = $icon = $icon_color = $icon_font_size = $label_image_id = $label_image_width = '';
$label_text_color = $label_font_size = $label_line_height  = $label_letter_spacing = $label_font_style = $label_google_font = $label_typo_style = $label_image_width = '';
$gradient_overlay_visibility = $overlay_gradient = $overlay_color_hover = '';
$image_html = $gradient_overlay_html = $hover_overlay_html = $title_html = $subtitle_html = $description_html = $read_more_html = $box_link_html = $title_link_html = $image_link_html = $button_link_html  = $label_html = '';


$atts = vc_map_get_attributes( 'dpr_image_banner', $atts );
extract( $atts );

$el_class = $this->getExtraClass( $el_class );
if ( '' !== $css_animation && 'none' !== $css_animation ) {
	dpr_enqueue_waypoint_js();
	dpr_enqueue_animate_css();
	$el_class .= ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
}
$unique_id = uniqid('dpr-image-banner-').'-'.rand(1,9999);

/* Element classes */
if(isset($style)) {
	$el_class .= ' '.$style;
}
if(isset($text_alignment)) {
	$el_class .= ' text-'.$text_alignment;
}
if(isset($image_hover_effect) && $image_hover_effect !='') {
	$el_class .= ' image-hover-effect image-'.$image_hover_effect;
}
$css_classes = array(
	'dpr-image-banner',
	$unique_id,
	$el_class,
);

$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->settings['base'], $atts ) );

/* * ************************
 * Styles and custom CSS
 * *********************** */
if (isset($overlay_color_hover) && $overlay_color_hover != '') {
	$custom_el_css .= '.'.esc_js($unique_id).':hover .overlay-hover {background-color:'.esc_attr($overlay_color_hover).';}';
}
if (isset($enable_shadow) && $enable_shadow == 'yes') {
	if(dpr_shadow_param_to_css($image_shadow) != '') {
		$custom_el_css .= '.'.esc_js($unique_id) .' .image-wrap {'.dpr_shadow_param_to_css($image_shadow).'}';
	}
	if(dpr_shadow_param_to_css($image_shadow_hover) != '') {
		$custom_el_css .= '.'.esc_js($unique_id) .':hover .image-wrap {'.dpr_shadow_param_to_css($image_shadow_hover).'}';
	}
}
if (isset($img_border_radius) && $img_border_radius != '') {
		$custom_el_css .= '.'.esc_js($unique_id) .' .image-wrap  {border-radius:'.$img_border_radius.'px;}';
		$custom_el_css .= '.'.esc_js($unique_id) .'.style-2 .image-wrap  {border-bottom-left-radius:0;}';	
		$custom_el_css .= '.'.esc_js($unique_id) .'.style-2 .image-wrap  {border-bottom-right-radius:0;}';	
		$custom_el_css .= '.'.esc_js($unique_id) .'.style-2 .box-content-wrap  {border-bottom-left-radius:'.$img_border_radius.'px;}';	
		$custom_el_css .= '.'.esc_js($unique_id) .'.style-2 .box-content-wrap  {border-bottom-right-radius:'.$img_border_radius.'px;}';	
}
if (isset($content_bg_color) && $content_bg_color !='') {
		$custom_el_css .= '.'.esc_js($unique_id) .'.style-2 .box-content-wrap  {background-color:'.$content_bg_color.';}';	
}
if (isset($content_border_color) && $content_border_color !='') {
		$custom_el_css .= '.'.esc_js($unique_id) .'.style-2 .box-content-wrap  {border-color:'.$content_border_color.';}';	
}
if(isset($enable_label) && $enable_label =='yes') {
	if(isset($label_size) && $label_size !='') {	
		$custom_el_css .= '.'.esc_js($unique_id).' .label-wrap {width:'.$label_size.'px;height:'.$label_size.'px;line-height:'.$label_size.'px;}';
	}
	if(isset($label_bg_color) && $label_bg_color !='') {	
		$custom_el_css .= '.'.esc_js($unique_id).' .label-wrap {background-color:'.$label_bg_color.';}';
	}
	if(isset($label_bg_radius) && $label_bg_radius !='') {	
		$custom_el_css .= '.'.esc_js($unique_id).' .label-wrap {border-radius:'.$label_bg_radius.'px;}';
	}
	if(isset($enable_label_shadow) && $enable_label_shadow == 'yes') {
		if(dpr_shadow_param_to_css($label_shadow) != '') {
			$custom_el_css .= '.'.esc_js($unique_id) .' .label-wrap {'.dpr_shadow_param_to_css($label_shadow).'}';
		}
	}
}
/* * ************************
 * Partial HTML.
 * *********************** */

/* Box Link */
if(isset($read_more) && $read_more  != 'none') {
	$box_link_attributes    = array();
	if (function_exists('vc_build_link')) {
		$box_link = ( '||' === $link ) ? '' : $link;
		$box_link = vc_build_link( $link );
	
		$link_href   = $box_link['url'];
		$link_title  = $box_link['title'];
		$link_rel  = $box_link['rel'];
		$link_target = strlen($box_link['target']) > 0 ? $box_link['target'] : '_self';
	
		$box_link_attributes[] = 'href="' . esc_url( trim( $link_href ) ) . '"';
		$box_link_attributes[] = 'title="' . esc_attr( trim( $link_title ) ) . '"';
		$box_link_attributes[] = 'target="' . esc_attr( trim( $link_target ) ) . '"';
		$box_link_attributes[] = 'rel="' . esc_attr( trim( $link_rel ) ) . '"';
	}
	if($box_link['url'] != '' && $read_more == 'box') {
			$box_link_html .= '<a class="dpr-cover-link" '.implode(' ',$box_link_attributes).'></a>';
	}
	if($box_link['url'] != '' && $read_more == 'title') {
			$title_link_html .= '<a class="dpr-cover-link" '.implode(' ',$box_link_attributes).'></a>';
	}
	if($box_link['url'] != '' && $read_more == 'more') {
			$button_link_html .= '<a class="dpr-cover-link" '.implode(' ',$box_link_attributes).'></a>';
	}
	if($box_link['url'] != '' && $read_more == 'image') {
			$image_link_html .= '<a class="dpr-cover-link" '.implode(' ',$box_link_attributes).'></a>';
	}
}
/* Image*/
if(isset($image_id) && $image_id != '') {
	$image = dpr_get_attachment_image_src($image_id, 'full');
	$alt_text = get_post_meta($image_id , '_wp_attachment_image_alt', true);
	$image_html .= '<div class ="image-wrap-inner"><img src="'.esc_url($image[0]).'" alt ="'.esc_attr($alt_text).'"/></div>';
} else {
	$image_html .= '<div class ="image-wrap-inner"><img src="'.dpr_calibra_no_image_url().'" alt =""/></div>';	
}

/* Title */
if(!empty($title)) {
	$title_typo_style = dpr_generate_typography_style($title_color, $title_font_size, $title_line_height, $title_letter_spacing, $title_font_style,$title_google_font);
	$title_html .= '<h4 class="title" ' . $title_typo_style . '>' . $title . '</h4>';
	$title_html .= $title_link_html;
}
/* Subtitle */
if(!empty($subtitle)) {
	$subtitle_typo_style = dpr_generate_typography_style($subtitle_color, $subtitle_font_size, $subtitle_line_height, $subtitle_letter_spacing, $subtitle_font_style,$subtitle_google_font);
	$subtitle_html .= '<div class="subtitle" ' . $subtitle_typo_style . '>' . $subtitle . '</div>';
}
/* Description */
if(!empty($description)) {
	$content_typo_style = dpr_generate_typography_style($content_color, $content_font_size, $content_line_height, $content_letter_spacing, $content_font_style,$content_google_font);
	$description_html .= '<div class="box-content" ' . $content_typo_style . '>' . wp_kses_post($description) . '</div>';
}

// Readmore HTML output
$read_more_data = dpr_generate_read_more($atts);
$read_more_html .= $read_more_data[0];
$custom_el_css .= $read_more_data[1];


/* Overlays */
if(isset($gradient_overlay_visibility) && $gradient_overlay_visibility != '') {
	$gradient_overlay_html .= '<span class="gradient-overlay '.esc_attr($gradient_overlay_visibility).'"></span>';
	if(isset($overlay_gradient) && !empty($overlay_gradient)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .gradient-overlay {'.esc_js(adeline_gradientToBgCSS ($overlay_gradient)).';}';
	}
}
$hover_overlay_html = '<span class="overlay-hover"></span>';

/* Label */

if(isset($enable_label) && $enable_label == 'yes') {
	$label_class ='type-'.$label_content_type.' '.$label_position;
	$label_html = '<div class="label-wrap '.$label_class.'">';
			if ('icon' === $label_content_type) {
				
				if ($icon != '') {
					$icon_style = '';
					if (!empty($icon_font_size) || !empty($icon_color)) {
				
						$icon_style .= 'style="';
		
						if ( ! empty( $icon_font_size ) ) {
							$icon_style .= 'font-size:' . $icon_font_size . 'px; ';
						}
		
						if ( ! empty( $icon_color ) ) {
							$icon_style .= 'color:' . $icon_color.'; ';
						}
		
						$icon_style .= '"';
						}
				
					$label_html .= '<i class="featured-icon ' . $icon . '" ' . $icon_style . '></i>';
				
				}
			
			} elseif('image' === $label_content_type ) {
				$img_style = '';
				if(isset($label_image_width) && $label_image_width != '') {
				$img_style = ' width:'.$label_image_width.'px';
				}
				$image_url = dpr_get_attachment_image_src( $label_image_id, 'full' );
				$image_src = $image_url[0];
				$alt_text_1 = get_post_meta($label_image_id , '_wp_attachment_image_alt', true);
				$label_html .= '<img src="' . esc_url($image_src) . '"'.$img_style.' alt ="'.esc_attr($alt_text_1).'"/>';
				
			} elseif('text' === $label_content_type ) {
				$label_typo_style = dpr_generate_typography_style($label_text_color, $label_font_size, $label_line_height, $label_letter_spacing, $label_font_style,$label_google_font);
				$label_html .= '<span class="label-text" '.$label_typo_style.'>'.  esc_html($label_text).'</span>';
			} 
				
			$label_html .= '</div>';
}



/* * ************************
 * Output
 * *********************** */
$output .= '<div id="'.esc_attr($unique_id).'" class="'.esc_attr($css_class).'">';
switch ($style) {
	case 'style-1':
		$output .= '<div class="image-wrap">';
		$output .= $image_html;
		$output .= $gradient_overlay_html;
		$output .= $image_link_html;
		$output .= '<div class="button-wrap on-dark-bg">'.$read_more_html.'</div>';
		$output .= $label_html;
		$output .= '</div>';
		$output .= '<div class="box-content-wrap">';
		$output .= '<div class="box-title">';
		$output .= $title_html;
		$output .= $subtitle_html;
		$output .= '</div>';
		$output .= $description_html;
		$output .= '</div>';
		$output .= $box_link_html;
		
		break;
	case 'style-2':
		$output .= '<div class="image-wrap">';
		$output .= $image_html;
		$output .= $gradient_overlay_html;
		$output .= $image_link_html;
		$output .= '<div class="button-wrap on-dark-bg">'.$read_more_html.'</div>';
		$output .= $label_html;
		$output .= '</div>';
		$output .= '<div class="box-content-wrap">';
		$output .= '<div class="box-title">';
		$output .= $title_html;
		$output .= $subtitle_html;
		$output .= '</div>';
		$output .= $description_html;
		$output .= '</div>';
		$output .= $box_link_html;
		break;
	case 'style-3':
		$output .= '<div class="image-wrap">';
		$output .= $image_html;
		$output .= $gradient_overlay_html;
		$output .= $image_link_html;
		$output .= '<div class="box-title">';
		$output .= $title_html;
		$output .= $subtitle_html;
		$output .= '</div>';
		$output .= $label_html;
		$output .= '</div>';
		$output .= '<div class="box-content-wrap">';
		$output .= $description_html;
		$output .= '</div>';
		$output .= '<div class="button-wrap dark-button">'.$read_more_html.'</div>';
		$output .= $box_link_html;
		break;
	case 'style-4':
		$output .= '<div class="image-wrap">';
		$output .= $image_html;
		$output .= $gradient_overlay_html;
		$output .= $image_link_html;
		$output .= '<div class="cover-wrap on-dark-bg">';
		$output .= '<div class="box-title">';
		$output .= $title_html;
		$output .= $subtitle_html;
		$output .= '</div>';
		$output .= '<div class="box-content-wrap">';
		$output .= $description_html;
		$output .= '</div>';
		$output .= '<div class="button-wrap">'.$read_more_html.'</div>';
		$output .= '</div>';
		$output .= $label_html;
		$output .= '</div>';
		$output .= $box_link_html;
		break;
	case 'style-5':
		$output .= '<div class="image-wrap">';
		$output .= $image_html;
		$output .= $gradient_overlay_html;
		$output .= $hover_overlay_html;
		$output .= $image_link_html;
		$output .= '<div class="cover-wrap on-dark-bg">';
		$output .= '<div class="box-title">';
		$output .= $title_html;
		$output .= $subtitle_html;
		$output .= '</div>';
		$output .= '<div class="box-content-wrap">';
		$output .= $description_html;
		$output .= '</div>';
		$output .= '<div class="button-wrap">'.$read_more_html.'</div>';
		$output .= '</div>';
		$output .= $label_html;
		$output .= '</div>';
		$output .= $box_link_html;
		break;
	case 'style-6':
		$output .= '<div class="image-wrap">';
		$output .= $image_html;
		$output .= $gradient_overlay_html;
		$output .= $hover_overlay_html;
		$output .= $image_link_html;
		$output .= '<div class="cover-wrap on-dark-bg">';
		$output .= '<div class="box-title">';
		$output .= $title_html;
		$output .= $subtitle_html;
		$output .= '</div>';
		$output .= '<div class="box-content-wrap">';
		$output .= $description_html;
		$output .= '</div>';
		$output .= '<div class="button-wrap">'.$read_more_html.'</div>';
		$output .= '</div>';
		$output .= $label_html;
		$output .= '</div>';
		$output .= '<div class="box-title secondary">';
		$output .= $title_html;
		$output .= $subtitle_html;
		$output .= '</div>';
		$output .= $box_link_html;
		break;
	case 'style-7':
		$output .= '<div class="image-wrap">';
		$output .= $image_html;
		$output .= $gradient_overlay_html;
		$output .= $image_link_html;
		$output .= $label_html;
		$output .= '</div>';
		$output .= '<div class="moved-wrap">';
		$output .= '<div class="box-content-wrap">';
		$output .= '<div class="box-title">';
		$output .= $title_html;
		$output .= $subtitle_html;
		$output .= '</div>';
		$output .= $description_html;
		$output .= '</div>';
		$output .= '<div class="button-wrap dark-button">'.$read_more_html.'</div>';
		$output .= '</div>';
		$output .= $box_link_html;
		break;
	case 'style-8':
		$output .= '<div class = "flex-wrap direction-row-reverse">';
		$output .= '<div class="image-wrap">';
		$output .= $image_html;
		$output .= $gradient_overlay_html;
		$output .= $image_link_html;
		$output .= '</div>';
		$output .= '<div class="box-content-wrap flex-wrap direction-column justify-center align-end">';
		$output .= '<div class="box-title">';
		$output .= $title_html;
		$output .= $subtitle_html;
		$output .= '</div>';
		$output .= $description_html;
		$output .= '<div class="button-wrap dark-button">'.$read_more_html.'</div>';
		$output .= '</div>';
		$output .= $box_link_html;
		$output .= '</div>';
		break;
	case 'style-9':
		$output .= '<div class = "flex-wrap direction-row">';
		$output .= '<div class="image-wrap">';
		$output .= $image_html;
		$output .= $gradient_overlay_html;
		$output .= $image_link_html;
		$output .= '</div>';
		$output .= '<div class="box-content-wrap flex-wrap direction-column justify-center align-start">';
		$output .= '<div class="box-title">';
		$output .= $title_html;
		$output .= $subtitle_html;
		$output .= '</div>';
		$output .= $description_html;
		$output .= '<div class="button-wrap dark-button">'.$read_more_html.'</div>';
		$output .= '</div>';
		$output .= $box_link_html;
		$output .= '</div>';
		break;
}



if(!empty($custom_el_css)) {
		$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>");'
						. '})(jQuery);'
					. '</script>';
}
$output .= '</div>';

echo $output;