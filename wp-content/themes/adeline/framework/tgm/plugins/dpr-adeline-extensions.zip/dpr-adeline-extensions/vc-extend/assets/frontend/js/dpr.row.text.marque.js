var $j = jQuery.noConflict();



$j( document ).on( 'ready', function() {

	"use strict";

	// Custom select

	dprInitializeTextMarque();

} );



/* ==============================================

ANIMATED TITLE

============================================== */

function dprInitializeTextMarque() {

	

			$j('.dpr_row_text_marque').each(function () {

				var $self =  $j(this),
					$duration = $self.attr('data-duration'),
					$direction = $self.attr('data-direction'),
					$duplicate = $self.attr('data-duplicate'),
					$visibility = $self.attr('data-visible'),
					$gap = $self.attr('data-gap'),
					$marque = $self.find('.marque-wrapper');

				$marque.marquee({
					duration: $duration,
					duplicated: $duplicate,
					gap:$gap,
					startVisible: $visibility,
					direction: $direction

				});			



			});

}
			
										