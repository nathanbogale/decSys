<?php



/**



 * Portfolio Options -> Source/Query Settings



 * 



 */







	Redux::setSection( $opt_name, array(



		'title' => esc_html__('Source', 'dpr-adeline-extensions'),



		'id' => 'portfolio_source',



		'subsection' => true,



		'fields' => array(



						array(



							'id'       => 'portfolio_use_query',



							'type'     => 'switch',



							'default' => false,



							'desc' => wp_kses_post(__('<small><em>By default are displayed all portfolio items. Enable this option if you need create custom portfolio items set to display.</em></small>','dpr-adeline-extensions')),



							'title'    =>  esc_html__('Use Qustom Query?','dpr-adeline-extensions'),



							'hint' => array(



								'title'   => esc_attr__('Use Qustom Query?','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Use custom query to create source for portfolio page.','dpr-adeline-extensions')



							)



						),



						array(



							'id'		=>'portfolio_query_categories',



							'type'		=> 'select',



							'data'		=> 'terms',



							'multi' => true,



							'args'		=> array('taxonomies'=>'dpr_portfolio_category'),



							'title' 	=> __('Categories', 'dpr-adeline-extensions'),



							'required' => array('portfolio_use_query','equals','1'),



							'desc'     => wp_kses_post(__('<small><i>If you leave this field blank all categories will be included.</i></small>', 'dpr-adeline-extensions')),



							'hint' => array(



								'title'   => esc_attr__('Categories','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Select categories to include in source','dpr-adeline-extensions')



								)



							),



						array(



							'id'		=>'portfolio_query_categories_excluded',



							'type'		=> 'select',



							'data'		=> 'terms',



							'multi' => true,



							'args'		=> array('taxonomies'=>'dpr_portfolio_category'),



							'title' 	=> __('Excluded Categories', 'dpr-adeline-extensions'),



							'required' => array('portfolio_use_query','equals','1'),



							'desc'     => wp_kses_post(__('<small><i>Select categories to exclude from source.</i></small>', 'dpr-adeline-extensions')),



							'hint' => array(



								'title'   => esc_attr__('Excluded Categories','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Select categories to exclude from source','dpr-adeline-extensions')



								)



							),



						array(



							'id'       => 'portfolio_query_offset',



							'type'     => 'spinner', 



							'title'    => __('Items count', 'dpr-adeline-extensions'),



							'required' => array('portfolio_use_query','equals','1'),



							'desc'     => wp_kses_post(__('<small><i>If set this field to -1 all items will be included.</i></small>', 'dpr-adeline-extensions')),



							'default'  => '-1',



							'min'      => '-1',



							'step'     => '1',



							'max'      => '200',



							'hint' => array(



									'title'   => esc_attr__('Portfolio Items Count','dpr-adeline-extensions'),



									'content' =>  esc_attr__('You can set portfolio items to display. If you set to -1 will be included all items.','dpr-adeline-extensions')



							),



						),



						array(



							'id'		=>'portfolio_query_orderby',



							'type'		=> 'select',



							'title' 	=> __('Order By', 'dpr-adeline-extensions'),



							'required' => array('portfolio_use_query','equals','1'),



							'desc'     => wp_kses_post(__('<small><i>Sort retrieved portfolio items by parameter.</i></small>', 'dpr-adeline-extensions')),



							'options'  => array(



								'none' => 'No Order',



								'date' => 'Date',



								'title' => 'Title',



								'name' => 'Slug',



								'author' => 'Author',



								'ID' => 'ID',



								'comment_count' => 'Comment Count',



								'random' => 'Random'



								),



							'default'  => 'none',



							'hint' => array(



								'title'   => esc_attr__('Order By','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Sort retrieved portfolio items by parameter','dpr-adeline-extensions')



								)



							),



						array(



							'id'		=>'portfolio_query_order',



							'type'		=> 'select',



							'title' 	=> __('Order', 'dpr-adeline-extensions'),



							'required' => array('portfolio_use_query','equals','1'),



							'desc'     => wp_kses_post(__('<small><i>Select the ascending or descending order</i></small>', 'dpr-adeline-extensions')),



							'options'  => array(



								'ASC' => 'Ascending Order',



								'DESC' => 'Decending Order',



								),



							'default'  => 'ASC',



							'hint' => array(



								'title'   => esc_attr__('Order','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Select the ascending or descending order','dpr-adeline-extensions')



								)



							),



		)



	));



