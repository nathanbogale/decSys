<?php



/**



 * General Options -> Advanced options



 * 



 */







	Redux::setSection( $opt_name, array(



		'title' => esc_html__('Advanced Options', 'dpr-adeline-extensions'),



		'id' => 'general_advanced_options',



		'subsection' => true,



		'fields' => array(



					array(



						'id'       => 'enable_schema_markup',



						'type'     => 'switch',



						'title'    =>  esc_html__('Enable Schema Markup','dpr-adeline-extensions'),



						'default' => false,



						'hint' => array(



							'title'   => esc_attr__('Enable Schema Markup','dpr-adeline-extensions'),



							'content' => esc_attr__('Schema markup is code (semantic vocabulary) that you put on your website to help the search engines return more informative results for users. So, Schema is not just for SEO reasons, it’s also for the benefit of the searcher.','dpr-adeline-extensions')



						)



					),



					array(



						'id' => 'custom_css',



						'type' => 'textarea',



						'title' => esc_html__('Custom CSS Code', 'dpr-adeline-extensions'),



						'default' => '',



						'hint' => array(



							'title'   => esc_attr__('Custom CSS Code','dpr-adeline-extensions'),



							'content' => esc_attr__('Allows you to add any custom CSS code if you need to customize styles. This CSS will be added after all other CSS so you can overwrite any style in this way.','dpr-adeline-extensions')



						)



					),



					array(



						'id' => 'head_custom_js',



						'type' => 'textarea',



						'title' => esc_html__('Custom JS in HEAD', 'dpr-adeline-extensions'),



						'default' => '',



						'hint' => array(



							'title'   => esc_attr__('JS in HEAD','dpr-adeline-extensions'),



							'content' => esc_attr__('Allows you to add the custom javascript code to HEAD tag.','dpr-adeline-extensions')



						)



					),



					array(



						'id' => 'custom_js',



						'type' => 'textarea',



						'title' => esc_html__('Custom JS', 'dpr-adeline-extensions'),



						'default' => '',



						'hint' => array(



							'title'   => esc_attr__('JS in HEAD','dpr-adeline-extensions'),



							'content' => esc_attr__('Allows you to add the custom javascript code in footer just before </body> tag. No need to add the <script> tags.','dpr-adeline-extensions')



						)



					),



					)



	));	