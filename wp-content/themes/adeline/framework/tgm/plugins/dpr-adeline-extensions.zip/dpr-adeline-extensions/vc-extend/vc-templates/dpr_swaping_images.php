<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$output = $style = $mode = $speed = $fade_duration = $el_class = $custom_el_css = $item_data = '';

$atts = vc_map_get_attributes($this->getShortcode(), $atts);
extract( $atts );
	

	$id = uniqid('dpr-swaping-images');

	wp_enqueue_script('interactive-showcase', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/dpr.swaping.images.js', array('jquery'), null, true);	
	if($style == 'reveal'){
	wp_enqueue_script('tweenmax', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/TweenMax.min.js', array('jquery'), null, true);
	}
	/* Element classes */
	if(isset($style) && $style != '') {
		$el_class .= ' style-'.$style;
	}
	if ( '' !== $css_animation && 'none' !== $css_animation ) {
		dpr_enqueue_waypoint_js();
		dpr_enqueue_animate_css();
		$el_class .= ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
	}

	$css_classes = array(
		'dpr-swaping-images',
		esc_attr($id),
		$el_class,
		vc_shortcode_custom_css_class( $css ),
	);

	$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->settings['base'], $atts ) );

/* Element data stuff */
 
 if(isset($speed) && $speed != '' ) {
	 $dataspeed = $speed;
 } else {
 	 $dataspeed = '1000';
 }
 if(isset($fade_duration) && $fade_duration != '' ) {
	 $dataduration = $fade_duration;
 } else {
 	 $dataduration = '1000';
 }
 $item_data .=' data-speed="'.esc_attr($dataspeed).'"';
 if($style == 'fade') {
	 $item_data .=' data-duration="'.esc_attr($dataduration).'"';
 }
if (isset($mode) && $mode !='') {
	$item_data .=' data-mode="'.esc_attr($mode).'"';
} else {
	$item_data .=' data-mode="allways"';
}

/* Generate Output */

	if ( '' === $swap_images ) {
	$swap_images = '-1,-2,-3';
	}
	$swap_images = explode( ',', $swap_images );


	$output .= '<div id="'.esc_attr($id).'" class="'.esc_attr($css_class).'"'.$item_data.'>';

	if (isset($main_image) && !empty($main_image)) {
		$image = dpr_get_attachment_image_src($main_image, 'full');
		$image_src = $image[0];
		if ($image_src == '') {
			$image_src = adeline_no_image_url();
		}
		$alt_text = get_post_meta($main_image , '_wp_attachment_image_alt', true);

		$output .= '<img src="'.esc_url($image_src ).'" alt ="'.esc_attr($alt_text).'"/>';
	}
	$output .= '<div class ="swap-images-container">';
	foreach ( $swap_images as $i => $image ) {
			if ( $image > 0 ) {
					$img = dpr_get_attachment_image_src( $image,'full');
					$large_img_src = $img[0];
					$output .=  '<div class="swap-image-wrap" style="background-image:url('.esc_url($large_img_src).');"></div>';
			}
		}
	$output .= '</div>';
	
		if($custom_el_css != '') {
			$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>")'
						. '})(jQuery);'
					. '</script>';
		}




	$output .= '</div>';

echo $output;