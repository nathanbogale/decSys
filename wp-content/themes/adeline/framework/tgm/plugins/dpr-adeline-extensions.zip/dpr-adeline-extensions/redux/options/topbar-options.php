<?php

/**



 * Typography Theme Options



 *



 */

Redux::setSection($opt_name, array(

    'title'   => __('Top Bar', 'dpr-adeline-extensions'),

    'id'      => 'topbar_tab',

    'default' => false,

    'desc'    => __('Top bar options are configured here.', 'dpr-adeline-extensions'),

    'icon'    => 'dashicons dashicons-archive',

));

Redux::setSection($opt_name, array(

    'title'      => esc_html__('General', 'dpr-adeline-extensions'),

    'subsection' => true,

    'fields'     => array(

        array(

            'id'      => 'top_bar',

            'type'    => 'switch',

            'default' => false,

            'title'   => esc_html__('Display Top Bar', 'dpr-adeline-extensions'),

            'hint'    => array(

                'title'   => esc_attr__('Display Top Bar', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enable or disable display of top bar.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'top_bar_full_width',

            'type'     => 'switch',

            'default'  => false,

            'title'    => esc_html__('Force fullwidth top bar', 'dpr-adeline-extensions'),

            'required' => array('top_bar', 'equals', '1'),

            'hint'     => array(

                'title'   => esc_attr__('Force fullwidth top bar', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enable full width of top bar.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'             => 'top_bar_full_width_padding',

            'type'           => 'spacing',

            'output'         => array('.full-width-topbar #dpr-top-bar-inner'),

            'mode'           => 'padding',

            'units'          => array('px'),

            'display_units'  => true,

            'units_extended' => false,

            'top'            => false,

            'bottom'         => false,

            'title'          => __('Fullwidth Top Bar Padding (px)', 'dpr-adeline-extensions'),

            'default'        => array(

                'padding-left'  => '30px',

                'padding-right' => '30px',

                'units'         => 'px',

            ),

            'required'       => array('top_bar_full_width', 'equals', '1'),

            'hint'           => array(

                'title'   => esc_attr__('Fullwidth Top Bar Paddingg', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Choose default padding for full width top bar.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'top_bar_visibility',

            'type'     => 'image_select',

            'title'    => __('Visibility', 'dpr-adeline-extensions'),

            'options'  => array(

                'all-devices'        => array(

                    'title' => esc_html__('All Devices', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/visibility/all.png',

                ),

                'hide-tablet'        => array(

                    'title' => esc_html__('Hide On Tablet', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/visibility/no_tablet.png',

                ),

                'hide-mobile'        => array(

                    'title' => esc_html__('Hide On Mobile', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/visibility/no_mobile.png',

                ),

                'hide-tablet-mobile' => array(

                    'title' => esc_html__('Hide On Tablet & Mobile', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/visibility/no_tablet_mobile.png',

                ),

            ),

            'default'  => 'all-devices',

            'hint'     => array(

                'title'   => esc_attr__('Visibility', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enable or disable display top bar on certain devices.', 'dpr-adeline-extensions'),

            ),

            'required' => array('top_bar', 'equals', '1'),

        ),

        array(

            'id'       => 'top_bar_elements',

            'type'     => 'sorter',

            'title'    => 'Top Bar Elements Order',

            'hint'     => array(

                'title'   => esc_attr__('Top Bar Elements Order', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enable or disable display of certain elements in top bar and set element order', 'dpr-adeline-extensions'),

            ),

            'options'  => array(

                'enabled'  => array(

                    'content' => 'Content',

                ),

                'disabled' => array(

                    'menu'   => 'Top Bar Menu',

                    'social' => 'Social Links',

                ),

            ),

            'required' => array('top_bar', 'equals', '1'),

        ),

        array(

            'id'       => 'top_bar_middle_column_alignment',

            'type'     => 'radio',

            'title'    => __('Middle Column Alignment', 'dpr-adeline-extensions'),

            'options'  => array(

                'left'  => 'Left',

                'right' => 'Right',

            ),

            'default'  => 'right',

            'hint'     => array(

                'title'   => esc_attr__('Middle Column Alignment', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set alignment for middle column. Applies only when all top bar elements are enabled ', 'dpr-adeline-extensions'),

            ),

            'required' => array('top_bar', 'equals', '1'),

        ),

        array(

            'id'             => 'top_bar_padding',

            'type'           => 'spacing',

            'output'         => array('#dpr-top-bar-wrapper'),

            'mode'           => 'padding',

            'units'          => array('px', 'em'),

            'display_units'  => true,

            'units_extended' => false,

            'title'          => __('Padding', 'dpr-adeline-extensions'),

            'default'        => array(

                'padding-top'    => '8px',

                'padding-right'  => '0px',

                'padding-bottom' => '8px',

                'padding-left'   => '0px',

                'units'          => 'px',

            ),

            'required'       => array('top_bar', 'equals', '1'),

            'hint'           => array(

                'title'   => esc_attr__('Padding', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set tob bar vertical padding', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'top_bar_bgr',

            'type'     => 'color',

            'output'   => array('background-color' => '#dpr-top-bar-wrapper'),

            'validate' => 'color',

            'title'    => esc_html__('Background Color', 'dpr-adeline-extensions'),

            'default'  => '#292933',

            'required' => array('top_bar', 'equals', '1'),

            'hint'     => array(

                'title'   => esc_attr__('Background Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set tob bar background color', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'top_bar_border',

            'type'     => 'color',

            'output'   => array('border-color' => '#dpr-top-bar-wrapper'),

            'validate' => 'color',

            'title'    => esc_html__('Border Color', 'dpr-adeline-extensions'),

            'default'  => '#292933',

            'required' => array('top_bar', 'equals', '1'),

            'hint'     => array(

                'title'   => esc_attr__('Border Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set tob bar bottom border color', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'top_bar_text_color',

            'type'     => 'color',

            'output'   => array('color' => '#dpr-top-bar-content'),

            'validate' => 'color',

            'title'    => esc_html__('Text Color', 'dpr-adeline-extensions'),

            'default'  => '#cccccc',

            'required' => array('top_bar', 'equals', '1'),

            'hint'     => array(

                'title'   => esc_attr__('Text Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set tob bar text color', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'top_bar_link_color',

            'type'     => 'color',

            'output'   => array('color' => '#dpr-top-bar-content a'),

            'validate' => 'color',

            'title'    => esc_html__('Link Color', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'required' => array('top_bar', 'equals', '1'),

            'hint'     => array(

                'title'   => esc_attr__('Link Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set tob bar link color', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'top_bar_link_color_hover',

            'type'     => 'color',

            'output'   => array('color' => '#dpr-top-bar-content a:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Link Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'required' => array('top_bar', 'equals', '1'),

            'hint'     => array(

                'title'   => esc_attr__('Link Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set tob bar link color hover', 'dpr-adeline-extensions'),

            ),

        ),

    ),

));

Redux::setSection($opt_name, array(

    'title'      => esc_html__('Content', 'dpr-adeline-extensions'),

    'subsection' => true,

    'fields'     => array(

        array(

            'id'       => 'top_bar_content',

            'type'     => 'textarea',

            'title'    => esc_html__('Top bar content', 'dpr-adeline-extensions'),

            'desc'     => esc_html__('Some HTML and shortcodes are allowed here', 'dpr-adeline-extensions'),

            'validate' => 'html',

            'default'  => 'Phone: +0(123) 456 78 90       Email: dynamicpress@email.com',

            'hint'     => array(

                'title'   => esc_attr__('Top Bar Content', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Add content (eg. the address information) which will be visible in top bar', 'dpr-adeline-extensions'),

            ),

        ),

    ),

));

Redux::setSection($opt_name, array(

    'title'      => esc_html__('Top Bar Menu', 'dpr-adeline-extensions'),

    'subsection' => true,

    'fields'     => array(

        array(

            'id'    => 'menu_top_bar_styling_info',

            'type'  => 'info',

            'style' => 'dpr-title',

            'title' => wp_kses_post(__('<h3>Main Styling</h3>', 'dpr-adeline-extensions')),

        ),

        array(

            'id'       => 'menu_top_bar_link_color',

            'type'     => 'color',

            'output'   => array('color' => '#dpr-top-bar-nav .dpr-top-bar-menu.dropdown-menu > li > a,#dpr-adeline-mobile-menu-icon a,#searchform-header-replace-close'),

            'validate' => 'color',

            'title'    => esc_html__('Menu Link Color', 'dpr-adeline-extensions'),

            'default'  => '#292933',

            'hint'     => array(

                'title'   => esc_attr__('Menu Link Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set main menu link color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_top_bar_link_color_hover',

            'type'     => 'color',

            'output'   => array('color' => '#dpr-top-bar-nav .dpr-top-bar-menu.dropdown-menu > li > a:hover,#dpr-adeline-mobile-menu-icon a:hover,#searchform-header-replace-close:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Menu Link Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'hint'     => array(

                'title'   => esc_attr__('Menu Link Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set main menu link hover color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_top_bar_link_color_curent',

            'type'     => 'color',

            'output'   => array('color' => '#dpr-top-bar-nav .dpr-top-bar-menu.dropdown-menu > .current-menu-item > a,#dpr-top-bar-nav .dpr-top-bar-menu.dropdown-menu > .current-menu-ancestor > a,#dpr-top-bar-nav .dpr-top-bar-menu.dropdown-menu > .current-menu-item > a:hover,#dpr-top-bar-nav .dpr-top-bar-menu.dropdown-menu > .current-menu-ancestor > a:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Menu Link Color: Current Menu Item', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'hint'     => array(

                'title'   => esc_attr__('Menu Link Color: Current Menu Item', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set main menu current menu item link color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_top_bar_link_bg_color',

            'type'     => 'color',

            'output'   => array('background-color' => '#dpr-top-bar-nav .dpr-top-bar-menu.dropdown-menu > li > a'),

            'validate' => 'color',

            'title'    => esc_html__('Menu Item Background Color', 'dpr-adeline-extensions'),

            'default'  => '',

            'hint'     => array(

                'title'   => esc_attr__('Menu Item Background Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set menu item background color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_top_bar_link_bg_color_hover',

            'type'     => 'color',

            'output'   => array('background-color' => '#dpr-top-bar-nav .dpr-top-bar-menu.dropdown-menu > li > a:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Menu Item Background Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '',

            'hint'     => array(

                'title'   => esc_attr__('Menu Item Background Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set menu item hover background color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_top_bar_link_bg_color_curent',

            'type'     => 'color',

            'output'   => array('color' => '#dpr-top-bar-nav .dpr-top-bar-menu.dropdown-menu > .current-menu-item > a,#dpr-top-bar-nav .dpr-top-bar-menu.dropdown-menu > .current-menu-ancestor > a,#dpr-top-bar-nav .dpr-top-bar-menu.dropdown-menu > .current-menu-item > a:hover,#dpr-top-bar-nav .dpr-top-bar-menu.dropdown-menu > .current-menu-ancestor > a:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Menu Item Background Color: Current Menu Item', 'dpr-adeline-extensions'),

            'default'  => '',

            'hint'     => array(

                'title'   => esc_attr__('Menu Item Background Color: Current Menu Item', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set current menu item background color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'             => 'menu_top_bar_link_spacing',

            'type'           => 'spacing',

            'output'         => array('#dpr-top-bar-nav .dpr-top-bar-menu.dropdown-menu > li > a'),

            'mode'           => 'padding',

            'units'          => array('px'),

            'display_units'  => true,

            'units_extended' => false,

            'top'            => false,

            'bottom'         => false,

            'title'          => __('Menu Items Horizontal Padding(px)', 'dpr-adeline-extensions'),

            'default'        => array(

                'padding-left'  => '15px',

                'padding-right' => '15px',

                'units'         => 'px',

            ),

            'hint'           => array(

                'title'   => esc_attr__('Menu Items Horizontal Padding(px)', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Choose default menu items left/right padding.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'      => 'woo_topbar_menu_wishlist_button',

            'type'    => 'switch',

            'default' => false,

            'title'   => esc_html__('Display Wishlist Icon', 'dpr-adeline-extensions'),

            'hint'    => array(

                'title'   => esc_attr__('Display Wishlist Icon', 'dpr-adeline-extensions'),

                'content' => esc_attr__('You need to activate the TI WooCommerce Wishlist plugin to add a wishlist button and icon.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'    => 'menu_top_bar_dropdown_styling_info',

            'type'  => 'info',

            'style' => 'dpr-title',

            'title' => wp_kses_post(__('<h3>Dropdowns Stylling</h3>', 'dpr-adeline-extensions')),

        ),

        array(

            'id'      => 'menu_top_bar_dropdown_width',

            'type'    => 'dimensions',

            'output'  => array('.dpr-top-bar-menu.dropdown-menu .sub-menu'),

            'title'   => esc_html__('Menu Dropdowns Width (px)', 'dpr-adeline-extensions'),

            'width'   => true,

            'height'  => false,

            'mode'    => array('width' => 'min-width', 'height' => 'height'),

            'units'   => array('px'),

            'default' => array(

                'width' => '220px',

            ),

            'hint'    => array(

                'title'   => esc_attr__('Menu Dropdowns Width ', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify the minimum menu dropdowns width.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'             => 'menu_top_bar_dropdown_margin',

            'type'           => 'spacing',

            'output'         => array('#dpr-top-bar-nav .current-shop-items-dropdown', '.dpr-top-bar-menu.dropdown-menu .sub-menu'),

            'mode'           => 'margin',

            'units'          => array('px'),

            'display_units'  => true,

            'units_extended' => false,

            'left'           => false,

            'right'          => false,

            'bottom'         => false,

            'title'          => __('Dropdown Top Margin', 'dpr-adeline-extensions'),

            'default'        => array(

                'margin-top' => '8px',

                'units'      => 'px',

            ),

            'hint'           => array(

                'title'   => esc_attr__('Dropdown Top Margin(px)', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Choose dropdown top margin.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_top_bar_dropdown_background',

            'type'     => 'color',

            'output'   => array('background-color' => '.dpr-top-bar-menu.dropdown-menu .sub-menu,#searchform-dropdown,#current-shop-items-dropdown'),

            'validate' => 'color',

            'title'    => esc_html__('Dropdown Background Color', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'hint'     => array(

                'title'   => esc_attr__('Dropdown Background Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set background color for menu dropdowns.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_top_bar_dropdown_separators_color',

            'type'     => 'color',

            'output'   => array('border-color' => '.dpr-top-bar-menu.dropdown-menu ul li.menu-item,.navigation > ul > li > ul.megamenu.sub-menu > li,.navigation .megamenu li ul.sub-menu'),

            'validate' => 'color',

            'title'    => esc_html__('Dropdown Separators Color', 'dpr-adeline-extensions'),

            'default'  => '#f1f2f4',

            'hint'     => array(

                'title'   => esc_attr__('Dropdown Background Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set separator lines color for menu dropdowns.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_top_bar_dropdown_link_color',

            'type'     => 'color',

            'output'   => array('color' => '.dpr-top-bar-menu.dropdown-menu ul li a.menu-link'),

            'validate' => 'color',

            'title'    => esc_html__('Dropdown Link Color', 'dpr-adeline-extensions'),

            'default'  => '#292933',

            'hint'     => array(

                'title'   => esc_attr__('Dropdown Link Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set color for menu dropdowns links.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_top_bar_dropdown_link_color_hover',

            'type'     => 'color',

            'output'   => array('color' => '.dpr-top-bar-menu.dropdown-menu ul li a.menu-link:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Dropdown Link Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'hint'     => array(

                'title'   => esc_attr__('Dropdown Link Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set hover color for menu dropdowns links.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_top_bar_dropdown_link_background_hover',

            'type'     => 'color',

            'output'   => array('background-color' => '.dpr-top-bar-menu.dropdown-menu ul li a.menu-link:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Dropdown Link Background Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '#f1f2f4',

            'hint'     => array(

                'title'   => esc_attr__('Dropdown Link Background Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set background color for menu dropdowns links.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_top_bar_dropdown_link_color_current',

            'type'     => 'color',

            'output'   => array('color' => '.dpr-top-bar-menu.dropdown-menu ul > .current-menu-item > a.menu-link'),

            'validate' => 'color',

            'title'    => esc_html__('Dropdown Link Color: Current', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'hint'     => array(

                'title'   => esc_attr__('Dropdown Link Color: Current Item', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set hover color for menu dropdowns links.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_top_bar_dropdown_link_background_current',

            'type'     => 'color',

            'output'   => array('background-color' => '.dpr-top-bar-menu.dropdown-menu ul > .current-menu-item > a.menu-link'),

            'validate' => 'color',

            'title'    => esc_html__('Dropdown Link Background Color: Current', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'hint'     => array(

                'title'   => esc_attr__('Dropdown Link Background Color: Current Item', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set background color for menu dropdowns links.', 'dpr-adeline-extensions'),

            ),

        ),

    ),

));

Redux::setSection($opt_name, array(

    'title'      => esc_html__('Social Icons', 'dpr-adeline-extensions'),

    'subsection' => true,

    'fields'     => array(

        array(

            'id'      => 'top_bar_social_display',

            'type'    => 'switch',

            'default' => false,

            'title'   => esc_html__('Enable social links', 'dpr-adeline-extensions'),

        ),

        array(

            'id'       => 'top_bar_social_target',

            'type'     => 'select',

            'title'    => esc_html__('Social Link Target', 'dpr-adeline-extensions'),

            'desc'     => '',

            'options'  => array(

                'blank' => esc_html__('New window', 'dpr-adeline-extensions'),

                'self'  => esc_html__('Same window', 'dpr-adeline-extensions'),

            ),

            'default'  => 'blank',

            'required' => array('top_bar_social_display', 'equals', '1'),

        ),

        array(

            'id'             => 'top_bar_social_font_size',

            'type'           => 'typography',

            'title'          => esc_html__('Social Icons Font Size', 'dpr-adeline-extensions'),

            'google'         => false,

            'font-family'    => false,

            'font-weight'    => false,

            'font-style'     => false,

            'subsets'        => false,

            'font-size'      => true,

            'text-align'     => false,

            'line-height'    => false,

            'word-spacing'   => false,

            'letter-spacing' => false,

            'text-transform' => false,

            'color'          => false,

            'preview'        => false,

            'all_styles'     => false,

            'units'          => 'px',

            'output'         => array('#dpr-top-bar-social li a'),

            'default'        => array(

                'font-size' => '14px',

            ),

            'required'       => array('top_bar_social_display', 'equals', '1'),

        ),

        array(

            'id'             => 'top_bar_social_padding',

            'type'           => 'spacing',

            'output'         => array('#dpr-top-bar-social li a'),

            'mode'           => 'padding',

            'top'            => false,

            'bottom'         => false,

            'units'          => array('px', 'em'),

            'display_units'  => true,

            'units_extended' => false,

            'title'          => __('Social Icons Padding (px)', 'dpr-adeline-extensions'),

            'default'        => array(

                'padding-left'  => '6px',

                'padding-right' => '6px',

                'units'         => 'px',

            ),

            'required'       => array('top_bar_social_display', 'equals', '1'),

        ),

        array(

            'id'       => 'top_bar_social_icons_color',

            'type'     => 'color',

            'output'   => array('#dpr-top-bar-social li a'),

            'validate' => 'color',

            'title'    => esc_html__('Social Icons Color', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'required' => array('top_bar_social_display', 'equals', '1'),

        ),

        array(

            'id'       => 'top_bar_social_icons_color_hover',

            'type'     => 'color',

            'output'   => array('#dpr-top-bar-social li a:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Social Icons Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'required' => array('top_bar_social_display', 'equals', '1'),

        ),

    ),

));
