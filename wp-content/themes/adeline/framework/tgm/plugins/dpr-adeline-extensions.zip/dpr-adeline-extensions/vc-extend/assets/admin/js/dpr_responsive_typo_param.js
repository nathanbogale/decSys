/**

 * Backend JS for responsive typo param

 */

(function ($) {

	vc.atts.dpr_responsive_typo = {

	

	init: function (param, $field) {


			if($field.find('.dpr_responsive_typo').val() != "") {

			var valString = $field.find('.dpr_responsive_typo').val();

			var splited = valString.split("|")

			jQuery.each(splited , function (index, value){

				var inputVar = value.split(":")

				$field.find('.'+ inputVar[0]).val(inputVar[1])

			});

			}

			$field.find('.css-input').on('change', function () {

			

			var $parent = $field;

			var options = {},

				string_parts,

				string;

			options.desktop_font_size = $parent.find('.desktop_font_size').val();

			options.desktop_line_height = $parent.find('.desktop_line_height').val();

			options.desktop_letter_spacing = $parent.find('.desktop_letter_spacing').val();



			options.tablet_font_size = $parent.find('.tablet_font_size').val();

			options.tablet_line_height = $parent.find('.tablet_line_height').val();

			options.tablet_letter_spacing = $parent.find('.tablet_letter_spacing').val();



			options.mobile_font_size = $parent.find('.mobile_font_size').val();

			options.mobile_line_height = $parent.find('.mobile_line_height').val();

			options.mobile_letter_spacing = $parent.find('.mobile_letter_spacing').val();

			

			string_parts = _.map(options, function (value, key) {

				if (_.isString(value) && 0 < value.length) {

					return key + ':' + encodeURIComponent(value);

				}

			});

			string = $.grep(string_parts, function (value) {

				return _.isString(value) && 0 < value.length;

			}).join('|');

			$field.find('.dpr_responsive_typo').val(string);

			

			

			});

		$field.find('.device-button').click(function (e) {

				var target = jQuery(this).data('target');

				e.preventDefault();

				$field.find('.css-panel, .device-button').each(function () {

					jQuery(this).removeClass('active');

				});

				jQuery(this).addClass('active');

				$field.find('.css-panel[data-panel="'+target+'"]').addClass('active');				

			});



	},

};

})(window.jQuery);

