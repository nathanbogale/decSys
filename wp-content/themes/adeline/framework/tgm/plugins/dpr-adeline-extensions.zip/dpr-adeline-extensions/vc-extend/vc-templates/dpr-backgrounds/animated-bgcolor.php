<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
$percent_value = $keyframe_css = '';
$uniqid = uniqid('dpr-bg-wrapper-');

$keyframe_pref = array('@-webkit-keyframes','@-moz-keyframes','@-ms-keyframes','@-o-keyframes','@keyframes');

if(isset($dpr_animated_colors) && !empty($dpr_animated_colors) && function_exists('vc_param_group_parse_atts')) {
	
	$animation_colors = (array) vc_param_group_parse_atts( $atts['dpr_animated_colors'] );

	$count = count($animation_colors);
		if($count) {
			$count = 100/$count;
	
			$i = 0;
			foreach($animation_colors as $color) {
				if(isset($color['dpr_animated_color']) && $color['dpr_animated_color'] != '') {
					if($i == 0)
						$custom_el_css .= 'background: '.esc_js($color['dpr_animated_color']).';';
						$percent_value .= esc_js($count * $i).'% { background: '.esc_js($color['dpr_animated_color']).'}';
				}
	
				$i++;
			}
			foreach($keyframe_pref as $v) {
				$keyframe_css .= esc_js($v) .' '.esc_js($uniqid).' {'.$percent_value.'}';
			}
		}

	$dpr_animated_speed = (isset($dpr_animated_speed) && $dpr_animated_speed != '') ? $dpr_animated_speed : 3;
	
	$custom_el_css .= '-webkit-animation: '. esc_js($uniqid) .' '. esc_js($dpr_animated_speed) .'s linear infinite;';
	$custom_el_css .= '-moz-animation: '. esc_js($uniqid) .' '. esc_js($dpr_animated_speed) .'s linear infinite;';
	$custom_el_css .= '-ms-animation: '. esc_js($uniqid) .' '. esc_js($dpr_animated_speed) .'s linear infinite;';
	$custom_el_css .= '-o-animation: '. esc_js($uniqid) .' '. esc_js($dpr_animated_speed) .'s linear infinite;';
	$custom_el_css .= 'animation: '. esc_js($uniqid) .' '. esc_js($dpr_animated_speed) .'s linear infinite;';
	
	$custom_el_css = '#'.esc_js($uniqid).'{'.$custom_el_css.'}';
	
	$custom_el_css .= $keyframe_css;

	$output .= '<div id="'.$uniqid.'" class="dpr_row_bg_container">';
	$output .= $overlay_output;
	$output .= '</div>';

}





