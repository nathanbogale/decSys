var $j = jQuery.noConflict();

$j( document ).on( 'ready', function() {
	"use strict";
	// Custom select
	dprInitializeCf7();
} );

/* ==============================================
BEFORE AFTER
============================================== */
function dprInitializeCf7() {
	"use strict"
    $j(function(){

		$j('.dpr-contact-form').each(function(){
			var submit = $j(this).find('[type="submit"]');
			var button = $j(this).find('[data-replacement-btn] div');

			if( submit.length ){
				button.find('.text').html( submit.val() );
				submit.replaceWith( button );
				$j(this).find('.ajax-loader').remove();
			}
		});

		// Loader
		$j('.dpr-contact-form form').on('submit', function(){
			$j(this).find('.loader').css({
				'width': '21px',
				'margin-right': '6px'
			});
		});
		$j(document).on('spam.wpcf7 invalid.wpcf7 spam.wpcf7 mailsent.wpcf7 mailfailed.wpcf7', function(e){
			var form = e.target;
			$j(form).find('.loader').css({
				'width': '0px',
				'margin-right': '0px'
			});
		});


    });
}