<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$unique_id = $style = $css_animation = $el_class = $css = $output = $custom_el_css = '';
$line_height = $line_color = $line_style = $line_pattern = $pattern_opacity = $pattern_size = $pattern_style = '';
$icon = $icon_size = $icon_color = $use_badge = $icon_bg_size = $icon_bg = $border_width = $border_color = $icon_html = '';
$icon_image_id = $image_size = $image_html = '';
$text = $text_color = $text_font_size = $text_line_height = $text_letter_spacing = $text_font_style = $use_google_fonts = $text_google_font = $text_typo_style = $text_wrap_html = '';
$totop_icon = $totop_icon_size = $totop_icon_color = $totop_icon_bg_size = $totop_icon_bg = $totop_border_width = $totop_border_color = $totop_icon_html = '';


$atts = vc_map_get_attributes( 'dpr_separator', $atts );
extract( $atts );



$el_class = $this->getExtraClass( $el_class );
$el_class .= 'separator-style-'.esc_attr($style);
if ($use_badge == 'yes') {
	$el_class .= ' with-badge';
}
if ( '' !== $css_animation && 'none' !== $css_animation ) {
	dpr_enqueue_waypoint_js();
	dpr_enqueue_animate_css();
	$el_class .= ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
}

$unique_id = uniqid('dpr-separator-').'-'.rand(1,9999);

$css_classes = array(
	'dpr-separator-wrap',
	$unique_id,
	$el_class,
	vc_shortcode_custom_css_class( $css ),
);

$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->settings['base'], $atts ) );






if(isset($line_height) && !empty($line_height)) {
	if ( $line_style == 'pattern' ) {
	$custom_el_css .= '.'.esc_js($unique_id).' .dpr-separator-line-left, .'.esc_js($unique_id).' .dpr-separator-line-right {height: '.esc_js($line_height).'px;border-width:0px;}';
	} else {
	$custom_el_css .= '.'.esc_js($unique_id).' .dpr-separator-line-left, .'.esc_js($unique_id).' .dpr-separator-line-right {border-bottom-width: '.esc_js($line_height).'px !important;}';
	}
}
if(isset($line_style) && !empty($line_style)) {
	if ( $line_style != 'pattern' ) {
	$custom_el_css .= '.'.esc_js($unique_id).' .dpr-separator-line-left, .'.esc_js($unique_id).' .dpr-separator-line-right {border-bottom-style: '.esc_js($line_style).' !important}';
	} 
}
if(isset($line_color) && !empty($line_color)) {
	if ( $line_style != 'pattern' ) {
	$custom_el_css .= '.'.esc_js($unique_id).' .dpr-separator-line-left, .'.esc_js($unique_id).' .dpr-separator-line-right {border-bottom-color: '.esc_js($line_color).' !important}';
	} 
}

if ( $line_style == 'pattern' ) {

	if(isset($line_pattern) && !empty($line_pattern)) {
		$pattern_style .= 'background-image: url('.DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/img/patterns/'.esc_attr($line_pattern).'.png);';
	}
	
	if(isset($pattern_opacity) && !empty($pattern_opacity)) {
		$pattern_style .= 'opacity: '.esc_attr($pattern_opacity/100).';';
	}
	
	if(isset($pattern_size) && !empty($pattern_size)) {
		$pattern_style .= 'background-size: '.esc_attr($pattern_size).'px;';
	}
	if(!empty($pattern_style)) {
		$pattern_style = ' style="'.$pattern_style.'" ';
	}
}

if(isset($icon_color) && !empty($icon_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .separator-icon {color: '.esc_js($icon_color).';}';
}

if(isset($icon_size) && !empty($icon_size)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .separator-icon {font-size: '.esc_js($icon_size).'px;}';
}
if(isset($icon_bg_size) && !empty($icon_bg_size)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .module-icon {width: '.esc_js($icon_bg_size).'px;height: '.esc_js($icon_bg_size).'px;}';
	$custom_el_css .= '.'.esc_js($unique_id).' .separator-icon {line-height: '.esc_js($icon_bg_size).'px;}';
}
if(isset($icon_bg) && !empty($icon_bg)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .module-icon {background-color: '.esc_js($icon_bg).';}';
}
if(isset($border_width) && !empty($border_width)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .module-icon {border-width: '.esc_js($border_width).'px;}';
}
if(isset($border_color) && !empty($border_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .module-icon {border-color: '.esc_js($border_color).';}';
}

if($style == 'text' ) {
	if(isset($text) && !empty($text)) {
		$text_typo_style = dpr_generate_typography_style($text_color, $text_font_size, $text_line_height, $text_letter_spacing, $text_font_style,$text_google_font);	
		$text_wrap_html .= '<div class="text-container"><h4 '.$text_typo_style.'>';
			$text_wrap_html .= esc_html($text);
		$text_wrap_html .= '</h4></div>';
	}
}

if( $style == 'icon' && $icon != '' && $icon != 'none' ) {
$icon_html .= '<div class="module-icon"><div class="icon-container"><i class="separator-icon '.esc_attr($icon).'"></i></div></div>';
}
if( $style == 'totop') {
$icon_html .= '<a href="#go-top"><div class="module-icon"><div class="icon-container"><i class="separator-icon dpr-icon-angle-up"></i></div></div></a>';
}

if( $style == 'image' && $icon_image_id != ''  ) {
	$img_style = '';
	$image_url = dpr_get_attachment_image_src( $icon_image_id, 'full' );
	if (! empty( $image_size )){
		
		$image_src = adeline_resize( $image_url[0], $image_size, $image_size, true, true, true );
		if(!$image_src) $image_src = $image_url[0];
	
	} else {
		
	$image_src = $image_url[0];
	}
	if ( ! empty( $image_size ) ) {

		$img_style .= 'style="';

		if ( isset( $image_size ) && ! empty( $image_size ) ) {
			$img_style .= 'width:' . esc_attr($image_size) . 'px; ';
		}

		$img_style .= '"';

	}
	$alt_text = get_post_meta($icon_image_id , '_wp_attachment_image_alt', true);
	$image_html .= '<img src="' . esc_url($image_src) . '"' . $img_style . ' alt ="'.esc_attr($alt_text).'"/>';
}


$output .= '<div id="'.esc_attr($unique_id).'" class="'.esc_attr($css_class).'">';
$output .= '<div class="dpr-separator-line-left" '.$pattern_style.'></div>';
	if(isset($style) && $style =='text' ) {
		$output .= $text_wrap_html;
	}
	if(isset($style) && ($style =='icon' || $style =='totop') ) {
		$output .= $icon_html;
	}
	if(isset($style) && $style =='image' ) {
		$output .= $image_html;
	}
$output .= '<div class="dpr-separator-line-right" '.$pattern_style.'></div>';
	
	if(!empty($custom_el_css)) {
		$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>");'
						. '})(jQuery);'
					. '</script>';
}
$output .=  '</div>';

$output .= '<div style="clear:both;"></div>';

echo $output;