<?php

// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}

/*

* Add-on Name: Image Grid

*/



class WPBakeryShortCode_DPR_Image_Grid extends WPBakeryShortCode {}



vc_map(

	array(

		'name'					=> esc_html__('DP Image Grid', 'dpr-adeline-extensions'),

		'base'					=> 'dpr_image_grid',

		'class'					=> 'dpr_image_grid',

		'icon'					=> 'icon-dpr-image-grid',

  		"category" 				=>array( esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions')),

		'description' 			=> esc_html__('Display styled image grid','dpr-adeline-extensions'),

		'params'				=> array(

			array(

				'heading'			=> esc_html__('Grid Style', 'dpr-adeline-extensions'),

				'type'				=> 'dpr_image_select',

				'param_name'		=> 'grid_style',

				'value' => 'regular',

				'options'			=> array(

					'regular'	=> array(

						'label'	=> esc_html__('Regular','dpr-adeline-extensions'),

						'src'		=> $module_images . 'carousel/regular.png'

					),

					'masonry'	=> array(

						'label'	=> esc_html__('Masonry','dpr-adeline-extensions'),

						'src'		=> $module_images . 'carousel/masonry.png'

					),

				),

			),

			array(

				'heading'			=> esc_html__('Hover Animation Style', 'dpr-adeline-extensions'),

				'type'				=> 'dpr_image_select',

				'param_name'		=> 'hover_style',

				'value' => 'opacity',

				'options'			=> array(

					'overlay'	=> array(

						'label'	=> esc_html__('overlay','dpr-adeline-extensions'),

						'src'		=> $module_images . 'carousel/img-gallery-style-5.png'

					),

					'opacity'	=> array(

						'label'	=> esc_html__('Opacity','dpr-adeline-extensions'),

						'src'		=> $module_images . 'carousel/img-gallery-style-1.png'

					),

					'grayscale'	=> array(

						'label'	=> esc_html__('Grayscale','dpr-adeline-extensions'),

						'src'		=> $module_images . 'carousel/img-gallery-style-2.png'

					),

					'grayscale_opacity'	=> array(

						'label'	=> esc_html__('Grayscale&Opacity','dpr-adeline-extensions'),

						'src'		=> $module_images . 'carousel/img-gallery-style-4.png'

					),

					'secondary_image'	=> array(

						'label'	=> esc_html__('Secondary Image','dpr-adeline-extensions'),

						'src'		=> $module_images . 'carousel/img-gallery-style-6.png'

					),

					'flip'	=> array(

						'label'	=> esc_html__('Flip','dpr-adeline-extensions'),

						'src'		=> $module_images . 'carousel/img-gallery-style-3.png'

					),

				),

			),

			array(

				'type'				=> 'dpr_radio',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Columns count','dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Columns', 'dpr-adeline-extensions'),

				'param_name'		=> 'columns',

				'value'				=> '3',

				'options'			=> array(

					esc_html__('1', 'dpr-adeline-extensions')		=> 1,

					esc_html__('2', 'dpr-adeline-extensions')		=> 2,

					esc_html__('3', 'dpr-adeline-extensions')		=> 3,

					esc_html__('4', 'dpr-adeline-extensions')		=> 4,

					esc_html__('5', 'dpr-adeline-extensions')		=> 5,

					esc_html__('6', 'dpr-adeline-extensions')		=> 6,

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-8',

			),

			array(

				'type' => 'number',

				'class' => '',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to add the space between the grid items.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Items offset', 'dpr-adeline-extensions'),

				'param_name' => 'items_offset',

				'value' => '20',

				'min' => '0',

				'max' => '100',

				'step' => '1',

				'edit_field_class' => 'vc_column vc_col-sm-4',

			),

			

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Additional Settings', 'dpr-adeline-extensions' ),

				'param_name'       => 'extra_features_title',

				'edit_field_class' => 'vc_column vc_col-sm-12',

			),

		   vc_map_add_css_animation( false ),

		    array(

				'type' => 'textfield',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Extra Class Name', 'dpr-adeline-extensions'),

				'param_name' => 'el_class',

			),

			array(

				'type'				=> 'param_group',

				'heading'			=> esc_html__('Image List', 'dpr-adeline-extensions'),

				'param_name'		=> 'image_list',

				'value'				=> '',

				'params'			=> array(

					array(

						'type'			=> 'attach_image',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Upload the custom image from media library.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Upload Image', 'dpr-adeline-extensions'),

						'param_name'	=> 'image_id',

						'edit_field_class' => 'vc_column vc_col-sm-6',

					),

					array(

						'type'			=> 'attach_image',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Upload the custom image from media library.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Upload Hover Image', 'dpr-adeline-extensions'),

						'param_name'	=> 'secondary_image_id',

						'dependency'	=> array('element' => 'hover_style', 'value' => 'secondary_image'),

						'edit_field_class' => 'vc_column vc_col-sm-6',

						'description' => 'Used only when Secondary Image on hover style selected'

					),

					array(

						'type'			=> 'textfield',

						'heading' 		=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to add some information for the image. This option is available only for the Flip style.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Description', 'dpr-adeline-extensions'),

						'param_name'	=> 'description',

						'dependency'	=> array('element' => 'hover_style', 'value' => array('flip'))

					), 

					array(

						'type'				=> 'dpr_radio',

						'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to add the link to your image','dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Add Link?', 'dpr-adeline-extensions'),

						'param_name'		=> 'use_link',

						'value'				=> '',

						'options'			=> array(

							esc_html__('No', 'dpr-adeline-extensions')		=> '',

							esc_html__('Lightbox', 'dpr-adeline-extensions')	=> 'ligthbox',

							esc_html__('Custom', 'dpr-adeline-extensions')		=> 'custom'

						),

						'edit_field_class'	=> 'vc_column vc_col-sm-6',

					),

					array(

						'type'			=> 'vc_link',

						'heading' 		=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Add a custom link or select existing page.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Add link', 'dpr-adeline-extensions'),

						'param_name'	=> 'link',

						'edit_field_class'	=> 'vc_col-sm-6 vc_column',

						'dependency'	=> array('element' => 'use_link', 'value' => 'custom'),

					),

					array(

						'type'             => 'dpr_title',

						'text'             => '',

						'param_name'       => 'images_sep_1',

						'edit_field_class' => 'vc_column vc_col-sm-12',

					),

					array(

						'type'			=> 'dpr_switcher',

						'heading' 		=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to add custom back background for this image. It is used only by Flip Style.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Use custom back background?', 'dpr-adeline-extensions'),

						'param_name'	=> 'custom_back_bg',

						'options'		=> array(

							'yes'				=> array(

								'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

								'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

							),

						),

						'edit_field_class'	=> 'vc_column vc_col-sm-6',

					),

					array(

						'type'				=> 'colorpicker',

						'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the color for the flip backside background. The default color is inherited from Theme Options > Styling Options > Main Accent Color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Back Side Background', 'dpr-adeline-extensions'),

						'param_name'		=> 'custom_back_bg_color',

						'edit_field_class'	=> 'vc_column vc_col-sm-6',

						'dependency'		=> array('element' => 'custom_back_bg', 'value' => array('yes')),

					),

				),

				'group'				=> esc_html__('Images', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_radio',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select hover overlay style.','dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Overlay Style', 'dpr-adeline-extensions'),

				'param_name'		=> 'overlay_style',

				'value'				=> 'solid',

				'options'			=> array(

					esc_html__('Solid', 'dpr-adeline-extensions')		=> 'solid',

					esc_html__('Gradient', 'dpr-adeline-extensions')	=> 'gradient'

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'dependency'		=> array('element' => 'hover_style', 'value' => array('overlay')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the color for overlay background.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Overlay Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'overlay_background',

				'value' 			=> 'rgba(0,0,0,0.3)',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 no-padding-top',

				'dependency'		=> array('element' => 'overlay_style', 'value' => array('solid')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'dpr_gradient_picker',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the gradient for overlay.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Overlay Gradient', 'dpr-adeline-extensions'),

				'param_name' => 'overlay_gradient',

				'value' => '45;0%/rgb(77, 47, 255,0.3);100%/rgb(36, 143, 255,0.3)',

				'dependency'		=> array('element' => 'overlay_style', 'value' => array('gradient')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set the border radius for the image. The border radius is not set by default', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border radius', 'dpr-adeline-extensions'),

				'param_name' => 'thumb_radius',

				'suffix' => 'px',

				'min' => 0,

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group' => esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the color for the mask background. The default mask color is inherited from Theme Options > Styling Options > Main Accent Color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background', 'dpr-adeline-extensions'),

				'param_name'		=> 'mask_background',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'dependency'		=> array('element' => 'hover_style', 'value' => array('flip')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set the image\'s opacity for the idle state. The default opacity is 50%', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Opacity', 'dpr-adeline-extensions'),

				'param_name'		=> 'opacity_idle',

				'suffix' 			=> '%',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'dependency'		=> array('element' => 'hover_style', 'value' => array('opacity')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set the image\'s opacity for the hover state. The default opacity is no', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Opacity: Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'opacity_hover',

				'suffix' 			=> '%',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'dependency'		=> array('element' => 'hover_style', 'value' => array('opacity')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('This option allows you to enable or disable the border between the images.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Use borders?', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_borders',

				'options'			=> array(

					'yes'			=> array(

						'on'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'off'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the color for borders. Default is #d2d7de.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Borders color', 'dpr-adeline-extensions'),

				'param_name'		=> 'border_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'dependency'		=> array('element' => 'use_borders', 'value' => array('yes')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Description Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_typography_head',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'hover_style', 'value' => array('flip')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

				

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the color for the descrption. The default mask color is #fff.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-3',

				'dependency'		=> array('element' => 'hover_style', 'value' => array('flip')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size. If you leave this field blank will be used default size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'hover_style', 'value' => array('flip')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title linne height.Default is 18px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'hover_style', 'value' => array('flip')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'hover_style', 'value' => array('flip')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'title_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'dependency'		=> array('element' => 'hover_style', 'value' => array('flip')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

	  		),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font. .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_google_fonts',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'dependency'		=> array('element' => 'hover_style', 'value' => array('flip')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'title_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'dependency'		=> array('element' => 'use_google_fonts', 'value' => 'yes'),

			),



		),

	)

);