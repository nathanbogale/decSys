<?php
	
// disable direct access to the file	
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 *
 * Add theme specific widgets
 *
 **/
// Including file with template widgets
require_once(DPR_EXTENSIONS_PLUGIN_PATH.'inc/widgets/widgets.recent_comments.php');
require_once(DPR_EXTENSIONS_PLUGIN_PATH.'inc/widgets/widgets.flickr.php');
require_once(DPR_EXTENSIONS_PLUGIN_PATH.'inc/widgets/widgets.recent_posts.php');
require_once(DPR_EXTENSIONS_PLUGIN_PATH.'inc/widgets/widgets.contact_info.php');
require_once(DPR_EXTENSIONS_PLUGIN_PATH.'inc/widgets/widgets.social_icons.php');

if(!function_exists('dpr_register_widgets')) {
	function dpr_register_widgets() {
		register_widget("DPR_Comments_Widget");
		register_widget("DPR_Flickr_Widget");
		register_widget("DPR_Recent_Posts_Widget");
		register_widget("DPR_Contact_Info_Widget");
		register_widget("DPR_Social_Icons_Widget");
		if(class_exists ( 'Vc_Manager' )) {	
		require_once(DPR_EXTENSIONS_PLUGIN_PATH.'inc/widgets/widgets.subscribe.php');
		require_once(DPR_EXTENSIONS_PLUGIN_PATH.'inc/widgets/widgets.share.php');
			register_widget("DPR_Subscribe_Widget");
			register_widget("DPR_Share_Buttons_Widget");
		}
	
	}
}

// register template built-in widgets
add_action('widgets_init', 'dpr_register_widgets');



/*EOF*/