<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$output = $shortcode_output = $custom_el_css = $el_class  = $css_animation =  '';

$calendar_id = $display_switcher = $display_style = $calendar_year = $calendar_month = $calendar_day = $members_only = $small_style = '';

$light_color_bg = $light_color_text = $dark_color_bg= $dark_color_text = $date_bg = $date_number_color = $date_border = $av_date_bg = $av_date_number_bg = $av_date_number_color = $av_date_bg_h = $av_date_number_bg_h = $av_date_number_color_h = $t_date_number_border = $ac_date_bg = $app_bg = $app_header = $app_text = $app_text_light = $button_bg = $button_color = $button_bg_h = $button_color_h = '';


$atts = vc_map_get_attributes(  $this->getShortcode(), $atts  );
extract( $atts );

$el_class = $this->getExtraClass( $el_class );
if ( '' !== $css_animation && 'none' !== $css_animation ) {
	dpr_enqueue_waypoint_js();
	dpr_enqueue_animate_css();
	$el_class .= ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
}
$unique_id = uniqid('dpr-booked-calendar').'-'.rand(1,9999);

$css_classes = array(
	'dpr-booked-calendar',
	esc_attr($unique_id),
	$el_class,
);



$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->settings['base'], $atts ) );

/* * ************************
 * Styles and custom CSS
 * *********************** 
*/

//Header
	if(isset($light_color_bg) && !empty($light_color_bg)) {
		$custom_el_css .= '.'.esc_js($unique_id).'   table.booked-calendar th,.'.esc_js($unique_id).'   table.booked-calendar thead,.'.esc_js($unique_id).'   table.booked-calendar thead th,.'.esc_js($unique_id).'   #booked-profile-page .booked-profile-header,.'.esc_js($unique_id).'   #booked-profile-page .booked-tabs li.active a,.'.esc_js($unique_id).'   #booked-profile-page .booked-tabs li.active a:hover { background:'.$light_color_bg.' !important; }';

		$custom_el_css .= '.'.esc_js($unique_id).'  table.booked-calendar th, .'.esc_js($unique_id).' #booked-profile-page .booked-profile-header { border-color:'.$light_color_bg.' !important; }';

	};
	if(isset($light_color_text) && !empty($light_color_text)) {
		$custom_el_css .= '.'.esc_js($unique_id).'   table.booked-calendar th,.'.esc_js($unique_id).'   table.booked-calendar thead,.'.esc_js($unique_id).'   table.booked-calendar thead th,.'.esc_js($unique_id).'   #booked-profile-page .booked-profile-header, .'.esc_js($unique_id).'  table.booked-calendar th .monthName a,.'.esc_js($unique_id).' table.booked-calendar th .page-left, .'.esc_js($unique_id).' table.booked-calendar th .page-right  { color:'.$light_color_text.' !important; }';


	};

	if(isset($dark_color_bg) && !empty($dark_color_bg)) {
		$custom_el_css .= '.'.esc_js($unique_id).' body table.booked-calendar tr.days,.'.esc_js($unique_id).' table.booked-calendar tr.days th, .'.esc_js($unique_id).' .booked-calendarSwitcher.calendar, .'.esc_js($unique_id).'  #booked-profile-page .booked-tabs,.'.esc_js($unique_id).' #ui-datepicker-div.booked_custom_date_picker table.ui-datepicker-calendar thead, .'.esc_js($unique_id).' #ui-datepicker-div.booked_custom_date_picker table.ui-datepicker-calendar thead th { background:'.$dark_color_bg.' !important; }';

		$custom_el_css .= '.'.esc_js($unique_id).' table.booked-calendar tr.days th,.'.esc_js($unique_id).' #booked-profile-page .booked-tabs { border-color:'.$dark_color_bg.' !important; }';

	

	};

	if(isset($dark_color_text) && !empty($dark_color_text)) {
		$custom_el_css .= '.'.esc_js($unique_id).' table.booked-calendar tr.days,.'.esc_js($unique_id).' table.booked-calendar tr.days th, .'.esc_js($unique_id).' .booked-calendarSwitcher.calendar, .'.esc_js($unique_id).'  #booked-profile-page .booked-tabs,.'.esc_js($unique_id).' #ui-datepicker-div.booked_custom_date_picker table.ui-datepicker-calendar thead, .'.esc_js($unique_id).' #ui-datepicker-div.booked_custom_date_picker table.ui-datepicker-calendar thead th, .'.esc_js($unique_id).' .booked-calendarSwitcher.calendar p:before, .'.esc_js($unique_id).' .booked-calendarSwitcher.calendar p i.booked-icon,.'.esc_js($unique_id).'  .booked-calendarSwitcher.calendar select { color:'.$dark_color_text.' !important; }';	
	};

	if(isset($date_bg) && !empty($date_bg)) {
		$custom_el_css .= '.'.esc_js($unique_id).' table.booked-calendar td.prev-month .date,.'.esc_js($unique_id).' table.booked-calendar td.prev-date:hover .date,.'.esc_js($unique_id).'  table.booked-calendar td.prev-date:hover .date span, .'.esc_js($unique_id).' table.booked-calendar td.prev-date .date { background-color:'.$date_bg.' !important; }';	
	};
	if(isset($date_number_color) && !empty($date_number_color)) {
		$custom_el_css .= '.'.esc_js($unique_id).' table.booked-calendar td.prev-date .date, .'.esc_js($unique_id).' table.booked-calendar td.prev-date:hover .date,.'.esc_js($unique_id).' table.booked-calendar td.prev-date:hover .date span,.'.esc_js($unique_id).'  table.booked-calendar td.next-month .date span,.'.esc_js($unique_id).' table.booked-calendar td.prev-month .date span {color:'.$date_number_color.' !important; }';	
	};
	if(isset($date_border) && !empty($date_border)) {
		$custom_el_css .= '.'.esc_js($unique_id).' table.booked-calendar td  { border-color:'.$date_border.' !important; }';	
	};
	if(isset($av_date_bg) && !empty($av_date_bg)) {
		$custom_el_css .= '.'.esc_js($unique_id).' table.booked-calendar td .date { background-color:'.$av_date_bg.'; }';	
	};
	if(isset($av_date_number_color) && !empty($av_date_number_color)) {
		$custom_el_css .= '.'.esc_js($unique_id).' table.booked-calendar td {color:'.$av_date_number_color.' !important; }';	
	};
	if(isset($av_date_bg_h) && !empty($av_date_bg_h)) {
		$custom_el_css .= '.'.esc_js($unique_id).' table.booked-calendar td:hover .date  { background-color:'.$av_date_bg_h.' !important; }';	
	};
	if(isset($av_date_number_bg_h) && !empty($av_date_number_bg_h)) {
		$custom_el_css .= '.'.esc_js($unique_id).' table.booked-calendar td:hover .date span { background-color:'.$av_date_number_bg_h.' !important; }';	
	};
	if(isset($av_date_number_color_h) && !empty($av_date_number_color_h)) {
		$custom_el_css .= '.'.esc_js($unique_id).' table.booked-calendar td:hover .date span { color:'.$av_date_number_color_h.' !important; }';	
	};
	if(isset($t_date_number_border) && !empty($t_date_number_border)) {
		$custom_el_css .= '.'.esc_js($unique_id).' table.booked-calendar td.today .date span { border-color:'.$t_date_number_border.' !important; }';
		$custom_el_css .= '.'.esc_js($unique_id).' table.booked-calendar td.today .date:hover span { background-color:'.$t_date_number_border.' !important; }';	
	};
	if(isset($ac_date_bg) && !empty($ac_date_bg)) {
		$custom_el_css .= '.'.esc_js($unique_id).'  table.booked-calendar tr.week td.active .date, .'.esc_js($unique_id).' table.booked-calendar tr.entryBlock, .'.esc_js($unique_id).' .booked-calendar-wrap.small table.booked-calendar tr.week td.active .date .number { background-color:'.$ac_date_bg.' !important; border-bottom-color:'.$ac_date_bg.' !important;}';	
		$custom_el_css .= '.'.esc_js($unique_id).'  table.booked-calendar td.active, .'.esc_js($unique_id).'  table.booked-calendar td.active date { border-bottom-color:'.$ac_date_bg.' !important;}';	
	};
	if(isset($app_bg) && !empty($app_bg)) {
		$custom_el_css .= '.'.esc_js($unique_id).' table.booked-calendar .booked-appt-list { background-color:'.$app_bg.' !important;}';	
	};
	if(isset($app_header) && !empty($app_header)) {
		$custom_el_css .= '.'.esc_js($unique_id).' table.booked-calendar .booked-appt-list h2 { color:'.$app_header.' !important;}';	
	};
	if(isset($app_text) && !empty($app_text)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .booked-calendar-wrap .booked-appt-list .timeslot .timeslot-time , .'.esc_js($unique_id).' .booked-calendar-wrap .booked-appt-list .timeslot .timeslot-time i.booked-icon{ color:'.$app_text.' !important;}';	
	};
	if(isset($app_text_light) && !empty($app_text_light)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .booked-calendar-wrap .booked-appt-list .timeslot .spots-available { color:'.$app_text_light.' !important;}';	
	};
	if(isset($app_border) && !empty($app_border)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .booked-calendar-wrap .booked-appt-list .timeslot  { border-top-color:'.$app_border.' !important;}';	
	};	
	if(isset($app_hover_bg) && !empty($app_hover_bg)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .booked-calendar-wrap .booked-appt-list .timeslot:hover { background-color:'.$app_hover_bg.' !important;}';	
	};
	if(isset($button_bg) && !empty($button_bg)) {
		$custom_el_css .= '.'.esc_js($unique_id).' #booked-profile-page input[type=submit].button-primary,.'.esc_js($unique_id).' table.booked-calendar input[type=submit].button-primary,.'.esc_js($unique_id).' .booked-list-view button.button,.'.esc_js($unique_id).' .booked-list-view input[type=submit].button-primary, body .booked-modal input[type=submit].button-primary,.'.esc_js($unique_id).' table.booked-calendar .booked-appt-list .timeslot .timeslot-people button,.'.esc_js($unique_id).' #booked-profile-page .booked-profile-appt-list .appt-block.approved .status-block,.'.esc_js($unique_id).' #booked-profile-page .appt-block .google-cal-button > a,body .booked-modal p.booked-title-bar { background-color:'.$button_bg.' !important;}';
		$custom_el_css .= '.'.esc_js($unique_id).' #booked-profile-page input[type=submit].button-primary,.'.esc_js($unique_id).' table.booked-calendar input[type=submit].button-primary,.'.esc_js($unique_id).' .booked-list-view button.button,.'.esc_js($unique_id).' .booked-list-view input[type=submit].button-primary, body .booked-modal input[type=submit].button-primary,.'.esc_js($unique_id).' table.booked-calendar .booked-appt-list .timeslot .timeslot-people button,.'.esc_js($unique_id).' #booked-profile-page .booked-profile-appt-list .appt-block.approved .status-block,.'.esc_js($unique_id).' #booked-profile-page .appt-block .google-cal-button > a {border-color:'.$button_bg.' !important;}';		
	};		
	if(isset($button_color) && !empty($button_color)) {
		$custom_el_css .= '.'.esc_js($unique_id).' #booked-profile-page input[type=submit].button-primary,.'.esc_js($unique_id).' table.booked-calendar input[type=submit].button-primary,.'.esc_js($unique_id).' .booked-list-view button.button,.'.esc_js($unique_id).' .booked-list-view input[type=submit].button-primary, body .booked-modal input[type=submit].button-primary,.'.esc_js($unique_id).' table.booked-calendar .booked-appt-list .timeslot .timeslot-people button,.'.esc_js($unique_id).' #booked-profile-page .booked-profile-appt-list .appt-block.approved .status-block,.'.esc_js($unique_id).' #booked-profile-page .appt-block .google-cal-button > a, .'.esc_js($unique_id).' table.booked-calendar .booked-appt-list .timeslot button .spots-available, body .booked-calendar-wrap .booked-appt-list .timeslot button .spots-available {color:'.$button_color.' !important;}';
	};
if(isset($button_bg_h) && !empty($button_bg_h)) {
		$custom_el_css .= '.'.esc_js($unique_id).' #booked-profile-page input[type=submit].button-primary:hover,.'.esc_js($unique_id).' table.booked-calendar input[type=submit].button-primary:hover,.'.esc_js($unique_id).' .booked-list-view button.button:hover,.'.esc_js($unique_id).' .booked-list-view input[type=submit].button-primary, body .booked-modal input[type=submit].button-primary:hover,.'.esc_js($unique_id).' table.booked-calendar .booked-appt-list .timeslot .timeslot-people button:hover,.'.esc_js($unique_id).' #booked-profile-page .booked-profile-appt-list .appt-block.approved .status-block:hover,.'.esc_js($unique_id).' #booked-profile-page .appt-block .google-cal-button > a:hover { background-color:'.$button_bg_h.' !important;}';
		$custom_el_css .= '.'.esc_js($unique_id).' #booked-profile-page input[type=submit].button-primary:hover,.'.esc_js($unique_id).' table.booked-calendar input[type=submit].button-primary:hover,.'.esc_js($unique_id).' .booked-list-view button.button:hover,.'.esc_js($unique_id).' .booked-list-view input[type=submit].button-primary:hover, body .booked-modal input[type=submit].button-primary:hover,.'.esc_js($unique_id).' table.booked-calendar .booked-appt-list .timeslot .timeslot-people button:hover,.'.esc_js($unique_id).' #booked-profile-page .booked-profile-appt-list .appt-block.approved .status-block:hover,.'.esc_js($unique_id).' #booked-profile-page .appt-block .google-cal-button > a:hover {border-color:'.$button_bg_h.' !important;}';		
	};		
	if(isset($button_color_h) && !empty($button_color_h)) {
		$custom_el_css .= '.'.esc_js($unique_id).' #booked-profile-page input[type=submit].button-primary:hover,.'.esc_js($unique_id).' table.booked-calendar input[type=submit].button-primary:hover,.'.esc_js($unique_id).' .booked-list-view button.button:hover,.'.esc_js($unique_id).' .booked-list-view input[type=submit].button-primary:hover, body .booked-modal input[type=submit].button-primary:hover,.'.esc_js($unique_id).' table.booked-calendar .booked-appt-list .timeslot .timeslot-people button:hover,.'.esc_js($unique_id).' #booked-profile-page .booked-profile-appt-list .appt-block.approved .status-block:hover,.'.esc_js($unique_id).' #booked-profile-page .appt-block .google-cal-button > a:hover {color:'.$button_color_h.' !important;}';
	};	
	if($small_style == 'yes' && isset($small_today_bg) && !empty($small_today_bg)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .booked-calendar-wrap.small table.booked-calendar td.today .date {background-color:'.$small_today_bg.';}';
	};
	if($small_style == 'yes' && isset($small_today_color) && !empty($small_today_color)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .booked-calendar-wrap.small table.booked-calendar td.today .date span{color:'.$small_today_color.' !important;}';
	};
	if($small_style == 'yes' && isset($small_today_bg_h) && !empty($small_today_bg_h)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .booked-calendar-wrap.small table.booked-calendar td.today:hover .date span {background-color:'.$small_today_bg_h.' !important;}';
	};
	if($small_style == 'yes' && isset($small_today_color_h) && !empty($small_today_color_h)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .booked-calendar-wrap.small table.booked-calendar td.today:hover .date span{color:'.$small_today_color_h.' !important;}';
	};

// Date
	


/* * ************************
 * Output
 * *********************** */

$shortcode_output = '[booked-calendar ';
if ( ! empty( $calendar_id ) ) {
			$shortcode_output .='calendar="'.$calendar_id.'" ';
}
if ( $display_switcher == 'yes' )  {
			$shortcode_output .='switcher="true" ';
}
if ( $display_style == 'list' )  {
			$shortcode_output .='style="list" ';
}
if ( $small_style == 'yes' )  {
			$shortcode_output .='size="small" ';
}
if ( $members_only == 'yes' )  {
			$shortcode_output .='members-only="true" ';
}
if ( ! empty($calendar_year) )  {
			$shortcode_output .='year="'.$calendar_year.'" ';
}
if ( ! empty($calendar_month) )  {
			$shortcode_output .='month="'.$calendar_month.'" ';
}
if ( ! empty($calendar_day) )  {
			$shortcode_output .='year="'.$calendar_day.'" ';
}

$shortcode_output .=']';

echo '<div id="'.esc_attr($unique_id).'" class="'.esc_attr($css_class).'">';

echo do_shortcode($shortcode_output);
if(!empty($custom_el_css)) {
		$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>");'
						. '})(jQuery);'
					. '</script>';
}
echo '</div>';
echo $output;