<?php

/**



 * Woocoommerce Options -> Menu Cart Style



 *



 */

Redux::setSection($opt_name, array(

    'title'      => esc_html__('Menu Cart', 'dpr-adeline-extensions'),

    'id'         => 'menu_cart',

    'subsection' => true,

    'fields'     => array(

        array(

            'id'      => 'menu_cart_display_mode',

            'type'    => 'radio',

            'title'   => __('Display Mode', 'dpr-adeline-extensions'),

            'options' => array(

                'disabled'         => 'Disabled',

                'icon'             => 'Icon',

                'icon_total'       => 'Icon & Total',

                'icon_count'       => 'Icon & Count',

                'icon_count_total' => 'Icon & Count & Total',

            ),

            'default' => 'icon_count',

            'hint'    => array(

                'title'   => esc_attr__('Display Mode', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set display mode for menu cart icon', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_cart_menu_to display',

            'type'     => 'radio',

            'title'    => __('Display in Menu', 'dpr-adeline-extensions'),

            'required' => array('menu_cart_display_mode', '!=', array('disabled')),

            'options'  => array(

                'main'   => 'Main Menu',

                'topbar' => 'Top Bar Menu',

            ),

            'default'  => 'main',

            'hint'     => array(

                'title'   => esc_attr__('Display in Menu', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set where manu cart should be displayed', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'hide_empty_menu_cart',

            'type'     => 'switch',

            'default'  => false,

            'title'    => esc_html__('Hide Empty Cart', 'dpr-adeline-extensions'),

            'required' => array('menu_cart_display_mode', '!=', array('disabled')),

            'hint'     => array(

                'title'   => esc_attr__('Hide Empty Cart', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Hide menu icon if empty cart.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'open_menu_cart_when_product_added',

            'type'     => 'switch',

            'default'  => false,

            'title'    => esc_html__('Open Cart when Product Added', 'dpr-adeline-extensions'),

            'required' => array('menu_cart_display_mode', '!=', array('disabled')),

            'hint'     => array(

                'title'   => esc_attr__('Open Cart when Product Added', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Dropdown menu cart when product added.Work in the shop and the single product pages if ajax is enabled.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'add_mobile_mini_cart',

            'type'     => 'switch',

            'default'  => true,

            'title'    => esc_html__('Display Mini Cart on Mobile', 'dpr-adeline-extensions'),

            'required' => array('menu_cart_display_mode', '!=', array('disabled')),

            'hint'     => array(

                'title'   => esc_attr__('Display Mini Cart on Mobile', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set display nini cart on mobile devices.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_cart_count_bg',

            'type'     => 'color',

            'output'   => array('background-color' => '.wcmenucart-details.count', 'border-color' => '.wcmenucart-details.count:before'),

            'validate' => 'color',

            'title'    => esc_html__('Count Indicator Background', 'dpr-adeline-extensions'),

            'required' => array('menu_cart_display_mode', 'equals', array('icon_count', 'icon_count_total')),

            'default'  => '#D3AE5F',

            'hint'     => array(

                'title'   => esc_attr__('Count Indicator Background', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set count indicator background color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_cart_count_color',

            'type'     => 'color',

            'output'   => array('color' => '.wcmenucart-details.count'),

            'validate' => 'color',

            'title'    => esc_html__('Count Indicator Color', 'dpr-adeline-extensions'),

            'required' => array('menu_cart_display_mode', 'equals', array('icon_count', 'icon_count_total')),

            'default'  => '#FFFFFF',

            'hint'     => array(

                'title'   => esc_attr__('Count Indicator Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set count indicator color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_cart_style',

            'type'     => 'radio',

            'title'    => __('Style', 'dpr-adeline-extensions'),

            'required' => array('menu_cart_display_mode', '!=', array('disabled')),

            'options'  => array(

                'drop_down'   => 'Drop Down',

                'cart'        => 'Cart',

                'custom_link' => 'Custom Link',

            ),

            'default'  => 'drop_down',

            'hint'     => array(

                'title'   => esc_attr__('Style', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set style for menu cart', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_cart_custom_link',

            'type'     => 'text',

            'title'    => __('Custom Link', 'dpr-adeline-extensions'),

            'default'  => '',

            'required' => array('menu_cart_style', 'equals', 'custom_link'),

            'hint'     => array(

                'title'   => esc_attr__('Custom Link', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set custom link for menu cart icon. Style must be set for custom link.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_cart_icon',

            'type'     => 'image_select',

            'title'    => __('Cart Icon', 'dpr-adeline-extensions'),

            'required' => array('menu_cart_display_mode', '!=', array('disabled')),

            'options'  => array(

                'dpr-icon-bag'             => array(

                    'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/menu-cart/bag.png',

                ),

                'dpr-icon-basket'          => array(

                    'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/menu-cart/basket.png',

                ),

                'dpr-icon-basket-loaded'   => array(

                    'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/menu-cart/basket-loaded.png',

                ),

                'dpr-icon-handbag'         => array(

                    'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/menu-cart/handbag.png',

                ),

                'dpr-icon-shopping-bag'    => array(

                    'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/menu-cart/shopping-bag.png',

                ),

                'dpr-icon-shopping-basket' => array(

                    'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/menu-cart/shopping-basket.png',

                ),

                'dpr-icon-bag3' => array(

                    'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/menu-cart/bag3.png',

                ),

                'dpr-icon-bag4' => array(

                    'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/menu-cart/bag4.png',

                ),

                'dpr-icon-bag5' => array(

                    'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/menu-cart/bag5.png',

                ),

                'custom'                   => array(

                    'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/menu-cart/custom.png',

                ),

            ),

            'default'  => 'dpr-icon-handbag',

            'hint'     => array(

                'title'   => esc_attr__('Cart Icon', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Choose icon for menu cart.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_cart_custom_icon',

            'type'     => 'dpr_icon_selector',

            'title'    => __('Custom Icon', 'dpr-adeline-extensions'),

            'required' => array('menu_cart_icon', 'equals', 'custom'),

            'default'  => '',

            'hint'     => array(

                'title'   => esc_attr__('Custom Icon', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set custom menu cart icon.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_cart_dropdown_info',

            'type'     => 'info',

            'style'    => 'dpr-title',

            'required' => array('menu_cart_style', 'equals', 'drop_down'),

            'title'    => wp_kses_post(__('<h3>Dropdown Styling</h3>', 'dpr-adeline-extensions')),

        ),

        array(

            'id'       => 'menu_cart_dropdown_width',

            'type'     => 'dimensions',

            'units'    => array('px'),

            'mode'     => array('width' => 'width', 'height' => 'height'),

            'height'   => false,

            'output'   => array('#current-shop-items-dropdown'),

            'title'    => __('Dropdown Width', 'dpr-adeline-extensions'),

            'default'  => array(

                'Width' => '300px',

            ),

            'hint'     => array(

                'title'   => esc_attr__('Dropdown Width', 'dpr-adeline-extensions'),

                'content' => esc_attr__('You can set menu cart dropdown width.', 'dpr-adeline-extensions'),

            ),

            'required' => array('menu_cart_style', 'equals', 'drop_down'),

        ),

        array(

            'id'       => 'menu_cart_dropdown_bg',

            'type'     => 'color',

            'output'   => array('background-color' => '#current-shop-items-dropdown'),

            'validate' => 'color',

            'title'    => esc_html__('Background Color', 'dpr-adeline-extensions'),

            'required' => array('menu_cart_style', 'equals', 'drop_down'),

            'default'  => '#ffffff',

            'hint'     => array(

                'title'   => esc_attr__('Background Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set background color for menu cart dropdown.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_cart_dropdown_separators_color',

            'type'     => 'color',

            'output'   => array('border-color' => '#dpr-navigation .woocommerce.widget_shopping_cart .cart_list li'),

            'validate' => 'color',

            'title'    => esc_html__('Separators Color', 'dpr-adeline-extensions'),

            'required' => array('menu_cart_style', 'equals', 'drop_down'),

            'default'  => '#e5e5e9',

            'hint'     => array(

                'title'   => esc_attr__('Seprators Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set separators color for menu cart dropdown.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_cart_dropdown_links_color',

            'type'     => 'color',

            'output'   => array('color' => '#dpr-navigation .woocommerce.widget_shopping_cart .cart_list li a'),

            'validate' => 'color',

            'title'    => esc_html__('Links Color', 'dpr-adeline-extensions'),

            'required' => array('menu_cart_style', 'equals', 'drop_down'),

            'default'  => '#292933',

            'hint'     => array(

                'title'   => esc_attr__('Links Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set links color for menu cart dropdown.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_cart_dropdown_links_color_hover',

            'type'     => 'color',

            'output'   => array('color' => '#dpr-navigation .woocommerce.widget_shopping_cart .cart_list li a:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Links Color: Hover', 'dpr-adeline-extensions'),

            'required' => array('menu_cart_style', 'equals', 'drop_down'),

            'default'  => '#D3AE5F',

            'hint'     => array(

                'title'   => esc_attr__('Links Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set links hover color for menu cart dropdown.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_cart_dropdown_remove_link_color',

            'type'     => 'color',

            'output'   => array('color' => 'body #dpr-navigation .woocommerce ul.product_list_widget li a.remove'),

            'validate' => 'color',

            'title'    => esc_html__('Remove Icon Color', 'dpr-adeline-extensions'),

            'required' => array('menu_cart_style', 'equals', 'drop_down'),

            'default'  => '#292933',

            'hint'     => array(

                'title'   => esc_attr__('Remove Icon Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set remove link color for menu cart dropdown.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_cart_dropdown_remove_link_color_hover',

            'type'     => 'color',

            'output'   => array('color' => 'body #dpr-navigation .woocommerce ul.product_list_widget li a.remove:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Remove Icon Color: Hover', 'dpr-adeline-extensions'),

            'required' => array('menu_cart_style', 'equals', 'drop_down'),

            'default'  => '#D3AE5F',

            'hint'     => array(

                'title'   => esc_attr__('Remove Icon Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set remove hover color for menu cart dropdown.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_cart_dropdown_price_color',

            'type'     => 'color',

            'output'   => array('color' => '#dpr-navigation #current-shop-items-dropdown .amount'),

            'validate' => 'color',

            'title'    => esc_html__('Price Color', 'dpr-adeline-extensions'),

            'required' => array('menu_cart_style', 'equals', 'drop_down'),

            'default'  => '#D3AE5F',

            'hint'     => array(

                'title'   => esc_attr__('Price Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set price color for menu cart dropdown.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_cart_dropdown_subtotal_color',

            'type'     => 'color',

            'output'   => array('color' => '#site-navigation .woocommerce .total strong'),

            'validate' => 'color',

            'title'    => esc_html__('Subtotal Color', 'dpr-adeline-extensions'),

            'required' => array('menu_cart_style', 'equals', 'drop_down'),

            'default'  => '#292933',

            'hint'     => array(

                'title'   => esc_attr__('Subtotal Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set subtotal color for menu cart dropdown.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_cart_dropdown_checkout_bg',

            'type'     => 'color',

            'output'   => array('background-color' => '.woocommerce .widget_shopping_cart_content .buttons .checkout', 'border-color' => '.woocommerce .widget_shopping_cart_content .buttons .checkout'),

            'validate' => 'color',

            'title'    => esc_html__('Checkout Button Background', 'dpr-adeline-extensions'),

            'required' => array('menu_cart_style', 'equals', 'drop_down'),

            'default'  => '#D3AE5F',

            'hint'     => array(

                'title'   => esc_attr__('Checkout Button Background', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set checkout button background color for menu cart dropdown.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_cart_dropdown_checkout_color',

            'type'     => 'color',

            'output'   => array('color' => '.woocommerce .widget_shopping_cart_content .buttons .checkout'),

            'validate' => 'color',

            'title'    => esc_html__('Checkout Button Color', 'dpr-adeline-extensions'),

            'required' => array('menu_cart_style', 'equals', 'drop_down'),

            'default'  => '#FFFFFF',

            'hint'     => array(

                'title'   => esc_attr__('Checkout Button Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set checkout button color for menu cart dropdown.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_cart_dropdown_checkout_bg_hover',

            'type'     => 'color',

            'output'   => array('background-color' => '.woocommerce .widget_shopping_cart_content .buttons .checkout:hover', 'border-color' => '.woocommerce .widget_shopping_cart_content .buttons .checkout:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Checkout Button Background: Hover', 'dpr-adeline-extensions'),

            'required' => array('menu_cart_style', 'equals', 'drop_down'),

            'default'  => '#292933',

            'hint'     => array(

                'title'   => esc_attr__('Checkout Button Background: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set checkout button background color for menu cart dropdown.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_cart_dropdown_checkout_color_hover',

            'type'     => 'color',

            'output'   => array('color' => '#dpr-navigation .woocommerce .widget_shopping_cart_content .buttons .checkout:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Checkout Button Color: Hover', 'dpr-adeline-extensions'),

            'required' => array('menu_cart_style', 'equals', 'drop_down'),

            'default'  => '#ffffff',

            'hint'     => array(

                'title'   => esc_attr__('Checkout Button Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set checkout button hover color for menu cart dropdown.', 'dpr-adeline-extensions'),

            ),

        ),

    ),

));
