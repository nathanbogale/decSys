<?php

/**

 * Proof Gallery Options

 *

 */

Redux::setSection($opt_name, array(

    'title'  => __('Proofing Galleries', 'dpr-adeline-extensions'),

    'id'     => 'proofgalery_tab',

    'icon'   => 'el el-camera',

    'fields' => array(


        array(

            'id'      => 'proof_gallery_page_layout',

            'type'    => 'image_select',

            'title'   => __('General Layout', 'dpr-adeline-extensions'),

            'options' => array(

                'right-sidebar' => array(

                    'title' => esc_html__('Sidebar right', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/sidebar_right.png',

                ),

                'left-sidebar'  => array(

                    'title' => esc_html__('Sidebar left', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/sidebar_left.png',

                ),

                'both-sidebars' => array(

                    'title' => esc_html__('Both sidebars', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/sidebar_both.png',

                ),

                'full-width'    => array(

                    'title' => esc_html__('Full width', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/sidebar_disabled.png',

                ),

                'full-screen'   => array(

                    'title' => esc_html__('Full screen', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/full_screen.png',

                ),

            ),

            'default' => 'full-width',

            'hint'    => array(

                'title'   => esc_attr__('Proof Gallery Page Layout', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Choose proof gallery page layout eg sidebar position.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'proof_gallery_both_sidebars_column_order',

            'type'     => 'image_select',

            'title'    => __('Both Sidebars: Column Order', 'dpr-adeline-extensions'),

            'options'  => array(

                'order-scs' => array(

                    'title' => esc_html__('Sidebar/Content/Sidebar', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/scs.png',

                ),

                'order-ssc' => array(

                    'title' => esc_html__('Sidebar/Sidebar/Content', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/ssc.png',

                ),

                'order-css' => array(

                    'title' => esc_html__('Content/Sidebar/Sidebar', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/css.png',

                ),

            ),

            'default'  => 'order-scs',

            'hint'     => array(

                'title'   => esc_attr__('Both Sidebars: Column Order', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Choose default column order.', 'dpr-adeline-extensions'),

            ),

            'required' => array('proof_gallery_page_layout', 'equals', 'both-sidebars'),

        ),


        array(

            'id'    => 'proof_gallery_header_overlaping_info',

            'type'  => 'info',

            'style' => 'dpr-title',

            'title' => wp_kses_post(__('<h3>Header Overlapping Settings</h3>', 'dpr-adeline-extensions')),

        ),
               
        array(

            'id'       => 'proofgallery_use_header_overlapping',

            'type'     => 'switch',

            'default'  => false,

            'title'    => esc_html__('Use Header Overlapping', 'dpr-adeline-extensions'),

            'required' => array('header_style', 'not_contain', 'vertical'), 'hint' => array(

                'title'   => esc_attr__('Use Header Overlapping', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Use transparent or semitransparent overlapped header', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'proofgallery_overlapping_header_bg_color',

            'type'     => 'color',

            'output'   => array('background-color' => '.single-proof_gallery.header-overlapping-used #dpr-header'),

            'validate' => 'color',

            'title'    => esc_html__('Overlapping Header Background Color', 'dpr-adeline-extensions'),

            'default'  => 'rgba(0,0,0,0)',

            'required' => array('proofgallery_use_header_overlapping', 'equals', '1'),

            'hint'     => array(

                'title'   => esc_attr__('Overlapping Header Background Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set overlapping header background color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'proofgallery_overlapping_header_style',

            'type'     => 'radio',

            'title'    => __('Overlapping Header Style', 'dpr-adeline-extensions'),

            'options'  => array(

                'light' => 'Light',

                'dark'  => 'Dark',

            ),

            'default'  => 'light',

            'required' => array('proofgallery_use_header_overlapping', 'equals', '1'),

            'hint'     => array(

                'title'   => esc_attr__('Overlapping Header Style', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Select default overlapping style. Light is intented for headers with a dark background , dark for light backgrounds,', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'    => 'proof_gallery_subheader_info',

            'type'  => 'info',

            'style' => 'dpr-title',

            'title' => wp_kses_post(__('<h3>Subheader</h3>', 'dpr-adeline-extensions')),

        ),

        array(

            'id'      => 'proof_gallery_subheader_display',

            'type'    => 'switch',

            'default' => true,

            'title'   => esc_html__('Display Subheader', 'dpr-adeline-extensions'),

            'hint'    => array(

                'title'   => esc_attr__('Display Subheader', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enable or disable display subheader area on proof gallery pages.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'proof_gallery_subheader_visibility',

            'type'     => 'image_select',

            'title'    => __('Visibility', 'dpr-adeline-extensions'),

            'options'  => array(

                'all-devices'        => array(

                    'title' => esc_html__('All Devices', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/visibility/all.png',

                ),

                'hide-tablet'        => array(

                    'title' => esc_html__('Hide On Tablet', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/visibility/no_tablet.png',

                ),

                'hide-mobile'        => array(

                    'title' => esc_html__('Hide On Mobile', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/visibility/no_mobile.png',

                ),

                'hide-tablet-mobile' => array(

                    'title' => esc_html__('Hide On Tablet & Mobile', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/visibility/no_tablet_mobile.png',

                ),

            ),

            'default'  => 'all-devices',

            'hint'     => array(

                'title'   => esc_attr__('Visibility', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enable or disable display subheader area  on proof galleries on certain devices.', 'dpr-adeline-extensions'),

            ),

            'required' => array('proof_gallery_subheader_display', 'equals', '1'),

        ),

        array(

            'id'       => 'proof_gallery_subheader_alignment',

            'type'     => 'select',

            'title'    => esc_html__('Alignment', 'dpr-adeline-extensions'),

            'desc'     => '',

            'options'  => array(

                'lefted'   => esc_html__('Left', 'dpr-adeline-extensions'),

                'centered' => esc_html__('Centered', 'dpr-adeline-extensions'),

            ),

            'default'  => 'centered',

            'hint'     => array(

                'title'   => esc_attr__('Alignment', 'dpr-adeline-extensions'),

                'content' => esc_attr__('You can use default left alignment or center subheader content on proof galleries.', 'dpr-adeline-extensions'),

            ),

            'required' => array('proof_gallery_subheader_display', 'equals', '1'),

        ),

        array(

            'id'       => 'proof_gallery_subheader_height',

            'type'     => 'dimensions',

            'units'    => array('px'),

            'mode'     => array('width' => 'width', 'height' => 'height'),

            'width'    => false,

            'output'   => array('.single-proof_gallery .subheader'),

            'title'    => __('Subheader Height', 'dpr-adeline-extensions'),

            'default'  => array(

                'Height' => '230px',

            ),

            'hint'     => array(

                'title'   => esc_attr__('Subheader Height', 'dpr-adeline-extensions'),

                'content' => esc_attr__('You can set subheader height  on proof galleries.', 'dpr-adeline-extensions'),

            ),

            'required' => array('proof_gallery_subheader_display', 'equals', '1'),

        ),

        array(

            'id'             => 'proof_gallery_subheader_padding',

            'type'           => 'spacing',

            'output'         => array('.single-proof_gallery .subheader'),

            'mode'           => 'padding',

            'units'          => array('px', 'em'),

            'left'           => false,

            'right'          => false,

            'display_units'  => true,

            'units_extended' => false,

            'title'          => __('Vertical Padding', 'dpr-adeline-extensions'),

            'default'        => array(

                'padding-top'    => '0px',

                'padding-bottom' => '0px',

                'units'          => 'px',

            ),

            'hint'           => array(

                'title'   => esc_attr__('Vertical Padding', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Using padding you can adjust vertical position of title in subheader area  on proof galleries', 'dpr-adeline-extensions'),

            ),

            'required'       => array('proof_gallery_subheader_display', 'equals', '1'),

        ),

        array(

            'id'       => 'proof_gallery_subheader_bg',

            'type'     => 'background',

            'title'    => __('Background', 'dpr-adeline-extensions'),

            'default'  => array(

                'background-color' => '#292933',

            ),

            'output'   => array('.single-proof_gallery .subheader'),

            'hint'     => array(

                'title'   => esc_attr__('Background', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set background for subheader area subheader area on proof galleries', 'dpr-adeline-extensions'),

            ),

            'required' => array('proof_gallery_subheader_display', 'equals', '1'),

        ),

        array(

            'id'       => 'proof_gallery_subheader_overlay',

            'type'     => 'switch',

            'default'  => false,

            'title'    => esc_html__('Use Subheader Overlay', 'dpr-adeline-extensions'),

            'hint'     => array(

                'title'   => esc_attr__('Use Subheader Overlay', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enable overlay layer over subheader background on proof galleries.', 'dpr-adeline-extensions'),

            ),

            'required' => array('proof_gallery_subheader_display', 'equals', '1'),

        ),

        array(

            'id'       => 'proof_gallery_subheader_overlay_bg_color',

            'type'     => 'color',

            'title'    => __('Overlay Color', 'dpr-adeline-extensions'),

            'default'  => 'rgba(0,0,0,.5)',

            'output'   => array('background-color' => '.single-proof_gallery .subheader-overlay'),

            'hint'     => array(

                'title'   => esc_attr__('Overlay Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set background color for subheader overlay on proof galleries.', 'dpr-adeline-extensions'),

            ),

            'required' => array('proof_gallery_subheader_overlay', 'equals', '1'),

        ),

        array(

            'id'       => 'proof_gallery_subheader_title_color',

            'type'     => 'color',

            'title'    => __('Title Color', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'output'   => array('.single-proof_gallery .subheader-title'),

            'hint'     => array(

                'title'   => esc_attr__('Title Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set title color on proof gallery pages.', 'dpr-adeline-extensions'),

            ),

            'required' => array('proof_gallery_subheader_display', 'equals', '1'),

        ),

       array(

            'id'       => 'proof_gallery_subheader_subtitle_color',

            'type'     => 'color',

            'title'    => __('Subitle Color', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'output'   => array('.single-proof_gallery .subheader-title'),

            'hint'     => array(

                'title'   => esc_attr__('Subtitle Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set subtitle color on proof gallery pages.', 'dpr-adeline-extensions'),

            ),

            'required' => array('proof_gallery_subheader_display', 'equals', '1'),

        ),
        array(

            'id'    => 'proof_gallery_colorr_info',

            'type'  => 'info',

            'style' => 'dpr-title',

            'title' => wp_kses_post(__('<h3>Proof Gallery Colors Settings</h3>', 'dpr-adeline-extensions')),

        ),

        array(

            'id'      => 'proof_gallery_select_button_bg',

            'type'    => 'color',

            'title'   => __('Select Button Background', 'dpr-adeline-extensions'),

            'default' => '#D3AE5F',

            'output'  => array( 'background-color' =>'.dpr-proof-gallery .proof-photo .actions-nav .select-action .button-text'),

            'hint'    => array(

                'title'   => esc_attr__('Selct Button Background', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set background color for select button.', 'dpr-adeline-extensions'),

            ),

        ),
        array(

            'id'      => 'proof_gallery_select_button_color',

            'type'    => 'color',

            'title'   => __('Select Button Color', 'dpr-adeline-extensions'),

            'default' => '#FFFFFF',

            'output'  => array( 'color' =>'.dpr-proof-gallery .proof-photo .actions-nav .select-action .button-text'),

            'hint'    => array(

                'title'   => esc_attr__('Select Button Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set color for select button.', 'dpr-adeline-extensions'),

            ),

        ),        		
        array(

            'id'      => 'proof_gallery_zoom_icon_color',

            'type'    => 'color',

            'title'   => __('Zoom Icon Color', 'dpr-adeline-extensions'),

            'default' => '#ffffff',

            'output'  => array( 'color' => 'a.meta__action.zoom-action'),

            'hint'    => array(

                'title'   => esc_attr__('Zoom Icon Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set zoom icon color for photo hover overlay.', 'dpr-adeline-extensions'),

            ),

        ),               

        array(

            'id'      => 'proof_gallery_ticker_bg',

            'type'    => 'color',

            'title'   => __('Ticker Background', 'dpr-adeline-extensions'),

            'default' => '#D3AE5F',

            'output'  => array( 'border-top-color' => '.dpr-proof-gallery .proof-photo__status span.ticker:before'),

            'hint'    => array(

                'title'   => esc_attr__('Ticker Background', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set background color for corner status ticker.', 'dpr-adeline-extensions'),

            ),

        ),        
        array(

            'id'      => 'proof_gallery_ticker_color',

            'type'    => 'color',

            'title'   => __('Ticker Color', 'dpr-adeline-extensions'),

            'default' => '#FFFFFF',

            'output'  => array( 'color' => '.dpr-proof-gallery .proof-photo__status span.ticker'),

            'hint'    => array(

                'title'   => esc_attr__('Ticker Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set color for corner status ticker.', 'dpr-adeline-extensions'),

            ),

        ),                
         array(

            'id'      => 'proof_gallery_description_bg',

            'type'    => 'color',

            'title'   => __('Photo ID Background', 'dpr-adeline-extensions'),

            'default' => '#fff',

            'output'  => array( 'background-color' => '.dpr-proof-gallery .proof-photo__id'),

            'hint'    => array(

                'title'   => esc_attr__('Photo ID Background', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set bacgkround color for photo ID.', 'dpr-adeline-extensions'),

            ),

        ),
        array(

            'id'      => 'proof_gallery_description_color',

            'type'    => 'color',

            'title'   => __('Photo ID Color', 'dpr-adeline-extensions'),

            'default' => '#555555',

            'output'  => array( 'color' => '.dpr-proof-gallery .proof-photo__id'),

            'hint'    => array(

                'title'   => esc_attr__('Photo ID Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set color for photo ID.', 'dpr-adeline-extensions'),

            ),

        ),       
        array(

            'id'      => 'proof_gallery_overlay_color',

            'type'    => 'color',

            'title'   => __('Hover Overlay Color', 'dpr-adeline-extensions'),

            'default' => 'rgba(0,0,0,0.8)',

            'output'  => array( 'background-color' => '.dpr-proof-gallery .proof-photo:hover .proof-photo__meta'),

            'hint'    => array(

                'title'   => esc_attr__('Hover Overlay Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set color for photo hover overlay.', 'dpr-adeline-extensions'),

            ),

        ), 

        array(

            'id'    => 'proof_gallery_ppc_info',

            'type'  => 'info',

            'style' => 'dpr-title',

            'title' => wp_kses_post(__('<h3>Password Page Settings</h3>', 'dpr-adeline-extensions')),

        ),

        array(

            'id'       => 'proof_gallery_ppc_style',

            'type'     => 'radio',

            'title'    => __('Password Page Style', 'dpr-adeline-extensions'),

            'options'  => array(

                'light'  => 'Light',

                'dark' => 'Dark',

            ),

            'default'  => 'light',

            'hint'     => array(

                'title'   => esc_attr__('Password Page Style', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Select page style light for light backrounds or dark for dark backgrounds', 'dpr-adeline-extensions'),

            )

        ),
        array(

            'id'       => 'proof_gallery_ppc_title',

            'type'     => 'text',

            'title'    => __('Title', 'dpr-adeline-extensions'),

            'default'  => 'Password Protected Gallery',

            'hint'     => array(

                'title'   => esc_attr__('Title', 'dpr-adeline-extensions'),

                'content' => esc_attr__('This text will be displayed as password protected gallery title.', 'dpr-adeline-extensions'),

            ),

        ),
        array(

            'id'       => 'proof_gallery_ppc_subtitle',

            'type'     => 'textarea',

            'title'    => esc_html__('Subtitle', 'dpr-adeline-extensions'),

            'desc'     => esc_html__('Some HTML and shortcodes are allowed here', 'dpr-adeline-extensions'),

            'validate' => 'html',

            'default'  => 'To view it please enter your password below',

            'hint'     => array(

                'title'   => esc_attr__('Subtitle', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Add  subtitle content. Will be displayed bellow title', 'dpr-adeline-extensions'),

            ),

        ),
        array(

            'id'       => 'proof_gallery_ppc_placehoder',

            'type'     => 'text',

            'title'    => __('Placeholder Text', 'dpr-adeline-extensions'),

            'default'  => 'Enter Password',

            'hint'     => array(

                'title'   => esc_attr__('Placeholder Text', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set placeholder for password input.', 'dpr-adeline-extensions'),

            ),

        ),        
        array(

            'id'       => 'proof_gallery_ppc_submit_text',

            'type'     => 'text',

            'title'    => __('Submit Button Text', 'dpr-adeline-extensions'),

            'default'  => 'Submit',

            'hint'     => array(

                'title'   => esc_attr__('Submit Button Text', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set submit button text.', 'dpr-adeline-extensions'),

            ),

        ), 
        array(

            'id'       => 'proof_gallery_ppc_bg',

            'type'     => 'background',

            'title'    => __('Password Protecttion Background', 'dpr-adeline-extensions'),

            'default'  => array(

                'background-color' => '#f1f2f4',

            ),

            'output'   => array('.single-proof_gallery.password-required #dpr-content-wrapper'),

            'hint'     => array(

                'title'   => esc_attr__('Background', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set background for password protection screen', 'dpr-adeline-extensions'),

            ),

        ),
      
    ),

));
