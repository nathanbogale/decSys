<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$unique_id = $css_animation = $el_class = $output = $custom_el_css = $layout = $currency = $price = $price_period = '';
$title = $title_color = $title_font_size = $title_line_height  = $title_letter_spacing = $title_font_style = $title_google_font = $title_typo_style = '';
$subtitle = $subtitle_color = $subtitle_font_size = $subtitle_line_height  = $subtitle_letter_spacing = $subtitle_font_style = $subtitle_google_font = $subtitle_typo_style = '';
$subtitle = $subtitle_color = $subtitle_font_size = $subtitle_line_height  = $subtitle_letter_spacing = $subtitle_font_style = $subtitle_google_font = $subtitle_typo_style = '';
$content_description = $content_color = $content_font_size = $content_line_height  = $content_letter_spacing = $content_font_style = $content_google_font = $content_typo_style = '';
$features_color = $features_font_size = $features_line_height  = $features_letter_spacing = $features_font_style = $features_google_font = $features_typo_style = '';
$use_icon = $icon_type = $icon = $icon_image_id = $icon_text = $icon_size = $icon_color = $text_icon_color = $text_icon_font_size = $text_icon_line_height = $text_icon_letter_spacing = $text_icon_font_style = $text_icon_use_google_fonts = $text_icon_custom_fonts = '';
$list_values = $button_text = $button_link = $button_full_width = $button_color = $button_hover_color = $button_bg_color = $button_bg_hover_color = $button_border_color = $button_border_color_hover = $button_border_radius = $button_left_padding = $button_right_padding = '';
$badge_text = $badge_color = $badge_bg_color = $badge_border_radius = '';
$border_style = $border_color = $border_width = $border_radius = $border_color_hover = $border_width_hover = $border_radius_hover = $box_bg_color = $top_bg_color = $features_bg_color = $top_offset = $bottom_offset = $use_hover_shadow = $box_shadow = '';
$delimeter_style = $delimeter_color = $use_arrow = $symbol_size = $amount_size = $period_size = $price_letter_spacing = $price_color = $features_delimiter_style = $features_delimiter_color = $features_icon_size = $features_icon_color = $features_offset = '';
$front_bg_color = $back_bg_color = $front_image_id = $back_image_id = $min_height = '';
$icon_html = $icon_style = $title_html = $subtitle_html = '';


$atts = vc_map_get_attributes( 'dpr_price_box', $atts );
extract( $atts );

$el_class = $this->getExtraClass( $el_class );
if ( '' !== $css_animation && 'none' !== $css_animation ) {
	dpr_enqueue_waypoint_js();
	dpr_enqueue_animate_css();
	$el_class .= ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
}
$unique_id = uniqid('dpr-price-box-').'-'.rand(1,9999);

/* Element classes */
if(isset($layout)) {
	$el_class .= ' style-'.$layout;
	if($layout == 'flip') {
		 $el_class .= ' dpr-flip-item';
	}
}

if(isset($button_full_width) && $button_full_width == 'yes') {
	$el_class .= ' full-width-button';
}
if(isset($use_hover_shadow) && $use_hover_shadow == 'yes' && dpr_shadow_param_to_css($box_shadow) != '') {
	$el_class .= ' shadow-on-hover';
}
if(isset($use_arrow) && $use_arrow == 'yes') {
	$el_class .= ' with-arrow-delimiter';	
}

$css_classes = array(
	'dpr-price-box',
	$unique_id,
	$el_class,
);

$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->settings['base'], $atts ) );

/* Styles */
if(dpr_shadow_param_to_css($box_shadow) != '') {
	$custom_el_css .= '.'.esc_js($unique_id) .'.shadow-on-hover:hover {'.dpr_shadow_param_to_css($box_shadow).'}';
}

if(isset($top_bg_color) && !empty($top_bg_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).'.style-classic .box-top {background-color: '.esc_attr($top_bg_color).';}';
	$custom_el_css .= '.'.esc_js($unique_id).'.style-classic .down-indicator path {fill: '.esc_attr($top_bg_color).';stroke: '.esc_attr($top_bg_color).';}';

}
if(isset($features_bg_color) && !empty($features_bg_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).'.style-classic .box-bottom {background-color: '.esc_attr($features_bg_color).';}';
}
if(isset($box_bg_color) && !empty($box_bg_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).'.style-color .box-bottom, .'.esc_js($unique_id).'.style-color .box-top {background-color: '.esc_attr($box_bg_color).';}';
}
if(isset($bottom_offset) && $bottom_offset != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .box-bottom {padding-bottom: '.esc_attr($bottom_offset).'px;}';
}
if(isset($top_offset) && $top_offset != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .box-top {padding-top: '.esc_attr($top_offset).'px;}';
}
if($border_radius != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' {border-radius:' . $border_radius . 'px}';
}
if($border_radius_hover != '') {
	$custom_el_css .= '.'.esc_js($unique_id).':hover {border-radius:' . $border_radius_hover . 'px}';
}
if(isset($symbol_size) && !empty($symbol_size)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .box-top .price-wrap .currency-symbol {font-size: '.esc_attr($symbol_size).'px;}';
}
if(isset($amount_size) && !empty($amount_size)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .box-top .price-wrap .price-amount {font-size: '.esc_attr($amount_size).'px;}';
}
if(isset($period_size) && !empty($period_size)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .box-top .price-wrap .recuring-time {font-size: '.esc_attr($period_size).'px;}';
}
if(isset($price_letter_spacing) && !empty($price_letter_spacing)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .box-top .price-wrap {letter-spacing: '.esc_attr($price_letter_spacing).'px;}';
}
if(isset($price_color) && !empty($price_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .box-top .price-wrap {color: '.esc_attr($price_color).' !important;}';
}

if(isset($delimeter_style) && !empty($delimeter_style)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .box-top {border-style: '.esc_attr($delimeter_style).';}';
}
if(isset($delimeter_color) && !empty($delimeter_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .box-top {border-color: '.esc_attr($delimeter_color).';}';
}
if(isset($features_delimiter_style) && !empty($features_delimiter_style)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .box-bottom .options-list .option {border-style: '.esc_attr($features_delimiter_style).';}';
}
if(isset($features_delimiter_color) && !empty($features_delimiter_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .box-bottom .options-list .option {border-color: '.esc_attr($features_delimiter_color).';}';
}
if(isset($badge_color) && !empty($badge_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .box-top .price-box-badge {color: '.esc_attr($badge_color).';}';
}
if(isset($badge_bg_color) && !empty($badge_bg_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .box-top .price-box-badge {background-color: '.esc_attr($badge_bg_color).';}';
}
if(isset($badge_border_radius) && !empty($badge_border_radius)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .box-top .price-box-badge {border-radius: '.esc_attr($badge_border_radius).'px;}';
}
if(isset($features_icon_size) && !empty($features_icon_size)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .box-bottom .options-list .option i {font-size: '.esc_attr($features_icon_size).'px;}';
}
if(isset($features_icon_color) && !empty($features_icon_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .box-bottom .options-list .option i {color: '.esc_attr($features_icon_color).';}';
}
if(isset($features_offset) && $features_offset != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .box-bottom .options-list .option {padding: '.esc_attr($features_offset).'px 0;}';
}
if(isset($button_color) && !empty($button_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .box-bottom .pricing-button {color: '.esc_attr($button_color).' !important;}';
}
if(isset($button_hover_color) && !empty($button_hover_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .box-bottom .pricing-button:hover {color: '.esc_attr($button_hover_color).' !important;}';
}
if(isset($button_bg_color) && !empty($button_bg_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .box-bottom .pricing-button {background-color: '.esc_attr($button_bg_color).' !important;}';
}
if(isset($button_bg_hover_color) && !empty($button_bg_hover_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .box-bottom .pricing-button:hover {background-color: '.esc_attr($button_bg_hover_color).' !important;}';
}
if(isset($button_border_color) && !empty($button_border_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .box-bottom .pricing-button {border-color: '.esc_attr($button_border_color).' !important;}';
}
if(isset($button_border_color_hover) && !empty($button_border_color_hover)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .box-bottom .pricing-button:hover {border-color: '.esc_attr($button_border_color_hover).'!important;}';
}

if($layout == 'flip') {
	if(isset($front_bg_color) && $front_bg_color != '') {
		$custom_el_css .= '.'.esc_js($unique_id).' .flip-wrap-front {background-color: '.esc_attr($front_bg_color).' !important;}';
	}
	if(isset($back_bg_color) && $back_bg_color != '') {
		$custom_el_css .= '.'.esc_js($unique_id).' .flip-wrap-back {background-color: '.esc_attr($back_bg_color).' !important;}';
	}
	if(isset($min_height) && $min_height != '') {
		$custom_el_css .= '.'.esc_js($unique_id).' .flip-wrap-front {min-height: '.esc_attr($min_height).'px}';
	}
	if(isset($front_image_id) && $front_image_id != '') {
		$front_image_url = dpr_get_attachment_image_src( $front_image_id, 'full' );
		$front_image_src = $front_image_url[0];
		$custom_el_css .= '.'.esc_js($unique_id).' .flip-wrap-front {background-image: url('.esc_url($front_image_src).');background-size:cover}';
	}
	if(isset($back_image_id) && $back_image_id != '') {
		$back_image_url = dpr_get_attachment_image_src( $back_image_id, 'full' );
		$back_image_src = $back_image_url[0];
		$custom_el_css .= '.'.esc_js($unique_id).' .flip-wrap-back {background-image: url('.esc_url($back_image_src).');;background-size:cover}';
	}
}

/* HTML Parts */
if(!empty($title)) {
	$title_typo_style = dpr_generate_typography_style($title_color, $title_font_size, $title_line_height, $title_letter_spacing, $title_font_style,$title_google_font);
	$title_html .= '<div class="box-title"><h4 class="title" ' . $title_typo_style . '>' . $title . '</h4></div>';
}

if(!empty($subtitle)) {
	$subtitle_typo_style = dpr_generate_typography_style($subtitle_color, $subtitle_font_size, $subtitle_line_height, $subtitle_letter_spacing, $subtitle_font_style,$subtitle_google_font);
	$subtitle_html .= '<div class="box-subtitle"><div class="title" ' . $subtitle_typo_style . '>' . $subtitle . '</div></div>';
}


if(isset($use_icon) && $use_icon == 'yes') {
	$icon_html = '<div class="icon-wrap">';
			if ('icon' === $icon_type) {
				
				if ($icon != '') {
					
					if (!empty($icon_size) || !empty($icon_color)) {
				
						$icon_style .= 'style="';
		
						if ( ! empty( $icon_size ) ) {
							$icon_style .= 'font-size:' . $icon_size . 'px; ';
						}
		
						if ( ! empty( $icon_color ) ) {
							$icon_style .= 'color:' . $icon_color.'; ';
						}
		
						$icon_style .= '"';
						}
				
					$icon_html .= '<i class="featured-icon ' . $icon . '" ' . $icon_style . '></i>';
				
				}
			
			} elseif('image' === $icon_type ) {
				$img_style = '';
				$image_url = dpr_get_attachment_image_src( $icon_image_id, 'full' );
				if (! empty( $icon_size )){
					
					$image_src = adeline_resize( $image_url[0], $icon_size, $icon_size, true, true, true );
					if(!$image_src) $image_src = $image_url[0];
				
				} else {
					
					$image_src = $image_url[0];
				
				}
				//$img_atts = adeline_image_attributes( $image_url[1], $image_url[2], $icon_size, $icon_size );
				if ( ! empty( $icon_size ) ) {
	
					$img_style .= 'style="';
	
					if ( isset( $icon_size ) && ! empty( $icon_size ) ) {
						$img_style .= 'width:' . esc_attr($icon_size) . 'px; ';
					}
	
					$img_style .= '"';
	
				}
				$alt_text = get_post_meta($icon_image_id , '_wp_attachment_image_alt', true);
				$icon_html .= '<img src="' . esc_url($image_src) . '"' . $img_style . ' alt ="'.esc_attr($alt_text).'"/>';
				
			} elseif('text' === $icon_type ) {
				$text_icon_typo_style = dpr_generate_typography_style($text_icon_color, $text_icon_font_size, $text_icon_line_height, $text_icon_letter_spacing, $text_icon_font_style, $text_icon_custom_fonts);
				$icon_html .= '<span class="dpr-text-icon-wrap" '.$text_icon_typo_style.'>'.  esc_html($icon_text).'</span>';
			} 
				
			$icon_html .= '</div>';
}

$box_link_attributes    = array();
if (function_exists('vc_build_link')) {
	$button_link = ( '||' === $button_link ) ? '' : $button_link;
	$button_link = vc_build_link( $button_link );

	$link_href   = $button_link['url'];
	$link_title  = $button_link['title'];
	$link_rel  = $button_link['rel'];
	$link_target = strlen($button_link['target']) > 0 ? $button_link['target'] : '_self';

	$box_link_attributes[] = 'href="' . esc_url( trim( $link_href ) ) . '"';
	$box_link_attributes[] = 'title="' . esc_attr( trim( $link_title ) ) . '"';
	$box_link_attributes[] = 'target="' . esc_attr( trim( $link_target ) ) . '"';
	$box_link_attributes[] = 'rel="' . esc_attr( trim( $link_rel ) ) . '"';
}

/* Output */
$output .= '<div id="'.esc_attr($unique_id).'" class="'.esc_attr($css_class).'">';
		if($layout == 'flip') {
			$output .= '<div class="flip-wrap"><div class="flip-wrap-front"><div class ="content-wrap">';
		}
		
		/* Box Head */
		$output .= '<div class="box-top">';
		
		if(isset($badge_text) && !empty($badge_text) ) {
			$output .= '<span class="price-box-badge">' . esc_html($badge_text) . '</span>';
		}
		
		$output .= $icon_html;
		$output .= $title_html;
		$output .= $subtitle_html;

		$output .= '<div class="price-wrap">';
			if ( ! empty( $currency ) ) {
				$output .= '<span class="currency-symbol">' . $currency . '</span>';
			}
			if ( ! empty( $price ) ) {
				$output .= '<span class="price-amount">' . $price . '</span>';
			}
			if ( ! empty( $price_period ) ) {
				$output .= '<span class="recuring-time"> /&nbsp;&nbsp;'.$price_period.'</span>';
			}
		$output .= '</div>';

		if(isset($content_description) && !empty($content_description)) {
			$content_typo_style = dpr_generate_typography_style($content_color, $content_font_size, $content_line_height, $content_letter_spacing, $content_font_style,$content_google_font);
			$output .= '<div class="content-desc" '.$content_typo_style.'>'.$content_description.'</div>';
		}
		$output .= '</div>';
		if($layout == 'flip') {
			$output .= '</div></div><div class="flip-wrap-back"><div class ="content-wrap">';
		}

		/* Box Head End */
				if(isset($use_arrow) && $use_arrow == 'yes') {
		$output .= '<svg class="down-indicator" xmlns="http://www.w3.org/2000/svg" version="1.1" width="100%" height="50" viewBox="0 0 100 51" preserveAspectRatio="none"><path d="M0 0 L50 50 L100 0 Z"></path></svg>';	
		}
		/* Box Bottom */
		$output .= '<div class="box-bottom">';
		if (function_exists('vc_param_group_parse_atts')) {
			$list_values = (array) vc_param_group_parse_atts($list_values);
			if (is_array($list_values)) {
			$features_typo_style = dpr_generate_typography_style($features_color, $features_font_size, $features_line_height, $features_letter_spacing, $features_font_style,$features_google_font);
			$output .= '<ul class="options-list">';
			
				foreach ($list_values as $item) {			
					$feature_icon_html = $dot_style = $feature_badge_html = '';			
					if(isset($item['features_style']) && ($item['features_style'] == 'text_icon' || $item['features_style'] == 'icon_only') ) {
					$feature_icon = '';
					switch ( $item['icon_type'] ) {
								case 'fontawesome':
								if (isset($item['icon_fontawesome']) && $item['icon_fontawesome'] != '') {
								$feature_icon = $item['icon_fontawesome'];
								}
								break;
								case 'openiconic':
								if (isset($item['icon_openiconic']) && $item['icon_openiconic'] != '') {
								$feature_icon = $item['icon_openiconic'];
								}
								break;
								case 'typicons':
								if (isset($item['icon_typicons']) && $item['icon_typicons'] != '') {
								$feature_icon = $item['icon_typicons'];
								}
								break;
								case 'entypo':
								if (isset($item['icon_entypo']) && $item['icon_entypo'] != '') {
								$feature_icon = $item['icon_entypo'];
								}
								break;
								case 'linecons':
								if (isset($item['icon_linecons']) && $item['icon_linecons'] != '') {
								$feature_icon = $item['icon_linecons'];
								}
								break;
								case 'pixelicons':
								if (isset($item['icon_pixelicons']) && $item['icon_pixelicons'] != '') {
								$feature_icon = $item['icon_pixelicons'];
								}
								break;
								case 'monosocial':
								if (isset($item['icon_monosocial']) && $item['icon_monosocial'] != '') {
								$feature_icon = $item['icon_monosocial'];
								}
								break;

					}
					// Enqueue needed font for icon element
					if ( 'pixelicons' !== $item['icon_type'] ) {
						vc_icon_element_fonts_enqueue( $item['icon_type'] );
					}
					$custom_icon_style = 'style="';
					if (!empty($item['custom_icon_color'])) {
						$custom_icon_style .= 'color:'.$item['custom_icon_color'].';';
					}
					$custom_icon_style .= '"';
					$feature_icon_html .= '<span class="option-icon"><i '. $custom_icon_style.' class="'.$feature_icon.'"></i></span>';
				}
				if(isset($item['use_feature_badge']) && $item['use_feature_badge'] == 'yes') {
					if(!empty($item['badge_text'])) {
						    $badge_style = 'style="';
							if (!empty($item['text_color'])) {
								$badge_style .= 'color:'.$item['text_color'].';';
							}
							if (!empty($item['bg_color'])) {
								$badge_style .= 'background-color:'.$item['bg_color'].';';
							}
							$badge_style .= '"';
							$feature_badge_html .= '<span '. $badge_style.' class="feature-badge">'.$item['badge_text'].'</span>';
					}
				}
				
				$output .= '<li class="option">';
					if($item['features_style'] === 'dot') {
						if(isset($item['dot_color']) && !empty($item['dot_color'])) {
							$dot_style = 'style="background: '.esc_attr($item['dot_color']).';"';
						}
						$output .= '<span class="price-box-dots"><span class="price-box-dot ' . $item['features_style'] . '" '.$dot_style.'></span></span>';
					} else {
						if (!empty($feature_icon_html) && ($item['features_style'] !== 'text_only')) {
							$output .= $feature_icon_html;
						}
						if (!empty($item['label']) && ($item['features_style'] !== 'icon_only')) {
							$output .= '<div class="feature-text" ' . $features_typo_style . '>' . $item['label'] . '</div>';
						}
					}
				$output .= $feature_badge_html;
				$output .= '</li>';
			

			}
			$output .= '</ul>';
		}
		if(isset($button_text) && !empty($button_text) && !empty($button_link)) {
			$output .='<a class="btn flat pricing-button" ' . implode( ' ', $box_link_attributes ) . '><span class="button-text ">'.$button_text.'</span></a>';
		}
		}
		$output .= '</div>';
		/* Box Bottom End */
	
		if($layout == 'flip') {
			$output .= '</div></div></div>';
		}
	


if(!empty($custom_el_css)) {
		$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>");'
						. '})(jQuery);'
					. '</script>';
}
$output .= '</div>';

echo $output;