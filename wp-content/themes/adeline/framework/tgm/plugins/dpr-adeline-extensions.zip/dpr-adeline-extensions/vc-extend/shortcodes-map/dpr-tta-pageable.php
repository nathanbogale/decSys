<?php

// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}



//VC TTA Pageable VC Map modifications



$settings = array (

  'name' => __( 'DP Pageable', 'dpr-adeline-extensions' ),

  'category' =>array( esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions')),

  'icon' => 'icon-dpr-pageable'

);



vc_map_update( 'vc_tta_pageable', $settings ); 



if(function_exists('vc_remove_param')) {

	

	vc_remove_param('vc_tta_pageable','title');

	vc_remove_param('vc_tta_pageable','color');

	vc_remove_param('vc_tta_pageable','autoplay');

	vc_remove_param('vc_tta_pageable','active_section');

	vc_remove_param('vc_tta_pageable','el_id');

	vc_remove_param('vc_tta_pageable','el_class');

	vc_remove_param('vc_tta_pageable','tab_position');

	vc_remove_param('vc_tta_pageable','pagination_style');

	vc_remove_param('vc_tta_pageable','pagination_color');

}



/* General Tabs */



	vc_add_param(

		'vc_tta_pageable', array(

			'type' => 'textfield',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Enter text used as widget title (Note: located above content element).', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Widget Title', 'dpr-adeline-extensions'),

			'param_name' => 'title',

			'value' => '',

			'weight' => 1

		)

	);

	vc_add_param(

		'vc_tta_pageable', array(

			'type' => 'dpr_radio',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select auto rotate for tabs in seconds (Note: disabled by default).', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Autoplay', 'dpr-adeline-extensions'),

			'param_name' => 'autoplay',

			'weight' => '1',

			'value' => 'none',

			'options' => array(

				__('None', 'dpr-adeline-extensions') => 'none',

				'1' => '1',

				'2' => '2',

				'3' => '3',

				'4' => '4',

				'5' => '5',

				'10' => '10',

				'20' => '20',

				'30' => '30',

				'40' => '40',

				'50' => '50',

				'60' => '60',

			)

		)

	);

	vc_add_param(

		'vc_tta_pageable', array(

			'type' => 'dpr_title',

			'text' => esc_html__('Additional settings', 'dpr-adeline-extensions'),

			'param_name' => 'tta_tabs_title_1',

			'class' => '',

			'weight' => 1

		)

	);





	vc_add_param(

		'vc_tta_pageable', array(

			'type' => 'textfield',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Enter active section number (Note: to have all sections closed on initial load enter non-existing number).', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Active section', 'dpr-adeline-extensions'),

			'param_name' => 'active_section',

			'value' => '1',

			'weight' => 0

		)

	);



	vc_add_param(

		'vc_tta_pageable', array(

			'type' => 'textfield',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Enter element ID (Note: make sure it is unique and valid according to w3c specification).).', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Element ID', 'dpr-adeline-extensions'),

			'param_name' => 'el_id',

			'value' => '',

			'weight' => 0

		)

	);



	vc_add_param(

		'vc_tta_pageable', array(

			'type' => 'textfield',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Extra class name', 'dpr-adeline-extensions'),

			'param_name' => 'el_class',

			'value' => '',

			'weight' => 0

		)

	);





/* Dots Group */



	vc_add_param(

		'vc_tta_pageable', array(

			'type' => 'dpr_image_select',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Select general style for pagination dots', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Style', 'dpr-adeline-extensions'),

			'param_name' => 'pagination_style',

			'weight' => '1',

			'group'	=> esc_html__('Navigation Style', 'dpr-adeline-extensions'),

			'value' => '',

			'options'			=> array(

				''			=> array(

					'label'			=> esc_html__('None','dpr-adeline-extension'),

					'src'				=> $module_images . 'dots/none.png'

				),

				'outline-square'			=> array(

					'label'			=> esc_html__('Square','dpr-adeline-extension'),

					'src'				=> $module_images . 'dots/square.png'

				),

				'outline-round'			=> array(

					'label'			=> esc_html__('Radio','dpr-adeline-extension'),

					'src'				=> $module_images . 'dots/radio.png'

				),

				'flat-round'			=> array(

					'label'			=> esc_html__('Point','dpr-adeline-extension'),

					'src'				=> $module_images . 'dots/points.png'

				),

				'flat-square'			=> array(

					'label'			=> esc_html__('Fill Square','dpr-adeline-extension'),

					'src'				=> $module_images . 'dots/filled-square.png'

				),

				'flat-rounded'			=> array(

					'label'			=> esc_html__('Fill Rounded','dpr-adeline-extension'),

					'src'				=> $module_images . 'dots/filled-rounded.png'

				),

				'bar'			=> array(

					'label'			=> esc_html__('Bar','dpr-adeline-extension'),

					'src'				=> $module_images . 'dots/bars.png'

				),

				'flat-bar'			=> array(

					'label'			=> esc_html__('Fill Bar','dpr-adeline-extension'),

					'src'				=> $module_images . 'dots/filed-bars.png'

				)

			),

		)

	);

	vc_add_param(

		'vc_tta_pageable', array(

			'type' => 'dpr_radio',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select dots navigation position.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Navigation Position', 'dpr-adeline-extensions'),

			'param_name' => 'tab_position',

			'edit_field_class' => 'vc_column vc_col-sm-4',

			'weight' => '1',

			'value' => 'top',

			'group'	=> esc_html__('Navigation Style', 'dpr-adeline-extensions'),

			'options' => array(

				__('Top', 'dpr-adeline-extensions') => 'top',

				__('Bottom', 'dpr-adeline-extensions') => 'bottom',

			),

			'dependency' => array(

				'element' => 'pagination_style',

				'not_empty' => true,

			),

		)

	);

	vc_add_param(

		'vc_tta_pageable', array(

			'type' => 'colorpicker',

			'class' => '',

			'edit_field_class' => 'vc_column vc_col-sm-4',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Choose dots color for active and hover state.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Dots Color Active', 'dpr-adeline-extensions'),

			'param_name' => 'dots_color',

			'group'	=> esc_html__('Navigation Style', 'dpr-adeline-extensions'),

			'dependency' => array(

				'element' => 'pagination_style',

				'not_empty' => true,

			),

		)

	);

