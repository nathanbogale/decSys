<?php

if ( ! defined( 'ABSPATH' ) ) { exit; }

/*

* Add-on Name: Flip Box

*/



class WPBakeryShortCode_DPR_Team_Box extends WPBakeryShortCode {}



vc_map(

	array(

		'name'        => esc_html__('DP Team Box', 'dpr-adeline-extensions'),

		'base'        => 'dpr_team_box',

		'class'       => 'dpr_team_box',

		'icon'        => 'icon-dpr-team-box',

  		"category" 				=>array( esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions')),

		'description' => esc_html__('Display team members info. ', 'dpr-adeline-extensions'),

		'params'			=> array(

			array(

				'heading'			=> esc_html__('Style ', 'dpr-adeline-extensions'),

				'type'				=> 'dpr_image_select',

				'param_name'		=> 'style',

				'options'			=> array(

					'style-1'	=> array(

						'label'	=> esc_html__('Style 1','dpr-adeline-extensions'),

						'src'		=> $module_images . 'team-box/style-1.png'

					),

					'style-2'	=> array(

						'label'	=> esc_html__('Style 2','dpr-adeline-extensions'),

						'src'		=> $module_images . 'team-box/style-2.png'

					),

					'style-3'	=> array(

						'label'	=> esc_html__('Style 3','dpr-adeline-extensions'),

						'src'		=> $module_images . 'team-box/style-3.png'

					),

					'style-4'	=> array(

						'label'	=> esc_html__('Style 4','dpr-adeline-extensions'),

						'src'		=> $module_images . 'team-box/style-4.png'

					),

					'style-5'	=> array(

						'label'	=> esc_html__('Style 5','dpr-adeline-extensions'),

						'src'		=> $module_images . 'team-box/style-5.png'

					),

					'style-6'	=> array(

						'label'	=> esc_html__('Style 6','dpr-adeline-extensions'),

						'src'		=> $module_images . 'team-box/style-6.png'

					),

					'style-7'	=> array(

						'label'	=> esc_html__('Style 7','dpr-adeline-extensions'),

						'src'		=> $module_images . 'team-box/style-7.png'

					),

					'style-8'	=> array(

						'label'	=> esc_html__('Style 8','dpr-adeline-extensions'),

						'src'		=> $module_images . 'team-box/style-8.png'

					),

					'style-9'	=> array(

						'label'	=> esc_html__('Style 9','dpr-adeline-extensions'),

						'src'		=> $module_images . 'team-box/style-9.png'

					),

				),

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Additional Settings', 'dpr-adeline-extensions' ),

				'param_name'       => 'extra_features_title',

				'edit_field_class' => 'vc_column vc_col-sm-12',

			),

		   vc_map_add_css_animation( false ),

		    array(

				'type' => 'textfield',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Extra Class Name', 'dpr-adeline-extensions'),

				'param_name' => 'el_class',

			),

			/* Content */

			array(

				'type'				=> 'attach_image',

				'heading'			=> esc_html__('Upload Image', 'dpr-adeline-extensions'),

				'param_name'		=> 'image_id',

				'edit_field_class'	=> 'vc_column vc_col-sm-12  ',

				'description'		=> esc_html__('Choose the image from the media library', 'dpr-adeline-extensions'),

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'textfield',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set team box title.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Title', 'dpr-adeline-extensions'),

				'param_name'		=> 'title',

				'value' 			=> esc_html__('Member Name', 'dpr-adeline-extensions'),

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'textfield',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set team box subtitle.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Subtitle', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle',

				'value' 			=> esc_html__('Team box subtitle', 'dpr-adeline-extensions'),

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'textarea',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set team box description.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Team Box Description', 'dpr-adeline-extensions'),

				'param_name'		=> 'description',

				'value'				=> esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce malesuada lacus condimentum, convallis nulla.', 'dpr-adeline-extensions'),

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Custom Link', 'dpr-adeline-extensions' ),

				'param_name'       => 'content_title_12',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),		

			array(

				'type'			=> 'dpr_switcher',

				'heading' 		=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to add the link to this team box.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Aply Custom Link?', 'dpr-adeline-extensions'),

				'param_name'	=> 'use_link',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'options'		=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

			),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select where the link should be aplied.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Aply link to', 'dpr-adeline-extensions'),

				'param_name'		=> 'link_aply_to',

				'value'				=> 'title',

				'edit_field_class'	=> 'vc_column vc_col-sm-6  ',

				'options'			=> array(

					esc_html__('Title', 'dpr-adeline-extensions')	=> 'title',

					esc_html__('Image', 'dpr-adeline-extensions')	=> 'image'

				),

				'dependency'		=> array('element' => 'use_link', 'value' => array('yes')),

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'vc_link',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Add a custom link or select existing page. You can remove existing link as well.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Link URL', 'dpr-adeline-extensions'),

				'param_name'		=> 'box_link',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'dependency'		=> array('element' => 'use_link', 'value' => array('yes')),

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			

			/* Typography */			

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Title Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'typography_title_1',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom ttle color. Default is headings color set in template options.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size.Default is 18px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title linne height.Default is 18px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'title_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

	  		),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font. .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_use_google_fonts',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'title_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'dependency'		=> array('element' => 'title_use_google_fonts', 'value' => 'yes'),

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Subtitle Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_typography_head',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom subtitle color. Default is #808080.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size.Default is 13px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom linne height.Default is 28px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_letter_spacing',

				'min'				=> 1,

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'subtitle_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

	  		),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font. .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_use_google_fonts',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'subtitle_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'dependency'		=> array('element' => 'subtitle_use_google_fonts', 'value' => 'yes'),

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Description Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'description_typgraphy_head',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom content color. Default is text color set in template options.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'content_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size.Default text font size set in template options .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'content_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom line height. Default is text line height set in template options .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'content_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'content_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'content_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

	  		),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font. .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'content_use_google_fonts',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'dependency'		=> array('element' => 'title', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'content_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'dependency'		=> array('element' => 'content_use_google_fonts', 'value' => 'yes'),

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			/* Style */

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Text Alignment', 'dpr-adeline-extensions' ),

				'param_name'       => 'style_title_1',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),		

			array(

				'type'				=> 'dpr_radio',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose text alignment.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Text Alignment', 'dpr-adeline-extensions'),

				'param_name'		=> 'text_alignment',

				'value'				=> 'left',

				'edit_field_class'	=> 'vc_column vc_col-sm-6  ',

				'options'			=> array(

					esc_html__('Left', 'dpr-adeline-extensions')	=> 'left',

					esc_html__('Center', 'dpr-adeline-extensions')	=> 'center',

					esc_html__('Right', 'dpr-adeline-extensions')	=> 'right',

				),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Image Style', 'dpr-adeline-extensions' ),

				'param_name'       => 'style_title_2',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),		

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set image border radius.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Image Border Radius', 'dpr-adeline-extensions'),

				'param_name'		=> 'img_border_radius',

				'min'				=> 0,

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'dependency'		=> array('element' => 'enable_label', 'value' => 'yes'),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'			=> 'dpr_switcher',

				'heading' 		=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to add shadow for image.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Enable Shadow', 'dpr-adeline-extensions'),

				'param_name'	=> 'enable_shadow',

				'options'		=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

			),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('set shadow visibility.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Shadow Visibilirty', 'dpr-adeline-extensions'),

				'param_name'		=> 'shadow_visibility',

				'value'				=> 'onhover',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'options'			=> array(

					esc_html__('Allways', 'dpr-adeline-extensions')	=> 'allways',

					esc_html__('Only on Hover', 'dpr-adeline-extensions')	=> 'onhover'

				),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				"type" => "dpr_shadow_picker",

				"class" => "",

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set shadow for image.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Shadow', 'dpr-adeline-extensions'),

				"param_name" => "image_shadow",

				"value" => "none||||||",

				'dependency'		=> array('element' => 'enable_shadow', 'value' => 'yes'),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Social Links Style', 'dpr-adeline-extensions' ),

				'param_name'       => 'style_title_3',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom icon size.Default is 14px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon Size', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'class'				=> '',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom icon color for social links in idle state. The default is #292933.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6  ',

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Image Overlay Style', 'dpr-adeline-extensions' ),

				'param_name'       => 'style_title_4',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'style', 'value' => array('style-6','style-7')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'class'				=> '',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the overlay color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Overlay Color on Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'overlay_color_hover',

				'value'				=> 'rgba(0,0,0,0.6)',

				'edit_field_class'	=> 'vc_column vc_col-sm-4  ',

				'dependency'		=> array('element' => 'style', 'value' => array('style-6','style-7')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'			=> 'dpr_switcher',

				'heading' 		=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to add gradient overlay in idle state. This help you make title better visble in idle state.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Enable Idle Gradient Overlay', 'dpr-adeline-extensions'),

				'param_name'	=> 'enable_idle_overlay',

				'options'		=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

			),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'dependency'		=> array('element' => 'style', 'value' => array('style-3','style-6','style-8')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'            	=> 'dpr_title',

				'text'            	=> '',

				'class'			   	=> 'seprator',

				'param_name'       	=> 'style_title_4',

				'edit_field_class' 	=> 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'style', 'value' => array('style-3','style-6','style-8')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'dpr_gradient_picker',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the gradient overlay for idle state.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Gradient', 'dpr-adeline-extensions'),

				'param_name' => 'idle_overlay_gradient',

				'value' => '-90;0%/rgba(0, 0, 0, 0);52%/rgba(0, 0, 0, 0);100%/rgba(0, 0, 0, 0.5)',

				'dependency'		=> array('element' => 'enable_idle_overlay', 'value' => array('yes')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Flip Style', 'dpr-adeline-extensions' ),

				'param_name'       => 'style_title_5',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'style', 'value' => array('style-8','style-9')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'heading'			=> esc_html__('Flip Direction ', 'dpr-adeline-extensions'),

				'type'				=> 'dpr_image_select',

				'param_name'		=> 'flip_style',

				'dependency'		=> array('element' => 'style', 'value' => array('style-8','style-9')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

				'options'			=> array(

					'flip-right'	=> array(

						'label'	=> esc_html__('Flip Right','dpr-adeline-extensions'),

						'src'		=> $module_images . 'flip-box/rotate-right.jpg'

					),

					'flip-left'	=> array(

						'label'	=> esc_html__('Flip Left','dpr-adeline-extensions'),

						'src'		=> $module_images . 'flip-box/rotate-left.jpg'

					),

					'flip-top'	=> array(

						'label'	=> esc_html__('Flip Top','dpr-adeline-extensions'),

						'src'		=> $module_images . 'flip-box/rotate-top.jpg'

					),

					'flip-bottom'	=> array(

						'label'	=> esc_html__('Flip Bottom','dpr-adeline-extensions'),

						'src'		=> $module_images . 'flip-box/rotate-bottom.jpg'

					)

				),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Adjust fliper height .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Fliper Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'fliper_height',

				'min'				=> 1,

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'dependency'		=> array('element' => 'style', 'value' => array('style-8','style-9')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the color flip back side.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Back Side Background Color', 'dpr-adeline-extensions'),

				'class'				=> '',

				'param_name'		=> 'fliper_back_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'dependency'		=> array('element' => 'style', 'value' => array('style-8','style-9')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			/* Soclal Links */

			array(

				'type'				=> 'param_group',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Add social links to this team box.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Social Links', 'dpr-adeline-extensions'),

				'param_name'		=> 'social_networks',

				'value' => urlencode( json_encode( array(

				array(

					'network' => 'facebook',

				),

				array(

					'network' => 'instagram',

				),

				array(

					'network' => 'pinterest',

				),

			) ) ),



				'params'			=> array(

					array(

						'type'				=> 'dropdown',

						'param_name'		=> 'network',

						'heading'			=> esc_html__('Network', 'dpr-adeline-extensions'),

						'default' => '',

						'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

						'admin_label' => true,

						'value'			=> array(

							esc_html__('Facebook', 'dpr-adeline-extensions')		=> 'facebook',

							esc_html__('Twitter', 'dpr-adeline-extensions')			=> 'twitter',

							esc_html__('Google+', 'dpr-adeline-extensions')			=> 'google-plus',

							esc_html__('Pinterest', 'dpr-adeline-extensions')		=> 'pinterest-p',

							esc_html__('Dribbble', 'dpr-adeline-extensions')		=> 'dribbble',

							esc_html__('Instagram', 'dpr-adeline-extensions')		=> 'instagram',

							esc_html__('Linkedin', 'dpr-adeline-extensions')		=> 'linkedin',

							esc_html__('Flickr', 'dpr-adeline-extensions')			=> 'flickr',

							esc_html__('Skype', 'dpr-adeline-extensions')			=> 'skype',

							esc_html__('VK', 'dpr-adeline-extensions')				=> 'vk',

							esc_html__('Tumblr', 'dpr-adeline-extensions')			=> 'tumblr',

							esc_html__('Github', 'dpr-adeline-extensions')			=> 'github-alt',

							esc_html__('YouTube', 'dpr-adeline-extensions')			=> 'youtube',

							esc_html__('Vimeo', 'dpr-adeline-extensions')			=> 'vimeo',

							esc_html__('Vine', 'dpr-adeline-extensions')			=> 'vine',

							esc_html__('Stumbleupon', 'dpr-adeline-extensions')		=> 'stumbleupon',

							esc_html__('Xing', 'dpr-adeline-extensions')			=> 'xing',

							esc_html__('Digg', 'dpr-adeline-extensions')			=> 'digg',

							esc_html__('Lastfm', 'dpr-adeline-extensions')			=> 'lastfm',

							esc_html__('Soundcloud', 'dpr-adeline-extensions')		=> 'soundcloud',

							esc_html__('Delicious', 'dpr-adeline-extensions')		=> 'delicious',

							esc_html__('Yelp', 'dpr-adeline-extensions')			=> 'yelp',

							esc_html__('Tripadvisor', 'dpr-adeline-extensions') 	=> 'tripadvisor',

							esc_html__('Odnoklassniki', 'dpr-adeline-extensions') 	=> 'odnoklassniki',
							esc_html__('RSS', 'dpr-adeline-extensions')				=> 'rss',

							esc_html__('Email', 'dpr-adeline-extensions')			=> 'envelope-o',

						),

					

					),

					array(

						'type'				=> 'vc_link',

						'heading' => esc_html__('Link URL', 'dpr-adeline-extensions'),

						'param_name'		=> 'link',

						'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

					),

				),

				'group'				=> esc_html__('Social Links', 'dpr-adeline-extensions'),

			),

			

			

		)

	)

);