<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$output = $unique_id = $id = $style = $css_animation = $css = $el_class = $custom_el_css  = '';
$text_color = $placeholder_color =  $border_color = $border_color_focus = $bg_color = $bg_color_focus = $field_border_radius = '';
$button_style = $button_size = $button_shape = $button_alignment = $full_width = $button_border_width = $button_border_radius = $button_color = $button_color_hover = $button_bg_color = $button_bg_color_hover = $button_border_color = $button_border_color_hover = '';
$input_font_size = $input_line_height  = $input_letter_spacing = $input_font_style = $input_google_font = $input_typo_css = '';
$button_font_size = $button_line_height  = $button_letter_spacing = $button_font_style = $button_google_font = $button_typo_css =  $button_html = '';

$atts = vc_map_get_attributes( 'dpr_contact_form', $atts );
extract( $atts );
wp_enqueue_script('dpr-cf7', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/dpr.cf7.js', array('jquery'), null, true);	

$unique_id = uniqid('dpr-contact-form-').'-'.rand(1,9999);

/* CSS Classes and styles */
if ( '' !== $css_animation && 'none' !== $css_animation ) {
	dpr_enqueue_waypoint_js();
	dpr_enqueue_animate_css();
	$el_class .= ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
}
/* Output */
$css_classes = array(
	'dpr-contact-form',
	$unique_id,
	$el_class,
	vc_shortcode_custom_css_class( $css ),
);

if(isset($style) && $style != '' ) {
	$css_classes[] = 'style-'.$style;
}

$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->settings['base'], $atts ) );


// Custom CSS stuff
$input_typo_css = dpr_generate_typography_css('', $input_font_size, $input_line_height, $input_letter_spacing, $input_font_style,$input_google_font);

$button_typo_css = dpr_generate_typography_css('', $button_font_size, $button_line_height, $button_letter_spacing, $button_font_style, $button_google_font);

if(isset($text_color) && $text_color != '' ) {
		$custom_el_css .= ".".esc_js($unique_id)." form input:not([type='submit']), .".esc_js($unique_id)." form textarea, .".esc_js($unique_id)." form select {color:".$text_color.";".$input_typo_css."}";
}
if(isset($input_typo_css) && $input_typo_css != '' ) {
		$custom_el_css .= ".".esc_js($unique_id)." form input:not([type='submit']), .".esc_js($unique_id)." form textarea, .".esc_js($unique_id)." form select {".$input_typo_css."}";
}

if(isset($placeholder_color) && $placeholder_color != '') {
		$custom_el_css .= ".".esc_js($unique_id)." form input::placeholder, .".esc_js($unique_id)." form textarea::placeholder, .".esc_js($unique_id)." form select::placeholder {color:".$placeholder_color.";}";
}
if(isset( $border_color) &&  $border_color != '') {
		$custom_el_css .= ".".esc_js($unique_id)." form input:not([type='submit']), .".esc_js($unique_id)." form textarea, .".esc_js($unique_id)." form select {border-color:". $border_color.";}";
}
if(isset( $border_color_focus) &&  $border_color_focus != '') {
		$custom_el_css .= ".".esc_js($unique_id)." form input:not([type='submit']):focus, .".esc_js($unique_id)." form textarea:focus, .".esc_js($unique_id)." form select:focus {border-color:". $border_color_focus.";}";
}
if(isset( $bg_color) &&  $bg_color != '') {
		$custom_el_css .= ".".esc_js($unique_id)." form input:not([type='submit']), .".esc_js($unique_id)." form textarea, .".esc_js($unique_id)." form select {background-color:". $bg_color.";}";
}
if(isset( $bg_color_focus) &&  $bg_color_focus != '') {
		$custom_el_css .= ".".esc_js($unique_id)." form input:not([type='submit']):focus, .".esc_js($unique_id)." form textarea:focus, .".esc_js($unique_id)." form select:focus {background-color:". $bg_color_focus.";}";
}
if(isset( $bg_color) &&  $bg_color != '') {
		$custom_el_css .= ".".esc_js($unique_id)." form input:not([type='submit']), .".esc_js($unique_id)." form textarea, .".esc_js($unique_id)." form select {background-color:". $bg_color.";}";
}
if ($button_color != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .replacement-btn {color:'.$button_color.' !important}' ;
}
if ($button_typo_css != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .replacement-btn {'.$button_typo_css.'}' ;
}
if ($button_bg_color != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .replacement-btn {background-color:'.$button_bg_color.' !important}' ;
}
if ($button_border_color != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .replacement-btn {border-color:'.$button_border_color.' !important}' ;
}
if ($button_color_hover != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .replacement-btn:hover {color:'.$button_color_hover.' !important}' ;
}
if ($button_bg_color_hover != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .replacement-btn:hover {background-color:'.$button_bg_color_hover.' !important}' ;
}
if ($button_border_color_hover != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .replacement-btn:hover {border-color:'.$button_border_color_hover.' !important}' ;
}
if ($button_border_radius != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .replacement-btn {border-radius:'.$button_border_radius.'px !important}' ;
}
if ($button_border_width != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .replacement-btn {border-width:'.$button_border_width.'px !important}' ;
}



/* HTML Parts */

$btn_class = 'btn '.$button_style.' '.$button_size.' '.$button_shape;
if( $full_width == 'yes') {
$btn_class .= ' btn-block';
}


	$button_html .= '<div class="hidden" data-replacement-btn="true">';
	$button_html .= '<div class="'.$button_alignment.'">';
	$button_html .= '<button class="replacement-btn '.$btn_class.'"><span class="loader"></span><span class="text"></span></button>';
	$button_html .= '</div>';
	$button_html .= '</div>';

?>

<div id="<?php echo esc_attr($unique_id) ?>" class="<?php echo esc_attr($css_class) ?>">
	<?php if(isset($id) && $id !='' ) {
        echo do_shortcode( '[contact-form-7 id="' . esc_attr( $id ) . '" title=""]' ); 
		echo $button_html;
    } else {
        echo '<p>'.esc_html__('No contact form selected', 'dpr-adeline-extensions').'<p>';
    }?>


<?php
	if(!empty($custom_el_css)) {
		$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>");'
						. '})(jQuery);'
					. '</script>';
}



echo $output;
?>
</div>
