<?php



/**



 * Blog Options



 * 



 */







    Redux::setSection( $opt_name, array(



        'title'  => __( 'Sidebar', 'dpr-adeline-extensions' ),



        'id'     => 'sidebar_tab',



        'icon'   => 'el el-photo rotate90ccw',



				'fields' => array(



						array(



							'id' => 'sidebar_bg_color',



							'type' => 'color',



							'output' => array('background-color' => '.widget-area'),



							'validate' => 'color',



							'title' => esc_html__('Background Color', 'dpr-adeline-extensions'),



							'default' => '#ffffff',



							'hint' => array(



								'title'   => esc_attr__('Background Color','dpr-adeline-extensions'),



								'content' => esc_attr__('Set background color for sidebar.','dpr-adeline-extensions')



							)



						),



						array(



							'id'   => 'sidebar_padding',



							'type' => 'spacing',



							'output'  => array('.widget-area'),



							'mode' => 'padding',



							'units' => array('px'),



							'display_units' => true,



							'units_extended' => false,



							'title' => __('Sidebar Padding (px)', 'dpr-adeline-extensions'),



							'default' => array(



							'padding-left' => '0px',



							'padding-right' => '0px',



							'padding-bottom' => '0px',



							'padding-top' => '0px', 



							'units' => 'px', 



							),



							'hint' => array (



								'title' => esc_attr__('Sidebar Padding', 'dpr-adeline-extensions'),



								'content' => esc_attr__('Choose default padding for sidebar.', 'dpr-adeline-extensions')



							)



						),



						array(



							'id'   => 'widgets_info',



							'type' => 'info',



							'style' => 'dpr-title',



							'required' => array('menu_cart_style','equals','drop_down'),



							'title' => wp_kses_post(__('<h3>Widgets</h3>', 'dpr-adeline-extensions')),



						),



						array(



							'id' => 'widgets_bg_color',



							'type' => 'color',



							'output' => array('background-color' => '.widget-area .sidebar-box'),



							'validate' => 'color',



							'title' => esc_html__('Background Color', 'dpr-adeline-extensions'),



							'default' => '#ffffff',



							'hint' => array(



								'title'   => esc_attr__('Background Color','dpr-adeline-extensions'),



								'content' => esc_attr__('Set background color for sidebar widgets.','dpr-adeline-extensions')



							)



						),



						array(



							'id'   => 'widgets_padding',



							'type' => 'spacing',



							'output'  => array('.widget-area .sidebar-box'),



							'mode' => 'padding',



							'units' => array('px'),



							'display_units' => true,



							'units_extended' => false,



							'title' => __('Widgets Padding (px)', 'dpr-adeline-extensions'),



							'default' => array(



							'padding-left' => '0px',



							'padding-right' => '0px',



							'padding-bottom' => '0px',



							'padding-top' => '0px', 



							'units' => 'px', 



							),



							'hint' => array (



								'title' => esc_attr__('Widgets Padding', 'dpr-adeline-extensions'),



								'content' => esc_attr__('Choose default padding for sidebar widgets.', 'dpr-adeline-extensions')



							)



						),



						array(



							'id'   => 'widgets_bottom_margin',



							'type' => 'spacing',



							'output'  => array('.widget-area .sidebar-box'),



							'mode' => 'margin',



							'units' => array('px'),



							'display_units' => true,



							'units_extended' => false,



							'top' => false,



							'left' => false,



							'right' => false,



							'title' => __('Widgets Bottom Margin (px)', 'dpr-adeline-extensions'),



							'default' => array(



							'margin-bottom' => '40px',



							'units' => 'px', 



							),



							'hint' => array (



								'title' => esc_attr__('Widgets Bottom Margin', 'dpr-adeline-extensions'),



								'content' => esc_attr__('Choose default bottom margin for sidebar widgets.', 'dpr-adeline-extensions')



							)



						),



						array(



							'id'       => 'widgets_title_decoration_style',



							'type'     => 'radio',



							'title'    => __('Widgets Title Decoration Style', 'dpr-adeline-extensions'),



							'options'  => array(



								'none'  => 'None',



								'bordered' => 'Left Border', 



								'underlined' => 'Underline'



							),



							'default' => 'none',



							'hint' => array(



								'title'   => esc_attr__('Widgets Title Decoration Style','dpr-adeline-extensions'),



								'content' => esc_attr__('Set widgets title decoration style. ','dpr-adeline-extensions')



							),



						),



						array(



							'id' => 'widgets_title_border_color',



							'type' => 'color',



							'validate' => 'color',



							'title' => esc_html__('Border Color', 'dpr-adeline-extensions'),



							'default' => '#D3AE5F',



							'hint' => array(



								'title'   => esc_attr__('Border Color','dpr-adeline-extensions'),



								'content' => esc_attr__('Set border color for sidebar widgets title.','dpr-adeline-extensions')



							),



							'required' => array('widgets_title_decoration_style','equals','bordered')



						),



						array(



						'id' => 'widgets_title_border_width',



						'type' => 'dimensions',



						'title' => esc_html__('Border Width (px)', 'dpr-adeline-extensions'),



						'width' => true,



						'height' => false,



						'mode' => array ('width' => 'width', 'height' => 'height'),



						'units' => array('px'),



						'default'  => array(



							'width' => '3px'



						),



						'hint' => array(



							'title'   => esc_attr__('Border Width','dpr-adeline-extensions'),



							'content' => esc_attr__('Set border width for sidebar widgets title.','dpr-adeline-extensions')



						),



						'required' => array('widgets_title_decoration_style','equals','bordered')



						),



						array(



							'id' => 'widgets_title_underline_color',



							'type' => 'color',



							'validate' => 'color',



							'title' => esc_html__('Underline Color', 'dpr-adeline-extensions'),



							'default' => '#D3AE5F',



							'hint' => array(



								'title'   => esc_attr__('Underline Color','dpr-adeline-extensions'),



								'content' => esc_attr__('Set underline color for sidebar widgets title.','dpr-adeline-extensions')



							),



							'required' => array('widgets_title_decoration_style','equals','underlined')



						),



						array(



							'id' => 'widgets_title_background_underline_color',



							'type' => 'color',



							'validate' => 'color',



							'title' => esc_html__('Background Underline Color', 'dpr-adeline-extensions'),



							'default' => '#e5e5e9',



							'hint' => array(



								'title'   => esc_attr__('Background Underline Color','dpr-adeline-extensions'),



								'content' => esc_attr__('Set background underline color for sidebar widgets title.','dpr-adeline-extensions')



							),



							'required' => array('widgets_title_decoration_style','equals','underlined')



						),



						array(



						'id' => 'widgets_title_underline_thikness',



						'type' => 'dimensions',



						'title' => esc_html__('Underline Thickness (px)', 'dpr-adeline-extensions'),



						'width' => false,



						'height' => true,



						'mode' => array ('width' => 'width', 'height' => 'height'),



						'units' => array('px'),



						'default'  => array(



							'height' => '1px'



						),



						'hint' => array(



							'title'   => esc_attr__('Underline Thickness','dpr-adeline-extensions'),



							'content' => esc_attr__('Set underline thickness for sidebar widgets title.','dpr-adeline-extensions')



						),



						'required' => array('widgets_title_decoration_style','equals','underlined')



						),



						array(



							'id'   => 'widgets_titles_bottom_margin',



							'type' => 'spacing',



							'output'  => array('.widget-title'),



							'mode' => 'margin',



							'units' => array('px'),



							'display_units' => true,



							'units_extended' => false,



							'top' => false,



							'left' => false,



							'right' => false,



							'title' => __('Widgets Title Bottom Margin (px)', 'dpr-adeline-extensions'),



							'default' => array(



							'margin-bottom' => '15px',



							'units' => 'px', 



							),



							'hint' => array (



								'title' => esc_attr__('Widgets Title Bottom Margin', 'dpr-adeline-extensions'),



								'content' => esc_attr__('Choose default bottom margin for sidebar widgets titles.', 'dpr-adeline-extensions')



							)



						),



	    )



	) );



