<?php

/**



 * General Options -> Right Click Blocker



 *



 */

Redux::setSection($opt_name, array(

    'title'      => esc_html__('Right Click Blocker', 'dpr-adeline-extensions'),

    'id'         => 'general_right_click_blocker',

    'subsection' => true,

    'fields'     => array(

        array(

            'id'      => 'right_click_blocker',

            'type'    => 'switch',

            'title'   => esc_html__('Right Click Blocker', 'dpr-adeline-extensions'),

            'default' => false,

            'hint'    => array(

                'title'   => esc_attr__('Right Click Blocker', 'dpr-adeline-extensions'),

                'content' => esc_attr__('You can enable or disable blocking of right click.', 'dpr-adeline-extensions'),

            ),

        ),
        array(

            'id'           => 'rightclick_blocker_text',

            'type'         => 'textarea',

            'title'        => __('Right Click Blocker Message', 'dpr-adeline-extensions'),

            'validate'     => 'html_custom',

            'default'      => 'You can enable/disable right clicking from Theme Options and customize this message too.',

            'hint'         => array(

                'title'   => esc_attr__('Right Click Blocker Message', 'dpr-adeline-extensions'),

                'content' => esc_attr__('You can set right click blocker message. Custom HTML is allowed', 'dpr-adeline-extensions'),

            ),

            'required' => array('right_click_blocker', 'equals', '1'),

        ),

        array(

            'id'       => 'right_click_bg',

            'type'     => 'background',

            'title'    => __('Right Click Blocker Background', 'dpr-adeline-extensions'),

            'default'  => array(

                'background-color' => 'rgba(17, 25, 34, 0.8)',

            ),

            'output'   => array('#rc-blocker'),

            'hint'     => array(

                'title'   => esc_attr__('Right Click Blocker Background', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set background for right click blocking message', 'dpr-adeline-extensions'),

            ),

            'required' => array('right_click_blocker', 'equals', '1'),

        ),

         array(

            'id'       => 'right_click_color',

            'type'     => 'color',

            'title'    => __('Right Click Blocker Message Color', 'dpr-adeline-extensions'),

            'output'   => array('.rc-blocker-text'),

            'default'  => '#ffffff',

            'hint'     => array(

                'title'   => esc_attr__('Right Click Blocker Message Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set color for right click blocker message', 'dpr-adeline-extensions'),

            ),

            'required' => array('right_click_blocker', 'equals', '1'),

        ),


    ),

));
