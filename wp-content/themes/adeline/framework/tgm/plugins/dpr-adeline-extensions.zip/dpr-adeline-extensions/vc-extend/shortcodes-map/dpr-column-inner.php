<?php

// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}



//VC Column VC Map modifications



if(function_exists('vc_remove_param')) {

	

	vc_remove_param('vc_column_inner','el_id');

	vc_remove_param('vc_column_inner','el_class');

}



	vc_add_param(

		'vc_column_inner', array(

			'type' => 'dpr_radio',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Choose the background style for the column. The text colors will be changed according to the style you choose to make it more readable.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background style', 'dpr-adeline-extensions'),

			'param_name' => 'bg_style',

			'value' => '',

			'weight' => 1,

			'options' => array(

				__('Light', 'dpr-adeline-extensions') => '',

				__('Dark', 'dpr-adeline-extensions') => 'dark',

			)

		)

	);

	vc_add_param(

		'vc_column_inner', array(

		'type' => 'animation_style',

		'heading' => __( 'CSS Animation', 'dpr-adeline-extensions' ),

		'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select type of animation for element to be animated when it "enters" the browsers viewport (Note: works only in modern browsers).', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('CSS Animation', 'dpr-adeline-extensions'),

		'param_name' => 'css_animation',

		'value' => '',

		'weight' => 1,

		'settings' => array(

			'type' => 'in',

			'custom' => array(

				array(

					'label' => __( 'Default', 'dpr-adeline-extensions' ),

					'values' => array(

						__( 'Top to bottom', 'dpr-adeline-extensions' ) => 'top-to-bottom',

						__( 'Bottom to top', 'dpr-adeline-extensions' ) => 'bottom-to-top',

						__( 'Left to right', 'dpr-adeline-extensions' ) => 'left-to-right',

						__( 'Right to left', 'jdpr-adeline-extensions' ) => 'right-to-left',

						__( 'Appear from center', 'dpr-adeline-extensions' ) => 'appear',

					),

				),

			),

		)

	)

	);

	vc_add_param(

		'vc_column_inner',array(

			'type' => 'textfield',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enter optional column ID. Make sure it is unique, and it is valid as w3c specification: %s (Must not have spaces).', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Element ID', 'dpr-adeline-extensions'),

			'param_name' => 'el_id',

			'weight' => 1

		)

	);

	vc_add_param(

		'vc_column_inner',array(

			'type' => 'textfield',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Extra Class Name', 'dpr-adeline-extensions'),

			'param_name' => 'el_class',

			'weight' => 1

		)

	);

	vc_add_param(

		'vc_column_inner', array(

			'type' => 'dpr_title',

			'text' => esc_html__('Default State', 'dpr-adeline-extensions'),

			'param_name' => 'default_design_setting_title',

			'group' => esc_html__('Design Options', 'dpr-adeline-extensions'),

			'class' => '',

			'weight' => 1

		)

	);

	vc_add_param(

		'vc_column_inner',array(

			"type" => "dpr_shadow_picker",

			"class" => "",

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set shadow for this column.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Column Shadow', 'dpr-adeline-extensions'),

			'group' => esc_html__('Design Options', 'dpr-adeline-extensions'),

			"param_name" => "column_shadow",

			"value" => "none||||||"

		)

	);

	vc_add_param(

		'vc_column_inner', array(

			'type' => 'dpr_title',

			'text' => esc_html__('Hover State', 'dpr-adeline-extensions'),

			'param_name' => 'hover_design_setting_title',

			'group' => esc_html__('Design Options', 'dpr-adeline-extensions'),

			'class' => '',

		)

	);

	vc_add_param(

		'vc_column_inner', array(

			'type' => 'colorpicker',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the color for column hover background.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background Color Hover', 'dpr-adeline-extensions'),

			'param_name' => 'column_bg_color_hover',

			'edit_field_class' => 'vc_column vc_col-sm-6',

			'value' => '',

			'group' => esc_html__('Design Options', 'dpr-adeline-extensions'),

		)

	);

	vc_add_param(

		'vc_column_inner', array(

			'type' => 'colorpicker',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the color for column hover border.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border Color Hover', 'dpr-adeline-extensions'),

			'param_name' => 'column_border_color_hover',

			'edit_field_class' => 'vc_column vc_col-sm-6',

			'value' => '',

			'group' => esc_html__('Design Options', 'dpr-adeline-extensions'),

		)

	);

	vc_add_param(

	'vc_column_inner',array(

		'type' => 'dropdown',

		'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select gap between columns in row.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border Style Hover', 'dpr-adeline-extensions'),

		'param_name' => 'column_border_style_hover',

		'group' => esc_html__('Design Options', 'dpr-adeline-extensions'),

		'edit_field_class' => 'vc_column vc_col-sm-6',

		'value' => array(

				__('Inherit', 'dpr-adeline-extensions') => '',

				__('None', 'dpr-adeline-extensions') => 'none',

				__('Solid', 'dpr-adeline-extensions') => 'solid',

				__('Doted', 'dpr-adeline-extensions') => 'dotted',

				__('Dashed', 'dpr-adeline-extensions') => 'dashed',

			    __('Hidden', 'dpr-adeline-extensions') => 'double',

				__('Groove', 'dpr-adeline-extensions') => 'groove',

				__('Ridge', 'dpr-adeline-extensions') => 'ridge',

				__('Inset', 'dpr-adeline-extensions') => 'inset',

				__('Outset', 'dpr-adeline-extensions') => 'outset',

			   ),

		'std' => '',

	)

	);

	vc_add_param(

		'vc_column_inner',array(

			'type' => 'number',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose border radius in hover state for this column.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border radius hover', 'dpr-adeline-extensions'),

			'param_name' => 'column_border_radius_hover',

			'value' =>'',

			'min'=>'0',

			'step' => '1',

			'group' => esc_html__('Design Options', 'dpr-adeline-extensions'),

			'edit_field_class' => 'vc_column vc_col-sm-6',

		)

	);

	vc_add_param(

		'vc_column_inner',array(

			"type" => "dpr_shadow_picker",

			"class" => "",

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set shadow for this column.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Column Shadow Hover', 'dpr-adeline-extensions'),

			'group' => esc_html__('Design Options', 'dpr-adeline-extensions'),

			"param_name" => "column_shadow_hover",

			"value" => "none||||||"

		)

	);

	vc_add_param(

		'vc_column_inner', array(

			'type' => 'dpr_switcher',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('This option allows you to add custom paddings, margins and border for different devices.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Responsive Custom CSS', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_enable_responsive_options',

			'edit_field_class' => 'vc_column vc_col-sm-6',

			'group' => esc_html__('Responsive Options', 'dpr-adeline-extensions'),			

			'value' => '',

			'options' => array(

				'yes' => array(

						'label' => '',

						'on' => 'Yes',

						'off' => 'No',

					),

				),

		)

	);

	vc_add_param(

		'vc_column_inner', array(

			'type'				=> 'dpr_responsive_css',

			'heading'			=> esc_html__('Resposive settings', 'dpr-adeline-extensions'),

			'param_name'		=> 'responsive_css_panel',

			'group'				=> esc_html__('Responsive Options', 'dpr-adeline-extensions'),

			'dependency' => array(

					'element' => 'dpr_enable_responsive_options', 

					'value' => array('yes')

			),

		)

	);

