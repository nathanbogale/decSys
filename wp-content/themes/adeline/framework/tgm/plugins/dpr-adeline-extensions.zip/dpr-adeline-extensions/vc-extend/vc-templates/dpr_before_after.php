<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$unique_id = $css_animation = $el_class = $output = $custom_el_css =  '';
$offset = $before_label = $after_label = $first_image = $second_image = $image_width = $image_height = $use_shadow = $shadow = $divider_width = $divider_color = $handler_bg = $handler_color = $label_color = $label_bg = '';
$first_image_html = $second_image_html = $data_atts = '';
$direction = (isset($direction) && $direction != '') ? $direction : 'horizontal';

$atts = vc_map_get_attributes( 'dpr_before_after', $atts );
extract( $atts );

$el_class = $this->getExtraClass( $el_class );

wp_enqueue_style('dpr-before-after-css', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/css/before_after.css');
wp_enqueue_script('dpr-before-after', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/dpr.before.after.js', array('jquery'), null, true);	

if ( '' !== $css_animation && 'none' !== $css_animation ) {
	dpr_enqueue_waypoint_js();
	dpr_enqueue_animate_css();
	$el_class .= ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
}
$unique_id = uniqid('dpr-before-after-').'-'.rand(1,9999);

/* Element classes */

$css_classes = array(
	'dpr-before-after',
	$unique_id,
	$el_class,
);

$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->settings['base'], $atts ) );

/* Data attributes*/
if(isset($direction) && $direction != '') {
	$data_atts .= ' data-orientation="' . esc_attr($direction) . '" ';
}
if(isset($offset) && $offset != '') {
$offset = $offset/100;
$data_atts .= ' data-offset="'.esc_attr($offset).'"';
}
if(isset($before_label) && $before_label != '') {
$data_atts .= ' data-label-before="'.esc_attr($before_label).'"';
}
if(isset($after_label) && $after_label != '') {
$data_atts .= ' data-label-after="'.esc_attr($after_label).'"';
}



/* * ************************
 * Styles and custom CSS
 * *********************** */
if (isset($divider_color) && $divider_color != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .twentytwenty-horizontal .twentytwenty-handle:before, .'.esc_js($unique_id).' .twentytwenty-horizontal .twentytwenty-handle:after, .'.esc_js($unique_id).' .twentytwenty-vertical .twentytwenty-handle:before, .'.esc_js($unique_id).' .twentytwenty-vertical .twentytwenty-handle:after {background-color:'.esc_attr($divider_color).';}';
}
if (isset($divider_width) && $divider_width != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .twentytwenty-horizontal .twentytwenty-handle:before, .'.esc_js($unique_id).' .twentytwenty-horizontal .twentytwenty-handle:after {width: '.$divider_width.'px; margin-left: -'.($divider_width/2).'px; }';
	$custom_el_css .= '.'.esc_js($unique_id).' .twentytwenty-vertical .twentytwenty-handle:before, .'.esc_js($unique_id).' .twentytwenty-vertical .twentytwenty-handle:after {height: '.$divider_width.'px; margin-top: -'.($divider_width/2).'px; }';
}
if (isset($handler_bg) && $handler_bg != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .twentytwenty-handle{background-color:'.$handler_bg.';border-color:'.$handler_bg.';}';
}
if (isset($handler_color) && $handler_color != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .twentytwenty-left-arrow{border-right-color:'.$handler_color.';}';
	$custom_el_css .= '.'.esc_js($unique_id).' .twentytwenty-right-arrow{border-left-color:'.$handler_color.';}';
	$custom_el_css .= '.'.esc_js($unique_id).' .twentytwenty-up-arrow{border-bottom-color:'.$handler_color.';}';
	$custom_el_css .= '.'.esc_js($unique_id).' .twentytwenty-down-arrow{border-top-color:'.$handler_color.';}';
}
if (isset($label_color) && $label_color != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .twentytwenty-before-label:before, .'.esc_js($unique_id).' .twentytwenty-after-label:before{color:'.$label_color.';}';
}
if (isset($label_bg) && $label_bg != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .twentytwenty-before-label:before, .'.esc_js($unique_id).' .twentytwenty-after-label:before{background-color:'.$label_bg.';}';
}
if(dpr_shadow_param_to_css($shadow) != '') {
	$custom_el_css .= '.'.esc_js($unique_id) .' {'.dpr_shadow_param_to_css($shadow).'}';
}


/* * ************************
 * Partial HTML.
 * *********************** */

/* Images */
if (isset($first_image) && !empty($first_image)) {
	$image = dpr_get_attachment_image_src($first_image, 'full');
	if(!empty($image_width) && !empty($image_height)) {
		$image_src = adeline_resize( $image[0], $image_width, $image_height, true, true, true );
	}
	if(!$image_src) $image_src = $image[0];
	if ($image_src == '') {
		$image_src = adeline_no_image_url();
	}
	$alt_text = get_post_meta($first_image , '_wp_attachment_image_alt', true);

	$first_image_html .= '<img src="'.esc_url($image_src ).'" alt ="'.esc_attr($alt_text).'"/>';
}

if (isset($second_image) && !empty($second_image)) {
	$image = dpr_get_attachment_image_src($second_image, 'full');
	if(!empty($image_width) && !empty($image_height)) {
		$image_src = adeline_resize( $image[0], $image_width, $image_height, true, true, true );
	}
	if(!$image_src) $image_src = $image[0];
	if ($image_src == '') {
		$image_src = adeline_no_image_url();
	}
		$alt_text = get_post_meta($second_image , '_wp_attachment_image_alt', true);

	$second_image_html .= '<img src="'.esc_url($image_src ).'" alt ="'.esc_attr($alt_text).'"/>';
} 


/* * ************************
 * Output
 * *********************** */
$output .= '<div id="'.esc_attr($unique_id).'" class="'.esc_attr($css_class).'">';
if ($first_image_html == '' || $second_image_html == '') {
		$output .= '<h3 class="text-center">' . esc_html__('OOPS!!', 'dpr-adeline-extensions') . '</h3>';
		$output .= '<h6 class="text-center">' . esc_html__('The images are required for this Before After VC element.', 'dpr-adeline-extensions') . '</h6>';
		$output .= '<h6 class="text-center">' . esc_html__('Please upload or select images from media library in element settings', 'dpr-adeline-extensions') . '</h6>';
} else {
		$output .= '<div class="dpr-before-after-images" ' . $data_atts . '>';
		$output .= $first_image_html . $second_image_html;
		$output .= '</div>';
}


if(!empty($custom_el_css)) {
		$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>");'
						. '})(jQuery);'
					. '</script>';
}
$output .= '</div>';

echo $output;