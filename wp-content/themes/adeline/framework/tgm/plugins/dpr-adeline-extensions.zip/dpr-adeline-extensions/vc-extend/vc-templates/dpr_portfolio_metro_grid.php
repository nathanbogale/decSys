<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$output = $custom_el_css = $el_class  = $items_to_display = $item_list = '';
$columns = $columns_tablet = $columns_mobile = $items_padding = $items_bg_color = $items_border_width = $items_border_radius = '';
$display_title = $display_category = $title_color = $title_color_hover = $category_link_color = $category_link_color_hover = '';
$entry_hover_animation = $entry_appear_animation = $appear_animation_duration = $appear_animation_easing = $appear_animation_delay = '';
$entry_img_size = $entry_img_width = $entry_img_height = $entry_overlay_type = $overlay_color = $overlay_spacing = $overlay_gradient = '';
$overlay_icons_style = $overlay_icons_size = $overlay_icons_font_size = $link_icon_type = $link_icon = $zoom_icon_type = $zoom_icon = $overlay_icons_color = $overlay_icons_bg = $overlay_icons_border = '';$overlay_icons_color_hover = $overlay_icons_bg_hover = $overlay_icons_border_hover = $plus_link = $plus_size = $plus_color = $plus_color_hover = '';
$overlay_title_color = $overlay_title_color_hover = $overlay_category_color = $overlay_category_color_hover = '';
$enable_filter = $enable_all = $all_text = $filter_position = $filter_taxonomy = $filter_bar_margin = $filter_buttons_spacing = $filter_buttons_vertical_padding = $filter_buttons_horizontal_padding = '';$filter_buttons_border_radius = $filter_buttons_bg_color = $filter_buttons_bg_color_hover = $filter_buttons_color = $filter_buttons_color_hover = $filter_border_color = $filter_border_color_hover = '';
$title_font_size = $title_line_height = $title_letter_spacing = $title_font_style = $title_use_google_fonts = $title_google_font = '';
$category_font_size = $category_line_height = $category_letter_spacing = $category_font_style = $category_use_google_fonts = $category_google_font = '';
$filter_font_size = $filter_line_height = $filter_letter_spacing = $filter_font_style = $filter_use_google_fonts = $filter_google_font = '';

$atts = vc_map_get_attributes(  $this->getShortcode(), $atts  );
extract( $atts );

$el_class = $this->getExtraClass( $el_class );
if ( '' !== $css_animation && 'none' !== $css_animation ) {
	dpr_enqueue_waypoint_js();
	dpr_enqueue_animate_css();
	$el_class .= ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
}

if (isset($entry_hover_animation) && ($entry_hover_animation == 'dpr-image-tilt' || $entry_hover_animation == 'dpr-item-tilt')) {
    wp_enqueue_script('jquery-tilt', DPR_EXTENSIONS_PLUGIN_URL . 'vc-extend/assets/frontend/js/universal-tilt.min.js', array('jquery'), null, true);
    wp_enqueue_script('dpr-portfolio-scat-grid-hover-animations', DPR_EXTENSIONS_PLUGIN_URL . 'vc-extend/assets/frontend/js/dpr.scat.grid.anim.js', array('jquery'), null, true);
}

$unique_id = uniqid('dpr-portfolio-metro-grid-').'-'.rand(1,9999);

// Enqueue AOS JS if appear animation selected

if( 'none' != $entry_appear_animation ) {
	wp_enqueue_script( 'aos' );
}


/* Element classes */
$wrap_classes 	   	= array( 'portfolio-items', 'clr', 'tablet-col', 'mobile-col' );
$wrap_classes[] 	= 'col-'.$columns;
$wrap_classes[] 	= 'tablet-' . $columns_tablet . '-col';
$wrap_classes[] 	= 'mobile-' . $columns_mobile . '-col';
$wrap_classes[] = 'packery-grid';
$wrap_classes[] = 'isotope-grid';

$wrap_classes 		= implode( ' ', $wrap_classes );


$css_classes = array(
	'dpr-portfolio-metro-grid',
	$unique_id,
	$wrap_classes,
	$el_class,
);

$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->settings['base'], $atts ) );

/* * *************************************
 * Custom CSS classes and attributes
 * ***************************************
*/
$link_icon_class = 'dpr-icon-size-fullscreen';
if ($link_icon_type == 'custom') {
		switch ( $link_icon_lib ) {
					case 'fontawesome':
					if (isset($link_icon_fontawesome) && $link_icon_fontawesome != '') {
					$link_icon_class = $link_icon_fontawesome;
					}
					break;
					case 'openiconic':
					if (isset($link_icon_openiconic) && $link_icon_openiconic != '') {
					$link_icon_class = $link_icon_openiconic;
					}
					break;
					case 'typicons':
					if (isset($link_icon_typicons) && $link_icon_typicons != '') {
					$link_icon_class = $link_icon_typicons;
					}
					break;
					case 'entypo':
					if (isset($link_icon_entypo) && $link_icon_entypo != '') {
					$link_icon_class = $link_icon_entypo;
					}
					break;
					case 'linecons':
					if (isset($link_icon_linecons) && $link_icon_linecons != '') {
					$link_icon_class = $link_icon_linecons;
					}

		}
		vc_icon_element_fonts_enqueue( $link_icon_lib );
}
$zoom_icon_class = 'dpr-icon-magnifier';
if ($zoom_icon_type == 'custom') {
		switch ( $zoom_icon_lib ) {
					case 'fontawesome':
					if (isset($zoom_icon_fontawesome) && $zoom_icon_fontawesome != '') {
					$zoom_icon_class = $zoom_icon_fontawesome;
					}
					break;
					case 'openiconic':
					if (isset($zoom_icon_openiconic) && $zoom_icon_openiconic != '') {
					$zoom_icon_class = $zoom_icon_openiconic;
					}
					break;
					case 'typicons':
					if (isset($zoom_icon_typicons) && $zoom_icon_typicons != '') {
					$zoom_icon_class = $zoom_icon_typicons;
					}
					break;
					case 'entypo':
					if (isset($zoom_icon_entypo) && $zoom_icon_entypo != '') {
					$zoom_icon_class = $zoom_icon_entypo;
					}
					break;
					case 'linecons':
					if (isset($zoom_icon_linecons) && $zoom_icon_linecons != '') {
					$zoom_icon_class = $zoom_icon_linecons;
					}

		}
		vc_icon_element_fonts_enqueue( $zoom_icon_lib );
}

$item_classes 	= array('portfolio-item-inner','clr');


$item_classes 		= implode( ' ', $item_classes );

$overlay_classes 	= array('overlay');
$overlay_classes[] = $entry_overlay_type;
$overlay_classes 		= implode( ' ', $overlay_classes );

$aos_data = '';

if ($entry_appear_animation != 'none')  {
	$aos_data .= ' data-aos-once ="true" data-aos="'.$entry_appear_animation.'"';
	if( !empty( $appear_animation_easing ) ) {
		$aos_data .= ' data-aos-easing="'.$appear_animation_easing.'"';
	}
	if( !empty( $appear_animation_duration ) ) {
		$aos_data .= ' data-aos-duration="'. $appear_animation_duration .'"';
	}
	if( !empty( $appear_animation_delay ) ) {
		$aos_data .= ' data-aos-delay="'.$appear_animation_delay.'"';
	}
}

/* * ************************
 * Styles and custom CSS
 * *********************** 
*/
$title_typo_style = dpr_generate_typography_style('', $title_font_size, $title_line_height, $title_letter_spacing, $title_font_style,$title_google_font);
$category_typo_style = dpr_generate_typography_style('', $category_font_size, $category_line_height, $category_letter_spacing, $category_font_style,$category_google_font);
$filter_typo_style = dpr_generate_typography_style('', $filter_font_size, $filter_line_height, $filter_letter_spacing, $filter_font_style,$filter_google_font);

//Grid 
if(isset($items_padding) && !empty($items_padding)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .portfolio-item .portfolio-item-inner {padding: '.esc_js($items_padding).'px;}';
}
if(isset($items_bg_color) && !empty($items_bg_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .portfolio-item .portfolio-item-inner, .'.esc_js($unique_id).' .portfolio-content {background-color: '.esc_js($items_bg_color).';}';
	$custom_el_css .= '.'.esc_js($unique_id).' .portfolio-item-thumbnail .arrow {border-bottom-color: '.esc_js($items_bg_color).';}';
}
if(isset($items_border_radius) && !empty($items_border_radius)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .portfolio-item .portfolio-item-inner {border-radius: '.esc_js($items_border_radius).'px;}';
}
if(isset($title_color) && !empty($title_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .portfolio-inside-content .portfolio-item-title a {color: '.esc_js($title_color).';}';
}
if(isset($title_color_hover) && !empty($title_color_hover)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .portfolio-inside-content .portfolio-item-title a:hover {color: '.esc_js($title_color_hover).';}';
}
if(isset($category_link_color) && !empty($category_link_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .portfolio-inside-content .categories a, .'.esc_js($unique_id).' .portfolio-inside-content .categories {color: '.esc_js($category_link_color).';}';
}
if(isset($category_link_color_hover) && !empty($category_link_color_hover)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .portfolio-inside-content .categories a:hover, .'.esc_js($unique_id).' .portfolio-inside-content .categories:hover  {color: '.esc_js($category_link_color_hover).';}';
}

//Overlay 
if(isset($overlay_color) && !empty($overlay_color) && $entry_overlay_type == 'solid') {
	$custom_el_css .= '.'.esc_js($unique_id).' .portfolio-item-thumbnail .overlay .inner  {background-color: '.esc_js($overlay_color).';}';
}
if(isset($entry_overlay_type) && $entry_overlay_type == 'gradient') {
	if(isset($overlay_gradient) && !empty($overlay_gradient)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .portfolio-item-thumbnail .overlay .inner {'.esc_js(adeline_gradientToBgCSS ($overlay_gradient)).'}';
	}
}
if(isset($overlay_spacing) && !empty($overlay_spacing)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .portfolio-item-thumbnail .overlay  {padding: '.esc_js($overlay_spacing).'px;}';
}
if(isset($overlay_icons_size) && !empty($overlay_icons_size)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .portfolio-item-thumbnail .portfolio-overlay-icons li a {width: '.esc_js($overlay_icons_size).'px;height: '.esc_js($overlay_icons_size).'px;}';
}
if(isset($overlay_icons_font_size) && !empty($overlay_icons_font_size)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .portfolio-item-thumbnail .portfolio-overlay-icons li a {font-size: '.esc_js($overlay_icons_font_size).'px;}';
}
if(isset($overlay_icons_color) && !empty($overlay_icons_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .portfolio-item-thumbnail .portfolio-overlay-icons li a {color: '.esc_js($overlay_icons_color).';}';
}
if(isset($overlay_icons_bg) && !empty($overlay_icons_bg)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .portfolio-item-thumbnail .portfolio-overlay-icons li a {background-color: '.esc_js($overlay_icons_bg).';}';
}
if(isset($overlay_icons_border) && !empty($overlay_icons_border)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .portfolio-item-thumbnail .portfolio-overlay-icons li a {border-color: '.esc_js($overlay_icons_border).';}';
}

if(isset($overlay_icons_color_hover) && !empty($overlay_icons_color_hover)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .portfolio-item-thumbnail .portfolio-overlay-icons li a:hover {color: '.esc_js($overlay_icons_color_hover).';}';
}
if(isset($overlay_icons_bg_hover) && !empty($overlay_icons_bg_hover)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .portfolio-item-thumbnail .portfolio-overlay-icons li a:hover {background-color: '.esc_js($overlay_icons_bg_hover).';}';
}
if(isset($overlay_icons_border_hover) && !empty($overlay_icons_border_hover)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .portfolio-item-thumbnail .portfolio-overlay-icons li a:hover {border-color: '.esc_js($overlay_icons_border_hover).';}';
}
if(isset($plus_size) && !empty($plus_size)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .portfolio-item-thumbnail .portfolio-plus-sign {width: '.esc_js($plus_size).'px;height: '.esc_js($plus_size).'px;}';
}
if(isset($plus_color) && !empty($plus_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .portfolio-item-thumbnail .portfolio-plus-sign svg .to-fill {fill: '.esc_js($plus_color).';}';
}
if(isset($plus_color) && !empty($plus_color_hover)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .portfolio-item-thumbnail .portfolio-plus-sign:hover svg .to-fill {fill: '.esc_js($plus_color_hover).';}';
}

//Filter
if($enable_filter == 'yes') {
	if(isset($filter_bar_margin) && !empty($filter_bar_margin)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .portfolio-filters {margin-bottom: '.esc_js($filter_bar_margin).'px;}';
	}
	if(isset($filter_buttons_spacing) && !empty($filter_buttons_spacing)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .portfolio-filters li {margin-right: '.esc_js($filter_buttons_spacing).'px;}';
	}
	if(isset($filter_buttons_vertical_padding) && !empty($filter_buttons_vertical_padding)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .portfolio-filters li a {padding-top: '.esc_js($filter_buttons_vertical_padding).'px; padding-bottom: '.esc_js($filter_buttons_vertical_padding).'px;}';
	}
	if(isset($filter_buttons_horizontal_padding) && !empty($filter_buttons_horizontal_padding)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .portfolio-filters li a {padding-left: '.esc_js($filter_buttons_horizontal_padding).'px; padding-right: '.esc_js($filter_buttons_horizontal_padding).'px;}';
	}
	if(isset($filter_buttons_border_radius) && !empty($filter_buttons_border_radius)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .portfolio-filters li a {border-radius: '.esc_js($filter_buttons_border_radius).'px;}';
	}
	if(isset($filter_buttons_bg_color) && !empty($filter_buttons_bg_color)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .portfolio-filters li a {background-color: '.esc_js($filter_buttons_bg_color).';}';
	}
	if(isset( $filter_buttons_bg_color_hover) && !empty( $filter_buttons_bg_color_hover)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .portfolio-filters li a:hover {background-color: '.esc_js( $filter_buttons_bg_color_hover).';}';
	}
	if(isset($filter_buttons_color) && !empty($filter_buttons_color)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .portfolio-filters li a {color: '.esc_js($filter_buttons_color).';}';
	}
	if(isset($filter_buttons_color_hover) && !empty($filter_buttons_color_hover)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .portfolio-filters li a:hover {color: '.esc_js($filter_buttons_color_hover).';}';
	}
	if(isset($filter_border_color) && !empty($filter_border_color)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .portfolio-filters li a {border-color: '.esc_js($filter_border_color).';}';
	}
	if(isset($filter_border_color_hover) && !empty($filter_border_color_hover)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .portfolio-filters li a:hover {border-color: '.esc_js($filter_border_color_hover).';}';
	}
}

/* * ************************
 * Partial HTML.
 * *********************** */

// Filter
$filter_html = '';

if ( $enable_filter =='yes' ) {

	// Get taxonomy
	if ( 'categories' == $filter_taxonomy ) {
		$taxonomy = 'dpr_portfolio_category';
		$tax = 'cat';
	} else if ( 'tags' == $filter_taxonomy ) {
		$taxonomy = 'dpr_portfolio_tag';
		$tax = 'tag';
	}

	// Filter args
	$filter_args = array(
		'taxonomy' 	 => $taxonomy,
		'hide_empty' => 1,
	);

	// Get filter terms
	$filter_terms = get_terms( $filter_args );

	// Class
	$filter_classes 	   	= array( 'portfolio-filters' );

	// Filter position
	if ( 'center' != $filter_position ) {
		$filter_classes[] 	= 'filter-pos-' . $filter_position;
	}
	
	$filter_classes 		= implode( ' ', $filter_classes ); 

	$filter_html .= '<ul class="'.$filter_classes.'">';
	if ( $enable_all == 'yes' ) {
	$filter_html .= '<li class="portfolio-filter active"><a href="#" data-filter="*"  '.$filter_typo_style.'>'. esc_html( $all_text ).'</a></li>';
	}
	foreach ( $filter_terms as $term ) { 
		$filter_html .= '<li class="portfolio-filter"><a href="#" data-filter=".cat-'. $term->term_id.'" '.$filter_typo_style.'>'.$term->name.'</a></li>';
	} 
	$filter_html .= '</ul>';
}


/* * ************************
 * Output
 * *********************** */
if(isset($item_list) && !empty($item_list) && function_exists('vc_param_group_parse_atts')) {
$output .= '<div id="'.esc_attr($unique_id).'" class="'.esc_attr($css_class).'">';
$output .= $filter_html;

// If masonry
$data = 'packery';
$output .='<div class="portfolio-wrap" data-layout="'.esc_attr( $data ).'">';

// Loop
$item_list = (array) vc_param_group_parse_atts($item_list);
foreach ($item_list as $item) {
if(isset($item['portfolio_item']) && $item['portfolio_item'] != '' ) {
	$id = $item['portfolio_item'];
	$port_post = get_post( $id);
	//Custom overlay color 
	$overlay_style = '';
	if (isset($item['custom_overlay_color']) && $item['custom_overlay_color'] != '') {
	$overlay_style = ' style="background-color:'.esc_attr($item['custom_overlay_color']).'"';
	}
	// Inner classes
	$inner_classes 		= array( 'portfolio-item', 'clr', 'col' );
	//$inner_classes[] 	= 'column-'. $columns;
	$inner_classes[] 	= 'item-size-'.$item['item_size'];
	if ( 'none' != $entry_hover_animation ) $inner_classes[] = $entry_hover_animation;

	// If filter
	if ( $enable_filter && ! empty( $filter_terms ) ) {

		$terms_list = wp_get_post_terms( $id, $taxonomy );

		foreach ( $terms_list as $term ) {
			$inner_classes[] = $tax . '-' . $term->term_id;
		}

	}

	$inner_classes 		= implode( ' ', $inner_classes ); 

	$output .='<div  class="'. esc_attr( $inner_classes ).'">';
	$output .= '<div class="'. $item_classes.'" '.$aos_data.'>';
	if ( has_post_thumbnail($id) ) {
	$output .= '<div class="portfolio-item-thumbnail">';
	$output .= '<a href="'. get_permalink($id).'" class="thumbnail-link">';
	$img_id 	= get_post_thumbnail_id( $id, 'full' );
	$alt_text = get_post_meta($id , '_wp_attachment_image_alt', true);
	$image 	= dpr_get_attachment_image_src( $img_id, 'full' );
	$image_width = 640;
	$image_height = 640;
	if( $item['item_size'] == 'wide') {
	$image_width = 1280;
	$image_height = 640;
	}
	if( $item['item_size'] == 'tall') {
	$image_width = 640;
	$image_height = 1280;
	}
	if( $item['item_size'] == 'large') {
	$image_width = 1280;
	$image_height = 1280;
	}
	$image_src = adeline_resize( $image[0], $image_width, $image_height, true, true, true );
	$output .= '<img src="'.$image_src .'" width="'.$image_width.'" height="'.$image_height.'" alt="'. get_the_title($port_post).'"/>';
	$output .= '<div class="'. esc_attr( $overlay_classes ).'"><div class="inner"'.$overlay_style.'></div></div>';
	$output .= '</a>';
	if ( 'none' != $overlay_icons_style ) { 
			$output .= '<div class="portfolio-overlay-content">';
			// Overlay icons
			if ( 'icons' == $overlay_icons_style ) {
				$output .= '<ul class="portfolio-overlay-icons">';
						if('none' != $link_icon_type) {
								$output .= '<li><a href="'. get_permalink($id).'"><i class="'. esc_attr($link_icon_class).'" aria-hidden="true"></i></a></li>';
						}
						if('none' != $zoom_icon_type) {
								$output .= '<li><a href="'. esc_url( wp_get_attachment_url( $img_id ) ).'" data-rel="portfoliogrid:'.esc_attr($unique_id).'" title="'. get_the_title($id).'"><i class="'. esc_attr($zoom_icon_class).'" aria-hidden="true"></i></a></li>';
						}
				$output .= '</ul>';
			}
			if ( 'plus' == $overlay_icons_style ) {
				if ($plus_link == 'lightbox') {
					$output .= '<a href="'.esc_url( wp_get_attachment_url( $img_id ) ).'" data-rel="portfoliogrid:'.esc_attr($unique_id).'" title="'. get_the_title($id).'">';
				} else {
					$output .= '<a href="'. get_permalink($id).'">';
				}
				$output .= '<div class="portfolio-plus-sign">
                                    <svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 123.31 595.281 595.27">
                                    <g><g>
									<circle class="to-fill" cx="297.636" cy="420.947" r="14.173"/>
                                    <path class="to-fill" d="M25.403,435.119H217.35c14.032,0,25.403-6.344,25.403-14.173s-11.371-14.173-25.403-14.173H25.403
                                C11.371,406.772,0,413.116,0,420.946S11.371,435.119,25.403,435.119z"/>
                                <path class="to-fill" d="M311.809,148.713c0-14.032-6.345-25.402-14.173-25.402c-7.829,0-14.173,11.37-14.173,25.402V340.66
                                c0,14.032,6.344,25.403,14.173,25.403c7.829,0,14.173-11.371,14.173-25.403V148.713z"/>
                                <path class="to-fill" d="M595.281,420.946c0-7.829-11.371-14.173-25.404-14.173H377.931c-14.033,0-25.404,6.344-25.404,14.173
                                s11.371,14.173,25.404,14.173h191.945C583.9,435.119,595.281,428.775,595.281,420.946z"/>
                                <path class="to-fill" d="M283.46,693.177c0,14.032,6.344,25.402,14.174,25.402c7.829,0,14.173-11.37,14.173-25.402V501.23
                                c0-14.032-6.344-25.403-14.173-25.403c-7.83,0-14.174,11.371-14.174,25.403V693.177z"/>
                                </g>
                                </g>
                                </svg>
                            </div>';
				$output .= '</a>';
			}
			// If title or category
			if ( $display_title || $display_category ) {
				$portfolio_content_class = '';
				if ( 'none' != $overlay_icons_style ) {
					$portfolio_content_class = ' has-icons';
				}
				$output .= '<div class="portfolio-inside-content clr '. esc_attr($portfolio_content_class).'">';
				// If title
				if ($display_title == 'yes' ) { 
				$output .= '<h3 class="portfolio-item-title entry-title" '.$title_typo_style.'><a href="'. get_permalink($id).'" rel="bookmark">'. get_the_title($id).'</a></h3>';
				}
				// If category
				if ( $display_category == 'yes' ) {
						$cat_str = '';
						$category = get_the_terms( $id, 'dpr_portfolio_category' );
						foreach ( $category as $cat){
						   $cat_str .= $cat->name . ',';
						} 
						$cat_str = substr_replace($cat_str, "", -1);   
						$output .= '<div class="categories" '.$category_typo_style.'>'.$cat_str.'</div>';
				}
				$output .= '</div>';
			}
			$output .= '</div>';
	}
	$output .= '</div>';
	}

	$output .= '</div>';
	$output .='</div>';


// End entry loop
}
}

$output .= '</div>';


} else {
	$output .= '<p class="portfolio-not-found">'.esc_html_e( 'You have no portfolio items', 'dpr-adeline-extensions' ).'</p>';
}

if(!empty($custom_el_css)) {
		$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>");'
						. '})(jQuery);'
					. '</script>';
}
$output .= '</div>';
$output .= '<div class="clr"></div>';

echo $output;