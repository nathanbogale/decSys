<?php

// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}



//VC Row VC Map modifications



if(function_exists('vc_remove_param')) {

	vc_remove_param('vc_row','full_width');

	vc_remove_param('vc_row','full_height');

	vc_remove_param('vc_row','columns_placement');

	vc_remove_param('vc_row','equal_height');

	vc_remove_param('vc_row','content_placement');

	vc_remove_param('vc_row','gap');

	vc_remove_param('vc_row','css_animation');

	vc_remove_param('vc_row','video_bg');

	vc_remove_param('vc_row','video_bg_url');

	vc_remove_param('vc_row','video_bg_parallax');

	vc_remove_param('vc_row','parallax');

	vc_remove_param('vc_row','parallax_image');

	vc_remove_param('vc_row','parallax_speed_video');

	vc_remove_param('vc_row','parallax_speed_bg');

	vc_remove_param('vc_row','el_id');

	vc_remove_param('vc_row','disable_element');

	vc_remove_param('vc_row','el_class');



}



	vc_add_param(

		'vc_row', array(

			'type' => 'dpr_title',

			'text' => esc_html__('Row Sizing', 'dpr-adeline-extensions'),

			'param_name' => 'sizing_title',

			'class' => '',

			'weight' => 1

		)

	);

	vc_add_param(

		'vc_row', array(

			'type' => 'dpr_radio',

			'class' => '',

			'weight' => 1,

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select content width for this row.Boxed width is set in template optioins {be default 1280px) or full width.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Content Width', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_row_content_sizing',

			'value' => 'boxed',

			'options' => array(

				__('Boxed', 'dpr-adeline-extensions') => 'boxed',

				__('Full Width', 'dpr-adeline-extensions') => 'full_width_content',

			),

		)

	);

	vc_add_param(

		'vc_row', array(

			'type' => 'dpr_switcher',

			'class' => '',

			'weight' => 1,

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set the row to full-screen.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Full height row', 'dpr-adeline-extensions'),

			'param_name' => 'full_height',

			'edit_field_class' => 'vc_column vc_col-sm-6',

			'value' => '',

			'options' => array(

				'yes' => array(

						'label' => '',

						'on' => 'Yes',

						'off' => 'No',

					),

				),

		)

	);

	vc_add_param(

		'vc_row', array(

			'type' => 'dpr_radio',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to choose the vertical alingnment for the content.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Columns position', 'dpr-adeline-extensions'),

			'param_name' => 'columns_placement',

			'weight' => 1,

			'value' => 'middle',

			'edit_field_class' => 'vc_column vc_col-sm-6',

			'options' => array(

				__('Middle', 'dpr-adeline-extensions') => 'middle',

				__('Top', 'dpr-adeline-extensions') => 'top',

				__('Bottom', 'dpr-adeline-extensions') => 'bottom',

			),

			'dependency' => array(

				'element' => 'full_height',

				'not_empty' => true,

			),

		)

	);

	vc_add_param(

		'vc_row', array(

			'type' => 'dpr_switcher',

			'class' => '',

			'weight' => 1,

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set columns in row to equal height adjusted to the height of the bigger one .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Equal column height', 'dpr-adeline-extensions'),

			'param_name' => 'equal_height',

			'value' => '',

			'options' => array(

				'yes' => array(

						'label' => '',

						'on' => 'Yes',

						'off' => 'No',

					),

				),

		)

	);

	vc_add_param(

		'vc_row', array(

			'type' => 'dpr_radio',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select content position within columns.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Content position', 'dpr-adeline-extensions'),

			'param_name' => 'content_placement',

			'edit_field_class' => 'vc_column vc_col-sm-6',

			'weight' => 1,

			'value' => '',

			'options' => array(

				__('Default', 'dpr-adeline-extensions') => '',

				__('Top', 'dpr-adeline-extensions') => 'top',

				__('Middle', 'dpr-adeline-extensions') => 'middle',

				__('Bottom', 'dpr-adeline-extensions') => 'bottom',

			)

		)

	);

	vc_add_param(

	'vc_row',array(

		'type' => 'dropdown',

		'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select gap between columns in row.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Columns gap', 'dpr-adeline-extensions'),

		'param_name' => 'gap',

		'edit_field_class' => 'vc_column vc_col-sm-6',

		'weight' => 1,

		'value' => array(

			'0px' => '0',

			'1px' => '1',

			'2px' => '2',

			'3px' => '3',

			'4px' => '4',

			'5px' => '5',

			'10px' => '10',

			'15px' => '15',

			'20px' => '20',

			'25px' => '25',

			'30px' => '30',

			'35px' => '35',

		),

		'std' => '0',

	)

	);

	vc_add_param(

		'vc_row', array(

			'type' => 'dpr_title',

			'text' => esc_html__('Row Effects', 'dpr-adeline-extensions'),

			'param_name' => 'effects_title',

			'class' => '',

			'weight' => 1

		)

	);

	

	vc_add_param(

		'vc_row', array(

		'type' => 'animation_style',

		'heading' => __( 'CSS Animation', 'dpr-adeline-extensions' ),

		'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select type of animation for element to be animated when it "enters" the browsers viewport (Note: works only in modern browsers).', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('CSS Animation', 'dpr-adeline-extensions'),

		'param_name' => 'css_animation',

		'value' => '',

		'weight' => 1,

		'settings' => array(

			'type' => 'in',

			'custom' => array(

				array(

					'label' => __( 'Default', 'dpr-adeline-extensions' ),

					'values' => array(

						__( 'Top to bottom', 'dpr-adeline-extensions' ) => 'top-to-bottom',

						__( 'Bottom to top', 'dpr-adeline-extensions' ) => 'bottom-to-top',

						__( 'Left to right', 'dpr-adeline-extensions' ) => 'left-to-right',

						__( 'Right to left', 'dpr-adeline-extensions' ) => 'right-to-left',

						__( 'Appear from center', 'dpr-adeline-extensions' ) => 'appear',

					),

				),

			),

		)

	)

	);

	vc_add_param(

		'vc_row', array(

			'type' => 'dpr_title',

			'text' => esc_html__('One Page Settings', 'dpr-adeline-extensions'),

			'param_name' => '_title',

			'class' => '',

			'weight' => 1

		)

	);

	vc_add_param(

		'vc_row', array(

			'type' => 'textfield',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Add the title for the one page scroll dots navigation', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Title for one page scroll navigation', 'dpr-adeline-extensions'),

			'param_name' => 'one_page_title',

			'value' => '',

			'weight' => 1

		)

	);

	vc_add_param(

		'vc_row', array(

			'type' => 'textfield',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Add the unique anchor name. The anchor can be used for the anchor navigation in menu', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Anchor', 'dpr-adeline-extensions'),

			'param_name' => 'anchor',

			'value' => '',

			'weight' => 1

		)

	);

	vc_add_param(

		'vc_row', array(

			'type' => 'dpr_title',

			'text' => esc_html__('Additional Settings', 'dpr-adeline-extensions'),

			'param_name' => 'additional_title',

			'class' => '',

			'weight' => 1

		)

	);

	vc_add_param(

		'vc_row',array(

			'type' => 'textfield',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Extra Class Name', 'dpr-adeline-extensions'),

			'param_name' => 'el_class',

			'weight' => 1

		)

	);

	vc_add_param(

		'vc_row', array(

			'type' => 'textfield',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to add custom inline css styles for the row.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom Inline CSS Styles', 'dpr-adeline-extensions'),

			'param_name' => 'custom_inline_css',

			'value' => '',

			'weight' => 1

		)

	);

	vc_add_param(

		'vc_row', array(

			'type' => 'dpr_switcher',

			'class' => '',

			'weight' => 1,

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If set to on the row won\'t be visible on the public side of your website. You can switch it back any time.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Disable Row', 'dpr-adeline-extensions'),

			'param_name' => 'disable_element',

			'value' => '',

			'options' => array(

				'yes' => array(

						'label' => '',

						'on' => 'Yes',

						'off' => 'No',

					),

				),

		)

	);

	vc_add_param(

		'vc_row', array(

			'type' => 'dpr_title',

			'text' => esc_html__('Background Options', 'dpr-adeline-extensions'),

			'param_name' => 'background_title',

			'class' => '',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),			

		)

	);

	vc_add_param(

		'vc_row', array(

			'type' => 'dpr_radio',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the background style for the row. The text colors will be changed according to the style you choose to make it more readable.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background style', 'dpr-adeline-extensions'),

			'param_name' => 'bg_style',

			'value' => '',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),			

			'options' => array(

				__('Light', 'dpr-adeline-extensions') => '',

				__('Dark', 'dpr-adeline-extensions') => 'dark',

			)

		)

	);

	vc_add_param(

		'vc_row', array(

			'type' => 'dpr_radio',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the background type for the row. Default will be use settings from Design Options for this row. Gradient allows you to set the gradient backgrouns. Parallax Image allows you to upload the image and add the parallax. Video allows you to set the video as row\'s background', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background type', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_bg_type',

			'value' => 'default',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),			

			'options' => array(

				__('Default', 'dpr-adeline-extensions') => 'default',

				__('Gradient', 'dpr-adeline-extensions') => 'gradient',

				__('Animated', 'dpr-adeline-extensions') => 'animated-bgcolor',

				__('Parallax Image', 'dpr-adeline-extensions') => 'parallax-image',

				__('Multilayers Parallax', 'dpr-adeline-extensions') => 'multilayer-parallax',

				__('Video', 'dpr-adeline-extensions') => 'video',
	
				__('Text', 'dpr-adeline-extensions') => 'text',
		
				__('Marque', 'dpr-adeline-extensions') => 'marque'
		

			)

		)

	);

	vc_add_param(

		'vc_row', array(

				'type' => 'dpr_gradient_picker',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the gradient for the row background.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Row gradient', 'dpr-adeline-extensions'),

				'param_name' => 'dpr_row_gradient',

				'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),			

				'value' => '',

				'dependency' => array(

					'element' => 'dpr_bg_type',

					'value' => 'gradient',

				),

		)

	);

	vc_add_param(

		'vc_row', array(

			'type' => 'dpr_switcher',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('This option allows you to enable or disable the row gradient animation.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Enable Gradient Animation', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_row_gradient_animate',

			'edit_field_class' => 'vc_column vc_col-sm-4',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'dependency' => array(

					'element' => 'dpr_bg_type',

					'value' => 'gradient',

				),			

			'value' => '',

			'options' => array(

				'yes' => array(

						'label' => '',

						'on' => 'Yes',

						'off' => 'No',

					),

				),

		)

	);

	vc_add_param(

		'vc_row',array(

			'type' => 'number',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set the animation duration in ms.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Animation Duration (in sec)', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_row_gradient_animate_speed',

			'value' =>'10',

			'min'=>'0',

			'step' => '0.5',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'edit_field_class' => 'vc_column vc_col-sm-4',

			'dependency' => array(

					'element' => 'dpr_row_gradient_animate',

					'value' => array('yes'),

			),		

		)

	);

	vc_add_param(

		'vc_row',array(

			'type' => 'number',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set the gradient background spread in % to adjust animation effect to uour needs.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background Spread (in %)', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_row_gradient_animate_spread',

			'value' =>'400',

			'min'=>'0',

			'step' => '10',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'edit_field_class' => 'vc_column vc_col-sm-4',

			'dependency' => array(

					'element' => 'dpr_row_gradient_animate',

					'value' => array('yes'),

			),		

		)

	);

	vc_add_param(

		'vc_row', array(

                'type' => 'param_group',

                'value' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Add colors for background color animation.You can use multiple colors which will be fade with animation speed set bellow.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Colors', 'dpr-adeline-extensions'),

				'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

				'value' => '',

				'dependency' => array(

						'element' => 'dpr_bg_type',

						'value' => 'animated-bgcolor',

					),		

                'param_name' => 'dpr_animated_colors',

                // Note params is mapped inside param-group:

                'params' => array(			

                    array(

                        'type' => 'colorpicker',

                        'param_name' => 'dpr_animated_color',

                    ),

                )

            )

	);

	vc_add_param(

		'vc_row',array(

			'type' => 'number',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set the animation duration in ms.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Animation Loop Duration (in sec)', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_animated_speed',

			'value' =>'3',

			'min'=>'0',

			'step' => '0.1',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'edit_field_class' => 'vc_column vc_col-sm-6',

			'dependency' => array(

					'element' => 'dpr_bg_type',

					'value' => 'animated-bgcolor',

			),		

		)

	);

	vc_add_param(

		'vc_row', array(

			'type' => 'attach_image',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose parallax image', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Parallax image', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_parallax_image',

			'value' => '',

			'edit_field_class' => 'vc_column vc_col-sm-12',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'dependency' => array(

					'element' => 'dpr_bg_type',

					'value' => 'parallax-image',

			),		

		)

	);

	vc_add_param(

		'vc_row', array(

			'type' => 'dpr_radio',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose Parallax Direction', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Parallax Direction', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_parallax_type',

			'value' => 'vertical',

			'edit_field_class' => 'vc_column vc_col-sm-6',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'dependency' => array(

					'element' => 'dpr_bg_type',

					'value' => 'parallax-image',

				),		

			'options' => array(

				__('Vertical', 'dpr-adeline-extensions') => 'vertical',

				__('Horizontal', 'dpr-adeline-extensions') => 'horizontal'

			)

		)

	);

	vc_add_param(

		'vc_row',array(

			'type' => 'number',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('This attribute sets elements offset and speed. It can be positive (0.3) or negative (-0.3). Less means slower.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Parallax Factor', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_parallax_factor',

			'value' =>'0.30',

			'min'=>'-1',

			'max'=>'1',

			'step' => '0.01',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'edit_field_class' => 'vc_column vc_col-sm-6',

			'dependency' => array(

					'element' => 'dpr_bg_type',

					'value' => 'parallax-image',

			),		

		)

	);



	vc_add_param(

		'vc_row', array(

                'type' => 'param_group',

                'value' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Add and order parallax layers.You can use multiple transparent or semitransparent layers and set parallax direction and factor sepratelly for each layer.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Parallax Layers', 'dpr-adeline-extensions'),

				'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

				'value' => '',

				'dependency' => array(

						'element' => 'dpr_bg_type',

						'value' => 'multilayer-parallax',

					),		

                'param_name' => 'dpr_parallax_layers',

                // Note params is mapped inside param-group:

                'params' => array(

                    array(

                        'type' => 'attach_image',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose layer image', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Layer image', 'dpr-adeline-extensions'),

                        'param_name' => 'dpr_layer_parallax_image',

                    ),

                    array(

                        'type' => 'dpr_radio',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose Parallax Direction', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Layer Parallax Direction', 'dpr-adeline-extensions'),

                        'param_name' => 'dpr_layer_parallax_type',

						'value' => 'vertical',

						'edit_field_class' => 'vc_column vc_col-sm-6',

						'options' => array(

							__('Vertical', 'dpr-adeline-extensions') => 'vertical',

							__('Horizontal', 'dpr-adeline-extensions') => 'horizontal'

						)

                    ),

                    array(

                        'type' => 'number',

                        'param_name' => 'dpr_layer_parallax_fator',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('This attribute sets elements offset and speed. It can be positive (0.3) or negative (-0.3). Less means slower.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Layer Parallax Factor', 'dpr-adeline-extensions'),

						'value' => '0.30',

						'min'=>'-1',

						'max'=>'1',

						'step' => '0.01',

						'edit_field_class' => 'vc_column vc_col-sm-6'

                    ),

                )

            )

	);

	vc_add_param(

		'vc_row', array(

			'type' => 'dpr_image_select',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Chose video type', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Video Source', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_video_type',

			'value' => 'hosted',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'dependency' => array(

					'element' => 'dpr_bg_type',

					'value' => 'video',

				),		

			'options'			=> array(

				'hosted'			=> array(

					'label'			=> esc_html__('Hosted','dpr-adeline-extensions'),

					'src'				=> $module_images . 'row/self_hosted.png'

				),

				'youtube'			=> array(

					'label'			=> esc_html__('YouTube','dpr-adeline-extensions'),

					'src'				=> $module_images . 'row/youtube.png'

				),

				'vimeo'			=> array(

					'label'			=> esc_html__('Vimeo','dpr-adeline-extensions'),

					'src'				=> $module_images . 'row/vimeo.png'

				)

			),

		)

	);

	vc_add_param(

		'vc_row', array(

			'type' => 'textfield',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Add the link to your video in mp4 format', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Video in MP4 format', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_mp4_url',

			'value' => '',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'dependency' => array(

					'element' => 'dpr_video_type',

					'value' => 'hosted',

				),		

		)

	);

	vc_add_param(

		'vc_row', array(

			'type' => 'textfield',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Add the link to your video in WebM / Ogg format', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Video in WEBM / OGG format', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_webm_url',

			'value' => '',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'dependency' => array(

					'element' => 'dpr_video_type',

					'value' => 'hosted',

				),

			'description' => esc_attr__('IE, Chrome & Safari support MP4 format, while Firefox & Opera prefer WebM / Ogg formats. You can upload the video through WordPress Media Library.', 'dpr-adeline-extensions')

		)

	);

	vc_add_param(

		'vc_row', array(

			'type' => 'textfield',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Add the video ID. Look at the URL of that page, and at the end of it, you should see a combination of numbers and letters after an equal sign (=)', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('YouTube Video ID', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_youtube_id',

			'value' => '',

			'edit_field_class' => 'vc_column vc_col-sm-12',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'dependency' => array(

					'element' => 'dpr_video_type',

					'value' => 'youtube',

				),

			'description' => esc_attr__('Add the video ID. Look at the URL of that page, and at the end of it, you should see a combination of numbers and letters after an equal sign (=).', 'dpr-adeline-extensions')

		)

	);

	vc_add_param(

		'vc_row', array(

			'type' => 'textfield',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Add the video ID. Copy the numeric code that appears at the end of its URL at the top of your browser window', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Vimeo Video ID', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_vimeo_id',

			'value' => '',

			'edit_field_class' => 'vc_column vc_col-sm-12',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'dependency' => array(

					'element' => 'dpr_video_type',

					'value' => 'vimeo',

				),

			'description' => esc_attr__('Add the video ID. Copy the numeric code that appears at the end of its URL at the top of your browser window.', 'dpr-adeline-extensions')

		)

	);

	vc_add_param(

			'vc_row',array(

			'type' => 'checkbox',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('These options allow you to loop and mute the video set as the background', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Video Options', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_video_options',

			'value' => array(

					__('Loop','dpr-adeline-extensions') => 'loop',

					__('Muted','dpr-adeline-extensions') => 'muted',

				),

			'dependency' => array(

					'element' => 'dpr_bg_type',

					'value' => 'video',

				),		

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

	  )

	);

	vc_add_param(

		'vc_row',array(

			'type' => 'number',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set video start time in seconds.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Video Start Time', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_video_start_time',

			'value' =>'',

			'min'=>'0',

			'step' => '1',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'edit_field_class' => 'vc_column vc_col-sm-3',

			'dependency' => array(

					'element' => 'dpr_video_type',

					'value' => 'youtube',

			),		

		)

	);

	vc_add_param(

		'vc_row',array(

			'type' => 'number',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set video stop time in seconds', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Video Stop Time', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_video_stop_time',

			'value' =>'',

			'min'=>'0',

			'step' => '1',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'edit_field_class' => 'vc_column vc_col-sm-3',

			'dependency' => array(

					'element' => 'dpr_video_type',

					'value' => 'youtube',

			),		

		)

	);

	vc_add_param(

		'vc_row', array(

			'type' => 'attach_image',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose placeholder image', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Placeholder Image', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_video_poster',

			'value' => '',

			'edit_field_class' => 'vc_column vc_col-sm-12',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'dependency' => array(

					'element' => 'dpr_bg_type',

					'value' => 'video',

			),

			'description' => esc_attr__('Placeholder image is displayed in case background video is restricted. (For example, on mobiles).', 'dpr-adeline-extensions')		

		)

	);

	vc_add_param(

		'vc_row', array(

			'type' => 'textfield',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enter background text').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background Text', 'dpr-adeline-extensions'),

			'param_name' => 'bg_text',

			'value' => '',

			'edit_field_class' => 'vc_column vc_col-sm-12',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'dependency' => array(

					'element' => 'dpr_bg_type',

					'value' => 'text',

			)

		)

	);

	vc_add_param(

		'vc_row', array(

			'type' => 'dpr_radio',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose background text width (full width or according grid).', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background Text Width', 'dpr-adeline-extensions'),

			'param_name' => 'bg_text_width',

			'value' => 'full',

			'edit_field_class' => 'vc_column vc_col-sm-4',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'dependency' => array(

					'element' => 'dpr_bg_type',

					'value' => 'text',

			),

			'options' => array(

				__('Full', 'dpr-adeline-extensions') => 'full',

				__('In Grid', 'dpr-adeline-extensions') => 'grid'

			)

		)

	);

	vc_add_param(

		'vc_row', array(

			'type' => 'dpr_switcher',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('This option allows you to enable or disable the overlay for the row.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Enable Text Animation?', 'dpr-adeline-extensions'),

			'param_name' => 'bg_text_animation',

			'edit_field_class' => 'vc_column vc_col-sm-6',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'dependency' => array(

					'element' => 'dpr_bg_type',

					'value' => 'text',

			),

			'value' => '',

			'options' => array(

				'yes' => array(

						'label' => '',

						'on' => 'Yes',

						'off' => 'No',

					),

				),

		)

	);


	vc_add_param(

		'vc_row', array(

			'type' => 'dpr_radio',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose background text horizontal position.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Horizontal Position', 'dpr-adeline-extensions'),

			'param_name' => 'bg_text_hpos',

			'value' => 'left',

			'edit_field_class' => 'vc_column vc_col-sm-6',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'dependency' => array(

					'element' => 'dpr_bg_type',

					'value' => 'text',

			),

			'options' => array(

				__('Left', 'dpr-adeline-extensions') => 'left',

				__('Center', 'dpr-adeline-extensions') => 'center',

				__('Right', 'dpr-adeline-extensions') => 'right'

			)

		)

	);

	vc_add_param(

		'vc_row', array(

			'type' => 'dpr_radio',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose background text vertical position.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Vertical Position', 'dpr-adeline-extensions'),

			'param_name' => 'bg_text_vpos',

			'value' => 'middle',

			'edit_field_class' => 'vc_column vc_col-sm-6',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'dependency' => array(

					'element' => 'dpr_bg_type',

					'value' => 'text',

			),

			'options' => array(

				__('Top', 'dpr-adeline-extensions') => 'top',

				__('Middle', 'dpr-adeline-extensions') => 'middle',

				__('Bottom', 'dpr-adeline-extensions') => 'bottom'

			)

		)

	);

	vc_add_param(

		'vc_row', array(

			'type' => 'textfield',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enter background text left padding.').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Padding Left', 'dpr-adeline-extensions'),

			'param_name' => 'bg_text_padding_left',

			'value' => '',

			'edit_field_class' => 'vc_column vc_col-sm-6',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'dependency' => array(

					'element' => 'bg_text_hpos',

					'value' => 'left',

			),

			'description' => esc_attr__('Enter valid padding value (eg 100px, 10%, 10vw).', 'dpr-adeline-extensions')

		)

	);

	vc_add_param(

		'vc_row', array(

			'type' => 'textfield',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enter background text right padding.').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Padding Right', 'dpr-adeline-extensions'),

			'param_name' => 'bg_text_padding_right',

			'value' => '',

			'edit_field_class' => 'vc_column vc_col-sm-6',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'dependency' => array(

					'element' => 'bg_text_hpos',

					'value' => 'right',

			),

			'description' => esc_attr__('Enter valid padding value (eg 100px, 10%, 10vw).', 'dpr-adeline-extensions')

		)

	);

	vc_add_param(

		'vc_row', array(

			'type' => 'textfield',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enter background text top padding.').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Padding Top', 'dpr-adeline-extensions'),

			'param_name' => 'bg_text_padding_top',

			'value' => '',

			'edit_field_class' => 'vc_column vc_col-sm-6',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'dependency' => array(

					'element' => 'bg_text_vpos',

					'value' => 'top',

			),

			'description' => esc_attr__('Enter valid padding value (eg 100px, 10%, 10vh).', 'dpr-adeline-extensions')

		)

	);

	vc_add_param(

		'vc_row', array(

			'type' => 'textfield',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enter background text bottom padding.').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Padding Bottom', 'dpr-adeline-extensions'),

			'param_name' => 'bg_text_padding_bottom',

			'value' => '',

			'edit_field_class' => 'vc_column vc_col-sm-6',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'dependency' => array(

					'element' => 'bg_text_vpos',

					'value' => 'bottom',

			),

			'description' => esc_attr__('Enter valid padding value (eg 100px, 10%, 10vh).', 'dpr-adeline-extensions')

		)

	);

	vc_add_param(

		'vc_row', array(

			'type' => 'dpr_title',

			'text' => esc_html__('Background Text Typography', 'dpr-adeline-extensions'),

			'param_name' => 'bg_text_typography_title',

			'class' => '',
		
			'dependency' => array(

					'element' => 'dpr_bg_type',

					'value' => 'text',

			),		

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),			

		)

	);


	vc_add_param(

		'vc_row', array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom background text color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background Text Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'bg_text_color',

				'edit_field_class'	=> 'vc_col-sm-3 vc_column ',
		
				'dependency' => array(

						'element' => 'dpr_bg_type',

						'value' => 'text',

				),
		
				'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			)
		);

	vc_add_param(

		'vc_row', array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size. If you leave this field blank will be used default size 230px.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'bg_text_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency' => array(

							'element' => 'dpr_bg_type',

							'value' => 'text',

				),

				'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			)
		);

	vc_add_param(
		'vc_row', array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom text linne height.Default is 230px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'bg_text_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',
		
				'dependency' => array(

							'element' => 'dpr_bg_type',

							'value' => 'text',

				),

				'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			)
		);

	vc_add_param(

		'vc_row', array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom text letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'bg_text_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',
		
				'dependency' => array(

							'element' => 'dpr_bg_type',

							'value' => 'text',

				),

				'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			)
		);

	vc_add_param(

		'vc_row', array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'bg_text_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'dependency' => array(

							'element' => 'dpr_bg_type',

							'value' => 'text',

				),

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

	  		)
		);

		vc_add_param(

		'vc_row', array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_bg_text_google_fonts',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',
			
				'dependency' => array(

							'element' => 'dpr_bg_type',

							'value' => 'text',

				),

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			)
		);

		vc_add_param(

		'vc_row', array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'bg_text_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'dependency'		=> array('element' => 'use_bg_text_google_fonts', 'value' => array('yes')),

				'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			)
		);

		vc_add_param(

		'vc_row', array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable responsive typography for background text.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Enable Responsive Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_bg_text_responsive_typo',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'dependency' => array(

							'element' => 'dpr_bg_type',

							'value' => 'text',

				),

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			)
		);

	vc_add_param(

		'vc_row', array(

				'type'				=> 'dpr_responsive_typo',

				'param_name'		=> 'bg_text_reaponsive_typography',

				'heading'			=> '',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'use_bg_text_responsive_typo', 'value' => array('yes')),

				'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),


			)
		);


	vc_add_param(

		'vc_row', array(

			'type' => 'dpr_radio',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose background marque type.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background Marque Type', 'dpr-adeline-extensions'),

			'param_name' => 'marque_type',

			'value' => 'text',

			'edit_field_class' => 'vc_column vc_col-sm-4',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'dependency' => array(

					'element' => 'dpr_bg_type',

					'value' => 'marque',

			),

			'options' => array(

				__('Text', 'dpr-adeline-extensions') => 'text',

				__('Image', 'dpr-adeline-extensions') => 'image'

			)

		)

	);

	vc_add_param(

		'vc_row', array(

			'type' => 'textfield',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enter marque text').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Marque Text', 'dpr-adeline-extensions'),

			'param_name' => 'bg_marque_text',

			'value' => '',

			'edit_field_class' => 'vc_column vc_col-sm-12',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'dependency' => array(

					'element' => 'marque_type',

					'value' => 'text',

			)

		)

	);



	vc_add_param(

		'vc_row', array(

			'type' => 'dpr_radio',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose text marque vertical position.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Vertical Position', 'dpr-adeline-extensions'),

			'param_name' => 'bg_text_marque_vpos',

			'value' => 'middle',

			'edit_field_class' => 'vc_column vc_col-sm-6',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'dependency' => array(

					'element' => 'marque_type',

					'value' => 'text',

			),

			'options' => array(

				__('Top', 'dpr-adeline-extensions') => 'top',

				__('Middle', 'dpr-adeline-extensions') => 'middle',

				__('Bottom', 'dpr-adeline-extensions') => 'bottom'

			)

		)

	);


	vc_add_param(

		'vc_row', array(

			'type' => 'textfield',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enter text marque top padding.').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Padding Top', 'dpr-adeline-extensions'),

			'param_name' => 'bg_text_marque_padding_top',

			'value' => '',

			'edit_field_class' => 'vc_column vc_col-sm-6',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'dependency' => array(

					'element' => 'bg_text_marque_vpos',

					'value' => 'top',

			),

			'description' => esc_attr__('Enter valid padding value (eg 100px, 10%, 10vh).', 'dpr-adeline-extensions')

		)

	);

	vc_add_param(

		'vc_row', array(

			'type' => 'textfield',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enter text marque bottom padding.').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Padding Bottom', 'dpr-adeline-extensions'),

			'param_name' => 'bg_text_marque_padding_bottom',

			'value' => '',

			'edit_field_class' => 'vc_column vc_col-sm-6',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'dependency' => array(

					'element' => 'bg_text_marque_vpos',

					'value' => 'bottom',

			),

			'description' => esc_attr__('Enter valid padding value (eg 100px, 10%, 10vh).', 'dpr-adeline-extensions')

		)

	);



	vc_add_param(

		'vc_row', array(

			'type'            	=> 'dpr_title',

			'text'            	=> '',

			'class'				=> 'separator',

			'param_name'      	=> 'marque_sep_1',

			'edit_field_class'	=> 'vc_column vc_col-sm-12',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

				'dependency' => array(

						'element' => 'marque_type',

						'value' => 'text',

				),

		)
	);

	vc_add_param(

		'vc_row', array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set marque animation speed. Default is 10000ms.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Marque Speed', 'dpr-adeline-extensions'),

				'param_name'		=> 'bg_text_marque_duration',

				'min'				=> 100,
				
				'step'				=> 100,
		
				'value'				=> 10000,

				'suffix'				=> 'ms',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

				'dependency' => array(

						'element' => 'marque_type',

						'value' => 'text',

				),

				'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			)
		);

	vc_add_param(

		'vc_row', array(

			'type' => 'dpr_radio',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose marque vertical animation direction.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Direction', 'dpr-adeline-extensions'),

			'param_name' => 'bg_text_marque_direction',

			'value' => 'left',

			'edit_field_class' => 'vc_column vc_col-sm-4',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'dependency' => array(

					'element' => 'marque_type',

					'value' => 'text',

			),

			'options' => array(

				__('Left', 'dpr-adeline-extensions') => 'left',

				__('Right', 'dpr-adeline-extensions') => 'right'

			)

		)

	);

		vc_add_param(

		'vc_row', array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Setting too ON let you make the marquee visible initially.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Start Visible?', 'dpr-adeline-extensions'),

				'param_name'		=> 'bg_text_marque_start_visible',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',
			
				'dependency' => array(

						'element' => 'marque_type',

						'value' => 'text',

				),

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			)
		);


		vc_add_param(

		'vc_row', array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Setting too ON let you make marque continious.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Duplicate Marque Text?', 'dpr-adeline-extensions'),

				'param_name'		=> 'bg_text_marque_duplicate',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',
			
				'dependency' => array(

						'element' => 'marque_type',

						'value' => 'text',

				),

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			)
		);

	vc_add_param(

		'vc_row', array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set marque gap between duplicate. Default is 100 px.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Marque Gap', 'dpr-adeline-extensions'),

				'param_name'		=> 'bg_text_marque_gap',

				'min'				=> 0,
				
				'step'				=> 1,
		
				'value'				=> 100,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

				'dependency' => array(

						'element' => 'bg_text_marque_duplicate',

						'value' => 'yes',

				),

				'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			)
		);


	vc_add_param(

		'vc_row', array(
				'type' => 'attach_images',
				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select images which will be appear in marque.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Marque Images', 'dpr-adeline-extensions'),
				'param_name' => 'marque_images',
				'value' => '',
				'description' => esc_html__( 'Select images from media library.', 'js_composer' ),
				'dependency' => array(

						'element' => 'marque_type',

						'value' => 'image',

				),

				'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),		
			)

	);

	vc_add_param(

		'vc_row', array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set marque animation speed in pixels moved per second. Default is 30.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Marque Speed', 'dpr-adeline-extensions'),

				'param_name'		=> 'bg_image_marque_speed',

				'min'				=> 24,
				
				'step'				=> 1,
		
				'value'				=> 30,

				'suffix'				=> 'px/s',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

				'dependency' => array(

						'element' => 'marque_type',

						'value' => 'image',

				),

				'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			)
		);

	vc_add_param(

		'vc_row', array(

			'type' => 'dpr_radio',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose marque vertical animation direction.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Direction', 'dpr-adeline-extensions'),

			'param_name' => 'bg_image_marque_direction',

			'value' => 'forwards',

			'edit_field_class' => 'vc_column vc_col-sm-4',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'dependency' => array(

					'element' => 'marque_type',

					'value' => 'image',

			),

			'options' => array(

				__('Left', 'dpr-adeline-extensions') => 'forwards',

				__('Right', 'dpr-adeline-extensions') => 'backwards'

			)

		)

	);

		vc_add_param(

		'vc_row', array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Setting too ON let you stop marque onhover.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Stop On Hover?', 'dpr-adeline-extensions'),

				'param_name'		=> 'bg_image_marque_stop_onhover',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',
			
				'dependency' => array(

						'element' => 'marque_type',

						'value' => 'image',

				),

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			)
		);






	vc_add_param(

		'vc_row', array(

			'type' => 'dpr_title',

			'text' => esc_html__('Marque Text Typography', 'dpr-adeline-extensions'),

			'param_name' => 'bg_text_marque_typography_title',

			'class' => '',
		
			'dependency' => array(

					'element' => 'marque_type',

					'value' => 'text',

			),

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),			

		)

	);


	vc_add_param(

		'vc_row', array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom marque text color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Marque Text Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'bg_text_marque_color',

				'edit_field_class'	=> 'vc_col-sm-3 vc_column ',
		
				'dependency' => array(

						'element' => 'marque_type',

						'value' => 'text',

				),
		
				'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			)
		);

	vc_add_param(

		'vc_row', array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size. If you leave this field blank will be used default size 320px.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'bg_text_marque_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency' => array(

						'element' => 'marque_type',

						'value' => 'text',

				),

				'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			)
		);

	vc_add_param(
		'vc_row', array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom text line height.Default is 320px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'bg_text_marque_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',
		
				'dependency' => array(

						'element' => 'marque_type',

						'value' => 'text',

				),

				'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			)
		);

	vc_add_param(

		'vc_row', array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom text marque letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'bg_text_marque_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',
		
				'dependency' => array(

						'element' => 'marque_type',

						'value' => 'text',

				),

				'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			)
		);

	vc_add_param(

		'vc_row', array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'bg_text_marque_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'dependency' => array(

						'element' => 'marque_type',

						'value' => 'text',

				),

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

	  		)
		);

		vc_add_param(

		'vc_row', array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_bg_text_marque_google_fonts',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',
			
				'dependency' => array(

						'element' => 'marque_type',

						'value' => 'text',

				),

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			)
		);

		vc_add_param(

		'vc_row', array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'bg_text_marque_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'dependency'		=> array('element' => 'use_bg_text_marque_google_fonts', 'value' => array('yes')),

				'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			)
		);

		vc_add_param(

		'vc_row', array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable responsive typography for background text.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Enable Responsive Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_bg_text_marque_responsive_typo',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'dependency' => array(

						'element' => 'marque_type',

						'value' => 'text',

				),

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			)
		);

	vc_add_param(

		'vc_row', array(

				'type'				=> 'dpr_responsive_typo',

				'param_name'		=> 'bg_text_marque_reaponsive_typography',

				'heading'			=> '',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'use_bg_text_marque_responsive_typo', 'value' => array('yes')),

				'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),


			)
		);















	vc_add_param(

		'vc_row', array(

			'type' => 'dpr_title',

			'text' => esc_html__('Overlay Options', 'dpr-adeline-extensions'),

			'param_name' => 'overlay_title',

			'class' => '',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),			

		)

	);

	vc_add_param(

		'vc_row', array(

			'type' => 'dpr_switcher',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('This option allows you to enable or disable the overlay for the row.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Enable overlay', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_enable_overlay',

			'edit_field_class' => 'vc_column vc_col-sm-6',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),			

			'value' => '',

			'options' => array(

				'yes' => array(

						'label' => '',

						'on' => 'Yes',

						'off' => 'No',

					),

				),

		)

	);

	vc_add_param(

		'vc_row', array(

			'type' => 'dpr_radio',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Overlay Color Type', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_overlay_color_type',

			'value' => 'solid',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'dependency' => array(

					'element' => 'dpr_enable_overlay', 

					'value' => array('yes')

			),

			'options' => array(

				__('Solid Color', 'dpr-adeline-extensions') => 'solid',

				__('Gradient', 'dpr-adeline-extensions') => 'gradient'

			)

		)

	);

	vc_add_param(

			'vc_row', array(

			'type' => 'colorpicker',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the color for the overlay.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Overlay Color', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_overlay_color',

			'value' => '',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),			

			'dependency' => array(

					'element' => 'dpr_overlay_color_type', 

					'value' => array('solid')

			),

		)

	);

	vc_add_param(

		'vc_row', array(

				'type' => 'dpr_gradient_picker',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the gradient for the row overlay.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Overlay Gradient', 'dpr-adeline-extensions'),

				'param_name' => 'dpr_overlay_gradient',

				'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),			

				'value' => '-45;0%/rgba(104, 89, 222, 0.4);100%/rgba(240, 55, 116, 0.4)',

				'dependency' => array(

						'element' => 'dpr_overlay_color_type', 

						'value' => array('gradient')

				),

		)

	);

	vc_add_param(

		'vc_row', array(

			'type' => 'dpr_image_select',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Chose pattern for overlay. Default pattern are black, light patterna are white.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Overlay Pattern', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_overlay_pattern',

			'dependency' => array(

					'element' => 'dpr_enable_overlay', 

					'value' => array('yes')

			),

			'value' => 'transparent',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'options'			=> array(

				'transparent'			=> array(

					'label'			=> esc_html__('None','dpr-adeline-extensions'),

					'src'				=> $module_images . 'row/no-pattern.png'

				),

				'p01'			=> array(

					'label'			=> 'P01',

					'src'				=> $module_images . 'row/p01.png'

				),

				'p02'			=> array(

					'label'			=> 'P02',

					'src'				=> $module_images . 'row/p02.png'

				),

				'p03'			=> array(

					'label'			=> 'P03',

					'src'				=> $module_images . 'row/p03.png'

				),

				'p04'			=> array(

					'label'			=> 'P04',

					'src'				=> $module_images . 'row/p04.png'

				),

				'p05'			=> array(

					'label'			=> 'P05',

					'src'				=> $module_images . 'row/p05.png'

				),

				'p06'			=> array(

					'label'			=> 'P06',

					'src'				=> $module_images . 'row/p06.png'

				),

				'p07'			=> array(

					'label'			=> 'P07',

					'src'				=> $module_images . 'row/p07.png'

				),

				'p08'			=> array(

					'label'			=> 'P08',

					'src'				=> $module_images . 'row/p08.png'

				),

				'p09'			=> array(

					'label'			=> 'P09',

					'src'				=> $module_images . 'row/p09.png'

				),

				'p01-l'			=> array(

					'label'			=> 'P01 Light',

					'src'				=> $module_images . 'row/p01-l.png'

				),

				'p02-l'			=> array(

					'label'			=> 'P02 Light',

					'src'				=> $module_images . 'row/p02-l.png'

				),

				'p03-l'			=> array(

					'label'			=> 'P03 Light',

					'src'				=> $module_images . 'row/p03-l.png'

				),

				'p04-l'			=> array(

					'label'			=> 'P04 Light',

					'src'				=> $module_images . 'row/p04-l.png'

				),

				'p05-l'			=> array(

					'label'			=> 'P05 Light',

					'src'				=> $module_images . 'row/p05-l.png'

				),

				'p06-l'			=> array(

					'label'			=> 'P06 Light',

					'src'				=> $module_images . 'row/p06-l.png'

				),

				'p07-l'			=> array(

					'label'			=> 'P07 Light',

					'src'				=> $module_images . 'row/p07-l.png'

				),

				'p08-l'			=> array(

					'label'			=> 'P08 Light',

					'src'				=> $module_images . 'row/p08-l.png'

				),

				'p09-l'			=> array(

					'label'			=> 'P09 Light',

					'src'				=> $module_images . 'row/p09-l.png'

				),

				'custom'			=> array(

					'label'			=> 'Custom',

					'src'				=> $module_images . 'row/custom-pattern.png'

				),

			),

		)

	);

	vc_add_param(

		'vc_row',array(

			'type' => 'textarea',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enter custom pattern style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom Pattern Style', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_overlay_custom_pattern',

			'value' =>'',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'edit_field_class' => 'vc_column vc_col-sm-12',

			'dependency' => array(

					'element' => 'dpr_overlay_pattern', 

					'value' => array('custom')

			),

			'description' => esc_attr__('Enter in this field any valid CSS code for custom pattern (For example, custom svg pattern).', 'dpr-adeline-extensions')		

		)

	);

	vc_add_param(

		'vc_row',array(

			'type' => 'number',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set pattern opacity. Enter value between 0 to 100 (0 is transparent) ', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Pattern Opacity', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_overlay_pattern_opacity',

			'value' =>'100',

			'min'=>'0',

			'max' => '100',

			'step' => '1',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'edit_field_class' => 'vc_column vc_col-sm-3',

			'dependency' => array(

					'element' => 'dpr_enable_overlay', 

					'value' => array('yes')

			),

		)

	);

	vc_add_param(

		'vc_row',array(

			'type' => 'number',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Specify the pattern\'s size for the overlay in px. If you leave this field blank pattern will be displayed own size', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Pattern Size', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_overlay_pattern_size',

			'value' =>'',

			'min'=>'1',

			'step' => '1',

			'group' => esc_html__('DP Background', 'dpr-adeline-extensions'),

			'edit_field_class' => 'vc_column vc_col-sm-3',

			'dependency' => array(

					'element' => 'dpr_enable_overlay', 

					'value' => array('yes')

			),

		)

	);

/* Shape Dividers stuff */

	vc_add_param(

		'vc_row', array(

			'type' => 'dpr_title',

			'text' => esc_html__('Top Divider', 'dpr-adeline-extensions'),

			'param_name' => 'divider_top_title',

			'group' => esc_html__('DP Shape Dividers', 'dpr-adeline-extensions'),

			'class' => ''

		)

	);

	vc_add_param(

		'vc_row', array(

			'type' => 'dpr_switcher',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('This option allows you to add shape top divider.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Enable Top Divider', 'dpr-adeline-extensions'),

			'param_name' => 'enable_top_divider',

			'edit_field_class' => 'vc_column vc_col-sm-6',

			'group' => esc_html__('DP Shape Dividers', 'dpr-adeline-extensions'),			

			'value' => 'off',

			'options' => array(

				'yes' => array(

						'label' => '',

						'on' => 'Yes',

						'off' => 'No',

					),

				),

		)

	);

	vc_add_param(

		'vc_row', array(

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose top divider style.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Top Divider Style', 'dpr-adeline-extensions'),

				'type'				=> 'dpr_image_select',

				'param_name'		=> 'top_divider_type',

				'value' 			=> '',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group' => esc_html__('DP Shape Dividers', 'dpr-adeline-extensions'),

				'dependency' => array(

						'element' => 'enable_top_divider', 

						'value' => array('yes')

				),

				'options'			=> array(

					'arrow_top'			=> array(

						'label'			=> esc_html__('Arrow', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/top/arrow-1-top.jpg'

					),

					'arrow2_top'			=> array(

						'label'			=> esc_html__('Arrow 2', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/top/arrow-2-top.jpg'

					),

					'arrow3_top'			=> array(

						'label'			=> esc_html__('Arrow 3', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/top/arrow-3-top.jpg'

					),

					'asymetric_top'			=> array(

						'label'			=> esc_html__('Asymetric', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/top/asymetric-1-top.jpg'

					),

					'asymetric2_top'			=> array(

						'label'			=> esc_html__('Asymetric 2', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/top/asymetric-2-top.jpg'

					),

					'asymetric3_top'			=> array(

						'label'			=> esc_html__('Asymetric 3', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/top/asymetric-3-top.jpg'

					),

					'asymetric4_top'			=> array(

						'label'			=> esc_html__('Asymetric 4', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/top/asymetric-4-top.jpg'

					),

					'clouds1_top'			=> array(

						'label'			=> esc_html__('Clouds 1', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/top/clouds-1-top.jpg'

					),

					'clouds2_top'			=> array(

						'label'			=> esc_html__('Clouds 2', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/top/clouds-3-top.jpg'

					),

					'curve1_top'			=> array(

						'label'			=> esc_html__('Curve 1', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/top/curve-1-top.jpg'

					),

					'curve2_top'			=> array(

						'label'			=> esc_html__('Curve 2', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/top/curve-2-top.jpg'

					),

					'graph1_top'			=> array(

						'label'			=> esc_html__('Graph 1', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/top/graph-1-top.jpg'

					),

					'graph2_top'			=> array(

						'label'			=> esc_html__('Graph 2', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/top/graph-2-top.jpg'

					),

					'graph3_top'			=> array(

						'label'			=> esc_html__('Graph 3', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/top/graph-3-top.jpg'

					),

					'graph4_top'			=> array(

						'label'			=> esc_html__('Graph 4', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/top/graph-4-top.jpg'

					),

					'mountain1_top'			=> array(

						'label'			=> esc_html__('Mountain 1', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/top/mountain-1-top.jpg'

					),

					'mountain2_top'			=> array(

						'label'			=> esc_html__('Mountain 2', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/top/mountain-2-top.jpg'

					),

					'ramp1_top'			=> array(

						'label'			=> esc_html__('Ramp 1', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/top/ramp-1-top.jpg'

					),

					'ramp2_top'			=> array(

						'label'			=> esc_html__('Ramp 2', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/top/ramp-2-top.jpg'

					),

					'slant1_top'			=> array(

						'label'			=> esc_html__('Slant 1', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/top/slant-1-top.jpg'

					),

					'slant2_top'			=> array(

						'label'			=> esc_html__('Slant 2', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/top/slant-2-top.jpg'

					),

					'triangle_top'			=> array(

						'label'			=> esc_html__('triangle', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/top/triangle-1-top.jpg'

					),

					'wave1_top'			=> array(

						'label'			=> esc_html__('Wave 1', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/top/wave-1-top.jpg'

					),

					'wave2_top'			=> array(

						'label'			=> esc_html__('Wave 2', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/top/wave-2-top.jpg'

					),

					'waves1_top'			=> array(

						'label'			=> esc_html__('Waves 1', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/top/waves-1-top.jpg'

					),

					'waves2_top'			=> array(

						'label'			=> esc_html__('Waves 2', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/top/waves-2-top.jpg'

					),

				),

			)



	);

	vc_add_param(

		'vc_row',array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose divider shape color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Top Divider Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'top_divider_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

			'group' => esc_html__('DP Shape Dividers', 'dpr-adeline-extensions'),

			'dependency' => array(

					'element' => 'enable_top_divider', 

					'value' => array('yes')

			),

			)

	);

	vc_add_param(

		'vc_row', array(

			'type' => 'dpr_switcher',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('This option allows you to add  reverse horizontal shape divider.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Reverse Horizontal', 'dpr-adeline-extensions'),

			'param_name' => 'top_divider_reverse',

			'edit_field_class' => 'vc_column vc_col-sm-6',

			'group' => esc_html__('DP Shape Dividers', 'dpr-adeline-extensions'),			

			'value' => 'off',

			'dependency' => array(

					'element' => 'enable_top_divider', 

					'value' => array('yes')

			),			

			'options' => array(

				'yes' => array(

						'label' => '',

						'on' => 'Yes',

						'off' => 'No',

					),

				),

		)

	);

	vc_add_param(

		'vc_row',array(

			'type' => 'number',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set top divider height in px.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Top Divider Height', 'dpr-adeline-extensions'),

			'param_name' => 'top_divider_height',

			'value' =>'100',

			'min'=>'0',

			'max' => '500',

			'step' => '1',

			'suffix' => 'px',

			'edit_field_class' => 'vc_column vc_col-sm-6',

			'group' => esc_html__('DP Shape Dividers', 'dpr-adeline-extensions'),

			'dependency' => array(

					'element' => 'enable_top_divider', 

					'value' => array('yes')

			),

		)

	);

	vc_add_param(

		'vc_row',array(

			'type' => 'number',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set top divider shape width in %.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Top Divider Shape Width', 'dpr-adeline-extensions'),

			'param_name' => 'top_divider_width',

			'value' =>'100',

			'min'=>'100',

			'max' => '300',

			'step' => '1',

			'suffix' => '%',

			'edit_field_class' => 'vc_column vc_col-sm-6',

			'group' => esc_html__('DP Shape Dividers', 'dpr-adeline-extensions'),

			'dependency' => array(

					'element' => 'enable_top_divider', 

					'value' => array('yes')

			),

		)

	);

	

	vc_add_param(

		'vc_row', array(

			'type' => 'dpr_title',

			'text' => esc_html__('Bottom Divider', 'dpr-adeline-extensions'),

			'param_name' => 'divider_bottom_title',

			'group' => esc_html__('DP Shape Dividers', 'dpr-adeline-extensions'),

			'class' => ''

		)

	);

	vc_add_param(

		'vc_row', array(

			'type' => 'dpr_switcher',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('This option allows you to add  bottom shape divider.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Enable Bottom Divider', 'dpr-adeline-extensions'),

			'param_name' => 'enable_bottom_divider',

			'edit_field_class' => 'vc_column vc_col-sm-6',

			'group' => esc_html__('DP Shape Dividers', 'dpr-adeline-extensions'),			

			'value' => 'off',

			'options' => array(

				'yes' => array(

						'label' => '',

						'on' => 'Yes',

						'off' => 'No',

					),

				),

		)

	);

	vc_add_param(

		'vc_row', array(

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose bottom divider style.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Bottom Divider Style', 'dpr-adeline-extensions'),

				'type'				=> 'dpr_image_select',

				'param_name'		=> 'bottom_divider_type',

				'value' 			=> '',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group' => esc_html__('DP Shape Dividers', 'dpr-adeline-extensions'),

				'dependency' => array(

						'element' => 'enable_bottom_divider', 

						'value' => array('yes')

				),

				'options'			=> array(

					'arrow_bottom'			=> array(

						'label'			=> esc_html__('Arrow', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/bottom/arrow-1-bottom.jpg'

					),

					'arrow2_bottom'			=> array(

						'label'			=> esc_html__('Arrow 2', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/bottom/arrow-2-bottom.jpg'

					),

					'arrow3_bottom'			=> array(

						'label'			=> esc_html__('Arrow 3', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/bottom/arrow-3-bottom.jpg'

					),

					'asymetric_bottom'			=> array(

						'label'			=> esc_html__('Asymetric', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/bottom/asymetric-1-bottom.jpg'

					),

					'asymetric2_bottom'			=> array(

						'label'			=> esc_html__('Asymetric 2', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/bottom/asymetric-2-bottom.jpg'

					),

					'asymetric3_bottom'			=> array(

						'label'			=> esc_html__('Asymetric 3', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/bottom/asymetric-3-bottom.jpg'

					),

					'asymetric4_bottom'			=> array(

						'label'			=> esc_html__('Asymetric 4', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/bottom/asymetric-4-bottom.jpg'

					),

					'clouds1_bottom'			=> array(

						'label'			=> esc_html__('Clouds 1', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/bottom/clouds-1-bottom.jpg'

					),

					'clouds2_bottom'			=> array(

						'label'			=> esc_html__('Clouds 2', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/bottom/clouds-4-bottom.jpg'

					),

					'curve1_bottom'			=> array(

						'label'			=> esc_html__('Curve 1', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/bottom/curve-1-bottom.jpg'

					),

					'curve2_bottom'			=> array(

						'label'			=> esc_html__('Curve 2', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/bottom/curve-2-bottom.jpg'

					),

					'graph1_bottom'			=> array(

						'label'			=> esc_html__('Graph 1', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/bottom/graph-1-bottom.jpg'

					),

					'graph2_bottom'			=> array(

						'label'			=> esc_html__('Graph 2', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/bottom/graph-2-bottom.jpg'

					),

					'graph3_bottom'			=> array(

						'label'			=> esc_html__('Graph 3', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/bottom/graph-3-bottom.jpg'

					),

					'graph4_bottom'			=> array(

						'label'			=> esc_html__('Graph 4', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/bottom/graph-4-bottom.jpg'

					),

					'mountain1_bottom'			=> array(

						'label'			=> esc_html__('Mountain 1', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/bottom/mountains-1-bottom.jpg'

					),

					'mountain2_bottom'			=> array(

						'label'			=> esc_html__('Mountain 2', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/bottom/mountains-2-bottom.jpg'

					),

					'ramp1_bottom'			=> array(

						'label'			=> esc_html__('Ramp 1', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/bottom/ramp-1-bottom.jpg'

					),

					'ramp2_bottom'			=> array(

						'label'			=> esc_html__('Ramp 2', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/bottom/ramp-2-bottom.jpg'

					),

					'slant1_bottom'			=> array(

						'label'			=> esc_html__('Slant 1', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/bottom/slant-1-bottom.jpg'

					),

					'slant2_bottom'			=> array(

						'label'			=> esc_html__('Slant 2', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/bottom/slant-2-bottom.jpg'

					),

					'triangle_bottom'			=> array(

						'label'			=> esc_html__('triangle', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/bottom/triangle-1-bottom.jpg'

					),

					'wave1_bottom'			=> array(

						'label'			=> esc_html__('Wave 1', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/bottom/wave-1-bottom.jpg'

					),

					'wave2_bottom'			=> array(

						'label'			=> esc_html__('Wave 2', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/bottom/wave-2-bottom.jpg'

					),

					'waves1_bottom'			=> array(

						'label'			=> esc_html__('Waves 1', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/bottom/waves-1-bottom.jpg'

					),

					'waves2_bottom'			=> array(

						'label'			=> esc_html__('Waves 2', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'shape-divider/bottom/waves-2-bottom.jpg'

					),

				),

			)



	);

	vc_add_param(

		'vc_row',array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose bottom divider shape color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Bottom Divider Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'bottom_divider_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

			'group' => esc_html__('DP Shape Dividers', 'dpr-adeline-extensions'),

			'dependency' => array(

					'element' => 'enable_bottom_divider', 

					'value' => array('yes')

			),

			)

	);

	vc_add_param(

		'vc_row', array(

			'type' => 'dpr_switcher',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('This option allows you to reverse horizontal shape divider.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Reverse Horizontal', 'dpr-adeline-extensions'),

			'param_name' => 'bottom_divider_reverse',

			'edit_field_class' => 'vc_column vc_col-sm-6',

			'group' => esc_html__('DP Shape Dividers', 'dpr-adeline-extensions'),			

			'value' => 'off',

			'dependency' => array(

					'element' => 'enable_bottom_divider', 

					'value' => array('yes')

			),			

			'options' => array(

				'yes' => array(

						'label' => '',

						'on' => 'Yes',

						'off' => 'No',

					),

				),

		)

	);

	vc_add_param(

		'vc_row',array(

			'type' => 'number',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set bottom divider height in px.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Bottom Divider Height', 'dpr-adeline-extensions'),

			'param_name' => 'bottom_divider_height',

			'value' =>'100',

			'min'=>'0',

			'max' => '500',

			'step' => '1',

			'suffix' => 'px',

			'edit_field_class' => 'vc_column vc_col-sm-4',

			'group' => esc_html__('DP Shape Dividers', 'dpr-adeline-extensions'),

			'dependency' => array(

					'element' => 'enable_bottom_divider', 

					'value' => array('yes')

			),

		)

	);

	vc_add_param(

		'vc_row',array(

			'type' => 'number',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set bottom divider shape width in %.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Bottom Divider Shape Width', 'dpr-adeline-extensions'),

			'param_name' => 'bottom_divider_width',

			'value' =>'100',

			'min'=>'100',

			'max' => '300',

			'step' => '1',

			'suffix' => '%',

			'edit_field_class' => 'vc_column vc_col-sm-4',

			'group' => esc_html__('DP Shape Dividers', 'dpr-adeline-extensions'),

			'dependency' => array(

					'element' => 'enable_bottom_divider', 

					'value' => array('yes')

			),

		)

	);

/* Responsive Options stuff */	

	vc_add_param(

		'vc_row', array(

			'type' => 'dpr_switcher',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('This option allows you to add custom paddings, margins and border for different devices.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Responsive Custom CSS', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_enable_responsive_options',

			'edit_field_class' => 'vc_column vc_col-sm-6',

			'group' => esc_html__('DP Responsive Options', 'dpr-adeline-extensions'),			

			'value' => '',

			'options' => array(

				'yes' => array(

						'label' => '',

						'on' => 'Yes',

						'off' => 'No',

					),

				),

		)

	);
	vc_add_param(

		'vc_row',array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Hide this row on certain devices', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Hide on devices', 'dpr-adeline-extensions'),

				'param_name' => 'hide_on',

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'value' => array(

						__('Desktop','dpr-adeline-extensions') => 'lg',

						__('Small Desktop','dpr-adeline-extensions') => 'md',

						__('Tablet','dpr-adeline-extensions') => 'sm',

						__('Mobile','dpr-adeline-extensions') => 'xs'

					),

				'group'				=> esc_html__('DP Responsive Options', 'dpr-adeline-extensions'),

				'dependency' => array(

					'element' => 'dpr_enable_responsive_options', 

					'value' => array('yes')

				),
	  		
	  		)
	);
	vc_add_param(

		'vc_row', array(

			'type' => 'dpr_switcher',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('This option allows you to add custom paddings, margins and border for different devices.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Responsive Custom CSS', 'dpr-adeline-extensions'),

			'param_name' => 'dpr_enable_responsive_options',

			'edit_field_class' => 'vc_column vc_col-sm-6',

			'group' => esc_html__('DP Responsive Options', 'dpr-adeline-extensions'),			

			'value' => '',

			'options' => array(

				'yes' => array(

						'label' => '',

						'on' => 'Yes',

						'off' => 'No',

					),

				),

		)

	);

	vc_add_param(

		'vc_row', array(

			'type'				=> 'dpr_responsive_css',

			'heading'			=> esc_html__('Resposive settings', 'dpr-adeline-extensions'),

			'param_name'		=> 'responsive_css_panel',

			'group'				=> esc_html__('DP Responsive Options', 'dpr-adeline-extensions'),

			'dependency' => array(

					'element' => 'dpr_enable_responsive_options', 

					'value' => array('yes')

			),

		)

	);



