<?php

/**



 * Header Options -> Mobile Menu



 *



 */

Redux::setSection($opt_name, array(

    'title'      => esc_html__('Mobile Menu', 'dpr-adeline-extensions'),

    'id'         => 'header_mobile_menu',

    'subsection' => true,

    'fields'     => array(

        array(

            'id'      => 'logo_mobile',

            'type'    => 'media',

            'title'   => __('Logo Mobile <i><small>(optional)</small></i>', 'dpr-adeline-extensions'),

            'default' => array(),

            'hint'    => array(

                'title'   => esc_attr__('Logo Mobile', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Select logo image for mobile devices. Is optional, if you leave it blank will be used default logo on mobile devices too.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'      => 'mobile_menu_switchpoint',

            'type'    => 'select',

            'title'   => esc_html__('Mobile Menu Switchpoint', 'dpr-adeline-extensions'),

            'desc'    => __('<i><small>Select the screen resolution (in px) below which you want to display the mobile menu.</small></i>', 'dpr-adeline-extensions'),

            'options' => array(

                '1280'   => esc_html__('Smaller than 1280px', 'dpr-adeline-extensions'),

                '1080'   => esc_html__('Smaller than 1080px ', 'dpr-adeline-extensions'),

                '959'    => esc_html__('Smaller than 959px', 'dpr-adeline-extensions'),

                '767'    => esc_html__('Smaller than 767px', 'dpr-adeline-extensions'),

                '480'    => esc_html__('Smaller than 480px', 'dpr-adeline-extensions'),

                '320'    => esc_html__('Smaller than 320px', 'dpr-adeline-extensions'),

                'custom' => esc_html__('Custom', 'dpr-adeline-extensions'),

            ),

            'default' => '959',

            'hint'    => array(

                'title'   => esc_attr__('Mobile Menu Switchpoint', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Select the screen resolution (in px) below which you want to display the mobile menu.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'mobile_menu_switchpoint_custom',

            'type'     => 'text',

            'title'    => esc_html__('Custom Mobile Menu Switchpoint (px)', 'dpr-adeline-extensions'),

            'default'  => '',

            'required' => array('mobile_menu_switchpoint', 'equals', 'custom'),

            'hint'     => array(

                'title'   => esc_attr__('Custom Mobile Menu Switchpoint (px)', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Select the screen resolution (in px) below which you want to display the mobile menu.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'      => 'mobile_menu_text_display',

            'type'    => 'switch',

            'default' => false,

            'title'   => esc_html__('Use Menu Texts', 'dpr-adeline-extensions'),

            'hint'    => array(

                'title'   => esc_attr__('Use Menu Text', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enable display texts next to the open and close icon ', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'mobile_menu_text',

            'type'     => 'text',

            'title'    => esc_html__('Menu Open Text', 'dpr-adeline-extensions'),

            'default'  => 'Menu',

            'required' => array('mobile_menu_text_display', 'equals', '1'),

            'hint'     => array(

                'title'   => esc_attr__('Menu Text', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Text displayed next to menu open icon', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'mobile_close_text',

            'type'     => 'text',

            'title'    => esc_html__('Menu Close Text', 'dpr-adeline-extensions'),

            'default'  => 'Close',

            'required' => array('mobile_menu_text_display', 'equals', '1'),

            'hint'     => array(

                'title'   => esc_attr__('Menu Close Text', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Text displayed next to menu close icon', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'      => 'mobile_menu_icon',

            'type'    => 'select',

            'title'   => esc_html__('Mobile Menu Icon', 'dpr-adeline-extensions'),

            'desc'    => __('<i>Select one of Tasty CSS-animated Hamburgers <a href="https://jonsuh.com/hamburgers" rel="nofollow" target="_blank">https://jonsuh.com/hamburgers</i>', 'dpr-adeline-extensions'),

            'options' => array(

                'default'     => esc_html__('Default Icon', 'dpr-adeline-extensions'),

                '3dx'         => esc_html__('3D X', 'dpr-adeline-extensions'),

                '3dx-r'       => esc_html__('3D X Reverse', 'dpr-adeline-extensions'),

                '3dy'         => esc_html__('3D Y', 'dpr-adeline-extensions'),

                '3dy-r'       => esc_html__('3D Y Reverse', 'dpr-adeline-extensions'),

                '3dxy'        => esc_html__('3D XY', 'dpr-adeline-extensions'),

                '3dxy-r'      => esc_html__('3D XY Reverse', 'dpr-adeline-extensions'),

                'arrow'       => esc_html__('Arrow', 'dpr-adeline-extensions'),

                'arrow-r'     => esc_html__('Arrow Reverse', 'dpr-adeline-extensions'),

                'arrowalt'    => esc_html__('Arrowalt', 'dpr-adeline-extensions'),

                'arrowalt-r'  => esc_html__('Arrowalt Reverse', 'dpr-adeline-extensions'),

                'arrowturn'   => esc_html__('Arrowturn', 'dpr-adeline-extensions'),

                'arrowturn-r' => esc_html__('Arrowturn Reverse', 'dpr-adeline-extensions'),

                'boring'      => esc_html__('Boring', 'dpr-adeline-extensions'),

                'collapse'    => esc_html__('Collapse', 'dpr-adeline-extensions'),

                'collapse-r'  => esc_html__('Collapse Reverse', 'dpr-adeline-extensions'),

                'elastic'     => esc_html__('Elastic', 'dpr-adeline-extensions'),

                'elastic-r'   => esc_html__('Elastic Reverse', 'dpr-adeline-extensions'),

                'minus'       => esc_html__('Minus', 'dpr-adeline-extensions'),

                'slider'      => esc_html__('Slider', 'dpr-adeline-extensions'),

                'slider-r'    => esc_html__('Slider Reverse', 'dpr-adeline-extensions'),

                'spin'        => esc_html__('Spin', 'dpr-adeline-extensions'),

                'spin-r'      => esc_html__('Spin Reverse', 'dpr-adeline-extensions'),

                'spring'      => esc_html__('Spring', 'dpr-adeline-extensions'),

                'spring-r'    => esc_html__('Spring Reverse', 'dpr-adeline-extensions'),

                'stand'       => esc_html__('Stand', 'dpr-adeline-extensions'),

                'stand-r'     => esc_html__('Stand Reverse', 'dpr-adeline-extensions'),

                'squeeze'     => esc_html__('Squeeze', 'dpr-adeline-extensions'),

                'vortex'      => esc_html__('Vortex', 'dpr-adeline-extensions'),

                'vortex-r'    => esc_html__('Vortex Reverse', 'dpr-adeline-extensions'),

            ),

            'default' => 'default',

            'hint'    => array(

                'title'   => esc_attr__('Mobile Menu Icon', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Select mobile menu icon. You can select default static icon or one of many animated hamburgers', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'mobile_menu_icon_color',

            'type'     => 'color',

            'output'   => array('background-color' => '.hamburger .hamburger-inner, .hamburger .hamburger-inner::before, .hamburger .hamburger-inner::after'),

            'validate' => 'color',

            'title'    => esc_html__('Hamburger Color', 'dpr-adeline-extensions'),

            'default'  => '#292933',

            'required' => array('mobile_menu_icon', 'not', 'default'),

            'hint'     => array(

                'title'   => esc_attr__('Hamburger Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set hamburger color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'mobile_menu_icon_color_hover',

            'type'     => 'color',

            'output'   => array('background-color' => '.hamburger:hover .hamburger-inner, .hamburger:hover .hamburger-inner::before, .hamburger:hover .hamburger-inner::after'),

            'validate' => 'color',

            'title'    => esc_html__('Hamburger Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'required' => array('mobile_menu_icon', 'not', 'default'),

            'hint'     => array(

                'title'   => esc_attr__('Hamburger Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set hamburger hover color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'      => 'mobile_menu_search',

            'type'    => 'switch',

            'default' => false,

            'title'   => esc_html__('Display Search Field', 'dpr-adeline-extensions'),

            'hint'    => array(

                'title'   => esc_attr__('Display Search Field', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enable or disable display of serch field in mobile menu', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'      => 'mobile_menu_style',

            'type'    => 'image_select',

            'title'   => __('Mobile Menu Style', 'dpr-adeline-extensions'),

            'options' => array(

                'sidebar'    => array(

                    'title' => esc_html__('Sidebar', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/mobile-menus/mobile-sidebar.png',

                ),

                'dropdown'   => array(

                    'title' => esc_html__('Dropdown', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/mobile-menus/mobile-dropdown.png',

                ),

                'fullscreen' => array(

                    'title' => esc_html__('Fullscreen', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/mobile-menus/mobile-fullscreen.png',

                ),

            ),

            'default' => 'sidebar',

            'hint'    => array(

                'title'   => esc_attr__('Mobile Menu Style', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Choose mobile menu style.', 'dpr-adeline-extensions'),

            ),

        ),

/** Sidebar style settings **/

        array(

            'id'       => 'sidebar_style_info',

            'type'     => 'info',

            'style'    => 'dpr-title',

            'title'    => wp_kses_post(__('<h3>Sidebar Menu Style Specific Settings</h3>', 'dpr-adeline-extensions')),

            'required' => array('mobile_menu_style', 'equals', array('sidebar')),

        ),

        array(

            'id'       => 'mobile_menu_slide_direction',

            'type'     => 'radio',

            'title'    => __('Menu Position', 'dpr-adeline-extensions'),

            'options'  => array(

                'left'  => 'Slide From Left',

                'right' => 'Slide From Right',

            ),

            'default'  => 'left',

            'required' => array('mobile_menu_style', 'equals', 'sidebar'),

            'hint'     => array(

                'title'   => esc_attr__('Menu Position', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set default menu position', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'mobile_menu_slide_effect',

            'type'     => 'radio',

            'title'    => __('Menu Slide Effect', 'dpr-adeline-extensions'),

            'options'  => array(

                'overlapp' => 'Overlapp Content',

                'shift'    => 'Shift Content',

            ),

            'default'  => 'overlapp',

            'required' => array('mobile_menu_style', 'equals', 'sidebar'),

            'hint'     => array(

                'title'   => esc_attr__('Menu Slide Effect', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set default menu slide effect', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'      => 'mobile_menu_sidebar_close_button',

            'type'    => 'switch',

            'default' => false,

            'title'   => esc_html__('Display Close Button', 'dpr-adeline-extensions'),

            'hint'    => array(

                'title'   => esc_attr__('Display Close Button', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enable or disable display of close button in mobile menu', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'mobile_menu_sidebar_bg',

            'type'     => 'color',

            'output'   => array('background-color' => '#sidr'),

            'validate' => 'color',

            'title'    => esc_html__('Menu Background Color', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'required' => array('mobile_menu_style', 'equals', 'sidebar'),

            'hint'     => array(

                'title'   => esc_attr__('Menu Background Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set sidebar mobile menu background color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'mobile_menu_sidebar_close_bg',

            'type'     => 'color',

            'output'   => array('background-color' => 'a.sidr-class-toggle-sidr-close'),

            'validate' => 'color',

            'title'    => esc_html__('Close Button Background Color', 'dpr-adeline-extensions'),

            'default'  => '#f1f2f4',

            'required' => array('mobile_menu_style', 'equals', 'sidebar'),

            'hint'     => array(

                'title'   => esc_attr__('Hamburger Icon Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set hamburger icon color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'mobile_menu_sidebar_separator_color',

            'type'     => 'color',

            'output'   => array('border-color' => '#sidr li, #sidr ul, #mobile-dropdown ul li, #mobile-dropdown ul li ul'),

            'validate' => 'color',

            'title'    => esc_html__('Menu Item Separators Color', 'dpr-adeline-extensions'),

            'default'  => '#f1f2f4',

            'required' => array('mobile_menu_style', 'equals', 'sidebar'),

            'hint'     => array(

                'title'   => esc_attr__('Menu Item Separators Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set menu items separators color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'mobile_menu_sidebar_link_color',

            'type'     => 'color',

            'output'   => array('color' => '.sidr a'),

            'validate' => 'color',

            'title'    => esc_html__('Menu Links Color', 'dpr-adeline-extensions'),

            'default'  => '#292933',

            'required' => array('mobile_menu_style', 'equals', 'sidebar'),

            'hint'     => array(

                'title'   => esc_attr__('Menu Links Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set menu items link color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'mobile_menu_sidebar_link_color_hover',

            'type'     => 'color',

            'output'   => array('color' => '.sidr a:hover,.sidr-class-dropdown-toggle:hover,.sidr-class-menu-item-has-children.active > a,.sidr-class-menu-item-has-children.active > a > .sidr-class-dropdown-toggle '),

            'validate' => 'color',

            'title'    => esc_html__('Menu Links Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'required' => array('mobile_menu_style', 'equals', 'sidebar'),

            'hint'     => array(

                'title'   => esc_attr__('Hamburger Icon Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set menu item link hover color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'mobile_menu_sidebar_link_bg_hover',

            'type'     => 'color',

            'output'   => array('background-color' => '.sidr a:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Menu Item Background Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '#e5e5e9',

            'required' => array('mobile_menu_style', 'equals', 'sidebar'),

            'hint'     => array(

                'title'   => esc_attr__('Menu Item Background Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set menu item hover background color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'mobile_menu_sidebar_search_bg_color',

            'type'     => 'color',

            'output'   => array('background-color' => 'form.sidr-class-mobile-searchform input'),

            'validate' => 'color',

            'title'    => esc_html__('Search Field Background Color', 'dpr-adeline-extensions'),

            'default'  => '#f1f2f4',

            'required' => array('mobile_menu_style', 'equals', 'sidebar'),

            'hint'     => array(

                'title'   => esc_attr__('Search Field Background Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set background color for search field.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'mobile_menu_sidebar_search_color',

            'type'     => 'color',

            'output'   => array('color' => 'form.sidr-class-mobile-searchform input, form.sidr-class-mobile-searchform input::placeholder'),

            'validate' => 'color',

            'title'    => esc_html__('Search Field Color', 'dpr-adeline-extensions'),

            'default'  => '#292933',

            'required' => array('mobile_menu_style', 'equals', 'sidebar'),

            'hint'     => array(

                'title'   => esc_attr__('Search Field Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set color for search input.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'mobile_menu_sidebar_search_border_color',

            'type'     => 'color',

            'output'   => array('border-color' => 'form.sidr-class-mobile-searchform input'),

            'validate' => 'color',

            'title'    => esc_html__('Search Input Border Color', 'dpr-adeline-extensions'),

            'default'  => '#e5e5e9',

            'required' => array('mobile_menu_style', 'equals', 'sidebar'),

            'hint'     => array(

                'title'   => esc_attr__('Search Input Border Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set border color for search inpute.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'mobile_menu_sidebar_search_border_color_active',

            'type'     => 'color',

            'output'   => array('border-color' => 'form.sidr-class-mobile-searchform input:hover, form.sidr-class-mobile-searchform input:focus, form.sidr-class-mobile-searchform input:active'),

            'validate' => 'color',

            'title'    => esc_html__('Search Input Border Color: Focus', 'dpr-adeline-extensions'),

            'default'  => '#c9c9ce',

            'required' => array('mobile_menu_style', 'equals', 'sidebar'),

            'hint'     => array(

                'title'   => esc_attr__('Search Input Border Color: Focus', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set border color for search focus and active', 'dpr-adeline-extensions'),

            ),

        ),

/** Dropdown style settings **/

        array(

            'id'       => 'dropdown_style__info',

            'type'     => 'info',

            'style'    => 'dpr-title',

            'title'    => wp_kses_post(__('<h3>Dropdown Menu Style Specific Settings</h3>', 'dpr-adeline-extensions')),

            'required' => array('mobile_menu_style', 'equals', 'dropdown'),

        ),

        array(

            'id'       => 'mobile_menu_dropdown_min_height',

            'type'     => 'dimensions',

            'title'    => esc_html__('Menu Maximum Height (px)', 'dpr-adeline-extensions'),

            'output'   => array('max-height' => '#mobile-dropdown'),

            'width'    => false,

            'height'   => true,

            'mode'     => array('width' => 'width', 'height' => 'max-height'),

            'units'    => array('px'),

            'default'  => array(

                'height' => '400px',

            ),

            'hint'     => array(

                'title'   => esc_attr__('Menu Maximum Height', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify the maximum heighth for the dropdown mobile menu.', 'dpr-adeline-extensions'),

            ),

            'required' => array('mobile_menu_style', 'equals', 'dropdown'),

        ),

        array(

            'id'       => 'mobile_menu_dropdown_bg',

            'type'     => 'color',

            'output'   => array('background-color' => '#mobile-dropdown'),

            'validate' => 'color',

            'title'    => esc_html__('Menu Background Color', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'required' => array('mobile_menu_style', 'equals', 'dropdown'),

            'hint'     => array(

                'title'   => esc_attr__('Menu Background Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set sidebar mobile menu background color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'mobile_menu_dropdown_separator_color',

            'type'     => 'color',

            'output'   => array('border-color' => '#mobile-dropdown ul li'),

            'validate' => 'color',

            'title'    => esc_html__('Menu Item Separators Color', 'dpr-adeline-extensions'),

            'default'  => '#f1f2f4',

            'required' => array('mobile_menu_style', 'equals', 'dropdown'),

            'hint'     => array(

                'title'   => esc_attr__('Menu Item Separators Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set menu items separators color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'mobile_menu_dropdown_link_color',

            'type'     => 'color',

            'output'   => array('color' => '#mobile-dropdown ul.dpr-mobile li a'),

            'validate' => 'color',

            'title'    => esc_html__('Menu Links Color', 'dpr-adeline-extensions'),

            'default'  => '#555',

            'required' => array('mobile_menu_style', 'equals', 'dropdown'),

            'hint'     => array(

                'title'   => esc_attr__('Menu Links Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set menu items link color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'mobile_menu_dropdown_link_color_hover',

            'type'     => 'color',

            'output'   => array('color' => '#mobile-dropdown ul.dpr-mobile li a:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Menu Links Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'required' => array('mobile_menu_style', 'equals', 'dropdown'),

            'hint'     => array(

                'title'   => esc_attr__('Menu Links Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set menu item link hover color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'mobile_menu_dropdown_link_bg_hover',

            'type'     => 'color',

            'output'   => array('background-color' => '#mobile-dropdown ul.dpr-mobile li a:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Menu Item Background Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '#e5e5e9',

            'required' => array('mobile_menu_style', 'equals', 'dropdown'),

            'hint'     => array(

                'title'   => esc_attr__('Menu Item Background Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set menu item hover background color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'mobile_menu_dropdown_search_bg_color',

            'type'     => 'color',

            'output'   => array('background-color' => '#mobile-dropdown form.mobile-searchform input'),

            'validate' => 'color',

            'title'    => esc_html__('Search Field Background Color', 'dpr-adeline-extensions'),

            'default'  => '#f1f2f4',

            'required' => array('mobile_menu_style', 'equals', 'dropdown'),

            'hint'     => array(

                'title'   => esc_attr__('Search Field Background Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set background color for search field.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'mobile_menu_dropdown_search_color',

            'type'     => 'color',

            'output'   => array('color' => '#mobile-dropdown form.mobile-searchform input, #mobile-dropdown form.mobile-searchform input::placeholder'),

            'validate' => 'color',

            'title'    => esc_html__('Search Field Color', 'dpr-adeline-extensions'),

            'default'  => '#292933',

            'required' => array('mobile_menu_style', 'equals', 'dropdown'),

            'hint'     => array(

                'title'   => esc_attr__('Search Field Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set color for search input.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'mobile_menu_dropdown_search_border_color',

            'type'     => 'color',

            'output'   => array('border-color' => '#mobile-dropdown form.mobile-searchform input'),

            'validate' => 'color',

            'title'    => esc_html__('Search Input Border Color', 'dpr-adeline-extensions'),

            'default'  => '#e5e5e9',

            'required' => array('mobile_menu_style', 'equals', 'dropdown'),

            'hint'     => array(

                'title'   => esc_attr__('Search Input Border Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set border color for search inpute.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'mobile_menu_dropdown_search_border_color_active',

            'type'     => 'color',

            'output'   => array('border-color' => '#mobile-dropdown form.mobile-searchform input:hover, #mobile-dropdown form.mobile-searchform input:focus, #mobile-dropdown form.mobile-searchform input:active'),

            'validate' => 'color',

            'title'    => esc_html__('Search Input Border Color: Focus', 'dpr-adeline-extensions'),

            'default'  => '#c9c9ce',

            'required' => array('mobile_menu_style', 'equals', 'dropdown'),

            'hint'     => array(

                'title'   => esc_attr__('Search Input Border Color: Focus', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set border color for search focus and active', 'dpr-adeline-extensions'),

            ),

        ),

/* Full screen styling */

        array(

            'id'       => 'fullscreen_style_info',

            'type'     => 'info',

            'style'    => 'dpr-title',

            'title'    => wp_kses_post(__('<h3>Fullscreen Menu Style Specific Settings</h3>', 'dpr-adeline-extensions')),

            'required' => array('mobile_menu_style', 'equals', array('fullscreen')),

        ),

        array(

            'id'       => 'mobile_menu_fullscreen_bg',

            'type'     => 'color',

            'output'   => array('background-color' => '#mobile-fullscreen'),

            'validate' => 'color',

            'title'    => esc_html__('Menu Background Color', 'dpr-adeline-extensions'),

            'default'  => 'rgba(0,0,0,0.9)',

            'required' => array('mobile_menu_style', 'equals', 'fullscreen'),

            'hint'     => array(

                'title'   => esc_attr__('Menu Background Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set fullscreen mobile menu background color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'mobile_menu_fullscreen_close_color',

            'type'     => 'color',

            'output'   => array('background-color' => '#mobile-fullscreen a.close .close-icon-inner,  #mobile-fullscreen a.close .close-icon-inner::after'),

            'validate' => 'color',

            'title'    => esc_html__('Menu Close Button Color', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'required' => array('mobile_menu_style', 'equals', 'fullscreen'),

            'hint'     => array(

                'title'   => esc_attr__('Menu Close Button Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set menu close button color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'mobile_menu_fullscreen_close_color_hover',

            'type'     => 'color',

            'output'   => array('background-color' => '#mobile-fullscreen a.close:hover .close-icon-inner,  #mobile-fullscreen a.close:hover .close-icon-inner::after'),

            'validate' => 'color',

            'title'    => esc_html__('Menu Close Button Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '#eeeeee',

            'required' => array('mobile_menu_style', 'equals', 'fullscreen'),

            'hint'     => array(

                'title'   => esc_attr__('Menu Close Button Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set menu close button hover color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'mobile_menu_fullscreen_link_color',

            'type'     => 'color',

            'output'   => array('color' => '#mobile-fullscreen ul.dpr-mobile li a'),

            'validate' => 'color',

            'title'    => esc_html__('Menu Links Color', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'required' => array('mobile_menu_style', 'equals', 'fullscreen'),

            'hint'     => array(

                'title'   => esc_attr__('Menu Links Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set menu items link color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'mobile_menu_fullscreen_link_color_hover',

            'type'     => 'color',

            'output'   => array('color' => '#mobile-fullscreen ul.dpr-mobile li a:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Menu Links Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '#cccccc',

            'required' => array('mobile_menu_style', 'equals', 'fullscreen'),

            'hint'     => array(

                'title'   => esc_attr__('Menu Links Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set menu item link hover color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'mobile_menu_fullscreen_search_color',

            'type'     => 'color',

            'output'   => array('color' => '#mobile-fullscreen #mobile-search input',

                'color'                     => '#mobile-fullscreen #mobile-search label',

                'background-color'          => '#mobile-fullscreen #mobile-search label i',

            ),

            'validate' => 'color',

            'title'    => esc_html__('Search Field Color', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'required' => array('mobile_menu_style', 'equals', 'fullscreen'),

            'hint'     => array(

                'title'   => esc_attr__('Search Field Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set color for search input.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'mobile_menu_fullscreen_search_border_color',

            'type'     => 'color',

            'output'   => array('border-color' => '#mobile-fullscreen #mobile-searchform input'),

            'validate' => 'color',

            'title'    => esc_html__('Search Input Underline Color', 'dpr-adeline-extensions'),

            'default'  => '#cccccc',

            'required' => array('mobile_menu_style', 'equals', 'fullscreen'),

            'hint'     => array(

                'title'   => esc_attr__('Search Input Underline Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set border color for search inpute.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'mobile_menu_fullscreen_search_border_color_active',

            'type'     => 'color',

            'output'   => array('border-color' => '#mobile-fullscreen #mobile-search input:hover, #mobile-fullscreen #mobile-search input:focus, #mobile-fullscreen #mobile-search input:active'),

            'validate' => 'color',

            'title'    => esc_html__('Search Input Underline Color: Focus', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'required' => array('mobile_menu_style', 'equals', 'fullscreen'),

            'hint'     => array(

                'title'   => esc_attr__('Search Input Underline Color: Focus', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set border color for search focus and active', 'dpr-adeline-extensions'),

            ),

        ),

    ),

));
