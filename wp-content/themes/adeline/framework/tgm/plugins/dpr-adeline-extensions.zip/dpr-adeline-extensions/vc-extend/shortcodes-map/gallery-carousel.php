<?php

// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}

/*

* Add-on Name: Gallery Carousel

*/



class WPBakeryShortCode_DPR_Gallery_Carousel extends WPBakeryShortCode {}

$gals = get_posts( 'post_type="dpr_gallery"&numberposts=-1' );



$galleries = array();

if ( $gals ) {

	foreach ( $gals as $gal ) {

		$galleries[ $gal->post_title ] = $gal->ID;

	}

} else {

	$galleries[ __( 'No galleries found', 'dpr-adeline-extensions' ) ] = 0;

}


vc_map(

	array(

		'name'					=> esc_html__('DP Gallery Carousel', 'dpr-adeline-extensions'),

		'base'					=> 'dpr_gallery_carousel',

		'class'					=> 'dpr_gallery_carousel',

		'icon'					=> 'icon-dpr-image-carousel',

  		"category" 				=>array( esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions')),

		'description' 			=> esc_html__('Display carousel from images in gallery post type post','dpr-adeline-extensions'),

		'params'				=> array(

			array(

				'heading'			=> esc_html__('Hover Animation Style', 'dpr-adeline-extensions'),

				'type'				=> 'dpr_image_select',

				'param_name'		=> 'hover_style',

				'options'			=> array(

					'opacity'	=> array(

						'label'	=> esc_html__('Opacity','dpr-adeline-extensions'),

						'src'		=> $module_images . 'carousel/img-gallery-style-1.png'

					),

					'grayscale'	=> array(

						'label'	=> esc_html__('Grayscale','dpr-adeline-extensions'),

						'src'		=> $module_images . 'carousel/img-gallery-style-2.png'

					),

					'grayscale_opacity'	=> array(

						'label'	=> esc_html__('Grayscale & Opacity','dpr-adeline-extensions'),

						'src'		=> $module_images . 'carousel/img-gallery-style-2.png'

					),

					'flip'	=> array(

						'label'	=> esc_html__('Flip','dpr-adeline-extensions'),

						'src'		=> $module_images . 'carousel/img-gallery-style-3.png'

					),

				),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set the active element in the center.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Center mode', 'dpr-adeline-extensions'),

				'param_name'		=> 'center_mode',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'dependency'		=> array('element' => 'slider_layout', 'value' => array('horizontal')),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('This option will adapt the carousel according to the content size. Option is available when you set one slide to show.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Adaptive height', 'dpr-adeline-extensions'),

				'param_name'		=> 'adaptive_height',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

			),

			array(

				'type'             => 'dpr_title',

				'text'             => '',

				'param_name'       => 'sep_1',

				'edit_field_class' => 'vc_column vc_col-sm-12',

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to enable or disable the dragging of the carousel\'s slides.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Draggable Slides', 'dpr-adeline-extensions'),

				'param_name'		=> 'draggable',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to enable or disable the carousel sliding by swiping on touch devices.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Touch Move', 'dpr-adeline-extensions'),

				'param_name'		=> 'touchable',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'dependency'		=> array('element' => 'draggable', 'value' => array('yes')),

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Additional Settings', 'dpr-adeline-extensions' ),

				'param_name'       => 'extra_features_title',

				'edit_field_class' => 'vc_column vc_col-sm-12',

			),

		   vc_map_add_css_animation( false ),

		    array(

				'type' => 'textfield',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Extra Class Name', 'dpr-adeline-extensions'),

				'param_name' => 'el_class',

			),

			array(

				'type'				=> 'param_group',

				'heading'			=> esc_html__('Image List', 'dpr-adeline-extensions'),

				'param_name'		=> 'image_list',

				'value'				=> '',

				'params'			=> array(

					array(

						'type'			=> 'attach_image',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Upload the custom image from media library.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Upload Image', 'dpr-adeline-extensions'),

						'param_name'	=> 'image_id',

					),

					array(

						'type'			=> 'textfield',

						'heading' 		=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to add some information for the image. This option is available only for the Flip style.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Description', 'dpr-adeline-extensions'),

						'param_name'	=> 'description',

						'dependency'	=> array('element' => 'hover_style', 'value' => array('flip'))

					), 

					array(

						'type'			=> 'dpr_switcher',

						'heading' 		=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to add the link to your image.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Link', 'dpr-adeline-extensions'),

						'param_name'	=> 'use_link',

						'options'		=> array(

							'yes'				=> array(

								'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

								'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

						),

						'edit_field_class'	=> 'vc_column vc_col-sm-6',

					),

					array(

						'type'			=> 'vc_link',

						'heading' 		=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Add a custom link or select existing page.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Add link', 'dpr-adeline-extensions'),

						'param_name'	=> 'link',

						'edit_field_class'	=> 'vc_col-sm-6 vc_column',

						'dependency'	=> array('element' => 'use_link', 'value' => 'yes'),

					),

					array(

						'type'             => 'dpr_title',

						'text'             => '',

						'param_name'       => 'images_sep_1',

						'edit_field_class' => 'vc_column vc_col-sm-12',

						'group' => esc_attr__('Slideshow', 'dpr-adeline-extensions'),

					),

					array(

						'type'			=> 'dpr_switcher',

						'heading' 		=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to add custom back background for this image. It is used only by Flip Style.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Use custom back bacground?', 'dpr-adeline-extensions'),

						'param_name'	=> 'custom_back_bg',

						'options'		=> array(

							'yes'				=> array(

								'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

								'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

						),

						'edit_field_class'	=> 'vc_column vc_col-sm-6',

					),

					array(

						'type'				=> 'colorpicker',

						'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the color for the mask background. The default mask color is inherited from Theme Options > Styling Options > Main Accent Color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Back Side Background', 'dpr-adeline-extensions'),

						'param_name'		=> 'custom_back_bg_color',

						'edit_field_class'	=> 'vc_column vc_col-sm-6',

						'dependency'		=> array('element' => 'custom_back_bg', 'value' => array('yes')),

						'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Images', 'dpr-adeline-extensions'),

			),
			array(

				'type' => 'dropdown',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose gaalery from previous created galleries.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Select Gallery', 'dpr-adeline-extensions'),

				'param_name' => 'gallery_id',

				'value' => $galleries,

				'save_always' => true,

				'group'				=> esc_html__('Images', 'dpr-adeline-extensions'),

				),
			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Slider Settings', 'dpr-adeline-extensions' ),

				'param_name'       => 'slideshow_title_1',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group' => esc_attr__('Slideshow', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'number',

				'class' => '',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set the number of slides you would like to display.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Slides to show at once', 'dpr-adeline-extensions'),

				'param_name' => 'slides_to_show',

				'value' => '1',

				'min' => '1',

				'max' => '16',

				'step' => '1',

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'group' => esc_html__('Slideshow', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set the number of slides to scroll', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Number of slides to scroll', 'dpr-adeline-extensions'),

				'param_name'		=> 'slides_to_scroll',

				'value'				=> 1,

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Slideshow', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'number',

				'class' => '',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set the speed for the slideshow.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Slideshow speed', 'dpr-adeline-extensions'),

				'param_name' => 'speed',

				'suffix' => 'ms',

				'value' => '300',

				'min' => '100',

				'max' => '10000',

				'step' => '100',

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'group' => esc_html__('Slideshow', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'number',

				'class' => '',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to add the space between the carousel items.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Items offset', 'dpr-adeline-extensions'),

				'param_name' => 'items_offset',

				'value' => '20',

				'min' => '0',

				'max' => '100',

				'step' => '1',

				'edit_field_class' => 'vc_column vc_col-sm-4',

				'group' => esc_html__('Slideshow', 'dpr-adeline-extensions'),

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Auto Play Settings', 'dpr-adeline-extensions' ),

				'param_name'       => 'slideshow_title_2',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group' => esc_attr__('Slideshow', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to enable or disable the autoplay for the carousel.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Autoplay', 'dpr-adeline-extensions'),

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'param_name'		=> 'autoplay',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Slideshow', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'number',

				'class' => '',

				'heading'	=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the speed for the autoplay.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Autoplay Speed', 'dpr-adeline-extensions'),

				'param_name' => 'autoplay_speed',

				'value' => '5000',

				'min' => '100',

				'suffix' => 'ms',

				'max' => '10000',

				'step' => '10',

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'dependency' => array('element' => 'autoplay', 'value' => array('yes')),

				'group' => esc_html__('Slideshow', 'dpr-adeline-extensions'),

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Medium Desktop', 'dpr-adeline-extensions' ),

				'param_name'       => 'responsive_title_1',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group' => esc_attr__('Slideshow', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'number',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set the screen resolution for the medium desktops.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Screen resolution', 'dpr-adeline-extensions'),

				'param_name' => 'screen_desktop_resolution',

				'value' => 1024,

				'group' => esc_attr__('Slideshow', 'dpr-adeline-extensions'),

				'edit_field_class' => 'vc_column vc_col-sm-6'

			),

			array(

				'type' => 'number',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set the number of slides to show for the medium desktops.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Number of slides', 'dpr-adeline-extensions'),

				'value' => '1',

				'param_name' => 'screen_desktop_slides',

				'group' => esc_attr__('Slideshow', 'dpr-adeline-extensions'),

				'edit_field_class' => 'vc_column vc_col-sm-6'

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Tablets', 'dpr-adeline-extensions' ),

				'param_name'       => 'responsive_title_2',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group' => esc_attr__('Slideshow', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'number',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set the screen resolution for the tablets.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Screen resolution', 'dpr-adeline-extensions'),

				'param_name' => 'screen_tablet_resolution',

				'value' => 800,

				'group' => esc_attr__('Slideshow', 'dpr-adeline-extensions'),

				'edit_field_class' => 'vc_column vc_col-sm-6'

			),

			array(

				'type' => 'number',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set the number of slides to show for the tablets.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Number of slides', 'dpr-adeline-extensions'),

				'value' => '1',

				'param_name' => 'screen_tablet_slides',

				'group' => esc_attr__('Slideshow', 'dpr-adeline-extensions'),

				'edit_field_class' => 'vc_column vc_col-sm-6'

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Mobile Devices', 'dpr-adeline-extensions' ),

				'param_name'       => 'responsive_title_3',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group' => esc_attr__('Slideshow', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'number',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set the screen resolution for the mobile phones.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Screen resolution', 'dpr-adeline-extensions'),

				'param_name' => 'screen_mobile_resolution',

				'value' => 480,

				'group' => esc_attr__('Slideshow', 'dpr-adeline-extensions'),

				'edit_field_class' => 'vc_column vc_col-sm-6 no-border-bottom'

			),

			array(

				'type' => 'number',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set the number of slides to show for the mobile phones.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Number of slides', 'dpr-adeline-extensions'),

				'value' => '1',

				'param_name' => 'screen_mobile_slides',

				'group' => esc_attr__('Slideshow', 'dpr-adeline-extensions'),

				'edit_field_class' => 'vc_column vc_col-sm-6'

			),

			array(

				'type' => 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set the border radius for the image. The border radius is not set by default', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border radius', 'dpr-adeline-extensions'),

				'param_name' => 'thumb_radius',

				'suffix' => 'px',

				'min' => 0,

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group' => esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the color for the mask background. The default mask color is inherited from Theme Options > Styling Options > Main Accent Color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Back Side Background', 'dpr-adeline-extensions'),

				'param_name'		=> 'back_side_bg',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'dependency'		=> array('element' => 'hover_style', 'value' => array('flip')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set the image\'s opacity for the idle state. The default opacity is 50%', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Opacity', 'dpr-adeline-extensions'),

				'param_name'		=> 'opacity_idle',

				'suffix' 			=> '%',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'dependency'		=> array('element' => 'hover_style', 'value' => array('opacity')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set the image\'s opacity for the hover state. The default opacity is no', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Opacity: Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'opacity_hover',

				'suffix' 			=> '%',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'dependency'		=> array('element' => 'hover_style', 'value' => array('opacity')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Caption Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_typography_head',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'hover_style', 'value' => array('flip')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

				

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the color for the descrption. The default mask color is #fff.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-3',

				'dependency'		=> array('element' => 'hover_style', 'value' => array('flip')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size. If you leave this field blank will be used default size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'hover_style', 'value' => array('flip')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title linne height.Default is 18px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'hover_style', 'value' => array('flip')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'hover_style', 'value' => array('flip')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'title_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'dependency'		=> array('element' => 'hover_style', 'value' => array('flip')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

	  		),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font. .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_google_fonts',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'dependency'		=> array('element' => 'hover_style', 'value' => array('flip')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'title_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'dependency'		=> array('element' => 'use_google_fonts', 'value' => 'yes'),

			),




			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Description Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_typography_head_1',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'hover_style', 'value' => array('flip')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

				

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the color for the descrption. The default mask color is #fff.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'content_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-3',

				'dependency'		=> array('element' => 'hover_style', 'value' => array('flip')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size. If you leave this field blank will be used default size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'content_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'hover_style', 'value' => array('flip')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom description line height.Default is 18px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'content_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'hover_style', 'value' => array('flip')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom description letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'content_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'hover_style', 'value' => array('flip')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'content_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'dependency'		=> array('element' => 'hover_style', 'value' => array('flip')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

	  		),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font. .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_google_fonts_content',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'dependency'		=> array('element' => 'hover_style', 'value' => array('flip')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'content_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'dependency'		=> array('element' => 'use_google_fonts_content', 'value' => 'yes'),

			),


			

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to add the pagination dots for your carousel.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Pagination Dots', 'dpr-adeline-extensions'),

				'param_name'		=> 'dots',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Pagination', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to choose the horizontal alignment for pagination.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Pagination Alignment', 'dpr-adeline-extensions'),

				'param_name'		=> 'pagination_alignment',

				'value'				=> 'pagination-center',

				'options'			=> array(

					esc_html__('Left', 'dpr-adeline-extensions')	=> 'pagination-left',

					esc_html__('Center', 'dpr-adeline-extensions')	=> 'pagination-center',

					esc_html__('Right', 'dpr-adeline-extensions')	=> 'pagination-right'

				),

				'dependency' => array('element' => 'dots', 'value' => array('yes')),

				'group'				=> esc_html__('Pagination', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'dpr_image_select',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Select style for pagination dots', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Dots Style', 'dpr-adeline-extensions'),

				'param_name' => 'dots_style',

				'weight' => '1',

				'value' => 'outline-round',

				'options'			=> array(

					'outline-square'			=> array(

						'label'			=> esc_html__('Square','dpr-adeline-extension'),

						'src'				=> $module_images . 'dots/square.png'

					),

					'outline-round'			=> array(

						'label'			=> esc_html__('Radio','dpr-adeline-extension'),

						'src'				=> $module_images . 'dots/radio.png'

					),

					'flat-round'			=> array(

						'label'			=> esc_html__('Point','dpr-adeline-extension'),

						'src'				=> $module_images . 'dots/points.png'

					),

					'flat-square'			=> array(

						'label'			=> esc_html__('Fill Square','dpr-adeline-extension'),

						'src'				=> $module_images . 'dots/filled-square.png'

					),

					'flat-rounded'			=> array(

						'label'			=> esc_html__('Fill Rounded','dpr-adeline-extension'),

						'src'				=> $module_images . 'dots/filled-rounded.png'

					),

					'outline-bar'			=> array(

						'label'			=> esc_html__('Bar','dpr-adeline-extension'),

						'src'				=> $module_images . 'dots/bars.png'

					),

					'flat-bar'			=> array(

						'label'			=> esc_html__('Fill Bar','dpr-adeline-extension'),

						'src'				=> $module_images . 'dots/filed-bars.png'

					)

				),

				'dependency' => array('element' => 'dots', 'value' => array('yes')),

				'group'				=> esc_html__('Pagination', 'dpr-adeline-extensions'),

			),

				array(

				'type' => 'colorpicker',

				'class' => '',

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Choose color for the active dot. The default color is inherited from Theme Options > Styling Options > Main Accent Color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Active dot color', 'dpr-adeline-extensions'),

				'param_name' => 'dots_color',

				'value' => '',

				'dependency' => array('element' => 'dots', 'value' => array('yes')),

				'group'				=> esc_html__('Pagination', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'colorpicker',

				'class' => '',

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Choose color for the inactive dot.','dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('InActive dot color', 'dpr-adeline-extensions'),

				'param_name' => 'dots_color_inactive',

				'value' => '',

				'dependency' => array('element' => 'dots', 'value' => array('yes')),

				'group'				=> esc_html__('Pagination', 'dpr-adeline-extensions'),

			),

			array (

				'type' => 'number',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set the space between dots. Default is 14px.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Dots Spacing', 'dpr-adeline-extensions'),

				'param_name' => 'dots_spacing',

				'suffix' => 'px',

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'dependency' => array('element' => 'dots', 'value' => array('yes')),

				'group'				=> esc_html__('Pagination', 'dpr-adeline-extensions'),

			),

			array (

				'type' => 'number',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set the top margin for dots. Default is 15px.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Dots Top Margin', 'dpr-adeline-extensions'),

				'param_name' => 'dots_top_margin',

				'suffix' => 'px',

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'dependency' => array('element' => 'dots', 'value' => array('yes')),

				'group'				=> esc_html__('Pagination', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to enable or disable the carousel navigation arrows.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Navigation Arrows?', 'dpr-adeline-extensions'),

				'param_name'		=> 'arrows',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Navigation', 'dpr-adeline-extensions'),

			),

			array(

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to choose the navigation arrows position.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Arrows position', 'dpr-adeline-extensions'),

				'type'				=> 'dpr_image_select',

				'param_name'		=> 'arrows_position',

				'value' => 'aside-outside',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'options'			=> array(

					'aside'	=> array(

						'label'	=> esc_html__('Aside','dpr-adeline-extensions'),

						'src'		=> $module_images . 'carousel/arrows-aside.png'

					),

					'aside-outside'	=> array(

						'label'	=> esc_html__('Outside','dpr-adeline-extensions'),

						'src'		=> $module_images . 'carousel/arrows-aside-outside.png'

					),

					'top-center'	=> array(

						'label'	=> esc_html__('Top','dpr-adeline-extensions'),

						'src'		=> $module_images . 'carousel/arrows-top.png'

					),

					'bottom-center'	=> array(

						'label'	=> esc_html__('Bottom','dpr-adeline-extensions'),

						'src'		=> $module_images . 'carousel/arrows-bottom.png'

					),

				),

				'group'				=> esc_html__('Navigation', 'dpr-adeline-extensions'),

				'dependency' => array('element' => 'arrows', 'value' => array('yes')),

			),

			array (

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the arrow style.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Arrow Type', 'dpr-adeline-extensions'),

				'type'				=> 'dpr_image_select',

				'param_name' => 'arrow_icon',

				'value'=>'arrow_type-1',

				'options'			=> array(

					'arrow-type-1'	=> array(

						'label'	=> esc_html__('Type 1','dpr-adeline-extensions'),

						'src'		=> $module_images . 'carousel/arrows-01.png'

					),

					'arrow-type-2'	=> array(

						'label'	=> esc_html__('Type 2','dpr-adeline-extensions'),

						'src'		=> $module_images . 'carousel/arrows-02.png'

					),

					'arrow-type-3'	=> array(

						'label'	=> esc_html__('Type 3','dpr-adeline-extensions'),

						'src'		=> $module_images . 'carousel/arrows-03.png'

					),

					'arrow-type-4'	=> array(

						'label'	=> esc_html__('Type 4','dpr-adeline-extensions'),

						'src'		=> $module_images . 'carousel/arrows-04.png'

					),

					'arrow-type-5'	=> array(

						'label'	=> esc_html__('Type 5','dpr-adeline-extensions'),

						'src'		=> $module_images . 'carousel/arrows-05.png'

					),

					'arrow-type-6'	=> array(

						'label'	=> esc_html__('Type 6','dpr-adeline-extensions'),

						'src'		=> $module_images . 'carousel/arrows-06.png'

					),

				),

				'dependency' => array('element' => 'arrows', 'value' => array('yes')),

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group' => esc_html__('Navigation', 'dpr-adeline-extensions'),

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Arrow Icon Style', 'dpr-adeline-extensions' ),

				'param_name'       => 'arrows_title_1',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group' => esc_attr__('Navigation', 'dpr-adeline-extensions'),

				'dependency' => array('element' => 'arrows', 'value' => array('yes')),

			),

			array (

				'type' => 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose icon color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Arrow Color', 'dpr-adeline-extensions'),

				'param_name' => 'arrow_icon_color',

				'edit_field_class' => 'vc_column vc_col-sm-4 ',

				'dependency' => array('element' => 'arrows', 'value' => array('yes')),

				'group' => esc_html__('Navigation', 'dpr-adeline-extensions'),

			),

			array (

				'type' => 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('CChoose icon hover color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Arrow Color: Hover', 'dpr-adeline-extensions'),

				'param_name' => 'arrow_icon_color_hover',

				'edit_field_class' => 'vc_column vc_col-sm-4',

				'dependency' => array('element' => 'arrows', 'value' => array('yes')),

				'group' => esc_html__('Navigation', 'dpr-adeline-extensions'),

			),

			array (

				'type' => 'number',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set the size of the icon. Default is 10px.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Arrow Icon Size', 'dpr-adeline-extensions'),

				'param_name' => 'arrow_icon_size',

				'suffix' => 'px',

				'edit_field_class' => 'vc_column vc_col-sm-4',

				'dependency' => array('element' => 'arrows', 'value' => array('yes')),

				'group' => esc_html__('Navigation', 'dpr-adeline-extensions'),

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Arrow Background Style', 'dpr-adeline-extensions' ),

				'param_name'       => 'arrows_title_2',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group' => esc_attr__('Navigation', 'dpr-adeline-extensions'),

				'dependency' => array('element' => 'arrows', 'value' => array('yes')),

			),

			array (

				'type' => 'number',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set border radius for the icon\'s background.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background border radius', 'dpr-adeline-extensions'),

				'param_name' => 'arrow_bg_border_radius',

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'group' => esc_attr__('Navigation', 'dpr-adeline-extensions'),

				'dependency' => array('element' => 'arrows', 'value' => array('yes')),

			),

			array (

				'type' => 'number',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set border width for the icon\'s background.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background border width', 'dpr-adeline-extensions'),

				'param_name' => 'arrow_bg_border_width',

				'suffix' => 'px',

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'group' => esc_attr__('Navigation', 'dpr-adeline-extensions'),

				'dependency' => array('element' => 'arrows', 'value' => array('yes')),

			),

			array (

				'type' => 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set the icon\'s background color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background color', 'dpr-adeline-extensions'),

				'param_name' => 'arrow_bg_color',

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'group' => esc_attr__('Navigation', 'dpr-adeline-extensions'),

				'dependency' => array('element' => 'arrows', 'value' => array('yes')),

			),

			array (

				'type' => 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set the icon\'s hover background color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background color: Hover', 'dpr-adeline-extensions'),

				'param_name' => 'arrow_bg_color_hover',

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'group' => esc_attr__('Navigation', 'dpr-adeline-extensions'),

				'dependency' => array('element' => 'arrows', 'value' => array('yes')),

			),

			array (

				'type' => 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the border color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border color', 'dpr-adeline-extensions'),

				'param_name' => 'arrow_bg_border_color',

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'group' => esc_attr__('Navigation', 'dpr-adeline-extensions'),

				'dependency' => array('element' => 'arrows', 'value' => array('yes')),

			),

			array (

				'type' => 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the hover border color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border color: Hover', 'dpr-adeline-extensions'),

				'param_name' => 'arrow_bg_border_color_hover',

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'group' => esc_attr__('Navigation', 'dpr-adeline-extensions'),

				'dependency' => array('element' => 'arrows', 'value' => array('yes')),

			),

			array(

				'type' => 'dpr_switcher',

				'param_name' => 'arrow_use_shadow_on_hover',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to show the shadow for the arrow.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Shadow on hover', 'dpr-adeline-extensions'),

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group' => esc_attr__('Navigation', 'dpr-adeline-extensions'),

				'dependency' => array('element' => 'arrows', 'value' => array('yes')),

			),

			array(

				"type" => "dpr_shadow_picker",

				"class" => "",

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set hover shadow for aroow.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Shadow', 'dpr-adeline-extensions'),

				"param_name" => "arrow_hover_shadow",

				"value" => "||||||",

				'dependency'		=> array('element' => 'arrow_use_shadow_on_hover', 'value' => array('yes')),

				'group'				=> esc_html__('Navigation', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'dpr_switcher',

				'param_name' => 'arrow_allways_visible',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Make arrows allways visible?', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Arrows allways visible?', 'dpr-adeline-extensions'),

				'edit_field_class' => 'vc_column vc_col-sm-4',

				'value' => 'yes',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group' => esc_attr__('Navigation', 'dpr-adeline-extensions'),

				'dependency' => array('element' => 'arrows', 'value' => array('yes')),

			),

			array(

				'type' => 'dpr_switcher',

				'param_name' => 'arrow_use_numbers',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Use navigation numbers above the arrows?', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Use Navigation Numbers?', 'dpr-adeline-extensions'),

				'edit_field_class' => 'vc_column vc_col-sm-4',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group' => esc_attr__('Navigation', 'dpr-adeline-extensions'),

				'dependency' => array('element' => 'arrows', 'value' => array('yes')),

			),

			array (

				'type' => 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the color for the numbers. The default color is #292933.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Numbers color', 'dpr-adeline-extensions'),

				'param_name' => 'arrow_numbers_color',

				'edit_field_class' => 'vc_column vc_col-sm-4',

				'dependency' => array(

					'element' => 'arrow_use_numbers',

					'value' => 'yes',

				),

				'group' => esc_html__('Navigation', 'dpr-adeline-extensions'),

			),



		),

	)

);