<?php



/**



 * Woocommerce Options



 * 



 */







    Redux::setSection( $opt_name, array(



        'title'  => __( 'Woocommerce', 'dpr-adeline-extensions' ),



        'id'     => 'woocommerce_tab',



        'icon'   => 'el el-shopping-cart'



    ) );



	require_once($options_dir . '/woocommerce-options/general-settings.php');



	require_once($options_dir . '/woocommerce-options/layout.php');



	require_once($options_dir . '/woocommerce-options/menu-cart.php');



	require_once($options_dir . '/woocommerce-options/products.php');



	require_once($options_dir . '/woocommerce-options/product.php');



	require_once($options_dir . '/woocommerce-options/cart_checkout.php');



	require_once($options_dir . '/woocommerce-options/product-sharing.php');



	require_once($options_dir . '/woocommerce-options/styling.php');







