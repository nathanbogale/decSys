<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
/*
Heading style
*/
$output .= $subtitle_html;
$output .= $headline_html;
$output .= $separator_html;