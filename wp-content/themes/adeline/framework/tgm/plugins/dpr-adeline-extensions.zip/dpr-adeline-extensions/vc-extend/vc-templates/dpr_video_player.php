<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$output = $unique_id = $type = $css_animation = $el_class = $custom_el_css = '';
$video_type = $thumb_image = $aspect_ratio = $video_link = $title = $subtitle = '';
$video_container_border_radius = $container_shadow = $container_shadow_hover = '';
$alignment = $force_fullwidth_button = $icon_color = $icon_color_hover = $icon_bg_color = $icon_bg_color_hover = $icon_border_color = $icon_border_color_hover = $icon_border_size = $button_size = $icon_size = $pulse_animation = $pulse_color = '';
$outline_bg = $outline_bg_hover = $outline_border = $outline_border_hover = $outline_border_width = $outline_padding = '';
$title_color = $title_font_size = $title_line_height  = $title_letter_spacing = $titlee_font_style = $title_google_font = $title_typo_style = '';
$subtitle_color = $subtitle_font_size = $subtitle_line_height  = $subtitle_letter_spacing = $subtitle_font_style = $subtitle_google_font = $subtitle_typo_style = '';
$title_html = $subtitle_html = $button_html = $button_minimal_html = $inline_player_html = $thumb_html = $video_html = '';

$atts = vc_map_get_attributes( 'dpr_video_player', $atts );
extract( $atts );

wp_enqueue_script('dpr-video-player', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/jquery.videoplayer.js', array('jquery'), null, true);	

$unique_id = uniqid('dpr-video-player-').'-'.rand(1,9999);
$unique_video = uniqid('video-').'-'.rand(1,9999);

if ( '' !== $css_animation && 'none' !== $css_animation ) {
	dpr_enqueue_waypoint_js();
	dpr_enqueue_animate_css();
	$el_class .= ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
}

$el_class .= ' '.$type;

// Alignment class

if (!empty($alignment)) {
	$el_class .= ' '.$alignment;
}

if(isset($thumb_image) && !empty($thumb_image)) {
	$el_class .= ' with-thumb';
}

if(isset($force_fullwidth_button) && $force_fullwidth_button == 'yes') {
	$el_class .= ' full-width';
}
if(isset($pulse_animation) && $pulse_animation != '') {
	$el_class .= ' '.$pulse_animation;
}


// Title HTML
if (!empty($title)) {
	$title_typo_style = dpr_generate_typography_style($title_color, $title_font_size, $title_line_height, $title_letter_spacing, $title_font_style,$title_google_font);
	$title_html .= '<h4 class="dpr-video-title" ' . $title_typo_style . '>' . esc_html($title) . '</h4>';
}

// Subtitle HTML
if (!empty($subtitle)) {
	$subtitle_typo_style = dpr_generate_typography_style($subtitle_color, $subtitle_font_size, $subtitle_line_height, $subtitle_letter_spacing, $subtitle_font_style,$subtitle_google_font);
	$subtitle_html .= '<div class="dpr-video-subtitle" ' . $subtitle_typo_style . '>' . esc_html($subtitle) . '</div>';
}

// Button HTML

$button_html .= '<div class="button-wrap">';
	$button_html .= '<div class="button-wrap-inner" >';
		$button_html .= '<div class="dpr-video-button" >';
			$button_html .= '<i class="dpr-icon-caret-right"><span class="icon-inner-wrap"></span></i>';
		$button_html .= '</div>';
		if($title || $subtitle) {
			$button_html .= '<div class="title-wrap">';
				$button_html .= $title_html;
				$button_html .= $subtitle_html;
			$button_html .= '</div>';
		}
	$button_html .= '</div>';
	
	$button_html .= '<a href="'.esc_url(dpr_convert_url_to_lightbox_url($video_link)).'" data-rel="lightcase" class="dpr-video-link"></a>';
$button_html .= '</div>';

// Button minimal HTML

$button_minimal_html .= '<div class="button-wrap">';
$button_minimal_html .= '<div class="dpr-video-button" >';
$button_minimal_html .= '<i class="dpr-icon-caret-right"><span class="icon-inner-wrap"></span>';
if($pulse_animation !='') {
$button_minimal_html .= '<span class="icon-pulse-wrap"></span>';
}
$button_minimal_html .= '</i>';
$button_minimal_html .= '</div>';
	
	$button_minimal_html .= '<a href="'.esc_url(dpr_convert_url_to_lightbox_url($video_link)).'" data-rel="lightcase" class="dpr-video-link"></a>';
$button_minimal_html .= '</div>';

// Inline Player
	$fitvid_padding = '75%';
	if (isset($aspect_ratio) && !empty($aspect_ratio)) {
		$fitvid_padding = $aspect_ratio;
	}
	if(isset($thumb_image) && !empty($thumb_image)) {
		$thumb_image_url = dpr_get_attachment_image_src($thumb_image, 'full');
		$alt_text = get_post_meta($thumb_image , '_wp_attachment_image_alt', true);
		$image_src = $thumb_image_url[0];
		$extra_class = 'is-html5';
		if ( strpos( $video_link, 'youtube' ) ) {
				$extra_class =  'is-youtube';
		}
		if ( strpos( $video_link, 'vimeo' ) ) {
				$extra_class =  'is-vimeo';
		}

			$img_html = '<img src="'.esc_url($image_src).'" alt ="'.esc_attr($alt_text).'"/>';
			$thumb_html .= '<a href="#'.esc_js($unique_id).'" class="dpr-video-cover '.esc_attr($extra_class).'" title="'.esc_html__('Play video','dpr-adeline-extensions').'">';
				$thumb_html .= '<span class="button-play">';
					$thumb_html .= '<span class="icon-inner-wrap"></span>';
					$thumb_html .= '<i class="dpr-icon-caret-right"></i>';
				$thumb_html .= '</span>';
				$thumb_html .= $img_html;
			$thumb_html .= '</a>';
		
	}

	$inline_player_html .= '<div class="dpr-video-box">';
		$inline_player_html .= $thumb_html;
		$inline_player_html .= '<div class="dpr_video_wrapper">';
				
				if ( strpos( $video_link, 'youtube' ) ) {
				$video_html .= '<div class="fluid-width-video-wrapperper" style="padding-top: '.$fitvid_padding.';">';
				$video_html .= '<iframe src="'.esc_url(dpr_convert_url_to_lightbox_url($video_link)).'?enablejsapi=1" frameborder="0" allowfullscreen  id="'.$unique_video.'"></iframe>';
				$video_html .= '</div>';
				} elseif ( strpos( $video_link, 'vimeo' ) ){
				$video_html .= '<div class="fluid-width-video-wrapperper" style="padding-top: '.$fitvid_padding.';">';
				$video_html .= '<iframe src="'.esc_url(dpr_convert_url_to_lightbox_url($video_link)).'?api=1" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen id="'.$unique_video.'"></iframe>';
				$video_html .= '</div>';
				}
				else {
				$video_html = apply_filters( 'the_content', $video_link );
				}
	
				// Add responsive video wrap for youtube/vimeo embeds
				if ( strpos( $video_link, 'youtube' ) || strpos( $video_link, 'vimeo' ) ) {
					
					$inline_player_html .=  '<div class="responsive-video-wrapper">'. $video_html .'</div>';
				}
	
				// Else return without responsive wrap
				else {
					$inline_player_html .=  $video_html;
				}
	$inline_player_html .= '</div>';
	$inline_player_html .= '</div>';



// Custom CSS stuff
if(isset($icon_color) && !empty($icon_color)) {
	$custom_el_css .= '.'.esc_js($unique_id) .' .dpr-video-button i {color:'.$icon_color.';}';
	$custom_el_css .= '.'.esc_js($unique_id) .'.inline .dpr-video-cover i {color:'.$icon_color.';}';
}
if(isset($icon_color_hover) && !empty($icon_color_hover)) {
	$custom_el_css .= '.'.esc_js($unique_id) .' .button-wrap:hover .dpr-video-button i {color:'.$icon_color_hover.';}';
	$custom_el_css .= '.'.esc_js($unique_id) .'.inline:hover .dpr-video-cover i {color:'.$icon_color_hover.';}';
}
if(isset($icon_bg_color) && !empty($icon_bg_color)) {
	$custom_el_css .= '.'.esc_js($unique_id) .' .icon-inner-wrap{background-color:'.$icon_bg_color.';}';
}
if(isset($icon_bg_color_hover) && !empty($icon_bg_color_hover)) {
	$custom_el_css .= '.'.esc_js($unique_id) .'.popup .button-wrap:hover .icon-inner-wrap{background-color:'.$icon_bg_color_hover.';}';
	$custom_el_css .= '.'.esc_js($unique_id) .'.inline:hover .icon-inner-wrap {background-color:'.$icon_bg_color_hover.';}';
	$custom_el_css .= '.'.esc_js($unique_id) .'.popup-minimal .button-wrap:hover .icon-inner-wrap {background-color:'.$icon_bg_color_hover.';}';
}
if(isset($outline_bg) && !empty($outline_bg)) {
	$custom_el_css .= '.'.esc_js($unique_id) .' .button-wrap-inner {background-color:'.$outline_bg.';}';
}
if(isset($outline_bg_hover) && !empty($outline_bg_hover)) {
	$custom_el_css .= '.'.esc_js($unique_id) .':hover .button-wrap-inner {background-color:'.$outline_bg_hover.';}';
}

if(isset($icon_border_color) && !empty($icon_border_color)) {
	$custom_el_css .= '.'.esc_js($unique_id) .'.inline .icon-inner-wrap {border-color:'.$icon_border_color.';}';
	$custom_el_css .= '#'.esc_js($unique_id) .'.popup-minimal .icon-inner-wrap {border-color:'.$icon_border_color.';}';
}
if(isset($icon_border_color_hover) && !empty($icon_border_color_hover)) {
	$custom_el_css .= '.'.esc_js($unique_id) .'.inline:hover .icon-inner-wrap {border-color:'.$icon_border_color_hover.';}';
	$custom_el_css .= '#'.esc_js($unique_id) .'.popup-minimal .button-wrap:hover .icon-inner-wrap {border-color:'.$icon_border_color_hover.';}';
}
if(isset($icon_border_size) && !empty($icon_border_size)) {
	$custom_el_css .= '.'.esc_js($unique_id) .'.inline .icon-inner-wrap {border-width:'.$icon_border_size.'px;}';
	$custom_el_css .= '#'.esc_js($unique_id) .'.popup-minimal .icon-inner-wrap  {border-width:'.$icon_border_size.'px;}';
}

if(isset($pulse_color) && !empty($pulse_color)) {
	$custom_el_css .= '.'.esc_js($unique_id) .' .icon-pulse-wrap {border-color:'.$pulse_color.';}';
}


if(isset($outline_border) && !empty($outline_border)) {
	$custom_el_css .= '.'.esc_js($unique_id) .' .button-wrap-inner {border-color:'.$outline_border.';}';
}
if(isset($outline_border_hover) && !empty($outline_border_hover)) {
	$custom_el_css .= '.'.esc_js($unique_id) .' .button-wrap:hover .button-wrap-inner {border-color:'.$outline_border_hover.';}';
}
if(isset($outline_border_width) && !empty($outline_border_width)) {
	$custom_el_css .= '.'.esc_js($unique_id) .' .button-wrap .button-wrap-inner {border-width:'.$outline_border_width.'px;}';
}
if(isset($outline_padding) && !empty($outline_padding)) {
	$custom_el_css .= '.'.esc_js($unique_id) .' .button-wrap .button-wrap-inner {padding:'.$outline_padding.'px;}';
}
if(isset($icon_size) && !empty($icon_size)) {
	$custom_el_css .= '.'.esc_js($unique_id) .' .dpr-video-button {font-size:'.$icon_size.'px;}';
}
if(isset($button_size) && !empty($button_size)) {
	$custom_el_css .= '.'.esc_js($unique_id) .' .dpr-video-button {width:'.$button_size.'px;height:'.$button_size.'px;line-height:'.$button_size.'px;}';
}
if(isset($video_container_border_radius) && !empty($video_container_border_radius)) {
	$custom_el_css .= '.'.esc_js($unique_id) .'.inline {border-radius:'.$video_container_border_radius.'px; overflow:hidden;}';
}
if (dpr_shadow_param_to_css($container_shadow) != '') {
	$custom_el_css .= '.'.esc_js($unique_id) .'{'.dpr_shadow_param_to_css($container_shadow).'}';
}
if (dpr_shadow_param_to_css($container_shadow_hover) != '') {
	$custom_el_css .= '.'.esc_js($unique_id) .':hover{'.dpr_shadow_param_to_css($container_shadow_hover).'}';
}



$output .= '<div id="' . esc_attr($unique_id) . '" class="dpr-video-player '.esc_attr($el_class).' ' . esc_attr($unique_id) . '">';
if($type == 'popup') {
$output .= $button_html;
}
if($type == 'inline') {
$output .= $inline_player_html;
}

if($type == 'popup-minimal') {
$output .= $button_minimal_html;
}



	if(!empty($custom_el_css)) {
		$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>");'
						. '})(jQuery);'
					. '</script>';
}


$output .= '</div>';

echo $output;