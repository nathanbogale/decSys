<?php







if ( !function_exists( "dpr_post_format_link_sections " ) ):



    function dpr_post_format_link_sections() {



		/*



     	* ---> START POST FORMAT LINK METABOX SECTIONS



		*/



		



		$post_format_link_sections = array();



		$post_format_link_sections[] = array(



			'fields'   => array(



								array(



									'id'       => 'link_post_link_url',



									'title'    =>  __( 'Link URL', 'dpr-adeline-extensions' ),



									'type'     => 'text',



									'default'  => ''



								),



								



								array(



									'id'       => 'link_post_link_text',



									'title'    =>  __( 'Link Text', 'dpr-adeline-extensions' ),



									'type'     => 'text',



									'default'  => '',



								),



								array(



									'id'       => 'link_post_link_target',



									'type'     => 'radio',



									'title'    => __('Link Target', 'dpr-adeline-extensions'), 



									'options'  => array(



										'_self' => 'Self', 



										'_blank' => 'Blank'



									),



									'default' => '_self',



									'desc'     => __('Here you can enter custom link URL and link text for post format <i><b>Link</b></i>. If you leave this filed blank will be used post content.', 'dpr-adeline-extensions'),



								),



			)



		);



		



		/*



     	* ---> END POST FORMAT LINK METABOX SECTIONS



		*/







        return $post_format_link_sections;



    }



endif;