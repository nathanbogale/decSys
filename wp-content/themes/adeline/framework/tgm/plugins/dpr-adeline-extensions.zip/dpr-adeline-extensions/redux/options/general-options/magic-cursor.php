<?php

/**



 * General Options -> Magic Cursor



 *



 */

Redux::setSection($opt_name, array(

    'title'      => esc_html__('Magic Cursor', 'dpr-adeline-extensions'),

    'id'         => 'general_magic_cursor',

    'subsection' => true,

    'fields'     => array(

        array(

            'id'      => 'magic_cursor',

            'type'    => 'switch',

            'title'   => esc_html__('Magic Cursor', 'dpr-adeline-extensions'),

            'default' => false,

            'hint'    => array(

                'title'   => esc_attr__('Magic Cursor', 'dpr-adeline-extensions'),

                'content' => esc_attr__('You can enable or disable magic cursor.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'magic_cursor_border_color',

            'type'     => 'color',

            'title'    => __('Magic Cursor Border Color', 'dpr-adeline-extensions'),

            'output'   => array('border-color' => '.dpr-cursor span.dpr-cursor-circle', 'color' => '.dpr-cursor span.dpr-cursor-slider:before, .dpr-cursor span.dpr-cursor-slider:after, .dpr-cursor span.dpr-cursor-label'),

            'default'  => '#ffffff',

            'hint'     => array(

                'title'   => esc_attr__('Magic Cursor Border Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set color for magic cursor border', 'dpr-adeline-extensions'),

            ),

            'required' => array('magic_cursor', 'equals', '1'),

        ),
        array(

            'id'       => 'magic_cursor_dot_color',

            'type'     => 'color',

            'title'    => __('Magic Cursor Dot Color', 'dpr-adeline-extensions'),

            'output'   => array('background-color' => '.dpr-cursor span.dpr-cursor-dot'),

            'default'  => '#D3AE5F',

            'hint'     => array(

                'title'   => esc_attr__('Magic Cursor Border Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set color for magic cursor border', 'dpr-adeline-extensions'),

            ),

            'required' => array('magic_cursor', 'equals', '1'),

        ),
        array(

            'id'      => 'disable_system_cursor',

            'type'    => 'switch',

            'title'   => esc_html__('Disable System Cursor', 'dpr-adeline-extensions'),

            'default' => false,

            'hint'    => array(

                'title'   => esc_attr__('Disable System Cursor', 'dpr-adeline-extensions'),

                'content' => esc_attr__('You can enable or disable system cursor.', 'dpr-adeline-extensions'),

            ),

            'required' => array('magic_cursor', 'equals', '1'),

        ),

    ),

));
