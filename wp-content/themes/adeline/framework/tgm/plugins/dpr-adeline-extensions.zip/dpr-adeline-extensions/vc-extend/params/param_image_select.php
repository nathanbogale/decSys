<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if(!class_exists('DPR_Image_Select_Param')) {
	class DPR_Image_Select_Param {
		function __construct() {	
			if(function_exists('vc_add_shortcode_param')) {
				vc_add_shortcode_param('dpr_image_select' , array(&$this, 'dpr_image_select' ), DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/admin/js/dpr_param.js' );
			}
		}
	
		function dpr_image_select($settings, $value) {

			$options      = isset( $settings['options'] ) ? $settings['options'] : '';
			

			$class      = isset( $settings['class'] ) ? $settings['class'] : '';

			$output = $selected = '';
			$css_option = str_replace( '#', 'hash-', vc_get_dropdown_option( $settings, $value ) );

			$output .= '<select name="'
			           . $settings['param_name']
			           . '" class="wpb_vc_param_value wpb-input wpb-select ' . $class
			           . ' ' .$settings['param_name']
			           . ' ' . $settings['type']
			           . ' ' . $css_option
			           . '" data-option="' . $css_option . '">';

			if ( is_array( $options ) ) {
				foreach ( $options as $key => $val ) {

					if ( '' !== $css_option && $css_option === $key ) {
						$selected = ' selected="selected"';
					} else {
						$selected = '';
					}
					
					
					$label = $val['label'];
					$img_url = $val['src'];

					$output .= '<option data-img-label="'.esc_html($label).'" data-img-src="' . esc_url($img_url) . '"  value="' . esc_attr($key) . '" ' . $selected . '>';
				}
			}
			$output .= '</select>';

			return $output;

		}
		
	}
	
	$DPR_Image_Select_Param = new DPR_Image_Select_Param();
}
