<?php



/**



 * Header Options



 * 



 */







    Redux::setSection( $opt_name, array(



        'title'  => __( 'Footer', 'dpr-adeline-extensions' ),



        'id'     => 'footer_tab',



        'desc'   => __( 'Basic footer area settings are configured here.', 'dpr-adeline-extensions' ),



        'icon'   => 'el el-photo'



    ) );



	require_once($options_dir . '/footer-options/footer.php');



	require_once($options_dir . '/footer-options/copyright.php');



