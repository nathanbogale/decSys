<?php



/**



 * Woocoommerce Options -> Single Product



 * 



 */







	Redux::setSection( $opt_name, array(



		'title' => esc_html__('Single Product', 'dpr-adeline-extensions'),



		'id' => 'woocommerce_product',



		'subsection' => true,



		'fields' => array(

						array (



							'id' => 'woo_single_page_content_width',



							'type' => 'image_select',



							'title' => __('Page Width', 'dpr-adeline-extensions'),



							'options' => array (



								'boxed' => array (



									'title' => esc_html__('Boxed', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/boxed.png'



								),					



								'full' => array (



									'title' => esc_html__('Full Width', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/full_width.png'



								)



							),



							'default' => 'boxed',



							'hint' => array (



								'title' => esc_attr__('Page Width', 'dpr-adeline-extensions'),



								'content' => esc_attr__('Choose page width boxed or full width.', 'dpr-adeline-extensions')



							)



						),



						array (



							'id' => 'woo_single_page_content_layout',



							'type' => 'image_select',



							'title' => __('Layout', 'dpr-adeline-extensions'),



							'options' => array (



								'right-sidebar' => array (



									'title' => esc_html__('Sidebar right', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/sidebar_right.png'



								),					



								'left-sidebar' => array (



									'title' => esc_html__('Sidebar left', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/sidebar_left.png'



								),



								'both-sidebars' => array (



									'title' => esc_html__('Both sidebars', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/sidebar_both.png'



								),



	



								'full-width' => array (



									'title' => esc_html__('No Sidebar', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/sidebar_disabled.png',	



								),



							),



							'default' => 'right-sidebar',



							'hint' => array (



								'title' => esc_attr__('Default Content Layout', 'dpr-adeline-extensions'),



								'content' => esc_attr__('Choose default content layoyt eg sidebar position. This general settings can be overwriten for specific pages.', 'dpr-adeline-extensions')



							)



						),



						array (



							'id' => 'woo_single_page_both_sidebars_column_order',



							'type' => 'image_select',



							'title' => __('Both Sidebars: Column Order', 'dpr-adeline-extensions'),



							'options' => array (



								'order-scs' => array (



									'title' => esc_html__('Sidebar/Content/Sidebar', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/scs.png'



								),					



								'order-ssc' => array (



									'title' => esc_html__('Sidebar/Sidebar/Content', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/ssc.png'



								),



								'order-css' => array (



									'title' => esc_html__('Content/Sidebar/Sidebar', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/css.png'



								),



							),



							'default' => 'order-scs',



							'hint' => array (



								'title' => esc_attr__('Both Sidebars: Column Order', 'dpr-adeline-extensions'),



								'content' => esc_attr__('Choose default column order. This general settings can be overwriten for specific pages.', 'dpr-adeline-extensions')



							),



							'required' => array('woo_single_page_content_layout','equals','both-sidebars')



						),

					array(



						'id'       => 'woo_single_page_sidebar_right_sticky',



						'type'     => 'switch',



						'default' => false,



						'title'    =>  esc_html__('Sidebar Sticky','dpr-adeline-extensions'),
						
						
						'hint' => array(



							'title'   => esc_attr__('Right Sidebar Sticky','dpr-adeline-extensions'),



							'content' => esc_attr__('If enabled main sidebar stay sticky by scroll','dpr-adeline-extensions')



						),

						'required' => array('woo_single_page_content_layout','equals', array('right-sidebar','both-sidebars','left-sidebar'))	



					),


					array(



						'id'       => 'woo_single_page_sidebar_left_sticky',



						'type'     => 'switch',



						'default' => false,



						'title'    =>  esc_html__('Left Sidebar Sticky','dpr-adeline-extensions'),
						
						
						'hint' => array(



							'title'   => esc_attr__('Left Sidebar Sticky','dpr-adeline-extensions'),



							'content' => esc_attr__('If enabled left sidebar stay sticky by scroll','dpr-adeline-extensions')



						),

						'required' => array('woo_single_page_content_layout','equals', array('both-sidebars'))	



					),



						array(

	

							'id' => 'woo_single_page_content_area_width',

	

							'type' => 'dimensions',

	

							'title' => esc_html__('Content Width (%)', 'dpr-adeline-extensions'),

	

							'width' => true,

	

							'height' => false,

	

							'mode' => array ('width' => 'width', 'height' => 'height'),

	

							'units' => array('%'),

	

							'default'  => array(

	

								'width' => '72%'

	

							),

	

							'hint' => array(

	

								'title'   => esc_attr__('Content Width','dpr-adeline-extensions'),

	

								'content' => esc_attr__('Specify themain content width (in %).','dpr-adeline-extensions')

	

							),

							'required' => array('woo_single_page_content_layout','equals', array('left-sidebar','right-sidebar'))

	

						),

	

						array(

	

							'id' => 'woo_single_page_sidebar_width',

	

							'type' => 'dimensions',

	

							'title' => esc_html__('Sidebar Width (%)', 'dpr-adeline-extensions'),

	

							'width' => true,

	

							'height' => false,

	

							'mode' => array ('width' => 'width', 'height' => 'height'),

	

							'units' => array('%'),

	

							'default'  => array(

	

								'width' => '28%'

	

							),

	

							'hint' => array(

	

								'title'   => esc_attr__('Sidebar Width','dpr-adeline-extensions'),

	

								'content' => esc_attr__('Specify the sidebar width (in %).','dpr-adeline-extensions')

	

							),

							'required' => array('woo_single_page_content_layout','equals', array('left-sidebar','right-sidebar'))

	

						),



						array(



							'id' => 'woo_single_both_sidebars_content_width',



							'type' => 'dimensions',



							'title' => esc_html__('Both Sidebars: Content Width (%)', 'dpr-adeline-extensions'),



							'width' => true,



							'height' => false,



							'mode' => array ('width' => 'width', 'height' => 'height'),



							'units' => array('%'),



							'default'  => array(



								'width' => '44%'



							),



							'hint' => array(



								'title'   => esc_attr__('Both Sidebars: Content Width','dpr-adeline-extensions'),



								'content' => esc_attr__('Specify the main content width in both sidebars layout (in %).','dpr-adeline-extensions')



							),



							'required' => array('woo_single_page_content_layout','equals','both-sidebars')



						),



						array(



							'id' => 'woo_single_both_sidebars_sidebars_width',



							'type' => 'dimensions',



							'title' => esc_html__('Both Sidebars: Sidebars Width (%)', 'dpr-adeline-extensions'),



							'width' => true,



							'height' => false,



							'mode' => array ('width' => 'width', 'height' => 'height'),



							'units' => array('%'),



							'default'  => array(



								'width' => '28%'



							),



							'hint' => array(



								'title'   => esc_attr__('Both Sidebars: Sidebars Width','dpr-adeline-extensions'),



								'content' => esc_attr__('Specify the sidebara width in both sidebars layout (in %).','dpr-adeline-extensions')



							),



							'required' => array('woo_single_page_content_layout','equals','both-sidebars')



						),


						array(



							'id'       => 'woo_product_display_title_in_subheader',



							'type'     => 'switch',



							'default' => false,



							'title'    =>  esc_html__('Display Product Title in Subheader','dpr-adeline-extensions'),



							'hint' => array(



								'title'   => esc_attr__('Display Product Title in Subheader','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Display product title in subheader instead Woocommerce pages default subheader text.','dpr-adeline-extensions')



							)



						),


						array(



							'id'       => 'woo_product_display_navigation',



							'type'     => 'switch',



							'default' => true,



							'title'    =>  esc_html__('Display Product Navigation','dpr-adeline-extensions'),



							'hint' => array(



								'title'   => esc_attr__('Display Product Navigation','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Hide or display product prev/next navigation.','dpr-adeline-extensions')



							)



						),



						array(



							'id'       => 'woo_product_ajax_add_to_cart',



							'type'     => 'switch',



							'default' => true,



							'title'    =>  esc_html__('Enable Ajax Add To Cart','dpr-adeline-extensions'),



							'hint' => array(



								'title'   => esc_attr__('Enable Ajax Add To Cart','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Enable or disable Ajax Add To Cart.','dpr-adeline-extensions')



							)



						),



						array(



							'id' => 'woo_product_image_width',



							'type' => 'dimensions',



							'title' => esc_html__('Product Image Width (%)', 'dpr-adeline-extensions'),



							'width' => true,



							'height' => false,



							'mode' => array ('width' => 'width', 'height' => 'height'),



							'units' => array('%'),



							'default'  => array(



								'width' => '54%'



							),



							'hint' => array(



								'title'   => esc_attr__('Product Image Width (%)','dpr-adeline-extensions'),



								'content' => esc_attr__('Specify the product image width (in %).','dpr-adeline-extensions')



							)



						),



						array(



							'id' => 'woo_product_details_sidebars_width',



							'type' => 'dimensions',



							'title' => esc_html__('Product Details Width (%)', 'dpr-adeline-extensions'),



							'width' => true,



							'height' => false,



							'mode' => array ('width' => 'width', 'height' => 'height'),



							'units' => array('%'),



							'default'  => array(



								'width' => '42%'



							),



							'hint' => array(



								'title'   => esc_attr__('Product Details Width (%)','dpr-adeline-extensions'),



								'content' => esc_attr__('Specify the product image width (in %).','dpr-adeline-extensions')



							)



						),



						array(



							'id'       => 'woo_product_thumbs_layout',



							'type'     => 'radio',



							'title'    => __('Product Gallery Thumbs Layout', 'dpr-adeline-extensions'),



							'options'  => array(



								'horizontal'  => 'Horizontal',



								'vertical' => 'Vertical'



							),



							'default' => 'horizontal',



							'hint' => array(



								'title'   => esc_attr__('Product Gallery Thumbs Layout','dpr-adeline-extensions'),



								'content' => esc_attr__('Set layout for product thumbs gallery. ','dpr-adeline-extensions')



							),



						),



						array(



							'id'      => 'woo_product_elements',



							'type'    => 'sorter',



							'title'   => 'Summary Elements Order',



							'hint' => array(



								'title'   => esc_attr__('Summary Elements Order','dpr-adeline-extensions'),



								'content' => esc_attr__('Enable or disable display of certain elements of product item summary and set element order','dpr-adeline-extensions')



							),



							'options' => array(



								'enabled'  => array(



									'title'   => 'Title',



									'rating' => 'Rating',



									'price' => 'Price',



									'excerpt'     => 'Excerpt',



									'quantity-button' => 'Quantity Button & Add to Cart Button',



									'meta' => 'Product Meta',



								),



								'disabled' => array(



									'sharing' => 'Sharing'



								)



							)



						),



						array(



							'id'   => 'woo_product_tabs_info',



							'type' => 'info',



							'style' => 'dpr-title',



							'title' => wp_kses_post(__('<h3>Tabs</h3>', 'dpr-adeline-extensions')),



						),



						array(



							'id'       => 'woo_product_tabs_style',



							'type'     => 'radio',



							'title'    => __('Tabs Style', 'dpr-adeline-extensions'),



							'options'  => array(



								'horizontal'  => 'Horizontal',



								'vertical' => 'Verical', 



								'section' => 'Section'



							),



							'default' => 'horizontal',



							'hint' => array(



								'title'   => esc_attr__('Tabs Style','dpr-adeline-extensions'),



								'content' => esc_attr__('Set style for product tabs. ','dpr-adeline-extensions')



							),



						),



						array(



							'id'       => 'woo_product_tabs_alignment',



							'type'     => 'radio',



							'title'    => __('Tabs Alignment', 'dpr-adeline-extensions'),



							'options'  => array(



								'left'  => 'Left',



								'center' => 'Center', 



								'right' => 'Right'



							),



							'default' => 'left',



							'hint' => array(



								'title'   => esc_attr__('Tabs Alignment','dpr-adeline-extensions'),



								'content' => esc_attr__('Set aligmnent for product tabs. ','dpr-adeline-extensions')



							),



						),



						array(



							'id'   => 'woo_product_related_info',



							'type' => 'info',



							'style' => 'dpr-title',



							'title' => wp_kses_post(__('<h3>Up-sells & Related Products</h3>', 'dpr-adeline-extensions')),



						),



						array(



							'id'       => 'woo_product_upsels_title',



							'type'     => 'text',



							'title'    => __('Up-sells Title', 'dpr-adeline-extensions'),



							'default'  => 'You May Also Like',



							'hint' => array(



								'title'   => esc_attr__('Up-sells Title','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Set up-sells section title.','dpr-adeline-extensions')



							),



						),



						array(



							'id'       => 'woo_product_upsels_count',



							'type'     => 'slider', 



							'title'    => __('Up-sells Count', 'dpr-adeline-extensions'),



							'default'  => '3',



							'min'      => '0',



							'step'     => '1',



							'max'      => '100',



							'hint' => array(



								'title'   => esc_attr__('Up-sells Count','dpr-adeline-extensions'),



								'content' => esc_attr__('Set up-sells per page count.','dpr-adeline-extensions')



							)



						),



						array(



							'id'       => 'woo_product_upsels_columns',



							'type'     => 'slider', 



							'title'    => __('Up-sells Columns', 'dpr-adeline-extensions'),



							'default'  => '3',



							'min'      => '1',



							'step'     => '1',



							'max'      => '6',



							'hint' => array(



								'title'   => esc_attr__('Up-sells Columns','dpr-adeline-extensions'),



								'content' => esc_attr__('Set up-sells section columns count.','dpr-adeline-extensions')



							)



						),



						array(



							'id'       => 'woo_product_related_display',



							'type'     => 'switch',



							'default' => true,



							'title'    =>  esc_html__('Display Related Products','dpr-adeline-extensions'),



							'hint' => array(



								'title'   => esc_attr__('Display Related Products','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Hide or display related products section.','dpr-adeline-extensions')



							)



						),



						array(



							'id'       => 'woo_product_related_title',



							'type'     => 'text',



							'title'    => __('Related Products Title', 'dpr-adeline-extensions'),



							'default'  => 'Related Products',



							'hint' => array(



								'title'   => esc_attr__('Related Products Title','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Set related products section title.','dpr-adeline-extensions')



							),



							'required' => array('woo_product_related_display','equals','1')



						),



						array(



							'id'       => 'woo_product_related_count',



							'type'     => 'slider', 



							'title'    => __('Related Products Count', 'dpr-adeline-extensions'),



							'default'  => '3',



							'min'      => '0',



							'step'     => '1',



							'max'      => '100',



							'hint' => array(



								'title'   => esc_attr__('Related Products Count','dpr-adeline-extensions'),



								'content' => esc_attr__('Set related products per page count.','dpr-adeline-extensions')



							),



							'required' => array('woo_product_related_display','equals','1')



						),



						array(



							'id'       => 'woo_product_related_columns',



							'type'     => 'slider', 



							'title'    => __('Related Products Columns', 'dpr-adeline-extensions'),



							'default'  => '3',



							'min'      => '1',



							'step'     => '1',



							'max'      => '6',



							'hint' => array(



								'title'   => esc_attr__('Related Products Columns','dpr-adeline-extensions'),



								'content' => esc_attr__('Set related products section columns count.','dpr-adeline-extensions')



							),



							'required' => array('woo_product_related_display','equals','1')



						),					



					)



	));