<?php
if (!defined('ABSPATH')) {
    die('-1');
}

$unique_id      = $css_animation      = $el_class      = $css      = $output      = $custom_el_css      = '';
$separator_type = $adjustment = $separator_height = $seprator_color = $separator_html = '';
$icon_size      = $icon_offset      = $icon_color      = $use_badge      = $badge_color      = $border_width      = $border_color      = $border_radius      = $icon_html      = '';
$text_color     = $text_font_size     = $text_line_height     = $text_letter_spacing     = $text_font_style     = $use_google_fonts     = $text_google_font     = $text_typo_style     = '';

$atts = vc_map_get_attributes('dpr_list', $atts);
extract($atts);

$el_class = $this->getExtraClass($el_class);

if ('' !== $css_animation && 'none' !== $css_animation) {
    dpr_enqueue_waypoint_js();
    dpr_enqueue_animate_css();
    $el_class .= ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
}
if ($separator_type != '') {
    $el_class .= ' separator-' . esc_attr($separator_type);
}

if ($alignment != '') {
    $el_class .= ' icon-' . esc_attr($alignment);
}
if ($use_badge == 'yes') {
    $el_class .= ' icon-with-badge';
}
$unique_id = uniqid('dpr-list-') . '-' . rand(1, 9999);

$css_classes = array(
    'dpr-list-wrap',
    $unique_id,
    $el_class,
    vc_shortcode_custom_css_class($css),
);

$css_class = preg_replace('/\s+/', ' ', apply_filters(VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode(' ', array_filter(array_unique($css_classes))), $this->settings['base'], $atts));


if (isset($icon_size) && !empty($icon_size)) {
    $custom_el_css .= '.' . esc_js($unique_id) . ' .icon-wrap i {font-size: ' . esc_js($icon_size) . 'px;}';
}
if (isset($icon_color) && !empty($icon_color)) {
    $custom_el_css .= '.' . esc_js($unique_id) . ' .icon-wrap i {color: ' . esc_js($icon_color) . ';}';
    $custom_el_css .= '.' . esc_js($unique_id) . ' .icon-wrap .dot {background-color: ' . esc_js($icon_color) . ';}';
}

if ($use_badge == 'yes') {
    if (isset($badge_color) && !empty($badge_color)) {
        $custom_el_css .= '.' . esc_js($unique_id) . ' .icon-wrap:before {background-color: ' . esc_js($badge_color) . ';}';
    }
    if (isset($border_width) && !empty($border_width)) {
        $custom_el_css .= '.' . esc_js($unique_id) . ' .icon-wrap:before {border-width: ' . esc_js($border_width) . 'px;}';
    }
    if (isset($border_color) && !empty($border_color)) {
        $custom_el_css .= '.' . esc_js($unique_id) . ' .icon-wrap:before {border-color: ' . esc_js($border_color) . ';}';
    }
    if (isset($border_radius) && !empty($border_radius)) {
        $custom_el_css .= '.' . esc_js($unique_id) . ' .icon-wrap:before {border-radius: ' . esc_js($border_radius) . 'px;}';
    }
}
if ($separator_type != '') {
    if (isset($separator_height) && !empty($separator_height)) {
        $custom_el_css .= '.' . esc_js($unique_id) . ' .separator {border-bottom-width: ' . esc_js($separator_height) . 'px;}';
    }
    if (isset($separator_color) && !empty($separator_color)) {
        $custom_el_css .= '.' . esc_js($unique_id) . ' .separator {border-bottom-color: ' . esc_js($separator_color) . ';}';
    }
    if (isset($separator_style) && !empty($separator_style)) {
        $custom_el_css .= '.' . esc_js($unique_id) . ' .separator {border-bottom-style: ' . esc_js($separator_style) . ';}';
    }
}
if ($icon_offset == '' && $use_badge == 'no') {
    $icon_offset = 10;
}

if (is_rtl()) {
    $custom_el_css .= '.' . esc_js($unique_id) . ' li .icon-wrap {margin-left: ' . esc_js($icon_offset) . 'px;}';
} else {
    $custom_el_css .= '.' . esc_js($unique_id) . ' li .icon-wrap {margin-right: ' . esc_js($icon_offset) . 'px;}';
}

if ($item_gape != '') {
    $custom_el_css .= '.' . esc_js($unique_id) . ' li {margin-bottom: ' . esc_js($item_gape) . 'px;}';
}

if ($separator_type != '') {
    $separator_html .= '<div class="separator"></div>';
}

$text_typo_style = dpr_generate_typography_style($text_color, $text_font_size, $text_line_height, $text_letter_spacing, $text_font_style, $text_google_font);

$output .= '<div id="' . esc_attr($unique_id) . '" class="' . esc_attr($css_class) . '">';

if (isset($list_items) && !empty($list_items) && function_exists('vc_param_group_parse_atts')) {

    $list_items = (array) vc_param_group_parse_atts($list_items);

    $output .= '<ul class="dpr-list">';
    foreach ($list_items as $item) {
        $icon_html = $content_html = $link_attr = $link_html = $link_class = '';

        if (isset($item['use_link']) && $item['use_link'] == 'yes') {
            $link_class = 'with-link';
            $link_src   = vc_build_link($item['link']);
            if (isset($link_src['url']) && !empty($link_src['url'])) {
                $link_attr .= 'href="' . esc_url($link_src['url']) . '" ';
            } else {
                $link_attr .= 'href="#" ';
            }
            if (isset($link_src['title']) && !empty($link_src['title'])) {
                $link_attr .= 'title="' . esc_attr($link_src['title']) . '" ';
            }
            if (isset($link_src['target']) && !empty($link_src['target'])) {
                $link_attr .= 'target="' . esc_attr(preg_replace('/\s+/', '', $link_src['target'])) . '" ';
            }
            if (isset($link_src['rel']) && !empty($link_src['rel'])) {
                $link_attr .= 'rel="' . esc_attr($link_src['rel']) . '"';
            }
            $link_html = '<a ' . $link_attr . ' class="list-item-link"></a>';
        }

        if (isset($item['item_text']) && !empty($item['item_text'])) {
            $content_html .= '<div class="content-wrap" ' . $text_typo_style . '>';
            $content_html .= '<div class="content-wrap-inner">';
            $content_html .= $item['item_text'];
            $content_html .= '</div>';
            $content_html .= '</div>';
        }
        if (isset($item['bullet_type']) && strcmp($item['bullet_type'], 'with-icon') === 0) {
            $icon = '';
            switch ($item['icon_type']) {
                case 'fontawesome':
                    if (isset($item['icon_fontawesome']) && $item['icon_fontawesome'] != '') {
                        $icon = $item['icon_fontawesome'];
                    }
                    break;
                case 'openiconic':
                    if (isset($item['icon_openiconic']) && $item['icon_openiconic'] != '') {
                        $icon = $item['icon_openiconic'];
                    }
                    break;
                case 'typicons':
                    if (isset($item['icon_typicons']) && $item['icon_typicons'] != '') {
                        $icon = $item['icon_typicons'];
                    }
                    break;
                case 'entypo':
                    if (isset($item['icon_entypo']) && $item['icon_entypo'] != '') {
                        $icon = $item['icon_entypo'];
                    }
                    break;
                case 'linecons':
                    if (isset($item['icon_linecons']) && $item['icon_linecons'] != '') {
                        $icon = $item['icon_linecons'];
                    }
                    break;
                case 'pixelicons':
                    if (isset($item['icon_pixelicons']) && $item['icon_pixelicons'] != '') {
                        $icon = $item['icon_pixelicons'];
                    }
                    break;
                case 'monosocial':
                    if (isset($item['icon_monosocial']) && $item['icon_monosocial'] != '') {
                        $icon = $item['icon_monosocial'];
                    }
                case 'themeicons':
                    if (isset($item['icon_theme']) && $item['icon_theme'] != '') {
                        $icon = $item['icon_theme'];
                    }

            }
            // Enqueue needed font for icon element
            if ('pixelicons' !== $item['icon_type']) {
                vc_icon_element_fonts_enqueue($item['icon_type']);
            }
            $icon_html .= '<div class="icon-wrap">';
            $icon_html .= '<i class="featured-icon ' . $icon . '"></i>';
            $icon_html .= '</div>';
        } elseif (isset($item['bullet_type']) && strcmp($item['bullet_type'], 'with-dot') === 0) {
            $icon_html .= '<div class="icon-wrap without-icon">';
            $icon_html .= '<i class="dot"></i>';
            $icon_html .= '</div>';
        }
        if (isset($item['item_text']) && !empty($item['item_text'])) {
            $output .= '<li class="' . esc_attr($link_class) . '">';
            $output .= '<div class="item-container ' . esc_attr($item['bullet_type']) . '">';
            if (isset($alignment) && ($alignment == 'left' || $alignment == 'justify')) {
                $output .= $icon_html;
                $output .= $content_html;
            } else {
                $output .= $content_html;
                $output .= $icon_html;
            }

            $output .= '</div>';
            $output .= $separator_html;
            $output .= $link_html;
            $output .= '</li>';
        }

    }
}

$output .= '</ul>';

if (!empty($custom_el_css)) {
    $output .= '<script>'
        . '(function($) {'
        . '$("head").append("<style>' . $custom_el_css . '</style>");'
        . '})(jQuery);'
        . '</script>';
}
$output .= '</div>';

echo $output;
