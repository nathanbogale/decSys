<?php

// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}



/*

  Shortcode: Carousel

 */



class WPBakeryShortCode_DPR_Image_Trail extends WPBakeryShortCodesContainer {

	

}



new dpr_hide_frontend("dpr_image_trail");



vc_map(

	array(

		'name' => esc_html__('DP Images Trail', 'dpr-adeline-extensions'),

		'base' => 'dpr_image_trail',

		'icon' => 'icon-dpr-image-trail',

		'class' => 'dpr_image_trail',

		'as_parent' => array('except' =>'dpr_image_trail'),

		'content_element' => true,

		'controls' => 'full',

		'show_settings_on_create' => true,

  		"category" =>array( esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions')),

		'description' => esc_html__('Container with animated images trail on mouse move in background'),

		'params' => array_merge(array(



				array(
					'type' => 'dropdown',
					'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select animation style.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Animation Style', 'dpr-adeline-extensions'),
					'description' => wp_kses_post( 'Select image trail animation style. All available style you can see <a href="https://tympanus.net/Development/ImageTrailEffects/" target="_blank">here</a>.Please note that <b>"Style 6"</b> images are full screen so if you chose this style you need to select images large enough below.', 'js_composer' ),
					'value' => '1',
					'param_name' => 'style',
					'value' => array(
						esc_html__( 'Style 1', 'js_composer' ) => '1',
						esc_html__( 'Style 2', 'js_composer' ) => '2',
						esc_html__( 'Style 3', 'js_composer' ) => '3',
						esc_html__( 'Style 4', 'js_composer' ) => '4',
						esc_html__( 'Style 5', 'js_composer' ) => '5',
						esc_html__( 'Style 6', 'js_composer' ) => '6',	
					),
				),

					array(

						'type' => 'number',

						'class' => '',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select trail images max width.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Images Max Width', 'dpr-adeline-extensions'),

						'param_name' => 'img_max_width',

						'value' =>'250',

						'min'=>'0',

						'step' => '1',

						'edit_field_class' => 'vc_column vc_col-sm-4',

						'dependency' => array(

								'element' => 'style',

								'value' => array('1','2','3','4','5'),

						),		

					),
	
	
	
			array(
				'type' => 'attach_images',
				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select images which will be appear on mose move over image trail elemnt', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Trail Images', 'dpr-adeline-extensions'),
				'param_name' => 'images',
				'value' => '',
				'description' => esc_html__( 'Select images from media library.', 'js_composer' ),
			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Additional Settings', 'dpr-adeline-extensions' ),

				'param_name'       => 'extra_features_title',

				'edit_field_class' => 'vc_column vc_col-sm-12',

			),
	

			array(

			'type' => 'textfield',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Extra Class Name', 'dpr-adeline-extensions'),

			'param_name' => 'el_class',

			),
	
			array(

				'type' => 'css_editor',

				'heading' => __( 'CSS box', 'dpr-adeline-extensions' ),

				'param_name' => 'css',

				'group' => __( 'Design Options', 'dpr-adeline-extensions' ),

			),

							

			)),

		'js_view' => 'VcColumnView'

	)

);

