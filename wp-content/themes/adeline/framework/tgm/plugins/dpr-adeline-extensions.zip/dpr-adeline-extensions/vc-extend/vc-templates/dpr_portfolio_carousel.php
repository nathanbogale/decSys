<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$output = $custom_el_css = $el_class = $el_inner_class = $source_type = $items_to_display = $categories_include = $categories_exclude = $item_list = $order_by = $order = '';
$carousel_mode = $center_mode_padding = $slideshow_speed = $autoplay = $autoplay_speed = $to_show = $to_show_desktop = $to_show_tablet = $to_show_mobile = $to_scroll = $to_scroll_desktop = $to_scroll_tablet = $to_scroll_mobile = $draggable = $touchable = '';
$items_margin = $items_padidng = $items_bg_color = $items_border_width = $items_border_radius = $items_border_color = $content_position = '';$outside_content_padding = $outside_arrowed_style = $outside_display_title =  $outside_display_excerpt = $outside_display_category = $outside_title_color = $outside_title_color_hover = $outside_category_link_color = $outside_category_link_color_hover = $outside_excerpt_color = '';
$inside_display_title = $inside_display_category = $inside_display_excerpt = $inside_title_color = $inside_title_color_hover = $inside_category_link_color = $inside_category_link_color_hover =  $inside_excerpt_color = '';
$item_shadow = $item_shadow_custom = $item_shadow_hover = $item_shadow_hover_custom = '';
$entry_img_size = $entry_img_width = $entry_img_height = $entry_overlay_type = $overlay_color = $overlay_spacing = $overlay_gradient = '';
$overlay_icons_style = $overlay_icons_size = $overlay_icons_font_size = $link_icon_type = $link_icon = $zoom_icon_type = $zoom_icon = $overlay_icons_color = $overlay_icons_bg = $overlay_icons_border = '';$overlay_icons_color_hover = $overlay_icons_bg_hover = $overlay_icons_border_hover = $plus_link = $plus_size = $plus_color = $plus_color_hover = '';
$overlay_title_color = $overlay_title_color_hover = $overlay_category_color = $overlay_category_color_hover = '';

$dots = $dots_style = $dots_color = $dots_color_inactive = $dots_spacing = $dots_top_margin = $pagination_alignment = '';
$arrows = $arrows_position = $arrow_icon = $arrow_icon_size = $arrow_icon_color = $arrow_icon_color_hover = $arrow_bg_border_radius = $arrow_bg_border_width = $arrow_bg_color = $arrow_bg_color_hover = $arrow_bg_border_color = $arrow_bg_border_color_hover = $arrow_use_shadow_on_hover = $arrow_hover_shadow = $arrow_allways_visible = $arrow_use_numbers = $arrow_numbers_color = ''; 
$slick_settings = $left_arrow_html = $right_arrow_html = $counter_html = '';

$title_font_size = $title_line_height = $title_letter_spacing = $title_font_style = $title_use_google_fonts = $title_google_font = '';
$category_font_size = $category_line_height = $category_letter_spacing = $category_font_style = $category_use_google_fonts = $category_google_font = '';

$atts = vc_map_get_attributes(  $this->getShortcode(), $atts  );
extract( $atts );

$el_class = $this->getExtraClass( $el_class );
if ( '' !== $css_animation && 'none' !== $css_animation ) {
	dpr_enqueue_waypoint_js();
	dpr_enqueue_animate_css();
	$el_class .= ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
}
$unique_id = uniqid('dpr-portfolio-carousel-').'-'.rand(1,9999);

/* Element classes and slick settings*/
if(isset($carousel_mode) && $carousel_mode =='center') {
	$el_class .= ' portfolio-carousel-centered';
}
$css_classes = array(
	'dpr-carousel-wrap portfolio-items',
	$pagination_alignment,
	$el_class,
);

$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->settings['base'], $atts ) );


$slick_settings .= 'arrows: false,';
$slick_settings .= 'dotsClass: \'dpr-slick-dots\',';

if(isset($to_scroll) && $to_scroll !='') {
$slick_settings .= 'slidesToScroll:'.$to_scroll.',';
} else {
$slick_settings .= 'slidesToScroll: 1,';
}

if(isset($to_show) && $to_show !='') {
$slick_settings .= 'slidesToShow:'.$to_show.',';
} else {
$slick_settings .= 'slidesToShow: 3,';
}

if ($dots == 'yes') {
	$el_inner_class .= ' dots-enabled';
	if(isset($dots_style) && $dots_style !='') {
		$el_inner_class .= ' dpr-dots-'.$dots_style;
	}
	$slick_settings .= 'dots: true,';
	$slick_settings .=	'customPaging: function(slider, i) {
						return \'<span data-role="none" role="button" aria-required="false" tabindex="0"></span>\';
					},';
} else {
	$slick_settings .= 'dots: false,';
}
if ($arrows == 'yes') {
	$el_inner_class .= ' arrows-enabled';
	
	if(isset($arrows_position) && $arrows_position !='') {
		$el_inner_class .= ' arrows-'.$arrows_position;
	}
	
	if($arrow_allways_visible == 'yes') {
		$el_inner_class .= ' arrows-allways';
	}

	if($arrow_use_numbers == 'yes') {
		$el_inner_class .= ' show-numbers';
	} else {
		$el_inner_class .= ' hide-numbers';
	}
	$arrow_style = dpr_getSlickArrowsStyle($atts);
	
	$custom_el_css .= "#".$unique_id." a.dpr-slider-controls:hover i{".$arrow_style["style-hover-icon"]."}";
	$custom_el_css .= "#".$unique_id." a.dpr-slider-controls:hover{".$arrow_style["style-hover-bg"]."}";
	$custom_el_css .= "#".$unique_id." a.dpr-slider-controls .counter{".$arrow_style["style-navigation"]."}";
	
	$style_icon = 'style="'.$arrow_style["style-icon"].'"';
	$style_bg = 'style="'.$arrow_style["style-bg"].'"';
	$left_arrow_html .= '<i class="'.$arrow_style["icon_left"].'" '.$style_icon.'></i>';
	$right_arrow_html .= '<i class="'.$arrow_style["icon_right"].'" '.$style_icon.'></i>';	
}
if($autoplay == 'yes') {
	$slick_settings .= 'autoplay: true,';
	if($autoplay != '') {
		$slick_settings .= 'autoplaySpeed: '.esc_js($autoplay_speed).',';
	}
}
if($carousel_mode == 'center') {
	$slick_settings .= 'centerMode: true,';
	if(isset($center_mode_padding) && $center_mode_padding != '') {
				$slick_settings .= 'centerPadding: "'.esc_js($center_mode_padding).'px",';
	}
}
if($slideshow_speed != '') {
	$slick_settings .= 'speed: '.esc_js($slideshow_speed).',';
}

if($draggable == 'yes') {
	$slick_settings .= 'swipe: true,';
	$slick_settings .= 'draggable: true,';
} else {
	$slick_settings .= 'swipe: false,';
	$slick_settings .= 'draggable: false,';

	if($touchable == 'yes') {
		$slick_settings .= 'touchMove: true,';
	}
}

if(is_rtl()) {
	$slick_settings .= 'rtl: true,';
}
if($to_show_desktop =='') {
	$to_show_desktop = 3;
}
if($to_show_tablet =='') {
	$to_show_tablet = 2;
}
if($to_show_mobile =='') {
	$to_show_mobile = 1;
}
if($to_scroll_desktop =='') {
	$to_scroll_desktop = 1;
}
if($to_scroll_tablet =='') {
	$to_scroll_tablet = 1;
}
if($to_scroll_mobile =='') {
	$to_scroll_mobile = 1;
}

if($to_show_desktop != '' || $to_show_tablet != '' || $to_show_mobile != '' || $to_scroll_desktop != '' || $to_scroll_tablet != '' || $to_scroll_mobile != '') {
	$slick_settings .= 'responsive: [';
	if($to_show_desktop != '' || $to_scroll_desktop != '') {
		$slick_settings .= '
				{
					breakpoint: 1024,
					settings: {
						slidesToShow: '.esc_js($to_show_desktop).',
						slidesToScroll: '.esc_js($to_scroll_desktop).',
					}
				},';
	}
	if($to_show_tablet != '' || $to_scroll_tablet != '') {
		$slick_settings .= '
				{
					breakpoint: 800,
					settings: {
						slidesToShow: '.esc_js($to_show_tablet).',
						slidesToScroll: '.esc_js($to_scroll_tablet).',
					}
				},';
	}
	if($to_show_mobile != '' || $to_scroll_mobile != '') {
		$slick_settings .= '
				{
					breakpoint: 480,
					settings: {
						slidesToShow: '.esc_js($to_show_mobile).',
						slidesToScroll: '.esc_js($to_scroll_mobile).',
					}
				},';
	}
	$slick_settings .= ']';
}

/* * *************************************
 * Custom CSS classes and attributes
 * ***************************************
*/
$link_icon_class = 'dpr-icon-size-fullscreen';
if ($link_icon_type == 'custom') {
		switch ( $link_icon_lib ) {
					case 'fontawesome':
					if (isset($link_icon_fontawesome) && $link_icon_fontawesome != '') {
					$link_icon_class = $link_icon_fontawesome;
					}
					break;
					case 'openiconic':
					if (isset($link_icon_openiconic) && $link_icon_openiconic != '') {
					$link_icon_class = $link_icon_openiconic;
					}
					break;
					case 'typicons':
					if (isset($link_icon_typicons) && $link_icon_typicons != '') {
					$link_icon_class = $link_icon_typicons;
					}
					break;
					case 'entypo':
					if (isset($link_icon_entypo) && $link_icon_entypo != '') {
					$link_icon_class = $link_icon_entypo;
					}
					break;
					case 'linecons':
					if (isset($link_icon_linecons) && $link_icon_linecons != '') {
					$link_icon_class = $link_icon_linecons;
					}

		}
		vc_icon_element_fonts_enqueue( $link_icon_lib );
}
$zoom_icon_class = 'dpr-icon-magnifier';
if ($zoom_icon_type == 'custom') {
		switch ( $zoom_icon_lib ) {
					case 'fontawesome':
					if (isset($zoom_icon_fontawesome) && $zoom_icon_fontawesome != '') {
					$zoom_icon_class = $zoom_icon_fontawesome;
					}
					break;
					case 'openiconic':
					if (isset($zoom_icon_openiconic) && $zoom_icon_openiconic != '') {
					$zoom_icon_class = $zoom_icon_openiconic;
					}
					break;
					case 'typicons':
					if (isset($zoom_icon_typicons) && $zoom_icon_typicons != '') {
					$zoom_icon_class = $zoom_icon_typicons;
					}
					break;
					case 'entypo':
					if (isset($zoom_icon_entypo) && $zoom_icon_entypo != '') {
					$zoom_icon_class = $zoom_icon_entypo;
					}
					break;
					case 'linecons':
					if (isset($zoom_icon_linecons) && $zoom_icon_linecons != '') {
					$zoom_icon_class = $zoom_icon_linecons;
					}

		}
		vc_icon_element_fonts_enqueue( $zoom_icon_lib );
}

$item_classes 	= array('portfolio-item-inner','clr');
if ( 'custom' != $item_shadow && '' != $item_shadow ) $item_classes[] = 'dpr-shadow-'.$item_shadow;
if ( 'custom' != $item_shadow_hover && '' != $item_shadow_hover ) $item_classes[] = 'dpr-shadow-onhover-'.$item_shadow_hover;


$item_classes 		= implode( ' ', $item_classes );

$overlay_classes 	= array('overlay');
$overlay_classes[] = $entry_overlay_type;
$overlay_classes 		= implode( ' ', $overlay_classes );


/* * ************************
 * Styles and custom CSS
 * *********************** 
*/
$title_typo_style = dpr_generate_typography_style('', $title_font_size, $title_line_height, $title_letter_spacing, $title_font_style,$title_google_font);
$category_typo_style = dpr_generate_typography_style('', $category_font_size, $category_line_height, $category_letter_spacing, $category_font_style,$category_google_font);

//Carousel Dots
$dots_side_margin = 2;
if($dots_color_inactive != '') {
	
	if(isset($items_margin) && !empty($items_margin)) {
	$dots_side_margin = $dots_side_margin + $items_margin ;
	}
	$custom_el_css .=	'#'.esc_js($unique_id).' .dpr-dots-outline-square .slick-slider .dpr-slick-dots li, #'.esc_js($unique_id).' .dpr-dots-outline-round .slick-slider .dpr-slick-dots li, #'.esc_js($unique_id).' .dpr-dots-outline-bar .slick-slider .dpr-slick-dots li  {border-color: '.esc_js($dots_color_inactive).'}';
	$custom_el_css .=	'#'.esc_js($unique_id).' .dpr-dots-flat-round .slick-slider .dpr-slick-dots li, #'.esc_js($unique_id).' .dpr-dots-flat-rounded .slick-slider .dpr-slick-dots li, #'.esc_js($unique_id).' .dpr-dots-flat-square .slick-slider .dpr-slick-dots li  {background-color: '.esc_js($dots_color_inactive).'}';
}
if($dots_color != '') {
	$custom_el_css .=	'#'.esc_js($unique_id).' .dpr-dots-outline-square .slick-slider .dpr-slick-dots li:hover, #'.esc_js($unique_id).' .dpr-dots-outline-round .slick-slider .dpr-slick-dots li:hover, #'.esc_js($unique_id).' .dpr-dots-outline-bar .slick-slider .dpr-slick-dots li:hover {border-color: '.esc_js($dots_color).';background-color: '.esc_js($dots_color).'}';
	$custom_el_css .=	'#'.esc_js($unique_id).' .dpr-dots-flat-round .slick-slider .dpr-slick-dots li:hover, #'.esc_js($unique_id).' .dpr-dots-flat-rounded .slick-slider .dpr-slick-dots li:hover, #'.esc_js($unique_id).' .dpr-dots-flat-square .slick-slider .dpr-slick-dots li:hover  {background-color: '.esc_js($dots_color).'}';
	$custom_el_css .=	'#'.esc_js($unique_id).' .dpr-dots-outline-square .slick-slider .dpr-slick-dots li.slick-active, #'.esc_js($unique_id).' .dpr-dots-outline-round .slick-slider .dpr-slick-dots li.slick-active, #'.esc_js($unique_id).' .dpr-dots-outline-bar .slick-slider .dpr-slick-dots li.slick-active {border-color: '.esc_js($dots_color).';background-color: '.esc_js($dots_color).'}';
	$custom_el_css .=	'#'.esc_js($unique_id).' .dpr-dots-flat-round .slick-slider .dpr-slick-dots li.slick-active, #'.esc_js($unique_id).' .dpr-dots-flat-rounded .slick-slider .dpr-slick-dots li.slick-active, #'.esc_js($unique_id).' .dpr-dots-flat-square .slick-slider .dpr-slick-dots li.slick-active  {background-color: '.esc_js($dots_color).'}';
if($dots_spacing != '') {
	$dots_margin = intval($dots_spacing/2);
	$dots_side_margin = $dots_side_margin -$dots_margin;;
	$custom_el_css .=	'#'.esc_js($unique_id).' .dpr-carousel-wrap-inner .dpr-slick-dots li {margin-left: '.esc_js($dots_margin).'px;margin-right: '.esc_js($dots_margin).'px}';
}

}

if($dots_top_margin != '') {
	$custom_el_css .=	'#'.esc_js($unique_id).' .dpr-carousel-wrap-inner .dpr-slick-dots {margin-top: '.esc_js($dots_top_margin).'px;}';
}
if($dots_side_margin != '') {
	$custom_el_css .=	'#'.esc_js($unique_id).'.pagination-left .dpr-carousel-wrap-inner .dpr-slick-dots {margin-left: '.esc_js($dots_side_margin).'px;}';
	$custom_el_css .=	'#'.esc_js($unique_id).'.pagination-right .dpr-carousel-wrap-inner .dpr-slick-dots {margin-right: '.esc_js($dots_side_margin).'px;}';

}


//Carousel Items 
if(empty($items_margin) || !isset($items_margin)) {
	$custom_el_css .= '#'.esc_js($unique_id).' .portfolio-item {padding: 0;}';
	$custom_el_css .= '#'.esc_js($unique_id).' {margin-left: 0;margin-right: 0;}';
}
if(isset($items_margin) && !empty($items_margin)) {
	$custom_el_css .= '#'.esc_js($unique_id).' .portfolio-item {padding: '.esc_js(round($items_margin/2)).'px;}';
	$custom_el_css .= '#'.esc_js($unique_id).' {margin-left: -'.esc_js(round($items_margin/2)).'px;margin-right: -'.esc_js(round($items_margin/2)).'px;}';
}
if(isset($items_padidng) && !empty($items_padidng)) {
	$custom_el_css .= '#'.esc_js($unique_id).' .portfolio-item .portfolio-item-inner {padding: '.esc_js($items_padidng).'px;}';
}
if(isset($items_bg_color) && !empty($items_bg_color)) {
	$custom_el_css .= '#'.esc_js($unique_id).' .portfolio-item .portfolio-item-inner, #'.esc_js($unique_id).' .portfolio-content {background-color: '.esc_js($items_bg_color).';}';
	$custom_el_css .= '#'.esc_js($unique_id).' .portfolio-item-thumbnail .arrow {border-bottom-color: '.esc_js($items_bg_color).';}';
}
if(isset($items_border_width) && !empty($items_border_width)) {
	$custom_el_css .= '#'.esc_js($unique_id).' .portfolio-item .portfolio-item-inner {border-width: '.esc_js($items_border_width).'px;}';
}
if(isset($items_border_radius) && !empty($items_border_radius)) {
	$custom_el_css .= '#'.esc_js($unique_id).' .portfolio-item .portfolio-item-inner {border-radius: '.esc_js($items_border_radius).'px;}';
}
if(isset($items_border_color) && !empty($items_border_color)) {
	$custom_el_css .= '#'.esc_js($unique_id).' .portfolio-item .portfolio-item-inner {border-color: '.esc_js($items_border_color).';}';
}
if(!empty($outside_content_padding)) {
	$custom_el_css .= '#'.esc_js($unique_id).' .portfolio-content {padding: 25px '.esc_js($outside_content_padding).'px;}';
}
if(isset($outside_title_color) && !empty($outside_title_color)) {
	$custom_el_css .= '#'.esc_js($unique_id).' .portfolio-content .portfolio-item-title a {color: '.esc_js($outside_title_color).';}';
}
if(isset($outside_title_color_hover) && !empty($outside_title_color_hover)) {
	$custom_el_css .= '#'.esc_js($unique_id).' .portfolio-content .portfolio-item-title a:hover {color: '.esc_js($outside_title_color_hover).';}';
}
if(isset($outside_category_link_color) && !empty($outside_category_link_color)) {
	$custom_el_css .= '#'.esc_js($unique_id).' .portfolio-content .categories a, #'.esc_js($unique_id).' .portfolio-content .categories {color: '.esc_js($outside_category_link_color).';}';
}
if(isset($outside_category_link_color_hover) && !empty($outside_category_link_color_hover)) {
	$custom_el_css .= '#'.esc_js($unique_id).' .portfolio-content .categories a:hover, #'.esc_js($unique_id).' .portfolio-content .categories:hover  {color: '.esc_js($outside_category_link_color_hover).';}';
}
if(isset($outside_excerpt_color) && !empty($outside_excerpt_color)) {
	$custom_el_css .= '#'.esc_js($unique_id).' .portfolio-content .portfolio-item-excerpt {color: '.esc_js($outside_excerpt_color).';}';
}
if(isset($inside_title_color) && !empty($inside_title_color)) {
	$custom_el_css .= '#'.esc_js($unique_id).' .portfolio-inside-content .portfolio-item-title a {color: '.esc_js($inside_title_color).';}';
}
if(isset($inside_title_color_hover) && !empty($inside_title_color_hover)) {
	$custom_el_css .= '#'.esc_js($unique_id).' .portfolio-inside-content .portfolio-item-title a:hover {color: '.esc_js($inside_title_color_hover).';}';
}
if(isset($inside_category_link_color) && !empty($inside_category_link_color)) {
	$custom_el_css .= '#'.esc_js($unique_id).' .portfolio-inside-content .categories a, #'.esc_js($unique_id).' .portfolio-inside-content .categories {color: '.esc_js($inside_category_link_color).';}';
}
if(isset($inside_category_link_color_hover) && !empty($inside_category_link_color_hover)) {
	$custom_el_css .= '#'.esc_js($unique_id).' .portfolio-inside-content .categories a:hover, #'.esc_js($unique_id).' .portfolio-inside-content .categories:hover  {color: '.esc_js($inside_category_link_color_hover).';}';
}
if(isset($inside_excerpt_color) && !empty($inside_excerpt_color)) {
	$custom_el_css .= '#'.esc_js($unique_id).' .portfolio-inside-content .categories a:hover, #'.esc_js($unique_id).' .portfolio-inside-content .portfolio-item-excerpt  {color: '.esc_js($inside_excerpt_color).';}';
}
if($item_shadow == 'custom') {
	if(dpr_shadow_param_to_css($item_shadow_custom) != '') {
		$custom_el_css .= '#'.esc_js($unique_id) .' .portfolio-item .portfolio-item-inner {'.dpr_shadow_param_to_css($item_shadow_custom).'}';
	}
}
if($item_shadow_hover == 'custom') {
	if(dpr_shadow_param_to_css($item_shadow_hover_custom) != '') {
		$custom_el_css .= '#'.esc_js($unique_id) .' .portfolio-item .portfolio-item-inner:hover {'.dpr_shadow_param_to_css($item_shadow_hover_custom).'}';
	}
}

//Overlay 
if(isset($overlay_color) && !empty($overlay_color) && $entry_overlay_type == 'solid') {
	$custom_el_css .= '#'.esc_js($unique_id).' .portfolio-item-thumbnail .overlay .inner  {background-color: '.esc_js($overlay_color).';}';
}
if(isset($entry_overlay_type) && $entry_overlay_type == 'gradient') {
	if(isset($overlay_gradient) && !empty($overlay_gradient)) {
		$custom_el_css .= '#'.esc_js($unique_id).' .portfolio-item-thumbnail .overlay .inner {'.esc_js(adeline_gradientToBgCSS ($overlay_gradient)).'}';
	}
}
if(isset($overlay_spacing) && !empty($overlay_spacing)) {
	$custom_el_css .= '#'.esc_js($unique_id).' .portfolio-item-thumbnail .overlay  {padding: '.esc_js($overlay_spacing).'px;}';
}
if(isset($overlay_icons_size) && !empty($overlay_icons_size)) {
	$custom_el_css .= '#'.esc_js($unique_id).' .portfolio-item-thumbnail .portfolio-overlay-icons li a {width: '.esc_js($overlay_icons_size).'px;height: '.esc_js($overlay_icons_size).'px;}';
}
if(isset($overlay_icons_font_size) && !empty($overlay_icons_font_size)) {
	$custom_el_css .= '#'.esc_js($unique_id).' .portfolio-item-thumbnail .portfolio-overlay-icons li a {font-size: '.esc_js($overlay_icons_font_size).'px;}';
}
if(isset($overlay_icons_color) && !empty($overlay_icons_color)) {
	$custom_el_css .= '#'.esc_js($unique_id).' .portfolio-item-thumbnail .portfolio-overlay-icons li a {color: '.esc_js($overlay_icons_color).';}';
}
if(isset($overlay_icons_bg) && !empty($overlay_icons_bg)) {
	$custom_el_css .= '#'.esc_js($unique_id).' .portfolio-item-thumbnail .portfolio-overlay-icons li a {background-color: '.esc_js($overlay_icons_bg).';}';
}
if(isset($overlay_icons_border) && !empty($overlay_icons_border)) {
	$custom_el_css .= '#'.esc_js($unique_id).' .portfolio-item-thumbnail .portfolio-overlay-icons li a {border-color: '.esc_js($overlay_icons_border).';}';
}

if(isset($overlay_icons_color_hover) && !empty($overlay_icons_color_hover)) {
	$custom_el_css .= '#'.esc_js($unique_id).' .portfolio-item-thumbnail .portfolio-overlay-icons li a:hover {color: '.esc_js($overlay_icons_color_hover).';}';
}
if(isset($overlay_icons_bg_hover) && !empty($overlay_icons_bg_hover)) {
	$custom_el_css .= '#'.esc_js($unique_id).' .portfolio-item-thumbnail .portfolio-overlay-icons li a:hover {background-color: '.esc_js($overlay_icons_bg_hover).';}';
}
if(isset($overlay_icons_border_hover) && !empty($overlay_icons_border_hover)) {
	$custom_el_css .= '#'.esc_js($unique_id).' .portfolio-item-thumbnail .portfolio-overlay-icons li a:hover {border-color: '.esc_js($overlay_icons_border_hover).';}';
}
if(isset($plus_size) && !empty($plus_size)) {
	$custom_el_css .= '#'.esc_js($unique_id).' .portfolio-item-thumbnail .portfolio-plus-sign {width: '.esc_js($plus_size).'px;height: '.esc_js($plus_size).'px;}';
}
if(isset($plus_color) && !empty($plus_color)) {
	$custom_el_css .= '#'.esc_js($unique_id).' .portfolio-item-thumbnail .portfolio-plus-sign svg .to-fill {fill: '.esc_js($plus_color).';}';
}
if(isset($plus_color) && !empty($plus_color_hover)) {
	$custom_el_css .= '#'.esc_js($unique_id).' .portfolio-item-thumbnail .portfolio-plus-sign:hover svg .to-fill {fill: '.esc_js($plus_color_hover).';}';
}

/* * ************************
 * Query args
 * *********************** 
*/
if($source_type != 'list') {
		$args = array(
			'post_type'      	=> 'dpr_portfolio',
			'posts_per_page' 	=> $items_to_display,
			'order'				=> $order,
			'orderby'			=> $order_by,
			'post_status' 		=> 'publish',
			'tax_query' 		=> array(
				'relation' 		=> 'AND',
			),
		);
		
		// Categories IDs
		if ( ! empty( $categories_include ) ) {
		
			// Convert to array
			$categories_include = explode( ',', $categories_include );
		
			// Add to query arg
			$args['tax_query'][] = array(
				'taxonomy' => 'dpr_portfolio_category',
				'field'    => 'term_id',
				'terms'    => $categories_include,
				'operator' => 'IN',
			);
		
		}
		
		// Order
		if ( $order != '' ) {
			$args['order'] = $order;
		}
		// Orderby
		if ( $order_by != 'none' ) {
			$args['orderby'] = $order_by;
		}
		
		// Exclude category
		if ( ! empty( $categories_exclude ) ) {
		
			// Convert to array
			$categories_exclude = explode( ',', $categories_exclude );
		
			// Add to query arg
			$args['tax_query'][] = array(
				'taxonomy' => 'dpr_portfolio_category',
				'field'    => 'term_id',
				'terms'    => $categories_exclude,
				'operator' => 'NOT IN',
			);
		
		}
} else {
	$items_ids = array();
	if(isset($item_list) && !empty($item_list) && function_exists('vc_param_group_parse_atts')) {
	$item_list = (array) vc_param_group_parse_atts($item_list);
		foreach($item_list as $item) {
			$items_ids[] = $item['portfolio_item'];
		}
	}
		$args = array(
		'post_type'      	=> 'dpr_portfolio',
		'post__in'  => $items_ids
		);
		
}




/* * ************************
 * Output
 * *********************** */
$dpr_portfolio_query = new WP_Query( $args );

if ( $dpr_portfolio_query->have_posts() ) {

$counter_html .= '<span class="counter"></span>';
$output .= '<div id="'.esc_attr($unique_id).'" class="'.esc_attr($css_class).'">';
	$output .= '<div class="dpr-carousel-wrap-inner '.$el_inner_class.'">';
			$output .= '<div class="dpr-carousel">';
				// Loop
				while ( $dpr_portfolio_query->have_posts() ) : $dpr_portfolio_query->the_post();
				// Inner classes
					$inner_classes 		= array( 'portfolio-item', 'clr', 'col' );
					$inner_classes[] 	= 'column-1';
					$inner_classes 		= implode( ' ', $inner_classes );
					$output .='<div  class="slide-wrapper">'; 
					$output .='<div  class="'. esc_attr( $inner_classes ).'" style="display:block;">';
					
						if ( has_post_thumbnail(get_the_ID()) ) {
						$output .= '<div class="portfolio-item-thumbnail">';
						$output .= '<a href="'. get_permalink(get_the_ID()).'" class="thumbnail-link">';
						$img_id 	= get_post_thumbnail_id( get_the_ID(), 'full' );
						$img_url 	= dpr_get_attachment_image_src( $img_id, 'full' );
						$img_atts 	= adeline_image_attributes( $img_url[1], $img_url[2], $entry_img_width, $entry_img_height );
						if ( 'custom' == $entry_img_size	&& ! empty( $img_atts ) ) {
						$output .= '<img src="'. adeline_resize( $img_url[0], $img_atts[ 'width' ], $img_atts[ 'height' ], $img_atts[ 'crop' ], true, $img_atts[ 'upscale' ] ).'" alt="'. esc_attr( the_title(get_the_ID()) ).'" width="'. esc_attr(  $entry_img_width ).'" height="'. esc_attr(  $entry_img_height ).' />';
						} else {
						$output .= get_the_post_thumbnail( get_the_ID(), $entry_img_size , array('alt' => get_the_title(get_the_ID()), 	) );
						}
						$output .= '<div class="'. esc_attr( $overlay_classes ).'"><div class="inner"></div></div>';
						$output .= '</a>';
						if ( 'none' != $overlay_icons_style || 'inside' == $content_position ) { 
								$output .= '<div class="portfolio-overlay-content">';
								// Overlay icons
								if ( 'icons' == $overlay_icons_style ) {
									$output .= '<ul class="portfolio-overlay-icons">';
											if('none' != $link_icon_type) {
													$output .= '<li><a href="'. get_permalink(get_the_ID()).'"><i class="'. esc_attr($link_icon_class).'" aria-hidden="true"></i></a></li>';
											}
											if('none' != $zoom_icon_type) {
													$output .= '<li><a href="'. esc_url( wp_get_attachment_url( $img_id ) ).'" data-rel="portfoliogrid:'.esc_attr($unique_id).'" title="'. get_the_title(get_the_ID()).'"><i class="'. esc_attr($zoom_icon_class).'" aria-hidden="true"></i></a></li>';
											}
									$output .= '</ul>';
								}
								if ( 'plus' == $overlay_icons_style ) {
									if ($plus_link == 'lightbox') {
										$output .= '<a href="'.esc_url( wp_get_attachment_url( $img_id ) ).'" data-rel="portfoliogrid:'.esc_attr($unique_id).'" title="'. get_the_title(get_the_ID()).'">';
									} else {
										$output .= '<a href="'. get_permalink(get_the_ID()).'">';
									}
									$output .= '<div class="portfolio-plus-sign">
														<svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 123.31 595.281 595.27">
														<g><g>
														<circle class="to-fill" cx="297.636" cy="420.947" r="14.173"/>
														<path class="to-fill" d="M25.403,435.119H217.35c14.032,0,25.403-6.344,25.403-14.173s-11.371-14.173-25.403-14.173H25.403
													C11.371,406.772,0,413.116,0,420.946S11.371,435.119,25.403,435.119z"/>
													<path class="to-fill" d="M311.809,148.713c0-14.032-6.345-25.402-14.173-25.402c-7.829,0-14.173,11.37-14.173,25.402V340.66
													c0,14.032,6.344,25.403,14.173,25.403c7.829,0,14.173-11.371,14.173-25.403V148.713z"/>
													<path class="to-fill" d="M595.281,420.946c0-7.829-11.371-14.173-25.404-14.173H377.931c-14.033,0-25.404,6.344-25.404,14.173
													s11.371,14.173,25.404,14.173h191.945C583.9,435.119,595.281,428.775,595.281,420.946z"/>
													<path class="to-fill" d="M283.46,693.177c0,14.032,6.344,25.402,14.174,25.402c7.829,0,14.173-11.37,14.173-25.402V501.23
													c0-14.032-6.344-25.403-14.173-25.403c-7.83,0-14.174,11.371-14.174,25.403V693.177z"/>
													</g>
													</g>
													</svg>
												</div>';
									$output .= '</a>';
								}
								// If title or category
								if ( 'inside' == $content_position && ( $inside_display_title || $inside_display_category ) ) {
									$portfolio_inside_content_class = '';
									if ( 'none' != $overlay_icons_style ) {
										$portfolio_inside_content_class = ' has-icons';
									}
									$output .= '<div class="portfolio-inside-content clr '. esc_attr($portfolio_inside_content_class).'">';
									// If title
									if ($inside_display_title == 'yes' ) { 
									$output .= '<h3 class="portfolio-item-title entry-title" '.$title_typo_style.'><a href="'. get_permalink(get_the_ID()).'" rel="bookmark">'. get_the_title(get_the_ID()).'</a></h3>';
									}
									// If category
									if ( $inside_display_category == 'yes' ) {
										if ( $categories = adeline_portfolio_category_meta() ) {
											$output .= '<div class="categories" '.$category_typo_style.'>'. $categories.'</div>';
										}
									// If excerpt
									if ( $inside_display_excerpt == 'yes' ) { 
										$output .= '<div class="portfolio-item-excerpt">'. get_the_excerpt(get_the_ID()).'</div>'; 
									} 
									}
									$output .= '</div>';
								}
								$output .= '</div>';
						}
						if ( 'outside' == $content_position && (  $outside_display_title =='yes' || $outside_display_category =='yes' ) && $outside_arrowed_style == 'yes' ) { 
						$output .= '<div class="arrow"></div>';
						} 
						$output .= '</div>';
						}
						// Outside content
						// If title or category
						if ( 'outside' == $content_position && (   $outside_display_title =='yes' || $outside_display_category =='yes'  ) ) { 
							$output .= '<div class="portfolio-content clr">';
								// If title
								if ( $outside_display_title == 'yes' ) { 
								$output .= '<h3 class="portfolio-item-title entry-title" '.$title_typo_style.'><a href="'. get_permalink(get_the_ID()).'" rel="bookmark">'. get_the_title(get_the_ID()).'</a></h3>';
								}
								if ( $outside_display_category == 'yes' ) { 
									if ( $categories = adeline_portfolio_category_meta() ) {
										$output .= '<div class="categories" '.$category_typo_style.'>'. $categories .'</div>';	}
									}
							 	// If excerpt
								if ( $outside_display_excerpt == 'yes' ) { 
									$output .= '<div class="portfolio-item-excerpt">'. get_the_excerpt(get_the_ID()).'</div>'; 
								} 

							$output .= '</div>';
						
						}
					
					
					$output .= '</div>';
					$output .= '</div>';
				endwhile;
			$output .= '</div>';
			if($arrows == 'yes') {
				$output .=  '<a href="#" class="dpr-slider-controls prev" '.$style_bg.' title="'.esc_attr__('Previous slide','dpr-adeline-extensions').'">'.$counter_html.$left_arrow_html.'</a>';
				$output .=  '<a href="#" class="dpr-slider-controls next" '.$style_bg.' title="'.esc_attr__('Next slide','dpr-adeline-extensions').'">'.$counter_html.$right_arrow_html.'</a>';
			}

	$output .= '</div>';
$output .= '</div>';


// Reset the post data to prevent conflicts with WP globals
wp_reset_postdata(); 

} else {
	$output .= '<p class="portfolio-not-found">'.esc_html_e( 'You have no portfolio items', 'dpr-adeline-extensions' ).'</p>';
}

if(!empty($custom_el_css)) {
		$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>");'
						. '})(jQuery);'
					. '</script>';
}

echo $output;
	?>
	<script>
		jQuery( document ).on( 'ready', function() {
			"use strict";
			var $carousel = jQuery('#<?php echo esc_js($unique_id); ?>').find('.dpr-carousel');		
			<?php if($arrows == 'yes') {
					if($arrow_use_numbers == 'yes') :  ?>
						var total_slides;
						$carousel.on('init reInit afterChange', function (event, slick, currentSlide) {
							var prev_slide_index, next_slide_index, current;
							var $prev_counter = $carousel.siblings('.dpr-slider-controls.prev').find('.counter');
							var $next_counter = $carousel.siblings('.dpr-slider-controls.next').find('.counter');
							total_slides = slick.slideCount;
							current = (currentSlide ? currentSlide : 0) + 1;
							prev_slide_index = (current - 1 < 1) ? total_slides : current - 1;
							next_slide_index = (current + 1 > total_slides) ? 1 : current + 1;
							$prev_counter.text(prev_slide_index + '/' + total_slides);
							$next_counter.text(next_slide_index + '/'+ total_slides);
						});
					<?php endif;
				} ?>
				$carousel.siblings('.dpr-slider-controls.prev').click(function(e) {
					e.preventDefault();
					$carousel.slick("slickPrev");
				});
				$carousel.siblings('.dpr-slider-controls.next').click(function(e) {
					e.preventDefault();
					$carousel.slick("slickNext");
				});
			$carousel.slick({<?php echo $slick_settings; ?>});
		} );
	</script>
<?php
