<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$unique_id = $css_animation = $el_class = $css = $output = $custom_el_css = '';
$style = $percent = $title = $title_html = $progress_animation_data = '';
$progress_line_height_1 = $progress_line_height_2 = $percent_near = $progress_animated = $progress_style = $slanting_lines = $slanting_lines_animate = $title_position = $title_position_compact = '';
$line_bg_style = $line_color = $line_border_radius = $line_gradient = $line_background_color = $line_background_border_color = $line_background_padding = $line_html = '';
$use_icon = $icon_size = $icon_color = $icon_html = '';
$title_color = $title_font_size = $title_line_height = $title_letter_spacing = $title_font_style = $title_use_google_fonts = $title_google_font = $title_typo_style = $title_html = '';
$number_color = $number_font_size = $number_line_height = $number_letter_spacing = $number_font_style = $number_use_google_fonts = $number_google_font = $number_typo_style = $number_html = '';

$atts = vc_map_get_attributes( 'dpr_progressbar', $atts );
extract( $atts );

$el_class = $this->getExtraClass( $el_class );
wp_enqueue_script('dpr-waypoints', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/waypoints.min.js', array('jquery'), null, true);

if ( '' !== $css_animation && 'none' !== $css_animation ) {
	dpr_enqueue_animate_css();
	$el_class .= ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
}
$unique_id = uniqid('dpr-progress-bar-').'-'.rand(1,9999);

if(isset($style)) {
	$el_class .= ' '.$style;
}

if($use_icon == 'yes' && $icon !='' && $icon != 'none') {
	$el_class .= ' with-icon';
}
if ($progress_animated != 'yes') {
	$el_class .= ' no-animation';
	$progress_style = 'style="width: '.esc_attr(intval($percent)).'%;"';
}
if ('0' !== $percent) {
	$progress_animation_data = ' data-percentage-value="'.esc_attr(intval($percent)).'"';
	$percent_position = 100 - esc_attr(intval($percent));
}

if($style  == 'compact' && $title_position_compact !='') {
	$el_class .= ' '.esc_attr($title_position_compact);
	if(isset($title_position_compact) && $title_position_compact == 'position-1') {
		if(is_rtl() ) {
			$custom_el_css .= '.'.esc_js($unique_id).' .title-wrap .progressbar-number {left: '.esc_attr($percent_position).'%;}';
		}else {
			$custom_el_css .= '.'.esc_js($unique_id).' .title-wrap .progressbar-number {right: '.esc_attr($percent_position).'%;}';
		}
	}
}
if($percent_near == 'yes') {
	$el_class .= ' percents-near-title';
}

if($slanting_lines == 'yes') {
	$el_class .= ' slanting-lines';
}
if($slanting_lines_animate == 'yes') {
	$el_class .= ' slanting-lines-animated';
}


$css_classes = array(
	'dpr-progress-bar',
	$unique_id,
	$el_class,
	vc_shortcode_custom_css_class( $css ),
);

$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->settings['base'], $atts ) );


$title_typo_style = dpr_generate_typography_style($title_color, $title_font_size, $title_line_height, $title_letter_spacing, $title_font_style,$title_google_font);	
$number_typo_style = dpr_generate_typography_style($number_color, $number_font_size, $number_line_height, $number_letter_spacing, $number_font_style,$number_google_font);	


if(isset($icon_size) && !empty($icon_size)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .featured-icon {font-size: '.esc_js($icon_size).'px;}';
}
if(isset($icon_color) && !empty($icon_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .featured-icon {color: '.esc_js($icon_color).' !important;}';
}

if(isset($progress_line_height_1) && !empty($progress_line_height_1)) {
	$custom_el_css .= '.'.esc_js($unique_id).'.simple .progress-bar-line {height: '.esc_attr($progress_line_height_1).'px;}';
}
if(isset($progress_line_height_2) && !empty($progress_line_height_2)) {
	$custom_el_css .= '.'.esc_js($unique_id).'.compact .progress-bar-line {height: '.esc_attr($progress_line_height_2).'px;}';
	$custom_el_css .= '.'.esc_js($unique_id).'.compact .title-wrap {line-height: '.esc_attr($progress_line_height_2).'px !important; height: '.esc_attr($progress_line_height_2).'px !important;}';
}
if(isset($line_background_color) && !empty($line_background_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .progress-bar-line .indicator-bg {background: '.esc_attr($line_background_color).' !important;}';
}
if(isset($line_color) && !empty($line_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .progress-bar-line .indicator {background: '.esc_attr($line_color).' !important;}';
}
if($line_bg_style == 'gradient' && isset($line_gradient) && !empty($line_gradient)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .progress-bar-line .indicator {'.adeline_gradientToBgCSS ($line_gradient).';}';
}
if(isset($line_border_radius) && !empty($line_border_radius)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .progress-bar-line, .'.esc_js($unique_id).' .progress-bar-line-wrap {border-radius: '.esc_attr($line_border_radius).'px !important;}';
}
if(isset($line_background_border_color) && !empty($line_background_border_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .progress-bar-line-wrap {border-color: '.esc_attr($line_background_border_color).';}';
}
if(isset($line_background_padding) && !empty($line_background_padding)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .progress-bar-line-wrap {padding: '.esc_attr($line_background_padding).'px;}';
	$custom_height = 2*$line_background_padding + $progress_line_height_2;
	$custom_el_css .= '.'.esc_js($unique_id).'.compact .title-wrap {line-height: '.esc_attr($custom_height).'px !important; height: '.esc_attr($custom_height).'px !important;}';

}



if(isset($use_icon) == 'yes' && $icon != '' && $icon != 'none' ) {
	$icon_html .= '<i class="featured-icon '.esc_attr($icon).'"></i>';
}

$title_html .= '<div class="title-wrap">';
	if (isset($title) && !empty($title)) {
		$title_html .= '<div class="progressbar-title" '.$title_typo_style.'>'.$icon_html.''.esc_html($title).'</div>';
	}
	$title_html .= '<div class="progressbar-number" '.$number_typo_style.'>'.$percent.'<span>%</span></div>';
$title_html .= '</div>';

$line_html .= '<div class="progress-bar-line-wrap"><div class="progress-bar-line">';
	$line_html .= '<div class="indicator-bg"></div>';
	$line_html .= '<div class="indicator" '.$progress_animation_data.' '.$progress_style.'></div>';
$line_html .= '</div></div>';




$output .= '<div id="'.esc_attr($unique_id).'" class="'.esc_attr($css_class).'">';
	if ( 'top' === $title_position ) {
		$output .= $title_html;
		$output .= $line_html;
	} else {
		$output .= $line_html;
		$output .= $title_html;
	}

if(!empty($custom_el_css)) {
		$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>");'
						. '})(jQuery);'
					. '</script>';
}
$output .= '</div>';


echo $output;