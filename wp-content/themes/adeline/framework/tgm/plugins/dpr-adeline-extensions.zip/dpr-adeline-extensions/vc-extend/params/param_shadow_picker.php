<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if(!class_exists('DPR_Shadow_Param')) {
	class DPR_Shadow_Param {
		function __construct() {
			add_action( 'admin_enqueue_scripts', array( $this, 'param_scripts' ) );

			if(function_exists('vc_add_shortcode_param')) {
				vc_add_shortcode_param( 'dpr_shadow_picker', array($this, 'dpr_shadow_picker'), DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/admin/js/dpr_shadow_param.js' );
			}
		}
		function param_scripts($hook) {
			wp_enqueue_style( 'dpr-shadow-picker', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/admin/css/shadow_picker.css');
		}

		function dpr_shadow_picker($settings, $value)
				{
					$param_name = isset($settings['param_name']) ? $settings['param_name'] : '';
					$type = isset($settings['type']) ? $settings['type'] : '';
					$class = isset($settings['class']) ? $settings['class'] : '';
					$uni = uniqid(rand());
					$output = '<input type="hidden" id="dpr-shadow-value-'.$uni.'" class="wpb_vc_param_value ' . $param_name . ' ' . $type . ' ' . $class . '" name="' . $param_name . '" value="'.$value.'"/>';
					$output .= '<div class="vc_col-sm-4">';
		    		$output .= '<div id="dpr-shadow-preview-'.$uni.'" class="vc-dpr-shadow-preview"><div id="target-'.$uni.'" class="vc-dpr-shadow-preview-inner"></div></div>';
					$output .= '</div>';
					$output .= '<div class="vc_col-sm-4" style="margin-top:53px;">';
					$output .= '<select id="dpr-shadow-style-'.$uni.'" class="vc-dpr-shadow-style">
										<optgroup>
											<option value="none">None</option>
										</optgroup>
										<optgroup label="Create Custom Shadows">
											<option value="custom">Custom Shadow</option>
										</optgroup>
										<optgroup label="Predefined Down Shadows">
											<option value="d1">Down Shadow 01</option>
											<option value="d2">Down Shadow 02</option>
											<option value="d3">Down Shadow 03</option>
											<option value="d4">Down Shadow 04</option>
											<option value="d5">Down Shadow 05</option>
											<option value="d6">Down Shadow 06</option>
											<option value="d7">Down Shadow 07</option>
											<option value="d8">Down Shadow 08</option>
											<option value="d9">Down Shadow 09</option>
											<option value="d10">Down Shadow 10</option>
											<option value="d11">Down Shadow 11</option>
											<option value="d12">Down Shadow 12</option>
											<option value="d13">Down Shadow 13</option>
											<option value="d14">Down Shadow 14</option>
											<option value="d15">Down Shadow 15</option>
											<option value="d16">Down Shadow 16</option>
											<option value="d17">Down Shadow 17</option>
											<option value="d18">Down Shadow 18</option>
											<option value="d19">Down Shadow 19</option>
											<option value="d20">Down Shadow 20</option>
											<option value="d21">Down Shadow 21</option>
											<option value="d22">Down Shadow 22</option>
											<option value="d23">Down Shadow 23</option>
											<option value="d24">Down Shadow 24</option>
										</optgroup>
										<optgroup label="Predefined Up Shadows">
											<option value="u1">Up Shadow 01</option>
											<option value="u2">Up Shadow 02</option>
											<option value="u3">Up Shadow 03</option>
											<option value="u4">Up Shadow 04</option>
											<option value="u5">Up Shadow 05</option>
											<option value="u6">Up Shadow 06</option>
											<option value="u7">Up Shadow 07</option>
											<option value="u8">Up Shadow 08</option>
											<option value="u9">Up Shadow 09</option>
											<option value="u10">Up Shadow 10</option>
											<option value="u11">Up Shadow 11</option>
											<option value="u12">Up Shadow 12</option>
											<option value="u13">Up Shadow 13</option>
											<option value="u14">Up Shadow 14</option>
											<option value="u15">Up Shadow 15</option>
											<option value="u16">Up Shadow 16</option>
											<option value="u17">Up Shadow 17</option>
											<option value="u18">Up Shadow 18</option>
											<option value="u19">Up Shadow 19</option>
											<option value="u20">Up Shadow 20</option>
											<option value="u21">Up Shadow 21</option>
											<option value="u22">Up Shadow 22</option>
											<option value="u23">Up Shadow 23</option>
											<option value="u24">Up Shadow 24</option>
										</optgroup>
								</select>';
					$output .= '</div>';
					$output .= '<div class="vc_col-sm-4" style="margin-top:53px;">';
					$output .= '<input type="text" value="" class="shadow-color-control" data-alpha="true">';
					$output .= '<input type="hidden" value="" class="shadow-color-selected">';
					$output .= '</div>';
					$output .= '<div class="vc-dpr-shadow-custom vc_col-sm-12">';
					$output .= '<div class="vc_col-sm-3">';
					$output .= '<label>Horizontal</label><div class="vc-dpr-shadow-custom-input"><input type="text" class="vc-dpr-shadow-custom-input shadow-v wpb-textinput textfield" value="0"></div><div class="units">px</div>';
					$output .= '</div>';
					$output .= '<div class="vc_col-sm-3">';
					$output .= '<label>Vertical</label><div class="vc-dpr-shadow-custom-input"><input type="text" class="shadow-h wpb-textinput textfield" value="0"></div><div class="units">px</div>';
					$output .= '</div>';
					$output .= '<div class="vc_col-sm-3">';
					$output .= '<label>Blur</label><div class="vc-dpr-shadow-custom-input"><input type="text" class="vc-dpr-shadow-custom-input shadow-b wpb-textinput textfield" value="0"></div><div class="units">px</div>';
					$output .= '</div>';
					$output .= '<div class="vc_col-sm-3">';
					$output .= '<label>Spread</label><div class="vc-dpr-shadow-custom-input"><input type="text" class="vc-dpr-shadow-custom-input shadow-s wpb-textinput textfield" value="0"></div><div class="units">px</div>';
					$output .= '</div>';
					$output .= '</div>';
					$output .= '<script>';
					$output .= 'jQuery(document).ready(function(){';

					$output .= '});';
					$output .= '</script>';
		
					return $output;
				}
		
	}

}

if(class_exists('DPR_Shadow_Param')) {
	$DPR_Shadow_Param = new DPR_Shadow_Param();
}