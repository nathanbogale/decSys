<?php

/**

 * Side Panel Template

 *

 */



// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}

global $dpr_adeline;

if ( true == $dpr_adeline['expandable_panel'] ) {



// Get opening button icon

$icon_html = '';

$icon = adeline_get_option_value('opening_button_icon','','Default-exchange');

$icon = $icon ? $icon : 'Default-exchange';

$image_src = adeline_get_option_value('opening_button_image','url','');

$img_style = 'style="width:auto; height:'.adeline_get_option_value('opening_button_icon_size','','20').'px;"';



if ( 'icon' == adeline_get_option_value('opening_button_icon_type','','icon') ) {

	$icon_html = '<i class="side-panel-icon '. $icon .'"></i>';

}

if ( 'image' == adeline_get_option_value('opening_button_icon_type','','icon') ) {

	$icon_html .= '<img src="' . esc_url($image_src) . '"' . $img_style . '/>';

}



// Close button text

$text = adeline_get_option_value( 'close_button_text','','Close Panel' );

$text = $text ? $text : esc_html__( 'Close Panel', 'dpr-adeline-extensions' );





// Get the template

$is_custom_template = false;

if ( 'custom' == adeline_get_option_value('panel_content_source')) $is_custom_template = true;

$particle_id = adeline_get_option_value( 'panel_particle_selected' );

?>



<div id="side-panel-wrap" class="clr">



	<?php

	// If the opening button is beside the panel

	if ( 'beside' === adeline_get_option_value('opening_button_position','','beside') ) {

		?>

			<a href="#" class="side-panel-btn"><?php echo  $icon_html; ?></a>

		<?php

	} ?>



	<div id="side-panel-inner" class="clr">



		<?php

		// If close button enabled

		if ( false != adeline_get_option_value('panel_close_button') ) { ?>

			<a href="#" class="close-panel"><i class="Default-close"></i><span class="close-panel-text"><?php echo esc_attr( $text ); ?></span></a>

		<?php

		} ?>



		<div id="side-panel-content" class="clr">

			<?php

			// Check if there is a custom template

			if ( $is_custom_template && ! empty( $particle_id ) ) {

			echo adeline_particle_content($particle_id);

			// Else, display the widgets

			} else {

				dynamic_sidebar( 'side-panel-sidebar' );

			} ?>

		</div><!-- #side-panel-content -->



	</div><!-- #side-panel-inner -->



</div><!-- #side-panel-wrap -->

<?php } 