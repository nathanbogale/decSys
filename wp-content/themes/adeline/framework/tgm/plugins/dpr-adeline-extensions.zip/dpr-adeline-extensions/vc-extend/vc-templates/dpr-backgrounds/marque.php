<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
if(isset($marque_type) && $marque_type == 'text') {
wp_enqueue_script('jquery-marque', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/jquery.marquee.min.js', array('jquery'), null, true);	
wp_enqueue_script('dpr-row-marque', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/dpr.row.text.marque.js', array('jquery'), null, false);	

$bg_wrap_data_atts = '';

if(isset($bg_text_marque_duration) && $bg_text_marque_duration != '') {
	$bg_wrap_data_atts .= ' data-duration="'.$bg_text_marque_duration.'"';
} else {
	$bg_wrap_data_atts .= ' data-duration="10000"';
}
if(isset($bg_text_marque_direction) && $bg_text_marque_direction != '') {
	$bg_wrap_data_atts .= ' data-direction="'.$bg_text_marque_direction.'"';
} else {
	$bg_wrap_data_atts .= ' data-direction="left"';
}
if($bg_text_marque_start_visible) {
	$bg_wrap_data_atts .= ' data-visible="true"';
} 
if($bg_text_marque_duplicate) {
	$bg_wrap_data_atts .= ' data-duplicate="true"';
} 
if(isset($bg_text_marque_gap) && $bg_text_marque_gap != '') {
	$bg_wrap_data_atts .= ' data-gap="'.$bg_text_marque_gap.'"';
} else {
	$bg_wrap_data_atts .= ' data-gap="left"';
}

$uniqid = uniqid('dpr-bg-wrapper-');

if(isset($bg_text_marque_padding_top) && !empty($bg_text_marque_padding_top)) {
	$custom_el_css .= '#'.esc_attr($uniqid).' h1 {padding-top:'.$bg_text_marque_padding_top.';}';
}
if(isset($bg_text_marque_padding__bottom) && !empty($bg_text_marque_padding__bottom)) {
	$custom_el_css .= '#'.esc_attr($uniqid).' h1 {padding-bottom:'.$bg_text_marque_padding__bottom.';}';
}

if(isset($bg_marque_text) && !empty($bg_marque_text)) {
$bg_text_marque_typo_style = dpr_generate_typography_style($bg_text_marque_color, $bg_text_marque_font_size, $bg_text_marque_line_height, $bg_text_marque_letter_spacing, $bg_text_marque_font_style,$bg_text_marque_google_font);
}
// Add responsive CSS
$responsive_unique_class_2 = uniqid('bg-text-responsive-');
if($use_bg_text_marque_responsive_typo && isset($bg_text_marque_reaponsive_typography) && $bg_text_marque_reaponsive_typography != '') {
	
	$custom_el_css .= DPR_Resposive_Typography_Param::generate_css($bg_text_marque_reaponsive_typography,'.'.$responsive_unique_class_2);
}

$output .= '<div class="dpr_row_bg_container valign-'.esc_attr($bg_text_marque_vpos).'">';

		$output .= $overlay_output;

		$output .= '<div id="'.esc_attr($uniqid).'" class="dpr_row_bg_container_inner dpr_row_text_marque" '.$bg_wrap_data_atts.'>';
		
		$output .= '<div class="marque-wrapper">';
		
		$output .= '<h1 class="'.$responsive_unique_class_2.'" ' . $bg_text_marque_typo_style . '>'.wp_kses_post($bg_marque_text).'</h1>';

		$output .= '</div>';
		
		$output .= '</div>';
	
	
$output .= '</div>';
}

if(isset($marque_type) && $marque_type == 'image') {
wp_enqueue_script('jquery-simplyscroll', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/jquery.simplyscroll.min.js', array('jquery'), null, true);	
wp_enqueue_script('dpr-row-image-marque', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/dpr.row.image.marque.js', array('jquery'), null, false);	

$bg_wrap_data_atts = '';

if(isset($bg_image_marque_direction) && $bg_image_marque_direction != '') {
	$bg_wrap_data_atts .= ' data-direction="'.$bg_image_marque_direction.'"';
}
if(isset($bg_image_marque_speed) && $bg_image_marque_speed != '') {
	$bg_wrap_data_atts .= ' data-speed="'.$bg_image_marque_speed.'"';
} else {
	$bg_wrap_data_atts .= ' data-speed="30"';
}
if(isset($bg_image_marque_stop_onhover) && $bg_image_marque_stop_onhover == 'yes') {
	$bg_wrap_data_atts .= ' data-onhover="yes"';
} else {
	$bg_wrap_data_atts .= ' data-onhover="no"';
}


	
$uniqid = uniqid('dpr-bg-wrapper-');

if ( '' === $marque_images ) {
	$marque_images = '-1,-2,-3';
}
$marque_images = explode( ',', $marque_images );
	
	
$output .= '<div class="dpr_row_bg_container">';

		//$output .= $overlay_output;

		$output .= '<div id="'.esc_attr($uniqid).'" class="dpr_row_bg_container_inner dpr_row_image_marque simply-scroll-container" '.$bg_wrap_data_atts.'>';
	
			$output .= '<div class="simply-scroll-clip">';

				$output .= '<ul class="simply-scroll-list">';

					foreach ( $marque_images as $i => $image ) {
						if ( $image > 0 ) {
								$img = dpr_get_attachment_image_src( $image,'full');
							
								$large_img_src = $img[0];				

								$output .= '<li>';
							
								$output .=  '<img class="marque-img" src="'.esc_url($large_img_src).'"/>';				
								$output .= '</li>';
							
						}
					}

				$output .= '</ul>';

			$output .= '</div>';		

		$output .= '</div>';

		$output .= $overlay_output;
	
$output .= '</div>';
}

