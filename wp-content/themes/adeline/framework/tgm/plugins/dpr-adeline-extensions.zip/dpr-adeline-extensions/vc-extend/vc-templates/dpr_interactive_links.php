<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$output = $id = $el_class = $custom_el_css = $style = $source_type = $custom_list = $blog_list = $portfolio_list = $link_pos = $subtitle_pos = $css = '';
$title_color = $title_font_size = $title_line_height  = $title_letter_spacing = $title_font_style = $title_google_font = $title_typo_style = $title_color_hover = $title_stroke_width = $title_stroke_color = $title_stroke_color_hover = '';
$subtitle_color = $subtitle_font_size = $subtitle_line_height  = $subtitle_letter_spacing = $subtitle_font_style = $subtitle_google_font = $subtitle_typo_style = $subtitle_color_hover = '';
$use_title_responsive_typo = $title_reaponsive_typography = $use_subtitle_responsive_typo = $subtitle_reaponsive_typography = '';
$display_category=$display_date = '';
$link_pos_aside = $aside_image_width = $aside_image_height = $aside_image_margin = $reveal_image = $reveal_color = '';
$link_pos_satelite = $satelite_image_width = '';
$links_left_margin = $animate_subtitle = '';
$atts = vc_map_get_attributes($this->getShortcode(), $atts);
extract( $atts );


	$id = uniqid('dpr-interactive-links-');
		
	wp_enqueue_script('interactive-links', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/dpr.interactive.links.js', array('jquery'), null, false);	
	if ($style == 'satelite-image') {
		wp_enqueue_script('mousefollow', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/jquery.mousefollow.js', array('jquery'), null, false);	
	}
	
	
	/* Element classes */
	if(isset($source_type)) {
		$el_class .= ' source-'.$source_type;
	}

	if(isset($links_pos) && !empty($links_pos)) {
		$el_class .= ' links-'.$links_pos;
	}

	if(isset($links_pos_aside) && !empty($links_pos_aside)) {
	   $el_class .= ' links-'.$links_pos_aside;
	}

	if(isset($links_pos_satelite) && !empty($links_pos_satelite)) {
	   $el_class .= ' links-'.$links_pos_satelite;
	}


	if(isset($links_pos) && ($links_pos == 'horizontal-center' || $links_pos == 'horizontal-bottom')) {
		$el_class .= ' '.$links_alignment;
	}

	if(!empty($reveal_image == 'yes')) {
	   $el_class .= ' reveal-effect';
	}
	if(!empty($animate_subtitle == 'yes')) {
		   $el_class .= ' animated-subtitle';
		}
	$css_classes = array(
		'dpr-ilinks-wrapper',
		'style-'.esc_attr($style),
		esc_attr($id),
		$el_class,
		vc_shortcode_custom_css_class( $css ),
	);

	$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->settings['base'], $atts ) );

	// Custom CSS stuff
	$title_text_typo_css = dpr_generate_typography_css($title_color, $title_font_size, $title_line_height, $title_letter_spacing, $title_font_style, $title_google_font);
	$subtitle_text_typo_css = dpr_generate_typography_css($subtitle_color, $subtitle_font_size, $subtitle_line_height, $subtitle_letter_spacing, $subtitle_font_style, $subtitle_google_font);
	if (isset($title_stroke_width) && $title_stroke_width !='' ) {
		$title_text_typo_css .= '-webkit-text-stroke-width: '.$title_stroke_width.'px;';
	}
	if (isset($title_stroke_color) && $title_stroke_color !='' ) {
		$title_text_typo_css .= '-webkit-text-stroke-color: '.$title_stroke_color.';';
	}
	if(isset($title_text_typo_css) && !empty($title_text_typo_css)) {
		$custom_el_css .= '.'.esc_js($id).'.dpr-ilinks-wrapper .dpr-ilinks-item-link h1 {'.esc_js($title_text_typo_css).'}';
	}
	if(isset($title_color_hover)){
		$custom_el_css .= '.'.esc_js($id).'.dpr-ilinks-wrapper .dpr-ilinks-item-link:hover h1, .'.esc_js($id).'.dpr-ilinks-wrapper .dpr-ilinks-item-link.dpr-active h1 {color:'.esc_js($title_color_hover).'}';
	}
	if(isset($title_stroke_color_hover) && $title_stroke_color_hover != ''){
		$custom_el_css .= '.'.esc_js($id).'.dpr-ilinks-wrapper .dpr-ilinks-item-link:hover h1, .'.esc_js($id).'.dpr-ilinks-wrapper .dpr-ilinks-item-link.dpr-active h1 {-webkit-text-stroke-color:'.esc_js($title_stroke_color_hover).'}';
	}
	if(isset($subtitle_text_typo_css) && !empty($subtitle_text_typo_css)) {
		$custom_el_css .= '.'.esc_js($id).'.dpr-ilinks-wrapper .dpr-ilinks-item-link h5 {'.esc_js($subtitle_text_typo_css).'}';
	}
	if(isset($subtitle_color_hover) && $subtitle_color_hover != ''){
		$custom_el_css .= '.'.esc_js($id).'.dpr-ilinks-wrapper .dpr-ilinks-item-link:hover h5, .'.esc_js($id).'.dpr-ilinks-wrapper .dpr-ilinks-item-link.dpr-active h5 {color:'.esc_js($subtitle_color_hover).'}';
	}
	//Aside image style //

	if(isset($aside_image_width) && !empty($aside_image_width)){
		$custom_el_css .= '.'.esc_js($id).'.dpr-ilinks-wrapper.style-aside-image .dpr-ilinks-image-wrapper  {max-width:'.esc_js($aside_image_width).'%;}';
	}
	if(isset($aside_image_height) && !empty($aside_image_height)){
		$aside_image_top_margin = (100 - $aside_image_height)/2;
		$custom_el_css .= '.'.esc_js($id).'.dpr-ilinks-wrapper.style-aside-image .dpr-ilinks-image-wrapper  {max-height:'.esc_js($aside_image_height).'%;margin-top:'.esc_js($aside_image_top_margin).'vh}';
	}	
	if(isset($aside_image_margin) && !empty($aside_image_margin)){
		if($links_pos_aside =='vertical-left') {
		$custom_el_css .= '.'.esc_js($id).'.dpr-ilinks-wrapper.style-aside-image .dpr-ilinks-image-wrapper  {margin-right:'.esc_js($aside_image_margin).'%;}';			
		} else {
		$custom_el_css .= '.'.esc_js($id).'.dpr-ilinks-wrapper.style-aside-image .dpr-ilinks-image-wrapper  {margin-left:'.esc_js($aside_image_margin).'%;}';						
		}
	}
	if(isset($reveal_color) && !empty($reveal_color)){
		$custom_el_css .= '.'.esc_js($id).'.dpr-ilinks-wrapper .dpr-ilinks-image-wrapper .dpr-ilinks-image-overlay  {background-color:'.esc_js($reveal_color).';}';
	}
	if(isset($links_left_margin) && !empty($links_left_margin)){
		$custom_el_css .= '.'.esc_js($id).'.dpr-ilinks-wrapper .dpr-ilinks-item-content  {margin-left:'.esc_js($links_left_margin).';}';
	}
// Add responsive CSS

if($use_title_responsive_typo && isset($title_reaponsive_typography) && $title_reaponsive_typography != '') {
	$responsive_unique_class = '.'.esc_js($id).'.dpr-ilinks-wrapper .dpr-ilinks-item-link h1';
	$custom_el_css .= DPR_Resposive_Typography_Param::generate_css($title_reaponsive_typography,$responsive_unique_class);
}
if($use_subtitle_responsive_typo && isset($subtitle_reaponsive_typography) && $subtitle_reaponsive_typography != '') {
	$responsive_unique_class = '.'.esc_js($id).'.dpr-ilinks-wrapper .dpr-ilinks-item-link h5';
	$custom_el_css .= DPR_Resposive_Typography_Param::generate_css($subtitle_reaponsive_typography,$responsive_unique_class);
}

/* Generate Output */

	$output .= '<div id="'.esc_attr($id).'" class="'.esc_attr($css_class).'">';
	
	switch ($source_type) {
		
		case "custom":
			
			 $custom_list = (array) vc_param_group_parse_atts($custom_list);
			 if ( ! empty( $custom_list ) ) { 
				$output .= '<div class="dpr-ilinks-image-wrapper">';
				  	if ($style == 'aside-image' && $reveal_image == 'yes') {
						$output .= '<span class="dpr-ilinks-image-overlay"></span>';
					}
					foreach ( $custom_list as $link_item ): 
							if ( isset( $link_item['image_id'] ) ) { 
								$image_url = wp_get_attachment_url( $link_item['image_id'] );
								$item_style   = 'style="background-image: url(' . $image_url . ');"';
								$output .= '<div class="dpr-ilinks-item-image" '.$item_style.'>';
								if($style == 'satelite-image') {
									$swidth = 300;
									if(isset($satelite_image_width) && !empty($satelite_image_width)) {
									 $swidth = $satelite_image_width;
									}
									$output .='<div style="width:'.esc_attr($swidth).'px">';
								}								
								$output .=	 wp_get_attachment_image( $link_item['image_id'], 'full' ); 
								if($style == 'satelite-image') {
									$output .='</div>';
								}										
								$output .= '</div>';
							} 
					endforeach;
				$output .= '</div>';
				$output .= '<div class="dpr-ilinks-content-wrapper">';
					$output .= '<div class="dpr-ilinks-content-inner">';
						$output .= '<div class="dpr-ilinks-item-content">';

								$i = 0;

								foreach ( $custom_list as $link_item ):
								  if ( isset( $link_item['link_title'] ) ) {
									$link_url = $link_target = $link_rel = '';
									if(isset($link_item['link'])) {
										$link = vc_build_link($link_item['link']);
										$link_target = !empty($link['target']) ? 'target="'.esc_attr(preg_replace('/\s+/', '', $link['target'])).'"' : '';
										$link_url = $link['url'];
										$link_rel = $link['rel'];
									}
									$output .= '<div class="dpr-ilinks-item-link-wrapper">';
										$output .= '<a itemprop="url" class="dpr-ilinks-item-link" data-index="'. esc_attr($i).'" href="'.$link_url.'" '.$link_target.' rel="'.$link_rel.'">';
									  	if ($subtitle_pos == 'above' && isset($link_item['link_subtitle'])) {
										$output .= '<h5 class="dpr-ilinks-item-subtitle">'. esc_html( $link_item['link_subtitle'] ) .'</h5>';
										}
									  	$output .= '<h1 class="dpr-ilinks-item-title">'. esc_html( $link_item['link_title'] ) .'</h1>';
									  	if ($subtitle_pos == 'bellow' && isset($link_item['link_subtitle'])) {									  
									  	$output .= '<h5 class="dpr-ilinks-item-subtitle">'. esc_html( $link_item['link_subtitle'] ) .'</h5>';
										}
										$output .= '</a>';
									 $output .= '</div>';

								$i++;
								} 
							 endforeach;
						$output .= '</div>';
					$output .= '</div>';
				$output .= '</div>';
			 } 

			break;
		
		case "blog":
			
			 $blog_list = (array) vc_param_group_parse_atts($blog_list);
			 if ( ! empty( $blog_list ) ) { 
				$output .= '<div class="dpr-ilinks-image-wrapper">';
				  	if ($style == 'aside-image' && $reveal_image == 'yes') {
						$output .= '<span class="dpr-ilinks-image-overlay"></span>';
					}			 
					foreach ( $blog_list as $link_item ): 
							if ( isset( $link_item['post_item'] ) ) { 
								$image_url = wp_get_attachment_url( get_post_thumbnail_id($link_item['post_item']), 'full' );
								$item_style   = 'style="background-image: url(' . $image_url . ')"';
								$output .= '<div class="dpr-ilinks-item-image" '.$item_style.'>';
								if($style == 'satelite-image') {
									$swidth = 300;
									if(isset($satelite_image_width) && !empty($satelite_image_width)) {
									 $swidth = $satelite_image_width;
									}
									$output .='<div style="width:'.esc_attr($swidth).'px">';
								}								
								$output .=	get_the_post_thumbnail( $link_item['post_item'], 'full' ); 
								if($style == 'satelite-image') {
									$output .='</div>';
								}										
								
								$output .= '</div>';
							} 
					endforeach;
				$output .= '</div>';
				$output .= '<div class="dpr-ilinks-content-wrapper">';
					$output .= '<div class="dpr-ilinks-content-inner">';
						$output .= '<div class="dpr-ilinks-item-content">';

								$i = 0;

								foreach ( $blog_list as $link_item ):
				 				$post_meta = '';
				 				if ( isset( $link_item['link_title']) && $link_item['link_title'] != '') {
									$post_title = $link_item['link_title'];
								} else {
									$post_title = get_the_title($link_item['post_item']);							
								}
				 				if($display_date) {
									$post_meta .= get_the_date( 'd M, Y', $link_item['post_item'] ).'&nbsp;&nbsp;';
								}
				 				if($display_category) {
									$cats = array();
									foreach (get_the_category($link_item['post_item']) as $c) {
									$cat = get_category($c);
									array_push($cats, $cat->name);
									}

									if (sizeOf($cats) > 0) {
									$post_categories = implode(', ', $cats);
									$post_meta .= '<i class="Default-Folders"></i>&nbsp;'.$post_categories;
									} 
									
									
								}
								if ( isset( $post_title ) ) { 
									$output .= '<div class="dpr-ilinks-item-link-wrapper">';
										$output .= '<a itemprop="url" class="dpr-ilinks-item-link" data-index="'. esc_attr($i).'" href="'.esc_url( get_permalink($link_item['post_item'])).'" target="'.esc_attr($link_target).'">';
											if ($subtitle_pos == 'above' && isset($link_item['link_subtitle'])) {
											$output .= '<h5 class="dpr-ilinks-item-subtitle">'. esc_html( $link_item['link_subtitle'] ) .'</h5>';
												
											}	else if($post_meta !='' && $subtitle_pos == 'bellow') {
											$output .= '<h5 class="dpr-ilinks-item-subtitle meta">'. wp_kses_post($post_meta ) .'</h5>';
											}								
											$output .= '<h1 class="dpr-ilinks-item-title">'. esc_html( $post_title ) .'</h1>';
											if ($subtitle_pos == 'bellow' && isset($link_item['link_subtitle'])) {									  
											$output .= '<h5 class="dpr-ilinks-item-subtitle">'. esc_html( $link_item['link_subtitle'] ) .'</h5>';
											}	else if ($post_meta !='' && $subtitle_pos == 'above') {
											$output .= '<h5 class="dpr-ilinks-item-subtitle meta">'. wp_kses_post($post_meta ) .'</h5>';
											}									
										$output .= '</a>';
									 $output .= '</div>';

								$i++;
								} 
				 
							 endforeach;
						$output .= '</div>';
					$output .= '</div>';
				$output .= '</div>';
			 } 

			break;
		
		case "portfolio":
			 $portfolio_list = (array) vc_param_group_parse_atts($portfolio_list);
			 if ( ! empty( $portfolio_list ) ) { 
				$output .= '<div class="dpr-ilinks-image-wrapper">';
				  	if ($style == 'aside-image' && $reveal_image == 'yes') {
						$output .= '<span class="dpr-ilinks-image-overlay"></span>';
					}
					foreach ( $portfolio_list as $link_item ): 
							if ( isset( $link_item['portfolio_item'] ) ) { 
								$image_url = wp_get_attachment_url( get_post_thumbnail_id($link_item['portfolio_item']), 'full' );
								$item_style   = 'style="background-image: url(' . $image_url . ')"';
								$output .= '<div class="dpr-ilinks-item-image" '.$item_style.'>';
								if($style == 'satelite-image') {
									$swidth = 300;
									if(isset($satelite_image_width) && !empty($satelite_image_width)) {
									 $swidth = $satelite_image_width;
									}
									$output .='<div style="width:'.esc_attr($swidth).'px">';
								}								
								$output .=	get_the_post_thumbnail( $link_item['portfolio_item'], 'full' );
								if($style == 'satelite-image') {
									$output .='</div>';
								}										
								
								$output .= '</div>';
							} 
					endforeach;
				$output .= '</div>';
				$output .= '<div class="dpr-ilinks-content-wrapper">';
					$output .= '<div class="dpr-ilinks-content-inner">';
						$output .= '<div class="dpr-ilinks-item-content">';

								$i = 0;

								foreach ( $portfolio_list as $link_item ):
				 				$post_meta = '';
				 				if($display_category) {
									$category = get_the_terms( $link_item['portfolio_item'], 'dpr_portfolio_category' );
									foreach ( $category as $cat){
									   $post_meta .= $cat->name . ',';
									} 
									$post_meta = substr_replace($post_meta, "", -1); 									
									
								} 
				 				if ( isset( $link_item['link_title']) && $link_item['link_title'] != '') {
									$post_title = $link_item['link_title'];
								} else {
									$post_title = get_the_title($link_item['portfolio_item']);							
								}			 
								if ( isset( $post_title ) ) { 
									$output .= '<div class="dpr-ilinks-item-link-wrapper">';
										$output .= '<a itemprop="url" class="dpr-ilinks-item-link" data-index="'. esc_attr($i).'" href="'.esc_url( get_permalink($link_item['portfolio_item'])).'" target="'.esc_attr($link_target).'">';
											if ($subtitle_pos == 'above' && isset($link_item['link_subtitle'])) {
											$output .= '<h5 class="dpr-ilinks-item-subtitle">'. esc_html( $link_item['link_subtitle'] ) .'</h5>';
											} 	elseif ($post_meta !='' && $subtitle_pos == 'bellow' ) {
											$output .= '<h5 class="dpr-ilinks-item-subtitle meta">'. wp_kses_post($post_meta ) .'</h5>';
											}									
											$output .= '<h1 class="dpr-ilinks-item-title">'. esc_html( $post_title ) .'</h1>';
											if ($subtitle_pos == 'bellow' && isset($link_item['link_subtitle'])) {									  
											$output .= '<h5 class="dpr-ilinks-item-subtitle">'. esc_html( $link_item['link_subtitle'] ) .'</h5>';
											} 	elseif ($post_meta !='' && $subtitle_pos == 'above') {
											$output .= '<h5 class="dpr-ilinks-item-subtitle meta">'. wp_kses_post($post_meta ) .'</h5>';
											}									
										$output .= '</a>';
									 $output .= '</div>';

								$i++;
								} 
				 
							 endforeach;
						$output .= '</div>';
					$output .= '</div>';
				$output .= '</div>';
			 } 

			break;
			
	}
	





		if($custom_el_css != '') {
			$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>")'
						. '})(jQuery);'
					. '</script>';
		}




	$output .= '</div>';

echo $output;