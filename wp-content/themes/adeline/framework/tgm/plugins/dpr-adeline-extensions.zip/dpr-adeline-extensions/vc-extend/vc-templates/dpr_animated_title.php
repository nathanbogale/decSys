<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$output = $unique_id = $animation_direction = $title_position = $el_class = $custom_el_css = '';
$title = $subtitle = $alignment = $title_bg_color = $subtitle_bg_color = $title_top_bottom_padding = $title_left_right_padding = $subtitle_top_bottom_padding = $subtitle_left_right_padding = $equalize_width = $vertical_space = '';
$headline_color = $headline_font_size = $headline_line_height  = $headline_letter_spacing = $headline_font_style = $headline_google_font = $headline_typo_style = '';
$subtitle_color = $subtitle_font_size = $subtitle_line_height  = $subtitle_letter_spacing = $subtitle_font_style = $subtitle_google_font = $subtitle_typo_style = '';
$use_hedline_responsive_typo = $headline_reaponsive_typography = $use_subtitle_responsive_typo = $subtitle_reaponsive_typography = '';
$headline_html = $subtitle_html = $separator_html = '';

$atts = vc_map_get_attributes( 'dpr_animated_title', $atts );
extract( $atts );
wp_enqueue_script('dpr-animated-title', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/dpr.animated.title.js', array('jquery'), null, false);	
wp_enqueue_script('dpr-waypoints', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/waypoints.min.js', array('jquery'), null, true);


$unique_id = uniqid('dpr-animated-title-').'-'.rand(1,9999);

$el_class .= ' animate-'.$animation_direction.' '.$unique_id;

if (!empty($alignment)) {
	$el_class .= ' '.$alignment;
}

if (!empty($title_position)) {
	$el_class .= ' '.$title_position;
}
if ($equalize_width =='yes') {
	$el_class .= ' equalized-width';
}


// Headline HTML
if (!empty($title)) {
	$headline_typo_style = dpr_generate_typography_style($headline_color, $headline_font_size, $headline_line_height, $headline_letter_spacing, $headline_font_style,$headline_google_font);
	$headline_html .= '<h3 class="dpr-headline" ' . $headline_typo_style . '>';
	$headline_html .= '<span class="title-wrapper animation-wrapper"><span class="movable-element">' . wpb_js_remove_wpautop($title) . '</span></span>';
	$headline_html .= '</h3>';
}

// Subtitle HTML
if (!empty($subtitle)) {
	$subtitle_typo_style = dpr_generate_typography_style($subtitle_color, $subtitle_font_size, $subtitle_line_height, $subtitle_letter_spacing, $subtitle_font_style,$subtitle_google_font);
	$subtitle_html .= '<div class="dpr-heading-subtitle" ' . $subtitle_typo_style . '>';
	$subtitle_html .= '<span class="subtitle-wrapper animation-wrapper"><span class="movable-element">' . esc_html($subtitle) . '</span></span>';
	$subtitle_html .= '</div>';
}
// Separator HTML
	$vertical_gap_style = '';
	if(isset($vertical_space) && $vertical_space != '') {
		$vertical_gap_style = ' style="height: '.esc_js($vertical_space).'px;"';
	}
	$separator_html .= '<div class"vertical-gap"'.$vertical_gap_style.'></div>';

// Custom CSS stuff
if(isset($title_bg_color) && !empty($title_bg_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .title-wrapper.animation-wrapper {background: '.esc_js($title_bg_color).';}';
}
if(isset($subtitle_bg_color) && !empty($subtitle_bg_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .subtitle-wrapper.animation-wrapper {background: '.esc_js($subtitle_bg_color).';}';
}
if(isset($title_top_bottom_padding) && !empty($title_top_bottom_padding)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .title-wrapper.animation-wrapper  .movable-element {padding-top: '.esc_js($title_top_bottom_padding).'px; padding-bottom: '.esc_js($title_top_bottom_padding).'px;}';
}
if(isset($title_left_right_padding) && !empty($title_left_right_padding)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .title-wrapper.animation-wrapper  .movable-element {padding-right: '.esc_js($title_left_right_padding).'px; padding-left: '.esc_js($title_left_right_padding).'px;}';
}
if(isset($subtitle_top_bottom_padding) && !empty($subtitle_top_bottom_padding)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .subtitle-wrapper.animation-wrapper .movable-element {padding-top: '.esc_js($subtitle_top_bottom_padding).'px; padding-bottom: '.esc_js($subtitle_top_bottom_padding).'px;}';
}
if(isset($subtitle_left_right_padding) && !empty($subtitle_left_right_padding)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .subtitle-wrapper.animation-wrapper .movable-element {padding-right: '.esc_js($subtitle_left_right_padding).'px; padding-left: '.esc_js($subtitle_left_right_padding).'px;}';
}
if(isset($title_border_radius) && !empty($title_border_radius)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .title-wrapper.animation-wrapper {border-radius: '.esc_js($title_border_radius).'px;}';
}
if(isset($subtitle_border_radius) && !empty($subtitle_border_radius)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .subtitle-wrapper.animation-wrapper {border-radius: '.esc_js($subtitle_border_radius).'px}';
}


// Add responsive CSS

if($use_hedline_responsive_typo && isset($headline_reaponsive_typography) && $headline_reaponsive_typography != '') {
	$responsive_unique_class = '.'.esc_js($unique_id) .' .dpr-headline';
	$custom_el_css .= DPR_Resposive_Typography_Param::generate_css($headline_reaponsive_typography,$responsive_unique_class);
}
if($use_subtitle_responsive_typo && isset($subtitle_reaponsive_typography) && $subtitle_reaponsive_typography != '') {
	$responsive_unique_class = '.'.esc_js($unique_id) .' .dpr-heading-subtitle';
	$custom_el_css .= DPR_Resposive_Typography_Param::generate_css($subtitle_reaponsive_typography,$responsive_unique_class);
}

$output .= '<div id="' . esc_attr($unique_id) . '" class="dpr-heading-wrapper dpr-animated-title call-on-in-viewport'.esc_attr($el_class).'">';
$output .= '<div class="dpr-heading-inner-wrapper">';
$output .= '<div class="dpr-heading">';
if($title_position =='title-top') {
	$output .= $headline_html;
	$output .= $separator_html;
	$output .= $subtitle_html;
} else {
	$output .= $subtitle_html;
	$output .= $separator_html;
	$output .= $headline_html;
}

$output .= '</div>';
$output .= '</div>';

	if(!empty($custom_el_css)) {
		$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>");'
						. '})(jQuery);'
					. '</script>';
}
$output .= '</div>';



echo $output;