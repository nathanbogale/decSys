<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
/*
Heading style
*/
$output .= '<div class="headline-wrap">';
$output .= $headline_html;
$output .= $separator_html;
$output .= '</div>';
$output .= $subtitle_html;