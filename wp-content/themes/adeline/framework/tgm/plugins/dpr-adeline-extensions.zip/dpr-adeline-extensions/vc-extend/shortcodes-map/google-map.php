<?php

if ( ! defined( 'ABSPATH' ) ) { exit; }



class WPBakeryShortCode_DPR_Google_Map extends WPBakeryShortCode {}



vc_map(

	array(

		'name'					=> esc_html__('DP Google Map', 'dpr-adeline-extensions'),

		'base'					=> 'dpr_google_map',

		'class'					=> '',

		'icon'					=> 'icon-dpr-google-map',

  		"category" =>array( esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions')),

		"description" => esc_attr__('Display Google map with locations pins', 'dpr-adeline-extensions'),

		'params'	=> array(

			array(

				'heading'			=> esc_html__('Style', 'dpr-adeline-extensions'),

				'type'				=> 'dpr_image_select',

				'param_name'		=> 'style',

				'value' => '',

				'options'			=> array(

					''	=> array(

						'label'	=> esc_html__('Default Google','dpr-adeline-extensions'),

						'src'		=> $module_images . 'google-map/default.jpg'

					),

					'ultra_light'	=> array(

						'label'	=> esc_html__('Ultra Light','dpr-adeline-extensions'),

						'src'		=> $module_images . 'google-map/ultra_light.jpg'

					),

					'subtle_grayscale'	=> array(

						'label'	=> esc_html__('Subtle Grayscale','dpr-adeline-extensions'),

						'src'		=> $module_images . 'google-map/subtle_grayscale.jpg'

					),

					'dark_gray'	=> array(

						'label'	=> esc_html__('Dark Gray','dpr-adeline-extensions'),

						'src'		=> $module_images . 'google-map/dark_gray.jpg'

					),

					'fresh'	=> array(

						'label'	=> esc_html__('Fresh','dpr-adeline-extensions'),

						'src'		=> $module_images . 'google-map/fresh.jpg'

					),

					'pastel'	=> array(

						'label'	=> esc_html__('Pastel','dpr-adeline-extensions'),

						'src'		=> $module_images . 'google-map/pastel.jpg'

					),

					'shades_of_blue'	=> array(

						'label'	=> esc_html__('Shades of blue','dpr-adeline-extensions'),

						'src'		=> $module_images . 'google-map/shades_of_blue.jpg'

					),

					'vintage'	=> array(

						'label'	=> esc_html__('Vintage','dpr-adeline-extensions'),

						'src'		=> $module_images . 'google-map/vintage.jpg'

					),

					'apple_maps'	=> array(

						'label'	=> esc_html__('Apple Maps Style','dpr-adeline-extensions'),

						'src'		=> $module_images . 'google-map/apple_maps.jpg'

					),

					'pale_classic'	=> array(

						'label'	=> esc_html__('Pale Classic','dpr-adeline-extensions'),

						'src'		=> $module_images . 'google-map/pale_classic.jpg'

					),

					'pale_purple'	=> array(

						'label'	=> esc_html__('Pale Purple','dpr-adeline-extensions'),

						'src'		=> $module_images . 'google-map/pale_purple.jpg'

					),

					'blue_watter'	=> array(

						'label'	=> esc_html__('Blue Watter','dpr-adeline-extensions'),

						'src'		=> $module_images . 'google-map/blue_watter.jpg'

					),

					'custom'	=> array(

						'label'	=> esc_html__('Custom','dpr-adeline-extensions'),

						'src'		=> $module_images . 'google-map/custom.jpg'

					),

				),

			),

            array(

                'type'       => 'textarea_raw_html',

                'heading'    => esc_html__('Map Custom Style', 'dpr-adeline-extensions'),

                'param_name' => 'map_custom_style',

				'dependency'		=> array('element' => 'style', 'value' => array('custom')),

                'description'        => 'Custom map theme in JSON format. For more themes see <a href=\"http://snazzymaps.com/\" target=\"_blank\">http://snazzymaps.com</a>',

                'value'      => '',

            ),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Additional Settings', 'dpr-adeline-extensions' ),

				'param_name'       => 'extra_features_title',

				'edit_field_class' => 'vc_column vc_col-sm-12',

			),

		   vc_map_add_css_animation( false ),

		    array(

				'type' => 'textfield',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Extra Class Name', 'dpr-adeline-extensions'),

				'param_name' => 'el_class',

			),

			array(

				'type'				=> 'param_group',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Add locations bellow.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Locations List', 'dpr-adeline-extensions'),

				'param_name'		=> 'markers_list',

				'value' => '%5B%7B%22located_by%22%3A%22address%22%2C%22location_address%22%3A%2275004%20Paris%2C%20France%22%2C%22marker_img%22%3A%22red%22%7D%5D',

				'params'			=> array(

					array (

						'type' => 'dpr_radio',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set how location will be determined, by address or by setting latitude and longtitude.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Location determined by:', 'dpr-adeline-extensions'),

						'value' => 'address',

						'options' => array (

							esc_attr__('by Address', 'dpr-adeline-extensions') => 'address',

							esc_attr__('by Latitude & Longtitude', 'dpr-adeline-extensions') => 'lat_long'

						),

						'param_name' => 'located_by',

					),

					array(

						'type'				=> 'textfield',

						'heading'			=> esc_html__('Address', 'dpr-adeline-extensions'),

						'param_name'		=> 'location_address',

						"suffix"=>"%",

						'edit_field_class'	=> 'vc_column vc_col-sm-12',

						'admin_label' => true,

						'dependency' => array ('element' => 'located_by', 'value' => array ('address')),

						'description' => esc_html__('Please, enter the location address. For example ', 'dpr-adeline-extensions')

					),

					array(

						'type'				=> 'textfield',

						'heading'			=> esc_html__('Longtitude', 'dpr-adeline-extensions'),

						'param_name'		=> 'location_long',

						"suffix"=>"%",

						'edit_field_class'	=> 'vc_column vc_col-sm-6',

						'admin_label' => true,

						'dependency' => array ('element' => 'located_by', 'value' => array ('lat_long')),

						'description' => esc_html__('Please, enter the location longtitude', 'dpr-adeline-extensions')

					),

					array(

						'type'				=> 'textfield',

						'heading'			=> esc_html__('Latitude', 'dpr-adeline-extensions'),

						'param_name'		=> 'location_lat',

						"suffix"=>"%",

						'edit_field_class'	=> 'vc_column vc_col-sm-6',

						'admin_label' => true,

						'dependency' => array ('element' => 'located_by', 'value' => array ('lat_long')),

						'description' => esc_html__('Please, enter the location latitude', 'dpr-adeline-extensions')

					),

					array(

						'heading'			=> esc_html__('Marker', 'dpr-adeline-extensions'),

						'type'				=> 'dpr_image_select',

						'param_name'		=> 'marker_img',

						'value' => 'red',

						'options'			=> array(

							'purple'	=> array(

								'label'	=> '',

								'src'		=> $module_images . 'google-map/markers/purple.png'

							),

							'green'	=> array(

								'label'	=> '',

								'src'		=> $module_images . 'google-map/markers/green.png'

							),

							'yellow'	=> array(

								'label'	=> '',

								'src'		=> $module_images . 'google-map/markers/yellow.png'

							),

							'amber'	=> array(

								'label'	=> '',

								'src'		=> $module_images . 'google-map/markers/amber.png'

							),

							'orange'	=> array(

								'label'	=> '',

								'src'		=> $module_images . 'google-map/markers/orange.png'

							),

							'red'	=> array(

								'label'	=> '',

								'src'		=> $module_images . 'google-map/markers/red.png'

							),

							'pink'	=> array(

								'label'	=> '',

								'src'		=> $module_images . 'google-map/markers/pink.png'

							),

							'cyan'	=> array(

								'label'	=> '',

								'src'		=> $module_images . 'google-map/markers/cyan.png'

							),

							'blue'	=> array(

								'label'	=> '',

								'src'		=> $module_images . 'google-map/markers/blue.png'

							),

							'indigo'	=> array(

								'label'	=> '',

								'src'		=> $module_images . 'google-map/markers/indigo.png'

							),

							'teal'	=> array(

								'label'	=> '',

								'src'		=> $module_images . 'google-map/markers/teal.png'

							),

							'brown'	=> array(

								'label'	=> '',

								'src'		=> $module_images . 'google-map/markers/brown.png'

							),

							'gray'	=> array(

								'label'	=> '',

								'src'		=> $module_images . 'google-map/markers/gray.png'

							),

							'bluegray'	=> array(

								'label'	=> '',

								'src'		=> $module_images . 'google-map/markers/bluegray.png'

							),

							'purple1'	=> array(

								'label'	=> '',

								'src'		=> $module_images . 'google-map/markers/purple1.png'

							),

							'green1'	=> array(

								'label'	=> '',

								'src'		=> $module_images . 'google-map/markers/green1.png'

							),

							'yellow1'	=> array(

								'label'	=> '',

								'src'		=> $module_images . 'google-map/markers/yellow1.png'

							),

							'amber1'	=> array(

								'label'	=> '',

								'src'		=> $module_images . 'google-map/markers/amber1.png'

							),

							'orange1'	=> array(

								'label'	=> '',

								'src'		=> $module_images . 'google-map/markers/orange1.png'

							),

							'red1'	=> array(

								'label'	=> '',

								'src'		=> $module_images . 'google-map/markers/red1.png'

							),

							'pink1'	=> array(

								'label'	=> '',

								'src'		=> $module_images . 'google-map/markers/pink1.png'

							),

							'cyan1'	=> array(

								'label'	=> '',

								'src'		=> $module_images . 'google-map/markers/cyan1.png'

							),

							'blue1'	=> array(

								'label'	=> '',

								'src'		=> $module_images . 'google-map/markers/blue1.png'

							),

							'indigo1'	=> array(

								'label'	=> '',

								'src'		=> $module_images . 'google-map/markers/indigo1.png'

							),

							'teal1'	=> array(

								'label'	=> '',

								'src'		=> $module_images . 'google-map/markers/teal1.png'

							),

							'brown1'	=> array(

								'label'	=> '',

								'src'		=> $module_images . 'google-map/markers/brown1.png'

							),

							'gray1'	=> array(

								'label'	=> '',

								'src'		=> $module_images . 'google-map/markers/gray1.png'

							),

							'bluegray1'	=> array(

								'label'	=> '',

								'src'		=> $module_images . 'google-map/markers/bluegray1.png'

							),

							'custom'	=> array(

								'label'	=> '',

								'src'		=> $module_images . 'google-map/markers/custom.png'

							),

						),

					),

					array (

						'type' => 'attach_image',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Upload the custom image from media library.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom Marker Image', 'dpr-adeline-extensions'),

						'param_name' => 'marker_image_id',

						'dependency' => array ('element' => 'marker_img', 'value' => array ('custom')),

						'edit_field_class' => 'vc_column vc_col-sm-6',

					),

					array(

						'type'				=> 'dpr_switcher',

						'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable tooltip for this location.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Enable Tooltip?', 'dpr-adeline-extensions'),

						'param_name'		=> 'enable_tooltip',

						'edit_field_class'	=> 'vc_column vc_col-sm-12',

						'options'			=> array(

							'yes'				=> array(

								'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

								'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

							),

						)

					),

					array(

						'type'				=> 'textfield',

						'heading'			=> esc_html__('Title', 'dpr-adeline-extensions'),

						'param_name'		=> 'tooltip_title',

						'edit_field_class'	=> 'vc_column vc_col-sm-12',

						'admin_label' => true,

						'dependency' => array ('element' => 'enable_tooltip', 'value' => array ('yes')),

						'description' => esc_html__('Please, enter tooltip title', 'dpr-adeline-extensions')

					),

					array(

						'type'				=> 'textarea',

						'heading'			=> esc_html__('Tooltip Content', 'dpr-adeline-extensions'),

						'param_name'		=> 'tooltip_content',

						'edit_field_class'	=> 'vc_column vc_col-sm-12',

						'admin_label' => true,

						'dependency' => array ('element' => 'enable_tooltip', 'value' => array ('yes')),

						'description' => esc_html__('Tooltip content (allows HTML tags).', 'dpr-adeline-extensions')

					),

				),

				'group'				=> esc_html__('Locations List', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set map height.Map width is allways 100% of parent container but width must be determined.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Map Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'map_height',

				'min'				=> 0,

				'value'				=> '400',

				'edit_field_class'	=> 'vc_column vc_col-sm-3',

				'group'				=> esc_html__('Map Settings', 'dpr-adeline-extensions'),

			),

			array (

				'type' => 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set units for map container height (px or %).', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Height Units', 'dpr-adeline-extensions'),

				'value' => 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 no-padding-top',

				'options' => array (

					esc_attr__('px', 'dpr-adeline-extensions') => 'px',

					esc_attr__('vh', 'dpr-adeline-extensions') => 'vh'

				),

				'param_name' => 'height_units',

				'group'				=> esc_html__('Map Settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Auto set zoom of map to see all markers.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Auto zoom', 'dpr-adeline-extensions'),

				'param_name'		=> 'auto_zoom',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 no-padding-top',

				'value'				=> '',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Map Settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set zoom level.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Zoom', 'dpr-adeline-extensions'),

				'param_name'		=> 'zoom',

				'min'				=> 1,

				'max' 				=> 19,

				'edit_field_class'	=> 'vc_column vc_col-sm-3 no-padding-top',

				'dependency' => array ('element' => 'auto_zoom', 'value_not_equal_to' => 'yes'),

				'group'				=> esc_html__('Map Settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> 'Map Control Settings',

				'param_name'		=> 'map_style_title_1',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_html__('Map Settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable or disable map controls.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Disable All Controls?', 'dpr-adeline-extensions'),

				'param_name'		=> 'disable_all_controls',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Map Settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable or disable map type controls.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Disable map type control?', 'dpr-adeline-extensions'),

				'param_name'		=> 'map_type_disable',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'dependency' => array ('element' => 'disable_all_controls', 'value_not_equal_to' => 'yes'),

				'group'				=> esc_html__('Map Settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable or disable pan controls.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Disable full screen control?', 'dpr-adeline-extensions'),

				'param_name'		=> 'full_screen_disable',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'dependency' => array ('element' => 'disable_all_controls', 'value_not_equal_to' => 'yes'),

				'group'				=> esc_html__('Map Settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable or disable zoom control.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Disable zoom control?', 'dpr-adeline-extensions'),

				'param_name'		=> 'zoom_control_disable',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'dependency' => array ('element' => 'disable_all_controls', 'value_not_equal_to' => 'yes'),

				'group'				=> esc_html__('Map Settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable or disable street view button.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Disable street view button?', 'dpr-adeline-extensions'),

				'param_name'		=> 'street_view_disable',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'dependency' => array ('element' => 'disable_all_controls', 'value_not_equal_to' => 'yes'),

				'group'				=> esc_html__('Map Settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable or disable street view button.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Disable Scrollwheel?', 'dpr-adeline-extensions'),

				'param_name'		=> 'scrollwheel_disable',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'value' 			=> 'yes',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'dependency' => array ('element' => 'disable_all_controls', 'value_not_equal_to' => 'yes'),

				'group'				=> esc_html__('Map Settings', 'dpr-adeline-extensions'),

			),



			array (

				'type' => 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set tooltip text alignment.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Tooltip text algnment', 'dpr-adeline-extensions'),

				'value' => 'left',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options' => array (

					esc_attr__('Left', 'dpr-adeline-extensions') => 'left',

					esc_attr__('Center', 'dpr-adeline-extensions') => 'center',

					esc_attr__('Right', 'dpr-adeline-extensions') => 'right'

				),

				'param_name' => 'tooltip_text_alignment',

				'group'				=> esc_html__('Tooltip Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set max tooltip width. Default is 300px.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Tooltip max width', 'dpr-adeline-extensions'),

				'param_name'		=> 'tooltip_max_width',

				'min'				=> 1,

				'value'				=> 300,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 no-padding-top',

				'group'				=> esc_html__('Tooltip Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Tooltip Title Typography', 'dpr-adeline-extensions' ),

				'param_name'       => 'tooltip_title_1',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group'				=> esc_html__('Tooltip Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom tooltip text color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'tooltip_title_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Tooltip Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'tooltip_title_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Tooltip Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom line height.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'tooltip_title_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Tooltip Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom letter sapacing.', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'tooltip_title_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Tooltip Style', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'tooltip_title_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'group'				=> esc_html__('Tooltip Style', 'dpr-adeline-extensions'),

	  		),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_use_google_fonts',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Tooltip Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'tooltip_title_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'dependency'		=> array('element' => 'title_use_google_fonts', 'value' => 'yes'),

				'group'				=> esc_attr__('Tooltip Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Tooltip Content Typography', 'dpr-adeline-extensions' ),

				'param_name'       => 'tooltip_title_2',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group'				=> esc_html__('Tooltip Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom tooltip text color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'tooltip_content_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Tooltip Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'tooltip_content_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Tooltip Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom line height.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'tooltip_content_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Tooltip Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom letter sapacing.', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'tooltip_content_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Tooltip Style', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'tooltip_content_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'group'				=> esc_html__('Tooltip Style', 'dpr-adeline-extensions'),

	  		),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'content_use_google_fonts',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Tooltip Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'tooltip_content_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'dependency'		=> array('element' => 'content_use_google_fonts', 'value' => 'yes'),

				'group'				=> esc_attr__('Tooltip Style', 'dpr-adeline-extensions'),

			),





		),

		

	)

);