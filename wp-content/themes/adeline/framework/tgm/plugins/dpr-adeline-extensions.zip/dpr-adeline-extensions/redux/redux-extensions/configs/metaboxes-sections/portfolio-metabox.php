<?php

if (!function_exists("dpr_portfolio_metabox_sections")):

    function dpr_portfolio_metabox_sections()
{

        // Declare your sections

        /*

         * ---> START PORTFOLIO METABOX SECTIONS

         */

        $portfolio_metabox_sections = array();

        $portfolio_metabox_sections[] = array(

            'title'    => esc_html__('Source', 'dpr-adeline-extensions'),

            'subtitle' => esc_html__('', 'dpr-adeline-extensions'),

            'fields'   => array(

                array(

                    'id'      => 'portfolio_use_query',

                    'type'    => 'switch',

                    'default' => false,

                    'desc'    => wp_kses_post(__('<small><em>By default are displayed all portfolio items. Enable this option if you need create custom portfolio items set to display.</em></small>', 'dpr-adeline-extensions')),

                    'title'   => esc_html__('Use Qustom Query?', 'dpr-adeline-extensions'),

                    'hint'    => array(

                        'title'   => esc_attr__('Use Qustom Query?', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Use custom query to create source for portfolio page.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'portfolio_query_categories',

                    'type'     => 'select',

                    'data'     => 'terms',

                    'multi'    => true,

                    'args'     => array('taxonomies' => 'dpr_portfolio_category'),

                    'title'    => __('Categories', 'dpr-adeline-extensions'),

                    'required' => array('portfolio_use_query', 'equals', '1'),

                    'desc'     => wp_kses_post(__('<small><i>If you leave this field blank all categories will be included.</i></small>', 'dpr-adeline-extensions')),

                    'hint'     => array(

                        'title'   => esc_attr__('Categories', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Select categories to include in source', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'portfolio_query_categories_excluded',

                    'type'     => 'select',

                    'data'     => 'terms',

                    'multi'    => true,

                    'args'     => array('taxonomies' => 'dpr_portfolio_category'),

                    'title'    => __('Excluded Categories', 'dpr-adeline-extensions'),

                    'required' => array('portfolio_use_query', 'equals', '1'),

                    'desc'     => wp_kses_post(__('<small><i>Select categories to exclude from source.</i></small>', 'dpr-adeline-extensions')),

                    'hint'     => array(

                        'title'   => esc_attr__('Excluded Categories', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Select categories to exclude from source', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'portfolio_query_offset',

                    'type'     => 'spinner',

                    'title'    => __('Items count', 'dpr-adeline-extensions'),

                    'required' => array('portfolio_use_query', 'equals', '1'),

                    'desc'     => wp_kses_post(__('<small><i>If set this field to -1 all items will be included.</i></small>', 'dpr-adeline-extensions')),

                    'default'  => '-1',

                    'min'      => '-1',

                    'step'     => '1',

                    'max'      => '200',

                    'hint'     => array(

                        'title'   => esc_attr__('Portfolio Items Count', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('You can set portfolio items to display. If you set to -1 will be included all items.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'portfolio_query_orderby',

                    'type'     => 'select',

                    'title'    => __('Order By', 'dpr-adeline-extensions'),

                    'required' => array('portfolio_use_query', 'equals', '1'),

                    'desc'     => wp_kses_post(__('<small><i>Sort retrieved portfolio items by parameter.</i></small>', 'dpr-adeline-extensions')),

                    'options'  => array(

                        'none'          => 'No Order',

                        'date'          => 'Date',

                        'title'         => 'Title',

                        'name'          => 'Slug',

                        'author'        => 'Author',

                        'ID'            => 'ID',

                        'comment_count' => 'Comment Count',

                        'random'        => 'Random',

                    ),

                    'default'  => 'none',

                    'hint'     => array(

                        'title'   => esc_attr__('Order By', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Sort retrieved portfolio items by parameter', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'portfolio_query_order',

                    'type'     => 'select',

                    'title'    => __('Order', 'dpr-adeline-extensions'),

                    'required' => array('portfolio_use_query', 'equals', '1'),

                    'desc'     => wp_kses_post(__('<small><i>Select the ascending or descending order</i></small>', 'dpr-adeline-extensions')),

                    'options'  => array(

                        'ASC'  => 'Ascending Order',

                        'DESC' => 'Decending Order',

                    ),

                    'default'  => 'ASC',

                    'hint'     => array(

                        'title'   => esc_attr__('Order', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Select the ascending or descending order', 'dpr-adeline-extensions'),

                    ),

                ),

            ),

        );

        $portfolio_metabox_sections[] = array(

            'title'    => esc_html__('Layout', 'dpr-adeline-extensions'),

            'subtitle' => esc_html__('', 'dpr-adeline-extensions'),

            'fields'   => array(

                array(

                    'id'      => 'portfolio_main_content_position',

                    'type'    => 'radio',

                    'title'   => __('Main Page Content Position', 'dpr-adeline-extensions'),

                    'options' => array(

                        'above'  => 'Above Portfolio Grid',

                        'bellow' => 'Bellow Portfolio Grid',

                    ),

                    'default' => 'above',

                    'hint'    => array(

                        'title'   => esc_attr__('Main Page Content Position', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set main page content (entered in WP editor or created in composer) position in relation to the portfolio grid', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'      => 'portfolio_posts_per_page',

                    'type'    => 'spinner',

                    'title'   => __('Portfolio Items per Page', 'dpr-adeline-extensions'),

                    'desc'    => wp_kses_post(__('<small><i>Put -1 to display all portfolio items. Default is 12.</i></small>', 'dpr-adeline-extensions')),

                    'default' => '12',

                    'min'     => '-1',

                    'step'    => '1',

                    'max'     => '200',

                    'hint'    => array(

                        'title'   => esc_attr__('Portfolio Items per Page', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('You can set default portfolio items per page count for portfolio page.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'      => 'portfolio_columns',

                    'type'    => 'slider',

                    'title'   => __('Columns', 'dpr-adeline-extensions'),

                    'default' => '3',

                    'min'     => '1',

                    'step'    => '1',

                    'max'     => '10',

                    'hint'    => array(

                        'title'   => esc_attr__('Portfolio Columns', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set default columns count on portfolio page. This value can be overwriten in individual page or grid setting.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'      => 'portfolio_tablet_columns',

                    'type'    => 'slider',

                    'title'   => __('Columns: Tablet', 'dpr-adeline-extensions'),

                    'default' => '2',

                    'min'     => '1',

                    'step'    => '1',

                    'max'     => '10',

                    'hint'    => array(

                        'title'   => esc_attr__('Portfolio Tablet Columns', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set default tablet columns count on portfolio page. This value can be overwriten in individual page or grid setting.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'      => 'portfolio_mobile_columns',

                    'type'    => 'slider',

                    'title'   => __('Columns: Mobile', 'dpr-adeline-extensions'),

                    'default' => '1',

                    'min'     => '1',

                    'step'    => '1',

                    'max'     => '10',

                    'hint'    => array(

                        'title'   => esc_attr__('Portfolio Mobile Columns', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set default mobile columns count on portfolio page. This value can be overwriten in individual page or grid setting.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'      => 'portfolio_masonry',

                    'type'    => 'switch',

                    'default' => false,

                    'title'   => esc_html__('Use Masonry', 'dpr-adeline-extensions'),

                    'hint'    => array(

                        'title'   => esc_attr__('Use Masonry', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Use masonry for protfolio items grid by default.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'      => 'portfolio_pagination_style',

                    'type'    => 'radio',

                    'title'   => __('Pagination Style', 'dpr-adeline-extensions'),

                    'options' => array(

                        'none'            => 'No Pagination',

                        'default'         => 'Default Numbered Pagination',

                        'load_more'       => 'Load More Button',

                        'infinite_scroll' => 'Infinite Scroll',

                        'next_prev'       => 'Next / Prev',

                    ),

                    'default' => 'default',

                    'hint'    => array(

                        'title'   => esc_attr__('Pagination Style', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set default pagination style', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'portfolio_pagination_infinite_spinners',

                    'type'     => 'color',

                    'output'   => array('background-color' => '.loader-ellips__dot'),

                    'validate' => 'color',

                    'title'    => esc_html__('Spinners Color', 'dpr-adeline-extensions'),

                    'required' => array('portfolio_pagination_style', 'equals', array('infinite_scroll', 'load_more')),

                    'hint'     => array(

                        'title'   => esc_attr__('Spinners Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set color for loading spinners.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'portfolio_pagination_infinite_scroll_last_text',

                    'type'     => 'text',

                    'title'    => __('Infinite Scroll: Last Text', 'dpr-adeline-extensions'),

                    'required' => array('portfolio_pagination_style', 'equals', 'infinite_scroll'),

                    'hint'     => array(

                        'title'   => esc_attr__('Infinite Scroll: Last Text', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set infinite scroll last text.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'portfolio_pagination_infinite_scroll_error_text',

                    'type'     => 'text',

                    'title'    => __('Infinite Scroll: Error Text', 'dpr-adeline-extensions'),

                    'required' => array('portfolio_pagination_style', 'equals', 'infinite_scroll'),

                    'hint'     => array(

                        'title'   => esc_attr__('Infinite Scroll: Error Text', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set infinite scroll error text.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'portfolio_pagination_loadmore_button_text',

                    'type'     => 'text',

                    'title'    => __('Load More: Button Text', 'dpr-adeline-extensions'),

                    'default'  => 'Load More',

                    'required' => array('portfolio_pagination_style', 'equals', 'load_more'),

                    'hint'     => array(

                        'title'   => esc_attr__('Load More: Button Text', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set load more button text.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'portfolio_pagination_loadmore_nomore_text',

                    'type'     => 'text',

                    'title'    => __('Load More: End Text', 'dpr-adeline-extensions'),

                    'default'  => 'No more items to load',

                    'required' => array('portfolio_pagination_style', 'equals', 'load_more'),

                    'hint'     => array(

                        'title'   => esc_attr__('Load More: End Text', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set load more end text.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'portfolio_pagination_loadmore_button_bg',

                    'type'     => 'color',

                    'output'   => array('background-color' => '.dp-adeline-loadmore-button'),

                    'validate' => 'color',

                    'title'    => esc_html__('Load More Button Background', 'dpr-adeline-extensions'),

                    'required' => array('portfolio_pagination_style', 'equals', 'load_more'),

                    'hint'     => array(

                        'title'   => esc_attr__('Load More Button Background', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set background color for load more button.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'portfolio_pagination_loadmore_button_text_color',

                    'type'     => 'color',

                    'output'   => array('color' => '.dp-adeline-loadmore-button', 'fill' => '.dp-adeline-loadmore-loading-icon', 'stroke' => '.dp-adeline-loadmore-loading-icon'),

                    'validate' => 'color',

                    'title'    => esc_html__('Load More Button Color', 'dpr-adeline-extensions'),

                    'required' => array('portfolio_pagination_style', 'equals', 'load_more'),

                    'hint'     => array(

                        'title'   => esc_attr__('Load More Button Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set color for load more button.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'portfolio_pagination_position',

                    'type'     => 'radio',

                    'title'    => __('Pagination Position', 'dpr-adeline-extensions'),

                    'options'  => array(

                        'left'   => 'Left',

                        'center' => 'Center',

                        'right'  => 'Right',

                    ),

                    'default'  => 'center',

                    'required' => array('portfolio_pagination_style', 'equals', 'default'),

                    'hint'     => array(

                        'title'   => esc_attr__('Pagination Position', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set default pagination position', 'dpr-adeline-extensions'),

                    ),

                ),

            ),

        );

        $portfolio_metabox_sections[] = array(

            'title'    => esc_html__('Filter Bar', 'dpr-adeline-extensions'),

            'subtitle' => esc_html__('', 'dpr-adeline-extensions'),

            'fields'   => array(

                array(

                    'id'    => 'portfolio_filter',

                    'type'  => 'switch',

                    'title' => esc_html__('Use Filter?', 'dpr-adeline-extensions'),

                    'hint'  => array(

                        'title'   => esc_attr__('Use Filter?', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Enable or disable display of portfolio item filter.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'portfolio_filter_all_button',

                    'type'     => 'switch',

                    'required' => array('portfolio_filter', 'equals', '1'),

                    'title'    => esc_html__('Display Button ALL?', 'dpr-adeline-extensions'),

                    'hint'     => array(

                        'title'   => esc_attr__('Display Button All?', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Enable or disable display of button ALL in filter.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'portfolio_filter_all_button_text',

                    'type'     => 'text',

                    'title'    => __('ALL Button Text', 'dpr-adeline-extensions'),

                    'required' => array('portfolio_filter_all_button', 'equals', '1'),

                    'hint'     => array(

                        'title'   => esc_attr__('ALL Button Text', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set all button text.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'portfolio_filter_position',

                    'type'     => 'radio',

                    'title'    => __('Portfolio Filter Position', 'dpr-adeline-extensions'),

                    'options'  => array(

                        'left'   => 'Left',

                        'center' => 'Center',

                        'right'  => 'Right',

                        'full'   => 'Full',

                    ),

                    'required' => array('portfolio_filter', 'equals', '1'),

                    'hint'     => array(

                        'title'   => esc_attr__('Portfolio Filter Position', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set portfolio filter position.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'portfolio_filter_taxonomy',

                    'type'     => 'radio',

                    'title'    => __('Portfolio Filter Taxonomy', 'dpr-adeline-extensions'),

                    'options'  => array(

                        'categories' => 'Categories',

                        'tags'       => 'Tags',

                    ),

                    'required' => array('portfolio_filter', 'equals', '1'),

                    'hint'     => array(

                        'title'   => esc_attr__('Portfolio Filter Taxonomy', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set portfolio filter taxonomy.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'             => 'portfolio_filter_bar_margin',

                    'type'           => 'spacing',

                    'output'         => array('.portfolio-items .portfolio-filters'),

                    'mode'           => 'margin',

                    'units'          => array('px'),

                    'display_units'  => true,

                    'units_extended' => false,

                    'title'          => __('Filter Bar Margin (px)', 'dpr-adeline-extensions'),

                    'hint'           => array(

                        'title'   => esc_attr__('Filter Bar Margin', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Choose margin for filter bar.', 'dpr-adeline-extensions'),

                    ),

                    'required'       => array('portfolio_filter', 'equals', '1'),

                ),

                array(

                    'id'             => 'portfolio_filter_buttons_margin',

                    'type'           => 'spacing',

                    'output'         => array('.portfolio-items .portfolio-filters li'),

                    'mode'           => 'margin',

                    'units'          => array('px'),

                    'display_units'  => true,

                    'units_extended' => false,

                    'title'          => __('Filter Bar Buttons: Margin (px)', 'dpr-adeline-extensions'),

                    'hint'           => array(

                        'title'   => esc_attr__('Filter Bar Buttons: Margin', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Choose margin for filter bar buttons.', 'dpr-adeline-extensions'),

                    ),

                    'required'       => array('portfolio_filter', 'equals', '1'),

                ),

                array(

                    'id'             => 'portfolio_filter_buttons_padding',

                    'type'           => 'spacing',

                    'output'         => array('.portfolio-items .portfolio-filters li a'),

                    'mode'           => 'padding',

                    'units'          => array('px'),

                    'display_units'  => true,

                    'units_extended' => false,

                    'title'          => __('Filter Bar Buttons: Padding (px)', 'dpr-adeline-extensions'),

                    'hint'           => array(

                        'title'   => esc_attr__('Filter Bar Buttons: Padding (px)', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Choose padding for filter bar buttons.', 'dpr-adeline-extensions'),

                    ),

                    'required'       => array('portfolio_filter', 'equals', '1'),

                ),

                array(

                    'id'             => 'portfolio_filter_buttons_border_radius',

                    'type'           => 'dpr_border_radius',

                    'units'          => array('px', '%'),

                    'all'            => true,

                    'output'         => array('.portfolio-items .portfolio-filters li a'),

                    'units_extended' => false,

                    'title'          => __('Filter Bar Buttons: Border Radius', 'dpr-adeline-extensions'),

                    'required'       => array('portfolio_filter', 'equals', '1'),

                    'hint'           => array(

                        'title'   => esc_attr__('Filter Bar Buttons: Border Radius', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Specify border radius for filter buttons.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'portfolio_filter_buttons_bg',

                    'type'     => 'color',

                    'title'    => __('Filter Bar Buttons: Background', 'dpr-adeline-extensions'),

                    'output'   => array('background-color' => '.portfolio-items .portfolio-filters li a'),

                    'hint'     => array(

                        'title'   => esc_attr__('Filter Bar Buttons: Background', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set background color for filter bar buttons.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('portfolio_filter', 'equals', '1'),

                ),

                array(

                    'id'       => 'portfolio_filter_buttons_bg_hover',

                    'type'     => 'color',

                    'title'    => __('Filter Bar Buttons: Background Hover', 'dpr-adeline-extensions'),

                    'output'   => array('background-color' => '.portfolio-items .portfolio-filters li a:hover, .portfolio-items .portfolio-filters li.active a'),

                    'hint'     => array(

                        'title'   => esc_attr__('Filter Bar Buttons: Background Hover', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set background color for filter bar buttons hover and active.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('portfolio_filter', 'equals', '1'),

                ),

                array(

                    'id'       => 'portfolio_filter_buttons_text',

                    'type'     => 'color',

                    'title'    => __('Filter Bar Buttons Text', 'dpr-adeline-extensions'),

                    'output'   => array('.portfolio-items .portfolio-filters li a'),

                    'hint'     => array(

                        'title'   => esc_attr__('Filter Bar Buttons Text', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set filter bar button text color.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('portfolio_filter', 'equals', '1'),

                ),

                array(

                    'id'       => 'portfolio_filter_buttons_text_hover',

                    'type'     => 'color',

                    'title'    => __('Filter Bar Buttons Text: Hover', 'dpr-adeline-extensions'),

                    'output'   => array('.portfolio-items .portfolio-filters li a:hover, .portfolio-items .portfolio-filters li.active a'),

                    'hint'     => array(

                        'title'   => esc_attr__('Filter Bar Buttons Text: Hover', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set filter bar button text color active nad hover.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('portfolio_filter', 'equals', '1'),

                ),

                array(

                    'id'       => 'portfolio_filter_buttons_border',

                    'type'     => 'color',

                    'title'    => __('Filter Bar Buttons Border', 'dpr-adeline-extensions'),

                    'output'   => array('border-color' => '.portfolio-items .portfolio-filters li a'),

                    'hint'     => array(

                        'title'   => esc_attr__('Filter Bar Buttons Border', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set border color for filter bar buttons.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('portfolio_filter', 'equals', '1'),

                ),

                array(

                    'id'       => 'portfolio_filter_buttons_border_hover',

                    'type'     => 'color',

                    'title'    => __('Filter Bar Buttons Border: Hover', 'dpr-adeline-extensions'),

                    'output'   => array('border-color' => '.portfolio-items .portfolio-filters li a:hover, .portfolio-items .portfolio-filters li.active a'),

                    'hint'     => array(

                        'title'   => esc_attr__('Filter Bar Buttons Border: Hover', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set border color for filter bar buttons hover and active.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('portfolio_filter', 'equals', '1'),

                ),

            ),

        );

        $portfolio_metabox_sections[] = array(

            'title'    => esc_html__('Grid Style', 'dpr-adeline-extensions'),

            'subtitle' => esc_html__('', 'dpr-adeline-extensions'),

            'fields'   => array(

                array(

                    'id'    => 'portfolio_entries_style_info',

                    'type'  => 'info',

                    'style' => 'dpr-title',

                    'title' => wp_kses_post(__('<h3>Entries Style</h3>', 'dpr-adeline-extensions')),

                ),

                array(

                    'id'             => 'portfolio_grid_margin',

                    'type'           => 'spacing',

                    'output'         => array('.portfolio-items .portfolio-item'),

                    'mode'           => 'padding',

                    'units'          => array('px', '%'),

                    'all'            => true,

                    'display_units'  => true,

                    'units_extended' => false,

                    'title'          => __('Items Margin', 'dpr-adeline-extensions'),

                    'hint'           => array(

                        'title'   => esc_attr__('Items Margin', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set margin for items in grid', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'             => 'portfolio_grid_padding',

                    'type'           => 'spacing',

                    'output'         => array('.portfolio-items .portfolio-item .portfolio-item-inner'),

                    'mode'           => 'padding',

                    'units'          => array('px', '%'),

                    'all'            => true,

                    'display_units'  => true,

                    'units_extended' => false,

                    'title'          => __('Entry Padding', 'dpr-adeline-extensions'),

                    'hint'           => array(

                        'title'   => esc_attr__('Entry Padding', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set padding for entries', 'dpr-adeline-extensions'),

                    ),

                ),

         array(

            'id'       => 'portfolio_entry_placeholder_bg',

            'type'     => 'background',

            'title'    => __('Portfolio Placeholder Background', 'dpr-adeline-extensions'),

            'output'   => array('.portfolio-items .portfolio-item .portfolio-item-inner'),

            'hint'     => array(

                'title'   => esc_attr__('Portfolio Placeholder Background', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set background for portfolio placeholder. Is visible only when potfolio item is move animated on hover,', 'dpr-adeline-extensions'),

            )

        ),               

                array(

                    'id'     => 'portfolio_entry_border',

                    'type'   => 'border',

                    'title'  => __('Border', 'dpr-adeline-extensions'),

                    'output' => array('.portfolio-items .portfolio-item .portfolio-item-inner'),

                    'hint'   => array(

                        'title'   => esc_attr__('Portfolio Entry Border', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set portfolio entry border.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'             => 'portfolio_entry_border_radius',

                    'type'           => 'dpr_border_radius',

                    'units'          => array('px', '%'),

                    'all'            => true,

                    'output'         => array('.portfolio-items .portfolio-item .portfolio-item-inner,.portfolio-items .portfolio-item .portfolio-item-inner-mover'),

                    'units_extended' => false,

                    'title'          => __('Entry Border Radius', 'dpr-adeline-extensions'),

                    'hint'           => array(

                        'title'   => esc_attr__('Entry Border Radius', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Specify border radius for portfolio entries.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'     => 'portfolio_entry_bg_color',

                    'type'   => 'color',

                    'title'  => __('Entry Background Color', 'dpr-adeline-extensions'),

                    'output' => array('background-color' => ' .portfolio-items .portfolio-item .portfolio-item-inner-mover, .portfolio-items .portfolio-content'),

                    'hint'   => array(

                        'title'   => esc_attr__('Entry Background Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set portfolio entry background color.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'      => 'portfolio_entry_content_style',

                    'type'    => 'image_select',

                    'title'   => __('Portfolio Item Content Position', 'dpr-adeline-extensions'),

                    'options' => array(

                        'outside' => array(

                            'title' => esc_html__('Outside(bellow image)', 'dpr-adeline-extensions'),

                            'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/portfolio/grid_cotent_outside.png',

                        ),

                        'inside'  => array(

                            'title' => esc_html__('Inside (over image)', 'dpr-adeline-extensions'),

                            'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/portfolio/grid_cotent_inside.png',

                        ),

                    ),

                    'hint'    => array(

                        'title'   => esc_attr__('Portfolio Item Content Position', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Choose content position for portfolio item in grid. This general settings can be overwriten for specific pages or grid.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'outside_content_style_info',

                    'type'     => 'info',

                    'style'    => 'dpr-title',

                    'title'    => wp_kses_post(__('<h3>Outside Content Style</h3>', 'dpr-adeline-extensions')),

                    'required' => array('portfolio_entry_content_style', 'equals', 'outside'),

                ),

                array(

                    'id'             => 'portfolio_grid_outer_content_padding',

                    'type'           => 'spacing',

                    'output'         => array('.portfolio-items .portfolio-content'),

                    'mode'           => 'padding',

                    'units'          => array('px', '%'),

                    'all'            => false,

                    'display_units'  => true,

                    'units_extended' => false,

                    'title'          => __('Outside Content Padding', 'dpr-adeline-extensions'),

                    'hint'           => array(

                        'title'   => esc_attr__('Entry Padding', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set padding for entries', 'dpr-adeline-extensions'),

                    ),

                    'required'       => array('portfolio_entry_content_style', 'equals', 'outside'),

                ),

                array(

                    'id'       => 'portfolio_entry_outside_arrowed',

                    'type'     => 'switch',

                    'title'    => esc_html__('Use Arrow For Outside Content?', 'dpr-adeline-extensions'),

                    'hint'     => array(

                        'title'   => esc_attr__('Use Arrow For Outside Content?', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Enable or disable display of arrow over ouside portfolio content.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('portfolio_entry_content_style', 'equals', 'outside'),

                ),

                array(

                    'id'    => 'portfolio_entry_title',

                    'type'  => 'switch',

                    'title' => esc_html__('Display Entry Title', 'dpr-adeline-extensions'),

                    'hint'  => array(

                        'title'   => esc_attr__('Display Entry Title', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Enable or disable display of portfolio entry title.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'portfolio_entry_title_color',

                    'type'     => 'color',

                    'title'    => __('Title Color', 'dpr-adeline-extensions'),

                    'output'   => array('color' => '.portfolio-items .portfolio-item-title a'),

                    'hint'     => array(

                        'title'   => esc_attr__('Title Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set portfolio entry title color.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('portfolio_entry_content_style', 'equals', 'outside'),

                ),

                array(

                    'id'       => 'portfolio_entry_title_color_hover',

                    'type'     => 'color',

                    'title'    => __('Title Color: Hover', 'dpr-adeline-extensions'),

                    'output'   => array('color' => '.portfolio-items .portfolio-item-title a:hover'),

                    'hint'     => array(

                        'title'   => esc_attr__('Title Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set portfolio entry title color.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('portfolio_entry_content_style', 'equals', 'outside'),

                ),

                array(

                    'id'    => 'portfolio_entry_category',

                    'type'  => 'switch',

                    'title' => esc_html__('Display Entry Category', 'dpr-adeline-extensions'),

                    'hint'  => array(

                        'title'   => esc_attr__('Display Entry Category', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Enable or disable display of portfolio entry category.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'portfolio_entry_catagory_color',

                    'type'     => 'color',

                    'title'    => __('Category Link Color', 'dpr-adeline-extensions'),

                    'output'   => array('color' => '.portfolio-items .categories, .portfolio-items .categories a'),

                    'hint'     => array(

                        'title'   => esc_attr__('Category Link Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set portfolio entry category color.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('portfolio_entry_category', 'equals', '1'),

                ),

                array(

                    'id'       => 'portfolio_entry_category_color_hover',

                    'type'     => 'color',

                    'title'    => __('Category Color: Hover', 'dpr-adeline-extensions'),

                    'output'   => array('color' => '.portfolio-items .categories a:hover'),

                    'hint'     => array(

                        'title'   => esc_attr__('Category Color: Hover', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set portfolio entry category hover color.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('portfolio_entry_category', 'equals', '1'),

                ),

                array(

                    'id'    => 'portfolio_entry_excerpt',

                    'type'  => 'switch',

                    'title' => esc_html__('Display Entry Excerpt', 'dpr-secondson-extensions'),

                    'hint'  => array(

                        'title'   => esc_attr__('Display Entry Excerpt', 'dpr-secondson-extensions'),

                        'content' => esc_attr__('Enable or disable display of portfolio entry excerpt.', 'dpr-secondson-extensions'),

                    ),

                ),

                array(

                    'id'       => 'portfolio_entry_excerpt_color',

                    'type'     => 'color',

                    'title'    => __('Excerpt Color', 'dpr-secondson-extensions'),

                    'output'   => array('color' => '.portfolio-items p'),

                    'hint'     => array(

                        'title'   => esc_attr__('Category excerpt Color', 'dpr-secondson-extensions'),

                        'content' => esc_attr__('Set portfolio entry excerpt color.', 'dpr-secondson-extensions'),

                    ),

                    'required' => array('portfolio_entry_excerpt', 'equals', '1'),

                ),

                array(

                    'id'    => 'portfolio_entry_decoration_info',

                    'type'  => 'info',

                    'style' => 'dpr-subtitle',

                    'title' => wp_kses_post(__('<h3>Portfolio Entry Decoration && Hover State</h3>', 'dpr-adeline-extensions')),

                ),

                array(

                    'id'      => 'portfolio_entry_shadow',

                    'type'    => 'select',

                    'title'   => esc_html__('Entry Shadow', 'dpr-adeline-extensions'),

                    'desc'    => '',

                    'options' => array(

                        ''       => esc_html__('None', 'dpr-adeline-extensions'),

                        '1'      => esc_html__('Shadow Depth 1', 'dpr-adeline-extensions'),

                        '2'      => esc_html__('Shadow Depth 2', 'dpr-adeline-extensions'),

                        '3'      => esc_html__('Shadow Depth 3', 'dpr-adeline-extensions'),

                        '4'      => esc_html__('Shadow Depth 4', 'dpr-adeline-extensions'),

                        '5'      => esc_html__('Shadow Depth 5', 'dpr-adeline-extensions'),

                        '6'      => esc_html__('Shadow Depth 6', 'dpr-adeline-extensions'),

                        'custom' => esc_html__('Custom Shadow', 'dpr-adeline-extensions'),

                    ),

                    'hint'    => array(

                        'title'   => esc_attr__('Entry Shadow', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set shadow for portfolio entry.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'portfolio_entry_custom_shadow',

                    'type'     => 'dpr_box_shadow',

                    'title'    => wp_kses_post(__('Custom Box Shadow', 'dpr-adeline-extensions')),

                    'output'   => array('.portfolio-items .portfolio-item .portfolio-item-inner'),

                    'desc'     => wp_kses_post('<em> Horizontal Offset, Vertical Offset and Color are required to display shadow</em>'),

                    'hint'     => array(

                        'title'   => esc_attr__('Custom Box Shadow', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Create custom box shadow.Horizontal Offset, Vertical Offset and Color are required. Blur and spread are optional.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('portfolio_entry_shadow', 'equals', 'custom'),

                ),

                array(

                    'id'      => 'portfolio_entry_shadow_hover',

                    'type'    => 'select',

                    'title'   => esc_html__('Entry Shadow: Hover', 'dpr-adeline-extensions'),

                    'desc'    => '',

                    'options' => array(

                        ''       => esc_html__('None', 'dpr-adeline-extensions'),

                        '1'      => esc_html__('Shadow Depth 1', 'dpr-adeline-extensions'),

                        '2'      => esc_html__('Shadow Depth 2', 'dpr-adeline-extensions'),

                        '3'      => esc_html__('Shadow Depth 3', 'dpr-adeline-extensions'),

                        '4'      => esc_html__('Shadow Depth 4', 'dpr-adeline-extensions'),

                        '5'      => esc_html__('Shadow Depth 5', 'dpr-adeline-extensions'),

                        '6'      => esc_html__('Shadow Depth 6', 'dpr-adeline-extensions'),

                        'custom' => esc_html__('Custom Shadow', 'dpr-adeline-extensions'),

                    ),

                    'hint'    => array(

                        'title'   => esc_attr__('Entry Shadow: Hover', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set shadow for portfolio entry hover state.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'portfolio_entry_custom_shadow_hover',

                    'type'     => 'dpr_box_shadow',

                    'title'    => wp_kses_post(__('Custom Box Shadow: Hover', 'dpr-adeline-extensions')),

                    'output'   => array('.portfolio-items .portfolio-item .portfolio-item-inner:hover'),

                    'desc'     => wp_kses_post('<em> Horizontal Offset, Vertical Offset and Color are required to display shadow</em>'),

                    'hint'     => array(

                        'title'   => esc_attr__('Custom Box Shadow: Hover', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Create custom box shadow for entry hover state.Horizontal Offset, Vertical Offset and Color are required. Blur and spread are optional.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('portfolio_entry_shadow_hover', 'equals', 'custom'),

                ),

                array(

                    'id'      => 'portfolio_entry_hover_animation',

                    'type'    => 'select',

                    'title'   => esc_html__('Entry Hover Animation', 'dpr-adeline-extensions'),

                    'desc'    => '',

                    'options' => array(

                        'none'                     => esc_html__('None', 'dpr-adeline-extensions'),

                        'dpr-upscale-onhover-1'    => esc_html__('Scale Up 3%', 'dpr-adeline-extensions'),

                        'dpr-upscale-onhover-2'    => esc_html__('Scale Up 6%', 'dpr-adeline-extensions'),

                        'dpr-upscale-onhover-3'    => esc_html__('Scale Up 10%', 'dpr-adeline-extensions'),

                        'dpr-upscale-onhover-4'    => esc_html__('Scale Up 15%', 'dpr-adeline-extensions'),

                        'dpr-downscale-onhover-1'  => esc_html__('Scale Down 3%', 'dpr-adeline-extensions'),

                        'dpr-downscale-onhover-2'  => esc_html__('Scale Down 6%', 'dpr-adeline-extensions'),

                        'dpr-up-onhover-1'         => esc_html__('Move Up 5px', 'dpr-adeline-extensions'),

                        'dpr-up-onhover-2'         => esc_html__('Move Up 10px', 'dpr-adeline-extensions'),

                        'dpr-up-onhover-3'         => esc_html__('Move Up 15px', 'dpr-adeline-extensions'),

                        'dpr-up-onhover-4'         => esc_html__('Move Up 20px', 'dpr-adeline-extensions'),

                        'dpr-down-onhover-1'       => esc_html__('Move Down 5px', 'dpr-adeline-extensions'),

                        'dpr-down-onhover-2'       => esc_html__('Move Down 10px', 'dpr-adeline-extensions'),

                        'dpr-down-onhover-3'       => esc_html__('Move Down 15px', 'dpr-adeline-extensions'),

                        'dpr-down-onhover-4'       => esc_html__('Move Down 20px', 'dpr-adeline-extensions'),

                        'dpr-up-left-onhover-1'    => esc_html__('Move UpLeft 5px', 'dpr-adeline-extensions'),

                        'dpr-up-left-onhover-2'    => esc_html__('Move UpLeft 10px', 'dpr-adeline-extensions'),

                        'dpr-up-left-onhover-3'    => esc_html__('Move UpLeft 15px', 'dpr-adeline-extensions'),

                        'dpr-up-left-onhover-4'    => esc_html__('Move UpLeft 20px', 'dpr-adeline-extensions'),

                        'dpr-up-right-onhover-1'   => esc_html__('Move UpRight 5px', 'dpr-adeline-extensions'),

                        'dpr-up-right-onhover-2'   => esc_html__('Move UpRight 10px', 'dpr-adeline-extensions'),

                        'dpr-up-right-onhover-3'   => esc_html__('Move UpRight 15px', 'dpr-adeline-extensions'),

                        'dpr-up-right-onhover-4'   => esc_html__('Move UpRight 20px', 'dpr-adeline-extensions'),

                        'dpr-down-left-onhover-1'  => esc_html__('Move DownLeft 5px', 'dpr-adeline-extensions'),

                        'dpr-down-left-onhover-2'  => esc_html__('Move DownLeft 10px', 'dpr-adeline-extensions'),

                        'dpr-down-left-onhover-3'  => esc_html__('Move DownLeft 15px', 'dpr-adeline-extensions'),

                        'dpr-down-left-onhover-4'  => esc_html__('Move DownLeft 20px', 'dpr-adeline-extensions'),

                        'dpr-down-right-onhover-1' => esc_html__('Move DownRight 5px', 'dpr-adeline-extensions'),

                        'dpr-down-right-onhover-2' => esc_html__('Move DownRight 10px', 'dpr-adeline-extensions'),

                        'dpr-down-right-onhover-3' => esc_html__('Move DownRight 15px', 'dpr-adeline-extensions'),

                        'dpr-down-right-onhover-4' => esc_html__('Move DownRight 20px', 'dpr-adeline-extensions'),
                        
                        'dpr-image-tilt' => esc_html__('Image Tilt', 'dpr-adeline-extensions'),

                        'dpr-item-tilt' => esc_html__('Item Tilt', 'dpr-adeline-extensions'),                        

                    ),

                    'hint'    => array(

                        'title'   => esc_attr__('Entry Hover Animation', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set entry hover animation.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'    => 'portfolio_entry_appear_info',

                    'type'  => 'info',

                    'style' => 'dpr-subtitle',

                    'title' => wp_kses_post(__('<h3>Portfolio Entries Appear Effect</h3>', 'dpr-adeline-extensions')),

                ),

                array(

                    'id'      => 'portfolio_entry_appear_animation_effect',

                    'type'    => 'select',

                    'title'   => esc_html__('Appear Animation Effect', 'dpr-adeline-extensions'),

                    'desc'    => '',

                    'options' => array(

                        'none'            => esc_html__('None', 'dpr-adeline-extensions'),

                        'fade'            => esc_html__('Fade', 'dpr-adeline-extensions'),

                        'fade-up'         => esc_html__('Fade Up', 'dpr-adeline-extensions'),

                        'fade-down'       => esc_html__('Fade Down', 'dpr-adeline-extensions'),

                        'fade-left'       => esc_html__('Fade Left', 'dpr-adeline-extensions'),

                        'fade-right'      => esc_html__('Fade Right', 'dpr-adeline-extensions'),

                        'fade-up-right'   => esc_html__('Fade Up Right', 'dpr-adeline-extensions'),

                        'fade-up-left'    => esc_html__('Fade Up Left', 'dpr-adeline-extensions'),

                        'fade-down-right' => esc_html__('Fade Down Right', 'dpr-adeline-extensions'),

                        'fade-down-left'  => esc_html__('Fade Down Left', 'dpr-adeline-extensions'),

                        'flip-up'         => esc_html__('Flip Up', 'dpr-adeline-extensions'),

                        'flip-down'       => esc_html__('Flip Down', 'dpr-adeline-extensions'),

                        'flip-left'       => esc_html__('Flip Left', 'dpr-adeline-extensions'),

                        'flip-right'      => esc_html__('Flip Right', 'dpr-adeline-extensions'),

                        'slide-up'        => esc_html__('Slide Up', 'dpr-adeline-extensions'),

                        'slide-down'      => esc_html__('Slide Down', 'dpr-adeline-extensions'),

                        'slide-left'      => esc_html__('Slide Left', 'dpr-adeline-extensions'),

                        'slide-right'     => esc_html__('Slide Right', 'dpr-adeline-extensions'),

                        'zoom-in'         => esc_html__('Zoom In', 'dpr-adeline-extensions'),

                        'zoom-in-up'      => esc_html__('Zoom In Up', 'dpr-adeline-extensions'),

                        'zoom-in-down'    => esc_html__('Zoom In Down', 'dpr-adeline-extensions'),

                        'zoom-in-left'    => esc_html__('Zoom In Left', 'dpr-adeline-extensions'),

                        'zoom-in-right'   => esc_html__('Zoom In Right', 'dpr-adeline-extensions'),

                        'zoom-out'        => esc_html__('Zoom Out', 'dpr-adeline-extensions'),

                        'zoom-out-up'     => esc_html__('Zoom Out Up', 'dpr-adeline-extensions'),

                        'zoom-out-down'   => esc_html__('Zoom Out Down', 'dpr-adeline-extensions'),

                        'zoom-out-left'   => esc_html__('Zoom Out Left', 'dpr-adeline-extensions'),

                        'zoom-out-right'  => esc_html__('Zoom Out Right', 'dpr-adeline-extensions'),

                    ),

                    'hint'    => array(

                        'title'   => esc_attr__('Appear Animation Effect', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Select entry appear animation effect.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'portfolio_entry_appear_animation_easing',

                    'type'     => 'select',

                    'title'    => esc_html__('Appear Animation Easing', 'dpr-adeline-extensions'),

                    'desc'     => '',

                    'options'  => array(

                        'linear'            => esc_html__('Linear', 'dpr-adeline-extensions'),

                        'ease'              => esc_html__('Ease', 'dpr-adeline-extensions'),

                        'ease-in'           => esc_html__('Ease In', 'dpr-adeline-extensions'),

                        'ease-out'          => esc_html__('Ease Out', 'dpr-adeline-extensions'),

                        'ease-in-out'       => esc_html__('Ease In Out', 'dpr-adeline-extensions'),

                        'ease-in-back'      => esc_html__('Ease In Back', 'dpr-adeline-extensions'),

                        'ease-out-back'     => esc_html__('Ease In Back', 'dpr-adeline-extensions'),

                        'ease-in-out-back'  => esc_html__('Ease In Out Back', 'dpr-adeline-extensions'),

                        'ease-in-sine'      => esc_html__('Ease In Sine', 'dpr-adeline-extensions'),

                        'ease-out-sine'     => esc_html__('Ease Out Sine', 'dpr-adeline-extensions'),

                        'ease-in-out-sine'  => esc_html__('Ease In Out Sine', 'dpr-adeline-extensions'),

                        'ease-in-quad'      => esc_html__('Ease In Quad', 'dpr-adeline-extensions'),

                        'ease-out-quad'     => esc_html__('Ease Out Quad', 'dpr-adeline-extensions'),

                        'ease-in-out-quad'  => esc_html__('Ease In Out Quad', 'dpr-adeline-extensions'),

                        'ease-in-cubic'     => esc_html__('Ease In Cubic', 'dpr-adeline-extensions'),

                        'ease-out-cubic'    => esc_html__('Ease Out Cubic', 'dpr-adeline-extensions'),

                        'ease-in-out-cubic' => esc_html__('Ease In Out Cubic', 'dpr-adeline-extensions'),

                        'ease-in-quart'     => esc_html__('Ease In Quart', 'dpr-adeline-extensions'),

                        'ease-out-quart'    => esc_html__('Ease Out Quart', 'dpr-adeline-extensions'),

                        'ease-in-out-quart' => esc_html__('Ease In Out Quart', 'dpr-adeline-extensions'),

                    ),

                    'hint'     => array(

                        'title'   => esc_attr__('Appear Animation Easing', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set entry appear animation easing.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('portfolio_entry_appear_animation_effect', 'not', 'none'),

                ),

                array(

                    'id'       => 'portfolio_entry_appear_animation_duration',

                    'type'     => 'text',

                    'title'    => __('Appear Animation Duration', 'dpr-adeline-extensions'),

                    'desc'     => wp_kses_post(__('<small><i>Set appear animation duration in miliseconds.<br/>If you leave this blank will be used default value 400ms</i></small>', 'dpr-adeline-extensions')),

                    'hint'     => array(

                        'title'   => esc_attr__('Appear Animation Duration', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set appear animation duration in miliseconds. If you leave this blank will be used default value 400ms', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('portfolio_entry_appear_animation_effect', 'not', 'none'),

                ),

                array(

                    'id'       => 'portfolio_entry_appear_animation_delay',

                    'type'     => 'text',

                    'title'    => __('Appear Animation Delay', 'dpr-adeline-extensions'),

                    'desc'     => wp_kses_post(__('<small><i>Set appear animation delay in miliseconds.<br/>If you leave this blank snimstion will be dnot delayed</i></small>', 'dpr-adeline-extensions')),

                    'hint'     => array(

                        'title'   => esc_attr__('Appear Animation Delay', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set appear animation delay in miliseconds.<br/>If you leave this blank snimstion will be dnot delayed.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('portfolio_entry_appear_animation_effect', 'not', 'none'),

                ),

                array(

                    'id'    => 'media_style_info',

                    'type'  => 'info',

                    'style' => 'dpr-title',

                    'title' => wp_kses_post(__('<h3>Image & Overlay Content Style</h3>', 'dpr-adeline-extensions')),

                ),

                array(

                    'id'      => 'portfolio_entry_img_size',

                    'type'    => 'select',

                    'title'   => esc_html__('Image Size', 'dpr-adeline-extensions'),

                    'desc'    => '',

                    'options' => array(

                        'thumbnail'    => esc_html__('Thumbnail', 'dpr-adeline-extensions'),

                        'medium'       => esc_html__('Medium', 'dpr-adeline-extensions'),

                        'medium_large' => esc_html__('Medium Large', 'dpr-adeline-extensions'),

                        'large'        => esc_html__('Large', 'dpr-adeline-extensions'),

                        'full'         => esc_html__('Full', 'dpr-adeline-extensions'),

                        'custom'       => esc_html__('Custom', 'dpr-adeline-extensions'),

                    ),

                    'hint'    => array(

                        'title'   => esc_attr__('Image Size', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set image size for portfolio.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'portfolio_entry_img_width',

                    'type'     => 'dimensions',

                    'title'    => esc_html__('Custom Image Width (px)', 'dpr-adeline-extensions'),

                    'width'    => true,

                    'height'   => false,

                    'mode'     => array('width' => 'width', 'height' => 'height'),

                    'units'    => array('px'),

                    'hint'     => array(

                        'title'   => esc_attr__('Custom Image Width', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Specify the cusrtom image width. In combination with custom image height bellow you can set custom image aspect ratio.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('portfolio_entry_img_size', 'equals', 'custom'),

                ),

                array(

                    'id'       => 'portfolio_entry_img_height',

                    'type'     => 'dimensions',

                    'title'    => esc_html__('Custom Image Height (px)', 'dpr-adeline-extensions'),

                    'width'    => false,

                    'height'   => true,

                    'mode'     => array('width' => 'width', 'height' => 'height'),

                    'units'    => array('px'),

                    'hint'     => array(

                        'title'   => esc_attr__('Custom Image Height', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Specify the cusrtom image height. In combination with custom image width above you can set custom featured image aspect ratio.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('portfolio_entry_img_size', 'equals', 'custom'),

                ),

                array(

                    'id'      => 'portfolio_entry_overlay_type',

                    'type'    => 'radio',

                    'title'   => __('Image Overlay Type', 'dpr-adeline-extensions'),

                    'options' => array(

                        'solid-color' => 'Solid Color',

                        'gradient'    => 'Gradient',

                    ),

                    'hint'    => array(

                        'title'   => esc_attr__('Overlay Type', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set image overlay type', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'portfolio_entry_overlay_color',

                    'type'     => 'color',

                    'title'    => __('Overlay Color', 'dpr-adeline-extensions'),

                    'output'   => array('background-color' => '.portfolio-items .portfolio-item-thumbnail .overlay.solid-color .inner'),

                    'hint'     => array(

                        'title'   => esc_attr__('Overlay Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set overlay color.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('portfolio_entry_overlay_type', 'equals', 'solid-color'),

                ),

                array(

                    'id'       => 'portfolio_entry_overlay_gradient',

                    'type'     => 'dpr_color_gradient',

                    'output'   => array('.portfolio-items .portfolio-item-thumbnail .overlay.gradient .inner'),

                    'title'    => esc_html__('Overlay Gradient', 'dpr-adeline-extensions'),

                    'hint'     => array(

                        'title'   => esc_attr__('Overlay Gradient', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set gradient for image overlay.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('portfolio_entry_overlay_type', 'equals', 'gradient'),

                ),

                array(

                    'id'             => 'portfolio_entry_overlay_spacing',

                    'type'           => 'spacing',

                    'output'         => array('.portfolio-items .portfolio-item-thumbnail .overlay'),

                    'mode'           => 'padding',

                    'units'          => array('px', '%'),

                    'all'            => true,

                    'display_units'  => true,

                    'units_extended' => false,

                    'title'          => __('Overlay Padding', 'dpr-adeline-extensions'),

                    'hint'           => array(

                        'title'   => esc_attr__('Overlay Padding', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Add overlay padding if you wish overlay frame', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'      => 'portfolio_entry_overlay_icons_style',

                    'type'    => 'radio',

                    'title'   => __('Overlay Icons', 'dpr-adeline-extensions'),

                    'options' => array(

                        'none'  => 'No Icons',

                        'icons' => 'Icons',

                        'plus'  => 'Plus Sign',

                    ),

                    'hint'    => array(

                        'title'   => esc_attr__('Overlay Icons', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set image overlay icons style', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'portfolio_entry_overlay_icons_size',

                    'type'     => 'dimensions',

                    'title'    => esc_html__('Icon Dimsensinons', 'dpr-adeline-extensions'),

                    'output'   => array('.portfolio-items .portfolio-item-thumbnail .portfolio-overlay-icons li a'),

                    'width'    => true,

                    'height'   => true,

                    'mode'     => array('width' => 'width', 'height' => 'height'),

                    'units'    => array('px'),

                    'hint'     => array(

                        'title'   => esc_attr__('Icon Dimmensions', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Specify the icon size.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('portfolio_entry_overlay_icons_style', 'equals', 'icons'),

                ),

                array(

                    'id'          => 'portfolio_entry_overlay_icons_font_size',

                    'type'        => 'typography',

                    'title'       => __('Icon Font Size', 'redux-framework-demo'),

                    'google'      => false,

                    'font-backup' => false,

                    'font-style'  => false,

                    'font-weight' => false,

                    'font-family' => false,

                    'subsets'     => false,

                    'color'       => false,

                    'text-align'  => false,

                    'line-height' => false,

                    'text'        => '&nbsp;',

                    'output'      => array('.portfolio-items .portfolio-item-thumbnail .portfolio-overlay-icons li a'),

                    'units'       => 'px',

                    'hint'        => array(

                        'title'   => esc_attr__('Icon Font Size', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set overlay icons font size.', 'dpr-adeline-extensions'),

                    ),

                    'required'    => array('portfolio_entry_overlay_icons_style', 'equals', 'icons'),

                ),

                array(

                    'id'       => 'portfolio_entry_overlay_icon_link',

                    'type'     => 'radio',

                    'title'    => __('Link Icon', 'dpr-adeline-extensions'),

                    'required' => array('portfolio_entry_overlay_icons_style', 'equals', 'icons'),

                    'options'  => array(

                        'none'          => 'None',

                        'theme-default' => 'Theme Default',

                        'custom'        => 'Custom Icon',

                    ),

                    'hint'     => array(

                        'title'   => esc_attr__('Link Icon', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Enable or disable link icon and eventually select custom link icon.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'portfolio_entry_custom_link_icon',

                    'type'     => 'dpr_icon_selector',

                    'title'    => __('Link Icon', 'dpr-adeline-extensions'),

                    'required' => array('portfolio_entry_overlay_icon_link', 'equals', 'custom'),

                    'hint'     => array(

                        'title'   => esc_attr__('Link Icon', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set link icon.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'portfolio_entry_overlay_icon_zoom',

                    'type'     => 'radio',

                    'title'    => __('Zoom Icon', 'dpr-adeline-extensions'),

                    'required' => array('portfolio_entry_overlay_icons_style', 'equals', 'icons'),

                    'options'  => array(

                        'none'          => 'None',

                        'theme-default' => 'Theme Default',

                        'custom'        => 'Custom Icon',

                    ),

                    'hint'     => array(

                        'title'   => esc_attr__('Zoom Icon', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Enable or disable zoom icon and eventually select custom zoom icon.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'portfolio_entry_custom_zoom_icon',

                    'type'     => 'dpr_icon_selector',

                    'title'    => __('Zoom Icon', 'dpr-adeline-extensions'),

                    'required' => array('portfolio_entry_overlay_icon_zoom', 'equals', 'custom'),

                    'hint'     => array(

                        'title'   => esc_attr__('Zoom Icon', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set zoom icon.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'portfolio_entry_icon_bg',

                    'type'     => 'color',

                    'title'    => __('Icon Background Color', 'dpr-adeline-extensions'),

                    'output'   => array('background-color' => '.portfolio-items .portfolio-item-thumbnail .portfolio-overlay-icons li a'),

                    'hint'     => array(

                        'title'   => esc_attr__('Icon Background Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set overlay icons background color.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('portfolio_entry_overlay_icons_style', 'equals', 'icons'),

                ),

                array(

                    'id'       => 'portfolio_entry_icon_color',

                    'type'     => 'color',

                    'title'    => __('Icon Color', 'dpr-adeline-extensions'),

                    'output'   => array('color' => '.portfolio-items .portfolio-item-thumbnail .portfolio-overlay-icons li a'),

                    'hint'     => array(

                        'title'   => esc_attr__('Icon Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set overlay icons color.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('portfolio_entry_overlay_icons_style', 'equals', 'icons'),

                ),

                array(

                    'id'       => 'portfolio_entry_icon_border',

                    'type'     => 'border',

                    'title'    => __('Icon Border', 'dpr-adeline-extensions'),

                    'output'   => array('.portfolio-items .portfolio-item-thumbnail .portfolio-overlay-icons li a'),

                    'hint'     => array(

                        'title'   => esc_attr__('Icon Border', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set overlay icons border.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('portfolio_entry_overlay_icons_style', 'equals', 'icons'),

                ),

                array(

                    'id'       => 'portfolio_entry_icon_bg_hover',

                    'type'     => 'color',

                    'title'    => __('Icon Background Color: Hover', 'dpr-adeline-extensions'),

                    'output'   => array('background-color' => '.portfolio-items .portfolio-item-thumbnail .portfolio-overlay-icons li a:hover'),

                    'hint'     => array(

                        'title'   => esc_attr__('Icon Background Color: Hover', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set overlay icons background hover color.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('portfolio_entry_overlay_icons_style', 'equals', 'icons'),

                ),

                array(

                    'id'       => 'portfolio_entry_icon_color_hover',

                    'type'     => 'color',

                    'title'    => __('Icon Color: Hover', 'dpr-adeline-extensions'),

                    'output'   => array('color' => '.portfolio-items .portfolio-item-thumbnail .portfolio-overlay-icons li a:hover'),

                    'hint'     => array(

                        'title'   => esc_attr__('Icon Color: Hover', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set overlay icons hover color.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('portfolio_entry_overlay_icons_style', 'equals', 'icons'),

                ),

                array(

                    'id'       => 'portfolio_entry_icon_border_hover',

                    'type'     => 'border',

                    'title'    => __('Icon Border: Hover', 'dpr-adeline-extensions'),

                    'output'   => array('.portfolio-items .portfolio-item-thumbnail .portfolio-overlay-icons li a:hover'),

                    'hint'     => array(

                        'title'   => esc_attr__('Icon Border: Hover', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set overlay icons hover border.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('portfolio_entry_overlay_icons_style', 'equals', 'icons'),

                ),

                array(

                    'id'       => 'portfolio_entry_overlay_plus_link',

                    'type'     => 'radio',

                    'title'    => __('Plus Sign Link', 'dpr-adeline-extensions'),

                    'required' => array('portfolio_entry_overlay_icons_style', 'equals', 'plus'),

                    'options'  => array(

                        'item'     => 'Portfolio Item',

                        'lightbox' => 'Lightbox',

                    ),

                    'hint'     => array(

                        'title'   => esc_attr__('Plus Sign Link', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set link for plus sign.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'portfolio_entry_overlay_plus_size',

                    'type'     => 'dimensions',

                    'title'    => esc_html__('Plus Sign Dimsensinons', 'dpr-adeline-extensions'),

                    'output'   => array('.portfolio-items .portfolio-item-thumbnail .portfolio-plus-sign'),

                    'width'    => true,

                    'height'   => true,

                    'mode'     => array('width' => 'width', 'height' => 'height'),

                    'units'    => array('px'),

                    'hint'     => array(

                        'title'   => esc_attr__('Plus Sign Dimsensinons', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Specify the plus sign size.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('portfolio_entry_overlay_icons_style', 'equals', 'plus'),

                ),

                array(

                    'id'       => 'portfolio_entry_overlay_plus_color',

                    'type'     => 'color',

                    'title'    => __('Plus Sign Color', 'dpr-adeline-extensions'),

                    'output'   => array('fill' => '.portfolio-items .portfolio-item-thumbnail .portfolio-plus-sign svg .to-fill '),

                    'hint'     => array(

                        'title'   => esc_attr__('Plus Sign Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set overlay plus sign color.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('portfolio_entry_overlay_icons_style', 'equals', 'plus'),

                ),

                array(

                    'id'       => 'portfolio_entry_overlay_plus_color_hover',

                    'type'     => 'color',

                    'title'    => __('Plus Sign Color: Hover', 'dpr-adeline-extensions'),

                    'output'   => array('fill' => '.portfolio-items .portfolio-item-thumbnail .portfolio-plus-sign:hover svg .to-fill '),

                    'hint'     => array(

                        'title'   => esc_attr__('Plus Sign Color: Hover', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set overlay plus sign hover color.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('portfolio_entry_overlay_icons_style', 'equals', 'plus'),

                ),

                array(

                    'id'       => 'portfolio_entry_overlay_title_color',

                    'type'     => 'color',

                    'title'    => __('Overlay Title Color', 'dpr-adeline-extensions'),

                    'output'   => array('color' => '.portfolio-items .portfolio-item-thumbnail .portfolio-inside-content .portfolio-item-title a'),

                    'hint'     => array(

                        'title'   => esc_attr__('Title Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set portfolio entry overlay title color.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('portfolio_entry_content_style', 'equals', 'inside'),

                ),

                array(

                    'id'       => 'portfolio_entry_overlay_title_color_hover',

                    'type'     => 'color',

                    'title'    => __('Overlay Title Color: Hover', 'dpr-adeline-extensions'),

                    'output'   => array('color' => '.portfolio-items .portfolio-item-thumbnail .portfolio-inside-content .portfolio-item-title a:hover'),

                    'hint'     => array(

                        'title'   => esc_attr__('Title Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set portfolio entry overlay title hover color.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('portfolio_entry_content_style', 'equals', 'inside'),

                ),

                array(

                    'id'       => 'portfolio_entry_overlay_category_color',

                    'type'     => 'color',

                    'title'    => __('Overlay Category Color', 'dpr-adeline-extensions'),

                    'output'   => array('color' => '.portfolio-items .portfolio-item-thumbnail .portfolio-inside-content .categories, .portfolio-items .portfolio-item-thumbnail .portfolio-inside-content .categories a'),

                    'hint'     => array(

                        'title'   => esc_attr__('Category Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set portfolio entry overlay category color.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('portfolio_entry_content_style', 'equals', 'inside'),

                ),

                array(

                    'id'       => 'portfolio_entry_overlay_category_color_hover',

                    'type'     => 'color',

                    'title'    => __('Overlay Category Color: Hover', 'dpr-adeline-extensions'),

                    'output'   => array('color' => '.portfolio-items .portfolio-item-thumbnail .portfolio-inside-content .categories a:hover'),

                    'hint'     => array(

                        'title'   => esc_attr__('Category Color: Hover', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set portfolio entry overlay category hover color.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('portfolio_entry_content_style', 'equals', 'inside'),

                ),

            ),

        );

        return $portfolio_metabox_sections;

    }

endif;
