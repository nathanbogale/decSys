<?php



/**

 *

 * Function used to add social share section

 *

 **/



if(!function_exists('dpr_add_social_share')) {



	function dpr_add_social_share() {

		include_once(DPR_EXTENSIONS_PLUGIN_PATH.'inc/social_share/templates/social-share.php');

	}



}

/**

 *

 * Function used to add social share section in product

 *

 **/



if(!function_exists('dpr_add_woo_social_share')) {



	function dpr_add_woo_social_share() {

		include_once(DPR_EXTENSIONS_PLUGIN_PATH.'inc/social_share/templates/woo-social-share.php');

	}



}






// EOF