<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$output = $id = $images = $img_max_width = $el_class = $style = $custom_el_css =  $css = '';

$atts = vc_map_get_attributes($this->getShortcode(), $atts);
extract( $atts );


	$id = uniqid('dpr-imagetrail-');
	wp_enqueue_script('tweenmax', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/TweenMax.min.js', array('jquery'), null, true);
	
	$jsID = '1';

	if(isset($style) && $style !='') {
	 $jsID = $style;
	}
	
	switch ($jsID) {
    case '1':
    	wp_enqueue_script('image-trail', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/dpr.image.trail-1.js', array('jquery'), null, false);         
        break;
    case '2':
     	wp_enqueue_script('image-trail', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/dpr.image.trail-2.js', array('jquery'), null, false);        
        break;
    case '3':
    	wp_enqueue_script('image-trail', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/dpr.image.trail-3.js', array('jquery'), null, false);        
        break;
    case '4':
    	wp_enqueue_script('image-trail', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/dpr.image.trail-4.js', array('jquery'), null, false);        
        break;
    case '5':
     	wp_enqueue_script('image-trail', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/dpr.image.trail-5.js', array('jquery'), null, false);       
        break;
    case '6':    	
		wp_enqueue_script('image-trail', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/dpr.image.trail-6.js', array('jquery'), null, false);         
        break;
    default:
    	wp_enqueue_script('image-trail', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/dpr.image.trail-1.js', array('jquery'), null, false);   
}	
	
	/* Element classes */

	if(isset($style) && !empty($style)) {
		$el_class .= ' style-'.$style;
	}
	
	$css_classes = array(
		'dpr-imagetrail-wrapper',
		esc_attr($id),
		$el_class,
		vc_shortcode_custom_css_class( $css ),
	);

	$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->settings['base'], $atts ) );

	// Custom CSS stuff
	$maxwidth = 250;
	if(isset($img_max_width) && $img_max_width != '') { 
		$maxwidth= $img_max_width;
	}
	if ($style != '6') {
	$custom_el_css .= '.'.esc_js($id).'.dpr-imagetrail-wrapper .trail-img  {max-width:'.esc_js($maxwidth).'px;}';
	}
	/* Generate Output */

	if ( '' === $images ) {
	$images = '-1,-2,-3';
	}
	$images = explode( ',', $images );


	$output .= '<div id="'.esc_attr($id).'" class="'.esc_attr($css_class).'">';
	$output .= '<div class="trail-images">';
	
	foreach ( $images as $i => $image ) {
		if ( $image > 0 ) {
				$img = dpr_get_attachment_image_src( $image,'full');
				$large_img_src = $img[0];
				if($style == '6'){
				$output .=  '<div class="trail-img trail-img-full" style="background-image:url('.esc_url($large_img_src).');"></div>';
				} else {
				$output .=  '<img class="trail-img" alt="" src="'.esc_url($large_img_src).'"  />';
				}
		}
	}

    $output .= '</div>';
    $output .= '<div class="content-wrap">';
    $output .= do_shortcode($content);
    $output .= '</div>';

	if($custom_el_css != '') {
			$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>")'
						. '})(jQuery);'
					. '</script>';
		}




	$output .= '</div>';

echo $output;