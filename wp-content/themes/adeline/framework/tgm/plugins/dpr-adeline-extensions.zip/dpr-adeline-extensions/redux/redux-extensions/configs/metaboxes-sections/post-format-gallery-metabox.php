<?php







if ( !function_exists( "dpr_post_format_gallery_sections " ) ):



    function dpr_post_format_gallery_sections() {



		



		/*



     	* ---> START POST FORMAT GALLERY METABOX SECTIONS



		*/







		$post_format_gallery_sections = array();



		$post_format_gallery_sections[] = array(



			'fields'   => array(



								array(



									'id'        => 'galery_post_images',



									'type'      => 'multi_media',



									'labels'    => array(



										'upload_file'       => __('Select File(s)', 'dpr-adeline-extensions'),



										'remove_image'      => __('Remove Image', 'dpr-adeline-extensions'),



										'remove_file'       => __('Remove', 'dpr-adeline-extensions'),



										'file'              => __('File: ', 'dpr-adeline-extensions'),



										'download'          => __('Download', 'dpr-adeline-extensions'),



										'title'             => __('Add Gallery Images', 'dpr-adeline-extensions'),



										'button'            => __('Add Images','dpr-adeline-extensions')



									),



									'library_filter'  => array('gif','jpg','png'),



								),



								array(



									'id'       => 'galery_post_lightbox',



									'type'     => 'switch',



									'default' => false,



									'title'    =>  esc_html__('Enable lightbox for this gallery?','dpr-adeline-extensions')



								),



								



								



			)



		);



		



		/*



     	* ---> END POST FORMAT GALLERY METABOX SECTIONS



		*/







        return $post_format_gallery_sections;



    }



endif;