<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$output = $unique_id = $style = $alignment = $content_position = $css_animation = $css = $el_class =  '';
$product = $image_type = $image = $image_width = $image_height = $title = $price = $add_to_cart = $rating = $onsale = $quickview = '';
$title_color = $price_color = $add_to_cart_color = $add_to_cart_color_hover = $add_to_cart_bg = $add_to_cart_bg_hover = $mask_type = $mask_color = $mask_gradient = '';
$title_font_size = $title_line_height  = $title_letter_spacing = $title_font_style = $title_google_font = $title_typo_style = '';
$price_font_size = $price_line_height  = $price_letter_spacing = $price_font_style = $price_google_font = $price_typo_style =  '';
$image_html = $title_html = $price_html = $add_to_cart_html = $rating_html = $quick_view_html = $onsale_html = '';
$custom_el_css = '';

$atts = vc_map_get_attributes( 'dpr_woo_single_product', $atts );
extract( $atts );

$unique_id = uniqid('dpr-woo-single-product-').'-'.rand(1,9999);

/* CSS Classes and styles */
if ( '' !== $css_animation && 'none' !== $css_animation ) {
	dpr_enqueue_waypoint_js();
	dpr_enqueue_animate_css();
	$el_class .= ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
}

/* Output */
$css_classes = array(
	'dpr-woo-single-product',
	esc_attr($unique_id),
	$el_class,
	vc_shortcode_custom_css_class( $css ),
);

if(isset($style) && $style != '') {
	$css_classes[] = $style;
}
if(isset($content_position) && $content_position != '' && ($style == 'compact' || $style == 'overlay')) {
	$css_classes[] = 'content-'.$content_position;
}
if(isset($alignment) && $alignment != '' && ($style == 'default')) {
	$css_classes[] = 'content-'.$alignment;
}

$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->settings['base'], $atts ) );

$add_prod_classes = '';

if(adeline_get_option_value( 'woo_onsale_style') == 'circle') {
$add_prod_classes .= ' circle-sale';
}


// Custom CSS stuff
$title_typo_style = dpr_generate_typography_style('', $title_font_size, $title_line_height, $title_letter_spacing, $title_font_style,$title_google_font);

$price_typo_style = dpr_generate_typography_style('', $price_font_size, $price_line_height, $price_letter_spacing, $price_font_style,$price_google_font);

if(isset($price_color) && $price_color != '') {
	$custom_el_css .= '.'.esc_js($unique_id).'  .product-inner .price-wrap .price span, .'.esc_js($unique_id).'  .product-inner .price-wrap .price .amount {color:'.$price_color.'!important;}';
}

if(isset($title_color) && $title_color != '') {
	$custom_el_css .= '.'.esc_js($unique_id).'  h4.product-title, .'.esc_js($unique_id).'  h4.product-title a  {color:'.$title_color.'!important;}';
}

if(isset($add_to_cart_color) && $add_to_cart_color != '') {
	$custom_el_css .= '.'.esc_js($unique_id).'  .add_to_cart_button {color:'.$add_to_cart_color.'!important;}';
}
if(isset($add_to_cart_bg) && $add_to_cart_bg != '') {
	$custom_el_css .= '.'.esc_js($unique_id).'  .add_to_cart_button {background-color:'.$add_to_cart_bg.'!important; border-color:'.$add_to_cart_bg.'!important;}';
}
if(isset($add_to_cart_color_hover) && $add_to_cart_color_hover != '') {
	$custom_el_css .= '.'.esc_js($unique_id).'  .add_to_cart_button:hover {color:'.$add_to_cart_color_hover.'!important;}';
}
if(isset($add_to_cart_bg_hover) && $add_to_cart_bg_hover != '') {
	$custom_el_css .= '.'.esc_js($unique_id).'  .add_to_cart_button:hover {background-color:'.$add_to_cart_bg_hover.'!important; border-color:'.$add_to_cart_bg_hover.'!important;}';
}

if(isset($mask_color) && $mask_color != '' && $mask_type == 'solid') {
	$custom_el_css .= '.'.esc_js($unique_id).'.overlay .product-inner .image-wrap > a:before {background-color:'.$mask_color.';}';
}
if(isset($mask_gradient) && $mask_gradient != '' && $mask_type == 'gradient') {
	$custom_el_css .= '.'.esc_js($unique_id).'.overlay .product-inner .image-wrap > a:before {'.esc_js(adeline_gradientToBgCSS ($mask_gradient)).'}';
}


/* HTML Parts */



?>

<div id="<?php echo esc_attr($unique_id) ?>" class="woocommerce <?php echo esc_attr($css_class) ?>">
<?php if(isset($product) && $product !='') { ?>
    <ul class="products">
    <?php 
	/* Query */
	$args = array('post_type' => 'product','p' => $product );
	$loop = new WP_Query($args);
	while ($loop->have_posts()): $loop->the_post();global $product;	
	?>
        <li class="product <?php echo esc_attr($add_prod_classes) ?>">
            <div class="product-inner clr">
            	<?php 
				if ($quickview == 'yes') {	?>
							<a href="#" id="product_id_<?php echo $product->get_id()?>" class="dpr-quick-view" style="z-index=1000;" data-product_id="<?php echo $product->get_id()?>"><i class="dpr-icon-eye"></i><?php echo esc_html__( 'Quick View', 'dpr-adeline-extensions' ) ?></a>
			<?php
				}?>
                <?php 
				// Wishlist button
				if ($wishlist == 'yes' && is_plugin_active( 'ti-woocommerce-wishlist/ti-woocommerce-wishlist.php' )) {
				echo do_shortcode("[ti_wishlists_addtowishlist loop=yes]") ;
				}
				?>
                <div class="title-wrap">
                	<?php if($title == 'yes') { ?>
                       <h4 class="product-title" <?php echo $title_typo_style ?>><a href="<?php echo esc_url(get_permalink($loop->post->ID)) ?>" title="" ><?php the_title();?></a></h4>
                    <?php } ?>
                    <?php if($price == 'yes') { ?>
                    <div class="price-wrap">
                    <span class="price" <?php echo $price_typo_style ?>><?php echo $product->get_price_html(); ?></span>
                    </div>
					<?php } ?>
                    <?php if($rating == 'yes') { ?>
					<div class="rating-wrap"> 
                    <?php woocommerce_template_loop_rating();?>
                    </div>
					<?php } ?>
                    <?php if($add_to_cart == 'yes') { ?>
                    <div class="button-wrap"> 
                    <?php woocommerce_template_loop_add_to_cart(); ?>
                    </div>
					<?php } ?>
                </div>
                
                <?php
				//On sale badge 
				if ($onsale == 'yes') {
				if ( class_exists( 'DPR_Adeline_WooCommerce_Config' ) ) {
					DPR_Adeline_WooCommerce_Config::adeline_add_out_of_stock_badge();
				}
				woocommerce_show_product_loop_sale_flash();
				}?>               
                <div class="image-wrap clr">
                	<?php
					// Product image
                    $w = 600;
					$h = 600;
					$img_html = '';
					if(isset($image_width) && $image_width != '') {
						$w = $image_width;
					}
					if(isset($image_height) && $image_height != '') {
						$h = $image_height;
					}
					
					if(isset($image_type) && $image_type == 'custom' && isset($image) && $image != '') {
						$img_src = dpr_get_attachment_image_src($image, 'full');
					} else {
						if(has_post_thumbnail($loop->post->ID)) {
							$thumb = get_post_thumbnail_id($loop->post->ID);
							$img_src = dpr_get_attachment_image_src($thumb, 'full');
						}
					}
					if (!empty($img_src)) {
						$img_atts = adeline_image_attributes( $img_src[1], $img_src[2], $w, $h );
						$img_html = '<img src="'.adeline_resize( $img_src[0], $img_atts[ 'width' ], $img_atts[ 'height' ], $img_atts[ 'crop' ], true, $img_atts[ 'upscale' ] ).'" width="'.esc_attr( $w ).'" height="'.esc_attr( $h ).'"/>';
					} else {
						$img_html = wc_placeholder_img();
					}
					
					
					?>
                    <a href="<?php echo esc_url(get_permalink($loop->post->ID)) ?>" class="woocommerce-LoopProduct-link"><?php echo $img_html ?></a>
                </div>
				<div class="content-wrap">
                	<?php if($title == 'yes') { ?>
                       <h4 class="product-title" <?php echo $title_typo_style ?>><a href="<?php echo esc_url(get_permalink($loop->post->ID)) ?>  " title="" ><?php the_title();?></a></h4>
                    <?php } ?>
                    <?php if($price == 'yes') { ?>
                    <div class="price-wrap" <?php echo $price_typo_style ?>>
                    <span class="price"><?php echo $product->get_price_html(); ?></span>
                    </div>
					<?php } ?>
                    <?php if($rating == 'yes') { ?>
					<div class="rating-wrap"> 
                    <?php woocommerce_template_loop_rating();?>
                    </div>
					<?php } ?>
                    <?php if($add_to_cart == 'yes') { ?>
                    <div class="button-wrap"> 
                    <?php woocommerce_template_loop_add_to_cart(); ?>
                    </div>
					<?php } ?>
                </div> 
                
            </div>
        </li>
    <?php endwhile;?>
    <?php wp_reset_query();?>
    </ul>
<?php } else {
	echo '<p>'.esc_html__('No product selected', 'dpr-adeline-extensions').'</p>';
} ?>

<?php
	if(!empty($custom_el_css)) {
		$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>");'
						. '})(jQuery);'
					. '</script>';
}



echo $output;
?>
</div>
