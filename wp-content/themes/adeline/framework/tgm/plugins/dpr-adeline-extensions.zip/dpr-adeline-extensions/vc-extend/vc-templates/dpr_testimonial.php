<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$unique_id = $css_animation = $el_class = $output = $custom_el_css = $style = '';
$image_id = $img_size = $img_border_radius = $img_border_width = $img_border_color = $enable_shadow = $image_shadow = $bg_color = $bg_border_radius = $enable_arrow = '';
$title = $title_color = $title_font_size = $title_line_height  = $title_letter_spacing = $title_font_style = $title_google_font = $title_typo_style = '';
$subtitle = $subtitle_color = $subtitle_font_size = $subtitle_line_height  = $subtitle_letter_spacing = $subtitle_font_style = $subtitle_google_font = $subtitle_typo_style = $one_line_title = '';
$description = $content_color = $content_font_size = $content_line_height  = $content_letter_spacing = $content_font_style = $content_google_font = $content_typo_style = '';
$use_title_responsive_typo = $title_reaponsive_typography = $use_subtitle_responsive_typo = $subtitle_reaponsive_typography = $use_content_responsive_typo = $content_reaponsive_typography = '';
$image_html = $title_html = $subtitle_html = $description_html = '';

$atts = vc_map_get_attributes( 'dpr_testimonial', $atts );
extract( $atts );

$el_class = $this->getExtraClass( $el_class );
if ( '' !== $css_animation && 'none' !== $css_animation ) {
	dpr_enqueue_waypoint_js();
	dpr_enqueue_animate_css();
	$el_class .= ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
}
$unique_id = uniqid('dpr-tesimonial-').'-'.rand(1,9999);

/* Element classes */
if(isset($style)) {
	$el_class .= ' '.$style;
}
if(isset($one_line_title) && $one_line_title == 'yes') {
	$el_class .= ' one-line-title';
}
if(isset($enable_shadow) && $enable_shadow == 'yes') {
	$el_class .= ' img-with-shadow';
}

if(isset($bg_color) && $bg_color != '') {
	$el_class .= ' bubble-with-bg';
}
if(isset($enable_arrow) && $enable_arrow == 'yes') {
	$el_class .= ' bubble-with-arrow';
}

$css_classes = array(
	'dpr-testimonial',
	esc_attr($unique_id),
	$el_class,
);

$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->settings['base'], $atts ) );

/* * ************************
 * Styles and custom CSS
 * *********************** */
if (isset($enable_shadow) && $enable_shadow == 'yes') {
		$custom_el_css .= '.'.esc_js($unique_id) .' .image-wrap .inner img{'.dpr_shadow_param_to_css($image_shadow).'}';
}
if (isset($bg_color) && $bg_color != '') {
	$custom_el_css .= '.'.esc_js($unique_id).'.bubble-with-bg .box-content {background-color:'.esc_attr($bg_color).';}';
}
if (isset($bg_border_radius) && $bg_border_radius != '') {
		$custom_el_css .= '.'.esc_js($unique_id) .'.bubble-with-bg .box-content  {border-radius:'.$bg_border_radius.'px;}';
}
if (isset($enable_arrow) && $enable_arrow == 'yes' && $bg_color != '' ) {
		$arrow_offset_left = 45;
		$arrow_offset_right = 30;
		if(isset($img_size) && $img_size !='') {
			$arrow_offset_left = round($img_size/2);
			$arrow_offset_right = round(($img_size/2)-15);
		}
		$custom_el_css .= '.'.esc_js($unique_id) .'.style-1 .box-content-wrap:after, .'.esc_js($unique_id) .'.style-2 .box-content-wrap:after, .'.esc_js($unique_id) .'.style-3 .box-content-wrap:after, .'.esc_js($unique_id) .'.style-4 .box-content-wrap:after {border-color: '.$bg_color.' transparent !important;}';
		$custom_el_css .= '.'.esc_js($unique_id) .'.style-5 .box-content-wrap:after, .'.esc_js($unique_id) .'.style-6 .box-content-wrap:after {border-color: transparent '.$bg_color.' !important;}';
		$custom_el_css .= '.'.esc_js($unique_id) .'.style-7 .box-content-wrap:after, .'.esc_js($unique_id) .'.style-9 .box-content-wrap:after {border-color: '.$bg_color.' transparent; !important left:auto;right:'.$arrow_offset_right.'px;}';
		$custom_el_css .= '.'.esc_js($unique_id) .'.style-8 .box-content-wrap:after, .'.esc_js($unique_id) .'.style-10 .box-content-wrap:after {border-color: '.$bg_color.' transparent !important; left:'.$arrow_offset_left.'px;}';
}



/* * ************************
 * Partial HTML.
 * *********************** */

/* Image*/
if(isset($image_id) && $image_id != '') {
	
	$img_style = '';
	if($img_size == '') {
		$img_size = 90;
	}
	$img_style .= 'width:'.$img_size.'px; height:'.$img_size.'px;';
	if(isset($img_border_width) && $img_border_width > 0 ) {
		$img_style .= 'border-width:'.$img_border_width.'px;';
	}
	if(isset($img_border_color) && $img_border_color !='' ) {
		$img_style .= 'border-color:'.$img_border_color.';';
	}
	if(isset($img_border_radius) && $img_border_radius !='' ) {
		$img_style .= 'border-radius:'.$img_border_radius.'px;';
	} else {
		$img_style .= 'border-radius:50%;';
	}
	$img_style .= 'border-style:solid;';
	$img_style = 'style= "'.$img_style.'"';
	$image = dpr_get_attachment_image_src($image_id, 'full');
	$alt_text = get_post_meta($image_id , '_wp_attachment_image_alt', true);
	$image_html .= '<div class="inner"><img src="'.esc_url($image[0]).'" alt ="'.esc_attr($alt_text).'" '.$img_style.'/></div>';
}

/* Title */
if(!empty($title)) {
	$title_typo_style = dpr_generate_typography_style($title_color, $title_font_size, $title_line_height, $title_letter_spacing, $title_font_style,$title_google_font);
	$title_html .= '<h4 class="title" ' . $title_typo_style . '>' . $title . '</h4>';
}
/* Subtitle */
if(!empty($subtitle)) {
	$subtitle_typo_style = dpr_generate_typography_style($subtitle_color, $subtitle_font_size, $subtitle_line_height, $subtitle_letter_spacing, $subtitle_font_style,$subtitle_google_font);
	$subtitle_html .= '<div class="subtitle" ' . $subtitle_typo_style . '>' . $subtitle . '</div>';
}
/* Description */
if(!empty($description)) {
	$content_typo_style = dpr_generate_typography_style($content_color, $content_font_size, $content_line_height, $content_letter_spacing, $content_font_style,$content_google_font);
	$description_html .= '<div class="box-content" ' . $content_typo_style . '>' . wp_kses_post($description) . '</div>';
}
// Add responsive typo CSS
if($use_title_responsive_typo && isset($title_reaponsive_typography) && $title_reaponsive_typography != '') {
	$responsive_unique_class = '.'.esc_js($unique_id) .' .box-title .title';
	$custom_el_css .= DPR_Resposive_Typography_Param::generate_css($title_reaponsive_typography,$responsive_unique_class);
}
if($use_subtitle_responsive_typo && isset($subtitle_reaponsive_typography) && $subtitle_reaponsive_typography != '') {
	$responsive_unique_class = '.'.esc_js($unique_id) .' .box-title .subtitle';
	$custom_el_css .= DPR_Resposive_Typography_Param::generate_css($subtitle_reaponsive_typography,$responsive_unique_class);
}
if($use_content_responsive_typo && isset($subtitle_content_typography) && $content_reaponsive_typography != '') {
	$responsive_unique_class = '.'.esc_js($unique_id) .' .box-content';
	$custom_el_css .= DPR_Resposive_Typography_Param::generate_css($content_reaponsive_typography,$responsive_unique_class);
}

/* * ************************
 * Output
 * *********************** */
$output .= '<div id="'.esc_attr($unique_id).'" class="'.esc_attr($css_class).'">';
switch ($style) {
	case 'style-1':
		$output .= '<div class="box-content-wrap text-center">';
		$output .= $description_html;
		$output .= '</div>';
		$output .= '<div class="image-wrap text-center">';
		$output .= $image_html;
		$output .= '</div>';
		$output .= '<div class="box-title text-center">';
		$output .= $title_html;
		$output .= $subtitle_html;
		$output .= '</div>';	
		break;
	case 'style-2':
		$output .= '<div class="image-wrap text-center">';
		$output .= $image_html;
		$output .= '</div>';
		$output .= '<div class="box-title text-center">';
		$output .= $title_html;
		$output .= $subtitle_html;
		$output .= '</div>';	
		$output .= '<div class="box-content-wrap text-center">';
		$output .= $description_html;
		$output .= '</div>';
		break;
	case 'style-3':
		$output .= '<div class="image-wrap text-center">';
		$output .= $image_html;
		$output .= '</div>';
		$output .= '<div class="box-content-wrap text-center">';
		$output .= $description_html;
		$output .= '</div>';
		$output .= '<div class="box-title text-center">';
		$output .= $title_html;
		$output .= $subtitle_html;
		$output .= '</div>';	
		break;
	case 'style-4':
		$output .= '<div class="box-title text-center">';
		$output .= $title_html;
		$output .= $subtitle_html;
		$output .= '</div>';	
		$output .= '<div class="box-content-wrap text-center">';
		$output .= $description_html;
		$output .= '</div>';
		$output .= '<div class="image-wrap text-center">';
		$output .= $image_html;
		$output .= '</div>';
		break;
	case 'style-5':
		$output .= '<div class="content-wrap">';
		$output .= '<div class="box-content-wrap text-right">';
		$output .= $description_html;
		$output .= '</div>';	
		$output .= '<div class="box-title text-right">';
		$output .= $title_html;
		$output .= $subtitle_html;
		$output .= '</div>';
		$output .= '</div>';
		$output .= '<div class="image-wrap text-center">';
		$output .= $image_html;
		$output .= '</div>';
		break;
	case 'style-6':
		$output .= '<div class="image-wrap text-center">';
		$output .= $image_html;
		$output .= '</div>';
		$output .= '<div class="content-wrap">';
		$output .= '<div class="box-content-wrap text-left">';
		$output .= $description_html;
		$output .= '</div>';	
		$output .= '<div class="box-title text-left">';
		$output .= $title_html;
		$output .= $subtitle_html;
		$output .= '</div>';
		$output .= '</div>';
		break;
	case 'style-7':
		$output .= '<div class="box-content-wrap text-right">';
		$output .= $description_html;
		$output .= '</div>';
		$output .= '<div class="image-wrap text-right">';
		$output .= $image_html;
		$output .= '</div>';
		$output .= '<div class="box-title text-right">';
		$output .= $title_html;
		$output .= $subtitle_html;
		$output .= '</div>';	
		break;
	case 'style-8':
		$output .= '<div class="box-content-wrap text-left">';
		$output .= $description_html;
		$output .= '</div>';
		$output .= '<div class="image-wrap text-left">';
		$output .= $image_html;
		$output .= '</div>';
		$output .= '<div class="box-title text-left">';
		$output .= $title_html;
		$output .= $subtitle_html;
		$output .= '</div>';	
		break;
	case 'style-9':
		$output .= '<div class="image-wrap text-right">';
		$output .= $image_html;
		$output .= '</div>';
		$output .= '<div class="box-content-wrap text-right">';
		$output .= $description_html;
		$output .= '</div>';
		$output .= '<div class="box-title text-right">';
		$output .= $title_html;
		$output .= $subtitle_html;
		$output .= '</div>';	
		break;
	case 'style-10':
		$output .= '<div class="image-wrap text-left">';
		$output .= $image_html;
		$output .= '</div>';
		$output .= '<div class="box-content-wrap text-left">';
		$output .= $description_html;
		$output .= '</div>';
		$output .= '<div class="box-title text-left">';
		$output .= $title_html;
		$output .= $subtitle_html;
		$output .= '</div>';	
		break;
}



if(!empty($custom_el_css)) {
		$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>");'
						. '})(jQuery);'
					. '</script>';
}
$output .= '</div>';

echo $output;