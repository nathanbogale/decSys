<?php

/**



 * Footer Options -> Copyright Area



 *



 */

Redux::setSection($opt_name, array(

    'title'      => esc_html__('Copright Area', 'dpr-adeline-extensions'),

    'id'         => 'copyright_area',

    'subsection' => true,

    'fields'     => array(

        array(

            'id'      => 'copyright_enable',

            'type'    => 'switch',

            'default' => true,

            'title'   => esc_html__('Enable Copyright Area', 'dpr-adeline-extensions'),

            'hint'    => array(

                'title'   => esc_attr__('Enable Footer', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enable or disable display of footer', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'           => 'copyright_text',

            'type'         => 'textarea',

            'title'        => __('Copyright Text', 'dpr-adeline-extensions'),

            'validate'     => 'html_custom',

            'default'      => '© 2020, Adeline Theme by DynamicPress Team.',

            'allowed_html' => array(

                'a'      => array(

                    'href'  => array(),

                    'title' => array(),

                ),

                'br'     => array(),

                'em'     => array(),

                'strong' => array(),

            ),

            'hint'         => array(

                'title'   => esc_attr__('Copyright Text', 'dpr-adeline-extensions'),

                'content' => esc_attr__('You can set copyright text. Custom HTML is allowed', 'dpr-adeline-extensions'),

            ),

            'required'     => array('copyright_enable', 'equals', '1'),

        ),

        array(

            'id'       => 'copyright_visibility',

            'type'     => 'image_select',

            'title'    => __('Visibility', 'dpr-adeline-extensions'),

            'options'  => array(

                'all-devices'        => array(

                    'title' => esc_html__('All Devices', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/visibility/all.png',

                ),

                'hide-tablet'        => array(

                    'title' => esc_html__('Hide On Tablet', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/visibility/no_tablet.png',

                ),

                'hide-mobile'        => array(

                    'title' => esc_html__('Hide On Mobile', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/visibility/no_mobile.png',

                ),

                'hide-tablet-mobile' => array(

                    'title' => esc_html__('Hide On Tablet & Mobile', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/visibility/no_tablet_mobile.png',

                ),

            ),

            'default'  => 'all-devices',

            'hint'     => array(

                'title'   => esc_attr__('Visibility', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enable or disable display copyright area on certain devices.', 'dpr-adeline-extensions'),

            ),

            'required' => array('copyright_enable', 'equals', '1'),

        ),

        array(

            'id'       => 'force_full_width_copyright',

            'type'     => 'switch',

            'default'  => false,

            'title'    => esc_html__('Force Full Copyright Area', 'dpr-adeline-extensions'),

            'required' => array('copyright_enable', 'equals', '1'),

            'hint'     => array(

                'title'   => esc_attr__('Force Full Copyright Area', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Force full width copright area .', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'             => 'copyright_padding',

            'type'           => 'spacing',

            'output'         => array('#copyright-area'),

            'mode'           => 'padding',

            'units'          => array('px'),

            'display_units'  => true,

            'units_extended' => false,

            'title'          => __('Padding (px)', 'dpr-adeline-extensions'),

            'default'        => array(

                'padding-left'   => '0px',

                'padding-right'  => '0px',

                'padding-bottom' => '15px',

                'padding-top'    => '15px',

                'units'          => 'px',

            ),

            'hint'           => array(

                'title'   => esc_attr__('Padding', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Choose default padding for copyright area.', 'dpr-adeline-extensions'),

            ),

            'required'       => array('copyright_enable', 'equals', '1'),

        ),

        array(

            'id'       => 'copyright_area_bg',

            'type'     => 'color',

            'output'   => array('background-color' => '#copyright-area'),

            'validate' => 'color',

            'title'    => esc_html__('Background Color', 'dpr-adeline-extensions'),

            'default'  => 'rgba(0,0,0,0)',

            'required' => array('copyright_enable', 'equals', '1'),

            'hint'     => array(

                'title'   => esc_attr__('Background Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set background color for copyright area.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'copyright_text_color',

            'type'     => 'color',

            'output'   => array('color' => '#copyright-area,#copyright-area p'),

            'validate' => 'color',

            'title'    => esc_html__('Text Color', 'dpr-adeline-extensions'),

            'default'  => '#cccccc',

            'required' => array('copyright_enable', 'equals', '1'),

            'hint'     => array(

                'title'   => esc_attr__('Text Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set copyright area text color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'copyright_links_color',

            'type'     => 'color',

            'output'   => array('color' => '#copyright-area a,#copyright-area #copyright-area-menu a'),

            'validate' => 'color',

            'title'    => esc_html__('Links Color', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'required' => array('copyright_enable', 'equals', '1'),

            'hint'     => array(

                'title'   => esc_attr__('Links Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set copyright area links color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'copyright_links_color_hover',

            'type'     => 'color',

            'output'   => array('color' => '#copyright-area a:hover,#copyright-area #copyright-area-menu a:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Links Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'required' => array('copyright_enable', 'equals', '1'),

            'hint'     => array(

                'title'   => esc_attr__('Links Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set copyright area links hover color.', 'dpr-adeline-extensions'),

            ),

        ),

    ),

));
