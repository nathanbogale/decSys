<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$el_class = $output = $custom_el_css = $axe_style = $axe_size = $axe_color = '';


$atts = vc_map_get_attributes( 'dpr_workflow', $atts );
extract( $atts );

$unique_id = uniqid('dpr-workflow');

/* Custom CSS */
if(isset($axe_style) && !empty($axe_style)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .axe-line {border-right-style: '.esc_attr($axe_style).';}';
}
if(isset($axe_size) && !empty($axe_size)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .axe-line {border-right-width: '.esc_attr($axe_size).'px;}';
}
if(isset($axe_color) && !empty($axe_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .axe-line {border-right-color: '.esc_attr($axe_color).';}';
}




$output .= '<div id="'.esc_attr($unique_id).'" class="dpr-workflow '.$el_class.' ' . esc_attr($unique_id) . '">';
	$output .= '<div class="axe-line"></div>';
	$output .= do_shortcode($content);

if(!empty($custom_el_css)) {
		$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>");'
						. '})(jQuery);'
					. '</script>';
}
$output .= '</div>';

echo $output;