<?php

/**

 * Tribe Options

 *

 */

Redux::setSection($opt_name, array(

    'title' => __('Events Calendar', 'dpr-adeline-extensions'),

    'id'    => 'tribe_tab',

    'icon'  => 'el el-calendar',

));

require_once $options_dir . '/tribe-options/calendar.php';

require_once $options_dir . '/tribe-options/single-event.php';
