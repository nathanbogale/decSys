<?php

// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}

/*

* Add-on Name: Separator 

*/



class WPBakeryShortCode_DPR_Separator extends WPBakeryShortCode {}



vc_map(

	array(

		'name'					=> esc_html__('DP Separator', 'dpr-adeline-extensions'),

		'base'					=> 'dpr_separator',

		"icon"					=> 'icon-dpr-separator',

		"class"					=> 'dpr_separator',

  		"category" =>array( esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions')),

		'description'			=> esc_html__('Styled delimiter', 'dpr-adeline-extensions'),

		'params'				=> array(

			array(

				'heading'			=> esc_html__('Separator Type', 'dpr-adeline-extensions'),

				'type'				=> 'dpr_image_select',

				'param_name'		=> 'style',

				'options'			=> array(

					'simple'			=> array(

						'label'			=> esc_html__('Simple', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'separator/simple-style.png'

					),

					'text'			=> array(

						'label'			=> esc_html__('Text', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'separator/text-style.png'

					),

					'icon'			=> array(

						'label'			=> esc_html__('Icon', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'separator/icon-style.png'

					),

					'image'			=> array(

						'label'			=> esc_html__('Image OR SVG', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'separator/image-style.png'

					),

					'totop'			=> array(

						'label'			=> esc_html__('To Top', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'separator/totop-style.png'

					),

				),

			),

			array(

				'type'				=> 'textfield',

				'heading'			=> esc_html__('Separator Text', 'dpr-adeline-extensions'),

				'param_name'		=> 'text',

				'admin_label' => true,

				'value'				=> esc_html__('Separator Text', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'style', 'value' => array('text')),

			),

			array(

				'type'				=> 'number',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set separator line height. Default is 1px', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'line_height',

				'min'				=> 0,

				'max'				=> 30,

				'value'				=> '1',

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

			),

			

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set separator color.Default is #d2d7de', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'line_color',

				'value'				=> '#d2d7de',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to choose line style.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Style', 'dpr-adeline-extensions'),

				'param_name'		=> 'line_style',

				'value'				=> 'solid',

				'options'			=> array(

					esc_html__('Solid', 'dpr-adeline-extensions')	=> 'solid',

					esc_html__('Dotted', 'dpr-adeline-extensions')	=> 'dotted',

					esc_html__('Dashed', 'dpr-adeline-extensions')	=> 'dashed',

					esc_html__('Double', 'dpr-adeline-extensions')	=> 'double',

					esc_html__('Inset', 'dpr-adeline-extensions')	=> 'inset',

					esc_html__('Outset', 'dpr-adeline-extensions')	=> 'outset',

					esc_html__('Custom Pattern', 'dpr-adeline-extensions')	=> 'pattern',

				),

				'edit_field_class'	=> 'vc_col-sm-12 vc_column ',

			),

			array(

				'type' => 'dpr_image_select',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Chose pattern for overlay. Default pattern are black, light patterna are white.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Overlay Pattern', 'dpr-adeline-extensions'),

				'param_name' => 'line_pattern',

				'dependency' => array(

						'element' => 'line_style', 

						'value' => array('pattern')

				),

				'value' => 'transparent',

				'options'			=> array(

					'p01'			=> array(

						'label'			=> 'P01',

						'src'				=> $module_images . 'row/p01.png'

					),

					'p02'			=> array(

						'label'			=> 'P02',

						'src'				=> $module_images . 'row/p02.png'

					),

					'p03'			=> array(

						'label'			=> 'P03',

						'src'				=> $module_images . 'row/p03.png'

					),

					'p04'			=> array(

						'label'			=> 'P04',

						'src'				=> $module_images . 'row/p04.png'

					),

					'p05'			=> array(

						'label'			=> 'P05',

						'src'				=> $module_images . 'row/p05.png'

					),

					'p06'			=> array(

						'label'			=> 'P06',

						'src'				=> $module_images . 'row/p06.png'

					),

					'p07'			=> array(

						'label'			=> 'P07',

						'src'				=> $module_images . 'row/p07.png'

					),

					'p08'			=> array(

						'label'			=> 'P08',

						'src'				=> $module_images . 'row/p08.png'

					),

					'p09'			=> array(

						'label'			=> 'P09',

						'src'				=> $module_images . 'row/p09.png'

					),

					'p01-l'			=> array(

						'label'			=> 'P01 Light',

						'src'				=> $module_images . 'row/p01-l.png'

					),

					'p02-l'			=> array(

						'label'			=> 'P02 Light',

						'src'				=> $module_images . 'row/p02-l.png'

					),

					'p03-l'			=> array(

						'label'			=> 'P03 Light',

						'src'				=> $module_images . 'row/p03-l.png'

					),

					'p04-l'			=> array(

						'label'			=> 'P04 Light',

						'src'				=> $module_images . 'row/p04-l.png'

					),

					'p05-l'			=> array(

						'label'			=> 'P05 Light',

						'src'				=> $module_images . 'row/p05-l.png'

					),

					'p06-l'			=> array(

						'label'			=> 'P06 Light',

						'src'				=> $module_images . 'row/p06-l.png'

					),

					'p07-l'			=> array(

						'label'			=> 'P07 Light',

						'src'				=> $module_images . 'row/p07-l.png'

					),

					'p08-l'			=> array(

						'label'			=> 'P08 Light',

						'src'				=> $module_images . 'row/p08-l.png'

					),

					'p09-l'			=> array(

						'label'			=> 'P09 Light',

						'src'				=> $module_images . 'row/p09-l.png'

					),

				),

			),

			array(

				'type' => 'number',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set pattern opacity. Enter value between 0 to 100 (0 is transparent) ', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Pattern Opacity', 'dpr-adeline-extensions'),

				'param_name' => 'pattern_opacity',

				'value' =>'100',

				'min'=>'0',

				'max' => '100',

				'step' => '1',

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'dependency' => array(

						'element' => 'line_style', 

						'value' => array('pattern')

				),

			),

			array(

				'type' => 'number',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Specify the pattern\'s size for the overlay in px. If you leave this field blank pattern will be displayed own size', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Pattern Size', 'dpr-adeline-extensions'),

				'param_name' => 'pattern_size',

				'value' =>'',

				'min'=>'1',

				'step' => '1',

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'dependency' => array(

						'element' => 'line_style', 

						'value' => array('pattern')

				),

			),			

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Additional Settings', 'dpr-adeline-extensions' ),

				'param_name'       => 'extra_features_title',

				'edit_field_class' => 'vc_column vc_col-sm-12',

			),

		   vc_map_add_css_animation( false ),

		    array(

				'type' => 'textfield',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Extra Class Name', 'dpr-adeline-extensions'),

				'param_name' => 'el_class',

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> 'Icon Style',

				'param_name'		=> 'title_sep_1',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'style', 'value' => array('icon')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

		  array(

				"type" => "dpr_icon_selector",

				"heading" => esc_attr__("Icon", 'dpr-adeline-extensions'),

				"param_name" => "icon",

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select icon.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'style', 'value' => 'icon',),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set the size for the icon.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon Size', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_size',

				'min'				=> 12,

				'edit_field_class'	=> 'vc_column vc_col-sm-4   ',

				'dependency'		=> array('element' => 'style', 'value' => array('icon','totop')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'class'				=> '',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the icon color. The default color is main acent color set in Template Options.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-4  ',

				'dependency'		=> array('element' => 'style', 'value' => array('icon','totop')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable icon badge.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Use background badge?', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_badge',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'dependency'		=> array('element' => 'style', 'value' => array('icon','totop')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> 'Icon Badge Style',

				'param_name'		=> 'title_sep_2',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'use_badge', 'value' => array('yes')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set the background size for the icon. The default value is 35px.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon badge size', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_bg_size',

				'min'				=> 1,

				'edit_field_class'	=> 'vc_column vc_col-sm-6  ',

				'dependency'		=> array('element' => 'use_badge', 'value' => array('yes')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'class'				=> '',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the icon background color. By default is main acent color set in Template Options.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon Background Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_bg',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'dependency'		=> array('element' => 'use_badge', 'value' => array('yes')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose background border width default is 0.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border width', 'dpr-adeline-extensions'),

				'param_name'		=> 'border_width',

				'min'				=> 0,

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'dependency'		=> array('element' => 'use_badge', 'value' => array('yes')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose background border color on hover.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border color', 'dpr-adeline-extensions'),

				'param_name'		=> 'border_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'dependency'		=> array('element' => 'use_badge', 'value' => array('yes')),

				'group'				=> esc_html__('Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'attach_image',

				'heading'			=> esc_html__('Upload image', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_image_id',

				'admin_label'		=> true,

				'description'		=> esc_html__('Upload the custom image from media library', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'style', 'value' => array('image')),

				'group'				=> esc_html__('Image', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set the size for the image or svg.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Image Size', 'dpr-adeline-extensions'),

				'param_name'		=> 'image_size',

				'min'				=> 12,

				'edit_field_class'	=> 'vc_column vc_col-sm-4   ',

				'dependency'		=> array('element' => 'style', 'value' => array('image')),

				'group'				=> esc_html__('Image', 'dpr-adeline-extensions'),

			),



			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Text Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'text_typography_head',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'style', 'values' => 'text'),

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom ttle color. Default is #97a3b3.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'text_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'style', 'value' => 'text'),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size.Default is 12px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'text_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'style', 'value' => 'text'),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title linne height.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'text_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'style', 'value' => 'text'),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'text_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'style', 'value' => 'text'),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'text_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'dependency'		=> array('element' => 'style', 'value' => 'text'),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

	  		),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_google_fonts',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'dependency'		=> array('element' => 'style', 'value' => 'text'),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'text_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'dependency'		=> array('element' => 'use_google_fonts', 'value' => 'yes'),

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'css_editor',

				'heading' => __( 'CSS box', 'dpr-adeline-extensions' ),

				'param_name' => 'css',

				'group' => __( 'Design Options', 'dpr-adeline-extensions' ),

			),

			

		),

	)

);