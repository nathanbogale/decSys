<?php

/**

 * Register Particle Post Type

 */

if (!class_exists('DPR_Particle_Post_Type')) {

    class DPR_Particle_Post_Type
    {

        public function __construct()
        {

            add_action('init', array($this, 'register_post_type'));

            add_action('init', array($this, 'register_taxonomy'));

            if (is_admin()) {

                add_action('add_meta_boxes', array($this, 'add_particle_shortcode_metabox'));

                add_filter('manage_edit-particle_columns', array($this, 'edit_columns_particle'));

                add_action('manage_posts_custom_column', array($this, 'custom_columns_particle'));

                add_action('admin_notices', array($this, 'dpr_particle_welcome_notice'));

                add_action('admin_notices', array($this, 'dpr_particle_edit_notice'));

            }

        }

        /**

         * Register custom post type

         *

         */

        public static function register_post_type()
        {

            $labels = array(

                'name'               => _x('Particles', 'post type general name', 'dpr-adeline-extensions'),

                'singular_name'      => _x('Particle', 'post type singular name', 'dpr-adeline-extensions'),

                'add_new'            => _x('Add New', 'particle', 'dpr-adeline-extensions'),

                'add_new_item'       => __('Add New Particle Item', 'dpr-adeline-extensions'),

                'edit_item'          => __('Edit Particle Item', 'dpr-adeline-extensions'),

                'new_item'           => __('New Particle Item', 'dpr-adeline-extensions'),

                'view_item'          => __('Preview Particle Item', 'dpr-adeline-extensions'),

                'search_items'       => __('Search Particle', 'dpr-adeline-extensions'),

                'not_found'          => __('No particles found', 'dpr-adeline-extensions'),

                'not_found_in_trash' => __('No particle items found in Trash.', 'dpr-adeline-extensions'),

                'parent_item_colon'  => '',

                'menu_name'          => 'Particles',

            );

            register_post_type('dpr_particle', array(

                'label'               => __('Particle', 'dpr-adeline-extensions'),

                'labels'              => $labels,

                'singular_label'      => __('Particle', 'dpr-adeline-extensions'),

                'public'              => true,

                'show_ui'             => true,

                'show_in_menu'        => true,

                'menu_position'       => null,

                '_builtin'            => false,

                'exclude_from_search' => false,

                'capability_type'     => 'page',

                'hierarchical'        => false,

                'rewrite'             => array("slug" => "dpr_particle", "with_front" => false),

                'query_var'           => "dpr_particle",

                'publicly_queryable'  => true,

                'supports'            => array('title', 'page-attributes', 'editor', 'elementor'),

                'menu_icon'           => 'dashicons-tagcloud',

            ));

        }

        /**

         * Add particle shortcode metaboxes

         *

         */

        public function display_particle_shortcode_metabox($post)
        {
            ?>



				<input type="text" class="widefat" value='[dpr_particle id="<?php echo $post->ID; ?>"]' readonly />



			<?php

        }

        public function add_particle_shortcode_metabox($post)
        {

            add_meta_box(

                'particle-shortcode-metabox',

                esc_html__('Shortcode', 'dpr-adeline-extensions'),

                array($this, 'display_particle_shortcode_metabox'),

                'dpr_particle',

                'side',

                'low'

            );

        }

        /**

         * Register associated taxonomy

         *

         */

        public static function register_taxonomy($args_particle)
        {

            $labels_particle = array(

                'name'          => __('Particles Categories', 'post type general name'),

                'all_items'     => __('All Categories', 'all items'),

                'add_new_item'  => __('Add New Category', 'adding a new item'),

                'new_item_name' => __('New Category Name', 'adding a new item'),

            );

            $args_particle = array(

                'labels'       => $labels_particle,

                'hierarchical' => true,

            );

            register_taxonomy('dpr_particles', 'dpr_particle', $args_particle);

        }

        /**

         * Customize Manage Posts interface

         *

         */

        public static function edit_columns_particle($columns)
        {

            $columns = array(

                "cb"                  => "<input type=\"checkbox\" />",

                "title"               => __("Title", 'dpr-adeline-extensions'),

                "date"                => __("Date", 'dpr-adeline-extensions'),

                "particle_categories" => __("Categories", 'dpr-adeline-extensions'),

                "particle_shortcode"  => __("Shortcode", 'dpr-adeline-extensions'),

            );

            return $columns;

        }

        public static function custom_columns_particle($column)
        {

            global $post;

            switch ($column) {

                case "particle_categories":

                    $particle_categories = get_the_terms(0, "particles");

                    $particle_categories_html = array();

                    if ($particle_categories) {

                        foreach ($particle_categories as $pcategory) {
                            array_push($particle_categories_html, $pcategory->name);
                        }

                        echo implode($particle_categories_html, ", ");

                    }

                    break;

                case "particle_shortcode":

                    $shortcode = esc_attr(sprintf('[dpr_particle id="%d"]', $post->ID));

                    printf('<input type="text" value="%s" readonly style="min-width: 200px;" />', $shortcode);

                    break;

            }

        }

        /**

         * Display custom admin notices

         *

         */

        public static function dpr_particle_welcome_notice()
        {

            $screen = get_current_screen();

            if ($screen->id == 'edit-particle') {

                ?>

			<div class="notice is-dismissible">

				<p><?php _e('Tu notka welcome!', 'dpr-adeline-extensions');?></p>

			</div>

		<?php }

        }

        public static function dpr_particle_edit_notice()
        {

            $screen = get_current_screen();

            if ($screen->id == 'dpr_particle') {?>

			<div class="notice is-dismissible">

				<p><?php _e('Tu notka przy edycji postu!', 'dpr-adeline-extensions');?></p>

			</div>

		<?php }

        }

    }

}

new DPR_Particle_Post_Type();