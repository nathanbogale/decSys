<?php

if ( ! defined( 'ABSPATH' ) ) { exit; }



class WPBakeryShortCode_DPR_Interactive_Showcase extends WPBakeryShortCode {}


vc_map(

	array(

		'name'					=> esc_html__('DP Showcase', 'dpr-adeline-extensions'),

		'base'					=> 'dpr_interactive_showcase',

		'class'					=> '',

		'icon'					=> 'icon-dpr-interactive-showcase',

  		"category" =>array( esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions')),

		"description" => esc_attr__('Interactive fullscreen showcase', 'dpr-adeline-extensions'),

		'params'				=> array(

			array(

			'type'				=> 'dpr_switcher',

			'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable autoplay of this interactive showcase.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Enable Showcase Autoplay', 'dpr-adeline-extensions'),

			'param_name'		=> 'enable_autoplay',

			'edit_field_class'	=> 'vc_column vc_col-sm-6 vc_column-with-padding',

			'options'			=> array(

				'yes'				=> array(

					'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

					'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

				),

			)

		),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set autoplay speed in ms.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Autoplay Speed', 'dpr-adeline-extensions'),

				'param_name'		=> 'autoplay_speed',

				'min'				=> 500,
				
	
				'step' 				=> 100,
	
				'value' 			=> 3000,

				'suffix'			=> 'ms',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',
	
				'dependency'		=> array('element' => 'enable_autoplay', 'value' => array('yes'))
			),


			array(

				'type'				=> 'param_group',

				'heading'			=> esc_html__('Showcase Items List', 'dpr-adeline-extensions'),

				'param_name'		=> 'custom_list',

				'value'				=> '',

				'params'			=> array(

				array(

					'type'				=> 'dpr_radio',

					'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select item background type (image or video).', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Item Background Type', 'dpr-adeline-extensions'),

					'param_name'		=> 'bg_type',

					'value'				=> 'image',

					'options'			=> array(

						esc_html__('Image', 'dpr-adeline-extensions')	=> 'image',

						esc_html__('Video', 'dpr-adeline-extensions')	=> 'video'



					)

				),	

	
				array(

						'type'			=> 'attach_image',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Upload the custom image from media library.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background Image', 'dpr-adeline-extensions'),

						'param_name'	=> 'image_id',
	
						'dependency'		=> array('element' => 'bg_type', 'value' => array('image')),

						'edit_field_class' => 'vc_column vc_col-sm-12',

					),
	
					array(

						'type' => 'dpr_image_select',

						'class' => '',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Chose video type', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Video Source', 'dpr-adeline-extensions'),

						'param_name' => 'video_type',

						'value' => 'hosted',

						'dependency' => array(

								'element' => 'bg_type',

								'value' => 'video',

							),		

						'options'			=> array(

							'hosted'			=> array(

								'label'			=> esc_html__('Hosted','dpr-adeline-extensions'),

								'src'				=> $module_images . 'row/self_hosted.png'

							),

							'youtube'			=> array(

								'label'			=> esc_html__('YouTube','dpr-adeline-extensions'),

								'src'				=> $module_images . 'row/youtube.png'

							),

							'vimeo'			=> array(

								'label'			=> esc_html__('Vimeo','dpr-adeline-extensions'),

								'src'				=> $module_images . 'row/vimeo.png'

							)

						),

					),

					array(

						'type' => 'textfield',

						'class' => '',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Add the link to your video in mp4 format', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Video in MP4 format', 'dpr-adeline-extensions'),

						'param_name' => 'mp4_url',

						'value' => '',

						'dependency' => array(

								'element' => 'video_type',

								'value' => 'hosted',

							),		

					),


					array(

						'type' => 'textfield',

						'class' => '',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Add the link to your video in WebM / Ogg format', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Video in WEBM / OGG format', 'dpr-adeline-extensions'),

						'param_name' => 'webm_url',

						'value' => '',

						'dependency' => array(

								'element' => 'video_type',

								'value' => 'hosted',

							),

						'description' => esc_attr__('IE, Chrome & Safari support MP4 format, while Firefox & Opera prefer WebM / Ogg formats. You can upload the video through WordPress Media Library.', 'dpr-adeline-extensions')

					),

					array(

						'type' => 'textfield',

						'class' => '',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Add the video ID. Look at the URL of that page, and at the end of it, you should see a combination of numbers and letters after an equal sign (=)', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('YouTube Video ID', 'dpr-adeline-extensions'),

						'param_name' => 'youtube_id',

						'value' => '',

						'edit_field_class' => 'vc_column vc_col-sm-12',

						'dependency' => array(

								'element' => 'video_type',

								'value' => 'youtube',

							),

						'description' => esc_attr__('Add the video ID. Look at the URL of that page, and at the end of it, you should see a combination of numbers and letters after an equal sign (=).', 'dpr-adeline-extensions')

					),

					array(

						'type' => 'textfield',

						'class' => '',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Add the video ID. Copy the numeric code that appears at the end of its URL at the top of your browser window', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Vimeo Video ID', 'dpr-adeline-extensions'),

						'param_name' => 'vimeo_id',

						'value' => '',

						'edit_field_class' => 'vc_column vc_col-sm-12',



						'dependency' => array(

								'element' => 'video_type',

								'value' => 'vimeo',

							),

						'description' => esc_attr__('Add the video ID. Copy the numeric code that appears at the end of its URL at the top of your browser window.', 'dpr-adeline-extensions')

					),

					array(

							'type' => 'checkbox',

							'class' => '',

							'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('These options allow you to loop and mute the video set as the background', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Video Options', 'dpr-adeline-extensions'),

							'param_name' => 'video_options',

							'value' => array(

									__('Loop','dpr-adeline-extensions') => 'loop',

									__('Muted','dpr-adeline-extensions') => 'muted',

								),

							'dependency' => array(

									'element' => 'bg_type',

									'value' => 'video',

								)

					  ),
	
					array(

						'type' => 'number',

						'class' => '',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set video start time in seconds.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Video Start Time', 'dpr-adeline-extensions'),

						'param_name' => 'video_start_time',

						'value' =>'',

						'min'=>'0',

						'step' => '1',

						'edit_field_class' => 'vc_column vc_col-sm-3',

						'dependency' => array(

								'element' => 'video_type',

								'value' => 'youtube',

						),		

					),

					array(

						'type' => 'number',

						'class' => '',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set video stop time in seconds', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Video Stop Time', 'dpr-adeline-extensions'),

						'param_name' => 'video_stop_time',

						'value' =>'',

						'min'=>'0',

						'step' => '1',

						'edit_field_class' => 'vc_column vc_col-sm-3',

						'dependency' => array(

								'element' => 'video_type',

								'value' => 'youtube',

						),		

					),
	
					array(

						'type' => 'attach_image',

						'class' => '',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose placeholder image', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Placeholder Image', 'dpr-adeline-extensions'),

						'param_name' => 'video_poster',

						'value' => '',

						'edit_field_class' => 'vc_column vc_col-sm-6',

						'dependency' => array(

								'element' => 'bg_type',

								'value' => 'video',

						),

						'description' => esc_attr__('Placeholder image is displayed in case background video is restricted. (For example, on mobiles).', 'dpr-adeline-extensions')		

					),

						array(

						'type'				=> 'colorpicker',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('You can use video overlay color to adjust video appearance.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Video Overlay Color', 'dpr-adeline-extensions'),

						'param_name'		=> 'overlay_color',

						'edit_field_class'	=> 'vc_col-sm-6 vc_column ',
							'dependency' => array(

								'element' => 'bg_type',

								'value' => 'video',

						)
					),

	
					array(

						'type'			=> 'textfield',

						'heading' 		=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom link title', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Link Title', 'dpr-adeline-extensions'),

						'param_name'	=> 'link_title'
					), 

					array(

						'type'			=> 'textfield',

						'heading' 		=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom link subtitle', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Link Subtitle', 'dpr-adeline-extensions'),

						'param_name'	=> 'link_subtitle'
					), 
	
					array(

						'type' => 'textarea',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set additional description. Will be used when description display is enabled in style settings.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Additional Description', 'dpr-adeline-extensions'),

						'param_name' => 'description'

					),

					array(

						'type'			=> 'vc_link',

						'heading' 		=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Add link to this item.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Link URL', 'dpr-adeline-extensions'),

						'param_name'	=> 'link',

						'edit_field_class'	=> 'vc_col-sm-12 vc_column'

					)

				)

			),

	
			array(

			'type'             => 'dpr_title',

			'text'             => esc_html__( 'Additional Settings', 'dpr-adeline-extensions' ),

			'param_name'       => 'extra_features_title',

			'edit_field_class' => 'vc_column vc_col-sm-12',

		),
	
			array(

			'type' => 'textfield',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Extra Class Name', 'dpr-adeline-extensions'),

			'param_name' => 'el_class',

			),
	
			array(

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select interactive showcase style.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Style', 'dpr-adeline-extensions'),

				'type'				=> 'dpr_image_select',

				'param_name'		=> 'style',

				'simple_mode'		=> false,
				
				'edit_field_class' => 'vc_column vc_col-sm-8 vc_column-with-padding',
	
				'group' => __( 'Style', 'dpr-adeline-extensions' ),

				'options'			=> array(

					'fullscreen-image'			=> array(

						'label'			=> esc_html__('Fullscreen', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'interactive-showcase/fullscreen.png'

					),

					'splited-image-right'			=> array(

						'label'			=> esc_html__('Splted Img Right', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'interactive-showcase/right-image.png'

					),

					'splited-image-left'			=> array(

						'label'			=> esc_html__('Splited Img Left', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'interactive-showcase/left-image.png'

					),

					'image-center'			=> array(

						'label'			=> esc_html__('Centered Image', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'interactive-showcase/centered-image.png'

					)
	
				),

			),
			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set center image scale. Default is 0.6', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Center Image Scale', 'dpr-adeline-extensions'),

				'param_name'		=> 'center_image_scale',

				'min'				=> 0.1,
				
				'max' 				=> 1,
	
				'step' 				=> 0.1,
	
				'value'				=> 0.6,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',
	
				'dependency'		=> array('element' => 'style', 'value' => array('image-center')),
	
				'group' => __( 'Style', 'dpr-adeline-extensions' ),

			),
	
			array(

			'type'            	=> 'dpr_title',

			'text'            	=> '',

			'class'				=> 'separator',

			'param_name'      	=> 'sep_1',

			'edit_field_class'	=> 'vc_column vc_col-sm-12',

			'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),
	
			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select vertical links alignment.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Links Vertical Alignment', 'dpr-adeline-extensions'),

				'param_name'		=> 'links_alignment',
				
				'group' => __( 'Style', 'dpr-adeline-extensions' ),

				'value'				=> 'middle',
	
				'edit_field_class' => 'vc_column vc_col-sm-4 vc_column-with-padding',

				'options'			=> array(

					esc_html__('Middle', 'dpr-adeline-extensions')	=> 'middle',
	
					esc_html__('Bottom', 'dpr-adeline-extensions')	=> 'bottom'
				)

			),		

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select subtitle position above or bellow title.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Subtitle Positon', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_pos',
				
				'group' => __( 'Style', 'dpr-adeline-extensions' ),

				'value'				=> 'bellow',
	
				'edit_field_class' => 'vc_column vc_col-sm-4',

				'options'			=> array(

					esc_html__('Bellow Title', 'dpr-adeline-extensions')	=> 'bellow',
	
					esc_html__('Above Title', 'dpr-adeline-extensions')	=> 'above'

				)

			),
	
			array(

			'type'				=> 'dpr_switcher',

			'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable display of showcase item description. will be displayed bottom left.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Display Description', 'dpr-adeline-extensions'),

			'param_name'		=> 'display_description',
	
			'group' => __( 'Style', 'dpr-adeline-extensions' ),
			
			'dependency'		=> array('element' => 'links_alignment', 'value' => array('middle')),

			'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

			'options'			=> array(

				'yes'				=> array(

					'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

					'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

				),

			)

		),

			array(

			'type'				=> 'dpr_switcher',

			'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable or disable mouse wheel navigation', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Mouse wheel navigation', 'dpr-adeline-extensions'),

			'param_name'		=> 'enable_mouse_wheel',
	
			'group' => __( 'Style', 'dpr-adeline-extensions' ),
			

			'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

			'options'			=> array(

				'yes'				=> array(

					'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

					'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

				),

			)

		),


			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Title Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'typo_title_1',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group' => __( 'Style', 'dpr-adeline-extensions' ),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom title color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Title Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_color',

				'edit_field_class'	=> 'vc_col-sm-3 vc_column ',

				'group' => __( 'Style', 'dpr-adeline-extensions' ),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size. If you leave this field blank will be used default size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group' => __( 'Style', 'dpr-adeline-extensions' ),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom line height.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group' => __( 'Style', 'dpr-adeline-extensions' ),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group' => __( 'Style', 'dpr-adeline-extensions' ),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'title_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'group' => __( 'Style', 'dpr-adeline-extensions' ),

	  		),
			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set text stroke width. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Stroke Width', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_stroke_width',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

				'group' => __( 'Style', 'dpr-adeline-extensions' ),

			),
			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose text stroke color for title', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Stroke Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_stroke_color',

				'edit_field_class'	=> 'vc_col-sm-4 vc_column ',

				'group' => __( 'Style', 'dpr-adeline-extensions' ),

			),
	
			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose text color on hover', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Title Color: Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_color_hover',

				'edit_field_class'	=> 'vc_col-sm-4 vc_column ',

				'group' => __( 'Style', 'dpr-adeline-extensions' ),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose text stroke color on hover', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Stroke Color: Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_stroke_color_hover',

				'edit_field_class'	=> 'vc_col-sm-4 vc_column ',

				'group' => __( 'Style', 'dpr-adeline-extensions' ),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font. .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_title_google_fonts',

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group' => __( 'Style', 'dpr-adeline-extensions' ),

			),



			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'title_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'dependency'		=> array('element' => 'use_title_google_fonts', 'value' => array('yes')),

				'group' => __( 'Style', 'dpr-adeline-extensions' ),

			),
	
			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Subtitle Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'typo_title_2',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group' => __( 'Style', 'dpr-adeline-extensions' ),

			),
			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom subtitle color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Subtitle Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_color',

				'edit_field_class'	=> 'vc_col-sm-3 vc_column ',

				'group' => __( 'Style', 'dpr-adeline-extensions' ),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size. If you leave this field blank will be used default size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group' => __( 'Style', 'dpr-adeline-extensions' ),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom linne height.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group' => __( 'Style', 'dpr-adeline-extensions' ),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom letter sapacing.', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group' => __( 'Style', 'dpr-adeline-extensions' ),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'subtitle_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'group' => __( 'Style', 'dpr-adeline-extensions' ),

	  		),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose subtitle color on hover', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Subtitle Color: Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_color_hover',

				'edit_field_class'	=> 'vc_col-sm-4 vc_column ',

				'group' => __( 'Style', 'dpr-adeline-extensions' ),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font. .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_subtitle_google_fonts',

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group' => __( 'Style', 'dpr-adeline-extensions' ),

			),

			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'subtitle_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'dependency'		=> array('element' => 'use_subtitle_google_fonts', 'value' => array('yes')),

				'group' => __( 'Style', 'dpr-adeline-extensions' ),

			),
	
			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Description Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'typo_title_3',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',
	
				'dependency'		=> array('element' => 'display_description', 'value' => array('yes')),

				'group' => __( 'Style', 'dpr-adeline-extensions' ),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom description color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Description Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'description_color',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'dependency'		=> array('element' => 'display_description', 'value' => array('yes')),

				'group' => __( 'Style', 'dpr-adeline-extensions' ),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom description text shadow color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Description Text Shadow Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'description_shadow_color',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'dependency'		=> array('element' => 'display_description', 'value' => array('yes')),

				'group' => __( 'Style', 'dpr-adeline-extensions' ),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom description title fornt size. Default is 16px.', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Description Title Fonts Size', 'dpr-adeline-extensions'),

				'param_name'		=> 'description_title_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',
	
				'dependency'		=> array('element' => 'display_description', 'value' => array('yes')),

				'group' => __( 'Style', 'dpr-adeline-extensions' ),

			),
	
			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom description font size. Default is 16px.', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Description Fonts Size', 'dpr-adeline-extensions'),

				'param_name'		=> 'description_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',
	
				'dependency'		=> array('element' => 'display_description', 'value' => array('yes')),

				'group' => __( 'Style', 'dpr-adeline-extensions' ),

			),


			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Link Title Responsive Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_reaponsive_typography_head',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Responsive Options', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable responsive typography for headline. .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Enable', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_title_responsive_typo',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Responsive Options', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_responsive_typo',

				'param_name'		=> 'title_reaponsive_typography',

				'heading'			=> '',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'use_title_responsive_typo', 'value' => array('yes')),

				'group'				=> esc_attr__('Responsive Options', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Subtitle Responsive Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_reaponsive_typography_head',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Responsive Options', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable responsive typography for subtitle.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Enable', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_subtitle_responsive_typo',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Responsive Options', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_responsive_typo',

				'param_name'		=> 'subtitle_reaponsive_typography',

				'heading'			=> '',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'use_subtitle_responsive_typo', 'value' => array('yes')),

				'group'				=> esc_attr__('Responsive Options', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'css_editor',

				'heading' => __( 'CSS box', 'dpr-adeline-extensions' ),

				'param_name' => 'css',

				'group' => __( 'Design Options', 'dpr-adeline-extensions' ),

			),


		),

		

	)

);