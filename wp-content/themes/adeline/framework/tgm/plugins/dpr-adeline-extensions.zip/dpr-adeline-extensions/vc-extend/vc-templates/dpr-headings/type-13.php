<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
/*
Heading style
*/
$output .= $delimiter_html;
$output .= '<div class="cover">';
$output .= $title_html;
$output .= $subtitle_html;
$output .= '</div>';