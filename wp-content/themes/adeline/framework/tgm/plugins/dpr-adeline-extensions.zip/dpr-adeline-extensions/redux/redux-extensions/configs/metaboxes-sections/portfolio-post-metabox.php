<?php

if (!function_exists("dpr_portfolio_post_metabox_sections")):

    function dpr_portfolio_post_metabox_sections()
{

        // Declare your sections

        /*

         * ---> START PAGE METABOX SECTIONS

         */

        $portfolio_post_metabox_sections = array();

        $portfolio_post_metabox_sections[] = array(

            'title'    => esc_html__('General Options', 'dpr-adeline-extensions'),

            'subtitle' => esc_html__('', 'dpr-adeline-extensions'),

        );

        $portfolio_post_metabox_sections[] = array(

            'title'      => esc_html__('Layout Options', 'dpr-adeline-extensions'),

            'subtitle'   => esc_html__('', 'dpr-adeline-extensions'),

            'subsection' => true,

            'fields'     => array(

                array(

                    'id'      => 'layout_width',

                    'type'    => 'image_select',

                    'title'   => __('Page Width', 'dpr-adeline-extensions'),

                    'options' => array(

                        'stretched' => array(

                            'title' => esc_html__('Stretched', 'dpr-adeline-extensions'),

                            'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/layouts/stretched_layout.png',

                        ),

                        'boxed'     => array(

                            'title' => esc_html__('Boxed', 'dpr-adeline-extensions'),

                            'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/layouts/boxed_layout.png',

                        ),

                        'framed'    => array(

                            'title' => esc_html__('Framed', 'dpr-adeline-extensions'),

                            'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/layouts/framed_layout.png',

                        ),

                    ),

                    'hint'    => array(

                        'title'   => esc_attr__('Pag width', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Choose page width for this page.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'container_width',

                    'type'     => 'dimensions',

                    'title'    => esc_html__('Main Container Width (px)', 'dpr-adeline-extensions'),

                    'output'   => array('width' => '.container'),

                    'width'    => true,

                    'height'   => false,

                    'mode'     => array('width' => 'width', 'height' => 'height'),

                    'units'    => array('px'),

                    'hint'     => array(

                        'title'   => esc_attr__('Main Container Width', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Specify the maximum base width for the theme to be visible on desktop computers for this page.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('layout_width', 'not', 'boxed'),

                ),

                array(

                    'id'       => 'boxed_shadow',

                    'type'     => 'switch',

                    'title'    => esc_html__('Box Shadow', 'dpr-adeline-extensions'),

                    'hint'     => array(

                        'title'   => esc_attr__('Box shadow', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Enable or disable shadow for box for this page.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('layout_width', 'equals', 'boxed'),

                ),

                array(

                    'id'       => 'boxed_width',

                    'type'     => 'dimensions',

                    'title'    => esc_html__('Boxed Width (px)', 'dpr-adeline-extensions'),

                    'output'   => array('width' => '.boxed-layout.wrap-boxshadow #dpr-inner-wrapper'),

                    'width'    => true,

                    'height'   => false,

                    'mode'     => array('width' => 'width', 'height' => 'height'),

                    'units'    => array('px'),

                    'hint'     => array(

                        'title'   => esc_attr__('Boxed Width', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Specify the width for inner box for this page.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('layout_width', 'equals', 'boxed'),

                ),

                array(

                    'id'       => 'boxed_wrapper_bg',

                    'type'     => 'color',

                    'output'   => array('background-color' => '.boxed-layout #dpr-wrapper'),

                    'validate' => 'color',

                    'title'    => esc_html__('Inner Background', 'dpr-adeline-extensions'),

                    'hint'     => array(

                        'title'   => esc_attr__('Inner Background', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set main content wrapper background color for this page.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('layout_width', 'equals', 'boxed'),

                ),

                 array(

                    'id'       => 'use_custom_boxed_body_bg',

                    'type'     => 'switch',

                    'title'    => esc_html__('Use custom outer background?', 'dpr-adeline-extensions'),

                    'hint'     => array(

                        'title'   => esc_attr__('Use custom outer background?', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Enable usage custom outer background for this item.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('layout_width', 'equals', 'boxed'),

                ),                              

                array(

                    'id'       => 'custom_boxed_body_bg',

                    'type'     => 'background',

                    'title'    => __('Background', 'dpr-adeline-extensions'),

                    'output'   => array(''),

                    'hint'     => array(

                        'title'   => esc_attr__('Background', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set outer body background for this page', 'dpr-adeline-extensions'),

                    ),

                   'required' => array('use_custom_boxed_body_bg', 'equals', '1'),

                ),               

                array(

                    'id'             => 'frame_width',

                    'type'           => 'spacing',

                    'output'         => array('.framed-layout #dpr-outer-wrapper'),

                    'mode'           => 'padding',

                    'units'          => array('%'),

                    'display_units'  => true,

                    'units_extended' => false,

                    'title'          => __('Frame Width (%)', 'dpr-adeline-extensions'),

                    'hint'           => array(

                        'title'   => esc_attr__('Frame Width (%)', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set frame width for this page.', 'dpr-adeline-extensions'),

                    ),

                    'required'       => array('layout_width', 'equals', 'framed'),

                ),

                array(

                    'id'       => 'framed_color',

                    'type'     => 'color',

                    'output'   => array('background-color' => '.framed-layout'),

                    'validate' => 'color',

                    'title'    => esc_html__('Frame Color', 'dpr-adeline-extensions'),

                    'hint'     => array(

                        'title'   => esc_attr__('Frame Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set frame background color for this page.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('layout_width', 'equals', 'framed'),

                ),

                array(

                    'id'       => 'framed_content_bg',

                    'type'     => 'color',

                    'output'   => array('background-color' => '.framed-layout #dpr-inner-wrapper'),

                    'validate' => 'color',

                    'title'    => esc_html__('Content Background Color', 'dpr-adeline-extensions'),

                    'hint'     => array(

                        'title'   => esc_attr__('Content Background Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set framed content background color for this page.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('layout_width', 'equals', 'framed'),

                ),

                array(

                    'id'      => 'portfolio_single_layout',

                    'type'    => 'image_select',

                    'title'   => __('Content Layout', 'dpr-adeline-extensions'),

                    'options' => array(

                        'right-sidebar' => array(

                            'title' => esc_html__('Sidebar right', 'dpr-adeline-extensions'),

                            'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/sidebar_right.png',

                        ),

                        'left-sidebar'  => array(

                            'title' => esc_html__('Sidebar left', 'dpr-adeline-extensions'),

                            'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/sidebar_left.png',

                        ),

                        'both-sidebars' => array(

                            'title' => esc_html__('Both sidebars', 'dpr-adeline-extensions'),

                            'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/sidebar_both.png',

                        ),

                        'full-width'    => array(

                            'title' => esc_html__('Full width', 'dpr-adeline-extensions'),

                            'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/sidebar_disabled.png',

                        ),

                        'full-screen'   => array(

                            'title' => esc_html__('Full screen', 'dpr-adeline-extensions'),

                            'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/full_screen.png',

                        ),

                    ),

                    'hint'    => array(

                        'title'   => esc_attr__('Content Layout', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Choose content layoyt eg sidebar position for this page', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'page_both_sidebars_column_order',

                    'type'     => 'image_select',

                    'title'    => __('Both Sidebars: Column Order', 'dpr-adeline-extensions'),

                    'options'  => array(

                        'order-scs' => array(

                            'title' => esc_html__('Sidebar/Content/Sidebar', 'dpr-adeline-extensions'),

                            'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/scs.png',

                        ),

                        'order-ssc' => array(

                            'title' => esc_html__('Sidebar/Sidebar/Content', 'dpr-adeline-extensions'),

                            'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/ssc.png',

                        ),

                        'order-css' => array(

                            'title' => esc_html__('Content/Sidebar/Sidebar', 'dpr-adeline-extensions'),

                            'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/css.png',

                        ),

                    ),

                    'hint'     => array(

                        'title'   => esc_attr__('Both Sidebars: Column Order', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Choose column order. For this page.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('page_content_layout', 'equals', 'both-sidebars'),

                ),

                array(

                    'id'             => 'page_padding',

                    'type'           => 'spacing',

                    'output'         => array('#main #dpr-content-wrapper'),

                    'mode'           => 'padding',

                    'left'           => false,

                    'right'          => false,

                    'units'          => array('px'),

                    'display_units'  => true,

                    'units_extended' => false,

                    'title'          => __('Content Padding (px)', 'dpr-adeline-extensions'),

                    'hint'           => array(

                        'title'   => esc_attr__('Content Padding', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Choose default padding. This settings affect on default WP pages.', 'dpr-adeline-extensions'),

                    ),

                ),

            ),

        );

        $portfolio_post_metabox_sections[] = array(

            'title'      => esc_html__('Pagination', 'dpr-adeline-extensions'),

            'subtitle'   => esc_html__('', 'dpr-adeline-extensions'),

            'subsection' => true,

            'fields'     => array(

                array(

                    'id'      => 'pagination_align',

                    'type'    => 'radio',

                    'title'   => __('Alignment', 'dpr-adeline-extensions'),

                    'options' => array(

                        'left'   => 'Left',

                        'center' => 'Center',

                        'right'  => 'Right',

                    ),

                    'hint'    => array(

                        'title'   => esc_attr__('Alignment', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set pagination alignment for this page', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'      => 'pagination_shape',

                    'type'    => 'radio',

                    'title'   => __('Pagination Links Style', 'dpr-adeline-extensions'),

                    'options' => array(

                        'square' => 'Square',

                        'round'  => 'Round',

                    ),

                    'hint'    => array(

                        'title'   => esc_attr__('Pagination Links Style', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set pagination links shape for this page', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'    => 'pagination_shadowed',

                    'type'  => 'switch',

                    'title' => esc_html__('Use shadow?', 'dpr-adeline-extensions'),

                    'hint'  => array(

                        'title'   => esc_attr__('Use shadow', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Enable or disable shadow for pagination links for this page', 'dpr-adeline-extensions'),

                    ),

                ),

            ),

        );

        $portfolio_post_metabox_sections[] = array(

            'title'      => esc_html__('Page Preloader', 'dpr-adeline-extensions'),

            'subtitle'   => esc_html__('', 'dpr-adeline-extensions'),

            'subsection' => true,

            'fields'     => array(

                array(

                    'id'    => 'page_preloader',

                    'type'  => 'switch',

                    'title' => esc_html__('Page Preloader', 'dpr-adeline-extensions'),

                    'hint'  => array(

                        'title'   => esc_attr__('Page Preloader', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('You can enable or disable page preloader feature.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'preloader_bg_color',

                    'type'     => 'color',

                    'title'    => __('Page Preloader Background Color', 'dpr-adeline-extensions'),

                    'output'   => array('background-color' => '#dpr-loading'),

                    'hint'     => array(

                        'title'   => esc_attr__('Page Preloader Background Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Page preloader background color for login page.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('page_preloader', 'equals', '1'),

                ),

                array(

                    'id'       => 'preloader_image',

                    'type'     => 'switch',

                    'title'    => esc_html__('Use Page Preloader Image?', 'dpr-adeline-extensions'),

                    'hint'     => array(

                        'title'   => esc_attr__('Use Page Preloader Image', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('You can enable or disable page preloader image. Will be dispayed over preloader spinner.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('page_preloader', 'equals', '1'),

                ),

                array(

                    'id'       => 'preloader_image_source',

                    'type'     => 'media',

                    'title'    => esc_html__('Page Preloader Image', 'dpr-adeline-extensions'),

                    'desc'     => wp_kses_post(__('&nbsp;&nbsp;You can use any type of  static image or animated gif.<br/>&nbsp;&nbsp;Great collection of preloaders you can find eg. on <a target ="_blank" href="https://preloaders.net/">Preloaders.net/</a>', 'dpr-adeline-extensions')),

                    'hint'     => array(

                        'title'   => esc_attr__('Page Preloader Image', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Select custom image for page preloader.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('preloader_image', 'equals', '1'),

                ),

                array(

                    'id'       => 'preloader_spinner',

                    'type'     => 'switch',

                    'title'    => esc_html__('Use Predefined CSS Spinner?', 'dpr-adeline-extensions'),

                    'hint'     => array(

                        'title'   => esc_attr__('Use Predefined CSS Spinner', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('You can enable or disable page preloader CSS animated spinner.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('page_preloader', 'equals', '1'),

                ),

                array(

                    'id'       => 'preloader_spinner_type',

                    'type'     => 'image_select',

                    'title'    => __('Spinner', 'dpr-adeline-extensions'),

                    'options'  => array(

                        'rotating-plane'   => array(

                            'alt' => esc_attr__('Rotating Plane', 'dpr-adeline-extensions'),

                            'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/preloaders/rotating-plane.png',

                        ),

                        'double-bounce'    => array(

                            'alt' => esc_attr__('Double Bounce', 'dpr-adeline-extensions'),

                            'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/preloaders/double-bounce.png',

                        ),

                        'wave'             => array(

                            'alt' => esc_attr__('Wave', 'dpr-adeline-extensions'),

                            'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/preloaders/wave.png',

                        ),

                        'wanedering-cubes' => array(

                            'alt' => esc_attr__('Wandering cubes', 'dpr-adeline-extensions'),

                            'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/preloaders/wanedering-cubes.png',

                        ),

                        'pulse'            => array(

                            'alt' => esc_attr__('Pulse', 'dpr-adeline-extensions'),

                            'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/preloaders/pulse.png',

                        ),

                        'chasing-dots'     => array(

                            'alt' => esc_attr__('Chasing dots', 'dpr-adeline-extensions'),

                            'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/preloaders/chasing-dots.png',

                        ),

                        'three-bounce'     => array(

                            'alt' => esc_attr__('Three bounce', 'dpr-adeline-extensions'),

                            'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/preloaders/three-bounce.png',

                        ),

                        'cube-grid'        => array(

                            'alt' => esc_attr__('Cube grid', 'dpr-adeline-extensions'),

                            'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/preloaders/cube-grid.png',

                        ),

                        'circle'           => array(

                            'alt' => esc_attr__('Circle', 'dpr-adeline-extensions'),

                            'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/preloaders/circle.png',

                        ),

                        'fading-circle'    => array(

                            'alt' => esc_attr__('Fading circle', 'dpr-adeline-extensions'),

                            'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/preloaders/fadding-circle.png',

                        ),

                        'folding-cube'     => array(

                            'alt' => esc_attr__('Folding cube', 'dpr-adeline-extensions'),

                            'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/preloaders/folding-cube.png',

                        ),

                    ),

                    'hint'     => array(

                        'title'   => esc_attr__('Spinner', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Choose one of predefined CSS spinners.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('preloader_spinner', 'equals', '1'),

                ),

                array(

                    'id'       => 'preloader_spinner_color',

                    'type'     => 'color',

                    'output'   => array('background-color' => '.dpr-spinner-rotating-plane, .dpr-spinner-double-bounce .dpr-spinner-child, .dpr-spinner-wave .dpr-spinner-rect, .dpr-spinner-wandering-cubes .dpr-spinner-cube, .dpr-spinner-pulse, .dpr-spinner-chasing-dots .dpr-spinner-child, .dpr-spinner-three-bounce .dpr-spinner-child, .dpr-spinner-circle .dpr-spinner-child:before, .dpr-spinner-cube-grid .dpr-spinner-cube, .dpr-spinner-fading-circle .dpr-spinner-circle:before, .dpr-spinner-folding-cube .dpr-spinner-cube:before'),

                    'title'    => __('Spinner Color', 'dpr-adeline-extensions'),

                    'hint'     => array(

                        'title'   => esc_attr__('Spinner Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set spinner color for page preloader.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('preloader_spinner', 'equals', '1'),

                ),

                array(

                    'id'       => 'preloader_text',

                    'type'     => 'switch',

                    'title'    => esc_html__('Use Preloader Text?', 'dpr-adeline-extensions'),

                    'hint'     => array(

                        'title'   => esc_attr__('Use Preloader Text?', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('You can enable or disable page preloader text. Will be displayed bellow spinner.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('page_preloader', 'equals', '1'),

                ),

                array(

                    'id'       => 'preloader_text_content',

                    'type'     => 'text',

                    'title'    => __('Preloader Text', 'dpr-adeline-extensions'),

                    'hint'     => array(

                        'title'   => esc_attr__('Preloader Text', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('You can set text for preloader. No HTML allowed.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('preloader_text', 'equals', '1'),

                ),

                array(

                    'id'             => 'preloader_text_typography',

                    'type'           => 'typography',

                    'title'          => __('Preloader Text Typography', 'redux-framework-demo'),

                    'google'         => true,

                    'letter-spacing' => true,

                    'text-transform' => true,

                    'all_styles'     => true,

                    'output'         => array('.dpr-loading-text-holder'),

                    'units'          => 'px',

                    'hint'           => array(

                        'title'   => esc_attr__('Preloader Text Typography', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('You can set typography for preloader text. No HTML allowed.', 'dpr-adeline-extensions'),

                    ),

                    'required'       => array('preloader_text', 'equals', '1'),

                ),

            ),

        );

        $portfolio_post_metabox_sections[] = array(

            'title'    => esc_html__('Top Bar Options', 'dpr-adeline-extensions'),

            'subtitle' => esc_html__('', 'dpr-adeline-extensions'),

        );

        $portfolio_post_metabox_sections[] = array(

            'title'      => esc_html__('General', 'dpr-adeline-extensions'),

            'subtitle'   => esc_html__('', 'dpr-adeline-extensions'),

            'subsection' => true,

            'fields'     => array(

                array(

                    'id'    => 'top_bar',

                    'type'  => 'switch',

                    'title' => esc_html__('Display Top Bar', 'dpr-adeline-extensions'),

                ),

                array(

                    'id'       => 'top_bar_full_width',

                    'type'     => 'switch',

                    'title'    => esc_html__('Force fullwidth top bar', 'dpr-adeline-extensions'),

                    'required' => array('top_bar', 'equals', '1'),

                ),

                array(

                    'id'             => 'top_bar_full_width_padding',

                    'type'           => 'spacing',

                    'output'         => array('.full-width-topbar #dpr-top-bar-inner'),

                    'mode'           => 'padding',

                    'units'          => array('px'),

                    'display_units'  => true,

                    'units_extended' => false,

                    'top'            => false,

                    'bottom'         => false,

                    'title'          => __('Fullwidth Top Bar Padding (px)', 'dpr-adeline-extensions'),

                    'required'       => array('top_bar_full_width', 'equals', '1'),

                    'hint'           => array(

                        'title'   => esc_attr__('Fullwidth Top Bar Paddingg', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Choose default padding for full width top bar.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'top_bar_visibility',

                    'type'     => 'image_select',

                    'title'    => __('Visibility', 'dpr-adeline-extensions'),

                    'options'  => array(

                        'all-devices'        => array(

                            'title' => esc_html__('All Devices', 'dpr-adeline-extensions'),

                            'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/visibility/all.png',

                        ),

                        'hide-tablet'        => array(

                            'title' => esc_html__('Hide On Tablet', 'dpr-adeline-extensions'),

                            'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/visibility/no_tablet.png',

                        ),

                        'hide-mobile'        => array(

                            'title' => esc_html__('Hide On Mobile', 'dpr-adeline-extensions'),

                            'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/visibility/no_mobile.png',

                        ),

                        'hide-tablet-mobile' => array(

                            'title' => esc_html__('Hide On Tablet & Mobile', 'dpr-adeline-extensions'),

                            'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/visibility/no_tablet_mobile.png',

                        ),

                    ),

                    'hint'     => array(

                        'title'   => esc_attr__('Visibility', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Enable or disable display top bar on certain devices.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('top_bar', 'equals', '1'),

                ),

                array(

                    'id'       => 'top_bar_style',

                    'type'     => 'select',

                    'title'    => esc_html__('Layout', 'dpr-adeline-extensions'),

                    'desc'     => '',

                    'options'  => array(

                        'one' => esc_html__('Content Left & Social Right', 'dpr-adeline-extensions'),

                        'two' => esc_html__('Social Left & Content Right', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('top_bar', 'equals', '1'),

                ),

                array(

                    'id'             => 'top_bar_padding',

                    'type'           => 'spacing',

                    'output'         => array('#dpr-top-bar-wrapper'),

                    'mode'           => 'padding',

                    'units'          => array('px', 'em'),

                    'display_units'  => true,

                    'units_extended' => false,

                    'title'          => __('Padding', 'dpr-adeline-extensions'),

                    'required'       => array('top_bar', 'equals', '1'),

                ),

                array(

                    'id'       => 'top_bar_bgr',

                    'type'     => 'color',

                    'output'   => array('background-color' => '#dpr-top-bar-wrapper'),

                    'validate' => 'color',

                    'title'    => esc_html__('Background Color', 'dpr-adeline-extensions'),

                    'required' => array('top_bar', 'equals', '1'),

                ),

                array(

                    'id'       => 'top_bar_border',

                    'type'     => 'color',

                    'output'   => array('border-color' => '#dpr-top-bar-wrapper'),

                    'validate' => 'color',

                    'title'    => esc_html__('Border Color', 'dpr-adeline-extensions'),

                    'required' => array('top_bar', 'equals', '1'),

                ),

                array(

                    'id'       => 'top_bar_text_color',

                    'type'     => 'color',

                    'output'   => array('color' => '#dpr-top-bar-content'),

                    'validate' => 'color',

                    'title'    => esc_html__('Text Color', 'dpr-adeline-extensions'),

                    'required' => array('top_bar', 'equals', '1'),

                ),

                array(

                    'id'       => 'top_bar_link_color',

                    'type'     => 'color',

                    'output'   => array('color' => '#dpr-top-bar-content a'),

                    'validate' => 'color',

                    'title'    => esc_html__('Link Color', 'dpr-adeline-extensions'),

                    'required' => array('top_bar', 'equals', '1'),

                ),

                array(

                    'id'       => 'top_bar_link_color_hover',

                    'type'     => 'color',

                    'output'   => array('color' => '#dpr-top-bar-content a:hover'),

                    'validate' => 'color',

                    'title'    => esc_html__('Link Color: Hover', 'dpr-adeline-extensions'),

                    'required' => array('top_bar', 'equals', '1'),

                ),

            ),

        );

        $portfolio_post_metabox_sections[] = array(

            'title'      => esc_html__('Content', 'dpr-adeline-extensions'),

            'subtitle'   => esc_html__('', 'dpr-adeline-extensions'),

            'subsection' => true,

            'fields'     => array(

                array(

                    'id'       => 'top_bar_content',

                    'type'     => 'textarea',

                    'title'    => esc_html__('Top bar content', 'dpr-adeline-extensions'),

                    'desc'     => esc_html__('Some HTML and shortcodes are allowed here', 'dpr-adeline-extensions'),

                    'validate' => 'html',

                    'hint'     => array(

                        'title'   => esc_attr__('Top Bar Content', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Add content (eg. the address information) which will be visible in top bar', 'dpr-adeline-extensions'),

                    ),

                ),

            ),

        );

        $portfolio_post_metabox_sections[] = array(

            'title'      => esc_html__('Social Icons', 'dpr-adeline-extensions'),

            'subtitle'   => esc_html__('', 'dpr-adeline-extensions'),

            'subsection' => true,

            'fields'     => array(

                array(

                    'id'    => 'top_bar_social_display',

                    'type'  => 'switch',

                    'title' => esc_html__('Enable social links', 'dpr-adeline-extensions'),

                ),

                array(

                    'id'       => 'top_bar_social_target',

                    'type'     => 'select',

                    'title'    => esc_html__('Social Link Target', 'dpr-adeline-extensions'),

                    'desc'     => '',

                    'options'  => array(

                        'blank' => esc_html__('New window', 'dpr-adeline-extensions'),

                        'self'  => esc_html__('Same window', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('top_bar_social_display', 'equals', '1'),

                ),

                array(

                    'id'             => 'top_bar_social_font_size',

                    'type'           => 'typography',

                    'title'          => esc_html__('Social Icons Font Size', 'dpr-adeline-extensions'),

                    'google'         => false,

                    'font-family'    => false,

                    'font-weight'    => false,

                    'font-style'     => false,

                    'subsets'        => false,

                    'font-size'      => true,

                    'text-align'     => false,

                    'line-height'    => false,

                    'word-spacing'   => false,

                    'letter-spacing' => false,

                    'text-transform' => false,

                    'color'          => false,

                    'preview'        => false,

                    'all_styles'     => false,

                    'units'          => 'px',

                    'output'         => array('#dpr-top-bar-social li a'),

                    'required'       => array('top_bar_social_display', 'equals', '1'),

                ),

                array(

                    'id'             => 'top_bar_social_padding',

                    'type'           => 'spacing',

                    'output'         => array('#dpr-top-bar-social li a'),

                    'mode'           => 'padding',

                    'top'            => false,

                    'bottom'         => false,

                    'units'          => array('px', 'em'),

                    'display_units'  => true,

                    'units_extended' => false,

                    'title'          => __('Social Icons Padding (px)', 'dpr-adeline-extensions'),

                    'required'       => array('top_bar_social_display', 'equals', '1'),

                ),

                array(

                    'id'       => 'top_bar_social_icons_color',

                    'type'     => 'color',

                    'output'   => array('#dpr-top-bar-social li a'),

                    'validate' => 'color',

                    'title'    => esc_html__('Social Icons Color', 'dpr-adeline-extensions'),

                    'required' => array('top_bar_social_display', 'equals', '1'),

                ),

                array(

                    'id'       => 'top_bar_social_icons_color_hover',

                    'type'     => 'color',

                    'output'   => array('#dpr-top-bar-social li a:hover'),

                    'validate' => 'color',

                    'title'    => esc_html__('Social Icons Color: Hover', 'dpr-adeline-extensions'),

                    'required' => array('top_bar_social_display', 'equals', '1'),

                ),

            ),

        );

        $portfolio_post_metabox_sections[] = array(

            'title'    => esc_html__('Header & Menu', 'dpr-adeline-extensions'),

            'subtitle' => esc_html__('', 'dpr-adeline-extensions'),

        );

        $portfolio_post_metabox_sections[] = array(

            'title'      => esc_html__('General Style', 'dpr-adeline-extensions'),

            'subtitle'   => esc_html__('', 'dpr-adeline-extensions'),

            'subsection' => true,

            'fields'     => array(

                array(

                    'id'      => 'header_style',

                    'type'    => 'image_select',

                    'title'   => __('Header Style', 'dpr-adeline-extensions'),

                    'options' => array(

                        'default'         => array(

                            'title' => esc_html__('Default', 'dpr-adeline-extensions'),

                            'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/header-styles/default.png',

                        ),

                        'center'          => array(

                            'title' => esc_html__('Center Logo', 'dpr-adeline-extensions'),

                            'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/header-styles/center.png',

                        ),

                        'top'             => array(

                            'title' => esc_html__('Top Logo', 'dpr-adeline-extensions'),

                            'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/header-styles/logo-top.png',

                        ),

                        'minimal'         => array(

                            'title' => esc_html__('Minimal', 'dpr-adeline-extensions'),

                            'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/header-styles/minimal.png',

                        ),

                        'magazine'        => array(

                            'title' => esc_html__('Magazine', 'dpr-adeline-extensions'),

                            'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/header-styles/magazine.png',

                        ),

                        'full_screen'     => array(

                            'title' => esc_html__('Fullscreen', 'dpr-adeline-extensions'),

                            'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/header-styles/fullscreen.png',

                        ),

                        'vertical'        => array(

                            'title' => esc_html__('Vertical', 'dpr-adeline-extensions'),

                            'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/header-styles/vertical.png',

                        ),

                        'custom'          => array(

                            'title' => esc_html__('Custom Horizontal', 'dpr-adeline-extensions'),

                            'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/header-styles/custom-h.png',

                        ),

                        'custom_vertical' => array(

                            'title' => esc_html__('Custom Vertical', 'dpr-adeline-extensions'),

                            'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/header-styles/custom-v.png',

                        ),

                    ),

                    'hint'    => array(

                        'title'   => esc_attr__('Header Style', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Choose default header style. This general settings can be overwriten for specific pages.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'default_header_info',

                    'type'     => 'info',

                    'style'    => 'dpr-title',

                    'title'    => wp_kses_post(__('<h3>Default Header Specific Settings</h3>', 'dpr-adeline-extensions')),

                    'required' => array('header_style', 'equals', array('default')),

                ),

                array(

                    'id'       => 'center_header_info',

                    'type'     => 'info',

                    'style'    => 'dpr-title',

                    'title'    => wp_kses_post(__('<h3>Center Header Specific Settings</h3>', 'dpr-adeline-extensions')),

                    'required' => array('header_style', 'equals', array('center')),

                ),

                array(

                    'id'       => 'top_header_info',

                    'type'     => 'info',

                    'style'    => 'dpr-title',

                    'title'    => wp_kses_post(__('<h3>Top Header Specific Settings</h3>', 'dpr-adeline-extensions')),

                    'required' => array('header_style', 'equals', array('top')),

                ),

                array(

                    'id'       => 'minimal_header_info',

                    'type'     => 'info',

                    'style'    => 'dpr-title',

                    'title'    => wp_kses_post(__('<h3>Minimal Header Specific Settings</h3>', 'dpr-adeline-extensions')),

                    'required' => array('header_style', 'equals', array('minimal')),

                ),

                array(

                    'id'       => 'magazine_header_info',

                    'type'     => 'info',

                    'style'    => 'dpr-title',

                    'title'    => wp_kses_post(__('<h3>Magazine Header Specific Settings</h3>', 'dpr-adeline-extensions')),

                    'required' => array('header_style', 'equals', array('magazine')),

                ),

                array(

                    'id'       => 'fullscreen_header_info',

                    'type'     => 'info',

                    'style'    => 'dpr-title',

                    'title'    => wp_kses_post(__('<h3>Full Screen Header Specific Settings</h3>', 'dpr-adeline-extensions')),

                    'required' => array('header_style', 'equals', array('full_screen')),

                ),

                array(

                    'id'       => 'custom_header_info',

                    'type'     => 'info',

                    'style'    => 'dpr-title',

                    'title'    => wp_kses_post(__('<h3>Custom Header Specific Settings</h3>', 'dpr-adeline-extensions')),

                    'required' => array('header_style', 'contains', 'custom'),

                ),

// Custom Header Settings

                array(

                    'id'       => 'header_particle_selected',

                    'type'     => 'select',

                    'data'     => 'posts',

                    'args'     => array('post_type' => array('dpr_particle'), 'posts_per_page' => -1),

                    'title'    => esc_html__('Custom Header Template', 'dpr-adeline-extensions'),

                    'desc'     => __('Please note that you need first create custom template in Particles menu'),

                    'hint'     => array(

                        'title'   => esc_attr__('Header Template', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Create custom header template first.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('header_style', 'contains', 'custom'),

                ),

                array(

                    'id'       => 'vertical_header_info',

                    'type'     => 'info',

                    'style'    => 'dpr-title',

                    'title'    => wp_kses_post(__('<h3>Vertical Header Specific Settings</h3>', 'dpr-adeline-extensions')),

                    'required' => array('header_style', 'contains', 'vertical'),

                ),

// Default & Center Header specifing settings

                array(

                    'id'       => 'header_height',

                    'type'     => 'dimensions',

                    'title'    => esc_html__('Header Height (px)', 'dpr-adeline-extensions'),

                    'output'   => array('height' => '#dpr-logo #dpr-logo-inner,.dpr-adeline-social-menu .social-menu-inner,.full_screen-header .menu-bar-inner,.minimal-header .menu-bar-inner'),

                    'width'    => false,

                    'height'   => true,

                    'mode'     => array('width' => 'width', 'height' => 'height'),

                    'units'    => array('px'),

                    'hint'     => array(

                        'title'   => esc_attr__('Header Height', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Specify the header height.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('header_style', 'equals', array('default', 'center', 'minimal', 'full_screen')),

                ),

                array(

                    'id'       => 'header_bg_color',

                    'type'     => 'color',

                    'output'   => array('background-color' => '#dpr-header,.vertical-header-overlapping-used .is-sticky #dpr-header.vertical-header,#searchform-header-replace'),

                    'validate' => 'color',

                    'title'    => esc_html__('Header Background Color', 'dpr-adeline-extensions'),

                    'required' => array('header_style', 'equals', array('default', 'center', 'minimal', 'full_screen')),

                    'hint'     => array(

                        'title'   => esc_attr__('Header Background Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set header background color.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'menu_alignment',

                    'type'     => 'radio',

                    'title'    => __('Menu Alignment', 'dpr-adeline-extensions'),

                    'options'  => array(

                        'left-menu'   => 'Left',

                        'center-menu' => 'Center',

                        'right-menu'  => 'Right',

                    ),

                    'required' => array('header_style', 'equals', array('default')),

                    'hint'     => array(

                        'title'   => esc_attr__('Menu Alignment', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set default menu alignment', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'center_header_menu_alignment',

                    'type'     => 'radio',

                    'title'    => __('Center Header Menus Position', 'dpr-adeline-extensions'),

                    'options'  => array(

                        'outside-aligned' => 'Outside aligned',

                        'centered'        => 'Centered',

                        'inside-aligned'  => 'Inside aligned',

                    ),

                    'required' => array('header_style', 'equals', 'center'),

                    'hint'     => array(

                        'title'   => esc_attr__('Center Header Menus Position', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('You can set default menus alignment in center header style', 'dpr-adeline-extensions'),

                    ),

                ),

// Top Header specifing settings

                array(

                    'id'             => 'top_header_logo_padding',

                    'type'           => 'spacing',

                    'output'         => array('#dpr-header.top-header .top-header-wrapper'),

                    'mode'           => 'padding',

                    'units'          => array('px'),

                    'display_units'  => true,

                    'units_extended' => false,

                    'left'           => false,

                    'right'          => false,

                    'title'          => __('Logo Vertical Padding (px)', 'dpr-adeline-extensions'),

                    'required'       => array('header_style', 'equals', 'top'),

                    'hint'           => array(

                        'title'   => esc_attr__('Logo Vertical Padding', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Choose default verticl padding for logo.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'top_header_top_bg_color',

                    'type'     => 'color',

                    'output'   => array('background-color' => '#dpr-header.top-header .top-header-wrapper'),

                    'validate' => 'color',

                    'title'    => esc_html__('Logo Area Background Color', 'dpr-adeline-extensions'),

                    'required' => array('header_style', 'equals', 'top'),

                    'hint'     => array(

                        'title'   => esc_attr__('Logo Area Background Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set logo area background color.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'top_header_nav_height',

                    'type'     => 'dimensions',

                    'title'    => esc_html__('Navigation Bar Height (px)', 'dpr-adeline-extensions'),

                    'output'   => array('height' => '#dpr-header.top-header #dpr-navigation-wrapper'),

                    'width'    => false,

                    'height'   => true,

                    'mode'     => array('width' => 'width', 'height' => 'height'),

                    'units'    => array('px'),

                    'hint'     => array(

                        'title'   => esc_attr__('Navigation Bar Height', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Specify top header navigation bar height.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('header_style', 'equals', 'top'),

                ),

                array(

                    'id'             => 'top_header_nav_item_padding',

                    'type'           => 'spacing',

                    'output'         => array('#dpr-header.top-header #dpr-navigation-wrapper .dropdown-menu > li > a'),

                    'mode'           => 'padding',

                    'units'          => array('px'),

                    'display_units'  => true,

                    'units_extended' => false,

                    'top'            => false,

                    'bottom'         => false,

                    'title'          => __('Menu Items Padding (px)', 'dpr-adeline-extensions'),

                    'required'       => array('header_style', 'equals', 'top'),

                    'hint'           => array(

                        'title'   => esc_attr__('Menu Item Padding', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Choose default padding for menu items.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'top_header_nav_bg_color',

                    'type'     => 'color',

                    'output'   => array('background-color' => '#dpr-header.top-header .bottom-header-wrapper'),

                    'validate' => 'color',

                    'title'    => esc_html__('Navigation Bar Background Color', 'dpr-adeline-extensions'),

                    'required' => array('header_style', 'equals', 'top'),

                    'hint'     => array(

                        'title'   => esc_attr__('Navigation Bar Background Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set navigation bar background color.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'top_header_only_menu_sticky',

                    'type'     => 'switch',

                    'title'    => esc_html__('Sticky Only Menu', 'dpr-adeline-extensions'),

                    'required' => array('header_style', 'equals', array('top')),

                    'hint'     => array(

                        'title'   => esc_attr__('Sticky Only menu', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('If enabled in sticky header will be only menu displayed ', 'dpr-adeline-extensions'),

                    ),

                ),

// Magazine Header specifing settings

                array(

                    'id'             => 'magazine_header_top_area_padding',

                    'type'           => 'spacing',

                    'output'         => array('#dpr-header.magazine-header .top-header-wrapper'),

                    'mode'           => 'padding',

                    'units'          => array('px'),

                    'display_units'  => true,

                    'units_extended' => false,

                    'left'           => false,

                    'right'          => false,

                    'title'          => __('Top Area Vertical Padding (px)', 'dpr-adeline-extensions'),

                    'required'       => array('header_style', 'equals', 'magazine'),

                    'hint'           => array(

                        'title'   => esc_attr__('Top Area Vertical Padding', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Choose default verticl padding for top area.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'magazine_header_top_bg_color',

                    'type'     => 'color',

                    'output'   => array('background-color' => '#dpr-header.magazine-header .top-header-wrapper'),

                    'validate' => 'color',

                    'title'    => esc_html__('Top Area Background Color', 'dpr-adeline-extensions'),

                    'required' => array('header_style', 'equals', 'magazine'),

                    'hint'     => array(

                        'title'   => esc_attr__('Top Area Background Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set top area background color.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'magazine_header_content_type',

                    'type'     => 'radio',

                    'title'    => __('Header Content Type', 'dpr-adeline-extensions'),

                    'options'  => array(

                        'default' => 'Default',

                        'custom'  => 'Custom Template',

                    ),

                    'required' => array('header_style', 'equals', 'magazine'),

                    'hint'     => array(

                        'title'   => esc_attr__('Header Content Type', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('By default is used HTML content entered bellow but you can also use custom template from Particles library. ', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'magazine_header_content',

                    'type'     => 'textarea',

                    'title'    => __('Header Content', 'dpr-adeline-extensions'),

                    'validate' => 'html',

                    'desc'     => __('<i><small>HTML is allowed.</small></i>'),

                    'hint'     => array(

                        'title'   => esc_attr__('Header Content', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('You can enter magazine header content here. HTML is allowed', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('magazine_header_content_type', 'equals', 'default'),

                ),

                array(

                    'id'       => 'magazine_header_particle_selected',

                    'type'     => 'select',

                    'data'     => 'posts',

                    'args'     => array('post_type' => array('dpr_particle'), 'posts_per_page' => -1),

                    'title'    => esc_html__('Custom Header Content Template', 'dpr-adeline-extensions'),

                    'desc'     => __('Please note that you need first create custom content template in Particles menu'),

                    'hint'     => array(

                        'title'   => esc_attr__('Custom Header Content Template', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Select previously prepared particle to display in magazine header content area. ', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('magazine_header_content_type', 'equals', 'custom'),

                ),

                array(

                    'id'       => 'magazine_header_nav_bg_color',

                    'type'     => 'color',

                    'output'   => array('background-color' => '#dpr-header.magazine-header .bottom-header-wrapper'),

                    'validate' => 'color',

                    'title'    => esc_html__('Navigation Bar Background Color', 'dpr-adeline-extensions'),

                    'required' => array('header_style', 'equals', 'magazine'),

                    'hint'     => array(

                        'title'   => esc_attr__('Navigation Bar Background Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set navigation bar background color.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'magazine_header_only_menu_sticky',

                    'type'     => 'switch',

                    'title'    => esc_html__('Sticky Only Menu', 'dpr-adeline-extensions'),

                    'required' => array('header_style', 'equals', array('magazine')),

                    'hint'     => array(

                        'title'   => esc_attr__('Sticky Only menu', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('If enabled in sticky header will be only menu displayed ', 'dpr-adeline-extensions'),

                    ),

                ),

// Fullscreen Header specifing settings

                array(

                    'id'       => 'fullscreen_appear_effect',

                    'type'     => 'select',

                    'title'    => esc_html__('Fullscreen Menu Appearance Effect', 'dpr-adeline-extensions'),

                    'desc'     => '',

                    'options'  => array(

                        'overlay-hugeinc'     => esc_html__('Fade', 'dpr-adeline-extensions'),

                        'overlay-corner'      => esc_html__('Corner', 'dpr-adeline-extensions'),

                        'overlay-slidedown'   => esc_html__('Slide Down', 'dpr-adeline-extensions'),

                        'overlay-scale'       => esc_html__('Scale', 'dpr-adeline-extensions'),

                        'overlay-simplegenie' => esc_html__('Genie', 'dpr-adeline-extensions'),

                    ),

                    'hint'     => array(

                        'title'   => esc_attr__('Fullscreen Menu Appearance Effect', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Select the appear animation effect for the full screen menu.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('header_style', 'equals', array('full_screen')),

                ),

                array(

                    'id'       => 'fullscreen_hamburger_color',

                    'type'     => 'color',

                    'output'   => array('background-color' => '.full_screen-header .menu-bar .opener,.full_screen-header .menu-bar .opener:before, .full_screen-header .menu-bar .opener:after'),

                    'validate' => 'color',

                    'title'    => esc_html__('Hamburger Color', 'dpr-adeline-extensions'),

                    'required' => array('header_style', 'equals', array('full_screen')),

                    'hint'     => array(

                        'title'   => esc_attr__('Hamburger Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set hamburger color.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'fullscreen_hamburger_close_color',

                    'type'     => 'color',

                    'output'   => array('background-color' => ' .full_screen-header .menu-bar.close-menu .opener:before, .full_screen-header .menu-bar.close-menu .opener:after'),

                    'validate' => 'color',

                    'title'    => esc_html__('Hamburger Color Close', 'dpr-adeline-extensions'),

                    'required' => array('header_style', 'equals', array('full_screen')),

                    'hint'     => array(

                        'title'   => esc_attr__('Hamburger Color Close', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set hamburger close color.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'fullscreen_menu_bg',

                    'type'     => 'color',

                    'output'   => array('background-color' => '.full_screen-header #full-screen-menu'),

                    'validate' => 'color',

                    'title'    => esc_html__('Full Screen Menu Background Color', 'dpr-adeline-extensions'),

                    'required' => array('header_style', 'equals', array('full_screen')),

                    'hint'     => array(

                        'title'   => esc_attr__('Full Screen Menu Background Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set full screen overlay background color.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'fullscreen_link_color',

                    'type'     => 'color',

                    'output'   => array('color' => '.full_screen-header .fs-dropdown-menu > li > a'),

                    'validate' => 'color',

                    'title'    => esc_html__('Full Screen Menu Link Color', 'dpr-adeline-extensions'),

                    'required' => array('header_style', 'equals', array('full_screen')),

                    'hint'     => array(

                        'title'   => esc_attr__('Full Screen Menu Link Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set full screen menu link color.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'fullscreen_hover_link_color',

                    'type'     => 'color',

                    'output'   => array('color' => '.full_screen-header .fs-dropdown-menu > li > a:hover'),

                    'validate' => 'color',

                    'title'    => esc_html__('Full Screen Menu Link Color: Hover', 'dpr-adeline-extensions'),

                    'required' => array('header_style', 'equals', array('full_screen')),

                    'hint'     => array(

                        'title'   => esc_attr__('Full Screen Menu Link Color: Hover', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set full screen menu link hover color.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'fullscreen_custom_logo',

                    'type'     => 'switch',

                    'title'    => esc_html__('Display Custom Logo', 'dpr-adeline-extensions'),

                    'required' => array('header_style', 'equals', array('full_screen')),

                    'hint'     => array(

                        'title'   => esc_attr__('Display Custom Logo', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Enable or disable display of custom logo ', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'fullscreen_logo',

                    'type'     => 'media',

                    'title'    => esc_html__('Logo', 'dpr-adeline-extensions'),

                    'required' => array('fullscreen_custom_logo', 'equals', '1'),

                    'hint'     => array(

                        'title'   => esc_attr__('Logo', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Select image for fullscreen logo', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'fullscreen_logo_retina',

                    'type'     => 'media',

                    'title'    => esc_html__('Retina Logo', 'dpr-adeline-extensions'),

                    'required' => array('fullscreen_custom_logo', 'equals', '1'),

                    'hint'     => array(

                        'title'   => esc_attr__('Logo', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Select image for fullscreen retina logo', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'fullscreen_search_form',

                    'type'     => 'switch',

                    'default'  => false,

                    'title'    => esc_html__('Display Serch Field', 'dpr-adeline-extensions'),

                    'required' => array('header_style', 'equals', array('full_screen')),

                    'hint'     => array(

                        'title'   => esc_attr__('Display Serch Form', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Enable or disable serch field bellow menu ', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'fullscreen_search_color',

                    'type'     => 'color',

                    'output'   => array('color' => '.full_screen-header .fs-dropdown-menu>li.search-toggle-li input,.full_screen-header .fs-dropdown-menu>li.search-toggle-li label',

                        'background-color'          => '.full_screen-header .fs-dropdown-menu>li.search-toggle-li label i'),

                    'validate' => 'color',

                    'title'    => esc_html__('Search Input Color', 'dpr-adeline-extensions'),

                    'required' => array('fullscreen_search_form', 'equals', '1'),

                    'hint'     => array(

                        'title'   => esc_attr__('Search Input Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set color for search input.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'fullscreen_search_underline_color',

                    'type'     => 'color',

                    'output'   => array('border-color' => '.full_screen-header .fs-dropdown-menu>li.search-toggle-li input'),

                    'validate' => 'color',

                    'title'    => esc_html__('Search Input Underline Color', 'dpr-adeline-extensions'),

                    'required' => array('fullscreen_search_form', 'equals', '1'),

                    'hint'     => array(

                        'title'   => esc_attr__('Search Input Underline Color: Active', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set color for search input underline.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'fullscreen_search_underline_color_active',

                    'type'     => 'color',

                    'output'   => array('border-color' => '.full_screen-header .fs-dropdown-menu>li.search-toggle-li input:hover, .full_screen-header .fs-dropdown-menu>li.search-toggle-li input:focus '),

                    'validate' => 'color',

                    'title'    => esc_html__('Search Input Underline Color: Focus', 'dpr-adeline-extensions'),

                    'required' => array('fullscreen_search_form', 'equals', '1'),

                    'hint'     => array(

                        'title'   => esc_attr__('Full Screen Menu Link Color: Focus', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set color for search focus and active input underline', 'dpr-adeline-extensions'),

                    ),

                ),

// Vertical Header specifing settings

                array(

                    'id'       => 'vertical_header_position',

                    'type'     => 'radio',

                    'title'    => __('Header Position', 'dpr-adeline-extensions'),

                    'options'  => array(

                        'left-header'  => 'Left',

                        'right-header' => 'Right',

                    ),

                    'required' => array('header_style', 'contains', 'vertical'),

                    'hint'     => array(

                        'title'   => esc_attr__('Header Position', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set default header position', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'vertical_header_expandable',

                    'type'     => 'switch',

                    'title'    => esc_html__('Header Expandable', 'dpr-adeline-extensions'),

                    'required' => array('header_style', 'contains', 'vertical'),

                    'hint'     => array(

                        'title'   => esc_attr__('Header Expandable', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Make header hidden on load and expandable on hamburger click.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'vertical_header_hamburger_color',

                    'type'     => 'color',

                    'output'   => array('background-color' => '#dpr-header.vertical-header .vertical-toggle .opener, #dpr-header.vertical-header .vertical-toggle .opener:before, #dpr-header.vertical-header .vertical-toggle .opener:after'),

                    'validate' => 'color',

                    'title'    => esc_html__('Hamburger Icon Color', 'dpr-adeline-extensions'),

                    'required' => array('vertical_header_expandable', 'equals', '1'),

                    'hint'     => array(

                        'title'   => esc_attr__('Hamburger Icon Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set hamburger icon color.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'vertical_header_width',

                    'type'     => 'dimensions',

                    'title'    => esc_html__('Header Width (px)', 'dpr-adeline-extensions'),

                    'output'   => array('width' => '#dpr-header.vertical-header'),

                    'width'    => true,

                    'height'   => false,

                    'mode'     => array('width' => 'width', 'height' => 'height'),

                    'units'    => array('px'),

                    'hint'     => array(

                        'title'   => esc_attr__('Width', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Specify vertical header width.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('header_style', 'equals', 'vertical'),

                ),

                array(

                    'id'       => 'vertical_header_bg',

                    'type'     => 'color',

                    'output'   => array('background-color' => '#dpr-header.vertical-header'),

                    'validate' => 'color',

                    'title'    => esc_html__('Background Color', 'dpr-adeline-extensions'),

                    'required' => array('header_style', 'contains', 'vertical'),

                    'hint'     => array(

                        'title'   => esc_attr__('Background Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set vertical header background color.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'vertical_header_shadow',

                    'type'     => 'switch',

                    'title'    => esc_html__('Use Shadow', 'dpr-adeline-extensions'),

                    'required' => array('header_style', 'contains', 'vertical'),

                    'hint'     => array(

                        'title'   => esc_attr__('Use Shadow', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Enable or disable box shadow effect for header ', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'             => 'vertical_header_padding',

                    'type'           => 'spacing',

                    'output'         => array('#dpr-header.vertical-header #dpr-header-inner'),

                    'mode'           => 'padding',

                    'units'          => array('px'),

                    'display_units'  => true,

                    'units_extended' => false,

                    'title'          => __('Inner Padding (px)', 'dpr-adeline-extensions'),

                    'required'       => array('header_style', 'equals', 'vertical'),

                    'hint'           => array(

                        'title'   => esc_attr__('Padding', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Choose default inner padding for verticalheader.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'vertical_header_logo_position',

                    'type'     => 'radio',

                    'title'    => __('Logo Position', 'dpr-adeline-extensions'),

                    'options'  => array(

                        'left-logo'   => 'Left',

                        'center-logo' => 'Center',

                        'right-logo'  => 'Right',

                    ),

                    'required' => array('header_style', 'contains', 'vertical'),

                    'hint'     => array(

                        'title'   => esc_attr__('Logo Position', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set default logo position', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'vertical_custom_logo',

                    'type'     => 'switch',

                    'title'    => esc_html__('Display Custom Logo', 'dpr-adeline-extensions'),

                    'required' => array('header_style', 'contains', 'vertical'),

                    'hint'     => array(

                        'title'   => esc_attr__('Display Custom Logo', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Enable or disable display of custom logo ', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'vertical_logo',

                    'type'     => 'media',

                    'title'    => esc_html__('Logo', 'dpr-adeline-extensions'),

                    'required' => array('vertical_custom_logo', 'equals', '1'),

                    'hint'     => array(

                        'title'   => esc_attr__('Logo', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Select image for fullscreen logo', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'vertical_logo_retina',

                    'type'     => 'media',

                    'title'    => esc_html__('Retina Logo', 'dpr-adeline-extensions'),

                    'required' => array('vertical_custom_logo', 'equals', '1'),

                    'hint'     => array(

                        'title'   => esc_attr__('Logo', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Select image for fullscreen retina logo', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'vertical_header_menu_align',

                    'type'     => 'radio',

                    'title'    => __('Menu Alignment', 'dpr-adeline-extensions'),

                    'options'  => array(

                        'left-vmenu'   => 'Left',

                        'center-vmenu' => 'Center',

                        'right-vmenu'  => 'Right',

                    ),

                    'required' => array('header_style', 'contains', 'vertical'),

                    'hint'     => array(

                        'title'   => esc_attr__('Menu Alignment', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set default menu alignment', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'             => 'vertical_header_menu_items_padding',

                    'type'           => 'spacing',

                    'output'         => array('#dpr-header.vertical-header #dpr-navigation-wrapper .dropdown-menu li > a '),

                    'mode'           => 'padding',

                    'units'          => array('px'),

                    'left'           => false,

                    'right'          => false,

                    'display_units'  => true,

                    'units_extended' => false,

                    'title'          => __('Menu Iteems Vertical Padding (px)', 'dpr-adeline-extensions'),

                    'required'       => array('header_style', 'equals', 'vertical'),

                    'hint'           => array(

                        'title'   => esc_attr__('Menu Iteems Vertical Padding', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Choose default menu items padding for vertical header menu.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'vertical_menu_link_color',

                    'type'     => 'color',

                    'output'   => array('color' => '#dpr-header.vertical-header #dpr-navigation-wrapper .dropdown-menu li > a '),

                    'validate' => 'color',

                    'title'    => esc_html__('Menu Link Color', 'dpr-adeline-extensions'),

                    'required' => array('header_style', 'contains', 'vertical'),

                    'hint'     => array(

                        'title'   => esc_attr__('Menu Link Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set menu link color.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'vertical_menu_link_color_hover',

                    'type'     => 'color',

                    'output'   => array('color' => '#dpr-header.vertical-header #dpr-navigation-wrapper .dropdown-menu li > a:hover'),

                    'validate' => 'color',

                    'title'    => esc_html__('Menu Link Color: Hover', 'dpr-adeline-extensions'),

                    'required' => array('header_style', 'contains', 'vertical'),

                    'hint'     => array(

                        'title'   => esc_attr__('Menu Link Color: Hover', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set menu link hover color.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'vertical_menu_separator_color',

                    'type'     => 'color',

                    'output'   => array('border-color' => '#dpr-header.vertical-header #dpr-navigation-wrapper .dropdown-menu li'),

                    'validate' => 'color',

                    'title'    => esc_html__('Menu Separator Color', 'dpr-adeline-extensions'),

                    'required' => array('header_style', 'contains', 'vertical'),

                    'hint'     => array(

                        'title'   => esc_attr__('Menu Separator Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set menu separator color.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'vertical_header_search',

                    'type'     => 'switch',

                    'title'    => esc_html__('Display Search Field', 'dpr-adeline-extensions'),

                    'required' => array('header_style', 'contains', 'vertical'),

                    'hint'     => array(

                        'title'   => esc_attr__('Display Search Field', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Enable or disable display search box for header ', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'vertical_header_search_bg',

                    'type'     => 'color',

                    'output'   => array('background-color' => '#dpr-header.vertical-header #vertical-searchform form .search-bg'),

                    'validate' => 'color',

                    'title'    => esc_html__('Search Field Background', 'dpr-adeline-extensions'),

                    'required' => array('vertical_header_search', 'equals', '1'),

                    'hint'     => array(

                        'title'   => esc_attr__('Search Field Background', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set background color for search box.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'vertical_header_search_color',

                    'type'     => 'color',

                    'output'   => array('color' => '#dpr-header.vertical-header #vertical-searchform form input, #dpr-header.vertical-header #vertical-searchform form label'),

                    'validate' => 'color',

                    'title'    => esc_html__('Search Field Text Color', 'dpr-adeline-extensions'),

                    'required' => array('vertical_header_search', 'equals', '1'),

                    'hint'     => array(

                        'title'   => esc_attr__('Search Field Text Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set color for search box.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'vertical_header_search_border',

                    'type'     => 'color',

                    'output'   => array('border-color' => '#dpr-header.vertical-header #vertical-searchform form input'),

                    'validate' => 'color',

                    'title'    => esc_html__('Search Field Border Color', 'dpr-adeline-extensions'),

                    'required' => array('vertical_header_search', 'equals', '1'),

                    'hint'     => array(

                        'title'   => esc_attr__('Search Field Border Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set border color for search box.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'vertical_header_search_border_hover',

                    'type'     => 'color',

                    'output'   => array('border-color' => '#dpr-header.vertical-header #vertical-searchform form input:hover, #dpr-header.vertical-header #vertical-searchform form input:focus'),

                    'validate' => 'color',

                    'title'    => esc_html__('Search Field Border Color: Hover', 'dpr-adeline-extensions'),

                    'required' => array('vertical_header_search', 'equals', '1'),

                    'hint'     => array(

                        'title'   => esc_attr__('Search Field Border Color: Hover', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set border hover and focus color for search box.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'vertical_header_search_button_color',

                    'type'     => 'color',

                    'output'   => array('color' => '#dpr-header.vertical-header #vertical-searchform form button'),

                    'validate' => 'color',

                    'title'    => esc_html__('Search Field Border Color: Hover', 'dpr-adeline-extensions'),

                    'required' => array('vertical_header_search', 'equals', '1'),

                    'hint'     => array(

                        'title'   => esc_attr__('Search Field Button Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set search button (icon) color for search box.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'vertical_header_search_button_color_hover',

                    'type'     => 'color',

                    'output'   => array('color' => '#dpr-header.vertical-header #vertical-searchform form button:hover'),

                    'validate' => 'color',

                    'title'    => esc_html__('Search Field Border Color: Hover', 'dpr-adeline-extensions'),

                    'required' => array('vertical_header_search', 'equals', '1'),

                    'hint'     => array(

                        'title'   => esc_attr__('Search Field Bytton Color: Hover', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set search button (icon) hover color for search box.', 'dpr-adeline-extensions'),

                    ),

                ),

// Common Settings

                array(

                    'id'       => 'common_header_info',

                    'type'     => 'info',

                    'style'    => 'dpr-title',

                    'required' => array('header_style', 'not_contain', 'vertical'),

                    'title'    => wp_kses_post(__('<h3>Settings Common For All Header Styles </h3>', 'dpr-adeline-extensions')),

                ),

                array(

                    'id'       => 'use_header_border',

                    'type'     => 'switch',

                    'title'    => esc_html__('Use Header Border Bottom', 'dpr-adeline-extensions'),

                    'required' => array('header_style', 'not_contain', 'vertical'),

                    'hint'     => array(

                        'title'   => esc_attr__('Use Header Border Bottom', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Enable or disable header bottom border ', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'header_border_color',

                    'type'     => 'color',

                    'output'   => array('border-color' => '#dpr-header'),

                    'validate' => 'color',

                    'title'    => esc_html__('Header Border Color', 'dpr-adeline-extensions'),

                    'required' => array('use_header_border', 'equals', '1'),

                    'hint'     => array(

                        'title'   => esc_attr__('Header Border Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set header bottom border color.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'header_full_width',

                    'type'     => 'switch',

                    'title'    => esc_html__('Force Fullwidth Header', 'dpr-adeline-extensions'),

                    'required' => array('header_style', 'not_contain', 'vertical'),

                    'hint'     => array(

                        'title'   => esc_attr__('Force Fullwidth Header', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Add content (eg. the address information) which will be visible in top bar', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'             => 'header_full_width_padding',

                    'type'           => 'spacing',

                    'output'         => array('.full-width-header #dpr-header-inner'),

                    'mode'           => 'padding',

                    'units'          => array('px'),

                    'display_units'  => true,

                    'units_extended' => false,

                    'top'            => false,

                    'bottom'         => false,

                    'title'          => __('Fullwidth Header Padding (px)', 'dpr-adeline-extensions'),

                    'required'       => array('header_full_width', 'equals', '1'),

                    'hint'           => array(

                        'title'   => esc_attr__('Fullwidth Header Paddingg', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Choose default padding for full width header.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'use_header_overlapping',

                    'type'     => 'switch',

                    'title'    => esc_html__('Use Header Overlapping', 'dpr-adeline-extensions'),

                    'required' => array('header_style', 'not_contain', 'vertical'),

                    'hint'     => array(

                        'title'   => esc_attr__('Use Header Overlapping', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Use transparent or semitransparent overlapped header', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'overlapping_header_bg_color',

                    'type'     => 'color',

                    'output'   => array('background-color' => '.header-overlapping-used #dpr-header'),

                    'validate' => 'color',

                    'title'    => esc_html__('Overlapping Header Background Color', 'dpr-adeline-extensions'),

                    'required' => array('use_header_overlapping', 'equals', '1'),

                    'hint'     => array(

                        'title'   => esc_attr__('Overlapping Header Background Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set overlapping header background color.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'overlapping_header_style',

                    'type'     => 'radio',

                    'title'    => __('Overlapping Header Style', 'dpr-adeline-extensions'),

                    'options'  => array(

                        'light' => 'Light',

                        'dark'  => 'Dark',

                    ),

                    'required' => array('use_header_overlapping', 'equals', '1'),

                    'hint'     => array(

                        'title'   => esc_attr__('Overlapping Header Style', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Select default overlapping style. Light is intented for headers with a dark background , dark for light backgrounds,', 'dpr-adeline-extensions'),

                    ),

                ),

            ),

        );

        $portfolio_post_metabox_sections[] = array(

            'title'      => esc_html__('Logo', 'dpr-adeline-extensions'),

            'subtitle'   => esc_html__('', 'dpr-adeline-extensions'),

            'subsection' => true,

            'fields'     => array(

                array(

                    'id'    => 'logo_default',

                    'type'  => 'media',

                    'title' => esc_html__('Logo', 'dpr-adeline-extensions'),

                    'hint'  => array(

                        'title'   => esc_attr__('Logo', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Select image for logo for this page', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'    => 'logo_default_retina',

                    'type'  => 'media',

                    'title' => esc_html__('Logo Retina', 'dpr-adeline-extensions'),

                    'hint'  => array(

                        'title'   => esc_attr__('Logo Retina', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Select image for retina logo for this page', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'    => 'logo_overlapping_light',

                    'type'  => 'media',

                    'title' => esc_html__('Overlapping Logo Light', 'dpr-adeline-extensions'),

                    'hint'  => array(

                        'title'   => esc_attr__('Overlapping Logo Light', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Select overlapping logo light for this page.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'    => 'logo_overlapping_light_retina',

                    'type'  => 'media',

                    'title' => esc_html__('Overlapping Logo Light  Retina', 'dpr-adeline-extensions'),

                    'hint'  => array(

                        'title'   => esc_attr__('Overlapping Logo Light Retina', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Select overlapping light retina logo for this page.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'    => 'logo_overlapping_dark',

                    'type'  => 'media',

                    'title' => esc_html__('Overlapping Logo Dark', 'dpr-adeline-extensions'),

                    'hint'  => array(

                        'title'   => esc_attr__('Overlapping Logo Dark', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Select overlapping logo dark for this page.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'    => 'logo_overlapping_dark_retina',

                    'type'  => 'media',

                    'title' => esc_html__('Overlapping Logo Dark  Retina', 'dpr-adeline-extensions'),

                    'hint'  => array(

                        'title'   => esc_attr__('Overlapping Logo Dark Retina', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Select overlapping retina logo dark for this page.', 'dpr-adeline-extensions'),

                    ),

                ),

            ),

        );

        $portfolio_post_metabox_sections[] = array(

            'title'      => esc_html__('Menu Style', 'dpr-adeline-extensions'),

            'subtitle'   => esc_html__('', 'dpr-adeline-extensions'),

            'subsection' => true,

            'fields'     => array(

                array(

                    'id'    => 'menu_main_styling_info',

                    'type'  => 'info',

                    'style' => 'dpr-title',

                    'title' => wp_kses_post(__('<h3>Main Styling</h3>', 'dpr-adeline-extensions')),

                ),

                array(

                    'id'       => 'menu_link_color',

                    'type'     => 'color',

                    'output'   => array('color' => '#dpr-navigation-wrapper .dropdown-menu > li > a,#dpr-adeline-mobile-menu-icon a,#searchform-header-replace-close'),

                    'validate' => 'color',

                    'title'    => esc_html__('Menu Link Color', 'dpr-adeline-extensions'),

                    'hint'     => array(

                        'title'   => esc_attr__('Menu Link Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set main menu link color.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'menu_link_color_hover',

                    'type'     => 'color',

                    'output'   => array('color' => '#dpr-navigation-wrapper .dropdown-menu > li > a:hover,#dpr-adeline-mobile-menu-icon a:hover,#searchform-header-replace-close:hover'),

                    'validate' => 'color',

                    'title'    => esc_html__('Menu Link Color: Hover', 'dpr-adeline-extensions'),

                    'hint'     => array(

                        'title'   => esc_attr__('Menu Link Color: Hover', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set main menu link hover color.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'menu_link_color_curent',

                    'type'     => 'color',

                    'output'   => array('color' => '#dpr-navigation-wrapper .dropdown-menu > .current-menu-item > a,#dpr-navigation-wrapper .dropdown-menu > .current-menu-ancestor > a,#dpr-navigation-wrapper .dropdown-menu > .current-menu-item > a:hover,#dpr-navigation-wrapper .dropdown-menu > .current-menu-ancestor > a:hover'),

                    'validate' => 'color',

                    'title'    => esc_html__('Menu Link Color: Current Menu Item', 'dpr-adeline-extensions'),

                    'hint'     => array(

                        'title'   => esc_attr__('Menu Link Color: Current Menu Item', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set main menu current menu item link color.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'menu_link_bg_color',

                    'type'     => 'color',

                    'output'   => array('background-color' => '#dpr-navigation-wrapper .dropdown-menu > li > a'),

                    'validate' => 'color',

                    'title'    => esc_html__('Menu Item Background Color', 'dpr-adeline-extensions'),

                    'hint'     => array(

                        'title'   => esc_attr__('Menu Item Background Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set menu item background color.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'menu_link_bg_color_hover',

                    'type'     => 'color',

                    'output'   => array('background-color' => '#dpr-navigation-wrapper .dropdown-menu > li > a:hover'),

                    'validate' => 'color',

                    'title'    => esc_html__('Menu Item Background Color: Hover', 'dpr-adeline-extensions'),

                    'hint'     => array(

                        'title'   => esc_attr__('Menu Item Background Color: Hover', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set menu item hover background color.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'menu_link_bg_color_curent',

                    'type'     => 'color',

                    'output'   => array('color' => '#dpr-navigation-wrapper .dropdown-menu > .current-menu-item > a,#dpr-navigation-wrapper .dropdown-menu > .current-menu-ancestor > a,#dpr-navigation-wrapper .dropdown-menu > .current-menu-item > a:hover,#dpr-navigation-wrappe .dropdown-menu > .current-menu-ancestor > a:hover'),

                    'validate' => 'color',

                    'title'    => esc_html__('Menu Item Background Color: Current Menu Item', 'dpr-adeline-extensions'),

                    'hint'     => array(

                        'title'   => esc_attr__('Menu Item Background Color: Current Menu Item', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set current menu item background color.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'             => 'menu_link_spacing',

                    'type'           => 'spacing',

                    'output'         => array('#dpr-navigation-wrapper .dropdown-menu > li > a'),

                    'mode'           => 'padding',

                    'units'          => array('px'),

                    'display_units'  => true,

                    'units_extended' => false,

                    'top'            => false,

                    'bottom'         => false,

                    'title'          => __('Menu Items Horizontal Padding(px)', 'dpr-adeline-extensions'),

                    'hint'           => array(

                        'title'   => esc_attr__('Menu Items Horizontal Padding(px)', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Choose default menu items left/right padding.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'    => 'menu_overlapp_info',

                    'type'  => 'info',

                    'style' => 'dpr-title',

                    'title' => wp_kses_post(__('<h3>Overlapping Header Menu styling</h3>', 'dpr-adeline-extensions')),

                ),

                array(

                    'id'    => 'menu_overlapp_light_info',

                    'type'  => 'info',

                    'style' => 'dpr-subtitle',

                    'title' => wp_kses_post(__('<h3>Overlapping Light Style</h3>', 'dpr-adeline-extensions')),

                ),

                array(

                    'id'       => 'menu_link_color_ol',

                    'type'     => 'color',

                    'output'   => array('color' => 'body.header-overlapping-used.overlapping-style-light #dpr-navigation-wrapper .dropdown-menu > li > a,body.header-overlapping-used.overlapping-style-light #dpr-adeline-mobile-menu-icon a,body.header-overlapping-used.overlapping-style-light #searchform-header-replace-close'),

                    'validate' => 'color',

                    'title'    => esc_html__('Menu Link Color', 'dpr-adeline-extensions'),

                    'hint'     => array(

                        'title'   => esc_attr__('Menu Link Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set main menu link color for overlapping header light style.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'menu_link_color_hover_ol',

                    'type'     => 'color',

                    'output'   => array('color' => 'body.header-overlapping-used.overlapping-style-light #dpr-navigation-wrapper .dropdown-menu > li > a:hover,body.header-overlapping-used.overlapping-style-light #dpr-adeline-mobile-menu-icon a:hover,body.header-overlapping-used.overlapping-style-light #searchform-header-replace-close:hover'),

                    'validate' => 'color',

                    'title'    => esc_html__('Menu Link Color: Hover', 'dpr-adeline-extensions'),

                    'hint'     => array(

                        'title'   => esc_attr__('Overlapping Light Menu Link Color: Hover', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set main menu link hover color for overlapping header light style.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'menu_link_color_curent_ol',

                    'type'     => 'color',

                    'output'   => array('color' => 'body.header-overlapping-used.overlapping-style-light #dpr-navigation-wrapper .dropdown-menu > .current-menu-item > a,body.header-overlapping-used.overlapping-style-light #dpr-navigation-wrapper .dropdown-menu > .current-menu-ancestor > a,body.header-overlapping-used.overlapping-style-light #dpr-navigation-wrapper .dropdown-menu > .current-menu-item > a:hover,body.header-overlapping-used.overlapping-style-light #dpr-navigation-wrapper .dropdown-menu > .current-menu-ancestor > a:hover'),

                    'validate' => 'color',

                    'title'    => esc_html__('Overlapping Light Menu Link Color: Current Menu Item', 'dpr-adeline-extensions'),

                    'hint'     => array(

                        'title'   => esc_attr__('Overlapping Light Menu Link Color: Current Menu Item', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set main menu current menu item link color for overlapping header light style.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'    => 'menu_overlapp_dark_info',

                    'type'  => 'info',

                    'style' => 'dpr-subtitle',

                    'title' => wp_kses_post(__('<h3>Overlapping Dark Style</h3>', 'dpr-adeline-extensions')),

                ),

                array(

                    'id'       => 'menu_link_color_od',

                    'type'     => 'color',

                    'output'   => array('color' => 'body.header-overlapping-used.overlapping-style-dark #dpr-navigation-wrapper .dropdown-menu > li > a,body.header-overlapping-used.overlapping-style-dark #dpr-adeline-mobile-menu-icon a,body.header-overlapping-used.overlapping-style-dark #searchform-header-replace-close'),

                    'validate' => 'color',

                    'title'    => esc_html__('Menu Link Color', 'dpr-adeline-extensions'),

                    'hint'     => array(

                        'title'   => esc_attr__('Menu Link Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set main menu link coloroverlapping header dark style.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'menu_link_color_hover_od',

                    'type'     => 'color',

                    'output'   => array('color' => 'body.header-overlapping-used.overlapping-style-dark #dpr-navigation-wrapper .dropdown-menu > li > a:hover,body.header-overlapping-used.overlapping-style-dark #dpr-adeline-mobile-menu-icon a:hover,body.header-overlapping-used.overlapping-style-dark #searchform-header-replace-close:hover'),

                    'validate' => 'color',

                    'title'    => esc_html__('Menu Link Color: Hover', 'dpr-adeline-extensions'),

                    'hint'     => array(

                        'title'   => esc_attr__('Menu Link Color: Hover', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set main menu link hover color overlapping header dark style.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'menu_link_color_curent_od',

                    'type'     => 'color',

                    'output'   => array('color' => 'body.header-overlapping-used.overlapping-style-dark #dpr-navigation-wrapper .dropdown-menu > .current-menu-item > a,body.header-overlapping-used.overlapping-style-dark #dpr-navigation-wrapper .dropdown-menu > .current-menu-ancestor > a,body.header-overlapping-used.overlapping-style-dark #dpr-navigation-wrapper .dropdown-menu > .current-menu-item > a:hover,body.header-overlapping-used.overlapping-style-dark #dpr-navigation-wrapper .dropdown-menu > .current-menu-ancestor > a:hover'),

                    'validate' => 'color',

                    'title'    => esc_html__('Menu Link Color: Current Menu Item', 'dpr-adeline-extensions'),

                    'hint'     => array(

                        'title'   => esc_attr__('Menu Link Color: Current Menu Item', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set main menu current menu item link color overlapping header dark style.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'    => 'menu_effets_info',

                    'type'  => 'info',

                    'style' => 'dpr-title',

                    'title' => wp_kses_post(__('<h3>Top Menu Effects</h3>', 'dpr-adeline-extensions')),

                ),

                array(

                    'id'      => 'menu_effect',

                    'type'    => 'select',

                    'title'   => esc_html__('Menu Link Effect', 'dpr-adeline-extensions'),

                    'desc'    => '',

                    'options' => array(

                        'no' => esc_html__('None', 'dpr-adeline-extensions'),

                        '1'  => esc_html__('Underline Animated From Left', 'dpr-adeline-extensions'),

                        '2'  => esc_html__('Underline Animated From Bottom', 'dpr-adeline-extensions'),

                        '3'  => esc_html__('Underline Animated From Top', 'dpr-adeline-extensions'),

                        '4'  => esc_html__('Underline Animated From Center', 'dpr-adeline-extensions'),

                        '5'  => esc_html__('Underline & Overline Animated From Left', 'dpr-adeline-extensions'),

                        '6'  => esc_html__('Underline & Overline Animated From Right', 'dpr-adeline-extensions'),

                        '7'  => esc_html__('Underline & Overline Animated From Center', 'dpr-adeline-extensions'),

                        '8'  => esc_html__('Underline & Overline Animated Oposite', 'dpr-adeline-extensions'),

                        '9'  => esc_html__('Underline & Overline Animated Oposite Reverse', 'dpr-adeline-extensions'),

                        '10' => esc_html__('Stroke', 'dpr-adeline-extensions'),

                        '11' => esc_html__('Marker', 'dpr-adeline-extensions'),

                        '12' => esc_html__('Background Animated From Left', 'dpr-adeline-extensions'),

                        '13' => esc_html__('Background Animated From Bottom', 'dpr-adeline-extensions'),

                        '14' => esc_html__('Bracket', 'dpr-adeline-extensions'),

                        '15' => esc_html__('Circular Reveal', 'dpr-adeline-extensions'),

                    ),

                    'hint'    => array(

                        'title'   => esc_attr__('Menu Link Effect', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Select menu link effect.', 'dpr-adeline-extensions'),

                    ),

                ),

            ),

        );

        $portfolio_post_metabox_sections[] = array(

            'title'      => esc_html__('Sticky Header', 'dpr-adeline-extensions'),

            'subtitle'   => esc_html__('', 'dpr-adeline-extensions'),

            'subsection' => true,

            'fields'     => array(

                array(

                    'id'    => 'sticky_heder_enable',

                    'type'  => 'switch',

                    'title' => esc_html__('Use Sticky Header', 'dpr-adeline-extensions'),

                    'hint'  => array(

                        'title'   => esc_attr__('Use Sticky Header', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Enable or disable display sticky header usage for this page', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'sticky_menu_general_info',

                    'type'     => 'info',

                    'style'    => 'dpr-title',

                    'required' => array('sticky_heder_enable', 'equals', '1'),

                    'title'    => wp_kses_post(__('<h3>General Setting</h3>', 'dpr-adeline-extensions')),

                ),

                array(

                    'id'       => 'use_sticky_topbar',

                    'type'     => 'switch',

                    'title'    => esc_html__('Use Sticky Top Bar', 'dpr-adeline-extensions'),

                    'required' => array('sticky_heder_enable', 'equals', '1'),

                    'hint'     => array(

                        'title'   => esc_attr__('Use Sticky Top Bar', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Enable to display top bar in sticky header too for this page', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'use_sticky_mobile',

                    'type'     => 'switch',

                    'title'    => esc_html__('Use Sticky Mobile', 'dpr-adeline-extensions'),

                    'required' => array('sticky_heder_enable', 'equals', '1'),

                    'hint'     => array(

                        'title'   => esc_attr__('Use Sticky Mobile', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Enable to display top bar in sticky header on mobile for this page', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'use_fullwidth_sticky_header',

                    'type'     => 'switch',

                    'title'    => esc_html__('Use Full Width Sticky Header', 'dpr-adeline-extensions'),

                    'required' => array('sticky_heder_enable', 'equals', '1'),

                    'hint'     => array(

                        'title'   => esc_attr__('Use Full Width Sticky Header', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Enable full width sticky header for this page', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'disable_sticky_header_shadow',

                    'type'     => 'switch',

                    'title'    => esc_html__('Disable Sticky Header Shadow', 'dpr-adeline-extensions'),

                    'required' => array('sticky_heder_enable', 'equals', '1'),

                    'hint'     => array(

                        'title'   => esc_attr__('Disable Sticky Header Shadow', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Disable bottom shadow for sticky header on this page', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'sticky_header_style',

                    'type'     => 'radio',

                    'title'    => __('Sticky Header Style', 'dpr-adeline-extensions'),

                    'required' => array('sticky_heder_enable', 'equals', '1'),

                    'options'  => array(

                        'fixed'  => 'Fixed',

                        'shrink' => 'Shrinked',

                    ),

                    'hint'     => array(

                        'title'   => esc_attr__('Sticky Header Style', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Shrinked style allow set smaller as default sticky header and resize some header elements. Fixed style leaves sticky header of the same size as default header.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'shrink_header_height',

                    'type'     => 'dimensions',

                    'units'    => array('px'),

                    'mode'     => array('height' => 'height', 'width' => 'width'),

                    'width'    => false,

                    'output'   => array('.is-sticky #dpr-header.shrink-header #dpr-logo #dpr-logo-inner, .is-sticky #dpr-header.shrink-header .dpr-adeline-social-menu .social-menu-inner, .is-sticky #dpr-header.shrink-header.full_screen-header .menu-bar-inner, .is-sticky #dpr-header.shrink-header.minimal-header .menu-bar-inner'),

                    'title'    => __('Shrinked Sticky Header Height', 'dpr-adeline-extensions'),

                    'hint'     => array(

                        'title'   => esc_attr__('Shrinked Sticky Header Height', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set sticky header height when shrinked style used for this page.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('sticky_header_style', 'equals', 'shrink'),

                ),

/* Logo settings stuff */

                array(

                    'id'       => 'sticky_menu_logo_info',

                    'type'     => 'info',

                    'style'    => 'dpr-title',

                    'required' => array('sticky_heder_enable', 'equals', '1'),

                    'title'    => wp_kses_post(__('<h3>Logo</h3>', 'dpr-adeline-extensions')),

                ),

                array(

                    'id'       => 'logo_sticky',

                    'type'     => 'media',

                    'title'    => esc_html__('Logo Sticky', 'dpr-adeline-extensions'),

                    'required' => array('sticky_heder_enable', 'equals', '1'),

                    'hint'     => array(

                        'title'   => esc_attr__('Logo Sticky', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Select logo image for sticky header for this page.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'logo_sticky_retina',

                    'type'     => 'media',

                    'title'    => esc_html__('Logo Sticky Retina', 'dpr-adeline-extensions'),

                    'required' => array('sticky_heder_enable', 'equals', '1'),

                    'hint'     => array(

                        'title'   => esc_attr__('Logo Sticky Retina', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Select retina logo image for sticky header for this page.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'shrink_header_logo_height',

                    'type'     => 'dimensions',

                    'units'    => array('px'),

                    'mode'     => array('height' => 'height', 'width' => 'width'),

                    'width'    => false,

                    'output'   => '',

                    'title'    => __('Shrinked  Sticky Header Logo Height', 'dpr-adeline-extensions'),

                    'hint'     => array(

                        'title'   => esc_attr__('Shrinked  Sticky Header Logo Height', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set logo height when shrinked style used for this page.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('sticky_header_style', 'equals', 'shrink'),

                ),

/* Sticky header styling*/

                array(

                    'id'       => 'sticky_menu_styling_info',

                    'type'     => 'info',

                    'style'    => 'dpr-title',

                    'title'    => wp_kses_post(__('<h3>Menu Style</h3>', 'dpr-adeline-extensions')),

                    'required' => array('sticky_heder_enable', 'equals', '1'),

                ),

                array(

                    'id'       => 'sticky_header_background',

                    'type'     => 'color',

                    'output'   => array('background-color' => '.is-sticky #dpr-header, .is-sticky #searchform-header-replace'),

                    'validate' => 'color',

                    'title'    => esc_html__('Sticky Header Background', 'dpr-adeline-extensions'),

                    'required' => array('sticky_heder_enable', 'equals', '1'),

                    'hint'     => array(

                        'title'   => esc_attr__('Sticky Header Background', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set sticky header background color for this page.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'sticky_header_link_color',

                    'type'     => 'color',

                    'output'   => array('.is-sticky  #dpr-header  #dpr-navigation-wrapper .dropdown-menu > li > a,.is-sticky #dpr-adeline-mobile-menu-icon a,.is-sticky #searchform-header-replace-close'),

                    'validate' => 'color',

                    'title'    => esc_html__('Sticky Header Link Color', 'dpr-adeline-extensions'),

                    'required' => array('sticky_heder_enable', 'equals', '1'),

                    'hint'     => array(

                        'title'   => esc_attr__('Sticky Header Link Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set sticky header link color for this page.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'sticky_header_link_color_hover',

                    'type'     => 'color',

                    'output'   => array('.is-sticky  #dpr-header  #dpr-navigation-wrapper .dropdown-menu > li > a:hover,.is-sticky #dpr-adeline-mobile-menu-icon a:hover,.is-sticky #searchform-header-replace-close:hover'),

                    'validate' => 'color',

                    'title'    => esc_html__('Sticky Header Link Color: Hover', 'dpr-adeline-extensions'),

                    'required' => array('sticky_heder_enable', 'equals', '1'),

                    'hint'     => array(

                        'title'   => esc_attr__('Sticky Header Link Color: Hover', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set sticky header link hover color for this page.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'sticky_header_link_color_current',

                    'type'     => 'color',

                    'output'   => array('.is-sticky #dpr-navigation-wrapper .dropdown-menu > .current-menu-item > a,.is-sticky #dpr-navigation-wrapper .dropdown-menu > .current-menu-parent > a > span,.is-sticky #dpr-navigation-wrapper .dropdown-menu > .current-menu-item > a:hover,.is-sticky #dpr-navigation-wrapper .dropdown-menu > .current-menu-parent > a:hover > span'),

                    'validate' => 'color',

                    'title'    => esc_html__('Sticky Header Link Color: Current', 'dpr-adeline-extensions'),

                    'required' => array('sticky_heder_enable', 'equals', '1'),

                    'hint'     => array(

                        'title'   => esc_attr__('Sticky Header Link Color: Current', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set sticky header current link color for this page.', 'dpr-adeline-extensions'),

                    ),

                ),

            ),

        );

        $portfolio_post_metabox_sections[] = array(

            'title'      => esc_html__('Social Links', 'dpr-adeline-extensions'),

            'subtitle'   => esc_html__('', 'dpr-adeline-extensions'),

            'subsection' => true,

            'fields'     => array(

                array(

                    'id'    => 'menu_social_display',

                    'type'  => 'switch',

                    'title' => esc_html__('Display Social Links In Menu', 'dpr-adeline-extensions'),

                ),

                array(

                    'id'       => 'menu_social_content_type',

                    'type'     => 'radio',

                    'title'    => __('Menu Social Content Type', 'dpr-adeline-extensions'),

                    'options'  => array(

                        'default' => 'Default',

                        'html'    => 'HTML Content',

                        'custom'  => 'Custom Template',

                    ),

                    'required' => array('menu_social_display', 'equals', '1'),

                    'hint'     => array(

                        'title'   => esc_attr__('Menu Social Content Type', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('By default is used setting entered bellow but you can also use custom HTML content or template from Particles library. ', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'menu_social_html',

                    'type'     => 'textarea',

                    'title'    => __('HTML Content', 'dpr-adeline-extensions'),

                    'validate' => 'html',

                    'desc'     => __('<i><small>HTML is allowed.</small></i>'),

                    'hint'     => array(

                        'title'   => esc_attr__('HTML Content', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('You can enter menu social content here. HTML is allowed', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('menu_social_content_type', 'equals', 'html'),

                ),

                array(

                    'id'       => 'menu_social_particle_selected',

                    'type'     => 'select',

                    'data'     => 'posts',

                    'args'     => array('post_type' => array('dpr_particle'), 'posts_per_page' => -1),

                    'title'    => esc_html__('Custom Menu Social Template', 'dpr-adeline-extensions'),

                    'desc'     => __('Please note that you need first create custom content template in Particles menu'),

                    'hint'     => array(

                        'title'   => esc_attr__('Custom Menu Social Template', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Select previously prepared particle to display in menu social area. ', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('menu_social_content_type', 'equals', 'custom'),

                ),

                array(

                    'id'       => 'menu_social_style',

                    'type'     => 'image_select',

                    'title'    => __('Social Links Style', 'dpr-adeline-extensions'),

                    'options'  => array(

                        'minimal'  => array(

                            'title' => esc_html__('Minimal', 'dpr-adeline-extensions'),

                            'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/socials/minimal.jpg',

                        ),

                        'rounded'  => array(

                            'title' => esc_html__('Rounded', 'dpr-adeline-extensions'),

                            'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/socials/rounded.jpg',

                        ),

                        'outlined' => array(

                            'title' => esc_html__('Outlined', 'dpr-adeline-extensions'),

                            'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/socials/outlined.jpg',

                        ),

                        'colored'  => array(

                            'title' => esc_html__('Colored', 'dpr-adeline-extensions'),

                            'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/socials/colored.jpg',

                        ),

                    ),

                    'hint'     => array(

                        'title'   => esc_attr__('Social Links Style', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Choose social share icon style.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('menu_social_content_type', 'equals', 'default'),

                ),

                array(

                    'id'       => 'menu_social_target',

                    'type'     => 'select',

                    'title'    => esc_html__('Social Link Target', 'dpr-adeline-extensions'),

                    'desc'     => '',

                    'options'  => array(

                        'blank' => esc_html__('New window', 'dpr-adeline-extensions'),

                        'self'  => esc_html__('Same window', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('menu_social_content_type', 'equals', 'default'),

                ),

                array(

                    'id'       => 'menu_social_minimal_color',

                    'type'     => 'color',

                    'output'   => array('.dpr-adeline-social-menu ul li a, .sidr-class-social-menu-inner ul li a'),

                    'validate' => 'color',

                    'title'    => esc_html__('Social Icons Color: Minimal Style', 'dpr-adeline-extensions'),

                    'required' => array('menu_social_style', 'equals', 'minimal'),

                ),

                array(

                    'id'       => 'menu_social_rounded_color',

                    'type'     => 'color',

                    'output'   => array('background-color' => '.dpr-adeline-social-menu .rounded ul li a,.sidr-class-social-menu-inner.sidr-class-rounded ul li a'),

                    'validate' => 'color',

                    'title'    => esc_html__('Social Icons Background Rounded Style', 'dpr-adeline-extensions'),

                    'required' => array('menu_social_style', 'equals', 'rounded'),

                ),

                array(

                    'id'       => 'menu_social_rounded_color_hover',

                    'type'     => 'color',

                    'output'   => array('background-color' => '.dpr-adeline-social-menu .rounded ul li a:hover, .sidr-class-social-menu-inner.sidr-class-rounded ul li a:hover'),

                    'validate' => 'color',

                    'title'    => esc_html__('Social Icons Background Rounded Style: Hover', 'dpr-adeline-extensions'),

                    'required' => array('menu_social_style', 'equals', 'rounded'),

                ),

                array(

                    'id'       => 'menu_social_outlined_color',

                    'type'     => 'color',

                    'output'   => array(

                        'color'        => '.dpr-adeline-social-menu .outlined ul li a, .sidr-class-social-menu-inner.sidr-class-outlined ul li a',

                        'border-color' => '.dpr-adeline-social-menu .outlined ul li a, .sidr-class-social-menu-inner.sidr-class-outlined ul li a'),

                    'validate' => 'color',

                    'title'    => esc_html__('Social Icons Outlined Style Color', 'dpr-adeline-extensions'),

                    'required' => array('menu_social_style', 'equals', 'outlined'),

                ),

                array(

                    'id'             => 'menu_social_font_size',

                    'type'           => 'typography',

                    'title'          => esc_html__('Social Icons Font Size', 'dpr-adeline-extensions'),

                    'google'         => false,

                    'font-family'    => false,

                    'font-weight'    => false,

                    'font-style'     => false,

                    'subsets'        => false,

                    'font-size'      => true,

                    'text-align'     => false,

                    'line-height'    => false,

                    'word-spacing'   => false,

                    'letter-spacing' => false,

                    'text-transform' => false,

                    'color'          => false,

                    'preview'        => false,

                    'all_styles'     => false,

                    'units'          => 'px',

                    'output'         => array('.dpr-adeline-social-menu ul li a'),

                    'required'       => array('menu_social_content_type', 'equals', 'default'),

                ),

                array(

                    'id'             => 'menu_social_spacing',

                    'type'           => 'spacing',

                    'output'         => array('.dpr-adeline-social-menu ul li a'),

                    'mode'           => 'margin',

                    'top'            => false,

                    'bottom'         => false,

                    'units'          => array('px'),

                    'display_units'  => true,

                    'units_extended' => false,

                    'title'          => __('Social Icons Spacing (px)', 'dpr-adeline-extensions'),

                    'required'       => array('menu_social_content_type', 'equals', 'default'),

                ),

            ),

        );

        $portfolio_post_metabox_sections[] = array(

            'title'    => esc_html__('Subheader', 'dpr-adeline-extensions'),

            'subtitle' => esc_html__('', 'dpr-adeline-extensions'),

        );

        $portfolio_post_metabox_sections[] = array(

            'title'      => esc_html__('General', 'dpr-adeline-extensions'),

            'subtitle'   => esc_html__('', 'dpr-adeline-extensions'),

            'subsection' => true,

            'fields'     => array(

                array(

                    'id'    => 'subheader_display',

                    'type'  => 'switch',

                    'title' => esc_html__('Display Subheader', 'dpr-adeline-extensions'),

                    'hint'  => array(

                        'title'   => esc_attr__('Display Subheader', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Enable or disable display subheader area for this page.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'subheader_visibility',

                    'type'     => 'image_select',

                    'title'    => __('Visibility', 'dpr-adeline-extensions'),

                    'options'  => array(

                        'all-devices'        => array(

                            'title' => esc_html__('All Devices', 'dpr-adeline-extensions'),

                            'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/visibility/all.png',

                        ),

                        'hide-tablet'        => array(

                            'title' => esc_html__('Hide On Tablet', 'dpr-adeline-extensions'),

                            'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/visibility/no_tablet.png',

                        ),

                        'hide-mobile'        => array(

                            'title' => esc_html__('Hide On Mobile', 'dpr-adeline-extensions'),

                            'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/visibility/no_mobile.png',

                        ),

                        'hide-tablet-mobile' => array(

                            'title' => esc_html__('Hide On Tablet & Mobile', 'dpr-adeline-extensions'),

                            'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/visibility/no_tablet_mobile.png',

                        ),

                    ),

                    'hint'     => array(

                        'title'   => esc_attr__('Visibility', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Enable or disable display subheader area on certain devices  for this page.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('subheader_display', 'equals', '1'),

                ),

                array(

                    'id'       => 'subheader_title_tag',

                    'type'     => 'select',

                    'title'    => esc_html__('Title Tag', 'dpr-adeline-extensions'),

                    'desc'     => '',

                    'options'  => array(

                        'h1'   => esc_html__('H1', 'dpr-adeline-extensions'),

                        'h2'   => esc_html__('H2', 'dpr-adeline-extensions'),

                        'h3'   => esc_html__('H3', 'dpr-adeline-extensions'),

                        'h4'   => esc_html__('H4', 'dpr-adeline-extensions'),

                        'h5'   => esc_html__('H5', 'dpr-adeline-extensions'),

                        'h6'   => esc_html__('H6', 'dpr-adeline-extensions'),

                        'span' => esc_html__('span', 'dpr-adeline-extensions'),

                        'p'    => esc_html__('p', 'dpr-adeline-extensions'),

                        'div'  => esc_html__('div', 'dpr-adeline-extensions'),

                    ),

                    'hint'     => array(

                        'title'   => esc_attr__('Title Tag', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Default tiltle is closed in H1 tag but you can select other tag . This options can be useful for SEO adjustement ', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('subheader_display', 'equals', '1'),

                ),

                array(

                    'id'       => 'subheader_alignment',

                    'type'     => 'select',

                    'title'    => esc_html__('Alignment', 'dpr-adeline-extensions'),

                    'desc'     => '',

                    'options'  => array(

                        'lefted'   => esc_html__('Left', 'dpr-adeline-extensions'),

                        'centered' => esc_html__('Centered', 'dpr-adeline-extensions'),

                    ),

                    'hint'     => array(

                        'title'   => esc_attr__('Alignment', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set subheader content alignment  for this page.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('subheader_display', 'equals', '1'),

                ),

                array(

                    'id'       => 'subheader_height',

                    'type'     => 'dimensions',

                    'units'    => array('px'),

                    'mode'     => array('width' => 'width', 'height' => 'height'),

                    'width'    => false,

                    'output'   => array('.subheader'),

                    'title'    => __('Subheader Height', 'dpr-adeline-extensions'),

                    'hint'     => array(

                        'title'   => esc_attr__('Subheader Height', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set subheader height for this page.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('subheader_display', 'equals', '1'),

                ),

                array(

                    'id'             => 'subheader_padding',

                    'type'           => 'spacing',

                    'output'         => array('.subheader'),

                    'mode'           => 'padding',

                    'units'          => array('px', 'em'),

                    'left'           => false,

                    'right'          => false,

                    'display_units'  => true,

                    'units_extended' => false,

                    'title'          => __('Vertical Padding', 'dpr-adeline-extensions'),

                    'hint'           => array(

                        'title'   => esc_attr__('Vertical Padding', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Using padding you can adjust vertical position of title in subheader area', 'dpr-adeline-extensions'),

                    ),

                    'required'       => array('subheader_display', 'equals', '1'),

                ),

                array(

                    'id'       => 'use_featured_image_as_bg',

                    'type'     => 'switch',

                    'title'    => esc_html__('Use featured image as subheader background?', 'dpr-adeline-extensions'),

                    'hint'     => array(

                        'title'   => esc_attr__('Use featured image as subheader background?', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Enable usage featured image of this post as subheader background.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('subheader_display', 'equals', '1'),

                ),

                 array(

                    'id'       => 'use_custom_subheader_bg',

                    'type'     => 'switch',

                    'title'    => esc_html__('Use custom subheader background?', 'dpr-adeline-extensions'),

                    'hint'     => array(

                        'title'   => esc_attr__('Use custom subheader background?', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Enable usage subheader custom background for this item.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('use_featured_image_as_bg', 'not', '1'),

                ),                              

                array(

                    'id'       => 'custom_subheader_bg',

                    'type'     => 'background',

                    'title'    => __('Background', 'dpr-adeline-extensions'),

                    'output'   => array(''),

                    'hint'     => array(

                        'title'   => esc_attr__('Background', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set background for subheader area for this page', 'dpr-adeline-extensions'),

                    ),

                   'required' => array('use_custom_subheader_bg', 'equals', '1'),

                ),

                array(

                    'id'       => 'subheader_overlay',

                    'type'     => 'switch',

                    'title'    => esc_html__('Use Subheader Overlay', 'dpr-adeline-extensions'),

                    'hint'     => array(

                        'title'   => esc_attr__('Use Subheader Overlay', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Enable overlay layer over subheader background  for this page.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('subheader_display', 'equals', '1'),

                ),

                array(

                    'id'       => 'subheader_overlay_bg_color',

                    'type'     => 'color',

                    'title'    => __('Overlay Color', 'dpr-adeline-extensions'),

                    'output'   => array('background-color' => '.subheader-overlay'),

                    'hint'     => array(

                        'title'   => esc_attr__('Overlay Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set background color for subheader overlay for this page.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('subheader_overlay', 'equals', '1'),

                ),

                array(

                    'id'       => 'subheader_title_color',

                    'type'     => 'color',

                    'title'    => __('Title Color', 'dpr-adeline-extensions'),

                    'output'   => array('.subheader-title'),

                    'hint'     => array(

                        'title'   => esc_attr__('Title Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set title color for this page.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('subheader_display', 'equals', '1'),

                ),

                array(

                    'id'       => 'subtitle_color',

                    'type'     => 'color',

                    'title'    => __('Subtitle Color', 'dpr-adeline-extensions'),

                    'output'   => array('.subheader-subtitle'),

                    'hint'     => array(

                        'title'   => esc_attr__('Subtitle Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set subtitle color  for this page.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('subheader_display', 'equals', '1'),

                ),

                array(

                    'id'       => 'subheader_alternative_title',

                    'type'     => 'text',

                    'title'    => __('Subheader Alternative Title Text', 'dpr-adeline-extensions'),

                    'required' => array('subheader_display', 'equals', '1'),

                    'hint'     => array(

                        'title'   => esc_attr__('Alternative  Title', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set alternative title text to display in subheader instead post/page title.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'subheader_subtitle',

                    'type'     => 'text',

                    'title'    => __('Subheader Subtitle Text', 'dpr-adeline-extensions'),

                    'required' => array('subheader_display', 'equals', '1'),

                    'hint'     => array(

                        'title'   => esc_attr__('Subtitle', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set subtitle for this page.', 'dpr-adeline-extensions'),

                    ),

                ),

            ),

        );

        $portfolio_post_metabox_sections[] = array(

            'title'      => esc_html__('Breadcrumb', 'dpr-adeline-extensions'),

            'subtitle'   => esc_html__('', 'dpr-adeline-extensions'),

            'subsection' => true,

            'fields'     => array(

                array(

                    'id'    => 'breadcrumb_display',

                    'type'  => 'switch',

                    'title' => esc_html__('Display Breadcrumb', 'dpr-adeline-extensions'),

                    'hint'  => array(

                        'title'   => esc_attr__('Display Breadcrumb', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Enable or disable display breadcrumb in subheader area for this page.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'breadcrumbs_position',

                    'type'     => 'radio',

                    'title'    => __('Breadcrumb Position', 'dpr-adeline-extensions'),

                    'options'  => array(

                        'default'     => 'Right Bottom',

                        'under-title' => 'Under Title',

                    ),

                    'hint'     => array(

                        'title'   => esc_attr__('Breadcrumb Position', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set breadcrumb position for this page', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('breadcrumb_display', 'equals', '1'),

                ),

                array(

                    'id'       => 'breadcrumb_color',

                    'type'     => 'color',

                    'title'    => __('Breadcrumb Color', 'dpr-adeline-extensions'),

                    'output'   => array('.dpr-adeline-breadcrumbs'),

                    'hint'     => array(

                        'title'   => esc_attr__('Breadcrumb Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set breadcrumb color for this page.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('breadcrumb_display', 'equals', '1'),

                ),

                array(

                    'id'       => 'breadcrumb_separator_color',

                    'type'     => 'color',

                    'title'    => __('Breadcrumb Separators Color', 'dpr-adeline-extensions'),

                    'output'   => array('.dpr-adeline-breadcrumbs ul li:after'),

                    'hint'     => array(

                        'title'   => esc_attr__('Breadcrumb Separators Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set breadcrumb separators color for this page.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('breadcrumb_display', 'equals', '1'),

                ),

                array(

                    'id'       => 'breadcrumb_link_color',

                    'type'     => 'color',

                    'title'    => __('Breadcrumb Links Color', 'dpr-adeline-extensions'),

                    'output'   => array('.dpr-adeline-breadcrumbs a'),

                    'hint'     => array(

                        'title'   => esc_attr__('Breadcrumb Links Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set breadcrumb links color for this page.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('breadcrumb_display', 'equals', '1'),

                ),

                array(

                    'id'       => 'breadcrumb_link_color_hover',

                    'type'     => 'color',

                    'title'    => __('Breadcrumb Links Color: Hover', 'dpr-adeline-extensions'),

                    'output'   => array('.dpr-adeline-breadcrumbs a:hover'),

                    'hint'     => array(

                        'title'   => esc_attr__('Breadcrumb Links Color: Hover', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set breadcrumb hover links color for this page.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('breadcrumb_display', 'equals', '1'),

                ),

            ),

        );

        $portfolio_post_metabox_sections[] = array(

            'title'    => esc_html__('Sidebar', 'dpr-adeline-extensions'),

            'subtitle' => esc_html__('', 'dpr-adeline-extensions'),

            'fields'   => array(

                array(

                    'id'    => 'custom_right_sidebar',

                    'title' => esc_html__('Custom Right Sidebar', 'dpr-adeline-extensions'),

                    'desc'  => wp_kses_post(__('<small><em>Please select the sidebar you would like to display as right sidebar on this page.</em></small>', 'dpr-adeline-extensions')),

                    'type'  => 'select',

                    'data'  => 'sidebars',

                    'hint'  => array(

                        'title'   => esc_attr__('Custom Right Sidebar', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Please select the sidebar you would like to display as right sidebar on this page. Note: You must first create the sidebar under Appearance > Widgets. If you leave thus field blank will be used default right sidebar.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'    => 'custom_left_sidebar',

                    'title' => esc_html__('Custom Left Sidebar', 'dpr-adeline-extensions'),

                    'desc'  => wp_kses_post(__('<small><em>Please select the sidebar you would like to display as left sidebar on this page.</em></small>', 'dpr-adeline-extensions')),

                    'type'  => 'select',

                    'data'  => 'sidebars',

                    'hint'  => array(

                        'title'   => esc_attr__('Custom Left Sidebar', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Please select the sidebar you would like to display as left sidebar on this page. Note: You must first create the sidebar under Appearance > Widgets. If you leave thus field blank will be used default left sidebar.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'sidebar_bg_color',

                    'type'     => 'color',

                    'output'   => array('background-color' => '.widget-area'),

                    'validate' => 'color',

                    'title'    => esc_html__('Background Color', 'dpr-adeline-extensions'),

                    'hint'     => array(

                        'title'   => esc_attr__('Background Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set background color for sidebar on this page.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'             => 'sidebar_padding',

                    'type'           => 'spacing',

                    'output'         => array('.widget-area'),

                    'mode'           => 'padding',

                    'units'          => array('px'),

                    'display_units'  => true,

                    'units_extended' => false,

                    'title'          => __('Sidebar Padding (px)', 'dpr-adeline-extensions'),

                    'hint'           => array(

                        'title'   => esc_attr__('Sidebar Padding', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Choose default padding for sidebar.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'widgets_info',

                    'type'     => 'info',

                    'style'    => 'dpr-title',

                    'required' => array('menu_cart_style', 'equals', 'drop_down'),

                    'title'    => wp_kses_post(__('<h3>Widgets</h3>', 'dpr-adeline-extensions')),

                ),

                array(

                    'id'       => 'widgets_bg_color',

                    'type'     => 'color',

                    'output'   => array('background-color' => '.widget-area .sidebar-box'),

                    'validate' => 'color',

                    'title'    => esc_html__('Background Color', 'dpr-adeline-extensions'),

                    'hint'     => array(

                        'title'   => esc_attr__('Background Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set background color for sidebar widgets on this page.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'             => 'widgets_padding',

                    'type'           => 'spacing',

                    'output'         => array('.widget-area .sidebar-box'),

                    'mode'           => 'padding',

                    'units'          => array('px'),

                    'display_units'  => true,

                    'units_extended' => false,

                    'title'          => __('Widgets Padding (px)', 'dpr-adeline-extensions'),

                    'hint'           => array(

                        'title'   => esc_attr__('Widgets Padding', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set padding for sidebar widgets on this page.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'             => 'widgets_bottom_margin',

                    'type'           => 'spacing',

                    'output'         => array('.widget-area .sidebar-box'),

                    'mode'           => 'margin',

                    'units'          => array('px'),

                    'display_units'  => true,

                    'units_extended' => false,

                    'top'            => false,

                    'left'           => false,

                    'right'          => false,

                    'title'          => __('Widgets Bottom Margin (px)', 'dpr-adeline-extensions'),

                    'hint'           => array(

                        'title'   => esc_attr__('Widgets Bottom Margin', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set bottom margin for sidebar widgets on this page.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'      => 'widgets_title_decoration_style',

                    'type'    => 'radio',

                    'title'   => __('Widgets Title Decoration Style', 'dpr-adeline-extensions'),

                    'options' => array(

                        'none'       => 'None',

                        'bordered'   => 'Left Border',

                        'underlined' => 'Underline',

                    ),

                    'hint'    => array(

                        'title'   => esc_attr__('Widgets Title Decoration Style', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set widgets title decoration style on this page. ', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'widgets_title_border_color',

                    'type'     => 'color',

                    'output'   => array('border-color' => '.widget-title-decoration-bordered .widget-title'),

                    'validate' => 'color',

                    'title'    => esc_html__('Border Color', 'dpr-adeline-extensions'),

                    'hint'     => array(

                        'title'   => esc_attr__('Border Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set border color for sidebar widgets title  on this page.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('widgets_title_decoration_style', 'equals', 'bordered'),

                ),

                array(

                    'id'       => 'widgets_title_border_width',

                    'type'     => 'dimensions',

                    'title'    => esc_html__('Border Width (px)', 'dpr-adeline-extensions'),

                    'width'    => true,

                    'height'   => false,

                    'mode'     => array('width' => 'width', 'height' => 'height'),

                    'units'    => array('px'),

                    'hint'     => array(

                        'title'   => esc_attr__('Border Width', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set border width for sidebar widgets title on this page.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('widgets_title_decoration_style', 'equals', 'bordered'),

                ),

                array(

                    'id'       => 'widgets_title_underline_color',

                    'type'     => 'color',

                    'output'   => array('border-color' => '.widget-title-decoration-underlined .widget-title:after'),

                    'validate' => 'color',

                    'title'    => esc_html__('Underline Color', 'dpr-adeline-extensions'),

                    'hint'     => array(

                        'title'   => esc_attr__('Underline Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set underline color for sidebar widgets title  on this page.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('widgets_title_decoration_style', 'equals', 'underlined'),

                ),

                array(

                    'id'       => 'widgets_title_background_underline_color',

                    'type'     => 'color',

                    'output'   => array('border-color' => '.widget-title-decoration-underlined .widget-title:before'),

                    'validate' => 'color',

                    'title'    => esc_html__('Background Underline Color', 'dpr-adeline-extensions'),

                    'hint'     => array(

                        'title'   => esc_attr__('Background Underline Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set background underline color for sidebar widgets title  on this page.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('widgets_title_decoration_style', 'equals', 'underlined'),

                ),

                array(

                    'id'       => 'widgets_title_underline_thikness',

                    'type'     => 'dimensions',

                    'title'    => esc_html__('Underline Thickness (px)', 'dpr-adeline-extensions'),

                    'width'    => false,

                    'height'   => true,

                    'mode'     => array('width' => 'width', 'height' => 'height'),

                    'units'    => array('px'),

                    'hint'     => array(

                        'title'   => esc_attr__('Underline Thickness', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set underline thickness for sidebar widgets title on this page.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('widgets_title_decoration_style', 'equals', 'underlined'),

                ),

                array(

                    'id'             => 'widgets_titles_bottom_margin',

                    'type'           => 'spacing',

                    'output'         => array('.widget-title'),

                    'mode'           => 'margin',

                    'units'          => array('px'),

                    'display_units'  => true,

                    'units_extended' => false,

                    'top'            => false,

                    'left'           => false,

                    'right'          => false,

                    'title'          => __('Widgets Title Bottom Margin (px)', 'dpr-adeline-extensions'),

                    'hint'           => array(

                        'title'   => esc_attr__('Widgets Title Bottom Margin', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Choose bottom margin for sidebar widgets titles on this page.', 'dpr-adeline-extensions'),

                    ),

                ),

            ),

        );

        $portfolio_post_metabox_sections[] = array(

            'title'    => esc_html__('Footer', 'dpr-adeline-extensions'),

            'subtitle' => esc_html__('', 'dpr-adeline-extensions'),

        );

        $portfolio_post_metabox_sections[] = array(

            'title'      => esc_html__('Widgets Area', 'dpr-adeline-extensions'),

            'subtitle'   => esc_html__('', 'dpr-adeline-extensions'),

            'subsection' => true,

            'fields'     => array(

                array(

                    'id'      => 'footer_content',

                    'type'    => 'radio',

                    'title'   => __('Footer Content', 'dpr-adeline-extensions'),

                    'options' => array(

                        'widgets'  => 'Footer Widgets',

                        'custom'   => 'Custom Template',

                        'disabled' => 'Disable Footer',

                    ),

                    'hint'    => array(

                        'title'   => esc_attr__('Footer Content', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('You can use widgets from footer widgets areas  or select custom footer template created in menu Particles on this page.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'footer_visibility',

                    'type'     => 'image_select',

                    'title'    => __('Visibility', 'dpr-adeline-extensions'),

                    'options'  => array(

                        'all-devices'        => array(

                            'title' => esc_html__('All Devices', 'dpr-adeline-extensions'),

                            'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/visibility/all.png',

                        ),

                        'hide-tablet'        => array(

                            'title' => esc_html__('Hide On Tablet', 'dpr-adeline-extensions'),

                            'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/visibility/no_tablet.png',

                        ),

                        'hide-mobile'        => array(

                            'title' => esc_html__('Hide On Mobile', 'dpr-adeline-extensions'),

                            'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/visibility/no_mobile.png',

                        ),

                        'hide-tablet-mobile' => array(

                            'title' => esc_html__('Hide On Tablet & Mobile', 'dpr-adeline-extensions'),

                            'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/visibility/no_tablet_mobile.png',

                        ),

                    ),

                    'hint'     => array(

                        'title'   => esc_attr__('Visibility', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Enable or disable display footer area on certain devices on this page.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('footer_content', 'not', 'disabled'),

                ),

                array(

                    'id'       => 'footer_paralax',

                    'type'     => 'switch',

                    'title'    => esc_html__('Footer Parallax Effect', 'dpr-adeline-extensions'),

                    'required' => array('footer_content', 'not', 'disabled'),

                    'hint'     => array(

                        'title'   => esc_attr__('Footer Parallax Effect', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Enable or disable footer parallax effect on this page', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'footer_fix_at_bottom',

                    'type'     => 'switch',

                    'title'    => esc_html__('Footer Allways Bottom', 'dpr-adeline-extensions'),

                    'required' => array('footer_content', 'not', 'disabled'),

                    'hint'     => array(

                        'title'   => esc_attr__('Footer Allways Bottom', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Enabling this option fix footer on boottom even when page height is lower then screen height  on this page.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'force_full_width_footer',

                    'type'     => 'switch',

                    'title'    => esc_html__('Force Full Width Footer', 'dpr-adeline-extensions'),

                    'required' => array('footer_content', 'not', 'disabled'),

                    'hint'     => array(

                        'title'   => esc_attr__('Force Full Width Footer', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Force full width footer container on this page .', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'footer_particle_selected',

                    'type'     => 'select',

                    'data'     => 'posts',

                    'args'     => array('post_type' => array('dpr_particle'), 'posts_per_page' => -1),

                    'title'    => esc_html__('Custom Footer Template', 'dpr-adeline-extensions'),

                    'desc'     => __('Please note that you need first create custom template in Particles menu'),

                    'hint'     => array(

                        'title'   => esc_attr__('Footer Template', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Create custom footer template first.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('footer_content', 'equals', 'custom'),

                ),

                array(

                    'id'       => 'footer_columns',

                    'type'     => 'radio',

                    'title'    => __('Footer Columns Count', 'dpr-adeline-extensions'),

                    'required' => array('footer_content', 'equals', 'widgets'),

                    'options'  => array(

                        '1' => '1 Column',

                        '2' => '2 Columns',

                        '3' => '3 Columns',

                        '4' => '4 Columns',

                    ),

                    'hint'     => array(

                        'title'   => esc_attr__('Footer Columns Count', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set columns count in footer on this page. ', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'footer_tablet_columns',

                    'type'     => 'radio',

                    'title'    => __('Footer Columns Count: Tablet', 'dpr-adeline-extensions'),

                    'required' => array('footer_content', 'equals', 'widgets'),

                    'options'  => array(

                        ''  => 'Inherit',

                        '1' => '1 Column',

                        '2' => '2 Columns',

                        '3' => '3 Columns',

                        '4' => '4 Columns',

                    ),

                    'hint'     => array(

                        'title'   => esc_attr__('Footer Columns Count: Tablet', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set columns count in footer for tablet devices on this page. ', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'footer_mobile_columns',

                    'type'     => 'radio',

                    'title'    => __('Footer Columns Count: Mobile', 'dpr-adeline-extensions'),

                    'required' => array('footer_content', 'equals', 'widgets'),

                    'options'  => array(

                        ''  => 'Inherit',

                        '1' => '1 Column',

                        '2' => '2 Columns',

                        '3' => '3 Columns',

                        '4' => '4 Columns',

                    ),

                    'hint'     => array(

                        'title'   => esc_attr__('Footer Columns Count: Mobile', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set columns count in footer for mobilet devices on this page. ', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'             => 'footer_padding',

                    'type'           => 'spacing',

                    'output'         => array('#footer-widgets'),

                    'mode'           => 'padding',

                    'units'          => array('px'),

                    'display_units'  => true,

                    'units_extended' => false,

                    'title'          => __('Footer Padding (px)', 'dpr-adeline-extensions'),

                    'hint'           => array(

                        'title'   => esc_attr__('Footer Padding', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Choose padding for footer on this page.', 'dpr-adeline-extensions'),

                    ),

                    'required'       => array('footer_content', 'equals', 'widgets'),

                ),

                 array(

                    'id'       => 'use_custom_footer_bg',

                    'type'     => 'switch',

                    'title'    => esc_html__('Use custom footer background?', 'dpr-adeline-extensions'),

                    'hint'     => array(

                        'title'   => esc_attr__('Use custom footer background?', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Enable usage custom footer background for this item.', 'dpr-adeline-extensions'),

                    )

                ),                              

                array(

                    'id'       => 'custom_footer_bg',

                    'type'     => 'background',

                    'title'    => __('Background', 'dpr-adeline-extensions'),

                    'output'   => array(''),

                    'hint'     => array(

                        'title'   => esc_attr__('Background', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set background for subheader area for this page', 'dpr-adeline-extensions'),

                    ),

                   'required' => array('use_custom_footer_bg', 'equals', '1'),

                ),               

                array(

                    'id'       => 'footer_overlay_color',

                    'type'     => 'color',

                    'output'   => array('background-color' => '#footer-inner'),

                    'validate' => 'color',

                    'title'    => esc_html__('Footer Overlay Color', 'dpr-adeline-extensions'),

                    'required' => array('footer_content', 'not', 'disabled'),

                    'hint'     => array(

                        'title'   => esc_attr__('Footer Overlay Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set footer overlay color  on this page.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'footer_widgets_titles_color',

                    'type'     => 'color',

                    'output'   => array('color' => '#footer-widgets .footer-box .widget-title'),

                    'validate' => 'color',

                    'title'    => esc_html__('Widget Titles Color', 'dpr-adeline-extensions'),

                    'required' => array('footer_content', 'equals', 'widgets'),

                    'hint'     => array(

                        'title'   => esc_attr__('Widget Titles Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set widget titles color for footer on this page.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'footer_text_color',

                    'type'     => 'color',

                    'output'   => array('color' => '#footer-widgets,#footer-widgets p,#footer-widgets li a:before,#footer-widgets .contact-info-widget span.dpr-adeline-contact-title,#footer-widgets .recent-posts-date,#footer-widgets .recent-posts-comments,#footer-widgets .widget-recent-posts-icons li i'),

                    'validate' => 'color',

                    'title'    => esc_html__('Footer Text Color', 'dpr-adeline-extensions'),

                    'required' => array('footer_content', 'equals', 'widgets'),

                    'hint'     => array(

                        'title'   => esc_attr__('Footer Text Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set footer text color on this page.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'footer_borders_color',

                    'type'     => 'color',

                    'output'   => array('border-color' => '#footer-widgets li,#footer-widgets #wp-calendar caption,#footer-widgets #wp-calendar th,#footer-widgets table td, #footer-widgets #wp-calendar tbody,#footer-widgets .contact-info-widget i,#footer-widgets .dpr-adeline-newsletter-form-wrap input[type="email"],#footer-widgets .posts-thumbnails-widget li,#footer-widgets .social-widget li a'),

                    'validate' => 'color',

                    'title'    => esc_html__('Footer Borders Color', 'dpr-adeline-extensions'),

                    'required' => array('footer_content', 'equals', 'widgets'),

                    'hint'     => array(

                        'title'   => esc_attr__('Footer Borders Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set footer borders color on this page.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'footer_links_color',

                    'type'     => 'color',

                    'output'   => array('color' => '#footer-widgets .footer-box a,#footer-widgets a'),

                    'validate' => 'color',

                    'title'    => esc_html__('Footer Links Color', 'dpr-adeline-extensions'),

                    'required' => array('footer_content', 'equals', 'widgets'),

                    'hint'     => array(

                        'title'   => esc_attr__('Footer Links Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set footer links color on this page.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'footer_links_color_hover',

                    'type'     => 'color',

                    'output'   => array('color' => '#footer-widgets .footer-box a:hover,#footer-widgets a:hover'),

                    'validate' => 'color',

                    'title'    => esc_html__('Footer Links Color: Hover', 'dpr-adeline-extensions'),

                    'required' => array('footer_content', 'equals', 'widgets'),

                    'hint'     => array(

                        'title'   => esc_attr__('Footer Links Color: Hover', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set footer links hover color on this page.', 'dpr-adeline-extensions'),

                    ),

                ),

            ),

        );

        $portfolio_post_metabox_sections[] = array(

            'title'      => esc_html__('Copyright Area', 'dpr-adeline-extensions'),

            'subtitle'   => esc_html__('', 'dpr-adeline-extensions'),

            'subsection' => true,

            'fields'     => array(

                array(

                    'id'    => 'copyright_enable',

                    'type'  => 'switch',

                    'title' => esc_html__('Enable Copyright Area', 'dpr-adeline-extensions'),

                    'hint'  => array(

                        'title'   => esc_attr__('Enable Footer', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Enable or disable display of footer on this page.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'           => 'copyright_text',

                    'type'         => 'textarea',

                    'title'        => __('Copyright Text', 'dpr-adeline-extensions'),

                    'validate'     => 'html_custom',

                    'allowed_html' => array(

                        'a'      => array(

                            'href'  => array(),

                            'title' => array(),

                        ),

                        'br'     => array(),

                        'em'     => array(),

                        'strong' => array(),

                    ),

                    'hint'         => array(

                        'title'   => esc_attr__('Copyright Text', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('You can set copyright text on this page. Custom HTML is allowed', 'dpr-adeline-extensions'),

                    ),

                    'required'     => array('copyright_enable', 'equals', '1'),

                ),

                array(

                    'id'       => 'copyright_visibility',

                    'type'     => 'image_select',

                    'title'    => __('Visibility', 'dpr-adeline-extensions'),

                    'options'  => array(

                        'all-devices'        => array(

                            'title' => esc_html__('All Devices', 'dpr-adeline-extensions'),

                            'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/visibility/all.png',

                        ),

                        'hide-tablet'        => array(

                            'title' => esc_html__('Hide On Tablet', 'dpr-adeline-extensions'),

                            'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/visibility/no_tablet.png',

                        ),

                        'hide-mobile'        => array(

                            'title' => esc_html__('Hide On Mobile', 'dpr-adeline-extensions'),

                            'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/visibility/no_mobile.png',

                        ),

                        'hide-tablet-mobile' => array(

                            'title' => esc_html__('Hide On Tablet & Mobile', 'dpr-adeline-extensions'),

                            'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/visibility/no_tablet_mobile.png',

                        ),

                    ),

                    'hint'     => array(

                        'title'   => esc_attr__('Visibility', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Enable or disable display copyright area on certain devices on this page.', 'dpr-adeline-extensions'),

                    ),

                    'required' => array('copyright_enable', 'equals', '1'),

                ),

                array(

                    'id'       => 'force_full_width_copyright',

                    'type'     => 'switch',

                    'title'    => esc_html__('Force Full Copyright Area', 'dpr-adeline-extensions'),

                    'required' => array('copyright_enable', 'equals', '1'),

                    'hint'     => array(

                        'title'   => esc_attr__('Force Full Copyright Area', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Force full width copright area on this page.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'             => 'copyright_padding',

                    'type'           => 'spacing',

                    'output'         => array('#copyright-area'),

                    'mode'           => 'padding',

                    'units'          => array('px'),

                    'display_units'  => true,

                    'units_extended' => false,

                    'title'          => __('Padding (px)', 'dpr-adeline-extensions'),

                    'hint'           => array(

                        'title'   => esc_attr__('Padding', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Choose padding for copyright area on this page.', 'dpr-adeline-extensions'),

                    ),

                    'required'       => array('copyright_enable', 'equals', '1'),

                ),

                array(

                    'id'       => 'copyright_area_bg',

                    'type'     => 'color',

                    'output'   => array('background-color' => '#copyright-area'),

                    'validate' => 'color',

                    'title'    => esc_html__('Background Color', 'dpr-adeline-extensions'),

                    'required' => array('copyright_enable', 'equals', '1'),

                    'hint'     => array(

                        'title'   => esc_attr__('Background Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set background color for copyright area on this page.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'copyright_text_color',

                    'type'     => 'color',

                    'output'   => array('color' => '#copyright-area,#copyright-area p'),

                    'validate' => 'color',

                    'title'    => esc_html__('Text Color', 'dpr-adeline-extensions'),

                    'required' => array('copyright_enable', 'equals', '1'),

                    'hint'     => array(

                        'title'   => esc_attr__('Text Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set copyright area text color on this page.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'copyright_links_color',

                    'type'     => 'color',

                    'output'   => array('color' => '#copyright-area a,#copyright-area #copyright-area-menu a'),

                    'validate' => 'color',

                    'title'    => esc_html__('Links Color', 'dpr-adeline-extensions'),

                    'required' => array('copyright_enable', 'equals', '1'),

                    'hint'     => array(

                        'title'   => esc_attr__('Links Color', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set copyright area links color on this page.', 'dpr-adeline-extensions'),

                    ),

                ),

                array(

                    'id'       => 'copyright_links_color_hover',

                    'type'     => 'color',

                    'output'   => array('color' => '#copyright-area a:hover,#copyright-area #copyright-area-menu a:hover'),

                    'validate' => 'color',

                    'title'    => esc_html__('Links Color: Hover', 'dpr-adeline-extensions'),

                    'required' => array('copyright_enable', 'equals', '1'),

                    'hint'     => array(

                        'title'   => esc_attr__('Links Color: Hover', 'dpr-adeline-extensions'),

                        'content' => esc_attr__('Set copyright area links hover color on this page.', 'dpr-adeline-extensions'),

                    ),

                ),

            ),

        );

        return $portfolio_post_metabox_sections;

    }

endif;
