<?php

if ( ! defined( 'ABSPATH' ) ) { exit; }



class WPBakeryShortCode_DPR_Interactive_Links extends WPBakeryShortCode {}



vc_map(

	array(

		'name'					=> esc_html__('DP Interactive Links', 'dpr-adeline-extensions'),

		'base'					=> 'dpr_interactive_links',

		'class'					=> '',

		'icon'					=> 'icon-dpr-interactive-links',

  		"category" =>array( esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions')),

		"description" => esc_attr__('Interactive links block animated on hover', 'dpr-adeline-extensions'),

		'params'				=> array(

	
			array(

				'heading'			=> esc_html__('Style', 'dpr-adeline-extensions'),

				'type'				=> 'dpr_image_select',

				'param_name'		=> 'style',

				'simple_mode'		=> false,

				'options'			=> array(

					'bg-image'			=> array(

						'label'			=> esc_html__('Background Image', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'interactive-links/background-image.png'

					),

					'aside-image'			=> array(

						'label'			=> esc_html__('Aside Image', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'interactive-links/aside-image.png'

					),

					'satelite-image'			=> array(

						'label'			=> esc_html__('Satelite Image', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'interactive-links/satelite-image.png'

					)

				),

			),
	
			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select cource for interactive links list.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Links Source', 'dpr-adeline-extensions'),

				'param_name'		=> 'source_type',

				'value'				=> 'custom',

				'options'			=> array(

					esc_html__('Custom Links', 'dpr-adeline-extensions')	=> 'custom',
	
					esc_html__('Blog Items', 'dpr-adeline-extensions')	=> 'blog',

					esc_html__('Portfolio Items', 'dpr-adeline-extensions')	=> 'portfolio',



				)

			),	

			array(

				'type'				=> 'param_group',

				'heading'			=> esc_html__('Custom Link List', 'dpr-adeline-extensions'),

				'param_name'		=> 'custom_list',

				'value'				=> '',
				
				'dependency'		=> array('element' => 'source_type', 'value' => array('custom')),

				'params'			=> array(

					array(

						'type'			=> 'attach_image',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Upload the custom image from media library.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Link Image', 'dpr-adeline-extensions'),

						'param_name'	=> 'image_id',

						'edit_field_class' => 'vc_column vc_col-sm-12',

					),


					array(

						'type'			=> 'textfield',

						'heading' 		=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom link title', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Link Title', 'dpr-adeline-extensions'),

						'param_name'	=> 'link_title'
					), 

					array(

						'type'			=> 'textfield',

						'heading' 		=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom link subtitle', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Link Subtitle', 'dpr-adeline-extensions'),

						'param_name'	=> 'link_subtitle'
					), 

					array(

						'type'			=> 'vc_link',

						'heading' 		=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Add link to this item.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Link URL', 'dpr-adeline-extensions'),

						'param_name'	=> 'link',

						'edit_field_class'	=> 'vc_col-sm-12 vc_column'

					)

				)

			),
			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select link target', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Links Target?', 'dpr-adeline-extensions'),

				'param_name'		=> 'link_target',
				
				'edit_field_class'	=> 'vc_col-sm-6 vc_column',

				'value'				=> '_self',
				
				'dependency' => array('element' => 'source_type', 'value' => array('blog','portfolio')),

				'options'			=> array(

					esc_html__('The Same Window', 'dpr-adeline-extensions')	=> '_self',

					esc_html__('New Window', 'dpr-adeline-extensions')	=> '_blank'

				)

			),	

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable display post date in link', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Display Post Date', 'dpr-adeline-extensions'),

				'param_name'		=> 'display_date',
				
				'dependency' => array('element' => 'source_type', 'value' => array('blog')),

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				)

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable display category in link', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Display Categories', 'dpr-adeline-extensions'),

				'param_name'		=> 'display_category',
				'dependency' => array('element' => 'source_type', 'value' => array('blog','portfolio')),

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				)

			),

			array(

				'type'				=> 'param_group',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Add blog items to display.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('List of post items', 'dpr-adeline-extensions'),

				'param_name'		=> 'blog_list',

				'params'			=> array(

					array(

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose post item.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Post Item', 'dpr-adeline-extensions'),

						'type'				=> 'dpr_image_post_select',

						'param_name'		=> 'post_item',

						'admin_label' => true,

						'value' 			=> '',

						'edit_field_class' => 'vc_column vc_col-sm-12',

						'post_type' => 'post'

					),
					array(

						'type'			=> 'textfield',

						'heading' 		=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom link title.I you leave it blank will be used original post title', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Link Title', 'dpr-adeline-extensions'),

						'param_name'	=> 'link_title'
					), 

					array(

						'type'			=> 'textfield',

						'heading' 		=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom link subtitle', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Link Subtitle', 'dpr-adeline-extensions'),

						'param_name'	=> 'link_subtitle'
					)
				),

				'dependency' => array('element' => 'source_type', 'value' => array('blog')),

			),

	
			array(

				'type'				=> 'param_group',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Add portfolio items to display.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('List of portfolio items', 'dpr-adeline-extensions'),

				'param_name'		=> 'portfolio_list',

				'params'			=> array(

					array(

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose portfolio item.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Portfolio Item', 'dpr-adeline-extensions'),

						'type'				=> 'dpr_image_post_select',

						'param_name'		=> 'portfolio_item',

						'admin_label' => true,

						'value' 			=> '',

						'edit_field_class' => 'vc_column vc_col-sm-12',

						'post_type' => 'dpr_portfolio'

					),
					array(

						'type'			=> 'textfield',

						'heading' 		=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom link title.I you leave it blank will be used original post title', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Link Title', 'dpr-adeline-extensions'),

						'param_name'	=> 'link_title'
					), 

					array(

						'type'			=> 'textfield',

						'heading' 		=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom link subtitle', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Link Subtitle', 'dpr-adeline-extensions'),

						'param_name'	=> 'link_subtitle'
					)

				),

				'dependency' => array('element' => 'source_type', 'value' => array('portfolio')),

			),	
	
			array(

			'type'             => 'dpr_title',

			'text'             => esc_html__( 'Additional Settings', 'dpr-adeline-extensions' ),

			'param_name'       => 'extra_features_title',

			'edit_field_class' => 'vc_column vc_col-sm-12',

		),
	
			array(

			'type' => 'textfield',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Extra Class Name', 'dpr-adeline-extensions'),

			'param_name' => 'el_class',

			),
	
			array(

				'heading'			=> esc_html__('Links Position', 'dpr-adeline-extensions'),

				'type'				=> 'dpr_image_select',

				'param_name'		=> 'links_pos',

				'simple_mode'		=> false,

				'group' => __( 'Links Style', 'dpr-adeline-extensions' ),
	
				'dependency' => array('element' => 'style', 'value' => array('bg-image')),	

				'options'			=> array(

					'vertical-left'			=> array(

						'label'			=> esc_html__('Vertical Left', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'interactive-links/links-vertical-left.png'

					),

					'vertical-center'			=> array(

						'label'			=> esc_html__('Vertical Center', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'interactive-links/links-vertical-center.png'

					),

					'vertical-right'			=> array(

						'label'			=> esc_html__('Vertical Right', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'interactive-links/links-vertical-right.png'

					),

					'horizontal-center'			=> array(

						'label'			=> esc_html__('Horiz. Center', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'interactive-links/links-horizontal-center.png'

					),
					'horizontal-bottom'			=> array(

						'label'			=> esc_html__('Horiz. Bottom', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'interactive-links/links-horizontal-bottom.png'

					),
					'horizontal-vertical'			=> array(

						'label'			=> esc_html__('Horiz. Reoriented', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'interactive-links/links-horizontal-bottom-1.png'

					)
	

				),

			),

					array(

						'type'			=> 'textfield',

						'heading' 		=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('You can add additional left margin. Enter CSS aceptable value eg 100px, 10%, 10vw etc', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Link Left Margin', 'dpr-adeline-extensions'),

						'param_name'	=> 'links_left_margin',

						'group' => __( 'Links Style', 'dpr-adeline-extensions' ),

						'edit_field_class'	=> 'vc_column vc_col-sm-6 ',
					
						'dependency' => array('element' => 'links_pos', 'value' => array('horizontal-vertical')),
				),


			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable link subtitle hover animation', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Animate Link Subtitle', 'dpr-adeline-extensions'),

				'param_name'		=> 'animate_subtitle',

				'group' => __( 'Links Style', 'dpr-adeline-extensions' ),
				
				'dependency' => array('element' => 'links_pos', 'value' => array('horizontal-vertical')),

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				)

			),


			array(

				'heading'			=> esc_html__('Links Position', 'dpr-adeline-extensions'),

				'type'				=> 'dpr_image_select',

				'param_name'		=> 'links_pos_aside',

				'simple_mode'		=> false,
	
				'dependency' => array('element' => 'style', 'value' => array('aside-image')),	

				'group' => __( 'Links Style', 'dpr-adeline-extensions' ),

				'options'			=> array(
	
					'vertical-left'			=> array(

						'label'			=> esc_html__('Vertical Left', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'interactive-links/links-vertical-left.png'

					),

					'vertical-right'			=> array(

						'label'			=> esc_html__('Vertical Right', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'interactive-links/links-vertical-right.png'

					)
	

				),

			),

			array(

				'heading'			=> esc_html__('Links Position', 'dpr-adeline-extensions'),

				'type'				=> 'dpr_image_select',

				'param_name'		=> 'links_pos_satelite',

				'simple_mode'		=> false,

				'group' => __( 'Links Style', 'dpr-adeline-extensions' ),
	
				'dependency' => array('element' => 'style', 'value' => array('satelite-image')),	

				'options'			=> array(

					'vertical-left'			=> array(

						'label'			=> esc_html__('Vertical Left', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'interactive-links/links-vertical-left.png'

					),

					'vertical-center'			=> array(

						'label'			=> esc_html__('Vertical Center', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'interactive-links/links-vertical-center.png'

					),
	
					'vertical-right'			=> array(

						'label'			=> esc_html__('Vertical Right', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'interactive-links/links-vertical-right.png'

					),

	
				),

			),



			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select horizontal links alignment.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Links Alignment', 'dpr-adeline-extensions'),

				'param_name'		=> 'links_alignment',
				
				'group' => __( 'Links Style', 'dpr-adeline-extensions' ),

				'value'				=> 'left',

				'options'			=> array(

					esc_html__('Left', 'dpr-adeline-extensions')	=> 'left-aligned',
	
					esc_html__('Center', 'dpr-adeline-extensions')	=> 'center-aligned',
	
					esc_html__('Right', 'dpr-adeline-extensions')	=> 'right-aligned',
				),
				
				'dependency'		=> array('element' => 'links_pos', 'value' => array('horizontal-center','horizontal-bottom')),

			),		
	

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select subtitle position above or bellow title.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Subtitle Positon', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_pos',
				
				'group' => __( 'Links Style', 'dpr-adeline-extensions' ),

				'value'				=> 'bellow',

				'options'			=> array(

					esc_html__('Bellow Title', 'dpr-adeline-extensions')	=> 'bellow',
	
					esc_html__('Above Title', 'dpr-adeline-extensions')	=> 'above'

				)

			),		
			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Title Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'typo_title_1',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group' => __( 'Links Style', 'dpr-adeline-extensions' ),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom title color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Title Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_color',

				'edit_field_class'	=> 'vc_col-sm-3 vc_column ',

				'group' => __( 'Links Style', 'dpr-adeline-extensions' ),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size. If you leave this field blank will be used default size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group' => __( 'Links Style', 'dpr-adeline-extensions' ),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom line height.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group' => __( 'Links Style', 'dpr-adeline-extensions' ),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group' => __( 'Links Style', 'dpr-adeline-extensions' ),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'title_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'group' => __( 'Links Style', 'dpr-adeline-extensions' ),

	  		),
			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set text stroke width. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Stroke Width', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_stroke_width',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

				'group' => __( 'Links Style', 'dpr-adeline-extensions' ),

			),
			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose text stroke color for title', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Stroke Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_stroke_color',

				'edit_field_class'	=> 'vc_col-sm-4 vc_column ',

				'group' => __( 'Links Style', 'dpr-adeline-extensions' ),

			),
	
			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose text color on hover', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Title Color: Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_color_hover',

				'edit_field_class'	=> 'vc_col-sm-4 vc_column ',

				'group' => __( 'Links Style', 'dpr-adeline-extensions' ),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose text stroke color on hover', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Stroke Color: Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_stroke_color_hover',

				'edit_field_class'	=> 'vc_col-sm-4 vc_column ',

				'group' => __( 'Links Style', 'dpr-adeline-extensions' ),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font. .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_title_google_fonts',

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group' => __( 'Links Style', 'dpr-adeline-extensions' ),

			),



			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'title_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'dependency'		=> array('element' => 'use_title_google_fonts', 'value' => array('yes')),

				'group' => __( 'Links Style', 'dpr-adeline-extensions' ),

			),
	
			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Subtitle Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'typo_title_2',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group' => __( 'Links Style', 'dpr-adeline-extensions' ),

			),
			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom subtitle color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Subtitle Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_color',

				'edit_field_class'	=> 'vc_col-sm-3 vc_column ',

				'group' => __( 'Links Style', 'dpr-adeline-extensions' ),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size. If you leave this field blank will be used default size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group' => __( 'Links Style', 'dpr-adeline-extensions' ),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom linne height.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group' => __( 'Links Style', 'dpr-adeline-extensions' ),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom letter sapacing.', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group' => __( 'Links Style', 'dpr-adeline-extensions' ),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'subtitle_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'group' => __( 'Links Style', 'dpr-adeline-extensions' ),

	  		),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose subtitle color on hover', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Subtitle Color: Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_color_hover',

				'edit_field_class'	=> 'vc_col-sm-4 vc_column ',

				'group' => __( 'Links Style', 'dpr-adeline-extensions' ),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font. .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_subtitle_google_fonts',

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group' => __( 'Links Style', 'dpr-adeline-extensions' ),

			),

			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'subtitle_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'dependency'		=> array('element' => 'use_subtitle_google_fonts', 'value' => array('yes')),

				'group' => __( 'Links Style', 'dpr-adeline-extensions' ),

			),
			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Aside Image Style', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_aside_image_head',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Image Style', 'dpr-adeline-extensions'),
				
				'dependency'		=> array('element' => 'style', 'value' => array('aside-image')),

			),
			
			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="small" data-balloon="'.esc_html__('Set custom width for aside image.default is 58%', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Aside Image Width', 'dpr-adeline-extensions'),

				'param_name'		=> 'aside_image_width',

				'min'				=> 1,

				'suffix'				=> '%',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

				'group' => __( 'Image Style', 'dpr-adeline-extensions' ),
				
				'dependency'		=> array('element' => 'style', 'value' => array('aside-image')),
	

			),
			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom height for aside image.default is 60%', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Aside Image Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'aside_image_height',

				'min'				=> 1,

				'suffix'				=> '%',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'group' => __( 'Image Style', 'dpr-adeline-extensions' ),
				
				'dependency'		=> array('element' => 'style', 'value' => array('aside-image')),

			),
			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set side margin for aside image.default is 0', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Aside Image Side Margin', 'dpr-adeline-extensions'),

				'param_name'		=> 'aside_image_margin',

				'min'				=> 1,

				'suffix'				=> '%',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

				'group' => __( 'Image Style', 'dpr-adeline-extensions' ),
				
				'dependency'		=> array('element' => 'style', 'value' => array('aside-image')),

			),
			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable block reveal animation for image. ', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Use Block Reveal Animation', 'dpr-adeline-extensions'),

				'param_name'		=> 'reveal_image',
				
				'dependency'		=> array('element' => 'style', 'value' => array('aside-image')),
	
				'group' => __( 'Image Style', 'dpr-adeline-extensions' ),

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				)

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose color for reveal overlay', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Reveal Overlay Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'reveal_color',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',
	
				'dependency'		=> array('element' => 'reveal_image', 'value' => array('yes')),

				'group' => __( 'Image Style', 'dpr-adeline-extensions' )

			),
			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Satelite Image Style', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_satelite_image_head',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Image Style', 'dpr-adeline-extensions'),
				
				'dependency'		=> array('element' => 'style', 'value' => array('satelite-image')),

			),
			
			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="small" data-balloon="'.esc_html__('Set custom width for satelite image.default is 300px', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Satelite Image Width', 'dpr-adeline-extensions'),

				'param_name'		=> 'satelite_image_width',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

				'group' => __( 'Image Style', 'dpr-adeline-extensions' ),
				
				'dependency'		=> array('element' => 'style', 'value' => array('satelite-image')),
	

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Link Title Responsive Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_reaponsive_typography_head',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Responsive Options', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable responsive typography for headline. .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Enable', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_title_responsive_typo',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Responsive Options', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_responsive_typo',

				'param_name'		=> 'title_reaponsive_typography',

				'heading'			=> '',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'use_title_responsive_typo', 'value' => array('yes')),

				'group'				=> esc_attr__('Responsive Options', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Subtitle Responsive Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_reaponsive_typography_head',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Responsive Options', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable responsive typography for subtitle.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Enable', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_subtitle_responsive_typo',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Responsive Options', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_responsive_typo',

				'param_name'		=> 'subtitle_reaponsive_typography',

				'heading'			=> '',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'use_subtitle_responsive_typo', 'value' => array('yes')),

				'group'				=> esc_attr__('Responsive Options', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'css_editor',

				'heading' => __( 'CSS box', 'dpr-adeline-extensions' ),

				'param_name' => 'css',

				'group' => __( 'Design Options', 'dpr-adeline-extensions' ),

			),


		),

		

	)

);