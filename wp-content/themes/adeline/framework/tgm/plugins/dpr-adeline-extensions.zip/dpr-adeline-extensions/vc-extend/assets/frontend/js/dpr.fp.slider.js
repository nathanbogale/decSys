var $j = jQuery.noConflict();



$j( document ).on( 'ready', function() {

	"use strict";

	// Custom select

	dprInitializeFpSlider();

} );



/* ==============================================

BEFORE AFTER

============================================== */

function dprInitializeFpSlider() {

	"use strict";

		var dprFullPageSlider = $j('.dpr-fp-slider');

		

		if(dprFullPageSlider.length){

			dprFullPageSlider.each(function() {

				var thisFullPageSlider = $j(this),

					dprFullPageSliderOuterColumn = thisFullPageSlider.closest('div[class^="vc_column-inner"]'),

					dprFullPageSliderWrapper = thisFullPageSlider.children('.dpr-fps-wrapper'),

					dprFullPageSliderItems = dprFullPageSliderWrapper.children('.dpr-fps-section'),

					dprFullPageSliderItemsNumber = dprFullPageSliderItems.length,

					defaultOverlappingStyle ='';

					if($j('body').hasClass('overlapping-style-light')) {

						defaultOverlappingStyle ='overlapping-style-light';

					}

					if($j('body').hasClass('overlapping-style-dark')) {

						defaultOverlappingStyle ='overlapping-style-dark';

					}

					dprFullPageSliderOuterColumn.css('padding-top','0');

					dprFullPageSliderWrapper.fullpage({

					sectionSelector: '.dpr-fps-section',

					scrollingSpeed: 1200,

					verticalCentered: false,

					navigation: true,

					onLeave: function(index, nextIndex, direction){

						var styleToSet = $j(dprFullPageSliderItems[nextIndex - 1]).data('navigation');

						var toAnimate = $j(dprFullPageSliderItems[nextIndex - 1]).find('.wpb_animate_when_almost_visible:not(.wpb_start_animation)');

						dprChangeHeaderStyle(styleToSet,defaultOverlappingStyle);

						toAnimate.each(function() {

  							$j( this ).addClass( "wpb_start_animation animated" );

						});

					},

					afterRender: function(){				

						dprFullPageSliderWrapper.css('visibility','visible');

					}

				});

				

				

					



			});

		}

}

function dprChangeHeaderStyle(style,defaultstyle) {

	"use strict";

		setTimeout(function() {

		$j('body').removeClass('overlapping-style-dark overlapping-style-light');

		if(style !=='') {

			$j('body').addClass(style);

		} else {

			$j('body').addClass(defaultstyle);

		}

		},900);

}

