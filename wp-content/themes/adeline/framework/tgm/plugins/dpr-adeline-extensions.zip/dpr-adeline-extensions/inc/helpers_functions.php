<?php

/**

 *

 * Function used to create custom admin icon

 *

 **/

if (!function_exists('dpr_admin_branding')) {

    function dpr_admin_branding()
    {

        // access to the template object

        global $dpr_adeline;

        // get logo path

        $icon_path = '';

        if (isset($dpr_adeline['branding_admin_icon']['url'])) {
            $icon_path = $dpr_adeline['branding_admin_icon']['url'];
        }

        // if icon path isn't blank

        if ($icon_path !== '') {

            echo '<style>';

            echo 'a.toplevel_page_dpr_adeline img { display:none;} a.toplevel_page_dpr_adeline .dashicons-before{ background-image:url("' . $icon_path . '") ; background-repeat: no-repeat; background-position: center; }';

            echo '</style>';

        }

    }

}

add_action('admin_head', 'dpr_admin_branding');

/**

 *

 * Function used for login page styling

 *

 **/

if (!function_exists('dpr_login_branding')) {

    function dpr_login_branding()
    {

        // access to the template object

        global $dpr_adeline;

        if (isset($dpr_adeline['branding_login_logo']['url'])) {
            $login_logo_path = $dpr_adeline['branding_login_logo']['url'];
        }

        if (isset($dpr_adeline['branding_login_bg_color'])) {
            $login_background_color = $dpr_adeline['branding_login_bg_color'];
        }

        if (isset($dpr_adeline['branding_login_bg_img']['url'])) {
            $login_background_img = $dpr_adeline['branding_login_bg_img']['url'];
        }

        if (isset($dpr_adeline['branding_login_text_color'])) {
            $login_text_color = $dpr_adeline['branding_login_text_color'];
        }

        echo '<style>';

        echo '.login form { margin: 25px 0 0 0; padding: 20px; padding-bottom: 25px;    background: #ffffff; border-radius: 10px; -webkit-box-shadow: 0px 15px 40px 5px rgba(0,0,0,.1); box-shadow: 0px 15px 40px 5px rgba(0,0,0,.1);}';

        echo 'body.login form label {text-transform: uppercase; font-size: 11px; letter-spacing: .5px; padding-left: 20px; color: #555555;}';

        echo 'body.login form .forgetmenot {width: 50%; line-height: 43px;}';

        echo 'body.login form .forgetmenot label {display: block; text-transform: uppercase; color: #555555; letter-spacing: .5px; font-size: 11px; line-height: inherit; padding-left: 0;}';

        echo 'body > .logo {display: block; text-indent: 9999em; position: relative; top: 50px; overflow: hidden; margin: 0 auto; color: transparent; z-index: 1; max-width: 380px;}';

        echo 'body.login form input[type="text"], body.login form input[type="password"], body.login form input[type="email"] {padding: 6px 20px; background: #f1f2f4 !important; color: #111111; border-color: #dfdfe4; border-radius: 22px; margin: 7px 6px 16px 0; -webkit-box-shadow: none; box-shadow: none;}';

        echo 'body.login form input[type="text"], body.login #login_error, body.login .message {font-size: 13px;}';

        echo 'body.login form input[type="text"] {padding: 12px 20px;}';

        echo 'body.login form input[type="password"], body.login form input[type="email"] {margin-bottom: 26px;}';

        echo 'body.login form p.submit {float: left; height: 43px; width: 50%; position: relative;}';

        echo 'body.login form p.submit input[type="submit"] {border: none; font-weight: 400; text-transform: uppercase; color: #fff; text-shadow: none; box-shadow: none; background: #292933; border-radius: 22px; height: inherit; letter-spacing: 1px; font-size: 11px; width: 100%; -webkit-transition: all .3s ease; -moz-transition: all .3s ease; transition: all .3s ease}';

        echo 'body.login form p.submit input[type="submit"]:hover {background: #424251;}';

        echo 'body.login-action-register #login form#registerform p.submit {padding-bottom: 0;}';

        echo 'body.login.login-action-register form p.submit:before {left: 40px;}';

        echo 'body.login form .forgetmenot label input[type="checkbox"] {position: relative; width: 18px; height: 18px; background: transparent; border-color: transparent; -webkit-box-shadow: none; box-shadow: none;}';

        echo 'body.login form .forgetmenot label input[type="checkbox"]:before {content: ""; display: block; width: 16px; height: 16px; border-radius:5px;position: absolute; left: 50%; top: 50%; margin-top: -9px; margin-left: -9px; background: #f1f1f1; border: 1px solid #dfdfe4; -webkit-transition: background .3s ease, border-color .3s ease; -moz-transition: background .3s ease, border-color .3s ease; transition: background .3s ease, border-color .3s ease;}';

        echo 'body.login form .forgetmenot label input[type="checkbox"]:checked:before {background: #ddd; border-color: #eee;}';

        echo 'body.login form .forgetmenot label input[type="checkbox"]:checked:after {-webkit-transform: translate(-50%,-50%) scale(1); -moz-transform: translate(-50%,-50%) scale(1); -o-transform: translate(-50%,-50%) scale(1); transform: translate(-50%,-50%) scale(1);}';

        echo 'body.login form .forgetmenot label input[type="checkbox"]:after {content: "\f147";font-family: dashicons; font-size: 15px; display: block; position: absolute; top: 50%; left: 50%; color: #555; -webkit-transform: translate(-50%,-50%) scale(0); -moz-transform: translate(-50%,-50%) scale(0); -o-transform: translate(-50%,-50%) scale(0); transform: translate(-50%,-50%) scale(0); -webkit-transition: -webkit-transform .3s ease; -moz-transition: -moz-transform .3s ease; transition: transform .3s ease;}';

        echo '.login #backtoblog a, .login #nav a {font-size: 12px; font-style: normal; font-weight: 700; text-transform: none; line-height: 1; letter-spacing: -.4px; color: #333 !important; -webkit-transition: color .3s ease; -moz-transition: color .3s ease; transition: color .3s ease}';

        echo '.login #nav a, body.login #backtoblog a {-webkit-transition: color .3s ease; -moz-transition: color .3s ease; transition: color .3s ease}';

        echo 'body.login form p.submit label {line-height: 43px; position: absolute; color: #ffffff; left: 50px; padding: 0; font-size: 12px;}';

        echo '.interim-login.login .message {width: 100%; margin-left: -20px;}';

        echo 'body.login #login_error, body.login .message {background: transparent;border-left-width: 0; margin: 0 -20px; border-top-width: 0; -webkit-box-shadow: none; box-shadow: none; overflow: hidden; padding: 20px 20px 0; position: relative; margin-top: 68px;margin-left:8px;}';

        echo 'body.login #login_error strong {color: #e96c6c; font-size: 11px;}';

        if ($login_logo_path !== '') {
            echo '.login h1 a { background-image:url("' . $login_logo_path . '") ; background-repeat: no-repeat; background-position: top center; }';
        }

        if ($login_background_color !== '') {
            echo 'body.login { background-color:' . $login_background_color . ' ; }';
        }

        if ($login_background_img !== '') {
            echo 'body.login { background-image:url("' . $login_background_img . '") ; background-repeat: no-repeat; background-position: top center; background-size:cover; }';
        }

        if ($login_text_color !== '') {
            echo '.login #backtoblog a, .login #nav a, body.login #login_error, body.login .message {color:' . $login_text_color . ' !important ; }';
        }

        echo '</style>';

    }

}

add_action('login_head', 'dpr_login_branding');

/**

 *

 * Function used to create custom media query for mobile menu switchpoint

 *

 **/

if (!function_exists('dpr_mobile_menu_switch_css')) {

    function dpr_mobile_menu_switch_css()
    {

        $css = '';

        $mobile_menu_switchpoint = intval(adeline_get_option_value('mobile_menu_switchpoint', '', '959'));

        if ($mobile_menu_switchpoint == 'custom' && !empty(adeline_get_option_value('mobile_menu_switchpoint_custom'))) {
            $mobile_menu_switchpoint = intval(adeline_get_option_value('mobile_menu_switchpoint_custom'));
        }

        if ($mobile_menu_switchpoint != 959) {

            $css .= '@media (max-width: ' . $mobile_menu_switchpoint . 'px) {

                          #dpr-logo.in-center-header {

                            display:block !important;

                          }

                          #dpr-header.top-header .dpr-adeline-social-menu {

                            display: none;

                          }

                          #dpr-header.top-header #dpr-logo {

                            float: left;

                          }

                          #dpr-logo.has-mobile-logo .custom-logo-link {

                            display: none !important;

                          }

                          #dpr-logo.has-mobile-logo .mobile-logo-link {

                            display: block;

                          }

                          .is-sticky #dpr-logo.has-mobile-logo .mobile-logo-link {

                            display: none;

                          }

                          .is-sticky #dpr-logo.has-mobile-logo .sticky-logo-link {

                            display: block;

                          }

                          #dpr-header.center-header #dpr-logo {

                            display: block;

                          }

                          #dpr-top-bar-nav, #dpr-navigation-wrapper, .dpr-adeline-social-menu {

                            display: none;

                          }

                          #dpr-adeline-mobile-menu-icon {

                            display: block;

                          }

                         #dpr-top-bar.has-no-content #dpr-top-bar-social {

                            text-align: center;

                          }

                          #dpr-top-bar.has-no-content #dpr-top-bar-social.dpr-top-bar-left, #dpr-top-bar.has-no-content #dpr-top-bar-social.dpr-top-bar-right {

                            position: inherit;

                            left: auto;

                            right: auto;

                            float: none;

                            height: auto;

                            line-height: 1.5em;

                            margin-top: 0;

                          }

                          #dpr-top-bar.has-no-content #dpr-top-bar-social li {

                            float: none;

                            display: inline-block;

                          }

                          body.vertical-header-style #dpr-outer-wrapper {

                            margin: 0 !important;

                          }

                          .minimal-header .menu-bar-wrapper {

                                display:none;

                            }

                          #dpr-header.vertical-header {

                            position: relative;

                            width: 100%;

                            left: 0 !important;

                            right: 0 !important;

                          }

                          #dpr-header.vertical-header #dpr-header-inner {

                            display: -webkit-box;

                            display: -webkit-flex;

                            display: -ms-flexbox;

                            display: flex;

                            -webkit-align-items: center;

                            -webkit-box-align: center;

                                -ms-flex-align: center;

                                    align-items: center;

                            padding: 0;

                            max-width: 90%;

                          }

                          #dpr-header.vertical-header #dpr-header-inner > *:not(#dpr-adeline-mobile-menu-icon) {

                            display: none;

                          }

                          body.default-switchpoint #dpr-header.vertical-header #dpr-header-inner > * {

                            padding: 0 !important;

                          }

                          #dpr-header.vertical-header #dpr-header-inner #dpr-logo {

                            display: block;

                            margin: 0;

                            width: 50%;

                            text-align: left;

                          }

                          #dpr-header.vertical-header #dpr-header-inner #dpr-adeline-mobile-menu-icon {

                            width: 50%;

                            text-align: right;

                          }

                          #dpr-header.vertical-header .vertical-toggle {

                            display: none;

                          }

                          body.vh-expandable .vertical-toggle {

                            display: none;

                          }



                 }';

            return $css;

        }

    }

}

/**

 *

 * Function used to create custom CSS

 *

 **/

if (!function_exists('dpr_custom_css')) {

    function dpr_custom_css()
    {

        global $dpr_adeline;

        $output = '@media only screen and (min-width: 960px){ .content-area, .content-left-sidebar .content-area{width:' . adeline_get_option_value('content_width', 'width', '72%') . ';} }';

        $output .= '@media only screen and (min-width: 960px){ .widget-area, .content-left-sidebar .widget-area{width:' . adeline_get_option_value('sidebar_width', 'width', '28%') . ';} }';

        $output .= '@media only screen and (min-width: 960px){.content-both-sidebars .content-area {width: ' . adeline_get_option_value('both_sidebars_content_width', 'width', '44%') . '; } }';

        $output .= '@media only screen and (min-width: 960px){.content-both-sidebars .widget-area,.content-both-sidebars.order-scs .widget-area.sidebar-secondary {width: ' . adeline_get_option_value('both_sidebars_sidebars_width', 'width', '28%') . ' } }';

        $output .= '@media only screen and (min-width: 960px){.content-both-sidebars.order-scs .content-area {left: ' . adeline_get_option_value('both_sidebars_sidebars_width', 'width', '28%') . ' } }';

        $output .= '@media only screen and (min-width: 960px){.content-both-sidebars.order-scs .widget-area.sidebar-secondary, .content-both-sidebars.order-ssc .widget-area {left: -' . adeline_get_option_value('both_sidebars_content_width', 'width', '44%') . ' } }';

        $double_left_margin = 2 * intval((adeline_get_option_value('both_sidebars_sidebars_width', 'width', '28%'))) . '%';

        $output .= '@media only screen and (min-width: 960px){.content-both-sidebars.order-ssc .content-area {left: ' . $double_left_margin . ';} }';

        $output .= '@media only screen and (min-width: 960px){ body.woocommerce.archive .content-area, body.woocommerce.archive.content-left-sidebar .content-area{width:' . adeline_get_option_value('woo_archive_content_width', 'width', '72%') . ';} }';

        $output .= '@media only screen and (min-width: 960px){ body.woocommerce.archive .widget-area, body.woocommerce.archive.content-left-sidebar .widget-area{width:' . adeline_get_option_value('woo_archive_sidebar_width', 'width', '28%') . ';} }';

        $output .= '@media only screen and (min-width: 960px){body.woocommerce.archive.content-both-sidebars .content-area {width: ' . adeline_get_option_value('woo_both_sidebars_content_width', 'width', '44%') . '; } }';

        $output .= '@media only screen and (min-width: 960px){body.woocommerce.archive.content-both-sidebars .widget-area,body.woocommerce.archive.content-both-sidebars.order-scs .widget-area.sidebar-secondary {width: ' . adeline_get_option_value('woo_page_both_sidebars_sidebars_width', 'width', '28%') . ' } }';

        $output .= '@media only screen and (min-width: 960px){body.woocommerce.archive.content-both-sidebars.order-scs .content-area {left: ' . adeline_get_option_value('woo_page_both_sidebars_sidebars_width', 'width', '28%') . ' } }';

        $output .= '@media only screen and (min-width: 960px){body.woocommerce.archive.content-both-sidebars.order-scs .widget-area.sidebar-secondary, body.woocommerce.archive.content-both-sidebars.order-ssc .widget-area {left: -' . adeline_get_option_value('woo_both_sidebars_content_width', 'width', '44%') . ' } }';

        $woo_double_left_margin = 2 * intval((adeline_get_option_value('woo_page_both_sidebars_sidebars_width', 'width', '28%'))) . '%';

        $output .= '@media only screen and (min-width: 960px){body.woocommerce.archive.content-both-sidebars.order-ssc .content-area {left: ' . $woo_double_left_margin . ';} }';

        $output .= '@media only screen and (min-width: 960px){ body.woocommerce.single-product .content-area, body.woocommerce.single-product.content-left-sidebar .content-area{width:' . adeline_get_option_value('woo_single_page_content_area_width', 'width', '72%') . ';} }';

        $output .= '@media only screen and (min-width: 960px){ body.woocommerce.single-product .widget-area, body.woocommerce.single-product.content-left-sidebar .widget-area{width:' . adeline_get_option_value('woo_single_page_sidebar_width', 'width', '28%') . ';} }';

        $output .= '@media only screen and (min-width: 960px){body.woocommerce.single-product.content-both-sidebars .content-area {width: ' . adeline_get_option_value('woo_single_both_sidebars_content_width', 'width', '44%') . '; } }';

        $output .= '@media only screen and (min-width: 960px){body.woocommerce.single-product.content-both-sidebars .widget-area,body.woocommerce.single-product.content-both-sidebars.order-scs .widget-area.sidebar-secondary {width: ' . adeline_get_option_value('woo_single_both_sidebars_sidebars_width', 'width', '28%') . ' } }';

        $output .= '@media only screen and (min-width: 960px){body.woocommerce.single-product.content-both-sidebars.order-scs .content-area {left: ' . adeline_get_option_value('woo_single_both_sidebars_sidebars_width', 'width', '28%') . ' } }';

        $output .= '@media only screen and (min-width: 960px){body.woocommerce.single-product.content-both-sidebars.order-scs .widget-area.sidebar-secondary, body.woocommerce.single-product.content-both-sidebars.order-ssc .widget-area {left: -' . adeline_get_option_value('woo_single_both_sidebars_content_width', 'width', '44%') . ' } }';

        $woo_single_double_left_margin = 2 * intval((adeline_get_option_value('woo_single_both_sidebars_sidebars_width', 'width', '28%'))) . '%';

        $output .= '@media only screen and (min-width: 960px){body.woocommerce.single-product.content-both-sidebars.order-ssc .content-area {left: ' . $woo_single_double_left_margin . ';} }';

        $output .= '#dpr-navigation-wrapper .dropdown-menu > li > a,#dpr-adeline-mobile-menu-icon a{line-height: ' . adeline_get_option_value('header_height', 'height', '76px') . ';} ';

        $output .= '#dpr-header.top-header #dpr-navigation-wrapper .dropdown-menu > li > a{line-height: ' . adeline_get_option_value('top_header_nav_height', 'height', '70px') . ';} ';

        $vh_width = intval((adeline_get_option_value('vertical_header_width', 'width', '300px')));

        $output .= 'body.vertical-header-style.left-header #dpr-outer-wrapper {margin-left:' . $vh_width . 'px}';

        $output .= 'body.vertical-header-style.left-header .dpr-footer.parallax-footer {padding-left:' . $vh_width . 'px}';

        $output .= 'body.vertical-header-style.right-header #dpr-outer-wrapper {margin-right:' . $vh_width . 'px}';

        $output .= 'body.vertical-header-style.right-header .dpr-footer.parallax-footer {padding-right:' . $vh_width . 'px}';

        $vh_width_minus = $vh_width - 50;

        $output .= 'body.vertical-header-style.vh-expandable.left-header #dpr-header.vertical-header {left:-' . $vh_width_minus . 'px}';

        $output .= 'body.vertical-header-style.vh-expandable.right-header #dpr-header.vertical-header {right:-' . $vh_width_minus . 'px}';

        $drop_border_width = intval(adeline_get_option_value('dropdown_top_border_width', '', '4'));

        $drop_arrow_pos = 8 + $drop_border_width;

        $output .= '.add-top-arrow .sub-menu.level-0:after {border-color: ' . adeline_get_option_value('dropdown_top_border_color', '', '#d3ae5f') . ' transparent;top: -' . $drop_arrow_pos . 'px;}';

        $output .= '.dropdown-menu .sub-menu,#searchform-dropdown,#current-shop-items-dropdown {border-top-width:' . $drop_border_width . 'px;}';

        $output .= '.is-sticky #dpr-header.shrink-header #dpr-logo #dpr-logo-inner, .is-sticky #dpr-header.shrink-header .dpr-adeline-social-menu .social-menu-inner, .is-sticky #dpr-header.shrink-header.full_screen-header .menu-bar-inner, .is-sticky #dpr-header.shrink-header #dpr-navigation-wrapper .dropdown-menu > li > a {line-height:' . adeline_get_option_value('shrink_header_height', 'height', '70px') . ';}';

        if ('1' == adeline_get_meta_value(get_the_ID(), 'use_custom_subheader_bg', '')) {
            $custom_subheader_bg_css = dpr_generate_bg_css(adeline_get_meta_value(get_the_ID(), 'custom_subheader_bg', ''));
            if ($custom_subheader_bg_css != '') {
                $output .= '.subheader{' . $custom_subheader_bg_css . '}';
            }
        }
        if ('1' == adeline_get_meta_value(get_the_ID(), 'use_custom_footer_bg', '')) {
            $output .= '.dpr-footer{' . dpr_generate_bg_css(adeline_get_meta_value(get_the_ID(), 'custom_footer_bg', '')) . '}';
        }
        if ('1' == adeline_get_meta_value(get_the_ID(), 'use_custom_boxed_body_bg', '')) {
            $output .= '.boxed-layout{' . dpr_generate_bg_css(adeline_get_meta_value(get_the_ID(), 'custom_boxed_body_bg', '')) . '}';
        }

        $output .= '.widget-title-decoration-bordered .sidebar-container .widget-title {border-left-width:' . adeline_get_option_value('widgets_title_border_width', 'width', '3px') . '; border-left-color:' . adeline_get_option_value('widgets_title_border_color') . '}';

        $output .= '.widget-title-decoration-underlined .sidebar-container .widget-title:before,.widget-title-decoration-underlined .sidebar-container .widget-title:after {border-width:' . adeline_get_option_value('widgets_title_underline_thikness', 'height', '1px') . '}';

        $output .= '.widget-title-decoration-underlined .sidebar-container .widget-title:before {border-color:' . adeline_get_option_value('widgets_title_background_underline_color') . '}';

        $output .= '.widget-title-decoration-underlined .sidebar-container .widget-title:after {border-color:' . adeline_get_option_value('widgets_title_underline_color') . '}';

        $output .= 'body.header-overlapping-used.overlapping-style-light .minimal-header .menu-bar.close-menu .opener:after,body.header-overlapping-used.overlapping-style-light .minimal-header .menu-bar.close-menu .opener:before, body.header-overlapping-used.overlapping-style-light .full_screen-header .menu-bar:not(.close-menu) .opener, body.header-overlapping-used.overlapping-style-light .full_screen-header .menu-bar:not(.close-menu) .opener:before,body.header-overlapping-used.overlapping-style-light .full_screen-header .menu-bar:not(.close-menu) .opener:after{background-color:' . adeline_get_option_value('menu_link_color_ol', '', '#ffffff') . '}';

        $output .= 'body.header-overlapping-used.overlapping-style-light .dpr-adeline-sticky-header-holder:not(.is-sticky) .dpr-adeline-social-menu ul li a {color: ' . adeline_get_option_value('menu_link_color_ol', '', '#ffffff') . '}';

        $output .= 'body.header-overlapping-used.overlapping-style-light .dpr-adeline-sticky-header-holder:not(.is-sticky) .dpr-adeline-social-menu ul li a:hover {color: ' . adeline_get_option_value('menu_link_color_hover_ol', '', '#d3ae5f') . ' !important}';

        $output .= 'body.header-overlapping-used.overlapping-style-light .dpr-adeline-sticky-header-holder:not(.is-sticky) .dpr-adeline-social-menu .rounded ul li a{ color: #111912; background-color: ' . adeline_get_option_value('menu_link_color_ol', '', '#ffffff') . '}';

        $output .= 'body.header-overlapping-used.overlapping-style-light .dpr-adeline-sticky-header-holder:not(.is-sticky) .dpr-adeline-social-menu .rounded ul li a:hover{ color: #fff !important; background-color: ' . adeline_get_option_value('menu_link_color_hover_ol', '', '#d3ae5f') . ' }';

        $output .= 'body.header-overlapping-used.overlapping-style-light .dpr-adeline-sticky-header-holder:not(.is-sticky) .dpr-adeline-social-menu .outlined ul li a{ color: ' . adeline_get_option_value('menu_link_color_ol', '', '#ffffff') . '; border-color: ' . adeline_get_option_value('menu_link_color_ol', '', '#ffffff') . '}';

        $output .= 'body.header-overlapping-used.overlapping-style-light .hamburger .hamburger-inner,body.header-overlapping-used.overlapping-style-light .hamburger .hamburger-inner::before, body.header-overlapping-used.overlapping-style-light .hamburger .hamburger-inner::after { background-color: ' . adeline_get_option_value('menu_link_color_ol', '', '#ffffff') . ' !important;}';

        $output .= ' body.header-overlapping-used.overlapping-style-light .hamburger:hover .hamburger-inner, body.header-overlapping-used.overlapping-style-light .hamburger:hover .hamburger-inner::before, body.header-overlapping-used.overlapping-style-light .hamburger:hover .hamburger-inner::after{ background-color: ' . adeline_get_option_value('menu_link_color_hover_ol', '', '#d3ae5f') . ' !important; }';

        $output .= '.blog-item-readmore a, .btn.btn-min, .btn-link.btn-min{ color: ' . adeline_get_option_value('headings_typo', 'color', '#111111') . ' !important }';  
        $output .= '.blog-item-readmore a:after, .btn.btn-min:after, .btn-link.btn-min:after { background-color: ' . adeline_get_option_value('link-color', 'regular', '#9e895d') . ' !important}';   

        $output .= 'body.header-overlapping-used.overlapping-style-dark .minimal-header .menu-bar.close-menu .opener:after,body.header-overlapping-used.overlapping-style-dark .minimal-header .menu-bar.close-menu .opener:before, body.header-overlapping-used.overlapping-style-dark .full_screen-header .menu-bar:not(.close-menu) .opener, body.header-overlapping-used.overlapping-style-dark .full_screen-header .menu-bar:not(.close-menu) .opener:before,body.header-overlapping-used.overlapping-style-dark .full_screen-header .menu-bar:not(.close-menu) .opener:after {background-color:' . adeline_get_option_value('menu_link_color_od', '', '#111111') . '}';

        $output .= 'body.header-overlapping-used.overlapping-style-dark .dpr-adeline-sticky-header-holder:not(.is-sticky) .dpr-adeline-social-menu .social-menu-inner:not(.colored) ul li a {color: ' . adeline_get_option_value('menu_link_color_od', '', '#111111') . '}';

        $output .= 'body.header-overlapping-used.overlapping-style-dark .dpr-adeline-sticky-header-holder:not(.is-sticky) .dpr-adeline-social-menu .social-menu-inner:not(.colored):not(.rounded) ul li a:hover {color: ' . adeline_get_option_value('menu_link_color_hover_od', '', '#111111') . ' !important}';

        $output .= 'body.header-overlapping-used.overlapping-style-dark .dpr-adeline-sticky-header-holder:not(.is-sticky) .dpr-adeline-social-menu .rounded ul li a{ color: #fff !important; background-color: ' . adeline_get_option_value('menu_link_color_od', '', '#111111') . '}';

        $output .= 'body.header-overlapping-used.overlapping-style-dark .dpr-adeline-sticky-header-holder:not(.is-sticky) .dpr-adeline-social-menu .rounded ul li a:hover{ color: #fff !important; background-color: ' . adeline_get_option_value('menu_link_color_hover_od', '', '#d3ae5f') . ' }';

        $output .= 'body.header-overlapping-used.overlapping-style-dark .dpr-adeline-sticky-header-holder:not(.is-sticky) .dpr-adeline-social-menu .outlined ul li a{ color: ' . adeline_get_option_value('menu_link_color_od', '', '#ffffff') . '; border-color: ' . adeline_get_option_value('menu_link_color_od', '', '#ffffff') . '}';

        $output .= 'body.header-overlapping-used.overlapping-style-dark .hamburger .hamburger-inner, body.header-overlapping-used.overlapping-style-dark .hamburger .hamburger-inner::before, body.header-overlapping-used.overlapping-style-dark .hamburger .hamburger-inner::after { background-color: ' . adeline_get_option_value('menu_link_color_od', '', '#111111') . ' !important; }';

        $output .= 'body.header-overlapping-used.overlapping-style-dark .hamburger:hover .hamburger-inner, body.header-overlapping-used.overlapping-style-dark .hamburger:hover .hamburger-inner::before, body.header-overlapping-used.overlapping-style-dark .hamburger:hover .hamburger-inner::after{ background-color: ' . adeline_get_option_value('menu_link_color_hover_od', '', '#d3ae5f') . ' !important; }';


        $output .= '.is-sticky .minimal-header .menu-bar .opener, .is-sticky .minimal-header .menu-bar .opener:after,.is-sticky .minimal-header .menu-bar .opener:before{background-color:' . adeline_get_option_value('sticky_header_link_color', '', '#111111') . ' }';

        $output .= '.is-sticky .minimal-header .menu-bar.close-menu .opener:after,.is-sticky .minimal-header .menu-bar.close-menu .opener:before{background-color:' . adeline_get_option_value('sticky_header_link_color', '', '#111111') . ' !important}';

        $portfolio_grid_margin = intval((adeline_get_option_value('portfolio_grid_margin', 'padding-top', '10px')));

        $output .= '.portfolio-items{margin:0 -' . $portfolio_grid_margin . 'px}';

        $portfolio_filter_switch_point = adeline_get_option_value('portfolio_filter_responsive_switch_point', '', '480');

        $output .= '.portfolio-items .portfolio-item-thumbnail .arrow{border-bottom-color:' . adeline_get_option_value('portfolio_entry_bg_color', '', '#f1f1f1') . '}';

        $portfolio_single_gallery_gap = absint(adeline_get_meta_value(get_the_ID(), 'porfolio_single_gallery_gap')) / 2;

        if ($portfolio_single_gallery_gap > 0) {

            $output .= '.single-portfolio-gallery {margin:-' . $portfolio_single_gallery_gap . 'px;}';

            $output .= '.single-portfolio-gallery .grid-item {padding:' . $portfolio_single_gallery_gap . 'px;}';

        }

        if (!empty(adeline_get_option_value('panel_width', 'width', '300px')) && '300px' != adeline_get_option_value('panel_width', 'width', '300px')) {

            $output .= '#side-panel-wrap{width:' . adeline_get_option_value('panel_width', 'width', '300px') . ';}.dpr-sp-right #side-panel-wrap{right:-' . adeline_get_option_value('panel_width', 'width', '300px') . ';}.dpr-sp-right.dpr-sp-opened #outer-wrap{left:-' . adeline_get_option_value('panel_width', 'width', '300px') . ';}.dpr-sp-left #side-panel-wrap{left:-' . adeline_get_option_value('panel_width', 'width', '300px') . ';}.dpr-sp-left.dpr-sp-opened #outer-wrap{right:-' . adeline_get_option_value('panel_width', 'width', '300px') . ';}';

        }

        if (!empty(adeline_get_option_value('panel_width_tablet', 'width', ''))) {

            $output .= '@media (max-width: 768px){#side-panel-wrap{width:' . adeline_get_option_value('panel_width_tablet', 'width', '') . ';}.dpr-sp-right #side-panel-wrap{right:-' . adeline_get_option_value('panel_width_tablet', 'width', '') . ';}.dpr-sp-right.dpr-sp-opened #outer-wrap{left:-' . adeline_get_option_value('panel_width_tablet', 'width', '') . ';}.dpr-sp-left #side-panel-wrap{left:-' . adeline_get_option_value('panel_width_tablet', 'width', '') . ';}.dpr-sp-left.dpr-sp-opened #outer-wrap{right:-' . adeline_get_option_value('panel_width_tablet', 'width', '') . ';}}';

        }

        if (!empty(adeline_get_option_value('panel_width_mobile', 'width', ''))) {

            $output .= '@media (max-width: 480px){#side-panel-wrap{width:' . adeline_get_option_value('panel_width_mobile', 'width', '') . ';}.dpr-sp-right #side-panel-wrap{right:-' . adeline_get_option_value('panel_width_mobile', 'width', '') . ';}.dpr-sp-right.dpr-sp-opened #outer-wrap{left:-' . adeline_get_option_value('panel_width_mobile', 'width', '') . ';}.dpr-sp-left #side-panel-wrap{left:-' . adeline_get_option_value('panel_width_mobile', 'width', '') . ';}.dpr-sp-left.dpr-sp-opened #outer-wrap{right:-' . adeline_get_option_value('panel_width_mobile', 'width', '') . ';}}';

        }

        $breakpoint = adeline_get_option_value('hide_breakpoint');

        if (!empty($breakpoint) && '959' != $breakpoint) {

            if ('custom' == $breakpoint && !empty(adeline_get_option_value('custom_hide_breakpoint')) && '959' != adeline_get_option_value('custom_hide_breakpoint')) {

                $breakpoint = adeline_get_option_value('custom_hide_breakpoint');

            }

            $output .= '@media (max-width: ' . $breakpoint . 'px) {li.side-panel-li,#side-panel-wrap, #oceanwp-mobile-menu-icon a.side-panel-btn { display: none !important; }}';

        }

        if (!empty(adeline_get_option_value('opening_button_icon_size')) && '20' != adeline_get_option_value('opening_button_icon_size')) {

            $output .= '#side-panel-wrap a.side-panel-btn{font-size:' . adeline_get_option_value('opening_button_icon_size') . 'px;}';

        }
        if ('1' == adeline_get_option_value('magic_cursor') && '1' == adeline_get_option_value('disable_system_cursor')) {

            $output .= 'body {cursor: none !important;}';

        }
        //if (isset($dpr_adeline['header_full_width_padding']['right'])) {

         $output .= '.full-width-header .center-header #dpr-header-inner .dpr-adeline-social-menu {padding-right:' .$dpr_adeline['header_full_width_padding']['padding-right'].';}';
        
        //}

        if (isset($dpr_adeline['branding_admin_icon']['right'])) {             
          
          $icon_path = $dpr_adeline['branding_admin_icon']['url'];

        }

        // Woocommerce CSS

        if (!empty(adeline_get_option_value('woo_product_image_width', 'width', '42%')) && '42%' != adeline_get_option_value('woo_product_image_width', 'width', '42%')) {

            $output .= '.woocommerce div.product div.images, .woocommerce.content-full-width div.product div.images{width:' . adeline_get_option_value('woo_product_image_width', 'width', '42%') . ';}';

        }

        if (!empty(adeline_get_option_value('woo_product_details_sidebars_width', 'width', '54%')) && '54%' != adeline_get_option_value('woo_product_details_sidebars_width', 'width', '54%')) {

            $output .= '.woocommerce div.product div.summary, .woocommerce.content-full-width div.product div.summary{width:' . adeline_get_option_value('woo_product_details_sidebars_width', 'width', '54%') . ';}';

        }

        $output .= adeline_minify_css(dpr_mobile_menu_switch_css());

        if ('' != adeline_get_option_value('custom_css')) {

            $output .= adeline_minify_css(adeline_get_option_value('custom_css'));

        }

        echo '<style data-type="dpr-custom-css">' . $output . '</style>';

    }

    add_action('wp_head', 'dpr_custom_css', 9999);

}

/**

 * Include custom JS in HEAD

 *

 */

if (!function_exists('dpr_head_custom_js')) {

    function dpr_head_custom_js()
    {

        if ('' != adeline_get_option_value('head_custom_js')) {

            $output = '<script>';

            $output .= DPR_JSMin::minify(adeline_get_option_value('head_custom_js'));

            $output .= '</script>';

            echo $output;

        }

    }

    add_action('wp_head', 'dpr_head_custom_js', 9999);

}

/**

 * Include custom JS in HEAD

 *

 */

if (!function_exists('dpr_custom_js')) {

    function dpr_custom_js()
    {

        if ('' != adeline_get_option_value('custom_js')) {

            $output = '<script>';

            $output .= DPR_JSMin::minify(adeline_get_option_value('custom_js'));

            $output .= '</script>';

            echo $output;

        }

    }

    add_action('wp_footer', 'dpr_custom_js', 9999);

}

/**

 * Return empty image url

 *

 */

if (!function_exists('dpr_empty_image_url')) {

    function dpr_empty_image_url()
    {

        return DPR_EXTENSIONS_PLUGIN_URL . 'assets/img/empty.png';

    }

}

/**

 * Return no image url

 *

 */

if (!function_exists('dpr_no_image_url')) {

    function dpr_no_image_url()
    {

        return DPR_EXTENSIONS_PLUGIN_URL . 'assets/img/noimage.jpg';

    }

}

/**

 * Generate background CSS form REDUX backround field value

 *

 */

if (!function_exists('dpr_generate_bg_css')) {

    function dpr_generate_bg_css($value = array())
    {

        $css = '';

        if (!empty($value) && is_array($value)) {

            foreach ($value as $key => $value) {

                if (!empty($value) && $key != "media") {

                    if ($key == "background-image") {

                        $css .= $key . ":url('" . $value . "');";

                    } else {

                        $css .= $key . ":" . $value . ";";

                    }

                }

            }

        }

        return $css;

    }

}

// EOF
