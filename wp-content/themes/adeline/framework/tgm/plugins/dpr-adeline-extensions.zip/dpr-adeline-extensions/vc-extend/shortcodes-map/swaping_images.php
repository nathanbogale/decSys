<?php

if ( ! defined( 'ABSPATH' ) ) { exit; }



class WPBakeryShortCode_DPR_Swaping_Images extends WPBakeryShortCode {}


vc_map(

	array(

		'name'					=> esc_html__('DP Swaping Images', 'dpr-adeline-extensions'),

		'base'					=> 'dpr_swaping_images',

		'class'					=> '',

		'icon'					=> 'icon-dpr-swaping-images',

  		"category" =>array( esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions')),

		"description" => esc_attr__('Stack of images swaping on hover ', 'dpr-adeline-extensions'),

		'params'				=> array(

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'General Settings', 'dpr-adeline-extensions' ),

				'param_name'       => 'general_title',

				'edit_field_class' => 'vc_column vc_col-sm-12',

			),
			array(

				'type'				=> 'dpr_radio',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose swap images element style.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Style', 'dpr-adeline-extensions'),

				'param_name'		=> 'style',

				'value'				=> 'fade',

				'edit_field_class'	=> 'vc_column vc_col-sm-6  ',

				'options'			=> array(

					esc_html__('Fade Images', 'dpr-adeline-extensions')	=> 'fade',

					esc_html__('Reveal Images', 'dpr-adeline-extensions')	=> 'reveal'

				),
			),
			array(

				'type'				=> 'dpr_radio',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose swap images eactivation mode.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Activation Mode', 'dpr-adeline-extensions'),

				'param_name'		=> 'mode',

				'value'				=> 'allways',

				'edit_field_class'	=> 'vc_column vc_col-sm-6  ',

				'options'			=> array(

					esc_html__('Allways', 'dpr-adeline-extensions')	=> 'allways',

					esc_html__('On Click', 'dpr-adeline-extensions')	=> 'onclick',
	
					esc_html__('On Hover', 'dpr-adeline-extensions')	=> 'onhover'

				),

			),
			array(

				'type' 				=> 'number',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select swap images interval in ms.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Swap Speed', 'dpr-adeline-extensions'),

				'param_name'		=> 'speed',

				'suffix'			=> 'ms',

				'value' 			=> 1000,

				'edit_field_class' 	=> 'vc_column vc_col-sm-6'
			),
			array(

				'type' 				=> 'number',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select fade duration in ms.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Fade Duration', 'dpr-adeline-extensions'),

				'param_name'		=> 'fade_duration',

				'suffix'			=> 'ms',

				'value' 			=> 300,

				'edit_field_class' 	=> 'vc_column vc_col-sm-6',
	
				'dependency'		=> array('element' => 'style', 'value' => array('fade'))
			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Images Settings', 'dpr-adeline-extensions' ),

				'param_name'       => 'image_title',

				'edit_field_class' => 'vc_column vc_col-sm-12',

			),
	
			array(

				'type' => 'attach_image',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Upload the image which will be allways visible in idle state.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Main Image', 'dpr-adeline-extensions'),
				'param_name' => 'main_image',
				'description' => esc_html__( 'Select images from media library.', 'js_composer' ),
				'edit_field_class' => 'vc_column vc_col-sm-12'

			),

			array(
				'type' => 'attach_images',
				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select images which will be appear on mouse enter on this element', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Swaping Images', 'dpr-adeline-extensions'),
				'param_name' => 'swap_images',
				'value' => '',
				'description' => esc_html__( 'Select images from media library.', 'js_composer' ),
			),


			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Additional Settings', 'dpr-adeline-extensions' ),

				'param_name'       => 'extra_features_title',

				'edit_field_class' => 'vc_column vc_col-sm-12',

			),

			vc_map_add_css_animation( false ),

		    array(

				'type' => 'textfield',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Extra Class Name', 'dpr-adeline-extensions'),

				'param_name' => 'el_class',

			),

	

			array(

				'type' => 'css_editor',

				'heading' => __( 'CSS box', 'dpr-adeline-extensions' ),

				'param_name' => 'css',

				'group' => __( 'Design Options', 'dpr-adeline-extensions' ),

			),


		),

		

	)

);