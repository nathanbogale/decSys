<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$el_class = $width = $el_id = $css = $offset = $bg_style = $css_animation = '';
$column_shadow = $column_bg_color_hover = $column_border_color_hover = $column_border_style_hover = $column_border_radius_hover = $column_shadow_hover = $dpr_enable_responsive_options = $responsive_css_panel = '';
$custom_el_css = $overlay_output = $output =  $after_output = '';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$unique_class = uniqid('uniq-');

if ( '' !== $css_animation && 'none' !== $css_animation ) {
	dpr_enqueue_waypoint_js();
	dpr_enqueue_animate_css();
	$el_class .= ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
}

$width = wpb_translateColumnWidthToSpan( $width );
$width = vc_column_offset_class_merge( $offset, $width );

$css_classes = array(
	$this->getExtraClass( $el_class ),
	'wpb_column',
	'vc_column_container',
	$width,
);

if ( vc_shortcode_custom_css_has_property( $css, array(
	'border',
	'background',
) ) ) {
	$css_classes[] = 'vc_col-has-fill';
}

$css_classes[] = $unique_class;

$wrapper_attributes = array();

// Add custom CSS rules

if (dpr_shadow_param_to_css($column_shadow) != '') {
	$custom_el_css .= '.'.$unique_class.' .vc_column-inner{'.dpr_shadow_param_to_css($column_shadow).'}';
}

if ( $column_bg_color_hover != '' || $column_border_color_hover != '' || $column_border_style_hover != '' || $column_border_radius_hover != '' || dpr_shadow_param_to_css($column_shadow_hover) != '') {
	$css_classes[] = 'has-hover-css';
	$custom_el_css .= '.'.$unique_class.' .vc_column-inner:hover {';
		if ( $column_bg_color_hover != '') {
			$custom_el_css .= 'background-color:'.$column_bg_color_hover.'!important;';
		}
		if ( $column_border_color_hover != '') {
			$custom_el_css .= 'border-color:'.$column_border_color_hover.'!important;';
		}
		if ( $column_border_style_hover != '') {
			$custom_el_css .= 'border-style:'.$column_border_style_hover.'!important;';
		}
		if ( $column_border_radius_hover != '') {
			$custom_el_css .= 'border-radius:'.$column_border_radius_hover.'px!important;';
		}
		if (dpr_shadow_param_to_css($column_shadow_hover) != '') {
			$custom_el_css .= dpr_shadow_param_to_css($column_shadow_hover).';';
		}
	$custom_el_css .= '}';
}
// Add responsive CSS

if($dpr_enable_responsive_options && isset($responsive_css_panel) && $responsive_css_panel != '') {
	
	$responsive_unique_class = uniqid('vc-column-responsive-');
	$css_classes[] .= $responsive_unique_class;
	$custom_el_css .= DPR_Responsive_CSS::generate_css($responsive_css_panel, '.'.$responsive_unique_class.' .vc_column-inner');

}

$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( $css_classes ) ), $this->settings['base'], $atts ) );
$wrapper_attributes[] = 'class="' . esc_attr( trim( $css_class ) ) . '"';
if ( ! empty( $el_id ) ) {
	$wrapper_attributes[] = 'id="' . esc_attr( $el_id ) . '"';
}
$output .= '<div ' . implode( ' ', $wrapper_attributes ) . '>';
$output .= '<div class="vc_column-inner ' . esc_attr( trim( vc_shortcode_custom_css_class( $css ) ) ) . '">';
$output .= '<div class="wpb_wrapper">';
$output .= wpb_js_remove_wpautop( $content );
$output .= '</div>';
$output .= '</div>';

if($custom_el_css != '') {
	$output .= '<script>'
				. '(function($) {'
					. '$("head").append("<style>'.$custom_el_css.'</style>")'
				. '})(jQuery);'
			. '</script>';
}
$output .= '</div>';

echo $output;
