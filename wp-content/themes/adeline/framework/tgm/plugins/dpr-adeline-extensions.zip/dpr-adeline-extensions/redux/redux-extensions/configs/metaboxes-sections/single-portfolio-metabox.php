<?php







if ( !function_exists( "dpr_single_portfolio_metabox_sections" ) ):



    function dpr_single_portfolio_metabox_sections( ) {



        // Declare your sections



		



		/*



     	* ---> START SINGLE PORTFOLIO METABOX SECTIONS



		*/







        $single_portfolio_metabox_sections = array();







		$single_portfolio_metabox_sections[] = array(



			'title'    => esc_html__( 'Layout Settings', 'dpr-adeline-extensions' ),



			'subtitle' => esc_html__( '', 'dpr-adeline-extensions' ),



			'fields'   => array(



						array (



							'id' => 'portfolio_single_content_layout',



							'type' => 'image_select',



							'title' => __('Content Layout Style', 'dpr-adeline-extensions'),



							'desc' => wp_kses_post(__('<small>If you select option <i>"Free Layout"</i> portfolio item will be displayed as default post and you can create any custom layout with Visual Composer for example.</small>', 'dpr-adeline-extensions')),



							'options' => array (



								'details-left' => array (



									'title' => esc_html__('Details Left', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/portfolio/single_style_1.png'



								),					



								'details-right' => array (



									'title' => esc_html__('Details Right', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/portfolio/single_style_2.png'



								),					



								'details-bellow' => array (



									'title' => esc_html__('Details Bellow', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/portfolio/single_style_3.png'



								),



								'post' => array (



									'title' => esc_html__('Free Layout', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/portfolio/single_style_4.png'



								),					



							),



							'hint' => array (



								'title' => esc_attr__('Content Layout Style', 'dpr-adeline-extensions'),



								'content' => esc_attr__('Choose default single item layout eg media and details position. If you select post style portfoli item will be displayed as default post and you will be able create free item layout with Visual Composer for example.', 'dpr-adeline-extensions')



							)



						),



						array(



							'id'       => 'portfolio_single_media_block_width',



							'type'     => 'radio',



							'title'    => __('Media Block Width', 'dpr-adeline-extensions'),



							'options'  => array(



								'one-third'  => 'One Third',



								'half' => 'One Half', 



								'two-thirds' => 'Two Thirds'



							),



							'default' => 'two-thirds',



							'hint' => array(



								'title'   => esc_attr__('Media Block Width','dpr-adeline-extensions'),



								'content' => esc_attr__('Set media block width. ','dpr-adeline-extensions')



							),



							'required' => array('portfolio_single_content_layout','equals',array('details-left','details-right'))



						),



						array(



							'id'       => 'portfolio_single_sticky_columns',



							'type'     => 'switch',



							'title'    =>  esc_html__('Use Sticky Columns','dpr-adeline-extensions'),



							'hint' => array(



								'title'   => esc_attr__('Use Sticky Columns','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Enable or disable sticky columns.','dpr-adeline-extensions')



							),



							'required' => array('portfolio_single_content_layout','equals',array('details-left','details-right'))



						), 



					)



		);		











		$single_portfolio_metabox_sections[] = array(



			'title'    => esc_html__( 'Elements Positioning', 'dpr-adeline-extensions' ),



			'subtitle' => esc_html__( '', 'dpr-adeline-extensions' ),



			'fields'   => array(



						array(



							'id'      => 'portfolio_single_post_style_elements',



							'type'    => 'sorter',



							'title'   => 'Single Portfolio Elements Order',



							'hint' => array(



								'title'   => esc_attr__('Single Portfolio Elements Order','dpr-adeline-extensions'),



								'content' => esc_attr__('Enable or disable display of certain elements for single portfolio item and set element order','dpr-adeline-extensions')



							),



							'options' => array(



								'enabled'  => array(



									'media' => 'Featured Image',



									'title'   => 'Title',



									'meta' => 'Meta Data',



									'content'     => 'Content',



									'tags' => 'Tags',



									'share' => 'Social Share',



									'next_prev' => 'Next Prev Links',



									'related_portfolio' => 'Related Portfolios',



									'comments' => 'Comments',



								),



								'disabled' => array(



								)



							),



							'required' => array('portfolio_single_content_layout','equals','post')



						),



						array(



							'id'      => 'portfolio_single_meta',



							'type'    => 'sorter',



							'title'   => 'Single Post Meta Data Order',



							'hint' => array(



								'title'   => esc_attr__('Single Poportfolio Meta Data Order','dpr-adeline-extensions'),



								'content' => esc_attr__('Enable or disable meta data display for single portfolio and set meta data order','dpr-adeline-extensions')



							),



							'options' => array(



								'enabled'  => array(



									'date' => 'Date',



									'author'   => 'Author',



									'category' => 'Category',



									'comments'     => 'Comments'



								),



								'disabled' => array(



								)



							),



							'required' => array('portfolio_single_content_layout','equals','post')



						),



						array(



							'id'      => 'portfolio_single_elements',



							'type'    => 'sorter',



							'title'   => 'Single Portfolio Elements Order',



							'hint' => array(



								'title'   => esc_attr__('Single Portfolio Elements Order','dpr-adeline-extensions'),



								'content' => esc_attr__('Enable or disable display of certain elements for single portfolio item and set element order','dpr-adeline-extensions')



							),



							'options' => array(



								'enabled'  => array(



									'media_details' => 'Media & Details Description',



									'next_prev' => 'Next Prev Links',



									'related_portfolio' => 'Related Portfolios',



									'comments' => 'Comments',



								),



								'disabled' => array(									



								'content'     => 'Content',



								)



							),



							'required' => array('portfolio_single_content_layout','not','post')



						),



						array(



							'id'       => 'portfolio_single_tags',



							'type'     => 'switch',



							'title'    =>  esc_html__('Display Tags? ','dpr-adeline-extensions'),



							'hint' => array(



								'title'   => esc_attr__('Display Tags?','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Enable or disable display of tags.','dpr-adeline-extensions')



							),



							'required' => array('portfolio_single_content_layout','not','post')



						),



						array(



							'id'       => 'portfolio_single_share',



							'type'     => 'switch',



							'title'    =>  esc_html__('Display Social Share Buttons? ','dpr-adeline-extensions'),



							'hint' => array(



								'title'   => esc_attr__('Display Social Share Buttons?','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Enable or disable display of social share links.','dpr-adeline-extensions')



							),



							'required' => array('portfolio_single_content_layout','not','post')



						),



			



			)	



		



		);



		



		$single_portfolio_metabox_sections[] = array(



			'title'    => esc_html__( 'Media Block Setting', 'dpr-adeline-extensions' ),



			'subtitle' => esc_html__( '', 'dpr-adeline-extensions' ),



			'fields' => array(



						array (



							'id' => 'portfolio_single_media_type',



							'type' => 'image_select',



							'title' => __('Media Block Content Type', 'dpr-adeline-extensions'),



							'required' => array('portfolio_single_content_layout','not','post'),



							'options' => array (



								'image' => array (



									'title' => esc_html__('Featured Image', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/portfolio/media_image.png'



								),					



								'carousel' => array (



									'title' => esc_html__('Carousel', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/portfolio/media_carousel.png'



								),



								'grid' => array (



									'title' => esc_html__('Image Grid', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/portfolio/media_grid.png'



								),



								'video' => array (



									'title' => esc_html__('Video', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/portfolio/media_video.png'



								),



								'audio' => array (



									'title' => esc_html__('Audio', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/portfolio/media_audio.png'



								),



								'particle' => array (



									'title' => esc_html__('Particle', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/portfolio/media_particle.png'



								),



							),



							'hint' => array (



								'title' => esc_attr__('Media Block Content Type', 'dpr-adeline-extensions'),



								'content' => esc_attr__('Choose default media type for portfolio. You can allways overwrite it for certain portfolio items.', 'dpr-adeline-extensions')



							)



						),



						array(



							'id'        => 'portfolio_single_multiple_images',



							'type'      => 'multi_media',



							'title'		=> 'Portfolio Item Additional Images',



							'desc'     => wp_kses_post(__('<small><i>This images can be used in carousel or image grid.</i></small>', 'dpr-adeline-extensions')),



							'required' => array('portfolio_single_media_type','equals',array('carousel','grid')),



							'labels'    => array(



								'upload_file'       => __('Select File(s)', 'dpr-adeline-extensions'),



								'remove_image'      => __('Remove Image', 'dpr-adeline-extensions'),



								'remove_file'       => __('Remove', 'dpr-adeline-extensions'),



								'file'              => __('File: ', 'dpr-adeline-extensions'),



								'download'          => __('Download', 'dpr-adeline-extensions'),



								'title'             => __('Portfolio Item Images', 'dpr-adeline-extensions'),



								'button'            => __('Add Images','dpr-adeline-extensions')



							),



							'library_filter'  => array('gif','jpg','png'),



							'hint' => array (



								'title' => esc_attr__('Portfolio Item Additional Images', 'dpr-adeline-extensions'),



								'content' => esc_attr__('This images can be used in carousel or image grid.', 'dpr-adeline-extensions')



							)



						),



						array(



							'id'       => 'porfolio_single_gallery_columns',



							'type'     => 'slider', 



							'title'    => __('Gallery Columns Count', 'dpr-adeline-extensions'),



							'default'  => '3',



							'min'      => '1',



							'step'     => '1',



							'max'      => '6',



							'hint' => array(



								'title'   => esc_attr__('Gallery Columns Count','dpr-adeline-extensions'),



								'content' => esc_attr__('Set columns count in gallery.','dpr-adeline-extensions')



							),



							'required' => array('portfolio_single_media_type','equals',array('grid')),



						),



						array(



							'id'       => 'porfolio_single_gallery_gap',



							'type'     => 'slider', 



							'title'    => __('Items Gap (px)', 'dpr-adeline-extensions'),



							'default'  => '0',



							'min'      => '0',



							'step'     => '1',



							'max'      => '80',



							'hint' => array(



								'title'   => esc_attr__('Items Gap (px)','dpr-adeline-extensions'),



								'content' => esc_attr__('Set gallery items gap.','dpr-adeline-extensions')



							),



							'required' => array('portfolio_single_media_type','equals',array('grid')),



						),



						array(



							'id'       => 'porfolio_single_gallery_isotope_style',



							'type'     => 'radio',



							'title'    => __('Gallery Style', 'dpr-adeline-extensions'), 



							'required' => array('portfolio_single_media_type','equals',array('grid')),



							'options'  => array(



								'fitRows' => 'Fit Rows', 



								'masonry' => 'Massonry'



							),



							'default' => 'fitRows',



							'hint' => array(



								'title'   => esc_attr__('Gallery Style','dpr-adeline-extensions'),



								'content' => esc_attr__('Use equal rows or massonry style','dpr-adeline-extensions')



							),



						),



						array(



							'id'       => 'portfolio_single_gallery_lightbox',



							'type'     => 'switch',



							'title'    =>  esc_html__('Use Lightbox? ','dpr-adeline-extensions'),



							'hint' => array(



								'title'   => esc_attr__('Use Lightbox?','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Enable or disable lightbox usage for this gallery.','dpr-adeline-extensions')



							),



							'required' => array('portfolio_single_media_type','equals',array('carousel','grid')),



							'default' => false



							



						),



						array(



							'id'       => 'single_portfolio_oembed_video_url',



							'type'     => 'text',



							'title'    => __('oEmbed Video URL ', 'dpr-adeline-extensions'), 



							'desc'     => __('Enter a video URL that is compatible with WordPress built-in oEmbed feature.<br/><a href="http://codex.wordpress.org/Embeds" target="_blank">Learn More</a>', 'dpr-adeline-extensions'),



							'default' => '',



							'required' => array('portfolio_single_media_type','equals','video'),



						),



						array(



							'id' => 'single_portfolio_self_hosted_video_url',



							'type' => 'media',



							'title' => esc_html__('Self Hosted Video', 'dpr-adeline-extensions'),



							'url' => true,



							'mode' => false,



							'readonly' => false,



							'preview' => false,



							'desc'     => __('Enter your self hosted video URL<br/><a href="http://make.wordpress.org/core/2013/04/08/audio-video-support-in-core/" target="_blank">Learn More</a>', 'dpr-adeline-extensions'),



							'required' => array('portfolio_single_media_type','equals','video'),



						),



						array(



							'id'       => 'single_portfolio_video_embeded_code',



							'title'    =>  __( 'Embed Code', 'dpr-adeline-extensions' ),



							'type'     => 'textarea',



							'default'  => '',



							'desc'     => __('Enter your embed/iframe code<br/><a href="https://wordpress.org/plugins/iframe/" target="_blank">Learn More</a>', 'dpr-adeline-extensions'),



							'required' => array('portfolio_single_media_type','equals','video'),



						),



						array(



							'id'       => 'single_portfolio_oembed_audio_url',



							'type'     => 'text',



							'title'    => __('oEmbed Audio URL ', 'dpr-adeline-extensions'), 



							'desc'     => __('Enter a audio URL that is compatible with WordPress built-in oEmbed feature.<br/><a href="http://codex.wordpress.org/Embeds" target="_blank">Learn More</a>', 'dpr-adeline-extensions'),



							'default' => '',



							'required' => array('portfolio_single_media_type','equals','audio'),



						),



						array(



							'id' => 'single_portfolio_self_hosted_audio_url',



							'type' => 'media',



							'title' => esc_html__('Self Hosted Audio', 'dpr-adeline-extensions'),



							'url' => true,



							'mode' => false,



							'readonly' => false,



							'preview' => false,



							'desc'     => __('Enter your self hosted audio URL<br/><a href="http://make.wordpress.org/core/2013/04/08/audio-video-support-in-core/" target="_blank">Learn More</a>', 'dpr-adeline-extensions'),



							'required' => array('portfolio_single_media_type','equals','audio'),



						),



						array(



							'id'       => 'single_portfolio_audio_embed_code',



							'title'    =>  __( 'Embed Code', 'dpr-adeline-extensions' ),



							'type'     => 'textarea',



							'default'  => '',



							'desc'     => __('Enter your embed/iframe code<br/><a href="https://wordpress.org/plugins/iframe/" target="_blank">Learn More</a>', 'dpr-adeline-extensions'),



							'required' => array('portfolio_single_media_type','equals','audio'),



						),



						array(



							'id' => 'single_portfolio_media_particle',



							'type'     => 'select',



							'data'     => 'posts',



							'args' => array('post_type' => array('dpr_particle'), 'posts_per_page' => -1),



							'title' => esc_html__('Particle For Media Block', 'dpr-adeline-extensions'),



							'desc' => __('Please note that you need first create custom content as particle in Particles menu'),



							'hint' => array(



								'title'   => esc_attr__('Select a Particle','dpr-adeline-extensions'),



								'content' => esc_attr__('Create custom media block particle first.','dpr-adeline-extensions')



							),



							'required' => array('portfolio_single_media_type','equals','particle'),



						),



			)



		);



		$single_portfolio_metabox_sections[] = array(



			'title'    => esc_html__( 'Custom Fields Settings', 'dpr-adeline-extensions' ),



			'subtitle' => esc_html__( '', 'dpr-adeline-extensions' ),



			'fields' => array(



						array(



							'id'       => 'porfolio_single_description_1_title',



							'type'     => 'text',



							'title'    => __('Custom Field 1 Title', 'dpr-adeline-extensions'),



							'required' => array('portfolio_single_content_layout','not','post'),



							'hint' => array(



								'title'   => esc_attr__('Custom Field 1 Title','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Set title for first custom description field in portfolio item.','dpr-adeline-extensions')



							),



						),



						array(



							'id'       => 'porfolio_single_description_1_content',



							'type'     => 'textarea',



							'title'    => __('Custom Field 1 Content', 'dpr-adeline-extensions'),



							'required' => array('portfolio_single_content_layout','not','post'),



							'hint' => array(



								'title'   => esc_attr__('Custom Field 1 Content','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Set content for this field. If you leave it blank field will be not displayed.','dpr-adeline-extensions')



							),



						),



						array(



							'id'       => 'porfolio_single_description_2_title',



							'type'     => 'text',



							'title'    => __('Custom Field 2 Title', 'dpr-adeline-extensions'),



							'required' => array('portfolio_single_content_layout','not','post'),



							'hint' => array(



								'title'   => esc_attr__('Custom Field 2 Title','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Set title for second custom description field in portfolio item.','dpr-adeline-extensions')



							),



						),



						array(



							'id'       => 'porfolio_single_description_2_content',



							'type'     => 'textarea',



							'title'    => __('Custom Field 2 Content', 'dpr-adeline-extensions'),



							'required' => array('portfolio_single_content_layout','not','post'),



							'hint' => array(



								'title'   => esc_attr__('Custom Field 2 Content','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Set content for this field. If you leave it blank field will be not displayed.','dpr-adeline-extensions')



							),



						),



						array(



							'id'       => 'porfolio_single_description_3_title',



							'type'     => 'text',



							'title'    => __('Short Info Block Title', 'dpr-adeline-extensions'),



							'required' => array('portfolio_single_content_layout','not','post'),



							'default'  => 'Additional',



							'hint' => array(



								'title'   => esc_attr__('Custom Field 3 Title','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Set title for third custom description field in portfolio item.','dpr-adeline-extensions')



							),



						),



						array(



							'id'       => 'porfolio_single_description_short_1_title',



							'type'     => 'text',



							'title'    => __('Short Info Field 1 Title', 'dpr-adeline-extensions'),



							'required' => array('portfolio_single_content_layout','not','post'),



							'default'  => 'Client',



							'hint' => array(



								'title'   => esc_attr__('Short Info Field Title 1','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Set title for first short info field.','dpr-adeline-extensions')



							),



						),



						array(



							'id'       => 'porfolio_single_description_short_1_content',



							'type'     => 'text',



							'title'    => __('Short Info Field 1 Content', 'dpr-adeline-extensions'),



							'required' => array('portfolio_single_content_layout','not','post'),



							'hint' => array(



								'title'   => esc_attr__('Short Info Field 1 Content','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Set content for this field. If you leave it blank field will be not displayed.','dpr-adeline-extensions')



							),



						),



						array(



							'id'       => 'porfolio_single_description_short_2_title',



							'type'     => 'text',



							'title'    => __('Short Info Field 2 Title', 'dpr-adeline-extensions'),



							'required' => array('portfolio_single_content_layout','not','post'),



							'default'  => 'Date',



							'hint' => array(



								'title'   => esc_attr__('Short Info Field 2 Title','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Set title for second short info field.','dpr-adeline-extensions')



							),



						),



						array(



							'id'       => 'porfolio_single_description_short_2_content',



							'type'     => 'text',



							'title'    => __('Short Info Field 2 Content', 'dpr-adeline-extensions'),



							'required' => array('portfolio_single_content_layout','not','post'),



							'hint' => array(



								'title'   => esc_attr__('Short Info Field 2 Content','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Set content for this field. If you leave it blank field will be not displayed.','dpr-adeline-extensions')



							),



						),



						array(



							'id'       => 'porfolio_single_description_short_3_title',



							'type'     => 'text',



							'title'    => __('Short Info Field 3 Title', 'dpr-adeline-extensions'),



							'required' => array('portfolio_single_content_layout','not','post'),



							'default'  => 'Website',



							'hint' => array(



								'title'   => esc_attr__('Short Info Field 3 Title','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Set title for short info field.','dpr-adeline-extensions')



							),



						),



						array(



							'id'       => 'porfolio_single_description_short_3_content',



							'type'     => 'text',



							'title'    => __('Short Info Field 3 Content', 'dpr-adeline-extensions'),



							'required' => array('portfolio_single_content_layout','not','post'),



							'hint' => array(



								'title'   => esc_attr__('Short Info Field 3 Content','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Set content for this field. If you leave it blank field will be not displayed.','dpr-adeline-extensions')



							),



						),



						array(



							'id'       => 'porfolio_single_action_button_title',



							'type'     => 'text',



							'title'    => __('Action Button Title', 'dpr-adeline-extensions'),



							'required' => array('portfolio_single_content_layout','not','post'),



							'default'  => 'See More',



							'hint' => array(



								'title'   => esc_attr__('Related Projects Block Title','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Set title for related projects block.','dpr-adeline-extensions')



							),



						),



						array(



							'id'       => 'porfolio_single_action_button_link',



							'type'     => 'text',



							'title'    => __('Action Button Link', 'dpr-adeline-extensions'),



							'required' => array('portfolio_single_content_layout','not','post'),



							'hint' => array(



								'title'   => esc_attr__('Action Button Link','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Set link for button. If you leave it blank field will be not displayed.','dpr-adeline-extensions')



							),



						),



						array(



							'id'       => 'porfolio_single_action_button_link_target',



							'type'     => 'radio',



							'title'    => __('Action Button Link Target', 'dpr-adeline-extensions'), 



							'required' =>	array('porfolio_single_action_button_link','not',''),



							'options'  => array(



								'_self' => 'The Same Window', 



								'_blank' => 'New Window'



							),



							'default' => '_self',



							'hint' => array(



								'title'   => esc_attr__('Action Button Link Target','dpr-adeline-extensions'),



								'content' => esc_attr__('Set link target','dpr-adeline-extensions')



							),



						),



			)



		);



		$single_portfolio_metabox_sections[] = array(



			'title'    => esc_html__( 'Related Projects Settings', 'dpr-adeline-extensions' ),



			'subtitle' => esc_html__( '', 'dpr-adeline-extensions' ),



			'fields' => array(



						array(



							'id'       => 'porfolio_single_related_title',



							'type'     => 'text',



							'title'    => __('Related Portfolios Block Title', 'dpr-adeline-extensions'),



							'default'  => 'Related Projects',



							'hint' => array(



								'title'   => esc_attr__('Related Projects Block Title','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Set title for related projects block.','dpr-adeline-extensions')



							),



						),



						array(



							'id'       => 'portfolio_single_related_count',



							'type'     => 'slider', 



							'title'    => __('Related Projects Count', 'dpr-adeline-extensions'),



							'default'  => '3',



							'min'      => '1',



							'step'     => '1',



							'max'      => '12',



							'hint' => array(



								'title'   => esc_attr__('Related Projects Count','dpr-adeline-extensions'),



								'content' => esc_attr__('Set max count of related projects to display.','dpr-adeline-extensions')



							)



						),



						array(



							'id'       => 'porfolio_single_related_columns',



							'type'     => 'slider', 



							'title'    => __('Related Projects Columns', 'dpr-adeline-extensions'),



							'default'  => '3',



							'min'      => '1',



							'step'     => '1',



							'max'      => '6',



							'hint' => array(



								'title'   => esc_attr__('Related Projects Columns','dpr-adeline-extensions'),



								'content' => esc_attr__('Set columns count in related projects section.','dpr-adeline-extensions')



							)



						),



						array(



						'id' => 'porfolio_single_related_image_width',



						'type' => 'dimensions',



						'title' => esc_html__('Related Projets Image Custom Width (px)', 'dpr-adeline-extensions'),



						'width' => true,



						'height' => false,



						'mode' => array ('width' => 'width', 'height' => 'height'),



						'units' => array('px'),



						'default'  => array(



							'width' => ''



						),



						'hint' => array(



							'title'   => esc_attr__('Related Projets Image Custom Width','dpr-adeline-extensions'),



							'content' => esc_attr__('Specify the custom image width in related projets section. In combination with custom image height bellow you can set custom featured image aspect ratio. If you leave this fields blank will be used original images size and aspect ratio.','dpr-adeline-extensions')



						)



						),



						array(



						'id' => 'porfolio_single_related_image_height',



						'type' => 'dimensions',



						'title' => esc_html__('Related Projects Image Custom Height (px)', 'dpr-adeline-extensions'),



						'width' => false,



						'height' => true,



						'mode' => array ('width' => 'width', 'height' => 'height'),



						'units' => array('px'),



						'default'  => array(



							'width' => ''



						),



						'hint' => array(



							'title'   => esc_attr__('Related Projects Image Custom Height','dpr-adeline-extensions'),



							'content' => esc_attr__('Specify the custom image image height in related projects section. In combination with custom image width above you can set custom featured image aspect ratio. If you leave this fields blank will be used original images size and aspect ratio.','dpr-adeline-extensions')



						)



						),



			



			)



		);		















		return $single_portfolio_metabox_sections;



    }



    



endif;