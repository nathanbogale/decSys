<?php



/**



 * Header Options -> Logo



 * 



 */







	Redux::setSection( $opt_name, array(



		'title' => esc_html__('Logo', 'dpr-adeline-extensions'),



		'id' => 'header_logo',



		'subsection' => true,



		'fields' => array(
		
		
					array(



					'id' => 'logo_max_width',



					'type' => 'dimensions',



					'title' => esc_html__('Logo Max Width (px)', 'dpr-adeline-extensions'),



					'output' => array('width' => '#dpr-logo #dpr-logo-inner a img'),



					'width' => true,



					'height' => false,



					'mode' => array ('width' => 'max-width','height'=>'max-height'),



					'units' => array('px'),



					'default'  => array(



						'width' => '181px'



					),



					'hint' => array(



						'title'   => esc_attr__('Logo Max Width','dpr-adeline-extensions'),



						'content' => esc_attr__('Specify the maximum base width for the theme to be visible on desktop computers.','dpr-adeline-extensions')



					)
					

					),

						array(



							'id' => 'logo_max_height',



							'type' => 'dimensions',



							'title' => esc_html__('Logo Max Height (px)', 'dpr-adeline-extensions'),



							'output' => array('height' => '#dpr-logo #dpr-logo-inner a img'),



							'width' => false,



							'height' => true,



							'mode' => array ('width' => 'max-width','height' => 'max-height'),



							'units' => array('px'),



							'default'  => array(



								'height' => '45px'



							),



							'hint' => array(



								'title'   => esc_attr__('Logo Max Height','dpr-adeline-extensions'),



								'content' => esc_attr__('Specify logo max height.','dpr-adeline-extensions')



							)

							),


						array(



							'id' => 'logo_default',



							'type' => 'media',



							'title' => esc_html__('Default Logo', 'dpr-adeline-extensions'),



							'default' => array(



											'url' => $assets_folder . 'img/logo/logo.png'



										),



							'hint' => array(



								'title'   => esc_attr__('Default Logo','dpr-adeline-extensions'),



								'content' => esc_attr__('Select image for default logo','dpr-adeline-extensions')



							)



						),



						array(



							'id' => 'logo_default_retina',



							'type' => 'media',



							'title' => esc_html__('Default Logo Retina', 'dpr-adeline-extensions'),



							'default' => array(



											'url' => $assets_folder . 'img/logo/logox2.png'



										),



							'hint' => array(



								'title'   => esc_attr__('Default Logo Retina','dpr-adeline-extensions'),



								'content' => esc_attr__('Select image for default retina logo','dpr-adeline-extensions')



							)



						),



						array(



							'id' => 'logo_overlapping_light',



							'type' => 'media',



							'title' => esc_html__('Overlapping Logo Light', 'dpr-adeline-extensions'),



							'default' => array(),



							'hint' => array(



								'title'   => esc_attr__('Overlapping Logo Light','dpr-adeline-extensions'),



								'content' => esc_attr__('Select logo image for overlapping header with dark background. Used in light overlapping style.','dpr-adeline-extensions')



							)



						),



						array(



							'id' => 'logo_overlapping_light_retina',



							'type' => 'media',



							'title' => esc_html__('Overlapping Logo Light  Retina', 'dpr-adeline-extensions'),



							'default' => array(),



							'hint' => array(



								'title'   => esc_attr__('Overlapping Logo Light Retina','dpr-adeline-extensions'),



								'content' => esc_attr__('Select retina logo image for overlapping header with dark background. Used in light overlapping style.','dpr-adeline-extensions')



							)



						),



						array(



							'id' => 'logo_overlapping_dark',



							'type' => 'media',



							'title' => esc_html__('Overlapping Logo Dark', 'dpr-adeline-extensions'),



							'default' => array(),



							'hint' => array(



								'title'   => esc_attr__('Overlapping Logo Dark','dpr-adeline-extensions'),



								'content' => esc_attr__('Select logo image for overlapping header with light background. Used in dark overlapping style.','dpr-adeline-extensions')



							)



						),



						array(



							'id' => 'logo_overlapping_dark_retina',



							'type' => 'media',



							'title' => esc_html__('Overlapping Logo Dark  Retina', 'dpr-adeline-extensions'),



							'default' => array(),



							'hint' => array(



								'title'   => esc_attr__('Overlapping Logo Dark Retina','dpr-adeline-extensions'),



								'content' => esc_attr__('Select retina logo image for overlapping header with light background. Used in dark overlapping style.','dpr-adeline-extensions')



							)



						),







					)



	));



