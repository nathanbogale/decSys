<?php

// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}

/*

* Add-on Name: Animated Text

*/



class WPBakeryShortCode_DPR_Animated_Svg extends WPBakeryShortCode {}





vc_map(

	array(

		'name'					=> esc_html__('DP Animated SVG', 'dpr-adeline-extensions'),

		'base'					=> 'dpr_animated_svg',

		"icon"					=> 'icon-dpr-animated-svg',

		"class"					=> 'dpr_animated_svg',

  		"category" =>array( esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions')),

		'description'			=> esc_html__('Display animated SVG', 'dpr-adeline-extensions'),

		'params'				=> array(

										array(

											'type'				=> 'attach_image',

											'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Upload your SVG from media library.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Upload SVG', 'dpr-adeline-extensions'),

											'param_name'		=> 'svg_id',

											'admin_label'		=> true,

											'description'		=> esc_html__('You can use the amazing ', 'dpr-adeline-extensions').'<a href="https://jakearchibald.github.io/svgomg/" target="_blank">SVGOMG</a>'.esc_html__(' to clean your SVG before uploading here', 'dpr-adeline-extensions'),

										),

										array(

											'type'				=> 'dpr_radio',

											'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose draw animation type.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('SVG Animation Type', 'dpr-adeline-extensions'),

											'param_name'		=> 'animation_type',

											'value'				=> 'delayed',

											'options'			=> array(

												esc_html__("Delayed", 'dpr-adeline-extensions') => "delayed",

												esc_html__("Sync", 'dpr-adeline-extensions') => "sync",

												esc_html__("One-By-One", 'dpr-adeline-extensions') => "oneByOne",

												esc_html__("Scenarize", 'dpr-adeline-extensions') => "scenario-sync"

											),

											'description'		=> esc_html__('You can choose from different options of SVG draw animation. Test that here ', 'dpr-adeline-extensions').'<a href="http://maxwellito.github.io/vivus/" target="_blank">VIVUS</a>'.esc_html__(' SVG Animation Type', 'dpr-adeline-extensions')



										),

										array(

											'type'				=> 'number',

											'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set SVG draw Animation Duration.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Animation Duration', 'dpr-adeline-extensions'),

											'param_name'		=> 'animation_duration',

											'min'				=> 1,

											'value' 			=> '1000',

											'suffix'				=> 'ms',

											'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

										),

										array(

											'type'				=> 'dpr_radio',

											'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to choose the horizontal alignment for the SVG.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('SVG Alignment', 'dpr-adeline-extensions'),

											'param_name'		=> 'svg_alignment',

											'value'				=> 'text-center',

											'options'			=> array(

												esc_html__('Left', 'dpr-adeline-extensions')	=> 'text-left',

												esc_html__('Center', 'dpr-adeline-extensions')	=> 'text-center',

												esc_html__('Right', 'dpr-adeline-extensions')	=> 'text-right'

											),

											'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

										),

										array(

											'type' => 'colorpicker',

											'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('You can Choose SVG&#39;s drawing color (Stroke in Normal Terms Border Color).', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Drawing Color', 'dpr-adeline-extensions'),

											'edit_field_class' => 'vc_col-xs-6',

											'param_name' => 'draw_color',

											"value" => '#D3AE5F',

											'admin_label' => false,

											'edit_field_class'	=> 'vc_col-sm-6 vc_column '

										),

										array(

											"type" => "textfield",

											'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('You can setup Maximum Width of SVG here in Percentage or in Pixels from this option.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Maximum Width', 'dpr-adeline-extensions'),

											"param_name" => "max_width",

											"value" => '100%',

											'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

											'admin_label' => false

										),

										/*EXTRA FEATURES */

										array(

											'type'             => 'dpr_title',

											'text'             => esc_html__( 'Additional Settings', 'dpr-adeline-extensions' ),

											'param_name'       => 'extra_features_title',

											'edit_field_class' => 'vc_column vc_col-sm-12',

										),

										vc_map_add_css_animation( false ),

										array(

											'type' => 'textfield',

											'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Extra Class Name', 'dpr-adeline-extensions'),

											'param_name' => 'el_class',

										),

										array(

											'type' => 'css_editor',

											'heading' => __( 'CSS box', 'dpr-adeline-extensions' ),

											'param_name' => 'css',

											'group' => __( 'Design Options', 'dpr-adeline-extensions' ),

										),

									),

									

	)

);