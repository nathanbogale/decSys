<?php

/**



 * Expandable Panel Options



 *



 */

Redux::setSection($opt_name, array(

    'title'  => __('Expandable Side Panel', 'dpr-adeline-extensions'),

    'id'     => 'expandable_panel_tab',

    'icon'   => 'el el-circle-arrow-left',

    'fields' => array(

        array(

            'id'      => 'expandable_panel',

            'type'    => 'switch',

            'default' => false,

            'title'   => esc_html__('Use Expandable Panel', 'dpr-adeline-extensions'),

        ),

        array(

            'id'       => 'side_panel_position',

            'type'     => 'radio',

            'title'    => __('Side Panel Position', 'dpr-adeline-extensions'),

            'options'  => array(

                'left'  => 'Left',

                'right' => 'Right',

            ),

            'default'  => 'right',

            'hint'     => array(

                'title'   => esc_attr__('Side Panel Position', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set expandable side panel position. ', 'dpr-adeline-extensions'),

            ),

            'required' => array('expandable_panel', 'equals', '1'),

        ),

        array(

            'id'       => 'panel_width',

            'type'     => 'dimensions',

            'title'    => esc_html__('Side Panel Width', 'dpr-adeline-extensions'),

            'width'    => true,

            'height'   => false,

            'mode'     => array('width' => 'width', 'height' => 'height'),

            'units'    => array('px'),

            'default'  => array(

                'width' => '300px',

            ),

            'hint'     => array(

                'title'   => esc_attr__('Side Panel Width', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set expandable side panel width (px).', 'dpr-adeline-extensions'),

            ),

            'required' => array('expandable_panel', 'equals', '1'),

        ),

        array(

            'id'       => 'panel_width_tablet',

            'type'     => 'dimensions',

            'title'    => esc_html__('Side Panel Width: Tablet', 'dpr-adeline-extensions'),

            'width'    => true,

            'height'   => false,

            'mode'     => array('width' => 'width', 'height' => 'height'),

            'units'    => array('px'),

            'default'  => array(

                'width' => '',

            ),

            'hint'     => array(

                'title'   => esc_attr__('Side Panel Width (tablet)', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set expandable side panel custom width for tablet (px).', 'dpr-adeline-extensions'),

            ),

            'required' => array('expandable_panel', 'equals', '1'),

        ),

        array(

            'id'       => 'panel_width_mobile',

            'type'     => 'dimensions',

            'title'    => esc_html__('Side Panel Width: Mobile', 'dpr-adeline-extensions'),

            'width'    => true,

            'height'   => false,

            'mode'     => array('width' => 'width', 'height' => 'height'),

            'units'    => array('px'),

            'default'  => array(

                'width' => '',

            ),

            'hint'     => array(

                'title'   => esc_attr__('Side Panel Width (mobile)', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set expandable side panel custom width for mobile devices (px).', 'dpr-adeline-extensions'),

            ),

            'required' => array('expandable_panel', 'equals', '1'),

        ),

        array(

            'id'       => 'hide_breakpoint',

            'type'     => 'select',

            'title'    => esc_html__('Breakpoint', 'dpr-adeline-extensions'),

            'desc'     => '<i>Choose the screen width where you want to hide the side panel.</i>',

            'options'  => array(

                'none'   => esc_html__('Never hide the side panel', 'dpr-adeline-extensions'),

                '1280'   => esc_html__('From 1280px', 'dpr-adeline-extensions'),

                '1080'   => esc_html__('From 1080px', 'dpr-adeline-extensions'),

                '959'    => esc_html__('From 959px', 'dpr-adeline-extensions'),

                '767'    => esc_html__('From 767px', 'dpr-adeline-extensions'),

                '480'    => esc_html__('From 480px', 'dpr-adeline-extensions'),

                '320'    => esc_html__('From 320px', 'dpr-adeline-extensions'),

                'custom' => esc_html__('Custom width', 'dpr-adeline-extensions'),

            ),

            'default'  => '959',

            'hint'     => array(

                'title'   => esc_attr__('Brekpoint', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Choose the screen width where you want to hide the side panel. ', 'dpr-adeline-extensions'),

            ),

            'required' => array('expandable_panel', 'equals', '1'),

        ),

        array(

            'id'       => 'custom_hide_breakpoint',

            'type'     => 'dimensions',

            'title'    => esc_html__('Custom Breakpoint', 'dpr-adeline-extensions'),

            'desc'     => '<i>Choose the screen width where you want to hide the side panel.</i>',

            'width'    => true,

            'height'   => false,

            'mode'     => array('width' => 'width', 'height' => 'height'),

            'units'    => array('px'),

            'default'  => array(

                'width' => '',

            ),

            'hint'     => array(

                'title'   => esc_attr__('Custom Breakpoint', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set the custom screen width where you want to hide the side panel.', 'dpr-adeline-extensions'),

            ),

            'required' => array('hide_breakpoint', 'equals', 'custom'),

        ),

        array(

            'id'       => 'opener_info',

            'type'     => 'info',

            'style'    => 'dpr-title',

            'required' => array('expandable_panel', 'equals', '1'),

            'title'    => wp_kses_post(__('<h3>Opening Button Style</h3>', 'dpr-adeline-extensions')),

        ),

        array(

            'id'       => 'opening_button_position',

            'type'     => 'radio',

            'title'    => __('Opening Button Position', 'dpr-adeline-extensions'),

            'options'  => array(

                'menu'   => 'Inside the main menu',

                'social'   => 'Beside Social Icons',

                'beside' => 'Beside the panel',

            ),

            'default'  => 'menu',

            'hint'     => array(

                'title'   => esc_attr__('Opening Button Position', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set opening button position (in menu or beside expandable panel). ', 'dpr-adeline-extensions'),

            ),

            'required' => array('expandable_panel', 'equals', '1'),

        ),

        array(

            'id'       => 'opening_button_icon_type',

            'type'     => 'radio',

            'title'    => __('Opening Button Icon Type', 'dpr-adeline-extensions'),

            'options'  => array(

                'icon'  => 'Icon',

                'image' => 'Image',

            ),

            'default'  => 'icon',

            'hint'     => array(

                'title'   => esc_attr__('Opening Button Icon Type', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set opening button icon type (icon custom image or custom HTML for example inline SVG) ', 'dpr-adeline-extensions'),

            ),

            'required' => array('expandable_panel', 'equals', '1'),

        ),

        array(

            'id'       => 'opening_button_icon',

            'type'     => 'dpr_icon_selector',

            'title'    => __('Opening Button Icon', 'dpr-adeline-extensions'),

            'required' => array('opening_button_icon_type', 'equals', 'icon'),

            'default'  => 'Default-exchange',

            'hint'     => array(

                'title'   => esc_attr__('Opening Button Icon', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Select icon.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'opening_button_image',

            'type'     => 'media',

            'title'    => esc_html__('Opening Button Image', 'dpr-adeline-extensions'),

            'required' => array('opening_button_icon_type', 'equals', 'image'),

            'default'  => '',

            'hint'     => array(

                'title'   => esc_attr__('Opening Button Image', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Select image for opening button', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'opening_button_icon_color',

            'type'     => 'color',

            'title'    => __('Button Icon Color', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'output'   => array('color' => '#side-panel-wrap a.side-panel-btn'),

            'hint'     => array(

                'title'   => esc_attr__('Button Icon Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set opening button icon color.', 'dpr-adeline-extensions'),

            ),

            'required' => array('opening_button_position', 'equals', 'beside'),

        ),

        array(

            'id'       => 'opening_button_icon_color_hover',

            'type'     => 'color',

            'title'    => __('Button Icon Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'output'   => array('color' => '#side-panel-wrap a.side-panel-btn:hover'),

            'hint'     => array(

                'title'   => esc_attr__('Button Icon Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set opening button icon color in hover state.', 'dpr-adeline-extensions'),

            ),

            'required' => array('opening_button_position', 'equals', 'beside'),

        ),

        array(

            'id'       => 'opening_button_icon_size',

            'type'     => 'spinner',

            'title'    => __('Opening Button Icon Size (px)', 'dpr-adeline-extensions'),

            'default'  => '20',

            'min'      => '1',

            'step'     => '1',

            'max'      => '100',

            'hint'     => array(

                'title'   => esc_attr__('Opening Button Icon Size', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set opening button icon/image size.', 'dpr-adeline-extensions'),

            ),

            'required' => array('expandable_panel', 'equals', '1'),

        ),

        array(

            'id'       => 'opening_button_text',

            'type'     => 'text',

            'title'    => __('Opening Button Text', 'dpr-adeline-extensions'),

            'default'  => '',

            'hint'     => array(

                'title'   => esc_attr__('Opening Button Text', 'dpr-adeline-extensions'),

                'content' => esc_attr__('You can set here text displayed beside opening icon in menu.', 'dpr-adeline-extensions'),

            ),

            'required' => array('opening_button_position', 'equals', 'menu'),

        ),

        array(

            'id'       => 'opening_button_text_position',

            'type'     => 'radio',

            'title'    => __('Opening Button Text Position', 'dpr-adeline-extensions'),

            'options'  => array(

                'before' => 'Before Icon',

                'after'  => 'After Icon',

            ),

            'default'  => 'after',

            'hint'     => array(

                'title'   => esc_attr__('Opening Button Text Position', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set opening button text position) ', 'dpr-adeline-extensions'),

            ),

            'required' => array('opening_button_position', 'equals', 'menu'),

        ),

        array(

            'id'       => 'opening_button_bg_color',

            'type'     => 'color',

            'title'    => __('Button Background Color', 'dpr-adeline-extensions'),

            'default'  => '#292933',

            'output'   => array('background-color' => '#side-panel-wrap a.side-panel-btn'),

            'hint'     => array(

                'title'   => esc_attr__('Button Background Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set opening button background color.', 'dpr-adeline-extensions'),

            ),

            'required' => array('opening_button_position', 'equals', 'beside'),

        ),

        array(

            'id'       => 'opening_button_bg_color_hover',

            'type'     => 'color',

            'title'    => __('Button Background Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'output'   => array('background-color' => '#side-panel-wrap a.side-panel-btn:hover'),

            'hint'     => array(

                'title'   => esc_attr__('Button Background Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set opening button background color in hover state.', 'dpr-adeline-extensions'),

            ),

            'required' => array('opening_button_position', 'equals', 'beside'),

        ),

        array(

            'id'       => 'panel_info',

            'type'     => 'info',

            'style'    => 'dpr-title',

            'required' => array('expandable_panel', 'equals', '1'),

            'title'    => wp_kses_post(__('<h3>Expandable Panel Style</h3>', 'dpr-adeline-extensions')),

        ),

        array(

            'id'       => 'panel_content_source',

            'type'     => 'radio',

            'title'    => __('Panel Content Source', 'dpr-adeline-extensions'),

            'options'  => array(

                'widgets' => 'Widgets',

                'custom'  => 'Custom Template',

            ),

            'default'  => 'widgets',

            'hint'     => array(

                'title'   => esc_attr__('Panel Content Source', 'dpr-adeline-extensions'),

                'content' => esc_attr__('You can use widgets from "Expandable Panel" widget area  or select custom side panel template created in menu Particles', 'dpr-adeline-extensions'),

            ),

            'required' => array('expandable_panel', 'equals', '1'),

        ),

        array(

            'id'       => 'panel_particle_selected',

            'type'     => 'select',

            'data'     => 'posts',

            'args'     => array('post_type' => array('dpr_particle'), 'posts_per_page' => -1),

            'title'    => esc_html__('Custom Panel Template', 'dpr-adeline-extensions'),

            'desc'     => __('Please note that you need first create custom template in Particles menu'),

            'hint'     => array(

                'title'   => esc_attr__('Panel Template', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Select one of created template in Particles', 'dpr-adeline-extensions'),

            ),

            'required' => array('panel_content_source', 'equals', 'custom'),

        ),

        array(

            'id'             => 'panel_padding',

            'type'           => 'spacing',

            'output'         => array('#side-panel-wrap #side-panel-content'),

            'mode'           => 'padding',

            'units'          => array('px'),

            'display_units'  => true,

            'units_extended' => false,

            'title'          => __('Padding', 'dpr-adeline-extensions'),

            'default'        => array(

                'padding-left'   => '30px',

                'padding-right'  => '30px',

                'padding-top'    => '30px',

                'padding-bottom' => '30px',

                'units'          => 'px',

            ),

            'required'       => array('expandable_panel', 'equals', '1'),

            'hint'           => array(

                'title'   => esc_attr__('Padding', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set panel padding.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'panel_bg_color',

            'type'     => 'color',

            'title'    => __('Panel Background Color', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'output'   => array('background-color' => '#side-panel-wrap'),

            'hint'     => array(

                'title'   => esc_attr__('Panel Background Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set panel background color.', 'dpr-adeline-extensions'),

            ),

            'required' => array('expandable_panel', 'equals', '1'),

        ),

        array(

            'id'       => 'panel_text_color',

            'type'     => 'color',

            'title'    => __('Panel Text Color', 'dpr-adeline-extensions'),

            'default'  => '#555555',

            'output'   => array('color' => '#side-panel-wrap, #side-panel-wrap p, #side-panel-wrap #wp-calendar caption, #side-panel-wrap #wp-calendar th, #side-panel-wrap #wp-calendar td'),

            'hint'     => array(

                'title'   => esc_attr__('Panel Text Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set panel text color.', 'dpr-adeline-extensions'),

            ),

            'required' => array('panel_content_source', 'equals', 'widgets'),

        ),

        array(

            'id'       => 'panel_headings_color',

            'type'     => 'color',

            'title'    => __('Panel Headings Color', 'dpr-adeline-extensions'),

            'default'  => '#292933',

            'output'   => array('color' => '#side-panel-wrap .sidebar-box .panel-widget-title'),

            'hint'     => array(

                'title'   => esc_attr__('Panel Headings Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set panel text color.', 'dpr-adeline-extensions'),

            ),

            'required' => array('panel_content_source', 'equals', 'widgets'),

        ),

        array(

            'id'       => 'panel_link_color',

            'type'     => 'color',

            'title'    => __('Panel links Color', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'output'   => array('color' => '#side-panel-wrap a'),

            'hint'     => array(

                'title'   => esc_attr__('Panel Links Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set panel links color.', 'dpr-adeline-extensions'),

            ),

            'required' => array('panel_content_source', 'equals', 'widgets'),

        ),

        array(

            'id'       => 'panel_link_color_hover',

            'type'     => 'color',

            'title'    => __('Panel links Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '#292933',

            'output'   => array('color' => '#side-panel-wrap a:hover'),

            'hint'     => array(

                'title'   => esc_attr__('Panel Links Color Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set panel links color hover.', 'dpr-adeline-extensions'),

            ),

            'required' => array('panel_content_source', 'equals', 'widgets'),

        ),

        array(

            'id'       => 'panel_close_button',

            'type'     => 'switch',

            'default'  => true,

            'title'    => esc_html__('Display Close Button', 'dpr-adeline-extensions'),

            'hint'     => array(

                'title'   => esc_attr__('Display Close Button', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enabe or disable close button for side panel.', 'dpr-adeline-extensions'),

            ),

            'required' => array('expandable_panel', 'equals', '1'),

        ),

        array(

            'id'       => 'close_button_text',

            'type'     => 'text',

            'title'    => __('Close Button Text', 'dpr-adeline-extensions'),

            'default'  => 'Close Panel',

            'hint'     => array(

                'title'   => esc_attr__('Close Button Text', 'dpr-adeline-extensions'),

                'content' => esc_attr__('You can set here text displayed in lanel close button.', 'dpr-adeline-extensions'),

            ),

            'required' => array('panel_close_button', 'equals', '1'),

        ),

        array(

            'id'       => 'close_button_color',

            'type'     => 'color',

            'title'    => __('Close Button Color', 'dpr-adeline-extensions'),

            'default'  => '#292933',

            'output'   => array('color' => '#side-panel-wrap a.close-panel'),

            'hint'     => array(

                'title'   => esc_attr__('Close Button Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set close button color.', 'dpr-adeline-extensions'),

            ),

            'required' => array('panel_close_button', 'equals', '1'),

        ),

        array(

            'id'       => 'close_button_color_hover',

            'type'     => 'color',

            'title'    => __('Close Button Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'output'   => array('color' => '#side-panel-wrap a.close-panel:hover'),

            'hint'     => array(

                'title'   => esc_attr__('Close Button Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set close button color hover.', 'dpr-adeline-extensions'),

            ),

            'required' => array('panel_close_button', 'equals', '1'),

        ),

        array(

            'id'       => 'close_button_bg',

            'type'     => 'color',

            'title'    => __('Close Button Background Color', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'output'   => array('background-color' => '#side-panel-wrap a.close-panel'),

            'hint'     => array(

                'title'   => esc_attr__('Close Button Background Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set close button color.', 'dpr-adeline-extensions'),

            ),

            'required' => array('panel_close_button', 'equals', '1'),

        ),

        array(

            'id'       => 'close_button_bg_hover',

            'type'     => 'color',

            'title'    => __('Close Button Background Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'output'   => array('background-color' => '#side-panel-wrap a.close-panel:hover'),

            'hint'     => array(

                'title'   => esc_attr__('Close Button Background Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set close button background color hover.', 'dpr-adeline-extensions'),

            ),

            'required' => array('panel_close_button', 'equals', '1'),

        ),

        array(

            'id'       => 'content_overlay',

            'type'     => 'switch',

            'default'  => false,

            'title'    => esc_html__('Use Content Overlay', 'dpr-adeline-extensions'),

            'hint'     => array(

                'title'   => esc_attr__('Use Content Overlay', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enable content overlay when side panel active .', 'dpr-adeline-extensions'),

            ),

            'required' => array('expandable_panel', 'equals', '1'),

        ),

        array(

            'id'       => 'overlay_color',

            'type'     => 'color',

            'title'    => __('Content Overlay Color', 'dpr-adeline-extensions'),

            'default'  => 'rgba(18, 26, 36, 0.7)',

            'output'   => array('background-color' => '.dpr-sp-overlay'),

            'hint'     => array(

                'title'   => esc_attr__('Content Overlay Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set content overlay color.', 'dpr-adeline-extensions'),

            ),

            'required' => array('content_overlay', 'equals', '1'),

        ),

        array(

            'id'       => 'content_displace',

            'type'     => 'switch',

            'default'  => true,

            'title'    => esc_html__('Use Content Displace', 'dpr-adeline-extensions'),

            'hint'     => array(

                'title'   => esc_attr__('Use Content Displace', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enable content displace when side panel active.', 'dpr-adeline-extensions'),

            ),

            'required' => array('expandable_panel', 'equals', '1'),

        ),

    ),

));
