<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

wp_enqueue_script( 'dpr_parralax_js', DPR_EXTENSIONS_PLUGIN_URL . 'vc-extend/assets/frontend/js/dpr.parallax.js', false, true);

$parallax_layers = (array) vc_param_group_parse_atts( $atts['dpr_parallax_layers'] );

foreach ( $parallax_layers as $k => $l ) {
			$layer_data_atts = $layer_style = '';
			if ( ! empty( $l['dpr_layer_parallax_image'] ) ) {
				$layer_bg_image_src = dpr_get_attachment_image_src($l['dpr_layer_parallax_image'], 'full');
				$layer_bg_image = $layer_bg_image_src[0];
				$layer_style = 'style="background-image: url('.esc_url($layer_bg_image).')"';
				
				if ( ! empty( $l['dpr_layer_parallax_type'] ) ) {
					$layer_data_atts .= 'data-paroller-direction="'.$l['dpr_layer_parallax_type'].'"';
				}
				
				if ( ! empty( $l['dpr_layer_parallax_fator'] ) ) {
					$layer_data_atts .= ' data-paroller-factor="'.$l['dpr_layer_parallax_fator'].'"';
				}

				$output .= '<div class="dpr_row_bg_container">';
				
					$output .= '<div class="dpr_row_bg_container_inner dpr_row_bg_image" '.$layer_data_atts.' '.$layer_style.'></div>';
				
				$output .= '</div>';
			
		}
				$output .= '<div class="dpr_row_bg_container">';
				
					$output .= $overlay_output;
				
				$output .= '</div>';
}

