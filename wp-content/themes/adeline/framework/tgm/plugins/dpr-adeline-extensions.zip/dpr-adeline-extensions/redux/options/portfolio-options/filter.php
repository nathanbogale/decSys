<?php

/**



 * Portfolio Options -> Filter Bar



 *



 */

Redux::setSection($opt_name, array(

    'title'      => esc_html__('Filter Bar', 'dpr-adeline-extensions'),

    'id'         => 'portfolio_filter_bar',

    'subsection' => true,

    'fields'     => array(

        array(

            'id'      => 'portfolio_filter',

            'type'    => 'switch',

            'default' => true,

            'title'   => esc_html__('Use Filter?', 'dpr-adeline-extensions'),

            'hint'    => array(

                'title'   => esc_attr__('Use Filter?', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enable or disable display of portfolio item filter.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'portfolio_filter_all_button',

            'type'     => 'switch',

            'default'  => true,

            'required' => array('portfolio_filter', 'equals', '1'),

            'title'    => esc_html__('Display Button ALL?', 'dpr-adeline-extensions'),

            'hint'     => array(

                'title'   => esc_attr__('Display Button All?', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enable or disable display of button ALL in filter.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'portfolio_filter_all_button_text',

            'type'     => 'text',

            'title'    => __('ALL Button Text', 'dpr-adeline-extensions'),

            'default'  => 'All',

            'required' => array('portfolio_filter_all_button', 'equals', '1'),

            'hint'     => array(

                'title'   => esc_attr__('ALL Button Text', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set all button text.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'portfolio_filter_position',

            'type'     => 'radio',

            'title'    => __('Portfolio Filter Position', 'dpr-adeline-extensions'),

            'default'  => 'center',

            'options'  => array(

                'left'   => 'Left',

                'center' => 'Center',

                'right'  => 'Right',

                'full'   => 'Full',

            ),

            'required' => array('portfolio_filter', 'equals', '1'),

            'hint'     => array(

                'title'   => esc_attr__('Portfolio Filter Position', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set default portfolio filter position.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'portfolio_filter_taxonomy',

            'type'     => 'radio',

            'title'    => __('Portfolio Filter Taxonomy', 'dpr-adeline-extensions'),

            'default'  => 'categories',

            'options'  => array(

                'categories' => 'Categories',

                'tags'       => 'Tags',

            ),

            'required' => array('portfolio_filter', 'equals', '1'),

            'hint'     => array(

                'title'   => esc_attr__('Portfolio Filter Taxonomy', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set portfolio filter taxonomy.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'             => 'portfolio_filter_bar_margin',

            'type'           => 'spacing',

            'output'         => array('.portfolio-items .portfolio-filters'),

            'mode'           => 'margin',

            'units'          => array('px'),

            'display_units'  => true,

            'units_extended' => false,

            'title'          => __('Filter Bar Margin (px)', 'dpr-adeline-extensions'),

            'default'        => array(

                'margin-left'   => '0px',

                'margin-right'  => '0px',

                'margin-bottom' => '25px',

                'margin-top'    => '0px',

                'units'         => 'px',

            ),

            'hint'           => array(

                'title'   => esc_attr__('Filter Bar Margin', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Choose default margin for filter bar.', 'dpr-adeline-extensions'),

            ),

            'required'       => array('portfolio_filter', 'equals', '1'),

        ),

        array(

            'id'             => 'portfolio_filter_buttons_margin',

            'type'           => 'spacing',

            'output'         => array('.portfolio-items .portfolio-filters li'),

            'mode'           => 'margin',

            'units'          => array('px'),

            'display_units'  => true,

            'units_extended' => false,

            'title'          => __('Filter Bar Buttons: Margin (px)', 'dpr-adeline-extensions'),

            'default'        => array(

                'margin-left'   => '0px',

                'margin-right'  => '5px',

                'margin-bottom' => '0px',

                'margin-top'    => '0px',

                'units'         => 'px',

            ),

            'hint'           => array(

                'title'   => esc_attr__('Filter Bar Buttons: Margin', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Choose default margin for filter bar buttons.', 'dpr-adeline-extensions'),

            ),

            'required'       => array('portfolio_filter', 'equals', '1'),

        ),

        array(

            'id'             => 'portfolio_filter_buttons_padding',

            'type'           => 'spacing',

            'output'         => array('.portfolio-items .portfolio-filters li a'),

            'mode'           => 'padding',

            'units'          => array('px'),

            'display_units'  => true,

            'units_extended' => false,

            'title'          => __('Filter Bar Buttons: Padding (px)', 'dpr-adeline-extensions'),

            'default'        => array(

                'padding-left'   => '12px',

                'padding-right'  => '12px',

                'padding-bottom' => '8px',

                'padding-top'    => '8px',

                'units'          => 'px',

            ),

            'hint'           => array(

                'title'   => esc_attr__('Filter Bar Buttons: Padding (px)', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Choose default padding for filter bar buttons.', 'dpr-adeline-extensions'),

            ),

            'required'       => array('portfolio_filter', 'equals', '1'),

        ),

        array(

            'id'             => 'portfolio_filter_buttons_border_radius',

            'type'           => 'dpr_border_radius',

            'units'          => array('px', '%'),

            'all'            => true,

            'output'         => array('.portfolio-items .portfolio-filters li a'),

            'units_extended' => false,

            'title'          => __('Filter Bar Buttons: Border Radius', 'dpr-adeline-extensions'),

            'required'       => array('portfolio_filter', 'equals', '1'),

            'default'        => array(

                'border-top-left-radius'     => '5px',

                'border-top-right-radius'    => '5px',

                'border-bottom-right-radius' => '5px',

                'border-bottom-left-radius'  => '5px',

                'units'                      => 'px',

            ),

            'hint'           => array(

                'title'   => esc_attr__('Filter Bar Buttons: Border Radius', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify border radius for filter buttons.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'portfolio_filter_buttons_bg',

            'type'     => 'color',

            'title'    => __('Filter Bar Buttons: Background', 'dpr-adeline-extensions'),

            'default'  => '#e5e5e9',

            'output'   => array('background-color' => '.portfolio-items .portfolio-filters li a'),

            'hint'     => array(

                'title'   => esc_attr__('Filter Bar Buttons: Background', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set background color for filter bar buttons.', 'dpr-adeline-extensions'),

            ),

            'required' => array('portfolio_filter', 'equals', '1'),

        ),

        array(

            'id'       => 'portfolio_filter_buttons_bg_hover',

            'type'     => 'color',

            'title'    => __('Filter Bar Buttons: Background Hover', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'output'   => array('background-color' => '.portfolio-items .portfolio-filters li a:hover, .portfolio-items .portfolio-filters li.active a'),

            'hint'     => array(

                'title'   => esc_attr__('Filter Bar Buttons: Background Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set background color for filter bar buttons hover and active.', 'dpr-adeline-extensions'),

            ),

            'required' => array('portfolio_filter', 'equals', '1'),

        ),

        array(

            'id'       => 'portfolio_filter_buttons_text',

            'type'     => 'color',

            'title'    => __('Filter Bar Buttons Text', 'dpr-adeline-extensions'),

            'default'  => '#292933',

            'output'   => array('.portfolio-items .portfolio-filters li a'),

            'hint'     => array(

                'title'   => esc_attr__('Filter Bar Buttons Text', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set filter bar button text color.', 'dpr-adeline-extensions'),

            ),

            'required' => array('portfolio_filter', 'equals', '1'),

        ),

        array(

            'id'       => 'portfolio_filter_buttons_text_hover',

            'type'     => 'color',

            'title'    => __('Filter Bar Buttons Text: Hover', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'output'   => array('.portfolio-items .portfolio-filters li a:hover, .portfolio-items .portfolio-filters li.active a'),

            'hint'     => array(

                'title'   => esc_attr__('Filter Bar Buttons Text: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set filter bar button text color active nad hover.', 'dpr-adeline-extensions'),

            ),

            'required' => array('portfolio_filter', 'equals', '1'),

        ),

        array(

            'id'       => 'portfolio_filter_buttons_border',

            'type'     => 'color',

            'title'    => __('Filter Bar Buttons Border', 'dpr-adeline-extensions'),

            'default'  => '#e5e5e9',

            'output'   => array('border-color' => '.portfolio-items .portfolio-filters li a'),

            'hint'     => array(

                'title'   => esc_attr__('Filter Bar Buttons Border', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set border color for filter bar buttons.', 'dpr-adeline-extensions'),

            ),

            'required' => array('portfolio_filter', 'equals', '1'),

        ),

        array(

            'id'       => 'portfolio_filter_buttons_border_hover',

            'type'     => 'color',

            'title'    => __('Filter Bar Buttons Border: Hover', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'output'   => array('border-color' => '.portfolio-items .portfolio-filters li a:hover, .portfolio-items .portfolio-filters li.active a'),

            'hint'     => array(

                'title'   => esc_attr__('Filter Bar Buttons Border: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set border color for filter bar buttons hover and active.', 'dpr-adeline-extensions'),

            ),

            'required' => array('portfolio_filter', 'equals', '1'),

        ),

    ),

));
