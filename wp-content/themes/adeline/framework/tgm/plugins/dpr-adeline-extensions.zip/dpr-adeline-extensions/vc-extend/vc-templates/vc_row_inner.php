<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Shortcode attributes
 * @var $atts
 * @var $el_class
 * @var $css
 * @var $el_id
 * @var $equal_height
 * @var $content_placement
 * @var $content - shortcode content
 * Shortcode class
 * @var $this WPBakeryShortCode_VC_Row_Inner
 */
$el_class = $dpr_row_content_sizing = $equal_height = $full_height = $content_placement = $css = $el_id = $custom_el_css = $css = '';
$custom_inline_css =  $bg_style = $dpr_bg_type = $dpr_row_gradient = $dpr_animated_colors = $dpr_animated_speed = '';
$dpr_row_gradient_animate = $dpr_row_gradient_animate_speed = $dpr_row_gradient_animate_spread = $dpr_video_type = $dpr_youtube_id = $dpr_vimeo_id = $dpr_mp4_url = $dpr_webm_url = $dpr_video_options = $dpr_video_poster = $dpr_video_start_time = $dpr_video_stop_time = '';
$dpr_enable_overlay = $dpr_overlay_color_type = $dpr_overlay_color = $dpr_overlay_gradient = $dpr_overlay_pattern = $dpr_overlay_pattern_opacity = $dpr_overlay_pattern_size = '';
$disable_element = $dpr_enable_responsive_options = $hide_on = $responsive_css_panel = '';
$output = $overlay_output = $after_output = '';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$el_class = $this->getExtraClass( $el_class );
$css_classes = array(
	'vc_row',
	'dpr_row_wrapper',
	'wpb_row',
	//deprecated
	'vc_inner',
	'vc_row-fluid',
	$el_class,
	vc_shortcode_custom_css_class( $css ),
);
if ( 'yes' === $disable_element ) {
	if ( vc_is_page_editable() ) {
		$css_classes[] = 'vc_hidden-lg vc_hidden-xs vc_hidden-sm vc_hidden-md';
	} else {
		return '';
	}
}

if ( vc_shortcode_custom_css_has_property( $css, array(
	'border',
	'background',
) ) ) {
	$css_classes[] = 'vc_row-has-fill';
}

if ( ! empty( $full_height ) ) {
	$css_classes[] = 'dpr-row-full-height';
}

if ( ! empty( $atts['gap'] ) ) {
	$css_classes[] = 'vc_column-gap-' . $atts['gap'];
}

if ( ! empty( $equal_height ) ) {
	$flex_row = true;
	$css_classes[] = 'vc_row-o-equal-height';
}

if ( ! empty( $content_placement ) ) {
	$flex_row = true;
	$css_classes[] = 'vc_row-o-content-' . $content_placement;
	$css_classes[] = 'vc_row-o-columns-' . $content_placement;}

if ( ! empty( $flex_row ) ) {
	$css_classes[] = 'vc_row-flex';
}
if  ($bg_style == 'dark') {
	$css_classes[] = ' dpr-dark-background';
}

if(isset($hide_on) && !empty($hide_on)) {

	if(substr_count($hide_on, 'lg') == 1) {

		$css_classes[] = ' vc_hidden-lg';

	}

	if(substr_count($hide_on, 'md') == 1) {

		$css_classes[] = ' vc_hidden-md';

	}

	if(substr_count($hide_on, 'sm') == 1) {

		$css_classes[] = ' vc_hidden-sm';

	}

	if(substr_count($hide_on, 'xs') == 1) {

		$css_classes[] = ' vc_hidden-xs';

	}	

}


$wrapper_attributes = array();
// build attributes for wrapper
if ( ! empty( $el_id ) ) {
	$wrapper_attributes[] = 'id="' . esc_attr( $el_id ) . '"';
}

// Add responsive CSS

if($dpr_enable_responsive_options && isset($responsive_css_panel) && $responsive_css_panel != '') {
	
	$responsive_unique_class = uniqid('vc-inner-row-responsive-');
	$css_classes[] .= $responsive_unique_class;
	$custom_el_css .= DPR_Responsive_CSS::generate_css($responsive_css_panel, '.'.$responsive_unique_class);

}


// Prepare Overlay Output
if($dpr_enable_overlay) {
	
	$overlay_style = $overlay_inner_style = '';
	
	if( $dpr_overlay_color_type == 'solid' && isset($dpr_overlay_color) && !empty($dpr_overlay_color)) {
		$overlay_style .= 'background-color: '.esc_attr($dpr_overlay_color).';';
	}
	
	if( $dpr_overlay_color_type == 'gradient' && isset($dpr_overlay_gradient) && !empty($dpr_overlay_gradient)) {
		
		$overlay_style .= esc_attr(adeline_gradientToBgCSS ($dpr_overlay_gradient)).';';
	}
	
	if(isset($dpr_overlay_pattern) && !empty($dpr_overlay_pattern)) {
		$overlay_inner_style .= 'background-image: url('.DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/img/patterns/'.esc_attr($dpr_overlay_pattern).'.png);';
	}
	
	if(isset($dpr_overlay_pattern_opacity) && !empty($dpr_overlay_pattern_opacity)) {
		$overlay_inner_style .= 'opacity: '.esc_attr($dpr_overlay_pattern_opacity/100).';';
	}
	
	if(isset($dpr_overlay_pattern_size) && !empty($dpr_overlay_pattern_size)) {
		$overlay_inner_style .= 'background-size: '.esc_attr($dpr_overlay_pattern_size).'px;';
	}	

	if(isset($dpr_overlay_pattern) && $dpr_overlay_pattern == 'custom' && !empty($dpr_overlay_custom_pattern)) {
		$overlay_inner_style = esc_attr($dpr_overlay_custom_pattern);
	}

		
	if(!empty($overlay_style) || !empty($overlay_inner_style)) {
		
		$overlay_output .= '<div class="dpr-row-bg-overlay" style="'.$overlay_style.'">';
		if(isset($dpr_overlay_pattern) && $dpr_overlay_pattern != 'transparent') {
			$overlay_output .= '<div class="dpr-row-bg-overlay-inner" style="'.$overlay_inner_style.'"></div>';
		}
		$overlay_output .= '</div>';
	
	}

}



$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->settings['base'], $atts ) );
$wrapper_attributes[] = 'class="' . esc_attr( trim( $css_class ) ) . '"';

$output .= '<div ' . implode( ' ', $wrapper_attributes ) . '>';

// Add row background container

if(isset($dpr_bg_type) && !empty($dpr_bg_type)) {
	$file = DPR_EXTENSIONS_PLUGIN_PATH.'vc-extend/vc-templates/dpr-backgrounds/' . $dpr_bg_type . '.php';
	if(file_exists($file)) {
		include($file);
	}
}
if ( 'boxed' == $dpr_row_content_sizing ) {
$output .= '<div class="container"><div class="container-inner">';
}
$output .= wpb_js_remove_wpautop( $content );
if ( 'boxed' == $dpr_row_content_sizing ) {
$output .= '</div></div>';
}
if($custom_el_css != '') {
	$output .= '<script>'
				. '(function($) {'
					. '$("head").append("<style>'.$custom_el_css.'</style>")'
				. '})(jQuery);'
			. '</script>';
}

$output .= $after_output;
$output .= '</div>';

echo $output;
