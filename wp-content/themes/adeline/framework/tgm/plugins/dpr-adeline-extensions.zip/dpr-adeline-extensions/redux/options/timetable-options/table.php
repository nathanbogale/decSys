<?php



/**



 * Timetable Options -> General Layout



 * 



 */







	Redux::setSection( $opt_name, array(



		'title' => esc_html__('Table Layout', 'dpr-adeline-extensions'),



		'id' => 'timetable_layout',



		'subsection' => true,



		'fields' => array(



			array(



				'id'          => 'columns_header_typo',



				'type'        => 'typography',



				'title'       => esc_html__( 'Columns Header Typography', 'dpr-adeline-extensions' ),



				'google'      => true,



				'font-style'    => true,



				'subsets'       => true, 



				'font-size'     => true,



				'text-align'	=> false,



				'line-height'   => true,



				'word-spacing'  => false,



				'letter-spacing'=> true, 



				'text-transform'=> true,



				'color'         => true,



				'output'		=> '.mptt-shortcode-wrapper .mptt-shortcode-table tr.mptt-shortcode-row th',				



				'preview'       => true,



				'all_styles'  => true,



				'units'       => 'px',



				'default'     => array(



					'font-style'  => '',



					'font-weight'  => '500',



					'font-size' => '15px',



					'line-height' => '30px',



					'font-family' => 'Roboto',



					'google'      => true,



					'color' => '#292933',



					'text-transform'=> 'uppercase',



				),



				'hint' => array(



                    'title'   => esc_attr__('Columns Header Typography', 'dpr-adeline-extensions'),



                    'content' => esc_attr__( 'Specify the typography settings and timetable columns heading', 'dpr-adeline-extensions')



                )



			),



			array(         



				'id'       => 'columns_header_bg',



				'type'     => 'color',



				'title'    => __('Columns Header Background', 'dpr-adeline-extensions'),



				'default'  => '#e5e5e9',



				'output'  => array( 'background-color' =>'.mptt-shortcode-wrapper .mptt-shortcode-table tr.mptt-shortcode-row th'),



				'hint' => array(



					'title'   => esc_attr__('Columns Header Background','dpr-adeline-extensions'),



					'content' =>  esc_attr__('Set background color for columns header.','dpr-adeline-extensions')



				)



			),



			array(         



				'id'       => 'table_row_bg',



				'type'     => 'color',



				'title'    => __('Table Row Background: Even', 'dpr-adeline-extensions'),



				'default'  => '#ffffff',



				'output'  => array( 'background-color' =>'.mptt-shortcode-wrapper .mptt-shortcode-table tbody tr'),



				'hint' => array(



					'title'   => esc_attr__('Table Row Background:Even','dpr-adeline-extensions'),



					'content' =>  esc_attr__('Set background color for table even row.','dpr-adeline-extensions')



				)



			),



			array(         



				'id'       => 'table_row_bg_odd',



				'type'     => 'color',



				'title'    => __('Table Row Background: Odd ', 'dpr-adeline-extensions'),



				'default'  => '#e5e5e9',



				'output'  => array( 'background-color' =>'.mptt-shortcode-wrapper .mptt-shortcode-table tbody tr:nth-child(2n+2)'),



				'hint' => array(



					'title'   => esc_attr__('Table Row Background: Odd','dpr-adeline-extensions'),



					'content' =>  esc_attr__('Set background color for table odd row.','dpr-adeline-extensions')



				)



			),



		)



	));



