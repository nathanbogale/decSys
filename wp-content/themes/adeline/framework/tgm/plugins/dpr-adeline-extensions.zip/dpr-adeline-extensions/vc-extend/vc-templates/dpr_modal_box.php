<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$output = $css_animation = $el_class = $apear_options = $animation = $delay_time = $display_frequency = $cookie_name = $repeat_after = ''; 
$overlay_background = $close_color = $close_bg = $box_width = $box_vertical_padding = $box_horizontal_padding = $box_bg_type = $box_bg_color = $box_bg_image = $box_border_style = $box_border_width = $box_border_color = '';
$btn_class = $btn_inner_class  = $custom_el_css = $open_tag_html = $close_tag_html = '';
$title = $link = $btn_type = $btn_style = $size = $shape = $button_alignment = $icon = $icon_size = $icon_color = $icon_color_hover = '';
$button_color = $button_color_hover = $button_bg_color = $button_bg_color_hover =  '';
$button_border_color = $button_border_color_hover  = $button_border_radius = $button_border_radius_hover = $button_border_width = $button_border_style = $button_shadow = $button_shadow_hover = '';
$title_typo_style = $title_color = $title_font_size = $title_line_height = $title_letter_spacing = $title_font_style = $title_google_font = $title_html = $icon_html = '';
$button_html = $modalcontent = $btn_data = '';
$atts = vc_map_get_attributes( 'dpr_modal_box', $atts );
extract( $atts );
wp_enqueue_script('dpr-waypoints', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/waypoints.min.js', array('jquery'), null, true);
wp_enqueue_script('js-cookie', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/js.cookie.js', array('jquery'), null, true);	
wp_enqueue_script('dpr-modal-box', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/dpr.modal.box.js', array('jquery'), null, true);	

$unique_id = uniqid('dpr-modal-box-').'-'.rand(1,9999);
$btn_unique_id = uniqid('dpr-modal-btn-').'-'.rand(1,9999);
$popup_unique_id = uniqid('popup-').'-'.rand(1,9999);

$btn_data = ' data-id="'.$popup_unique_id.'"';
if($apear_options == 'delay' ) {
	if ($delay_time != '') {
	$btn_data .= ' data-delay="'.$delay_time.'"';
	} else {
	$btn_data .= ' data-delay="3000"';
	}
}
if($apear_options == 'on-scroll' ||  $apear_options == 'delay') {
	$btn_data .= ' data-frequency="'.$display_frequency.'"';
	if(isset($cookie_name) && $cookie_name != '') {
		$btn_data .= ' data-name="'.$cookie_name.'"';
	}
	if(isset($repeat_after) && $repeat_after != '' && $display_frequency == 'every-few-day') {
		$btn_data .= ' data-expiry="'.$repeat_after.'"';
	}
}


if ( '' !== $css_animation && 'none' !== $css_animation ) {
	dpr_enqueue_animate_css();
	$btn_class .= ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
}

if($box_vertical_padding != '') {
	$custom_el_css .= '#modal-'.esc_js($popup_unique_id) .' .dpr-md-content {padding-top:'.$box_vertical_padding.'px; padding-bottom:'.$box_vertical_padding.'px;}'; 
}
if($box_horizontal_padding != '') {
	$custom_el_css .= '#modal-'.esc_js($popup_unique_id) .' .dpr-md-content {padding-left:'.$box_horizontal_padding.'px; padding-right:'.$box_horizontal_padding.'px;}'; 
}
if($box_width != '') {
	$custom_el_css .= '#modal-'.esc_js($popup_unique_id) .' {width:'.$box_width.'px;}'; 
}

if($box_bg_color  != '') {
	$custom_el_css .= '#modal-'.esc_js($popup_unique_id) .' .dpr-md-content {background-color:'.$box_bg_color.';}'; 
}
if($box_bg_image  != '') {
	$img_src = dpr_get_attachment_image_src($box_bg_image, 'full');
	$custom_el_css .= '#modal-'.esc_js($popup_unique_id) .' .dpr-md-content {background-image:url('.esc_attr($img_src[0]).');background-position:center center;background-size:cover;}'; 
}
if($box_border_style != '') {
	$custom_el_css .= '#modal-'.esc_js($popup_unique_id) .' .dpr-md-content {border-style:'.$box_border_style.';}'; 
}
if($box_border_width != '') {
	$custom_el_css .= '#modal-'.esc_js($popup_unique_id) .' .dpr-md-content {border-width:'.$box_border_width.'px;}'; 
}
if($box_border_color != '') {
	$custom_el_css .= '#modal-'.esc_js($popup_unique_id) .' .dpr-md-content {border-color:'.$box_border_color.';}'; 
}
if($close_color != '') {
	$custom_el_css .= '#modal-'.esc_js($popup_unique_id) .' .dpr-modal-close svg {fill:'.$close_color.';}'; 
}
if($close_bg != '') {
	$custom_el_css .= '#modal-'.esc_js($popup_unique_id) .' .dpr-modal-close {background-color:'.$close_bg.';}'; 
}


/* Button HTML */
if($apear_options == 'on-click') {

$btn_class .= ' '.esc_attr($btn_type).' '.esc_attr($button_alignment);

$btn_inner_class .= 'dpr-md-trigger btn '.esc_attr($btn_style).' '.esc_attr($shape).' '.esc_attr($size);

if(isset($btn_type) && $btn_type == 'type-2') {
	$btn_inner_class .= ' btn-with-icon btn-icon-left';
}

if(isset($btn_type) && $btn_type == 'type-3') {
	$btn_inner_class .= ' btn-with-icon btn-icon-right';
}

if(isset($btn_type) && $btn_type == 'type-4') {
	$btn_inner_class .= ' btn-with-icon btn-icon-left btn-icon-animated';
}

if(isset($btn_type) && $btn_type == 'type-5') {
	$btn_inner_class .= ' btn-with-icon btn-icon-right btn-icon-animated';
}

if(isset($btn_type) && $btn_type == 'type-6') {
	$btn_inner_class .= ' btn-with-icon btn-icon-top btn-icon-animated';
}

if(isset($button_color) && !empty($button_color)) {
	$custom_el_css .= '#'.esc_js($btn_unique_id) .' {color:'.$button_color.';}';
}

if(isset($button_color_hover) && !empty($button_color_hover)) {
	$custom_el_css .= '#'.esc_js($btn_unique_id) .':hover {color: '.esc_js($button_color_hover).';}';
}

if(isset($button_bg_color) && !empty($button_bg_color)) {
	$custom_el_css .= '#'.esc_js($btn_unique_id) .' { background-color:'.esc_js($button_bg_color).'!important;}';
}

if(isset($button_bg_color_hover) && !empty($button_bg_color_hover)) {
	$custom_el_css .= '#'.esc_js($btn_unique_id) .':hover {background-color: '.esc_js($button_bg_color_hover).'!important;}';
}
if(isset($button_border_color) && !empty($button_border_color)) {
	$custom_el_css .= '#'.esc_js($btn_unique_id) .' { border-color:'.esc_js($button_border_color).'!important;}';
}

if(isset($button_border_color_hover) && !empty($button_border_color_hover)) {
	$custom_el_css .= '#'.esc_js($btn_unique_id) .':hover {border-color: '.esc_js($button_border_color_hover).'!important;}';
}

if(isset($border_radius) && !empty($border_radius)) {
	$custom_el_css .= '#'.esc_js($btn_unique_id) .' { border-radius:'.esc_js($border_radius).'px !important;}';
}

if(isset($hover_border_radius) && !empty($hover_border_radius)) {
	$custom_el_css .= '#'.esc_js($btn_unique_id) .':hover { border-radius:'.esc_js($hover_border_radius).'px !important;}';
}

if(isset($border_width) ) {
	$custom_el_css .= '#'.esc_js($btn_unique_id) .' { border-width:'.esc_js($border_width).'px;}';
}

if(isset($border_style) && !empty($border_style)) {
	$custom_el_css .= '#'.esc_js($btn_unique_id) .' { border-style:'.esc_js($border_style).';}';
}

if(isset($icon_size) && !empty($icon_size)) {
	$custom_el_css .= '#'.esc_js($btn_unique_id) .' .button-icon-wrapper { font-size:'.esc_js($icon_size).'px;}';
}

if(isset($icon_color) && !empty($icon_color)) {
	$custom_el_css .= '#'.esc_js($btn_unique_id) .' .button-icon-wrapper { color:'.esc_js($icon_color).';}';
}

if(isset($icon_color_hover) && !empty($icon_color_hover)) {
	$custom_el_css .= '#'.esc_js($btn_unique_id) .':hover .button-icon-wrapper { color:'.esc_js($icon_color_hover).';}';
}

$open_tag_html .= '<span id="'.esc_attr($btn_unique_id).'" class ="'.esc_attr($btn_inner_class).'"'.$btn_data.'>';
$close_tag_html .= '</span>';

if(dpr_shadow_param_to_css($button_shadow) != '') {
	$custom_el_css .= '#'.esc_js($btn_unique_id) .' {'.dpr_shadow_param_to_css($button_shadow).'}';
}

if(dpr_shadow_param_to_css($button_shadow_hover) != '') {
	$custom_el_css .= '#'.esc_js($btn_unique_id) .':hover {'.dpr_shadow_param_to_css($button_shadow_hover).'}';
}

if(!empty($title)) {
	$title_typo_style = dpr_generate_typography_style($title_color, $title_font_size, $title_line_height, $title_letter_spacing, $title_font_style,$title_google_font);
	$title_html .= '<span class="button-text " '.$title_typo_style.'>'.wp_kses($title, array('span' => array(),'br' => array())).'</span>';
}

if(isset($icon) && $icon !='none' && $icon !='') {
	$icon_html = '<span class="button-icon-wrapper"><i class="'.esc_attr($icon).'"></i></span>';
}




$button_html .= '<div class="dpr-button-wrapper '.esc_attr($btn_class).'">';

$button_html .= $open_tag_html;

if( $btn_type == 'type-2' || $btn_type == 'type-4' || $btn_type == 'type-6') {
$button_html .= $icon_html;
}

$button_html .= $title_html;

if( $btn_type == 'type-3' || $btn_type == 'type-5') {
$button_html .= $icon_html;
}

$button_html .= $close_tag_html;
$button_html .= '</div>';
}

if($apear_options == 'on-scroll') {
	$button_html .= '<div class="dpr-md-trigger-onscroll" '.$btn_data.'></div>';
}

if($apear_options == 'delay') {
	$button_html .= '<div class="dpr-md-trigger-delay" '.$btn_data.'></div>';
}

/*Modal Box HTML */
$modalcontent .= "<div class='dpr-modal ".$animation."' id='modal-".$popup_unique_id."'>";
$modalcontent .="<div class='dpr-md-content'>";
$modalcontent .= wpb_js_remove_wpautop($content, true);
$modalcontent .="</div>";
$modalcontent .="<div class='dpr-modal-close' data-id='".$popup_unique_id."'>";
$modalcontent .= '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18"><path d="M14.53 4.53l-1.06-1.06L9 7.94 4.53 3.47 3.47 4.53 7.94 9l-4.47 4.47 1.06 1.06L9 10.06l4.47 4.47 1.06-1.06L10.06 9z"/></svg>';
$modalcontent .= "</div>";
$modalcontent .="</div>";
$modalcontent .="<div class='dpr-md-overlay' id='overlay-".$popup_unique_id."' data-id='".$popup_unique_id."' style='background-color:".$overlay_background."'></div>";

/* Output */

$output .= '<div id="'.esc_attr($unique_id).'" class="dpr-modal-box '.esc_attr($el_class).'">';
$output .= $button_html;
$output .= $modalcontent;

?>
<script>
jQuery(document).ready(function(){
	jQuery('.dpr-modal').appendTo(document.body);
});
</script>
<?php
	if(!empty($custom_el_css)) {
		$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>");'
						. '})(jQuery);'
					. '</script>';
}
if(!empty($custom_el_css)) {
}
$output .= '</div>';


echo $output;