<?php

// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}



if(!class_exists('DPR_Clear_Param')) {

	class DPR_Clear_Param {

		function __construct() {

			if(function_exists('vc_add_shortcode_param')) {

				vc_add_shortcode_param('dpr_clear' , array($this, 'dpr_clear'));

			}

		}

	

		function dpr_clear($settings, $value) {

			$param_name = isset($settings['param_name']) ? $settings['param_name'] : '';

			$class = isset($settings['class']) ? $settings['class'] : '';

			$output = '<div class="vc_col-sm-12 '.esc_attr($class).' ' . esc_attr($param_name) . '" name="' . esc_attr($param_name) . '"></div>';



			return $output;

		}

		

	}

	

	$DPR_Clear_Param = new DPR_Clear_Param();

}

