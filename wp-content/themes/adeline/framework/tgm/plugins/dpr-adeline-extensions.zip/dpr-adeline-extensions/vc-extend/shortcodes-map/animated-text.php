<?php

// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}

/*

* Add-on Name: Animated Text

*/



class WPBakeryShortCode_DPR_Animated_Text extends WPBakeryShortCode {}



$in_animation = array(

				esc_html__('BounceIn','dpr-adeline-extensions') => 'bounceIn',

				esc_html__('BounceInDown','dpr-adeline-extensions') => 'bounceInDown',

				esc_html__('BounceInLeft','dpr-adeline-extensions') => 'bounceInLeft',

				esc_html__('BounceInRight','dpr-adeline-extensions') => 'bounceInRight',

				esc_html__('BounceInUp','dpr-adeline-extensions') => 'bounceInUp',

				esc_html__('FadeIn','dpr-adeline-extensions') => 'fadeIn',

				esc_html__('FadeInDown','dpr-adeline-extensions') => 'fadeInDown',

				esc_html__('FadeInDownBig','dpr-adeline-extensions') => 'fadeInDownBig',

				esc_html__('FadeInLeft','dpr-adeline-extensions') => 'fadeInLeft',

				esc_html__('FadeInLeftBig','dpr-adeline-extensions') => 'fadeInLeftBig',

				esc_html__('FadeInRight','dpr-adeline-extensions') => 'fadeInRight',

				esc_html__('FadeInRightBig','dpr-adeline-extensions') => 'fadeInRightBig',

				esc_html__('FadeInUp','dpr-adeline-extensions') => 'fadeInUp',

				esc_html__('FadeInUpBig','dpr-adeline-extensions') => 'fadeInUpBig',

				esc_html__('LightSpeedIn','dpr-adeline-extensions') => 'lightSpeedIn',

				esc_html__('RotateIn','dpr-adeline-extensions') => 'rotateIn',

				esc_html__('RotateInDownLeft','dpr-adeline-extensions') => 'rotateInDownLeft',

				esc_html__('RotateInDownRight','dpr-adeline-extensions') => 'rotateInDownRight',

				esc_html__('RotateInUpLeft','dpr-adeline-extensions') => 'rotateInUpLeft',

				esc_html__('RotateInUpRight','dpr-adeline-extensions') => 'rotateInUpRight',

				esc_html__('RollIn','dpr-adeline-extensions') => 'rollIn',

				esc_html__('ZoomIn','dpr-adeline-extensions') => 'zoomIn',

				esc_html__('ZoomInDown','dpr-adeline-extensions') => 'zoomInDown',

				esc_html__('ZoomInLeft','dpr-adeline-extensions') => 'zoomInLeft',

				esc_html__('ZoomInRight','dpr-adeline-extensions') => 'zoomInRight',

				esc_html__('ZoomInUp','dpr-adeline-extensions') => 'zoomInUp',

				esc_html__('SlideInDown','dpr-adeline-extensions') => 'slideInDown',

				esc_html__('SlideInLeft','dpr-adeline-extensions') => 'slideInLeft',

				esc_html__('SlideInRight','dpr-adeline-extensions') => 'slideInRight',

				esc_html__('SlideInUp','dpr-adeline-extensions') => 'slideInUp',

);

$out_animation = array(

				esc_html__('BounceOut','dpr-adeline-extensions') => 'bounceOut',

				esc_html__('BounceOutDown','dpr-adeline-extensions') => 'bounceOutDown',

				esc_html__('BounceOutLeft','dpr-adeline-extensions') => 'bounceOutLeft',

				esc_html__('BounceOutRight','dpr-adeline-extensions') => 'bounceOutRight',

				esc_html__('BounceOutUp','dpr-adeline-extensions') => 'bounceOutUp',

				esc_html__('FadeOut','dpr-adeline-extensions') => 'fadeOut',

				esc_html__('FadeOutDown','dpr-adeline-extensions') => 'fadeOutDown',

				esc_html__('FadeOutDownBig','dpr-adeline-extensions') => 'fadeOutDownBig',

				esc_html__('FadeOutLeft','dpr-adeline-extensions') => 'fadeOutLeft',

				esc_html__('FadeOutLeftBig','dpr-adeline-extensions') => 'fadeOutLeftBig',

				esc_html__('FadeOutRight','dpr-adeline-extensions') => 'fadeOutRight',

				esc_html__('FadeOutRightBig','dpr-adeline-extensions') => 'fadeOutRightBig',

				esc_html__('FadeOutUp','dpr-adeline-extensions') => 'fadeOutUp',

				esc_html__('FadeOutUpBig','dpr-adeline-extensions') => 'fadeOutUpBig',

				esc_html__('LightSpeedOut','dpr-adeline-extensions') => 'lightSpeedOut',

				esc_html__('RotateOut','dpr-adeline-extensions') => 'rotateOut',

				esc_html__('RotateOutDownLeft','dpr-adeline-extensions') => 'rotateOutDownLeft',

				esc_html__('RotateOutDownRight','dpr-adeline-extensions') => 'rotateOutDownRight',

				esc_html__('RotateOutUpLeft','dpr-adeline-extensions') => 'rotateOutUpLeft',

				esc_html__('RotateOutUpRight','dpr-adeline-extensions') => 'rotateOutUpRight',

				esc_html__('RollOut','dpr-adeline-extensions') => 'rollOut',

				esc_html__('ZoomOut','dpr-adeline-extensions') => 'zoomOut',

				esc_html__('ZoomOutDown','dpr-adeline-extensions') => 'zoomOutDown',

				esc_html__('ZoomOutLeft','dpr-adeline-extensions') => 'zoomOutLeft',

				esc_html__('ZoomOutRight','dpr-adeline-extensions') => 'zoomOutRight',

				esc_html__('ZoomOutUp','dpr-adeline-extensions') => 'zoomOutUp',

				esc_html__('SlideOutDown','dpr-adeline-extensions') => 'slideOutDown',

				esc_html__('SlideOutLeft','dpr-adeline-extensions') => 'slideOutLeft',

				esc_html__('SlideOutRight','dpr-adeline-extensions') => 'slideOutRight',

				esc_html__('SlideOutUp','dpr-adeline-extensions') => 'slideOutUp',

);



vc_map(

	array(

		'name'					=> esc_html__('DP Animated Text', 'dpr-adeline-extensions'),

		'base'					=> 'dpr_animated_text',

		"icon"					=> 'icon-dpr-animated-text',

		"class"					=> 'dpr_animated_text',

  		"category" =>array( esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions')),

		'description'			=> esc_html__('Display text with animated parts of text', 'dpr-adeline-extensions'),

		'params'				=> array(

			array(

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose background animation direction.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Animation Type', 'dpr-adeline-extensions'),

				'type'				=> 'dpr_image_select',

				'param_name'		=> 'type',

				'value' 			=> 'typing',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'options'			=> array(

					'typing'			=> array(

						'label'			=> esc_html__('Typed Text', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'animated-text/type-2.png'

					),

					'rotate-words'			=> array(

						'label'			=> esc_html__('Rotate Words', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'animated-text/type-1.png'

					),

				),

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to choose the horizontal alignment for the text.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Text Alignment', 'dpr-adeline-extensions'),

				'param_name'		=> 'alignment',

				'value'				=> 'text-left',

				'options'			=> array(

					esc_html__('Left', 'dpr-adeline-extensions')	=> 'text-left',

					esc_html__('Center', 'dpr-adeline-extensions')	=> 'text-center',

					esc_html__('Right', 'dpr-adeline-extensions')	=> 'text-right'

				),

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set type speed in miliseconds.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Type speed', 'dpr-adeline-extensions'),

				'param_name'		=> 'type_speed',

				'min'				=> 1,

				'suffix'			=> 'ms',

				'value' 			=> 150,

				'edit_field_class'	=> 'vc_column vc_col-sm-6 no-top-padding',

				'dependency' => array('element' => 'type', 'value' => array('typing')),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set delay before back animation in seconds.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Back delay', 'dpr-adeline-extensions'),

				'param_name'		=> 'back_delay',

				'min'				=> 1,

				'suffix'			=> 's',

				'value' 			=> 2,

				'edit_field_class'	=> 'vc_column vc_col-sm-6 no-top-padding',

				'dependency' => array('element' => 'type', 'value' => array('typing')),

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to choose the horizontal alignment for the text.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Back Animation', 'dpr-adeline-extensions'),

				'param_name'		=> 'back_animation',

				'value'				=> 'back-type',

				'options'			=> array(

					esc_html__('Back Type', 'dpr-adeline-extensions')	=> 'back-type',

					esc_html__('Fade', 'dpr-adeline-extensions')	=> 'fade'

				),

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'dependency' => array('element' => 'type', 'value' => array('typing')),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable loop animation of typing', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Enable Loop?', 'dpr-adeline-extensions'),

				'param_name'		=> 'loop_animation',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'dependency' => array('element' => 'type', 'value' => array('typing')),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable cursor by typingtyping', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Enable Cursor?', 'dpr-adeline-extensions'),

				'param_name'		=> 'enable_cursor',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'dependency' => array('element' => 'type', 'value' => 'typing'),

			),

			array(

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose cursor type.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Cursor Type', 'dpr-adeline-extensions'),

				'type'				=> 'dpr_image_select',

				'param_name'		=> 'cursor_type',

				'value' 			=> 'cursor-1',

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'options'			=> array(

					'cursor-1'			=> array(

						'label'			=> '',

						'src'				=> $module_images.'animated-text/cursor-1.gif'

					),

					'cursor-2'			=> array(

						'label'			=> '',

						'src'				=> $module_images.'animated-text/cursor-2.gif'

					)

				),

				'dependency' => array('element' => 'enable_cursor', 'value' => 'yes'),

			),

			

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set text animation speed in seconds.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Animation speed', 'dpr-adeline-extensions'),

				'param_name'		=> 'animation_speed',

				'min'				=> 1,

				'suffix'			=> 's',

				'value' 			=> 3,

				'edit_field_class'	=> 'vc_column vc_col-sm-6 no-top-padding',

				'dependency' => array('element' => 'type', 'value' => array('rotate-words')),

			),

			array(

				'type' => 'dropdown',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Animation for the words appearing', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Rotating Words In Animation', 'dpr-adeline-extensions'),

				'param_name' => 'in_animation',

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'dependency' => array('element' => 'type', 'value' => array('rotate-words')),

				'value' => $in_animation,

			),

			array(

				'type' => 'dropdown',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Animation for the words disappearing', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Rotating Words Out Animation', 'dpr-adeline-extensions'),

				'param_name' => 'out_animation',

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'dependency' => array('element' => 'type', 'value' => array('rotate-words')),

				'value' => $out_animation,

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Additional Settings', 'dpr-adeline-extensions' ),

				'param_name'       => 'extra_features_title',

				'edit_field_class' => 'vc_column vc_col-sm-12',

			),

			vc_map_add_css_animation( false ),

		    array(

				'type' => 'textfield',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Extra Class Name', 'dpr-adeline-extensions'),

				'param_name' => 'el_class',

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Content Settings', 'dpr-adeline-extensions' ),

				'param_name'       => 'content_title_1',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

		    array(

				'type' => 'textfield',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set text displayed before animated segment.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Text Before', 'dpr-adeline-extensions'),

				'param_name' => 'before_text',

				'value' => 'This is an example of',

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			



			array(

				'type'				=> 'param_group',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Add strings for animation bellow.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Animated text strings', 'dpr-adeline-extensions'),

				'param_name'		=> 'strings_list',

				'value' => '%5B%7B%22animated_string%22%3A%22amazing%22%7D%2C%7B%22animated_string%22%3A%22eye-catching%22%7D%5D',

				'params'			=> array(

					array(

						'type'				=> 'textfield',

						'heading'			=> esc_html__('String', 'dpr-adeline-extensions'),

						'param_name'		=> 'animated_string',

						'edit_field_class'	=> 'vc_column vc_col-sm-12',

						'admin_label' => true,

					),

					array(

						'type'				=> 'colorpicker',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose color for this string', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('String Color', 'dpr-adeline-extensions'),

						'param_name'		=> 'string_color',

						'edit_field_class'	=> 'vc_column vc_col-sm-6',

					),

					array(

						'type'				=> 'colorpicker',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose background color for this string', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('String Background', 'dpr-adeline-extensions'),

						'param_name'		=> 'string_bg',

						'edit_field_class'	=> 'vc_column vc_col-sm-6',

					),



				),

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

		    array(

				'type' => 'textfield',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set text displayed after animated segment.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Text After', 'dpr-adeline-extensions'),

				'param_name' 	=> 'after_text',

				'value' 	 	=> 'animated text',

				'group'			=> esc_html__('Content', 'dpr-adeline-extensions'),

			),	

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Color Settings', 'dpr-adeline-extensions' ),

				'param_name'       => 'content_title_2',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose color for text before animated segment', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Before Text Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'before_text_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose color for after animated segment', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('After Text Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'after_text_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Animated Text Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'typo_title_1',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size. If you leave this field blank will be used default size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'animated_text_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom line height.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'animated_text_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'animated_text_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'animated_text_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

	  		),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font. .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_animated_text_google_fonts',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'animated_text_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'dependency'		=> array('element' => 'use_animated_text_google_fonts', 'value' => array('yes')),

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Before and After Text Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'typo_title_2',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size. If you leave this field blank will be used default size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'text_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom linne height.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'text_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom letter sapacing.', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'text_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'text_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

	  		),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font. .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_text_google_fonts',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'text_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'dependency'		=> array('element' => 'use_text_google_fonts', 'value' => array('yes')),

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Headline Responsive Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'animated_text_reaponsive_typography_head',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Responsive', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable responsive typography for animated texts.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Enable', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_animated_text_responsive_typo',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Responsive', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_responsive_typo',

				'param_name'		=> 'animated_text_reaponsive_typography',

				'heading'			=> '',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'use_animated_text_responsive_typo', 'value' => array('yes')),

				'group'				=> esc_attr__('Responsive', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Before and After Texts Responsive Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'text_reaponsive_typography_head',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Responsive', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable responsive typography for before and after texts.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Enable', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_text_responsive_typo',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Responsive', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_responsive_typo',

				'param_name'		=> 'text_reaponsive_typography',

				'heading'			=> '',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'use_text_responsive_typo', 'value' => array('yes')),

				'group'				=> esc_attr__('Responsive', 'dpr-adeline-extensions'),

			),

		),

	)

);