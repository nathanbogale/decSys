<?php



$metaboxes_dir 	= dirname( __FILE__ ) . '/metaboxes-sections';







require_once($metaboxes_dir . '/page-metabox.php');



require_once($metaboxes_dir . '/post-metabox.php');



require_once($metaboxes_dir . '/portfolio-post-metabox.php');



require_once($metaboxes_dir . '/post-format-link-metabox.php');



require_once($metaboxes_dir . '/post-format-video-metabox.php');



require_once($metaboxes_dir . '/post-format-audio-metabox.php');



require_once($metaboxes_dir . '/post-format-quote-metabox.php');



require_once($metaboxes_dir . '/post-format-gallery-metabox.php');



require_once($metaboxes_dir . '/portfolio-metabox.php');



require_once($metaboxes_dir . '/single-portfolio-metabox.php');



require_once($metaboxes_dir . '/blog-metabox.php');







if ( !function_exists( "dpr_add_metaboxes" ) ):



    function dpr_add_metaboxes($metaboxes) {







        // Declare your metaboxes



        $metaboxes = array();



        $metaboxes[] = array(



            'id'            => 'single-portfolio-options',



            'title'         => __( 'Single Portfolio Related Settings', 'dpr-adeline-extensions' ),



            'post_types'    => array( 'dpr_portfolio'),



            'position'      => 'normal', 



            'priority'      => 'high',



            'sections'      => dpr_single_portfolio_metabox_sections(),



        );



        $metaboxes[] = array(



            'id'            => 'portfolio-options',



            'title'         => __( 'Portfolio Page Template Related Settings', 'dpr-adeline-extensions' ),



            'post_types'    => array( 'page'),



			'page_template' => array('page-templates/portfolio.php'), 



            'position'      => 'normal', 



            'priority'      => 'high',



            'sections'      => dpr_portfolio_metabox_sections(),



        );



        $metaboxes[] = array(



            'id'            => 'blog-options',



            'title'         => __( 'Blog Page Template Related Settings', 'dpr-adeline-extensions' ),



            'post_types'    => array( 'page'),



			'page_template' => array('page-templates/blog-page.php'), 



            'position'      => 'normal', 



            'priority'      => 'high',



            'sections'      => dpr_blog_metabox_sections(),



        );



		$metaboxes[] = array(



            'id'            => 'page-options',



            'title'         => __( 'Page/Post Custom Settings', 'dpr-adeline-extensions' ),



            'post_types'    => array( 'page'),



            'position'      => 'normal', 



            'priority'      => 'high',



            'sections'      => dpr_page_metabox_sections(),



        );



		$metaboxes[] = array(



            'id'            => 'post-options',



            'title'         => __( 'Page/Post Custom Settings', 'dpr-adeline-extensions' ),



            'post_types'    => array( 'post'),



            'position'      => 'normal', 



            'priority'      => 'high',



            'sections'      => dpr_post_metabox_sections(),



        );



		$metaboxes[] = array(



            'id'            => 'portfolio-post-options',



            'title'         => __( 'Page/Post Custom Settings', 'dpr-adeline-extensions' ),



            'post_types'    => array( 'dpr_portfolio'),



            'position'      => 'normal', 



            'priority'      => 'high',



            'sections'      => dpr_portfolio_post_metabox_sections(),



        );



        $metaboxes[] = array(



            'id'            => 'post_format_link',



            'title'         => __( 'Custom Link', 'dpr-adeline-extensions' ),



            'post_types'    => array( 'post'),



            'post_format' => array('link'),



            'position'      => 'side', 



            'priority'      => 'default',



            'sections'      => dpr_post_format_link_sections(),



        );



        $metaboxes[] = array(



            'id'            => 'post_format_video',



            'title'         => __( 'Video Source', 'dpr-adeline-extensions' ),



            'post_types'    => array( 'post'),



            'post_format' => array('video'),



            'position'      => 'side', 



            'priority'      => 'default',



            'sections'      => dpr_post_format_video_sections(),



        );



        $metaboxes[] = array(



            'id'            => 'post_format_audio',



            'title'         => __( 'Audio Source', 'dpr-adeline-extensions' ),



            'post_types'    => array( 'post'),



            'post_format' => array('audio'),



            'position'      => 'side', 



            'priority'      => 'default',



            'sections'      => dpr_post_format_audio_sections(),



        );



        $metaboxes[] = array(



            'id'            => 'post_format_quote',



            'title'         => __( 'Custom Quote', 'dpr-adeline-extensions' ),



            'post_types'    => array( 'post'),



            'post_format' => array('quote'),



            'position'      => 'side', 



            'priority'      => 'default',



            'sections'      => dpr_post_format_quote_sections(),



        );



        $metaboxes[] = array(



            'id'            => 'post_format_gallery',



            'title'         => __( 'Gallery', 'dpr-adeline-extensions' ),



            'post_types'    => array( 'post'),



            'post_format' => array('gallery'),



            'position'      => 'side', 



            'priority'      => 'default',



            'sections'      => dpr_post_format_gallery_sections(),



        );



        return $metaboxes;



    }



    add_action("redux/metaboxes/dpr_adeline/boxes", "dpr_add_metaboxes");



endif;