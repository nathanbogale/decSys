<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Shortcode attributes
 * @var $atts
 * @var $content - shortcode content
 * @var $el_class
 * @var $el_id
 * @var $this WPBakeryShortCode_VC_Tta_Accordion|WPBakeryShortCode_VC_Tta_Tabs|WPBakeryShortCode_VC_Tta_Tour|WPBakeryShortCode_VC_Tta_Pageable
 */
$el_class = $css = $css_animation = $custom_el_css = '';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
$this->resetVariables( $atts, $content );
extract( $atts );

$type = str_replace('vc_tta_', '', $this->getShortcode());
$unique_wrapper_class = uniqid('dpr-tta-wrapper-');

$this->setGlobalTtaInfo();

$this->enqueueTtaStyles();
$this->enqueueTtaScript();

// It is required to be before tabs-list-top/left/bottom/right for tabs/tours
$prepareContent = $this->getTemplateVariable( 'content' );
if( 'tour' == $type ) {
	$el_class = 'vertical-tabs';
}
$class_to_filter = $this->getTtaGeneralClasses();
$class_to_filter .= vc_shortcode_custom_css_class( $css, ' ' ) . $this->getExtraClass( $el_class ) . $this->getCSSAnimation( $css_animation ).' '.$unique_wrapper_class;
$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $class_to_filter, $this->settings['base'], $atts );
$output .= '<div ' . $this->getWrapperAttributes() . '>';
$output .= $this->getTemplateVariable( 'title' );
$output .= '<div class="' . esc_attr( $css_class ) . '">';
if ( isset( $atts['tab_position'] ) && strlen( $atts['tab_position'] ) > 0 ) {
	if ( 'top' == $atts['tab_position'] ) {
	 $output .= dpr_getParamTabsList( $atts, $content, $type );
	}
	if ( 'left' == $atts['tab_position'] ) {
	$output .= dpr_getParamTabsList( $atts, $content, $type );
	}
}
$output .= '<div class="vc_tta-panels-container">';
$output .= '<div class="vc_tta-panels">';
$output .= $prepareContent;
$output .= '</div>';
$output .= dpr_getParamPaginationList( $atts, $content );
$output .= '</div>';
if ( isset( $atts['tab_position'] ) && strlen( $atts['tab_position'] ) > 0 ) {
	if ( 'bottom' == $atts['tab_position'] ) {
	$output .= dpr_getParamTabsList( $atts, $content, $type );
	}
	if ( 'right' == $atts['tab_position'] ) {
	$output .= dpr_getParamTabsList( $atts, $content, $type);
	}
}
$output .= '</div>';
$output .= '</div>';

// Custom CSS for element/

// Accordion 

if( 'accordion' == $type ) {

$dpr_style = $atts['style'];

$border_width = $atts['border_width'];
$border_radius = $atts['border_radius'];
$tab_background = $atts['tab_background'];
$tab_background_hover = $atts['tab_background_hover'];
$tab_background_active = $atts['tab_background_active'];
$tab_border = $atts['tab_border'];
$tab_border_hover = $atts['tab_border_hover'];
$tab_border_active = $atts['tab_border_active'];
$underline_thick_active = $atts['underline_thick_active'];
$underline_color_active = $atts['underline_color_active'];
$underline_bg_color_active = $atts['underline_bg_color_active'];
$underline_thick_inactive = $atts['underline_thick_inactive'];
$underline_color_inactive = $atts['underline_color_inactive'];
$underline_bg_color_inactive = $atts['underline_bg_color_inactive'];
$underline_thick_hover = $atts['underline_thick_hover'];
$underline_color_hover = $atts['underline_color_hover'];
$underline_bg_color_hover = $atts['underline_bg_color_hover'];
$add_shadows = $atts['add_shadows'];
$tab_shadow_active = $atts['tab_shadow_active'];
$tab_shadow_inactive = $atts['tab_shadow_inactive'];
$tab_shadow_hover = $atts['tab_shadow_hover'];
$title_font_size = $atts['title_font_size'];
$title_color = $atts['title_color'];
$title_color_active = $atts['title_color_active'];
$title_color_hover = $atts['title_color_hover'];
$icon_font_size = $atts['icon_font_size'];
$icon_color = $atts['icon_color'];
$icon_color_active = $atts['icon_color_active'];
$icon_color_hover = $atts['icon_color_hover'];
		
		if( $border_width != '' ){
		$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading {border-width: '.$border_width.'px !important;}';
		}
		if( $border_radius != '' ){
		$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading {border-radius: '.$border_radius.'px !important;}';
		}

	//Style_1
	if ('style_1' == $style) {
		if( $tab_background != '' ){
		$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading {background-color: '.$tab_background.' !important;}';
		}
		if( $tab_background_hover != '' ){
		$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading:hover, .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading:focus {background-color: '.$tab_background_hover.' !important;}';
		}
		if( $tab_background_active!= '' ){
		$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel.vc_active .vc_tta-panel-heading {background-color: '.$tab_background_active.' !important;}';
		}
		if( $tab_border != '' ){
		$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading {border-color: '.$tab_border.' !important;}';
		}
		if( $tab_border_hover != '' ){
		$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading:hover, .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading:focus {border-color: '.$tab_border_hover.' !important;}';
		}
		if( $tab_border_active != '' ){
		$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel.vc_active .vc_tta-panel-heading {border-color: '.$tab_border_active.' !important;}';
		}
	}
	if ('style_2' == $style) {
		$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading {background-color: transparent !important;}';
		
		if( $tab_border != '' ){
		$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading {border-color: '.$tab_border.' !important;}';
		}
		if( $tab_border_hover != '' ){
		$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading:hover, .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading:focus {border-color: '.$tab_border_hover.' !important;}';
		}
		if( $tab_border_active != '' ){
		$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel.vc_active .vc_tta-panel-heading {border-color: '.$tab_border_active.' !important;}';
		}
	}
	if ('style_3' == $style) {
		$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading {border-top-width: 0 !important; border-left-width: 0 !important; border-right-width: 0 !important;}';
		$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading {border-bottom-width:'.$underline_thick_inactive.'px !important;}';
		$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading:hover, .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading:focus {border-bottom-width: '.$underline_thick_inactive.'px !important;}';
		$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel.vc_active .vc_tta-panel-heading {border-bottom-width: '.$underline_thick_active.'px !important;}';
		if( $underline_bg_color_inactive != '' ){
		$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading {background-color: '.$underline_bg_color_inactive.' !important;}';
		}
		if( $underline_bg_color_hover != '' ){
		$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading:hover, .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading:focus {background-color: '.$underline_bg_color_hover.' !important;}';
		}
		if( $underline_bg_color_active!= '' ){
		$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel.vc_active .vc_tta-panel-heading {background-color: '.$underline_bg_color_active.' !important;}';
		}
		if( $underline_color_inactive != '' ){
		$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading {border-color: '.$underline_color_inactive.' !important;}';
		}
		if( $underline_color_hover != '' ){
		$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading:hover, .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading:focus {border-color: '.$underline_color_hover.' !important;}';
		}
		if( $underline_color_active != '' ){
		$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel.vc_active .vc_tta-panel-heading {border-color: '.$underline_color_active.' !important;}';
		}
	}
	// Add shadows
	if( $add_shadows != '' ){
	$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading {'.dpr_shadow_param_to_css($tab_shadow_inactive).'}';
	$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading:hover, .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading:focus {'.dpr_shadow_param_to_css($tab_shadow_hover).'}';
	$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel.vc_active .vc_tta-panel-heading {'.dpr_shadow_param_to_css($tab_shadow_active).'}';
	}
	
	// Title style 
	if ($title_font_size != '') {
	$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading h4 span { font-size:'.$title_font_size.'px !important}';
	}
	if( $title_color != '' ){
	$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading h4 span, .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading h4 .vc_tta-controls-icon {color: '.$title_color.' !important;}';
	}
	if( $title_color_hover != '' ){
	$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading:hover h4 span, .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading:focus h4 span, .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading:hover h4 .vc_tta-controls-icon, .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading:focus h4 .vc_tta-controls-icon {color: '.$title_color_hover.' !important;}';
	}
	if( $title_color_active != '' ){
	$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel.vc_active .vc_tta-panel-heading h4 span, .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel.vc_active .vc_tta-panel-heading h4 .vc_tta-controls-icon {color: '.$title_color_active.' !important;}';
	}

	if ($icon_font_size != '') {
	$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading h4 .vc_tta-icon { font-size:'.$icon_font_size.'px !important}';
	}
	if( $icon_color != '' ){
	$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading h4 .vc_tta-icon {color: '.$icon_color.' !important;}';
	}
	if( $icon_color_hover != '' ){
	$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading:hover h4 .vc_tta-icon, .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading:focus h4 .vc_tta-icon{color: '.$icon_color_hover.' !important;}';
	}
	if( $icon_color_active != '' ){
	$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel.vc_active .vc_tta-panel-heading h4 .vc_tta-icon {color: '.$icon_color_active.' !important;}';
	}
}

// Tabs


if( 'tabs' == $type || 'tour' == $type ) {

$dpr_style = $atts['style'];

$border_width = $atts['border_width'];
$border_radius = $atts['border_radius'];
$tab_background = $atts['tab_background'];
$tab_background_hover = $atts['tab_background_hover'];
$tab_background_active = $atts['tab_background_active'];
$tab_border = $atts['tab_border'];
$tab_border_hover = $atts['tab_border_hover'];
$tab_border_active = $atts['tab_border_active'];
$underline_thick_active = $atts['underline_thick_active'];
$underline_color_active = $atts['underline_color_active'];
$underline_bg_color_active = $atts['underline_bg_color_active'];
$underline_thick_inactive = $atts['underline_thick_inactive'];
$underline_color_inactive = $atts['underline_color_inactive'];
$underline_bg_color_inactive = $atts['underline_bg_color_inactive'];
$underline_thick_hover = $atts['underline_thick_hover'];
$underline_color_hover = $atts['underline_color_hover'];
$underline_bg_color_hover = $atts['underline_bg_color_hover'];
$add_shadows = $atts['add_shadows'];
$tab_shadow_active = $atts['tab_shadow_active'];
$tab_shadow_inactive = $atts['tab_shadow_inactive'];
$tab_shadow_hover = $atts['tab_shadow_hover'];
$title_font_size = $atts['title_font_size'];
$title_color = $atts['title_color'];
$title_color_active = $atts['title_color_active'];
$title_color_hover = $atts['title_color_hover'];
$icon_font_size = $atts['icon_font_size'];
$icon_color = $atts['icon_color'];
$icon_color_active = $atts['icon_color_active'];
$icon_color_hover = $atts['icon_color_hover'];
		
		if( $border_width != '' ){
		$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-tab .vc-tta-tab-link, .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading  {border-width: '.$border_width.'px !important;}';
		}
		if( $border_radius != '' ){
		$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-tab .vc-tta-tab-link {border-radius: '.$border_radius.'px !important;}';
		}

	//Style_1
	if ('style_1' == $style || 'style_4' == $style) {
		if( $tab_background != '' ){
		$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-tab .vc-tta-tab-link, .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading {background-color: '.$tab_background.' !important;}';
		}
		if( $tab_background_hover != '' ){
		$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-tab .vc-tta-tab-link:hover, .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-tab .vc-tta-tab-link:focus, .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading:hover {background-color: '.$tab_background_hover.' !important;}';
		}
		if( $tab_background_active!= '' ){
		$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-tab.vc_active .vc-tta-tab-link, .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel.vc_active .vc_tta-panel-heading {background-color: '.$tab_background_active.' !important;}';
		}
		if( $tab_border != '' ){
		$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-tab .vc-tta-tab-link, .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading {border-color: '.$tab_border.' !important;}';
		}
		if( $tab_border_hover != '' ){
		$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-tab .vc-tta-tab-link:hover, .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-tab .vc-tta-tab-link:focus, .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading:hover {border-color: '.$tab_border_hover.' !important;}';
		}
		if( $tab_border_active != '' ){
		$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-tab.vc_active .vc-tta-tab-link,  .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel.vc_active .vc_tta-panel-heading  {border-color: '.$tab_border_active.' !important;}';
		}
	}
	if ('style_2' == $style) {
		$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-tab .vc-tta-tab-link,  .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading  {background-color: transparent !important;}';
		
		if( $tab_border != '' ){
		$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-tab .vc-tta-tab-link,  .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading  {border-color: '.$tab_border.' !important;}';
		}
		if( $tab_border_hover != '' ){
		$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-tab .vc-tta-tab-link:hover, .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-tab .vc-tta-tab-link:focus,  .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading:hover {border-color: '.$tab_border_hover.' !important;}';
		}
		if( $tab_border_active != '' ){
		$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-tab.vc_active .vc-tta-tab-link,  .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel.vc_active .vc_tta-panel-heading {border-color: '.$tab_border_active.' !important;}';
		}
	}
	if ('style_3' == $style) {
		$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-tab .vc-tta-tab-link, .wpb-js-composer .'.$unique_wrapper_class.'  .vc_tta-panel .vc_tta-panel-heading {border-top-width: 0 !important; border-left-width: 0 !important; border-right-width: 0 !important;}';
		$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-tab .vc-tta-tab-link,  .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading  {border-bottom-width:'.$underline_thick_inactive.'px !important;}';
		$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-tab .vc-tta-tab-link:hover, .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-tab .vc-tta-tab-link:focus,  .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading:hover {border-bottom-width: '.$underline_thick_inactive.'px !important;}';
		$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-tab.vc_active .vc-tta-tab-link ,   .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-style-style_3 .vc_tta-tab.vc_active .vc-tta-tab-link,  .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel.vc_active .vc_tta-panel-heading  {border-bottom-width: '.$underline_thick_active.'px !important;}';
		if( $underline_bg_color_inactive != '' ){
		$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-tab .vc-tta-tab-link,  .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading  {background-color: '.$underline_bg_color_inactive.' !important;}';
		}
		if( $underline_bg_color_hover != '' ){
		$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-tab .vc-tta-tab-link:hover, .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-tab .vc-tta-tab-link:focus,  .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading :hover {background-color: '.$underline_bg_color_hover.' !important;}';
		}
		if( $underline_bg_color_active!= '' ){
		$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel.vc_active .vc_tta-panel-heading,  .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel.vc_active .vc_tta-panel-heading  {background-color: '.$underline_bg_color_active.' !important;}';
		}
		if( $underline_color_inactive != '' ){
		$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-tab .vc-tta-tab-link,  .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading  {border-color: '.$underline_color_inactive.' !important;}';
		}
		if( $underline_color_hover != '' ){
		$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-tab .vc-tta-tab-link:hover, .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-tab .vc-tta-tab-link:focus,  .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading:hover  {border-color: '.$underline_color_hover.' !important;}';
		}
		if( $underline_color_active != '' ){
		$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel.vc_active .vc_tta-panel-heading,  .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel.vc_active .vc_tta-panel-heading  {border-color: '.$underline_color_active.' !important;}';
		}
	}
	// Add shadows
	if( $add_shadows != '' ){
	$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-tab .vc-tta-tab-link {'.dpr_shadow_param_to_css($tab_shadow_inactive).'!important}';
	$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-tab .vc-tta-tab-link:hover, .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-tab .vc-tta-tab-link:focus {'.dpr_shadow_param_to_css($tab_shadow_hover).'!important}';
	$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' ..vc_tta-tab.vc_active .vc-tta-tab-link {'.dpr_shadow_param_to_css($tab_shadow_active).'!important}';
	}
	
	// Title style 
	if ($title_font_size != '') {
	$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-tab .vc-tta-tab-link span, .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading h4  { font-size:'.$title_font_size.'px !important}';
	}
	if( $title_color != '' ){
	$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-tab .vc-tta-tab-link span, .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-tab .vc-tta-tab-link .vc_tta-controls-icon,  .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading h4  {color: '.$title_color.' !important;}';
	}
	if( $title_color_hover != '' ){
	$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-tab .vc-tta-tab-link:hover span, .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-tab .vc-tta-tab-link:focus span, .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-tab .vc-tta-tab-link:hover .vc_tta-controls-icon, .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-tab .vc-tta-tab-link:focus h4 .vc_tta-controls-icon,  .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading:hover h4  {color: '.$title_color_hover.' !important;}';
	}
	if( $title_color_active != '' ){
	$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel.vc_active .vc_tta-panel-heading h4 span, .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-tab.vc_active .vc-tta-tab-link span, .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel.vc_active .vc_tta-panel-heading .vc_tta-controls-icon,  .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel.vc_active .vc_tta-panel-heading h4  {color: '.$title_color_active.' !important;}';
	}

	if ($icon_font_size != '') {
	$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-tab .vc-tta-tab-link .vc_tta-icon,  .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading .vc_tta-icon { font-size:'.$icon_font_size.'px !important; line-height:'.$icon_font_size.'px !important; width:'.$icon_font_size.'px !important;}';
	}
	if ($style == 'style_4') {
	$calc_icon_dim = 14;
	$calc_link_pad = 18;
	if (isset($icon_padding) && $icon_padding != '') {
		$calc_link_pad = $icon_padding;
	}
	if (isset($icon_font_size) && $icon_font_size != '') {
		$calc_icon_dim = $icon_font_size;
	}
	$calc_link_dim = 2*$calc_link_pad + $calc_icon_dim;
	$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-tab .vc-tta-tab-link {height:'.$calc_link_dim.'px !important; width:'.$calc_link_dim.'px !important;}';
	}
	if( $icon_color != '' ){
	$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-tab .vc-tta-tab-link .vc_tta-icon, .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading .vc_tta-icon {color: '.$icon_color.' !important;}';
	}
	if( $icon_color_hover != '' ){
	$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-tab .vc-tta-tab-link:hover .vc_tta-icon, .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-tab .vc-tta-tab-link:focus .vc_tta-icon, .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel .vc_tta-panel-heading:hover .vc_tta-icon {color: '.$icon_color_hover.' !important;}';
	}
	if( $icon_color_active != '' ){
	$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel.vc_active .vc_tta-panel-heading h4 .vc_tta-icon, .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-tab.vc_active .vc-tta-tab-link .vc_tta-icon, .wpb-js-composer .'.$unique_wrapper_class.' .vc_tta-panel.vc_active .vc_tta-panel-heading .vc_tta-icon {color: '.$icon_color_active.' !important;}';
	}
	
}

// Pagination custom color 
if ( isset( $atts['pagination_style'] ) && strlen( $atts['pagination_style'] ) > 0 ) {

if ($atts['pagination_style'] != '' && $atts['dots_color'] != '') {
	$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_pagination.vc_pagination-style-outline .vc_pagination-trigger,.wpb-js-composer .'.$unique_wrapper_class.' .vc_pagination.vc_pagination-style-bar .vc_pagination-trigger { border-color:'.$atts['dots_color'].';}';
	$custom_el_css .= '.wpb-js-composer .'.$unique_wrapper_class.' .vc_pagination-style-flat .vc_pagination-trigger,.wpb-js-composer .'.$unique_wrapper_class.' .vc_pagination-style-outline .vc_active .vc_pagination-trigger,.wpb-js-composer .'.$unique_wrapper_class.' .vc_pagination-style-bar .vc_active .vc_pagination-trigger,.wpb-js-composer .'.$unique_wrapper_class.' .vc_pagination-style-outline .vc_pagination-trigger:hover,.wpb-js-composer .'.$unique_wrapper_class.' .vc_pagination-style-bar .vc_pagination-trigger:hover {background-color:'.$atts['dots_color'].' !important;}';
	}
}

if($custom_el_css != '') {
	$output .= '<script>'
				. '(function($) {'
					. '$("head").append("<style>'.$custom_el_css.'</style>")'
				. '})(jQuery);'
			. '</script>';
}


echo $output;

