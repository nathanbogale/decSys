<?php

// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}



if(!class_exists('DPR_Hotspot_Param')) {



	class DPR_Hotspot_Param {

		

		function __construct() {

			if(function_exists('vc_add_shortcode_param')) {

				vc_add_shortcode_param('dpr_hotspot_param' , array(&$this,'dpr_hotspot'), DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/admin/js/dpr_param.js' );

			}

		}

		

		function dpr_hotspot($settings, $value) {

			$param_name = isset($settings['param_name']) ? $settings['param_name'] : '';

			$type = isset($settings['type']) ? $settings['type'] : '';

			$class = isset($settings['class']) ? $settings['class'] : '';

			$uni = uniqid('dpr-hotspot-'.rand());

			$output = '<div class="dpr-hotspot-param-container clearboth">';

			$output .= '<div class="dpr-hotspot-image-holder" data-popup-title="'.esc_attr__('Hotspot Tooltip Content', 'dpr-adeline-extensions').'" data-save-text="'.esc_attr__('Save changes', 'dpr-adeline-extensions').'" data-close-text="'.esc_attr__('Close','dpr-adeline-extensions').'"></div>';

			$output .= '<input type="hidden" id="'.esc_attr($uni).'" name="'.$settings['param_name'].'" class="wpb_vc_param_value dpr_hotspot_var '.$settings['param_name'].' '.$settings['type'].'_field" value=\''.$value.'\' />';

			$output .= '</div>';

			return $output;

		}

	}

}



if(class_exists('DPR_Hotspot_Param')) {

	$DPR_Hotspot_Param = new DPR_Hotspot_Param();

}

