<?php

// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}



/*

* Add-on Name: Before After

*/

class WPBakeryShortCode_DPR_Before_After extends WPBakeryShortCode {}



vc_map(

	array(

	   'name' => esc_html__('DP Before After','dpr-adeline-extensions'),

	   'base' => 'dpr_before_after',

	   'class' => '',

	   'icon'	=> 'icon-dpr-before-after',

  	   "category" =>array( esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions')),

	   'description' => esc_html__('Two compared images with sliding divider.'),

	   'params' => array(

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Main Settings', 'dpr-adeline-extensions' ),

				'param_name'       => 'main_settigs_title',

				'edit_field_class' => 'vc_column vc_col-sm-12',

			),

			array(

				'heading'			=> esc_html__('Direction ', 'dpr-adeline-extensions'),

				'type'				=> 'dpr_image_select',

				'param_name'		=> 'direction',

				'options'			=> array(

					'horizontal'	=> array(

						'label'	=> esc_html__('Horizontal','dpr-adeline-extensions'),

						'src'		=> $module_images . 'before-after/horizontal.jpg'

					),

					'vertical'	=> array(

						'label'	=> esc_html__('Vertical','dpr-adeline-extensions'),

						'src'		=> $module_images . 'before-after/vertical.jpg'

					),

				),

			),

			array(

				'type' 				=> 'number',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set default position of divider in percent spacing from left (eg top in horizontal mode) ', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Default Divider Position', 'dpr-adeline-extensions'),

				'param_name'		=> 'offset',

				'suffix'			=> '%',

				'max'				=> 100,

				'min'				=> 0,

				'value' 			=> 50,

				'edit_field_class' 	=> 'vc_column vc_col-sm-4',

			),

		    array(

				'type' => 'textfield',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enter here label for BEFORE image. If you leave it blank label will be not displayed.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Before Label', 'dpr-adeline-extensions'),

				'param_name' => 'before_label',

				'edit_field_class' 	=> 'vc_column vc_col-sm-4',

			),

		    array(

				'type' => 'textfield',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enter here label for AFTER image. If you leave it blank label will be not displayed.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('After Label', 'dpr-adeline-extensions'),

				'param_name' => 'after_label',

				'edit_field_class' 	=> 'vc_column vc_col-sm-4',

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Additional Settings', 'dpr-adeline-extensions' ),

				'param_name'       => 'extra_features_title',

				'edit_field_class' => 'vc_column vc_col-sm-12',

			),

		   vc_map_add_css_animation( false ),

		    array(

				'type' => 'textfield',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Extra Class Name', 'dpr-adeline-extensions'),

				'param_name' => 'el_class',

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Images', 'dpr-adeline-extensions' ),

				'param_name'       => 'images_title',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group'			   => esc_html('Images','dpr-adeline-extensions')

			),

			array(

				'type' => 'attach_image',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Upload the image which will be set to the right/top side.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Before Image', 'dpr-adeline-extensions'),

				'param_name' => 'first_image',

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'group'			   => esc_html('Images','dpr-adeline-extensions')

			),

			array(

				'type' => 'attach_image',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Upload the image which will be set to the left/bottom side.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('After Image', 'dpr-adeline-extensions'),

				'param_name' => 'second_image',

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'group'			   => esc_html('Images','dpr-adeline-extensions')

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Image Size', 'dpr-adeline-extensions' ),

				'param_name'       => 'images_title_2',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group'			   => esc_html('Images','dpr-adeline-extensions')

			),

			array(

				'type' => 'number',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select the width for the images', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Image width', 'dpr-adeline-extensions'),

				'param_name' => 'image_width',

				'suffix'	=> 'px',

				'value' => 1230,

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'group'			   => esc_html('Images','dpr-adeline-extensions')

			),

			array(

				'type' 				=> 'number',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select the height for the images', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Image height', 'dpr-adeline-extensions'),

				'param_name'		=> 'image_height',

				'suffix'			=> 'px',

				'value' 			=> 630,

				'edit_field_class' 	=> 'vc_column vc_col-sm-6',

				'group'			   	=> esc_html('Images','dpr-adeline-extensions')

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Container Style', 'dpr-adeline-extensions' ),

				'param_name'       => 'style_title_2',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group'		=> esc_html('Style','dpr-adeline-extensions')

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable shadow for this comparison images block.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Use Shadow?', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_shadow',

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				"type" => "dpr_shadow_picker",

				"class" => "",

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set shadow for this block.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Shadow', 'dpr-adeline-extensions'),

				'group' => esc_html__('Design Options', 'dpr-adeline-extensions'),

				"param_name" => "shadow",

				"value" => "none||||||",

				'dependency'		=> array('element' => 'use_shadow', 'value' => array('yes')),

				'group'				=> esc_html__('Style', 'dpr-adeline-extensions'),

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Slider Style', 'dpr-adeline-extensions' ),

				'param_name'       => 'style_title_2',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group'		=> esc_html('Style','dpr-adeline-extensions')

			),

			array(

				'type' => 'number',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Specify the width for the divider', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Divider Width', 'dpr-adeline-extensions'),

				'param_name' => 'divider_width',

				'value' => 1,

				'suffix' => 'px',

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'group'			   => esc_html('Style','dpr-adeline-extensions')

			),

			array(

				'type' => 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Specify the divider color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Divider Color', 'dpr-adeline-extensions'),

				'param_name' => 'divider_color',

				'value' => '#292933',

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'group'		=> esc_html('Style','dpr-adeline-extensions')

			),

			array(

				'type' => 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Specify the slider handle background color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Handle Background Color', 'dpr-adeline-extensions'),

				'param_name' => 'handler_bg',

				'value' => '#292933',

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'group'		=> esc_html('Style','dpr-adeline-extensions')

			),

			array(

				'type' => 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Specify the slider handle arrows color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Handle Arrows Color', 'dpr-adeline-extensions'),

				'param_name' => 'handler_color',

				'value' => '#ffffff',

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'group'		=> esc_html('Style','dpr-adeline-extensions')

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Labels Style', 'dpr-adeline-extensions' ),

				'param_name'       => 'style_title_3',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group'		=> esc_html('Style','dpr-adeline-extensions')

			),

			array(

				'type' => 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Specify color for labels.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Label Color', 'dpr-adeline-extensions'),

				'param_name' => 'label_color',

				'value' => '#ffffff',

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'group'		=> esc_html('Style','dpr-adeline-extensions')

			),

			array(

				'type' => 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Specify background color for labels.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Label Background Color', 'dpr-adeline-extensions'),

				'param_name' => 'label_bg',

				'value' => 'rgba(255, 255, 255, 0.2)',

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'group'		=> esc_html('Style','dpr-adeline-extensions')

			),





		),

	)

);