<?php



/**



 * Portfolio Options -> Single Portfolio Item



 * 



 */







	Redux::setSection( $opt_name, array(



		'title' => esc_html__('Single Portfolio Item', 'dpr-adeline-extensions'),



		'id' => 'single_portfolio_item',



		'subsection' => true,



		'fields' => array(



						array(



							'id'   => 'portfolio_single_setting_info',



							'type' => 'info',



							'style' => 'dpr-title',



							'title' => wp_kses_post(__('<h3>General Setting</h3>', 'dpr-adeline-extensions')),



						),



						array (



							'id' => 'portfolio_single_layout',



							'type' => 'image_select',



							'title' => __('General Layout', 'dpr-adeline-extensions'),



							'options' => array (



								'right-sidebar' => array (



									'title' => esc_html__('Sidebar right', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/sidebar_right.png'



								),					



								'left-sidebar' => array (



									'title' => esc_html__('Sidebar left', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/sidebar_left.png'



								),



								'both-sidebars' => array (



									'title' => esc_html__('Both sidebars', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/sidebar_both.png'



								),



	



								'full-width' => array (



									'title' => esc_html__('Full width', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/sidebar_disabled.png',	



								),



								'full-screen' => array (



									'title' => esc_html__('Full screen', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/full_screen.png',	



								),



							),



							'default' => 'full-width',



							'hint' => array (



								'title' => esc_attr__('Single Post Layout', 'dpr-adeline-extensions'),



								'content' => esc_attr__('Choose default single portfolio item layout eg sidebar position.', 'dpr-adeline-extensions')



							)



						),



						array (



							'id' => 'portfolio_single_both_sidebars_column_order',



							'type' => 'image_select',



							'title' => __('Both Sidebars: Column Order', 'dpr-adeline-extensions'),



							'options' => array (



								'order-scs' => array (



									'title' => esc_html__('Sidebar/Content/Sidebar', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/scs.png'



								),					



								'order-ssc' => array (



									'title' => esc_html__('Sidebar/Sidebar/Content', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/ssc.png'



								),



								'order-css' => array (



									'title' => esc_html__('Content/Sidebar/Sidebar', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/css.png'



								),



							),



							'default' => 'order-scs',



							'hint' => array (



								'title' => esc_attr__('Both Sidebars: Column Order', 'dpr-adeline-extensions'),



								'content' => esc_attr__('Choose default column order. This general settings can be overwriten for specific pages.', 'dpr-adeline-extensions')



							),



							'required' => array('portfolio_single_layout','equals','both-sidebars')



						),



						array (



							'id' => 'portfolio_single_content_layout',



							'type' => 'image_select',



							'title' => __('Content Layout Style', 'dpr-adeline-extensions'),



							'desc' => wp_kses_post(__('<small>If you select option <i>"Free Layout"</i> portfolio item will be displayed as default post and you can create any custom layout with Visual Composer for example.</small>', 'dpr-adeline-extensions')),



							'options' => array (



								'details-left' => array (



									'title' => esc_html__('Details Left', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/portfolio/single_style_1.png'



								),					



								'details-right' => array (



									'title' => esc_html__('Details Right', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/portfolio/single_style_2.png'



								),					



								'details-bellow' => array (



									'title' => esc_html__('Details Bellow', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/portfolio/single_style_3.png'



								),



								'post' => array (



									'title' => esc_html__('Free Layout', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/portfolio/single_style_4.png'



								),					



							),



							'default' => 'details-right',



							'hint' => array (



								'title' => esc_attr__('Content Layout Style', 'dpr-adeline-extensions'),



								'content' => esc_attr__('Choose default single item layout eg media and details position. If you select post style portfoli item will be displayed as default post and you will be able create free item layout with Visual Composer for example.', 'dpr-adeline-extensions')



							)



						),



						array(



							'id'       => 'portfolio_single_media_block_width',



							'type'     => 'radio',



							'title'    => __('Media Block Width', 'dpr-adeline-extensions'),



							'options'  => array(



								'one-third'  => 'One Third',



								'half' => 'One Half', 



								'two-thirds' => 'Two Thirds'



							),



							'default' => 'two-thirds',



							'hint' => array(



								'title'   => esc_attr__('Media Block Width','dpr-adeline-extensions'),



								'content' => esc_attr__('Set media block width. ','dpr-adeline-extensions')



							),



							'required' => array('portfolio_single_content_layout','equals',array('details-left','details-right'))



						),



						array(



							'id'       => 'portfolio_single_sticky_columns',



							'type'     => 'switch',



							'default' => false,



							'title'    =>  esc_html__('Use Sticky Columns','dpr-adeline-extensions'),



							'hint' => array(



								'title'   => esc_attr__('Use Sticky Columns','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Enable or disable sticky columns.','dpr-adeline-extensions')



							),



							'required' => array('portfolio_single_content_layout','equals',array('details-left','details-right'))



						), 



						array(



							'id'   => 'portfolio_single_elements_post_style_info',



							'type' => 'info',



							'style' => 'dpr-title',



							'title' => wp_kses_post(__('<h3>Elements & Meta Data Positioning</h3>', 'dpr-adeline-extensions')),



							'required' => array('portfolio_single_content_layout','equals','post')



						),



						array(



							'id'      => 'portfolio_single_post_style_elements',



							'type'    => 'sorter',



							'title'   => 'Single Portfolio Elements Order',



							'hint' => array(



								'title'   => esc_attr__('Single Portfolio Elements Order','dpr-adeline-extensions'),



								'content' => esc_attr__('Enable or disable display of certain elements for single portfolio item and set element order','dpr-adeline-extensions')



							),



							'options' => array(



								'enabled'  => array(



									'media' => 'Featured Image',



									'title'   => 'Title',



									'meta' => 'Meta Data',



									'content'     => 'Content',



									'tags' => 'Tags',



									'share' => 'Social Share',



									'next_prev' => 'Next Prev Links',



									'related_portfolio' => 'Related Portfolios',



									'comments' => 'Comments',



								),



								'disabled' => array(



								)



							),



							'required' => array('portfolio_single_content_layout','equals','post')



						),



						array(



							'id'      => 'portfolio_single_meta',



							'type'    => 'sorter',



							'title'   => 'Single Post Meta Data Order',



							'hint' => array(



								'title'   => esc_attr__('Single Poportfolio Meta Data Order','dpr-adeline-extensions'),



								'content' => esc_attr__('Enable or disable meta data display for single portfolio and set meta data order','dpr-adeline-extensions')



							),



							'options' => array(



								'enabled'  => array(



									'date' => 'Date',



									'author'   => 'Author',



									'category' => 'Category',



									'comments'     => 'Comments'



								),



								'disabled' => array(



								)



							),



							'required' => array('portfolio_single_content_layout','equals','post')



						),



						array(



							'id'   => 'portfolio_single_elements_info',



							'type' => 'info',



							'style' => 'dpr-title',



							'title' => wp_kses_post(__('<h3>Elements Positioning</h3>', 'dpr-adeline-extensions')),



							'required' => array('portfolio_single_content_layout','not','post')



						),



						array(



							'id'      => 'portfolio_single_elements',



							'type'    => 'sorter',



							'title'   => 'Single Portfolio Elements Order',



							'hint' => array(



								'title'   => esc_attr__('Single Portfolio Elements Order','dpr-adeline-extensions'),



								'content' => esc_attr__('Enable or disable display of certain elements for single portfolio item and set element order','dpr-adeline-extensions')



							),



							'options' => array(



								'enabled'  => array(



									'media_details' => 'Media & Details Description',



									'next_prev' => 'Next Prev Links',



									'related_portfolio' => 'Related Portfolios',



									'comments' => 'Comments',



								),



								'disabled' => array(									



								'content'     => 'Content',



								)



							),



							'required' => array('portfolio_single_content_layout','not','post')



						),



						array(



							'id'       => 'portfolio_single_tags',



							'type'     => 'switch',



							'default' => false,



							'title'    =>  esc_html__('Display Tags? ','dpr-adeline-extensions'),



							'hint' => array(



								'title'   => esc_attr__('Display Tags?','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Enable or disable display of tags.','dpr-adeline-extensions')



							),



							'required' => array('portfolio_single_content_layout','not','post')



						),



						array(



							'id'       => 'portfolio_single_share',



							'type'     => 'switch',



							'default' => false,



							'title'    =>  esc_html__('Display Social Share Buttons? ','dpr-adeline-extensions'),



							'hint' => array(



								'title'   => esc_attr__('Display Social Share Buttons?','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Enable or disable display of social share links.','dpr-adeline-extensions')



							),



							'required' => array('portfolio_single_content_layout','not','post')



						),



						array(



							'id'   => 'portfolio_single_media_info',



							'type' => 'info',



							'style' => 'dpr-title',



							'title' => wp_kses_post(__('<h3>Media Block Setting</h3>', 'dpr-adeline-extensions')),



							'required' => array('portfolio_single_content_layout','not','post')



						),



						array (



							'id' => 'portfolio_single_media_type',



							'type' => 'image_select',



							'title' => __('Media Block Content Type', 'dpr-adeline-extensions'),



							'required' => array('portfolio_single_content_layout','not','post'),



							'options' => array (



								'image' => array (



									'title' => esc_html__('Featured Image', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/portfolio/media_image.png'



								),					



								'carousel' => array (



									'title' => esc_html__('Carousel', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/portfolio/media_carousel.png'



								),



								'grid' => array (



									'title' => esc_html__('Image Grid', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/portfolio/media_grid.png'



								),



								'video' => array (



									'title' => esc_html__('Video', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/portfolio/media_video.png'



								),



								'audio' => array (



									'title' => esc_html__('Audio', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/portfolio/media_audio.png'



								),



								'particle' => array (



									'title' => esc_html__('Particle', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/portfolio/media_particle.png'



								),



							),



							'default' => 'image',



							'hint' => array (



								'title' => esc_attr__('Media Block Content Type', 'dpr-adeline-extensions'),



								'content' => esc_attr__('Choose default media type for portfolio. You can allways overwrite it for certain portfolio items.', 'dpr-adeline-extensions')



							)



						),



						array(



							'id'   => 'portfolio_single_fields_info',



							'type' => 'info',



							'style' => 'dpr-title',



							'title' => wp_kses_post(__('<h3>Custom Fields Settings</h3>', 'dpr-adeline-extensions')),



							'required' => array('portfolio_single_content_layout','not','post')



						),



						array(



							'id'       => 'porfolio_single_description_1_title',



							'type'     => 'text',



							'title'    => __('Custom Field 1 Title', 'dpr-adeline-extensions'),



							'required' => array('portfolio_single_content_layout','not','post'),



							'default'  => 'Description',



							'hint' => array(



								'title'   => esc_attr__('Custom Field Title 1','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Set title for first custom description field in portfolio item.','dpr-adeline-extensions')



							),



						),



						array(



							'id'       => 'porfolio_single_description_2_title',



							'type'     => 'text',



							'title'    => __('Custom Field 2 Title', 'dpr-adeline-extensions'),



							'required' => array('portfolio_single_content_layout','not','post'),



							'default'  => 'Tasks',



							'hint' => array(



								'title'   => esc_attr__('Custom Field 2 Title','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Set title for second custom description field in portfolio item.','dpr-adeline-extensions')



							),



						),



						array(



							'id'       => 'porfolio_single_description_3_title',



							'type'     => 'text',



							'title'    => __('Short Info Block Title', 'dpr-adeline-extensions'),



							'required' => array('portfolio_single_content_layout','not','post'),



							'default'  => 'Additional',



							'hint' => array(



								'title'   => esc_attr__('Custom Field 3 Title','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Set title for third custom description field in portfolio item.','dpr-adeline-extensions')



							),



						),



						array(



							'id'       => 'porfolio_single_description_short_1_title',



							'type'     => 'text',



							'title'    => __('Short Info Field 1 Title', 'dpr-adeline-extensions'),



							'required' => array('portfolio_single_content_layout','not','post'),



							'default'  => 'Client',



							'hint' => array(



								'title'   => esc_attr__('Short Info Field Title 1','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Set title for first short info field.','dpr-adeline-extensions')



							),



						),



						array(



							'id'       => 'porfolio_single_description_short_2_title',



							'type'     => 'text',



							'title'    => __('Short Info Field 2 Title', 'dpr-adeline-extensions'),



							'required' => array('portfolio_single_content_layout','not','post'),



							'default'  => 'Date',



							'hint' => array(



								'title'   => esc_attr__('Short Info Field 2 Title','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Set title for second short info field.','dpr-adeline-extensions')



							),



						),



						array(



							'id'       => 'porfolio_single_description_short_3_title',



							'type'     => 'text',



							'title'    => __('Short Info Field 3 Title', 'dpr-adeline-extensions'),



							'required' => array('portfolio_single_content_layout','not','post'),



							'default'  => 'Website',



							'hint' => array(



								'title'   => esc_attr__('Short Info Field 3 Title','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Set title for short info field.','dpr-adeline-extensions')



							),



						),



						array(



							'id'       => 'porfolio_single_action_button_title',



							'type'     => 'text',



							'title'    => __('Action Button Title', 'dpr-adeline-extensions'),



							'required' => array('portfolio_single_content_layout','not','post'),



							'default'  => 'See More',



							'hint' => array(



								'title'   => esc_attr__('Related Projects Block Title','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Set title for related projects block.','dpr-adeline-extensions')



							),



						),



						array(



							'id'   => 'portfolio_single_related_info',



							'type' => 'info',



							'style' => 'dpr-title',



							'title' => wp_kses_post(__('<h3>Related Projects Section Setting</h3>', 'dpr-adeline-extensions'))



						),



						array(



							'id'       => 'porfolio_single_related_title',



							'type'     => 'text',



							'title'    => __('Related Portfolios Block Title', 'dpr-adeline-extensions'),



							'default'  => 'Related Projects',



							'hint' => array(



								'title'   => esc_attr__('Related Projects Block Title','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Set title for related projects block.','dpr-adeline-extensions')



							),



						),



						array(



							'id'       => 'portfolio_single_related_count',



							'type'     => 'slider', 



							'title'    => __('Related Projects Count', 'dpr-adeline-extensions'),



							'default'  => '3',



							'min'      => '1',



							'step'     => '1',



							'max'      => '12',



							'hint' => array(



								'title'   => esc_attr__('Related Projects Count','dpr-adeline-extensions'),



								'content' => esc_attr__('Set max count of related projects to display.','dpr-adeline-extensions')



							)



						),



						array(



							'id'       => 'porfolio_single_related_columns',



							'type'     => 'slider', 



							'title'    => __('Related Projects Columns', 'dpr-adeline-extensions'),



							'default'  => '3',



							'min'      => '1',



							'step'     => '1',



							'max'      => '6',



							'hint' => array(



								'title'   => esc_attr__('Related Projects Columns','dpr-adeline-extensions'),



								'content' => esc_attr__('Set columns count in related projects section.','dpr-adeline-extensions')



							)



						),



						array(



						'id' => 'porfolio_single_related_image_width',



						'type' => 'dimensions',



						'title' => esc_html__('Related Projets Image Custom Width (px)', 'dpr-adeline-extensions'),



						'width' => true,



						'height' => false,



						'mode' => array ('width' => 'width', 'height' => 'height'),



						'units' => array('px'),



						'default'  => array(



							'width' => ''



						),



						'hint' => array(



							'title'   => esc_attr__('Related Projets Image Custom Width','dpr-adeline-extensions'),



							'content' => esc_attr__('Specify the custom image width in related projets section. In combination with custom image height bellow you can set custom featured image aspect ratio. If you leave this fields blank will be used original images size and aspect ratio.','dpr-adeline-extensions')



						)



						),



						array(



						'id' => 'porfolio_single_related_image_height',



						'type' => 'dimensions',



						'title' => esc_html__('Related Projects Image Custom Height (px)', 'dpr-adeline-extensions'),



						'width' => false,



						'height' => true,



						'mode' => array ('width' => 'width', 'height' => 'height'),



						'units' => array('px'),



						'default'  => array(



							'width' => ''



						),



						'hint' => array(



							'title'   => esc_attr__('Related Projects Image Custom Height','dpr-adeline-extensions'),



							'content' => esc_attr__('Specify the custom image image height in related projects section. In combination with custom image width above you can set custom featured image aspect ratio. If you leave this fields blank will be used original images size and aspect ratio.','dpr-adeline-extensions')



						)



						),



		)



	));



