<?php

// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}

/*

* Add-on Name: Featured box

*/



class WPBakeryShortCode_DPR_Services_Box extends WPBakeryShortCode {}



vc_map(

	array(

		'name'					=> esc_html__('DP Service Box', 'dpr-adeline-extensions'),

		'base'					=> 'dpr_service_box',

		"icon"					=> 'icon-dpr-service-box',

		"class"					=> 'dpr_services_box',

  		"category" =>array( esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions')),

		'description'			=> esc_html__('Box with number, background image and short information', 'dpr-adeline-extensions'),

		'params'				=> array(

			array(

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose content position .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Content position', 'dpr-adeline-extensions'),

				'type'				=> 'dpr_image_select',

				'param_name'		=> 'content_pos',

				'value' 			=> 'lt',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'options'			=> array(

					'lt'			=> array(

						'label'			=> esc_html__('Left Top', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'ads-banner/left-top.png'

					),

					'lc'			=> array(

						'label'			=> esc_html__('Left center', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'ads-banner/left-center.png'

					),

					'lb'			=> array(

						'label'			=> esc_html__('Left bottom', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'ads-banner/left-bottom.png'

					),

					'ct'			=> array(

						'label'			=> esc_html__('Center Top', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'ads-banner/center-top.png'

					),

					'cc'			=> array(

						'label'			=> esc_html__('Center', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'ads-banner/center-center.png'

					),

					'cb'			=> array(

						'label'			=> esc_html__('Center bottom', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'ads-banner/center-bottom.png'

					),

					'rt'			=> array(

						'label'			=> esc_html__('Right Top', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'ads-banner/right-top.png'

					),
					
					'rc'			=> array(

						'label'			=> esc_html__('Right center', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'ads-banner/right-center.png'

					),

					'rb'			=> array(

						'label'			=> esc_html__('Right bottom', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'ads-banner/right-bottom.png'

					),



				)

			),

			array(

				'heading'			=> esc_html__('Number/Icon position', 'dpr-adeline-extensions'),

				'type'				=> 'dpr_image_select',

				'param_name'		=> 'number_pos',
	
				'value' => 'rb',
	
				'options'			=> array(
	
					'lt'			=> array(

						'label'			=> esc_html__('Left Top', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'service-box/number-top-left.png'

					),

					'ct'			=> array(

						'label'			=> esc_html__('Center Top', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'service-box/number-top-center.png'

					),

					'rt'			=> array(

						'label'			=> esc_html__('Right Top', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'service-box/number-top-right.png'

					),
	
					'lb'			=> array(

						'label'			=> esc_html__('Left bottom', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'service-box/number-bottom-left.png'

					),

					'cb'			=> array(

						'label'			=> esc_html__('Center bottom', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'service-box/number-bottom-center.png'

					),

					'rb'			=> array(

						'label'			=> esc_html__('Right bottom', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'service-box/number-bottom-right.png'

					)

				)

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Additional Settings', 'dpr-adeline-extensions' ),

				'param_name'       => 'extra_features_title',

				'edit_field_class' => 'vc_column vc_col-sm-12',

			),
	
			array(

				'type'				=> 'dpr_switcher',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Enable you to set custom fixed height for box.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Use Fixed Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_fixed_height',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',
	
				'description' 		=> 'By default is auto height ( according content eg background image). But you can set custom fixed height for box.',

			),

			array(
	
				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set box fixed height.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Box Fixed Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'box_height',

				'min'				=> 0,

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'dependency'		=> array('element' => 'use_fixed_height', 'value'   => 'yes'),
			),


		   vc_map_add_css_animation( false ),

		    array(

				'type' => 'textfield',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Extra Class Name', 'dpr-adeline-extensions'),

				'param_name' => 'el_class',

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set content container top padding.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Top Padding', 'dpr-adeline-extensions'),

				'param_name'		=> 'content_padding_top',

				'min'				=> 0,
	
				'value' 			=> 60,

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 vc_column-with-padding',

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set content container right padding.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Right Padding', 'dpr-adeline-extensions'),

				'param_name'		=> 'content_padding_right',

				'min'				=> 0,

				'value' 			=> 50,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set content container bottom padding.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Bottom Padding', 'dpr-adeline-extensions'),

				'param_name'		=> 'content_padding_bottom',

				'min'				=> 0,

				'value' 			=> 60,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set content container right padding.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Left Padding', 'dpr-adeline-extensions'),

				'param_name'		=> 'content_padding_left',

				'min'				=> 0,

				'value' 			=> 50,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'textarea',

				'heading'			=> esc_html__('Title', 'dpr-adeline-extensions'),

				'param_name'		=> 'title',

				'value'				=> esc_html__('Box Title', 'dpr-adeline-extensions'),

				'admin_label'		=> true,

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'textfield',

				'heading'			=> esc_html__('Subtitle', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle',

				'value'				=> esc_html__('Subtitle', 'dpr-adeline-extensions'),

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'textarea',

				'heading'			=> esc_html__('Content', 'dpr-adeline-extensions'),

				'param_name'		=> 'main_content',

				'value'				=> esc_html__('Service box content. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque mollis ex eu blandit scelerisque.', 'dpr-adeline-extensions'),

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select where the link should be applied.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Link aply to', 'dpr-adeline-extensions'),

				'param_name'		=> 'read_more',

				'value'				=> 'none',

				'options'			=> array(

					esc_html__('No Link', 'dpr-adeline-extensions')		=> 'none',

					esc_html__('Complete Box', 'dpr-adeline-extensions')	=> 'box',

					esc_html__('Box Title', 'dpr-adeline-extensions')		=> 'title',

					esc_html__('Read More', 'dpr-adeline-extensions')		=> 'more',

				),

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'vc_link',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Add a custom link or select existing page. You can remove existing link as well.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Link URL', 'dpr-adeline-extensions'),

				'param_name'		=> 'link',

				'dependency'		=> array('element' => 'read_more', 'value' => array('box','title','more')),

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to enable or disable the Read more.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Display Read more button', 'dpr-adeline-extensions'),

				'param_name'		=> 'readmore_show',

				'options'			=> array(

					'show'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'dependency'		=> array('element' => 'read_more', 'value' => array('box','title','more')),

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose read more style.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Read more style', 'dpr-adeline-extensions'),

				'param_name'		=> 'readmore_style',

				'value'				=> 'button',

				'options'			=> array(

					esc_html__('Button', 'dpr-adeline-extensions')		=> 'button',

					esc_html__('Outlined Button', 'dpr-adeline-extensions') => 'button-outlined',

					esc_html__('Minimal', 'dpr-adeline-extensions')			=> 'minimal',

					esc_html__('Custom Button', 'dpr-adeline-extensions')	=> 'custom',

				),

				'dependency'		=> array('element' => 'readmore_show', 'value'   => 'show'),

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom button size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom button size', 'dpr-adeline-extensions'),

				'param_name'		=> 'custom_button_size',

				'value'				=> 'btn-sm',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'options'			=> array(

					esc_html__('Default', 'dpr-adeline-extensions')		=> '',

					esc_html__('Large', 'dpr-adeline-extensions') => 'btn-lg',

					esc_html__('Extra Large', 'dpr-adeline-extensions')	=> 'btn-xl',

					esc_html__('Small', 'dpr-adeline-extensions')	=> 'btn-sm',

				),

				'dependency'		=> array('element' => 'readmore_style', 'value'   => 'custom'),

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom button shape.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom button shape', 'dpr-adeline-extensions'),

				'param_name'		=> 'custom_button_shape',

				'value'				=> '',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'options'			=> array(

					esc_html__('Default', 'dpr-adeline-extensions')		=> '',

					esc_html__('Rounded', 'dpr-adeline-extensions') => 'btn-round',

					esc_html__('Circle', 'dpr-adeline-extensions')	=> 'btn-circle',

					esc_html__('Square', 'dpr-adeline-extensions')	=> 'btn-square',

				),

				'dependency'		=> array('element' => 'readmore_style', 'value'   => 'custom'),

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom button text color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'custom_button_color',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'dependency'		=> array('element' => 'readmore_style', 'value'   => array('custom','minimal')),

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom button text color hover', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'custom_button_color_hover',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'dependency'		=> array('element' => 'readmore_style', 'value'   => array('custom','minimal')),

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom button background color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background', 'dpr-adeline-extensions'),

				'param_name'		=> 'custom_button_bg_color',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'dependency'		=> array('element' => 'readmore_style', 'value'   => 'custom'),

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom button background color hover', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'custom_button_bg_color_hover',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'dependency'		=> array('element' => 'readmore_style', 'value'   => 'custom'),

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom button border color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border', 'dpr-adeline-extensions'),

				'param_name'		=> 'custom_button_border_color',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'dependency'		=> array('element' => 'readmore_style', 'value'   => 'custom'),

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom button border color hover', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'custom_button_border_color_hover',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'dependency'		=> array('element' => 'readmore_style', 'value'   => 'custom'),

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'textfield',

				'heading'			=> esc_html__('Read more text', 'dpr-adeline-extensions'),

				'param_name'		=> 'readmore_text',

				'value'				=> esc_html__('Read more', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'readmore_show', 'value'   => 'show'),

				'group'				=> esc_html__('Content', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select existing icon, upload custom image or add the text.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Number/Icon container content', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_type',

				'value'				=> 'text',

				'options'			=> array(

					esc_html__('Text', 'dpr-adeline-extensions')	=> 'text',					
	
					esc_html__('Icon', 'dpr-adeline-extensions')	=> 'icon',

					esc_html__('Image', 'dpr-adeline-extensions')	=> 'custom',
	


				),

				'group'				=> esc_html__('Number/Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set number/icon container top padding.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Top Padding', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_padding_top',

				'min'				=> 0,
				
				'value' 			=> 60,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Number/Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set number/icon container right padding.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Right Padding', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_padding_right',

				'min'				=> 0,
				
				'value' 			=> 50,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Number/Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set number/icon container bottom padding.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Bottom Padding', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_padding_bottom',

				'min'				=> 0,
				
				'value' 			=> 60,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Number/Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set number/icon container right padding.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Left Padding', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_padding_left',

				'min'				=> 0,
				
				'value' 			=> 50,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Number/Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to use vertical text ( rotated 90deg counter clockwise).', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Vertical Text?', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_vertical_text',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'dependency'		=> array('element' => 'icon_type', 'value' => array('text')),

				'group'				=> esc_html__('Number/Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to scale number container on hover.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Scale Number on Hover?', 'dpr-adeline-extensions'),

				'param_name'		=> 'scale_on_hover',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Number/Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'textarea',

				'heading'			=> esc_html__('Text', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_text',

				'dependency'		=> array('element' => 'icon_type', 'value' => array('text')),

				'group'				=> esc_html__('Number/Icon', 'dpr-adeline-extensions'),

				

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom text icon color. Default is #b5bdc9.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'text_icon_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'icon_type', 'value' => array('text')),

				'group'				=> esc_html__('Number/Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'text_icon_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'icon_type', 'value' => array('text')),

				'group'				=> esc_html__('Number/Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom linne height..', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'text_icon_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'icon_type', 'value' => array('text')),

				'group'				=> esc_html__('Number/Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom letter spacing.', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'text_icon_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'icon_type', 'value' => array('text')),

				'group'				=> esc_html__('Number/Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'text_icon_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'dependency'		=> array('element' => 'icon_type', 'value' => array('text')),

				'group'				=> esc_html__('Number/Icon', 'dpr-adeline-extensions'),

	  		),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose color on hover', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color: Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'text_icon_color_hover',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

				'dependency'		=> array('element' => 'icon_type', 'value' => array('text')),

				'group'				=> esc_html__('Number/Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to use custom Google font.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'text_icon_use_google_fonts',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'dependency'		=> array('element' => 'icon_type', 'value' => array('text')),

				'group'				=> esc_html__('Number/Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'text_icon_custom_fonts',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'dependency'		=> array('element' => 'text_icon_use_google_fonts', 'value' => 'yes'),

				'group'				=> esc_html__('Number/Icon', 'dpr-adeline-extensions'),

			),

		  array(

				"type" => "dpr_icon_selector",

				"heading" => esc_attr__("Icon", 'dpr-adeline-extensions'),

				"param_name" => "icon",

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select icon.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'icon_type', 'value' => 'icon',),

				'group'				=> esc_html__('Number/Icon', 'dpr-adeline-extensions'),

			),



			array(

				'type'				=> 'attach_image',

				'heading'			=> esc_html__('Upload image', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_image_id',

				'admin_label'		=> true,

				'description'		=> esc_html__('Upload the custom image from media library', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'icon_type', 'value' => array('custom')),

				'group'				=> esc_html__('Number/Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set the size for the icon (image).', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Size', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_size',

				'min'				=> 12,

				'edit_field_class'	=> 'vc_column vc_col-sm-4   ',

				'dependency'		=> array('element' => 'icon_type', 'value' => array('custom', 'icon')),

				'group'				=> esc_html__('Number/Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'class'				=> '',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the icon color. The default color for the style Classic and Outlined style is main accent color set in Template Options. The default color for the badge style is #fff.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-4  ',

				'dependency'		=> array('element' => 'icon_type', 'value' => array('icon')),

				'group'				=> esc_html__('Number/Icon', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'class'				=> '',

				'heading' 			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the icon hover color. The default color for the style Classic and Outlined style is main accent color set in Template Options. The default color for the badge style is #fff.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'icon_hover',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'dependency'		=> array('element' => 'icon_type', 'value' => array('icon')),

				'group'				=> esc_html__('Number/Icon', 'dpr-adeline-extensions'),

			),


			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select hover bacground type.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Hover Background Type', 'dpr-adeline-extensions'),

				'param_name'		=> 'hover_bg_type',

				'value'				=> 'image',

				'options'			=> array(

					esc_html__('Image', 'dpr-adeline-extensions')		=> 'image',

					esc_html__('Solid color', 'dpr-adeline-extensions')	=> 'color',

					esc_html__('Gradient', 'dpr-adeline-extensions')		=> 'gradient'

				),

				'group'				=> esc_html__('Hover Background', 'dpr-adeline-extensions'),

			),
	
			array(

				'type'				=> 'attach_image',

				'heading'			=> esc_html__('Hover Background image', 'dpr-adeline-extensions'),

				'param_name'		=> 'hover_bg_image',

				'admin_label'		=> true,

				'description'		=> esc_html__('Upload the custom image from media library', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'hover_bg_type', 'value' => 'image'),

				'group'				=> esc_html__('Hover Background', 'dpr-adeline-extensions'),

				'edit_field_class'	=> 'vc_column vc_col-sm-6'

			),

			array(

				'type'				=> 'attach_image',

				'heading'			=> esc_html__('Idle Background image', 'dpr-adeline-extensions'),

				'param_name'		=> 'idle_bg_image',

				'description'		=> esc_html__('Upload the custom image from media library. Idle background image is optional but you can use it to have background image for idle state positioned exactly as hover image.', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'hover_bg_type', 'value' => 'image'),

				'group'				=> esc_html__('Hover Background', 'dpr-adeline-extensions'),

				'edit_field_class'	=> 'vc_column vc_col-sm-6'


			),
	
			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set hover background color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Hover Background color', 'dpr-adeline-extensions'),

				'param_name'		=> 'hover_bg_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'dependency'		=> array('element' => 'hover_bg_type', 'value' => 'color'),

				'group'				=> esc_html__('Hover Background', 'dpr-adeline-extensions'),

			),	
	
			array(

				'type' => 'dpr_gradient_picker',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the gradient for hover background.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Hover Background Gradient', 'dpr-adeline-extensions'),

				'param_name' => 'hover_bg_gradient',

				'value' => '45;0%/rgba(0, 5, 56, 0.35);100%/rgba(10, 48, 169, 0.35)',

				'dependency'		=> array('element' => 'hover_bg_type', 'value' => 'gradient'),

				'group'				=> esc_html__('Hover Background', 'dpr-adeline-extensions'),

			),
	

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Title Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_typography_head',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'title', 'not_empty' => true),

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom ttle color. Default is headings color set in template options.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'title', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size.Default is 18px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'title', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title linne height.Default is 18px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'title', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'title', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'title_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'dependency'		=> array('element' => 'title', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

	  		),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title color in hover state.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color: Hover State', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_color_hover',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'title', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font. .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_google_fonts',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'dependency'		=> array('element' => 'title', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'title_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'dependency'		=> array('element' => 'use_google_fonts', 'value' => 'yes'),

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Subtitle Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_typography_head',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'subtitle', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom subtitle color. Default is #808080.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'subtitle', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size.Default is 13px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'subtitle', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom linne height.Default is 28px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'subtitle', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'subtitle', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'subtitle_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'dependency'		=> array('element' => 'subtitle', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

	  		),



			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom subtitle color in hover state.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__(' Color:Hover State', 'dpr-adeline-extensions'),

				'param_name'		=> 'subtitle_color_hover',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'dependency'		=> array('element' => 'subtitle', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Content Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'content_typgraphy_head',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'main_content', 'not_empty' => true),

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom content color. Default is text color set in template options.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'content_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'main_content', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size.Default text font size set in template options .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'content_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'main_content', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title linne height. Default is text line height set in template options .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'content_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'main_content', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'content_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'main_content', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'content_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'dependency'		=> array('element' => 'main_content', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

	  		),



			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom content color in hover state.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color: Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'content_color_hover',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'dependency'		=> array('element' => 'main_content', 'not_empty' => true),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),



			array(

				'type' => 'css_editor',

				'heading' => __( 'CSS box', 'dpr-adeline-extensions' ),

				'param_name' => 'css',

				'group' => __( 'Design Options', 'dpr-adeline-extensions' ),

			),
			

			array(

				'type' => 'dropdown',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set shadow for featured box.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Shadow', 'dpr-adeline-extensions'),

				'param_name' => 'box_shadow',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'value' => array(

						__('None', 'dpr-adeline-extensions') => '',

						__('Shadow Depth 1', 'dpr-adeline-extensions') => '1',

						__('Shadow Depth 2', 'dpr-adeline-extensions') => '2',

						__('Shadow Depth 3', 'dpr-adeline-extensions') => '3',

						__('Shadow Depth 4', 'dpr-adeline-extensions') => '4',

						__('Shadow Depth 5', 'dpr-adeline-extensions') => '5',

						__('Shadow Depth 6', 'dpr-adeline-extensions') => '6',

						__('Custom Shadow', 'dpr-adeline-extensions') => 'custom',

					   ),

				'group'	=> esc_html__('Design Options', 'dpr-adeline-extensions'),

			),

			array(

				"type" => "dpr_shadow_picker",

				"class" => "",

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom shadow for featured box.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom Shadow', 'dpr-adeline-extensions'),

				"param_name" => "box_shadow_custom",

				"value" => "none||||||",

				'dependency'		=> array('element' => 'box_shadow', 'value' => array('custom')),

				'group'	=> esc_html__('Design Options', 'dpr-adeline-extensions'),

			),



			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Hover State Options', 'dpr-adeline-extensions' ),

				'param_name'       => 'design_option_title_1',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group'				=> esc_html__('Design Options', 'dpr-adeline-extensions'),

			),



			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose custom hover state border color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'box_border_color_hover',

				'edit_field_class'	=> 'vc_col-sm-4 vc_column ',

				'group'				=> esc_html__('Design Options', 'dpr-adeline-extensions'),

			),



			array(

				'type' => 'dropdown',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom border style.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border Style', 'dpr-adeline-extensions'),

				'param_name' => 'box_border_style_hover',

				'edit_field_class' => 'vc_column vc_col-sm-4',

				'value' => array(

						__('Inherit', 'dpr-adeline-extensions') => '',

						__('Solid', 'dpr-adeline-extensions') => 'solid',

						__('Dotted', 'dpr-adeline-extensions') => 'dotted',

						__('Dashed', 'dpr-adeline-extensions') => 'dashed',

						__('Hidden', 'dpr-adeline-extensions') => 'hidden',

						__('Double', 'dpr-adeline-extensions') => 'double',

						__('Groove', 'dpr-adeline-extensions') => 'groove',

						__('Ridge', 'dpr-adeline-extensions') => 'ridge',

						__('Inset', 'dpr-adeline-extensions') => 'inset',

						__('Outset', 'dpr-adeline-extensions') => 'outset',

					   ),

				'group'	=> esc_html__('Design Options', 'dpr-adeline-extensions'),

			),




			array(

				'type' => 'dropdown',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set shadow for featured box.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Shadow', 'dpr-adeline-extensions'),

				'param_name' => 'box_shadow_hover',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'value' => array(

						__('None', 'dpr-adeline-extensions') => '',

						__('Shadow Depth 1', 'dpr-adeline-extensions') => '1',

						__('Shadow Depth 2', 'dpr-adeline-extensions') => '2',

						__('Shadow Depth 3', 'dpr-adeline-extensions') => '3',

						__('Shadow Depth 4', 'dpr-adeline-extensions') => '4',

						__('Shadow Depth 5', 'dpr-adeline-extensions') => '5',

						__('Shadow Depth 6', 'dpr-adeline-extensions') => '6',

						__('Custom Shadow', 'dpr-adeline-extensions') => 'custom',

					   ),

				'group'	=> esc_html__('Design Options', 'dpr-adeline-extensions'),

			),

			

			array(

				"type" => "dpr_shadow_picker",

				"class" => "",

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom shadow for featured box in hover state.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom Shadow', 'dpr-adeline-extensions'),

				"param_name" => "box_shadow_custom_hover",

				"value" => "none||||||",

				'dependency'		=> array('element' => 'box_shadow_hover', 'value' => array('custom')),

				'group'	=> esc_html__('Design Options', 'dpr-adeline-extensions'),

			)

		),

	)

);