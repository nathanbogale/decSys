<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

if(adeline_unsuported_frontend_markup("DP Carousel")) return false;

$unique_id = $css_animation = $el_class = $el_inner_class = $output = $custom_el_css = $slider_layout = $center_mode = $adaptive_height = $draggable = $touchable = '';
$slides_to_show = $slides_to_scroll = $speed = $items_offset = $items_offset_vertical = $autoplay = $autoplay_speed = $screen_desktop_resolution = $screen_desktop_slides = $screen_tablet_resolution = $screen_tablet_slides = $screen_mobile_resolution = $screen_mobile_slides = '';
$dots = $dots_style = $dots_color = $dots_color_inactive = $dots_spacing = $dots_top_margin = $pagination_alignment = '';
$arrows = $arrows_position = $arrow_icon = $arrow_icon_size = $arrow_icon_color = $arrow_icon_color_hover = $arrow_bg_border_radius = $arrow_bg_border_width = $arrow_bg_color = $arrow_bg_color_hover = $arrow_bg_border_color = $arrow_bg_border_color_hover = $arrow_use_shadow_on_hover = $arrow_hover_shadow = $arrow_allways_visible = $arrow_use_numbers = $arrow_numbers_color = ''; 
$slick_settings = $left_arrow_html = $right_arrow_html = $counter_html = '';

$atts = vc_map_get_attributes( 'dpr_carousel', $atts );
extract( $atts );

$el_class = $this->getExtraClass( $el_class );
if ( '' !== $css_animation && 'none' !== $css_animation ) {
	dpr_enqueue_waypoint_js();
	dpr_enqueue_animate_css();
	$el_class .= ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
}
$unique_id = uniqid('dpr-carousel-').'-'.rand(1,9999);

$css_classes = array(
	'dpr-carousel-wrap',
	$pagination_alignment,
	$el_class,
);

$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->settings['base'], $atts ) );

$slick_settings .= 'arrows: false,';
$slick_settings .= 'dotsClass: \'dpr-slick-dots\',';
$slick_settings .= 'slidesToScroll: '.$slides_to_scroll.',';
if(is_rtl() && $slider_layout != 'vertical') {
$slick_settings .= 'rtl: true,';
}
if(isset($slider_layout) && $slider_layout !='') {
	$el_inner_class .= ' dpr-carousel-'.$slider_layout;
}

if($slider_layout == 'vertical') {
	$slick_settings .= 'vertical: true,';
}

if ($dots == 'yes') {
	$el_inner_class .= ' dots-enabled';
	if(isset($dots_style) && $dots_style !='') {
		$el_inner_class .= ' dpr-dots-'.$dots_style;
	}
	$slick_settings .= 'dots: true,';
	$slick_settings .=	'customPaging: function(slider, i) {
						return \'<span data-role="none" role="button" aria-required="false" tabindex="0"></span>\';
					},';
} else {
	$slick_settings .= 'dots: false,';
}
if ($arrows == 'yes') {
	$el_inner_class .= ' arrows-enabled';
	
	if(isset($arrows_position) && $arrows_position !='') {
		$el_inner_class .= ' arrows-'.$arrows_position;
	}
	
	if($arrow_allways_visible == 'yes') {
		$el_inner_class .= ' arrows-allways';
	}

	if($arrow_use_numbers == 'yes') {
		$el_inner_class .= ' show-numbers';
	} else {
		$el_inner_class .= ' hide-numbers';
	}
	$arrow_style = dpr_getSlickArrowsStyle($atts);
	
	$custom_el_css .= "#".$unique_id." a.dpr-slider-controls:hover i{".$arrow_style["style-hover-icon"]."}";
	$custom_el_css .= "#".$unique_id." a.dpr-slider-controls:hover{".$arrow_style["style-hover-bg"]."}";
	$custom_el_css .= "#".$unique_id." a.dpr-slider-controls .counter{".$arrow_style["style-navigation"]."}";
	
	$style_icon = 'style="'.$arrow_style["style-icon"].'"';
	$style_bg = 'style="'.$arrow_style["style-bg"].'"';
	$left_arrow_html .= '<i class="'.$arrow_style["icon_left"].'" '.$style_icon.'></i>';
	$right_arrow_html .= '<i class="'.$arrow_style["icon_right"].'" '.$style_icon.'></i>';	
}

if($autoplay == 'yes') {
	$slick_settings .= 'autoplay: true,';
	if($autoplay != '') {
		$slick_settings .= 'autoplaySpeed: '.esc_js($autoplay_speed).',';
	}
}

if($center_mode == 'yes' && $slider_layout != 'vertical') {
	$slick_settings .= 'centerMode: true,';
}

if($slides_to_show != '') {
	$slick_settings .= 'slidesToShow: '.esc_js($slides_to_show).',';
}

if($speed != '') {
	$slick_settings .= 'speed: '.esc_js($speed).',';
}

if($draggable == 'yes') {
	$slick_settings .= 'swipe: true,';
	$slick_settings .= 'draggable: true,';
} else {
	$slick_settings .= 'swipe: false,';
	$slick_settings .= 'draggable: false,';

	if($touchable == 'yes') {
		$slick_settings .= 'touchMove: true,';
	}
}

if($adaptive_height == 'yes') {
	$slick_settings .= 'adaptiveHeight: true,';
}

if(isset($rtl) && $rtl == 'yes') {
	$slick_settings .= 'rtl: true,';
}

if($screen_desktop_resolution == '') {
	$screen_desktop_resolution == 1024;
}

if($screen_tablet_resolution == '') {
	$screen_tablet_resolution == 800;
}

if($screen_mobile_resolution == '') {
	$screen_mobile_resolution == 480;
}

if($screen_desktop_slides != '' || $screen_tablet_slides != '' || $screen_mobile_slides != '') {
	$slick_settings .= 'responsive: [';
	if($screen_desktop_slides != '') {
		$slick_settings .= '
				{
					breakpoint: '.esc_js($screen_desktop_resolution).',
					settings: {
						slidesToShow: '.esc_js($screen_desktop_slides).',
						slidesToScroll: 1,
					}
				},';
	}
	if($screen_tablet_slides != '') {
		$slick_settings .= '
				{
					breakpoint: '.esc_js($screen_tablet_resolution).',
					settings: {
						slidesToShow: '.esc_js($screen_tablet_slides).',
						slidesToScroll: 1,
					}
				},';
	}
	if($screen_mobile_slides != '') {
		$slick_settings .= '
				{
					breakpoint: '.esc_js($screen_mobile_resolution).',
					settings: {
						slidesToShow: '.esc_js($screen_mobile_slides).',
						slidesToScroll: 1,
					}
				},';
	}
	$slick_settings .= ']';
}

if($items_offset != '' && $slider_layout != 'vertical') {
	$custom_el_css .= '#'.esc_js($unique_id).' .slick-slide {padding: '.esc_js($items_offset/2).'px;}';
}

if($items_offset_vertical != '' && $slider_layout != 'horizontal') {
	$custom_el_css .= '#'.esc_js($unique_id).' .slick-slide {padding-top: '.esc_js($items_offset_vertical/2).'px;padding-bottom: '.esc_js($items_offset_vertical/2).'px;}';
}

if($dots_color_inactive != '') {
	$custom_el_css .=	'#'.esc_js($unique_id).' .dpr-dots-outline-square .slick-slider .dpr-slick-dots li, #'.esc_js($unique_id).' .dpr-dots-outline-round .slick-slider .dpr-slick-dots li, #'.esc_js($unique_id).' .dpr-dots-outline-bar .slick-slider .dpr-slick-dots li  {border-color: '.esc_js($dots_color_inactive).'}';
	$custom_el_css .=	'#'.esc_js($unique_id).' .dpr-dots-flat-round .slick-slider .dpr-slick-dots li, #'.esc_js($unique_id).' .dpr-dots-flat-rounded .slick-slider .dpr-slick-dots li, #'.esc_js($unique_id).' .dpr-dots-flat-square .slick-slider .dpr-slick-dots li  {background-color: '.esc_js($dots_color_inactive).'}';
}
if($dots_color != '') {
	$custom_el_css .=	'#'.esc_js($unique_id).' .dpr-dots-outline-square .slick-slider .dpr-slick-dots li:hover, #'.esc_js($unique_id).' .dpr-dots-outline-round .slick-slider .dpr-slick-dots li:hover, #'.esc_js($unique_id).' .dpr-dots-outline-bar .slick-slider .dpr-slick-dots li:hover {border-color: '.esc_js($dots_color).';background-color: '.esc_js($dots_color).'}';
	$custom_el_css .=	'#'.esc_js($unique_id).' .dpr-dots-flat-round .slick-slider .dpr-slick-dots li:hover, #'.esc_js($unique_id).' .dpr-dots-flat-rounded .slick-slider .dpr-slick-dots li:hover, #'.esc_js($unique_id).' .dpr-dots-flat-square .slick-slider .dpr-slick-dots li:hover  {background-color: '.esc_js($dots_color).'}';
	$custom_el_css .=	'#'.esc_js($unique_id).' .dpr-dots-outline-square .slick-slider .dpr-slick-dots li.slick-active, #'.esc_js($unique_id).' .dpr-dots-outline-round .slick-slider .dpr-slick-dots li.slick-active, #'.esc_js($unique_id).' .dpr-dots-outline-bar .slick-slider .dpr-slick-dots li.slick-active {border-color: '.esc_js($dots_color).';background-color: '.esc_js($dots_color).'}';
	$custom_el_css .=	'#'.esc_js($unique_id).' .dpr-dots-flat-round .slick-slider .dpr-slick-dots li.slick-active, #'.esc_js($unique_id).' .dpr-dots-flat-rounded .slick-slider .dpr-slick-dots li.slick-active, #'.esc_js($unique_id).' .dpr-dots-flat-square .slick-slider .dpr-slick-dots li.slick-active  {background-color: '.esc_js($dots_color).'}';
}

if($dots_spacing != '') {
	$dots_margin = intval($dots_spacing/2);
	$custom_el_css .=	'#'.esc_js($unique_id).' .dpr-carousel-wrap-inner .dpr-slick-dots li {margin-left: '.esc_js($dots_margin).'px;margin-right: '.esc_js($dots_margin).'px}';
}

if($dots_top_margin != '') {
	$custom_el_css .=	'#'.esc_js($unique_id).' .dpr-carousel-wrap-inner .dpr-slick-dots {margin-top: '.esc_js($dots_top_margin).'px;}';
}



$counter_html .= '<span class="counter"></span>';

$output .= '<div id="'.esc_attr($unique_id).'" class="'.esc_attr($css_class).'">';
	$output .= '<div class="dpr-carousel-wrap-inner '.$el_inner_class.'">';
		$output .= '<div class="dpr-carousel">';
			$output .= do_shortcode($content);
		$output .= '</div>';
		if($arrows == 'yes') {
			$output .=  '<a href="#" class="dpr-slider-controls prev" '.$style_bg.' title="'.esc_attr__('Previous slide','dpr-adeline-extensions').'">'.$counter_html.$left_arrow_html.'</a>';
			$output .=  '<a href="#" class="dpr-slider-controls next" '.$style_bg.' title="'.esc_attr__('Next slide','dpr-adeline-extensions').'">'.$counter_html.$right_arrow_html.'</a>';
		}
	$output .= '</div>';
$output .= '</div>';


if(!empty($custom_el_css)) {
		$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>");'
						. '})(jQuery);'
					. '</script>';
}

echo $output;
	?>
	<script>
		jQuery( document ).on( 'ready', function() {
			"use strict";
			var $carousel = jQuery('#<?php echo esc_js($unique_id); ?>').find('.dpr-carousel');		
			<?php if($arrows == 'yes') {
					if($arrow_use_numbers == 'yes') :  ?>
						var total_slides;
						$carousel.on('init reInit afterChange', function (event, slick, currentSlide) {
							var prev_slide_index, next_slide_index, current;
							var $prev_counter = $carousel.siblings('.dpr-slider-controls.prev').find('.counter');
							var $next_counter = $carousel.siblings('.dpr-slider-controls.next').find('.counter');
							total_slides = slick.slideCount;
							current = (currentSlide ? currentSlide : 0) + 1;
							prev_slide_index = (current - 1 < 1) ? total_slides : current - 1;
							next_slide_index = (current + 1 > total_slides) ? 1 : current + 1;
							$prev_counter.text(prev_slide_index + '/' + total_slides);
							$next_counter.text(next_slide_index + '/'+ total_slides);
						});
					<?php endif;
				} ?>
				$carousel.siblings('.dpr-slider-controls.prev').click(function(e) {
					e.preventDefault();
					$carousel.slick("slickPrev");
				});
				$carousel.siblings('.dpr-slider-controls.next').click(function(e) {
					e.preventDefault();
					$carousel.slick("slickNext");
				});
			$carousel.slick({<?php echo $slick_settings; ?>});
		} );
	</script>
<?php
