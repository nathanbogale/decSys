<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$output = '';

$atts = vc_map_get_attributes( 'dpr_split_slider', $atts );
extract( $atts );
wp_enqueue_script('jquery-easing', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/jquery.easings.min.js', array('jquery'), null, true);	
wp_enqueue_script('dpr-split-slider', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/dpr.split.slider.js', array('jquery'), null, true);	

$id = uniqid('dpr-split-slider');
$output .= '<div id="'.esc_attr($id).'" class="dpr-split-slider">';
	$output .= do_shortcode($content);
$output .= '</div>';

echo $output;