<?php



/**



 * Woocoommerce Options -> Cart & Checkout



 * 



 */







	Redux::setSection( $opt_name, array(



		'title' => esc_html__('Cart & Checkout', 'dpr-adeline-extensions'),



		'id' => 'woocommerce_cart_checkout',



		'subsection' => true,



		'fields' => array(



						array(



							'id'   => 'woocommerce_cart_page_info',



							'type' => 'info',



							'style' => 'dpr-title',



							'title' => wp_kses_post(__('<h3>Cart Page</h3>', 'dpr-adeline-extensions')),



						),



						array(



							'id'       => 'woo_distraction_free_cart',



							'type'     => 'switch',



							'default' => false,



							'title'    =>  esc_html__('Distraction Free Cart','dpr-adeline-extensions'),



							'hint' => array(



								'title'   => esc_attr__('Distraction Free Cart','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Enable distraction free cart.','dpr-adeline-extensions')



							)



						),



						array(



							'id'       => 'woocommerce_cross_sells_count',



							'type'     => 'slider', 



							'title'    => __('Cross-Sells Count', 'dpr-adeline-extensions'),



							'default'  => '2',



							'min'      => '1',



							'step'     => '1',



							'max'      => '10',



							'desc'    => __('<i><small>Enter 0 to hide cross-sells section.</small><i>', 'dpr-adeline-extensions'),



							'hint' => array(



								'title'   => esc_attr__('Cross-Sells Count','dpr-adeline-extensions'),



								'content' => esc_attr__('Set cros-sell products count.If you set 0 no products cross-sells section will be displayed.','dpr-adeline-extensions')



							)



						),



						array(



							'id'       => 'woocommerce_cross_sells_columns',



							'type'     => 'slider', 



							'title'    => __('Cross-Sells Columns', 'dpr-adeline-extensions'),



							'default'  => '2',



							'min'      => '1',



							'step'     => '1',



							'max'      => '6',



							'hint' => array(



								'title'   => esc_attr__('Cross-Sells Columns','dpr-adeline-extensions'),



								'content' => esc_attr__('Set cros-sell products columns count.','dpr-adeline-extensions')



							)



						),



						array(



							'id'   => 'woocommerce_checkout_info',



							'type' => 'info',



							'style' => 'dpr-title',



							'title' => wp_kses_post(__('<h3>Checkout Page</h3>', 'dpr-adeline-extensions')),



						),



						array(



							'id'       => 'woo_distraction_free_checkout',



							'type'     => 'switch',



							'default' => false,



							'title'    =>  esc_html__('Distraction Free Checkout','dpr-adeline-extensions'),



							'hint' => array(



								'title'   => esc_attr__('Distraction Free Checkout','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Enable distraction free checkout.','dpr-adeline-extensions')



							)



						),



						array(



							'id'       => 'woo_multi_step_checkout_timeline_style',



							'type'     => 'radio',



							'title'    => __('Timeline Style', 'dpr-adeline-extensions'),



							'options'  => array(



								'arrow'  => 'Arrow',



								'square' => 'Square'



							),



							'default' => 'arrow',



							'hint' => array(



								'title'   => esc_attr__('Timeline Style','dpr-adeline-extensions'),



								'content' => esc_attr__('Set style for timeline in multi-step checkout form. ','dpr-adeline-extensions')



							)



						),



















					)



	));