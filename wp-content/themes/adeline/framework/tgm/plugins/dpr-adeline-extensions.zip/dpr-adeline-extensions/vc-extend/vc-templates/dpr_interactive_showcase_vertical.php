<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$output = $id = $el_class = $custom_el_css = $custom_list = $links_alignment = $subtitle_pos = $links_count = $enable_autoplay = $autoplay_speed = $links_animation = $css = '';
$title_color = $title_font_size = $title_line_height  = $title_letter_spacing = $title_font_style = $title_google_font = $title_typo_style = $title_color_hover = $title_stroke_width = $title_stroke_color = $title_stroke_color_hover = '';
$subtitle_color = $subtitle_font_size = $subtitle_line_height  = $subtitle_letter_spacing = $subtitle_font_style = $subtitle_google_font = $subtitle_typo_style = $subtitle_color_hover = '';
$use_title_responsive_typo = $title_reaponsive_typography = $use_subtitle_responsive_typo = $subtitle_reaponsive_typography = '';
$display_description = $description_color = '';
$atts = vc_map_get_attributes($this->getShortcode(), $atts);
extract( $atts );

	if ($enable_autoplay == 'yes' && $autoplay_speed != '') {
		$data_autoplay = $autoplay_speed;
	} else {
		$data_autoplay = 0;
	}


	$id = uniqid('dpr-vertical-showcase-');
	$slicknav_id = uniqid('slick-nav-');
	$slickimg_id = uniqid('slick-img-');
	
	wp_enqueue_script('interactive-showcase', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/dpr.interactive.showcase-vertical.js', array('jquery'), null, false);	
	
	/* Element classes */

	if(isset($links_alignment) && !empty($links_alignment)) {
		$el_class .= ' links-'.$links_alignment;
	}

	$css_classes = array(
		'dpr-ishowcase-wrapper vertical-showcase',
		esc_attr($id),
		$el_class,
		vc_shortcode_custom_css_class( $css ),
	);

	$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->settings['base'], $atts ) );

	// Custom CSS stuff
	$title_text_typo_css = dpr_generate_typography_css($title_color, $title_font_size, $title_line_height, $title_letter_spacing, $title_font_style, $title_google_font);
	$subtitle_text_typo_css = dpr_generate_typography_css($subtitle_color, $subtitle_font_size, $subtitle_line_height, $subtitle_letter_spacing, $subtitle_font_style, $subtitle_google_font);
	if (isset($title_stroke_width) && $title_stroke_width !='' ) {
		$title_text_typo_css .= '-webkit-text-stroke-width: '.$title_stroke_width.'px;';
	}
	if (isset($title_stroke_color) && $title_stroke_color !='' ) {
		$title_text_typo_css .= '-webkit-text-stroke-color: '.$title_stroke_color.';';
	}
	if(isset($title_text_typo_css) && !empty($title_text_typo_css)) {
		$custom_el_css .= '.'.esc_js($id).'.dpr-ishowcase-wrapper .dpr-ishowcase-item-link h1 {'.esc_js($title_text_typo_css).'}';
	}
	if(isset($title_color_hover)){
		$custom_el_css .= '.'.esc_js($id).' .dpr-ishowcase-item-link:hover h1,.'.esc_js($id).'.dpr-ishowcase-wrapper .slick-current h1 {color:'.esc_js($title_color_hover).'}';
	}
	if(isset($title_stroke_color_hover) && $title_stroke_color_hover != ''){
		$custom_el_css .= '.'.esc_js($id).'.dpr-ishowcase-wrapper .slick-current h1 {-webkit-text-stroke-color:'.esc_js($title_stroke_color_hover).'}';
	}
	if(isset($subtitle_text_typo_css) && !empty($subtitle_text_typo_css)) {
		$custom_el_css .= '.'.esc_js($id).' .dpr-ishowcase-item-link:hover h5, .'.esc_js($id).'.dpr-ishowcase-wrapper .dpr-ishowcase-item-link h5 {'.esc_js($subtitle_text_typo_css).'}';
	}
	if(isset($subtitle_color_hover) && $subtitle_color_hover != ''){
		$custom_el_css .= '.'.esc_js($id).'.dpr-ishowcase-wrapper .dpr-ishowcase-item-link:hover h5, .'.esc_js($id).'.dpr-ishowcase-wrapper .slick-current h5 {color:'.esc_js($subtitle_color_hover).'}';
	}
	if(isset($description_color) && $description_color != ''){
		$custom_el_css .= '.'.esc_js($id).'.dpr-ishowcase-wrapper .dpr-ishowcase-item-description, .'.esc_js($id).'.dpr-ishowcase-wrapper .dpr-ishowcase-item-description h6 {color:'.esc_js($description_color).'}';
	}
	if(isset($description_shadow_color) && $description_shadow_color != ''){
		$custom_el_css .= '.'.esc_js($id).'.dpr-ishowcase-wrapper .dpr-ishowcase-item-description, .'.esc_js($id).'.dpr-ishowcase-wrapper .dpr-ishowcase-item-description h6 {text-shadow: 1px 1px 2px '.esc_js($description_shadow_color).';}';
	}
	if(isset($description_title_font_size) && $description_title_font_size != ''){
		$custom_el_css .= '.'.esc_js($id).'.dpr-ishowcase-wrapper .dpr-ishowcase-item-description h6 {font-size:'.esc_js($description_title_font_size).'px}';
	}
	if(isset($description_font_size) && $description_font_size != ''){
		$custom_el_css .= '.'.esc_js($id).'.dpr-ishowcase-wrapper .dpr-ishowcase-item-description {font-size:'.esc_js($description_font_size).'px}';
	}
	if(isset($image_scale) && $image_scale != ''){
		$custom_el_css .= '.'.esc_js($id).'.dpr-ishowcase-wrapper .dpr-ishowcase-item-image {transform: translate3d(0px, 0px, 0px) scale('.esc_js($image_scale).', '.esc_js($image_scale).');}';
	}

// Add responsive CSS

if($use_title_responsive_typo && isset($title_reaponsive_typography) && $title_reaponsive_typography != '') {
	$responsive_unique_class = '.'.esc_js($id).'.dpr-ishowcase-wrapper .dpr-ishowcase-item-link h1';
	$custom_el_css .= DPR_Resposive_Typography_Param::generate_css($title_reaponsive_typography,$responsive_unique_class);
}
if($use_subtitle_responsive_typo && isset($subtitle_reaponsive_typography) && $subtitle_reaponsive_typography != '') {
	$responsive_unique_class = '.'.esc_js($id).'.dpr-ishowcase-wrapper .dpr-ishowcase-item-link h1';
	$custom_el_css .= DPR_Resposive_Typography_Param::generate_css($subtitle_reaponsive_typography,$responsive_unique_class);
}
	

/* Generate Output */

	$output .= '<div id="'.esc_attr($id).'" class="'.esc_attr($css_class).'" data-links-count="'.esc_attr($links_count).'" data-autoplay="'.esc_attr($data_autoplay).'">';
	
			
			 $custom_list = (array) vc_param_group_parse_atts($custom_list);
			 if ( ! empty( $custom_list ) ) { 
				$output .= '<div id ="'.esc_attr($slickimg_id).'" class="dpr-ishowcase-image-wrapper">';
					foreach ( $custom_list as $link_item ): 
				 			if($link_item['bg_type'] == 'image' ) {
								if ( isset( $link_item['image_id'] ) ) { 
									$image_url = wp_get_attachment_url( $link_item['image_id'] );
									$item_style   = 'style="background-image: url(' . $image_url . ');"';
									$output .= '<div class="dpr-ishowcase-item-image" '.$item_style.'></div>';

								} 
							} else {
								$video_atts = $poster_url = '';
								$uniqid = uniqid('dpr-bg-wrapper');
								if(isset( $link_item['video_type']) && !empty($link_item['video_type'])) {
									$output .= '<div class="dpr-ishowcase-item-image">';
									$output .= '<div class="dpr_row_bg_container" style="position:relative">';
									if(isset($link_item['video_poster']) && !empty($link_item['video_poster'])) {
										$poster_src = dpr_get_attachment_image_src($link_item['video_poster'],'full');
										$poster_url = $poster_src[0];
									} 
									// Hosted Video
									if($link_item['video_type'] == 'hosted' && (isset($link_item['mp4_url']) || isset($link_item['webm_url']))) {

										$video_atts .= 'poster="'. $poster_url .'"';
										if(isset($link_item['video_options']) && !empty($link_item['video_options'])) {
											if(substr_count($link_item['video_options'], 'loop') == 1) {
												$video_atts .= ' loop="true" ';
											}
											if(substr_count($link_item['video_options'], 'muted') == 1) {
												$video_atts .= ' muted="true" ';
											}
										}
										$output .= '<div class="dpr_row_bg_container_inner dpr-video-bg" id="wrapper-'.esc_attr($uniqid).'">';
										$output .= '<video id="'.esc_attr($uniqid).'" class="video-js vjs-default-skin" 
											   preload="auto"
											   width="100%"
											   height="100%"
											   autoplay="autoplay"
											   '.$video_atts.'
											   data-setup="{}" data-keepplaying>';

											if (!empty($link_item['mp4_url'])):
												$output .= '<source src="'.esc_url($link_item['mp4_url']).'" type="video/mp4">';
											endif;
											if (!empty($link_item['webm_url'])):
												$output .= '<source src="'.esc_url($link_item['webm_url']).'" type="video/webm">';
											endif;
										$output .= '</video>';

										$output .= '</div>';
									} elseif($link_item['video_type'] == 'youtube' || $link_item['video_type'] == 'vimeo') {
									// Youtube and Vimeo videos	
										$loop = false;
										if(isset($link_item['video_options']) && !empty($link_item['video_options'])) {
											if(substr_count($link_item['video_options'], 'loop') == 1) {
												$loop = true;
											}
											if(substr_count($link_item['video_options'], 'muted') == 1) {
												$muted = true;
											}
										} 
									// Youtube video	
										if($link_item['video_type'] == 'youtube' && isset($link_item['youtube_id']) && !empty($link_item['youtube_id'])) {
											$extra_url_part = '';
											if(substr_count($link_item['youtube_id'], '?') > 0) {
												$link_item['youtube_id'] = substr($link_item['youtube_id'],(stripos($link_item['youtube_id'],'?v=')+3));
											}
											if(substr_count($link_item['youtube_id'], '&') > 0) {
												$link_item['youtube_id'] = substr($link_item['youtube_id'], 0, stripos($link_item['youtube_id'],'&'));
											}
											if ($loop) {
												$extra_url_part .= '&amp;loop=1&amp;playlist='.$link_item['youtube_id'];
											}
											if ($muted) {
												$extra_url_part .= '&amp;mute=1';
											}
											if (!empty($link_item['video_start_time'])){
												$extra_url_part .= '&amp;start='.$link_item['video_start_time'];
											}
											if (!empty($link_item['video_stop_time'])) {
												$extra_url_part .= '&amp;end='.$link_item['video_stop_time'];
											}
											$output .= '<div id="wrapper-'.esc_attr($uniqid).'" class="dpr_row_bg_container_inner dpr-video-bg">
															<div class="video-iframe-wrapper"><iframe id="'.esc_attr($uniqid).'" width="100%" height="100%" src="https://www.youtube.com/embed/'.esc_attr($link_item['youtube_id']).'?wmode=opaque'.esc_attr($extra_url_part).'&amp;autoplay=1&amp;enablejsapi=1&amp;showinfo=0&amp;controls=0&amp;rel=0" frameborder="0" class="dpr-bg-frame" allowfullscreen></iframe></div>
														</div>';
										}
									// Vimeo video
										if($link_item['video_type'] == 'vimeo' && isset($link_item['vimeo_id']) && !empty($link_item['vimeo_id'])) {
											add_action( 'wp_enqueue_scripts', 'dpr_enqueue_vimeo_api_js' );
											if(substr_count($link_item['vimeo_id'], 'vimeo.com/') > 0) {
												$link_item['vimeo_id'] = substr($link_item['vimeo_id'],(stripos($link_item['vimeo_id'], 'vimeo.com/')+10));
											}
											if(substr_count($link_item['vimeo_id'], '&') > 0) {
												$link_item['vimeo_id'] = substr($link_item['vimeo_id'], 0, stripos($link_item['vimeo_id'],'&'));
											}

											$output .= '<div id="wrapper-'.esc_attr($uniqid).'" class="dpr_row_bg_container_inner dpr-video-bg">
															<div class="video-iframe-wrapper"><iframe id="'.esc_attr($uniqid).'" src="https://player.vimeo.com/video/'.esc_attr($link_item['vimeo_id']).'?background=1&amp;api=1&amp;portrait=0&amp;rel=0" width="100%" height="100%" frameborder="0" class="dpr-bg-frame"></iframe></div>
														</div>';
										}

									}
									
									if($poster_url != '') {
										$custom_el_css .= '#wrapper-'.esc_js($uniqid).' {background-image: url(\"'.esc_js($poster_url).'\");}';
									}
									if (isset($link_item['overlay_color'])) {
									$output .= '<div class ="video-overlay" style="background-color:'.$link_item['overlay_color'].';position: absolute;top: 0;left: 0;display: block;width: 100%;height: 100%;"></div>';	
									}
									$output .= '</div>';
									
									$output .= '</div>';
									
									
								}								
							}
					endforeach;
				$output .= '</div>';
				 
				if($display_description == 'yes') {
				$output .= '<div class="dpr-ishowcase-description-wrapper">';
					$output .= '<div class="dpr-ishowcase-description-inner"><div class="dpr-ishowcase-description-inner-wrapper">';
				 				$k = 1;
							$visibility_class = '';
				 				foreach ( $custom_list as $content_item ):
				 				if ( isset( $content_item['link_title']) ) {
									if (!isset( $content_item['description']) )  $visibility_class = 'unvisible';
				 				$output .= '<div class="dpr-ishowcase-item-description '.$visibility_class.'">';
								$output .= '<h6><span class="number">'.str_pad($k, 2, '0', STR_PAD_LEFT).'</span> '.$content_item['link_title'] .'</h6>';
								if (isset( $content_item['description']) ) {$output .= wp_kses_post($content_item['description']);}
									
								$output .= '</div>';								
								$k++;
								}
								endforeach;
				 	$output .= '</div></div>';
				 $output .= '</div>';
				}
				 
				$output .= '<div class="dpr-ishowcase-content-wrapper">';
					$output .= '<div class="dpr-ishowcase-content-inner">';
						$output .= '<div id="'.esc_attr($slicknav_id).'" class="dpr-ishowcase-item-content">';

								$i = 0;

								foreach ( $custom_list as $link_item ):
								  if ( isset( $link_item['link_title'] ) ) {
									$link_url = $link_target = $link_rel = '';
									if(isset($link_item['link'])) {
										$link = vc_build_link($link_item['link']);
										$link_target = !empty($link['target']) ? 'target="'.esc_attr(preg_replace('/\s+/', '', $link['target'])).'"' : '';
										$link_url = $link['url'];
										$link_rel = $link['rel'];
									}
									$output .= '<div class="dpr-ishowcase-item-link-wrapper">';
										$output .= '<a itemprop="url" class="dpr-ishowcase-item-link" data-index="'. esc_attr($i).'" href="'.$link_url.'" '.$link_target.' rel="'.$link_rel.'">';
									  	if ($subtitle_pos == 'above' && isset($link_item['link_subtitle'])) {
										$output .= '<h5 class="dpr-ishowcase-item-subtitle">'. esc_html( $link_item['link_subtitle'] ) .'</h5>';
										}
									  	$output .= '<h1 class="dpr-ishowcase-item-title">'. esc_html( $link_item['link_title'] ) .'</h1>';
									  	if ($subtitle_pos == 'bellow' && isset($link_item['link_subtitle'])) {									  
									  	$output .= '<h5 class="dpr-ishowcase-item-subtitle">'. esc_html( $link_item['link_subtitle'] ) .'</h5>';
										}
										$output .= '</a>';
									 $output .= '</div>';

								$i++;
								} 
							 endforeach;
						$output .= '</div>';
					$output .= '</div>';
				$output .= '</div>';
			 } 


		if($custom_el_css != '') {
			$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>")'
						. '})(jQuery);'
					. '</script>';
		}




	$output .= '</div>';

echo $output;