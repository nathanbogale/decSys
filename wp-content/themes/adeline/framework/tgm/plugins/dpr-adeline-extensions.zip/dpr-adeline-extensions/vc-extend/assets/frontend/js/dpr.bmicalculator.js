var $j = jQuery.noConflict();

$j( document ).on( 'ready', function() {
	"use strict";
	// Custom select
	dprInitializeBMI();
} );

/* ==============================================
BEFORE AFTER
============================================== */
function dprInitializeBMI() {
	"use strict"
    $j(function(){
		
		$j("a.close").removeAttr("href").click(function(){
		$j(this).parent().fadeOut(200);
		});

    // Show or hide inputs based on radio fields
    $j('.dpr-bmi-calculator').each(function() {
        dprBMIRadioChange($j(this));       
    });
	
    $j('.dpr-bmi-calculator .dpr-bmi-radio').on('change', 'input[name=dpr-bmi-unit]', function() {
        var $parent = $j(this).closest('.dpr-bmi-calculator');
        dprBMIRadioChange($parent);
    });
    $j('.dpr-bmi-calculator').on('click', '.dpr-bmi-submit', function(event) {
        event.preventDefault();
        var $parent = $j(this).closest('.dpr-bmi-calculator'),
        bmi = dprBMICalculate($parent),
        chart = $parent.find('.dpr-bmi-result').data('chart'),
        status = false,
        errorMsg;

        if ( bmi == 'emptyError' ) {
            errorMsg = $parent.find('.dpr-bmi-error').data('emptymsg');
        }
        else if( bmi == 'numberError' ){
            errorMsg = $parent.find('.dpr-bmi-error').data('numbermsg');
        }
        else if( bmi<18.5 ){
            status = 1;
        }
        else if( 18.5<=bmi && bmi<=24.99 ){
            status = 2;
        }
        else if( 25<=bmi && bmi<=29.99 ){
            status = 3;
        }
        else if( bmi>=30 && bmi<=34.99 ){
            status = 4;
        }
        else if( bmi>=35 ){
            status = 5;
        }

        if (status) {
            $parent.find('.dpr-bmi-val').text(bmi);
            $parent.find('.dpr-bmi-status').text(chart[status-1][1]);
			$parent.find('.dpr-bmi-icon').html( "<span class='"+chart[status-1][2]+"'></span>" );
            $parent.find('.dpr-bmi-error').hide();
            $parent.find('.dpr-bmi-result').show();
        }
        else {
            $parent.find('.dpr-bmi-result').hide();
            $parent.find('.dpr-bmi-error p').text(errorMsg).show();
            $parent.find('.dpr-bmi-error').show();
        }
    });



    });
}

function dprBMICalculate($parent){
    var unit = $parent.find('input[name=dpr-bmi-unit]:checked').val();
    if ( unit == 'metric' ) {
        var weight = $parent.find('input[name=dpr-bmi-weight]').val();
        var height = $parent.find('input[name=dpr-bmi-height]').val();
        if ( weight == '' || height == '' ) {
            return 'emptyError';
        }
        if ( !jQuery.isNumeric(weight) || !jQuery.isNumeric(height) ) {
            return 'numberError';
        }
        height = height/100;
        var bmi = weight/(height*height);
    }
    else {
        var weight = $parent.find('input[name=dpr-bmi-pound]').val();
        var feet   = $parent.find('input[name=dpr-bmi-feet]').val();
        var inch   = $parent.find('input[name=dpr-bmi-inch]').val();
        if ( weight == '' || feet == '' || inch == '' ) {
            return 'emptyError';
        }
        if ( !jQuery.isNumeric(weight) || !jQuery.isNumeric(feet) || !jQuery.isNumeric(inch) ) {
            return 'numberError';
        }
        height = (feet*12)+parseFloat(inch);
        var bmi = (weight/(height*height)*703);
    }
    return Math.round(bmi*100)/100;
}

function dprBMIRadioChange($parent){
    var unit = $parent.find('input[name=dpr-bmi-unit]:checked').val();
    if ( unit == 'metric' ) {
        $parent.find('.dpr-bmi-fields .dpr-bmi-fields-imperial').hide();
        $parent.find('.dpr-bmi-fields .dpr-bmi-fields-metric').show();
    }
    else {
        $parent.find('.dpr-bmi-fields .dpr-bmi-fields-metric').hide();
        $parent.find('.dpr-bmi-fields .dpr-bmi-fields-imperial').show();
    }
}
