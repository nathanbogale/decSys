<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Shortcode attributes
 * @var $atts
 * @var $content - shortcode content
 * @var $this WPBakeryShortCode_VC_Tta_Section
 */
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
$this->resetVariables( $atts, $content );
WPBakeryShortCode_VC_Tta_Section::$self_count ++;
WPBakeryShortCode_VC_Tta_Section::$section_info[] = $atts;
$isPageEditable = vc_is_page_editable();

//DPR custom stuff

$dprHeading = '';
$h4attributes = array();
$h4classes = array(
	'vc_tta-panel-title',
);
if ( $isPageEditable ) {
	$h4attributes[] = 'data-vc-tta-controls-icon-position=""';
} else {
	$controlIconPosition = $this->getTemplateVariable( 'control-icon-position' );
	if ( $controlIconPosition ) {
		$h4classes[] = $controlIconPosition;
	}
}

$h4attributes[] = 'class="' . implode( ' ', $h4classes ) . '"';

$dprHeading .= '<h4 ' . implode( ' ', $h4attributes ) . '>';

if ( $isPageEditable ) {
	$dprHeading .= '<a href="javascript:;" data-vc-target=""';
	$dprHeading .= ' data-vc-tta-controls-icon-wrapper';
	$dprHeading .= ' data-vc-use-cache="false"';
} else {
	$dprHeading .= '<a href="#' . esc_attr( $this->getTemplateVariable( 'tab_id' ) ) . '"';
}

$dprHeading .= ' data-vc-accordion';

$dprHeading .= ' data-vc-container=".vc_tta-container">';
if ( 'left' === $atts['i_position'] ) {
		if ( $atts['icon'] != '') {
		$dprHeading .= '<i class="vc_tta-icon ' .$atts['icon']. '"></i>';
		}
}
$dprHeading .= '<span class="vc_tta-title-text">';
$dprHeading .= $this->getTemplateVariable( 'title' );
$dprHeading .= '</span>';
if ( 'right' === $atts['i_position'] ) {
		if ( $atts['icon'] != '') {
		$dprHeading .= '<i class="vc_tta-icon ' .$atts['icon']. '"></i>';
		}
}
$dprHeading .= $this->getTemplateVariable( 'icon-right' );
if ( ! $isPageEditable ) {
	$dprHeading .= $this->getTemplateVariable( 'control-icon' );
}

$dprHeading .= '</a>';
$dprHeading .= '</h4>'; 

// DPR custom stuff end


$output = '';

$output .= '<div class="' . esc_attr( $this->getElementClasses() ) . '"';
$output .= ' id="' . esc_attr( $this->getTemplateVariable( 'tab_id' ) ) . '"';
$output .= ' data-vc-content=".vc_tta-panel-body">';
$output .= '<div class="vc_tta-panel-heading">';
$output .= $dprHeading;
$output .= '</div>';
$output .= '<div class="vc_tta-panel-body">';
if ( $isPageEditable ) {
	$output .= '<div data-js-panel-body>'; // fix for fe - shortcodes container, not required in b.e.
}

$output .= $this->getTemplateVariable( 'content' );
if ( $isPageEditable ) {
	$output .= '</div>';
}
$output .= '</div>';
$output .= '</div>';

echo $output;
