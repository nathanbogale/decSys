<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$unique_id = $css_animation = $el_class = $css = $output = $custom_el_css = $style = $alignment = $social_networks = '';
$icon_size =  $icon_padding = $icon_color = $icon_color_hover = $icon_bg_color = $icon_bg_color_hover = $icon_border_color = '';


$atts = vc_map_get_attributes( 'dpr_social_icons', $atts );
extract( $atts );

$el_class = $this->getExtraClass( $el_class );
if ( '' !== $css_animation && 'none' !== $css_animation ) {
	dpr_enqueue_waypoint_js();
	dpr_enqueue_animate_css();
	$el_class .= ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
}
$unique_id = uniqid('dpr-social-icons-').'-'.rand(1,9999);


$css_classes = array(
	'dpr-social-icons',
	$unique_id,
	$el_class,
	vc_shortcode_custom_css_class( $css ),
);

$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->settings['base'], $atts ) );

if(isset($icon_size) && $icon_size !='') {
	$custom_el_css .= '.'.esc_js($unique_id).' .dpr-adeline-social-block ul li a  {font-size:'.$icon_size.'px;}';
}
if(isset($icon_color) && $icon_color !='') {
	$custom_el_css .= '.'.esc_js($unique_id).' .dpr-adeline-social-block ul li a:not(:hover)  {color:'.$icon_color.';}';
}
if(isset($icon_color_hover) && $icon_color_hover !='') {
	$custom_el_css .= '.'.esc_js($unique_id).' .dpr-adeline-social-block ul li a:hover  {color:'.$icon_color_hover.';}';
}
if(isset($icon_bg_color) && $icon_bg_color !='') {
	$custom_el_css .= '.'.esc_js($unique_id).' .dpr-adeline-social-block ul li a:not(:hover)  {background-color:'.$icon_bg_color.';}';
}
if(isset($icon_bg_color_hover) && $icon_bg_color_hover !='') {
	$custom_el_css .= '.'.esc_js($unique_id).' .dpr-adeline-social-block ul li a:hover  {background-color:'.$icon_bg_color_hover.';}';
}
if(isset($icon_border_color) && $icon_border_color !='') {
	$custom_el_css .= '.'.esc_js($unique_id).' .dpr-adeline-social-block ul li a:not(:hover)  {border-color:'.$icon_border_color.';}';
}
if(isset($icon_border_color_hover) && $icon_border_color_hover !='') {
	$custom_el_css .= '.'.esc_js($unique_id).' .dpr-adeline-social-block ul li a:hover  {border-color:'.$icon_border_color_hover.';}';
}

if(isset($icon_border_radius) && $icon_border_radius !='') {
	$custom_el_css .= '.'.esc_js($unique_id).' .dpr-adeline-social-block ul li a:not(:hover)  {border-radius:'.$icon_border_radius.'px;}';
}
if(isset($icon_border_radius_hover) && $icon_border_radius_hover !='') {
	$custom_el_css .= '.'.esc_js($unique_id).' .dpr-adeline-social-block ul li a:hover  {border-radius:'.$icon_border_radius_hover.'px;}';
}
if(isset($icon_border_width) && $icon_border_width !='') {
	$custom_el_css .= '.'.esc_js($unique_id).' .dpr-adeline-social-block ul li a  {border-width:'.$icon_border_width.'px;}';
}




if(isset($icon_padding) && $icon_padding !='') {
	$custom_el_css .= '.'.esc_js($unique_id).' .dpr-adeline-social-block ul li a  {margin-right:'.$icon_padding.'px;margin-left:'.$icon_padding.'px;}';
}

$output .= '<div id="'.esc_attr($unique_id).'" class="'.esc_attr($css_class).'">';
$output .='<div class="dpr-adeline-social-block clr">';
if(isset($social_networks) && !empty($social_networks) && function_exists('vc_param_group_parse_atts')) {
$output .= '<div class="social-menu-inner clr '.$style.' '.$alignment.'"><ul>';	
$social_networks = (array) vc_param_group_parse_atts($social_networks);
	foreach($social_networks as $item) {
			$link_attr = 'href="#"';
			if(isset($item['link']) ) {
				$link = $item['link'];
				$link = vc_build_link($link);
					$link_target = !empty($link['target']) ? 'target="'.esc_attr(preg_replace('/\s+/', '', $link['target'])).'"' : '';
					if($link['url'] != '' ) {
						$link_attr = 'href="'.esc_url($link['url']).'" title="'.esc_attr($link['title']).'" '.$link_target.' rel="'.esc_attr($link['rel']).'"';
					}
			}
			if(isset($item['network'])) {
			$output .= '<li class="dpr-adeline-'.esc_attr($item['network']).'"><a '.$link_attr.'><span class="dpr-icon-'.esc_attr($item['network']).'"></span></a></li>';	
			}
	}
$output .= '</ul></div>';	
}
$output .= '</div>'; 

if(!empty($custom_el_css)) {
		$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>");'
						. '})(jQuery);'
					. '</script>';
}
$output .= '</div>';


echo $output;