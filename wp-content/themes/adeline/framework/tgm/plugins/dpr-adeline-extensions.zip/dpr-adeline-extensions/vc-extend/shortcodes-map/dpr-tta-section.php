<?php

// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}



//VC TTA Section VC Map modifications



if(function_exists('vc_remove_param')) {

	

	vc_remove_param('vc_tta_section','tab_id');

	vc_remove_param('vc_tta_section','el_class');

	vc_remove_param('vc_tta_section','title');

	vc_remove_param('vc_tta_section','add_icon');

	vc_remove_param('vc_tta_section','i_position');

	

}



	vc_add_param(

		'vc_tta_section',array(

			'type' => 'textfield',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enter section title (Note: you can leave it empty).', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Title', 'dpr-adeline-extensions'),

			'param_name' => 'title',

			'weight' => 1

		)

	);	

	vc_add_param(

		'vc_tta_section', array(

			'type' => 'dpr_switcher',

			'class' => '',

			'weight' => 1,

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Add icon to section title.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Add Icon', 'dpr-adeline-extensions'),

			'param_name' => 'add_icon',

			'edit_field_class' => 'vc_column vc_col-sm-6',

			'value' => '',

			'options' => array(

				'yes' => array(

						'label' => '',

						'on' => 'Yes',

						'off' => 'No',

					),

				),

		)

	);

	vc_add_param(

		'vc_tta_section', array(

			'type' => 'dpr_radio',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select icon position.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon Position', 'dpr-adeline-extensions'),

			'param_name' => 'i_position',

			'weight' => 1,

			'value' => 'left',

			'edit_field_class' => 'vc_column vc_col-sm-6',

			'options' => array(

				__('Before Title', 'dpr-adeline-extensions') => 'left',

				__('After Title', 'dpr-adeline-extensions') => 'right',

			),

			'dependency' => array(

				'element' => 'add_icon',

				'not_empty' => true,

			),

		)

	);

	vc_add_param(

		'vc_tta_section', array(

			"type" => "dpr_icon_selector",

			"heading" => esc_attr__("Icon", 'dpr-adeline-extensions'),

			"param_name" => "icon",

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select icon.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icon', 'dpr-adeline-extensions'),

			'weight' => 1,

			'dependency' => array(

				'element' => 'add_icon',

				'not_empty' => true,

			),

		)

	);

	vc_add_param(

		'vc_tta_section', array(

			'type' => 'dpr_title',

			'text' => esc_html__('Additional settings', 'dpr-adeline-extensions'),

			'param_name' => 'tta_section_title_1',

			'class' => '',

			'weight' => 1

		)

	);

	vc_add_param(

		'vc_tta_section',array(

			'type' => 'textfield',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Extra Class Name', 'dpr-adeline-extensions'),

			'param_name' => 'el_class',

			'weight' => 1

		)

	);	

	vc_add_param(

		'vc_tta_section',array(

			'type' => 'el_id',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enter section ID (Note: make sure it is unique and valid according to w3c specification.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Section ID', 'dpr-adeline-extensions'),

			'param_name' => 'tab_id',

			'settings' => array(

				'auto_generate' => true,

			),

			'weight' => 1

		)

	);

