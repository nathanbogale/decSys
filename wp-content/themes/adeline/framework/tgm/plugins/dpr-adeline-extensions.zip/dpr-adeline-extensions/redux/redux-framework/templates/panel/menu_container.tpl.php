<?php



/**



 * The template for the menu container of the panel.



 *



 * Override this template by specifying the path where it is stored (templates_path) in your Redux config.



 *



 * @author 	Redux Framework



 * @package 	ReduxFramework/Templates



 * @version:    3.5.4



 */



global $dpr_adeline;



?>



<div class="redux-sidebar">



<div class="dpr-branding-header">







<?php if (isset($dpr_adeline['branding_panel_logo']['url']) && $dpr_adeline['branding_panel_logo']['url'] != '')  { ?>



	<img src="<?php echo $dpr_adeline['branding_panel_logo']['url'] ; ?>"  /> 



 <?php   } 



		



 ?>



            <h2>

			

			<?php if ($dpr_adeline['branding_panel_name'] != '') {

			

			echo $dpr_adeline['branding_panel_name'];

			

			} else {

			

			echo wp_kses_post( $this->parent->args['display_name'] ); 

			

			}

			?>







            <?php 

			

			if ($dpr_adeline['branding_panel_version'] != '') { ?>

				

				<br/><span><i> <?php echo $dpr_adeline['branding_panel_version']  ?></i></span>

				

			<?php } else {

			

			if ( ! empty( $this->parent->args['display_version'] ) ) { ?>



                <br/><span><i><?php echo  __( 'v. ', 'dpr-adeline-extensions' ).wp_kses_post( $this->parent->args['display_version'] ); ?></i></span>



            <?php } 

			}

			?>



            </h2>



</div>



  <ul class="redux-group-menu">



<?php



        foreach ( $this->parent->sections as $k => $section ) {



            $title = isset ( $section[ 'title' ] ) ? $section[ 'title' ] : '';







            $skip_sec = false;



            foreach ( $this->parent->hidden_perm_sections as $num => $section_title ) {



                if ( $section_title == $title ) {



                    $skip_sec = true;



                }



            }







            if ( isset ( $section[ 'customizer_only' ] ) && $section[ 'customizer_only' ] == true ) {



                continue;



            }







            if ( false == $skip_sec ) {



                echo $this->parent->section_menu ( $k, $section );



                $skip_sec = false;



            }



        }







        /**



         * action 'redux-page-after-sections-menu-{opt_name}'



         *



         * @param object $this ReduxFramework



         */



        do_action ( "redux-page-after-sections-menu-{$this->parent->args[ 'opt_name' ]}", $this );







        /**



         * action 'redux/page/{opt_name}/menu/after'



         *



         * @param object $this ReduxFramework



         */



        do_action ( "redux/page/{$this->parent->args[ 'opt_name' ]}/menu/after", $this );



?>



    </ul>



</div>