<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$unique_id = $el_class = $custom_el_css =  $type = $css = "";
$node_style = $node_size = $node_inner_size = $node_bg_color = $node_border_color = $node_inner_color = $node_border_width = $node_border_radius = '';
$title = $title_color = $title_font_size = $title_line_height = $title_letter_spacing = $title_font_style = $title_use_google_fonts = $title_google_font = '';
$subtitle = $subtitle_color = $subtitle_font_size = $subtitle_line_height = $subtitle_letter_spacing = $subtitle_font_style = $subtitle_use_google_fonts = $subtitle_google_font = '';
$content = $image_id = $image_block_anim = $content_block_anim = $content_typo_style = $content_color = $content_font_size = $content_line_height = $content_letter_spacing = $content_font_style = $content_google_font= $content_html = '';
$read_more = $link = '';
$node_html = $content_html = $image_html = $output = $img_anim_class = $content_anim_class ='';

$atts = vc_map_get_attributes( 'dpr_workflow_item', $atts );
extract( $atts );

$unique_id = uniqid('dpr-workflow-item-').'-'.rand(1,9999);

/* Element classes */

if ( '' !== $image_block_anim && 'none' !== $image_block_anim ) {
	dpr_enqueue_waypoint_js();
	dpr_enqueue_animate_css();
	$img_anim_class .= ' wpb_animate_when_almost_visible wpb_' . $image_block_anim . ' ' . $image_block_anim;
}
if ( '' !== $content_block_anim && 'none' !== $content_block_anim ) {
	dpr_enqueue_waypoint_js();
	dpr_enqueue_animate_css();
	$content_anim_class .= ' wpb_animate_when_almost_visible wpb_' . $content_block_anim . ' ' . $content_block_anim;
}

if(isset($type) & $type !='') {
	$el_class .= ' '.$type;
}

$css_classes = array(
	'dpr-workflow-item',
	esc_attr($unique_id),
	$el_class,
	vc_shortcode_custom_css_class( $css ),
);

$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->settings['base'], $atts ) );

/* * ************************
 * Styles and custom CSS
 * *********************** */
if(isset($node_size) && !empty( $node_size)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .workflow-node {width: '.esc_attr( $node_size).'px;height: '.esc_attr( $node_size).'px;}';
}
if(isset($node_bg_color) && !empty($node_bg_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .workflow-node .node-inner{background-color: '.esc_attr($node_bg_color).' !important;}';
}
if(isset($node_border_color) && !empty($node_border_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .workflow-node .node-inner {border-color: '.esc_attr($node_border_color).' !important;}';
}
if(isset($node_border_width) && !empty($node_border_width)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .workflow-node .node-inner {border-width: '.esc_attr($node_border_width).'px;}';
}
if(isset($node_border_radius) && !empty($node_border_radius)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .workflow-node .node-inner{border-radius: '.esc_attr($node_border_radius).'px;}';
}
if(isset($node_style) && $node_style == 'style-2') {
	if(isset($node_inner_size) && !empty($node_inner_size)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .workflow-node .node-dot{width: '.esc_attr($node_inner_size).'px;height: '.esc_attr($node_inner_size).'px;}';
	}
	if(isset($node_inner_color) && !empty($node_inner_color)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .workflow-node .node-dot{background-color: '.esc_attr($node_inner_color).' !important;}';
	}
}

/* * ************************
 * Partial HTML.
 * *********************** */
$title_wrap_html = $subtitle_html = $title_html = $read_more_html = '';
if(!empty($subtitle)) {
	$title_typo_style = dpr_generate_typography_style($title_color, $title_font_size, $title_line_height, $title_letter_spacing, $title_font_style,$title_google_font);
	$title_html .= '<h3 class="title" '.$title_typo_style.' >'.esc_html($title).'</h3>';
}
if(!empty($subtitle)) {
	$subtitle_typo_style = dpr_generate_typography_style($subtitle_color, $subtitle_font_size, $subtitle_line_height, $subtitle_letter_spacing, $subtitle_font_style, $subtitle_google_font);
	$subtitle_html .= '<div class="subtitle" '.$subtitle_typo_style.' >'.esc_html($subtitle).'</div>';
}
if(isset($title) &&!empty($title) || isset($subtitle) && !empty($subtitle)) {
	$title_wrap_html .= '<div class="title-wrap">';
		$title_wrap_html .= $title_html;
		$title_wrap_html .= $subtitle_html;
	$title_wrap_html .= '</div>';
}


$read_more_data = dpr_generate_read_more($atts);
$read_more_html .= $read_more_data[0];
$custom_el_css .= $read_more_data[1];

$content_html .= '<div class="item-content'.$content_anim_class.'">';
	$content_html .= $title_wrap_html;
	$content_typo_style = dpr_generate_typography_style($content_color, $content_font_size, $content_line_height, $content_letter_spacing, $content_font_style,$content_google_font);
	$content_html .= '<div class="description" '.$content_typo_style.'>'.strip_tags($main_content,'<br><br/>').'</div>';
	$content_html .= $read_more_html;
$content_html .= '</div>';


$image_html .= '<div class="item-image'.$img_anim_class.'">';
	if(isset($image_id) && $image_id != '') {
	$image_url = dpr_get_attachment_image_src( $image_id, 'full' );
	$image_src = $image_url[0];
	$alt_text = get_post_meta($image_id , '_wp_attachment_image_alt', true);
	$image_html .= '<img src="' . esc_url($image_src) . '" alt ="'.esc_attr($alt_text).'"/>';
	}
	
$image_html .= '</div>';



$node_html .= '<div class="workflow-node '.esc_attr($node_style).'">';
	$node_html .= '<div class="node-inner">';
		$node_html .= '<div class="node-dot"></div>';
	$node_html .= '</div>';
$node_html .= '</div>';



/* * ************************
 * Output
 * *********************** */
$output .= '<div id="'.esc_attr($unique_id).'" class="'.esc_attr($css_class).' clr">';
	$output .= '<div class="inner">';
	$output .= $node_html;
	switch($type) {
		case 'right';
		$output .= $content_html;
		$output .= $image_html;
		break;
		case 'left';
		$output .= $image_html;
		$output .= $content_html;
		break;
	}
	$output .= "</div>";
if(!empty($custom_el_css)) {
		$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>");'
						. '})(jQuery);'
					. '</script>';
}
$output .= "</div>";
echo $output;

