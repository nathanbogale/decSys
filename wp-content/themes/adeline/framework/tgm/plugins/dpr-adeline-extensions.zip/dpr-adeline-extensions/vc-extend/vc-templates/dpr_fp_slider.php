<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$output = $el_class = $animation_type = '';

$atts = vc_map_get_attributes( 'dpr_fp_slider', $atts );
extract( $atts );
wp_enqueue_script('fullpage', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/jquery.fullPage.js', array('jquery'), null, true);	
wp_enqueue_script('dpr-fp-slider', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/dpr.fp.slider.js', array('jquery'), null, true);	

if ($enable_pagination == 'yes') {
	$el_class .= ' pagination-enabled';
} else {
	$el_class .= ' pagination-disabled';
}
if ($animation_type != '') {
	$el_class .= ' animation-style-'.$animation_type;
}
$id = uniqid('dpr-fp-slider-');
$output .= '<div id="'.esc_attr($id).'" class="dpr-fp-slider'.$el_class.'">';
$output .= '<div class="dpr-fps-wrapper">';
	$output .= do_shortcode($content);
$output .= '</div>';
$output .= '</div>';
echo $output;