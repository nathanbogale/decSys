<?php

// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}

// Add paths to custom templates, parameters and shortcodes

$module_images = DPR_EXTENSIONS_PLUGIN_URL .'vc-extend/assets/admin/img/modules/';



foreach(glob(DPR_EXTENSIONS_PLUGIN_PATH.'vc-extend/params/*.php') as $parameter) {

		require_once($parameter);

}

if ( is_plugin_active( 'booked/booked.php' ) ) {

	foreach(glob(DPR_EXTENSIONS_PLUGIN_PATH.'vc-extend/shortcodes-map/booked/*.php') as $booked_shortcode) {

		require_once($booked_shortcode);

	}

}

if ( is_plugin_active( 'dpr-timetable/dpr-timetable.php' ) ) {

	foreach(glob(DPR_EXTENSIONS_PLUGIN_PATH.'vc-extend/shortcodes-map/timetable/*.php') as $timetable_shortcode) {

		require_once($timetable_shortcode);

	}

}



if ( is_plugin_active( 'contact-form-7/wp-contact-form-7.php' ) || defined( 'WPCF7_PLUGIN' ) ) {

	foreach(glob(DPR_EXTENSIONS_PLUGIN_PATH.'vc-extend/shortcodes-map/cf7/*.php') as $cf7_shortcode) {

		require_once($cf7_shortcode);

	}

}

if ( is_plugin_active( 'sitepress-multilingual-cms/sitepress.php' ) || function_exists('icl_object_id' ) ) {

	foreach(glob(DPR_EXTENSIONS_PLUGIN_PATH.'vc-extend/shortcodes-map/wpml/*.php') as $wpml_shortcode) {

		require_once($wpml_shortcode);

	}

}

foreach(glob(DPR_EXTENSIONS_PLUGIN_PATH.'vc-extend/shortcodes-map/*.php') as $shortcode) {

	require_once($shortcode);

}

if(class_exists('WooCommerce')) {

	foreach(glob(DPR_EXTENSIONS_PLUGIN_PATH.'vc-extend/shortcodes-map/woo/*.php') as $woo_shortcode) {

		require_once($woo_shortcode);

	}

}



if ( function_exists( 'vc_shortcodes_theme_templates_dir' ) || function_exists( 'vc_set_template_dir' ) ) {

	$templates_path = DPR_EXTENSIONS_PLUGIN_URL . 'vc-ectend/vc-templates/';

	vc_set_shortcodes_templates_dir( $templates_path );

}



// Add VC admin CSS styles

function dpr_load_custom_vc_admin_scripts() {

        wp_enqueue_style( 'dpr_vc_admin_css', DPR_EXTENSIONS_PLUGIN_URL . 'vc-extend/assets/admin/css/dpr_vc_admin.css', false, '' );

        wp_enqueue_script( 'dpr_vc_admin_js', DPR_EXTENSIONS_PLUGIN_URL . 'vc-extend/assets/admin/js/dpr_vc_admin.js', false, true);

}

add_action( 'admin_enqueue_scripts', 'dpr_load_custom_vc_admin_scripts' );

//Add VC frontend styles

function dpr_load_custom_vc_frontend_style() {

			wp_enqueue_style( 'dpr_vc_frontend_css', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/css/dpr_vc_frontend.css', array('js_composer_front'), '', 'screen' );

			if(is_rtl()) {

			wp_enqueue_style( 'dpr_vc_frontend_rtl_css', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/css/dpr_vc_frontend_rtl.css', array('js_composer_front'), '', 'screen' );

			}

    }

add_action('wp_head', 'dpr_load_custom_vc_frontend_style', 6);



// VC Helpers functuins

if(!function_exists('dpr_enqueue_waypoint_js')) {

	function dpr_enqueue_waypoint_js() {
		if (WPB_VC_VERSION < 6) { 
			wp_enqueue_script( 'waypoints' );
		} else {
			wp_enqueue_script( 'vc_waypoints' );
		}
	
	}

}


if(!function_exists('dpr_enqueue_animate_css')) {

	function dpr_enqueue_animate_css() {
		if (WPB_VC_VERSION < 6) { 
			wp_enqueue_style( 'animate-css' );
		} else {
			wp_enqueue_style( 'vc_animate-css' );
		}
	
	}

}



if(!function_exists('dpr_shadow_param_to_css')){

	

	function dpr_shadow_param_to_css ($param_val) {

		$param_value_array = explode('|',$param_val);

		$shadow_css = end($param_value_array);

		return ($shadow_css);

	}

	

}



if(!function_exists('dpr_convert_url_to_lightbox_url')){



		function dpr_convert_url_to_lightbox_url($link){

			

			$lightbox_url = $link;

			//DAILYMOTION

			if (preg_match("#^https?://(?:www\.)?dailymotion.com#", $link)) {

			 

			$dailymotion = "http://www.dailymotion.com/video/";

			 

			if (filter_var($link, FILTER_VALIDATE_URL) AND strpos($link, $dailymotion) !== FALSE) {

			$link = str_replace($dailymotion, "", $link);

			//$pos_underscore = strpos($link, "_");

			//$link = substr($link, 0, $pos_underscore);

			}

			$lightbox_url = "//www.dailymotion.com/embed/video/" . $link;

			 

			}

			 

			//VIMEO

			if (preg_match("#^https?://(?:www\.)?vimeo.com#", $link)) {

			 

			$vimeo = "https://vimeo.com/";

			 

			if (filter_var($link, FILTER_VALIDATE_URL) AND strpos($link, $vimeo) !== FALSE) {

			$link = str_replace($vimeo, "", $link);

			} else if (is_numeric($link) === TRUE) {

			$link = $link;

			} else {

			return FALSE;

			}

			 

			$lightbox_url = "//player.vimeo.com/video/" . $link ;

			}

			 

			//YOUTUBE

			if (preg_match("#^https?://(?:www\.)?youtube.com#", $link)) {

			 

			$youtube = "https://www.youtube.com/watch?v=";

			 

			if (filter_var($link, FILTER_VALIDATE_URL) AND strpos($link, $youtube) !== FALSE) {

			$link = str_replace($youtube, "", $link);

			}

			$lightbox_url = "//www.youtube.com/embed/" . $link;

			 

			}

			 

			return $lightbox_url;

		}

 

}







if(!function_exists('dpr_get_youtube_id')){



		function dpr_get_youtube_id($url){

		preg_match('%(?:youtube(?:-nocookie)?\.com/(?:[^/]+/.+/|(?:v|e(?:mbed)?)/|.*[?&]v=)|youtu\.be/)([^"&?/ ]{11})%i', $url, $match);

		$youtube_id = $match[1];

		return $youtube_id;

		}

		

}



if(!function_exists('dpr_generate_typography_style')){

	

	function dpr_generate_typography_style ($color, $font_size, $line_height, $letter_spacing, $font_style, $google_font = false) {

		$typography_style = '';

		if( $color !='' ) {

			$typography_style .= 'color:'.$color.';';

		}

		if( $font_size !='' ) {

			$typography_style .= 'font-size:'.$font_size.'px;';

		}

		if( $line_height !='' ) {

			$typography_style .= 'line-height:'.$line_height.'px;';

		}

		if( $letter_spacing !='' ) {

			$typography_style .= 'letter-spacing:'.$letter_spacing.'px;';

		}

		if(isset($font_style) && !empty($font_style)) {

			if(substr_count($font_style, 'italic') == 1) {

				$typography_style .= 'font-style:italic;';

			}

			if(substr_count($font_style, 'underline') == 1) {

				$typography_style .= 'text-decoration:underline;';

			}

			if(substr_count($font_style, 'bold') == 1) {

				$typography_style .= 'font-weight:bold;';

			}

		}

		

		if ( $google_font != '' && class_exists('Vc_Google_Fonts')) {

			$google_fonts_obj  = new Vc_Google_Fonts();

			$google_fonts_data = strlen( $google_font ) > 0 ? $google_fonts_obj->_vc_google_fonts_parse_attributes( array(), $google_font ) : '';

			if($google_fonts_data != '') {

				    $google_fonts_family = explode( ':', $google_fonts_data['values']['font_family'] );

					$settings = get_option( 'wpb_js_google_fonts_subsets' );

					if ( is_array( $settings ) && ! empty( $settings ) ) {

						$subsets = '&subset=' . implode( ',', $settings );

					} else {

						$subsets = '';

					}

					if ( isset( $google_fonts_data['values']['font_family'] ) && function_exists('vc_build_safe_css_class') ) {

						wp_enqueue_style( 'vc_google_fonts_' . vc_build_safe_css_class( $google_fonts_data['values']['font_family'] ), '//fonts.googleapis.com/css?family=' . $google_fonts_data['values']['font_family'] . $subsets );

						$typography_style .= 'font-family:' . $google_fonts_family[0] . '; ';

					}





			}

		}

		

		if( $typography_style != '') {

			$typography_style = ' style="'.$typography_style.'" ';

		}

		

		return ($typography_style);

	}

	

}



if(!function_exists('dpr_generate_typography_css')){

	

	function dpr_generate_typography_css ($color, $font_size, $line_height, $letter_spacing, $font_style, $google_font = false) {

		$typography_css = '';

		if( $color !='' ) {

			$typography_css .= 'color:'.$color.';';

		}

		if( $font_size !='' ) {

			$typography_css .= 'font-size:'.$font_size.'px;';

		}

		if( $line_height !='' ) {

			$typography_css .= 'line-height:'.$line_height.'px;';

		}

		if( $letter_spacing !='' ) {

			$typography_css .= 'letter-spacing:'.$letter_spacing.'px;';

		}

		if(isset($font_style) && !empty($font_style)) {

			if(substr_count($font_style, 'italic') == 1) {

				$typography_css .= 'font-style:italic;';

			}

			if(substr_count($font_style, 'underline') == 1) {

				$typography_css .= 'text-decoration:underline;';

			}

			if(substr_count($font_style, 'bold') == 1) {

				$typography_css .= 'font-weight:bold;';

			}

		}

		

		if ( $google_font != '' && class_exists('Vc_Google_Fonts')) {

			$google_fonts_obj  = new Vc_Google_Fonts();

			$google_fonts_data = strlen( $google_font ) > 0 ? $google_fonts_obj->_vc_google_fonts_parse_attributes( array(), $google_font ) : '';

			if($google_fonts_data != '') {

				    $google_fonts_family = explode( ':', $google_fonts_data['values']['font_family'] );

					$settings = get_option( 'wpb_js_google_fonts_subsets' );

					if ( is_array( $settings ) && ! empty( $settings ) ) {

						$subsets = '&subset=' . implode( ',', $settings );

					} else {

						$subsets = '';

					}

					if ( isset( $google_fonts_data['values']['font_family'] ) && function_exists('vc_build_safe_css_class') ) {

						wp_enqueue_style( 'vc_google_fonts_' . vc_build_safe_css_class( $google_fonts_data['values']['font_family'] ), '//fonts.googleapis.com/css?family=' . $google_fonts_data['values']['font_family'] . $subsets );

						$typography_css .= 'font-family:' . $google_fonts_family[0] . '; ';

					}





			}

		}

		

		return ($typography_css);

	}

	

}





if (!function_exists('dpr_generate_read_more')) {

	/**

	 * Genrerate readmore button for VC elements

	 */

	function dpr_generate_read_more($atts = array()) {

		$html = $css = $link_more_open_tag = $link_more_close_tag = '';

		$unique_id = uniqid('readmore').'-'.rand(1,9999);

		$defaults = array(

			'link'				=> '',

			'readmore_show'		=> '',

			'read_more' 	=> 'none',

			'readmore_style'	=> 'button',

			'readmore_text'		=> esc_html__('Read More', 'dpr-adeline-extensions'),

			'readmore_size'	=> '',

			'readmore_shape' => '',

			'custom_button_size' => '',

			'custom_button_shape' => '',

			'custom_button_color' => '',

			'custom_button_color_hover' => '',

			'custom_button_bg_color' => '',

			'custom_button_bg_color_hover' => '',

			'custom_button_border_color' => '',

			'custom_button_border_color_hover' => '',

		);

		extract(shortcode_atts($defaults, $atts));

		

		$span_class = 'btn';

		if ($readmore_style == 'button-outlined')  {

			$span_class .= ' btn-outlined';

		}

		if ($readmore_style == 'button-outlined' || $readmore_style == 'button' || $readmore_size == 'btn-sm')  {

			$span_class .= ' btn-sm';

		}

		if ($readmore_shape != '')  {

			$span_class .= ' '.$readmore_shape;

		}

		if ($readmore_style == 'minimal')  {

			$span_class .= ' btn-min';

		}

		if ($readmore_style == 'custom')  {

			$span_class .= ' '.$custom_button_size.' '.$custom_button_shape;

		}

		if(isset($read_more) && strcmp($read_more, 'more') == 0 && isset($link)) {

			$link = vc_build_link($link);

			$link_title = !empty($link['title']) ? 'title="'.esc_attr($link['title']).'"' : '';

			$link_rel = !empty($link['rel']) ? 'rel="'.esc_attr($link['rel']).'"' : '';

			$link_target = !empty($link['target']) ? 'target="'.esc_attr(preg_replace('/\s+/', '', $link['target'])).'"' : '';

			$link_more_open_tag = '<a href="'.esc_url($link['url']).'" '.$link_title.' '.$link_target.' '.$link_rel.'>';

			$link_more_close_tag = '</a>';

		}



		if(isset($readmore_show) && strcmp($readmore_show, 'show') == 0) {

			$html .= '<div  class="dpr-read-more-wrap">';

			$html .= $link_more_open_tag;

			$html .= '<span id ="'.esc_attr($unique_id).'" class="'.$span_class.'">'.$readmore_text.'</span>';

			$html .= $link_more_close_tag;

			$html .= '</div>';

			if ($custom_button_color != '') {

				$css .= '#'.esc_js($unique_id).' {color:'.$custom_button_color.' !important}' ;

			}

			if ($custom_button_bg_color != '') {

				$css .= '#'.esc_js($unique_id).' {background-color:'.$custom_button_bg_color.' !important}' ;

			}

			if ($custom_button_border_color != '') {

				$css .= '#'.esc_js($unique_id).' {border-color:'.$custom_button_border_color.' !important}' ;

			}

			if ($custom_button_color_hover != '') {

				$css .= '#'.esc_js($unique_id).':hover {color:'.$custom_button_color_hover.' !important}' ;

			}

			if ($custom_button_bg_color_hover != '') {

				$css .= '#'.esc_js($unique_id).':hover {background-color:'.$custom_button_bg_color_hover.' !important}' ;

			}

			if ($custom_button_border_color_hover != '') {

				$css .= '#'.esc_js($unique_id).':hover {border-color:'.$custom_button_border_color_hover.' !important}' ;

			}

		}

		$output = array($html,$css);

		return $output;

	

	}

}



//DPR custom TTA functions



if(!function_exists('dpr_getParamTabsList')){

	function dpr_getParamTabsList( $atts, $content, $type ) {

			if ( $type == 'pageable' ) {

			return;

			}

			$isPageEditabe = vc_is_page_editable();

			$html = array();

			$html[] = '<div class="vc_tta-tabs-container">';

			$html[] = '<ul class="vc_tta-tabs-list">';

			if ( ! $isPageEditabe ) {

				$active_section = intval( $atts['active_section'] );

	

				foreach ( WPBakeryShortCode_VC_Tta_Section::$section_info as $nth => $section ) {

					$icon_html = '';

					$classes = array( 'vc_tta-tab' );

					if ( ( $nth + 1 ) === $active_section ) {

						$classes[] = 'vc_active';

					}

					if ($atts['style'] == 'style_4') {

					$tooltip = '';

					if ('yes' == $atts['use_tooltips']) {

					$tooltip .= ' data-content="'.$section['title'].'" data-toggle="popover" data-trigger="hover" data-delay="300" data-placement="top"';

					}

					if ( 'yes' === $section['add_icon'] ) {

						$icon_html ='<i class="vc_tta-icon ' . $section['icon'] . '"></i>';

					}

					$a_html = '<a class="vc-tta-tab-link dpr-tip" href="#' . $section['tab_id'] . '"'.$tooltip. ' data-vc-tabs data-vc-container=".vc_tta">' .  $icon_html . '</a>';

					

					} else {

					

					$title = '<span class="vc_tta-title-text">' . $section['title'] . '</span>';

					if ( 'yes' === $section['add_icon'] ) {

						$icon_html ='<i class="vc_tta-icon ' . $section['icon'] . '"></i>';

						if ( 'left' === $section['i_position'] ) {

							$title = $icon_html . $title;

						} else {

							$title = $title . $icon_html;

						}

					}

					$a_html = '<a class="vc-tta-tab-link" href="#' . $section['tab_id'] . '" data-vc-tabs data-vc-container=".vc_tta">' . $title . '</a>';

					

					}

					$html[] = '<li class="' . implode( ' ', $classes ) . '" data-vc-tab>' . $a_html . '</li>';

				}

			}

	

			$html[] = '</ul>';

			$html[] = '</div>';

	

			return implode( '', $html );

	}

}

if(!function_exists('dpr_getParamPaginationList')){



	 function dpr_getParamPaginationList( $atts, $content ) {

			if ( empty( $atts['pagination_style'] ) ) {

				return null;

			}

			$pag_classes = array();

			$pag_classes[] = 'vc_general';

			$pag_classes[] = 'vc_pagination';

	

			if ( isset( $atts['pagination_style'] ) && strlen( $atts['pagination_style'] ) > 0 ) {

				$chunks = explode( '-', $atts['pagination_style'] );

				$pag_classes[] = 'vc_pagination-style-' . $chunks[0];

				$pag_classes[] = 'vc_pagination-shape-' . $chunks[1];

			}

	

			if ( isset( $atts['pagination_color'] ) && strlen( $atts['pagination_color'] ) > 0 ) {

				$pag_classes[] = 'vc_pagination-color-' . $atts['pagination_color'];

			}

			$pag_classes = implode( ' ', $pag_classes );

	

	

	

	

			$isPageEditabe = vc_is_page_editable();

	

			$sectionClass = visual_composer()->getShortCode( 'vc_tta_section' )->shortcodeClass();

	

			$html = array();

			$html[] = '<ul class="' . $pag_classes . '">';

	

			if ( ! $isPageEditabe ) {

				VcShortcodeAutoloader::getInstance()->includeClass( 'WPBakeryShortCode_VC_Tta_Section' );

				foreach ( WPBakeryShortCode_VC_Tta_Section::$section_info as $nth => $section ) {

					$active_section = intval( $atts['active_section'] );

	

					$classes = array( 'vc_pagination-item' );

					if ( ( $nth + 1 ) === $active_section ) {

						$classes[] = 'vc_active';

					}

	

					$a_html = '<a href="#' . $section['tab_id'] . '" class="vc_pagination-trigger" data-vc-tabs data-vc-container=".vc_tta"></a>';

					$html[] = '<li class="' . implode( ' ', $classes ) . '" data-vc-tab>' . $a_html . '</li>';

				}

			}

	

			$html[] = '</ul>';

	

			return implode( '', $html );

		}

}



if(!function_exists('dpr_getSliderArrowsStyle')){

		

		function dpr_getSlickArrowsStyle(&$atts){

			

			$arrow_icons_array = $style_icon = $style_hover_icon = $style_bg = $padding_top =  $style_navigation = $style_hover_bg = "";

			$expand_factor = 2;

			$pading_factor =0.8;

			

			$options = array(

				"arrow_icon"=>'',

				"arrow_use_shadow_on_hover"=>'',

				"arrow_hover_shadow" => '',

				"arrow_icon_color"=>'',

				"arrow_icon_color_hover"=>'',

				"arrow_icon_size"=>'',

				"arrow_bg_border_radius"=>'',

				"arrow_bg_border_width"=>'1',

				"arrow_bg_color"=>'',

				"arrow_bg_color_hover"=>'',

				"arrow_bg_border_color"=>'',

				"arrow_bg_border_color_hover"=>'',

				"arrow_use_numbers"=>'yes',

				"arrow_numbers_color"=>'',

			);

			extract( shortcode_atts( $options, $atts ) );

			

			if(!empty($arrow_icon_color)){

				$style_icon.="color:".esc_attr($arrow_icon_color).";";

			}

			if(!empty($arrow_icon_size)){

				$style_icon.="font-size:".(int)$arrow_icon_size."px;";

				$style_bg.="width:".((int)$arrow_icon_size*$expand_factor)."px;";

				$style_bg.="height:".((int)$arrow_icon_size*$expand_factor)."px;";

				$padding_top.=$arrow_use_numbers=="yes" ? "padding-top:".((int)$arrow_icon_size/$pading_factor)."px;" : "padding-top:25px;";

			}else{

				$padding_top.=$arrow_use_numbers=="yes" ? "padding-top:".(12/$pading_factor)."px;" : "";

			}

			if(!empty($arrow_hover_color_hover)){

				$style_hover_icon.="color:".esc_attr($arrow_icon_color_hover)." !important;";

			}

			if(!empty($arrow_bg_border_radius)){

				$style_bg.="border-radius:".esc_attr($arrow_bg_border_radius)."px;";

			}

			$set_border = false;

			if(!empty($arrow_bg_border_width)){

				$set_border = true;

				$style_bg.="border-style:solid;";

				$style_bg.="border-width:".esc_attr($arrow_bg_border_width)."px;";

			}

			if(!empty($arrow_bg_color)){

				

				$style_bg.="background-color:".esc_attr($arrow_bg_color).";";

			}

			if(!empty($arrow_bg_border_color)){

				$style_bg.="border-style:solid;";

				$style_bg.=!$set_border ? "border-width:1px;" : "";

				$style_bg.="border-color:".esc_attr($arrow_bg_border_color).";";

			}

			if(!empty($arrow_bg_color_hover)){

				$style_hover_bg.="background-color:".esc_attr($arrow_bg_color_hover)." !important;";

			}

			if(!empty($arrow_bg_border_color_hover)){

				$style_bg.="border-style:solid";

				$style_hover_bg.=!$set_border ? "border-width:1px;" : "";

				$style_hover_bg.="border-color:".esc_attr($arrow_bg_border_color_hover)." !important;";

			}

			if($arrow_use_shadow_on_hover=="yes"){

				if(dpr_shadow_param_to_css($arrow_hover_shadow) != '') {

				$style_hover_bg.= dpr_shadow_param_to_css($arrow_hover_shadow);

				}

			}

			if($arrow_use_numbers!="yes"){

				$style_navigation .= "display:none;";

			}

			if($arrow_numbers_color){

				$style_navigation.="color:".esc_attr($arrow_numbers_color).";";

			}

			switch ($arrow_icon) {

				case 'arrow-type-1':

					$arrow_icons_array = array(

							"left"=>"dpr-icon-angle-left",

							"right"=>"dpr-icon-angle-right",

					);

					break;

				case 'arrow-type-2':

					$arrow_icons_array = array(

							"left"=>"dpr-icon-angle-double-left",

							"right"=>"dpr-icon-angle-double-right",

					);

					break;

				case 'arrow-type-3':

					$arrow_icons_array = array(

							"left"=>"dpr-icon-caret-left",

							"right"=>"dpr-icon-caret-right",

					);

					break;

				case 'arrow-type-4':

					$arrow_icons_array = array(

							"left"=>"dpr-icon-chevron-left",

							"right"=>"dpr-icon-chevron-right",

					);

					break;

				case 'arrow-type-5':

					$arrow_icons_array = array(

							"left"=>"dpr-icon-arrow-left",

							"right"=>"dpr-icon-arrow-right",

					);

					break;

				case 'arrow-type-6':

					$arrow_icons_array = array(

							"left"=>"dpr-icon-long-arrow-left",

							"right"=>"dpr-icon-long-arrow-right",

					);

					break;

				default:

					$arrow_icons_array = array(

							"left"=>"dpr-icon-angle-left",

							"right"=>"dpr-icon-angle-right",

					);

			}

			

			$result = array(

				"style-icon"=>$style_icon,

				"style-hover-icon"=>$style_hover_icon,

				"style-bg"=>$style_bg,

				"style-hover-bg"=>$style_hover_bg,

				"style-navigation"=>$style_navigation,

				"padding_top"=>$padding_top,

				"icon"=>$arrow_icons_array,

				"icon_left"=>$arrow_icons_array["left"],

				"icon_right"=>$arrow_icons_array["right"],

				"arrow_icon_color"=>$arrow_icon_color,

				"arrow_icon_hover_color"=>$arrow_icon_color_hover,

				"arrow_icon_size"=>$arrow_icon_size,

				"arrow_bg_border_radius"=>$arrow_bg_border_radius,

				"arrow_bg_border_width"=>$arrow_bg_border_width,

				"arrow_bg_color"=>$arrow_bg_color,

				"arrow_bg_color_hover"=>$arrow_bg_color_hover,

				"arrow_bg_border_color"=>$arrow_bg_border_color,

				"arrow_bg_border_color_hover"=>$arrow_bg_border_color_hover,

			);

			return $result;

		}

}



/* Genreate Google Map custom style code */

if(!function_exists('dpr_getGoogleMapStyle')){

		

		function dpr_getGoogleMapStyle($style,$map_custom_style){



			switch ($style) {

				case 'ultra_light':

					$code = '[{"featureType": "water","elementType": "geometry","stylers": [{"color": "#e9e9e9"},{"lightness": 17}]},{"featureType": "landscape","elementType": "geometry","stylers": [{"color": "#f5f5f5"

            },{"lightness": 20}]},{"featureType": "road.highway","elementType": "geometry.fill","stylers": [{"color": "#ffffff"},{"lightness": 17}]},{"featureType": "road.highway","elementType": "geometry.stroke","stylers": [{  "color": "#ffffff"},{"lightness": 29},{"weight": 0.2}]},{"featureType": "road.arterial","elementType": "geometry","stylers": [{"color": "#ffffff"},{"lightness": 18}]},{"featureType": "road.local","elementType": "geometry",      "stylers": [ {"color": "#ffffff"},{"lightness": 16}]},{"featureType": "poi","elementType": "geometry","stylers": [{"color": "#f5f5f5"},{"lightness": 21}]},{"featureType": "poi.park","elementType": "geometry","stylers":[          {"color": "#dedede"},{ "lightness": 21}]},{"elementType": "labels.text.stroke","stylers":[{"visibility": "on"},{"color": "#ffffff"},{"lightness": 16}]},{"elementType": "labels.text.fill","stylers":[{"saturation":36},{"color": "#333333"},{"lightness": 40}]},{"elementType": "labels.icon","stylers":[{"visibility": "off"}]},{"featureType": "transit","elementType": "geometry","stylers":[{"color": "#f2f2f2"},{"lightness":19}]},{"featureType": "administrative","elementType": "geometry.fill","stylers":[{"color": "#fefefe"},{"lightness": 20}]},{"featureType": "administrative","elementType": "geometry.stroke","stylers":[{"color": "#fefefe"},{"lightness": 17},{           "weight": 1.2}]}]';

					break;

				case 'subtle_grayscale':

					$code = '[{"featureType":"administrative","elementType":"all","stylers":[{"saturation":"-100"}]},{"featureType":"administrative.province","elementType":"all","stylers":[{"visibility":"off"}]},{"featureType":"landscape","elementType":"all","stylers":[{"saturation":-100},{"lightness":65},{"visibility":"on"}]},{"featureType":"poi","elementType":"all","stylers":[{"saturation":-100},{"lightness":"50"},{"visibility":"simplified"}]},{"featureType":"road","elementType":"all","stylers":[{"saturation":"-100"}]},{"featureType":"road.highway","elementType":"all","stylers":[{"visibility":"simplified"}]},{"featureType":"road.arterial","elementType":"all","stylers":[{"lightness":"30"}]},{"featureType":"road.local","elementType":"all","stylers":[{"lightness":"40"}]},{"featureType":"transit","elementType":"all","stylers":[{"saturation":-100},{"visibility":"simplified"}]},{"featureType":"water","elementType":"geometry","stylers":[{"hue":"#ffff00"},{"lightness":-25},{"saturation":-97}]},{"featureType":"water","elementType":"labels","stylers":[{"lightness":-25},{"saturation":-100}]}]';

					break;

				case 'dark_gray':

					$code = '[{"featureType":"all","elementType":"labels.text.fill","stylers":[{"saturation":36},{"color":"#000000"},{"lightness":40}]},{"featureType":"all","elementType":"labels.text.stroke","stylers":[{"visibility":"on"},{"color":"#000000"},{"lightness":16}]},{"featureType":"all","elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featureType":"administrative","elementType":"geometry.fill","stylers":[{"color":"#000000"},{"lightness":20}]},{"featureType":"administrative","elementType":"geometry.stroke","stylers":[{"color":"#000000"},{"lightness":17},{"weight":1.2}]},{"featureType":"landscape","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":20}]},{"featureType":"poi","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":21}]},{"featureType":"road.highway","elementType":"geometry.fill","stylers":[{"color":"#000000"},{"lightness":17}]},{"featureType":"road.highway","elementType":"geometry.stroke","stylers":[{"color":"#000000"},{"lightness":29},{"weight":.2}]},{"featureType":"road.arterial","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":18}]},{"featureType":"road.local","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":16}]},{"featureType":"transit","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":19}]},{"featureType":"water","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":17}]}]';

					break;

				case 'fresh':

					$code = '[{featureType:"water",stylers:[{hue:"#0096ff"},{saturation:39},{lightness:-8}]},{featureType:"landscape.man_made",elementType:"geometry",stylers:[{visibility:"on"},{hue:"#ff8000"},{saturation:2},{lightness:-4}]},{featureType:"administrative.land_parcel",stylers:[{visibility:"off"}]},{featureType:"administrative.neighborhood",stylers:[{visibility:"off"}]},{featureType:"landscape.man_made",elementType:"labels",stylers:[{visibility:"off"}]},{featureType:"poi.park",stylers:[{hue:"#91ff00"},{saturation:15},{lightness:0}]},{featureType:"poi.business",stylers:[{visibility:"off"}]},{featureType:"poi.sports_complex",elementType:"labels",stylers:[{visibility:"off"}]},{featureType:"poi.government",elementType:"labels",stylers:[{visibility:"off"}]},{featureType:"poi.medical",elementType:"labels",stylers:[{visibility:"off"}]},{featureType:"road",elementType:"labels",stylers:[{hue:"#000000"},{saturation:-100},{gamma:2},{lightness:"10"}]},{featureType:"road.arterial",elementType:"geometry",stylers:[{visibility:"simplified"},{saturation:59},{hue:"#00fff7"},{lightness:87},{gamma:3.82}]},{featureType:"road.local",elementType:"labels",stylers:[{visibility:"off"}]},{featureType:"road.highway",elementType:"geometry",stylers:[{visibility:"on"},{saturation:59},{hue:"#00fff7"},{lightness:87},{gamma:3.82}]},{featureType:"transit",stylers:[{visibility:"off"}]},{featureType:"poi.place_of_worship",elementType:"labels",stylers:[{visibility:"off"}]}]';

					break;

				case 'pastel':

					$code = '[{"featureType":"water","stylers":[{"visibility":"on"},{"color":"#acbcc9"}]},{"featureType":"landscape","stylers":[{"color":"#f2e5d4"}]},{"featureType":"road.highway","elementType":"geometry","stylers":[{"color":"#c5c6c6"}]},{"featureType":"road.arterial","elementType":"geometry","stylers":[{"color":"#e4d7c6"}]},{"featureType":"road.local","elementType":"geometry","stylers":[{"color":"#fbfaf7"}]},{"featureType":"poi.park","elementType":"geometry","stylers":[{"color":"#c5dac6"}]},{"featureType":"administrative","stylers":[{"visibility":"on"},{"lightness":33}]},{"featureType":"road"},{"featureType":"poi.park","elementType":"labels","stylers":[{"visibility":"on"},{"lightness":20}]},{},{"featureType":"road","stylers":[{"lightness":20}]}]';

					break;

				case 'shades_of_blue':

					$code = '[{"featureType":"all","elementType":"labels.text.fill","stylers":[{"visibility":"simplified"}]},{"featureType":"all","elementType":"labels.text.stroke","stylers":[{"color":"#53606f"},{"weight":"5.04"},{"invert_lightness":!0}]},{"featureType":"administrative","elementType":"geometry","stylers":[{"weight":0.6},{"color":"#1a3541"}]},{"featureType":"landscape","elementType":"geometry","stylers":[{"color":"#283547"}]},{"featureType":"poi","elementType":"geometry","stylers":[{"color":"#7e4457"},{"visibility":"off"}]},{"featureType":"poi.park","elementType":"geometry","stylers":[{"color":"#2e3a4f"}]},{"featureType":"road","elementType":"geometry","stylers":[{"color":"#4c5969"}]},{"featureType":"transit","elementType":"geometry","stylers":[{"color":"#496672"},{"visibility":"off"}]},{"featureType":"water","elementType":"geometry","stylers":[{"color":"#3c4959"}]}]';

					break;

				case 'vintage':

					$code = '[{"featureType":"administrative","stylers":[{"visibility":"off"}]},{"featureType":"poi","stylers":[{"visibility":"simplified"}]},{"featureType":"road","elementType":"labels","stylers":[{"visibility":"simplified"}]},{"featureType":"water","stylers":[{"visibility":"simplified"}]},{"featureType":"transit","stylers":[{"visibility":"simplified"}]},{"featureType":"landscape","stylers":[{"visibility":"simplified"}]},{"featureType":"road.highway","stylers":[{"visibility":"off"}]},{"featureType":"road.local","stylers":[{"visibility":"on"}]},{"featureType":"road.highway","elementType":"geometry","stylers":[{"visibility":"on"}]},{"featureType":"water","stylers":[{"color":"#84afa3"},{"lightness":52}]},{"stylers":[{"saturation":-17},{"gamma":0.36}]},{"featureType":"transit.line","elementType":"geometry","stylers":[{"color":"#3f518c"}]}]';

					break;

				case 'apple_maps':

					$code = '[{"featureType":"administrative.country","elementType":"labels.text","stylers":[{"lightness":"29"}]},{"featureType":"administrative.province","elementType":"labels.text.fill","stylers":[{"lightness":"-12"},{"color":"#796340"}]},{"featureType":"administrative.locality","elementType":"labels.text.fill","stylers":[{"lightness":"15"},{"saturation":"15"}]},{"featureType":"landscape.man_made","elementType":"geometry","stylers":[{"visibility":"on"},{"color":"#fbf5ed"}]},{"featureType":"landscape.natural","elementType":"geometry","stylers":[{"visibility":"on"},{"color":"#fbf5ed"}]},{"featureType":"poi","elementType":"labels","stylers":[{"visibility":"off"}]},{"featureType":"poi.attraction","elementType":"all","stylers":[{"visibility":"on"},{"lightness":"30"},{"saturation":"-41"},{"gamma":"0.84"}]},{"featureType":"poi.attraction","elementType":"labels","stylers":[{"visibility":"on"}]},{"featureType":"poi.business","elementType":"all","stylers":[{"visibility":"off"}]},{"featureType":"poi.business","elementType":"labels","stylers":[{"visibility":"off"}]},{"featureType":"poi.medical","elementType":"geometry","stylers":[{"color":"#fbd3da"}]},{"featureType":"poi.medical","elementType":"labels","stylers":[{"visibility":"on"}]},{"featureType":"poi.park","elementType":"geometry","stylers":[{"color":"#b0e9ac"},{"visibility":"on"}]},{"featureType":"poi.park","elementType":"labels","stylers":[{"visibility":"on"}]},{"featureType":"poi.park","elementType":"labels.text.fill","stylers":[{"hue":"#68ff00"},{"lightness":"-24"},{"gamma":"1.59"}]},{"featureType":"poi.sports_complex","elementType":"all","stylers":[{"visibility":"on"}]},{"featureType":"poi.sports_complex","elementType":"geometry","stylers":[{"saturation":"10"},{"color":"#c3eb9a"}]},{"featureType":"road","elementType":"geometry.stroke","stylers":[{"visibility":"on"},{"lightness":"30"},{"color":"#e7ded6"}]},{"featureType":"road","elementType":"labels","stylers":[{"visibility":"on"},{"saturation":"-39"},{"lightness":"28"},{"gamma":"0.86"}]},{"featureType":"road.highway","elementType":"geometry.fill","stylers":[{"color":"#ffe523"},{"visibility":"on"}]},{"featureType":"road.highway","elementType":"geometry.stroke","stylers":[{"visibility":"on"},{"saturation":"0"},{"gamma":"1.44"},{"color":"#fbc28b"}]},{"featureType":"road.highway","elementType":"labels","stylers":[{"visibility":"on"},{"saturation":"-40"}]},{"featureType":"road.arterial","elementType":"geometry","stylers":[{"color":"#fed7a5"}]},{"featureType":"road.arterial","elementType":"geometry.fill","stylers":[{"visibility":"on"},{"gamma":"1.54"},{"color":"#fbe38b"}]},{"featureType":"road.local","elementType":"geometry.fill","stylers":[{"color":"#ffffff"},{"visibility":"on"},{"gamma":"2.62"},{"lightness":"10"}]},{"featureType":"road.local","elementType":"geometry.stroke","stylers":[{"visibility":"on"},{"weight":"0.50"},{"gamma":"1.04"}]},{"featureType":"transit.station.airport","elementType":"geometry.fill","stylers":[{"color":"#dee3fb"}]},{"featureType":"water","elementType":"geometry","stylers":[{"saturation":"46"},{"color":"#a4e1ff"}]}]';

					break;

				case 'pale_classic':

					$code = '[{"featureType":"administrative","elementType":"labels.text.fill","stylers":[{"color":"#444444"}]},{"featureType":"landscape","elementType":"all","stylers":[{"color":"#f2f2f2"}]},{"featureType":"poi","elementType":"all","stylers":[{"visibility":"off"}]},{"featureType":"poi.park","elementType":"geometry","stylers":[{"saturation":"0"},{"gamma":"0"},{"visibility":"simplified"},{"color":"#e6f2e0"},{"lightness":"0"}]},{"featureType":"road","elementType":"all","stylers":[{"saturation":-100},{"lightness":45}]},{"featureType":"road.highway","elementType":"all","stylers":[{"visibility":"simplified"}]},{"featureType":"road.highway","elementType":"geometry.fill","stylers":[{"color":"#ffffff"}]},{"featureType":"road.arterial","elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featureType":"transit","elementType":"all","stylers":[{"visibility":"off"}]},{"featureType":"water","elementType":"all","stylers":[{"color":"#dde6e8"},{"visibility":"on"}]}]';

					break;

				case 'pale_purple':

					$code = '[{"featureType":"all","elementType":"labels.text.fill","stylers":[{"saturation":"-20"},{"color":"#a28bb5"},{"lightness":"50"}]},{"featureType":"all","elementType":"labels.text.stroke","stylers":[{"visibility":"on"},{"color":"#a28bb5"},{"lightness":"-20"},{"saturation":"20"}]},{"featureType":"all","elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featureType":"administrative","elementType":"geometry","stylers":[{"color":"#a28bb5"},{"saturation":"15"}]},{"featureType":"administrative","elementType":"geometry.fill","stylers":[{"color":"#a28bb5"},{"lightness":"10"}]},{"featureType":"administrative","elementType":"geometry.stroke","stylers":[{"color":"#a28bb5"},{"lightness":"-40"},{"weight":1.2}]},{"featureType":"administrative.land_parcel","elementType":"all","stylers":[{"visibility":"off"}]},{"featureType":"landscape","elementType":"geometry","stylers":[{"color":"#a28bb5"},{"lightness":"-20"},{"saturation":"20"}]},{"featureType":"poi","elementType":"geometry","stylers":[{"color":"#a28bb5"},{"lightness":"-25"},{"saturation":"20"}]},{"featureType":"road.highway","elementType":"geometry.fill","stylers":[{"color":"#a28bb5"},{"lightness":"-35"},{"saturation":"20"}]},{"featureType":"road.highway","elementType":"geometry.stroke","stylers":[{"color":"#000000"},{"lightness":29},{"weight":0.2}]},{"featureType":"road.arterial","elementType":"geometry","stylers":[{"color":"#a28bb5"},{"lightness":"-35"},{"saturation":"20"}]},{"featureType":"road.local","elementType":"geometry","stylers":[{"color":"#a28bb5"},{"lightness":"-35"},{"saturation":"20"}]},{"featureType":"transit","elementType":"all","stylers":[{"visibility":"off"}]},{"featureType":"water","elementType":"geometry","stylers":[{"color":"#a28bb5"},{"lightness":"-10"},{"saturation":"20"}]}]';

					break;

				case 'blue_watter':

					$code = '[{"featureType":"administrative","elementType":"labels.text.fill","stylers":[{"color":"#444444"}]},{"featureType":"landscape","elementType":"all","stylers":[{"color":"#f2f2f2"}]},{"featureType":"poi","elementType":"all","stylers":[{"visibility":"off"}]},{"featureType":"road","elementType":"all","stylers":[{"saturation":-100},{"lightness":45}]},{"featureType":"road.highway","elementType":"all","stylers":[{"visibility":"simplified"}]},{"featureType":"road.arterial","elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featureType":"transit","elementType":"all","stylers":[{"visibility":"off"}]},{"featureType":"water","elementType":"all","stylers":[{"color":"#0088f6"},{"visibility":"on"}]}]';

					break;

				case 'custom':

					$code = rawurldecode(base64_decode(strip_tags($map_custom_style)));

					break;

				default:

					$code = '';

			}



			return $code;

		}

}



/*/* Genreate CSS Animation field with custom parameter name and heading */



function dpr_map_add_css_animation( $label = true,$param_name,$heading,$group,$dependency = '' ) {

	$data = array(

		'type' => 'animation_style',

		'heading' => $heading,

		'param_name' => $param_name,

		'admin_label' => $label,

		'value' => '',

		'group' => $group,

		'dependency' => $dependency,

		'settings' => array(

			'type' => 'in',

			'custom' => array(

				array(

					'label' => __( 'Default', 'dpr-adeline-extensions' ),

					'values' => array(

						__( 'Top to bottom', 'dpr-adeline-extensions' ) => 'top-to-bottom',

						__( 'Bottom to top', 'dpr-adeline-extensions' ) => 'bottom-to-top',

						__( 'Left to right', 'dpr-adeline-extensions' ) => 'left-to-right',

						__( 'Right to left', 'dpr-adeline-extensions' ) => 'right-to-left',

						__( 'Appear from center', 'dpr-adeline-extensions' ) => 'appear',

					),

				),

			),

		)

	);



	return apply_filters( 'dpr_map_add_css_animation1', $data, $label,$param_name,$heading );

}



function dpr_string_limit($value, $limit = 100, $end = '...')

{

    if (mb_strwidth($value, 'UTF-8') <= $limit) {

        return $value;

    }



    return rtrim(mb_strimwidth($value, 0, $limit, '', 'UTF-8')).$end;

}



function dpr_process_svg( $type, $color , $height, $width, $paths  ) {

	

		// Create SVG markup

		switch ( $type ) {

			case 'triangle_top':

				$svg_markup = '<svg width="100%%" height="60" viewBox="0 0 1280 40" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg"><g fill="%2$s">%3$s</g></svg>';

				break;

			case 'triangle_bottom':

				$svg_markup = '<svg width="160px" height="140px" viewBox="0 0 160 140" xmlns="http://www.w3.org/2000/svg"><g fill="%2$s">%3$s</g></svg>';

				break;

			default:

				$svg_markup = '<svg width="100%%" height="%1$s" viewBox="0 0 1280 140" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg"><g fill="%2$s">%3$s</g></svg>';

				break;

		}



		$svg = sprintf( $svg_markup, $height, $color, $paths );



		

		$svg_bg = base64_encode( $svg ); 

		return $svg_bg;

		



}

