<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$unique_id = $el_class = $output = $custom_el_css = $text = $bg_color = $border_color = $border_width = $border_radius = '';
$text_color = $text_font_size = $text_line_height = $text_letter_spacing = $text_font_style = $use_google_fonts = $google_fonts = '';

$atts = vc_map_get_attributes( 'dpr_time_line_sep', $atts );
extract( $atts );

$el_class = $this->getExtraClass( $el_class );

$unique_id = uniqid('dpr-timeline-sep-').'-'.rand(1,9999);

/* Element classes */

$css_classes = array(
	'dpr-timeline-sep',
	esc_attr($unique_id),
	$el_class,
);

$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->settings['base'], $atts ) );

/* * ************************
 * Styles and custom CSS
 * *********************** */
$sep_typo_style = dpr_generate_typography_style($text_color, $text_font_size, $text_line_height, $text_letter_spacing, $text_font_style,$text_google_font);
if(isset($bg_color) && !empty($bg_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .date-label {background-color: '.esc_attr($bg_color).';}';
}
if(isset($border_color) && !empty($border_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .date-label {border-color: '.esc_attr($border_color).';}';
}
if(isset($border_width) && !empty($border_width)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .date-label {border-width: '.esc_attr($border_width).'px;}';
}
if(isset($border_radius) && !empty($border_radius)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .date-label {border-radius: '.esc_attr($border_radius).'px;}';
}



/* * ************************
 * Output
 * *********************** */
$output .= '<div id="'.esc_attr($unique_id).'" class="'.esc_attr($css_class).' clr">';
		$output .= '<div class="date-label" '.$sep_typo_style.'>';
			$output .= '<span>'.esc_html($text).'</span>';
		$output .= '</div>';		


if(!empty($custom_el_css)) {
		$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>");'
						. '})(jQuery);'
					. '</script>';
}
$output .= '</div>';

echo $output;