<?php

// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}



/*

  Shortcode: Time Line

 */



class WPBakeryShortCode_DPR_Time_Line extends WPBakeryShortCodesContainer {

	

}

vc_map(

	array(

		'name' => esc_html__('DP Time Line', 'dpr-adeline-extensions'),

		'base' => 'dpr_time_line',

		'icon' => 'icon-dpr-timeline',

		'class' => 'dpr-timeline',

		'as_parent' => array('only' =>'dpr_time_line_item,dpr_time_line_sep'),

		'content_element' => true,

		'controls' => 'full',

		'show_settings_on_create' => true,

  		"category" =>array( esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions')),

		'description' => 'Display vertical time line',

		'params' => array_merge(array(

			array(

				'heading'			=> '',

				'type'				=> 'dpr_info',

				'param_name'		=> 'info_1',

				'title' => 'NOTE',

				'icon' => 'info',

				'text' => esc_html('This is only shortode container for Time Line items. Add Timeline Items eg Time Line Separators inside here.'),

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set time line style.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Time line style', 'dpr-adeline-extensions'),

				'param_name'		=> 'timeline_style',

				''				=> 'solid',

				'options'			=> array(

					esc_html__('Default', 'dpr-adeline-extensions')	=> '',

					esc_html__('Solid', 'dpr-adeline-extensions')	=> 'solid',

					esc_html__('Dashed', 'dpr-adeline-extensions')	=> 'dashed',

					esc_html__('Dotted', 'dpr-adeline-extensions')	=> 'dotted',

					esc_html__('Double', 'dpr-adeline-extensions')	=> 'double'

				),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom time line color. Default is #dee3e6.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Time line color', 'dpr-adeline-extensions'),

				'param_name'		=> 'timeline_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set time line width.Default is 2px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Time line width', 'dpr-adeline-extensions'),

				'param_name'		=> 'timeline_size',

				'min'				=> 0,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Additional Settings', 'dpr-adeline-extensions' ),

				'param_name'       => 'extra_features_title',

				'edit_field_class' => 'vc_column vc_col-sm-12',

			),

		    array(

				'type' => 'textfield',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Extra Class Name', 'dpr-adeline-extensions'),

				'param_name' => 'el_class',

			),



		)),

		'js_view' => 'VcColumnView'

	)

);



/*** Time Line Item ***/



class WPBakeryShortCode_DPR_Time_Line_Item  extends WPBakeryShortCodesContainer {}

vc_map( 

	array(

		"name" =>  __( 'Time Line Item', 'dpr-adeline-extensions' ),

		"base" => "dpr_time_line_item",

		"content_element" => true,

		"as_parent" => array('only' => 'vc_row'),

		"as_child" => array('only' => 'dpr_time_line'),

		"category" =>array( esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions')),

		'icon' => 'icon-dpr-timeline-item',

		"show_settings_on_create" => false,

		"js_view" => 'VcColumnView',

		'description' => 'Time line item container',

		"params" => array(

			array(

				'heading'			=> '',

				'type'				=> 'dpr_info',

				'param_name'		=> 'info_1',

				'title' => 'NOTE',

				'icon' => 'info',

				'text' => esc_html('This is only Time Line item shortcode container. Add content of this item inside here.'),

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

			),

			array(

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose item type.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Type', 'dpr-adeline-extensions'),

				'type'				=> 'dpr_image_select',

				'param_name'		=> 'type',

				'value' 			=> 'left',

				'options'			=> array(

					'left'			=> array(

						'label'		=> esc_html__('Left', 'dpr-adeline-extensions'),

						'src'		=> $module_images.'timeline/left.png'

					),

					'right'			=> array(

						'label'			=> esc_html__('Right', 'dpr-adeline-extensions'),

						'src'			=> $module_images.'timeline/right.png'

					),

					'center'			=> array(

						'label'			=> esc_html__('Center', 'dpr-adeline-extensions'),

						'src'			=> $module_images.'timeline/center.png'

					)

				),

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Additional Settings', 'dpr-adeline-extensions' ),

				'param_name'       => 'extra_features_title',

				'edit_field_class' => 'vc_column vc_col-sm-12',

			),

			vc_map_add_css_animation( false ),

		    array(

				'type' => 'textfield',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Extra Class Name', 'dpr-adeline-extensions'),

				'param_name' => 'el_class',

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Bubble Settings', 'dpr-adeline-extensions' ),

				'param_name'       => 'bubble_title',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group'				=> esc_html__('Bubble', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set item bubble background color. Default is #f1f2f4.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Bubble Background Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'bubble_bg_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'group'				=> esc_html__('Bubble', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set item bubble border color. Default is #eceff1.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Bubble Border Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'bubble_border_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'group'				=> esc_html__('Bubble', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set bubble border radius.Default is 5px.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Bubble Border Radius', 'dpr-adeline-extensions'),

				'param_name'		=> 'bubble_border_radius',

				'min'				=> 1,

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'group'				=> esc_html__('Bubble', 'dpr-adeline-extensions'),

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Node Settings', 'dpr-adeline-extensions' ),

				'param_name'       => 'node_title',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group'				=> esc_html__('Node', 'dpr-adeline-extensions'),

			),

			array(

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose node style.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Style', 'dpr-adeline-extensions'),

				'type'				=> 'dpr_image_select',

				'param_name'		=> 'node_style',

				'value' 			=> 'style-1',

				'options'			=> array(

					'style-1'			=> array(

						'label'		=> esc_html__('Style 1', 'dpr-adeline-extensions'),

						'src'		=> $module_images.'timeline/style-1.png'

					),

					'style-2'			=> array(

						'label'			=> esc_html__('Style 2', 'dpr-adeline-extensions'),

						'src'			=> $module_images.'timeline/style-2.png'

					),

					'style-3'			=> array(

						'label'			=> esc_html__('Style 3', 'dpr-adeline-extensions'),

						'src'			=> $module_images.'timeline/style-3.png'

					)

				),

				'group'				=> esc_html__('Node', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set time line node size.Default is 15 px', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Node Size', 'dpr-adeline-extensions'),

				'param_name'		=> 'node_size',

				'min'				=> 1,

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

				'group'				=> esc_html__('Node', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set time line node inner point size.Default is 5 px', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Node Inner Point Size', 'dpr-adeline-extensions'),

				'param_name'		=> 'node_inner_size',

				'min'				=> 1,

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

				'dependency'		=> array('element' => 'node_style', 'value' => 'style-2'),

				'group'				=> esc_html__('Node', 'dpr-adeline-extensions'),

			),

			array(

				'type'            	=> 'dpr_title',

				'class'				=> 'separator',

				'text'     	        => '',

				'param_name'  	    => 'node_sep_1',

				'edit_field_class' 	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_html__('Node', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set timeline node background color. Default is #fff.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Node Background Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'node_bg_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

				'group'				=> esc_html__('Node', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set timeline node border color. Default is #eceff1.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Node Border Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'node_border_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

				'group'				=> esc_html__('Node', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set timeline node inner point color. Default is #eceff1.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Node Inner Point Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'node_inner_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

				'dependency'		=> array('element' => 'node_style', 'value' => 'style-2'),

				'group'				=> esc_html__('Node', 'dpr-adeline-extensions'),

			),

			array(

				'type'            	=> 'dpr_title',

				'class'				=> 'separator',

				'text'     	        => '',

				'param_name'  	    => 'node_sep_2',

				'edit_field_class' 	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_html__('Node', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set time line node border width.Default is 1px', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Node Border Width', 'dpr-adeline-extensions'),

				'param_name'		=> 'node_border_width',

				'min'				=> 1,

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

				'group'				=> esc_html__('Node', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set time line node border radius.Default is  10px', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Node Border Radius', 'dpr-adeline-extensions'),

				'param_name'		=> 'node_border_radius',

				'min'				=> 1,

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

				'group'				=> esc_html__('Node', 'dpr-adeline-extensions'),

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Date Label Settings', 'dpr-adeline-extensions' ),

				'param_name'       => 'date_title',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group'				=> esc_html__('Date Label', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'textfield',

				'heading'			=> esc_html__('Date Text', 'dpr-adeline-extensions'),

				'param_name'		=> 'date_text',

				'value'				=> esc_html__('2018', 'dpr-adeline-extensions'),

				'group'				=> esc_html__('Date Label', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set timeline date label background color. Default is main acceent color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Date Label Background Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'date_bg_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'group'				=> esc_html__('Date Label', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set timeline date label border color. Default is main accent color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Date Label Border Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'date_border_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'group'				=> esc_html__('Date Label', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set time line date label border width.Default is 1px', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Date Label Border Width', 'dpr-adeline-extensions'),

				'param_name'		=> 'date_border_width',

				'min'				=> 1,

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'group'				=> esc_html__('Date Label', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set time line date label border radius.Default is  3px', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Date Label Border Radius', 'dpr-adeline-extensions'),

				'param_name'		=> 'date_border_radius',

				'min'				=> 1,

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'group'				=> esc_html__('Date Label', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Date Label Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'text_typography_head',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_html__('Date Label', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom ttle color. Default is #97a3b3.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'text_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Date Label', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size.Default is 12px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'text_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Date Label', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title linne height.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'text_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Date Label', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'text_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Date Label', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'text_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'group'				=> esc_html__('Date Label', 'dpr-adeline-extensions'),

	  		),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_google_fonts',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Date Label', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'text_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'dependency'		=> array('element' => 'use_google_fonts', 'value' => 'yes'),

				'group'				=> esc_html__('Date Label', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'css_editor',

				'heading' => __( 'CSS box', 'dpr-adeline-extensions' ),

				'param_name' => 'css',

				'group' => __( 'Design Options', 'dpr-adeline-extensions' ),

			),

		)

	) 

);









/*** Time Line Separator ***/

class WPBakeryShortCode_DPR_Time_Line_Sep extends WPBakeryShortCode {}



vc_map(

	array(

		'name'					=> esc_html__('Time Line Separator', 'dpr-adeline-extensions'),

		'base'					=> 'dpr_time_line_sep',

		"icon"					=> 'icon-dpr-timeline-sep',

		"class"					=> 'dpr_time_line_sep',

		"as_child" 				=> array('only' => 'dpr_time_line'),

  		"category" =>array( esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions')),

		'description'			=> esc_html__('Time Line Separator', 'dpr-adeline-extensions'),

		'params'				=> array(

			array(

				'type'				=> 'textfield',

				'heading'			=> esc_html__('Separator Text', 'dpr-adeline-extensions'),

				'param_name'		=> 'text',

				'value'				=> esc_html__('Separator Text', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set separator background color. Default is main acceent color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'bg_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set separator border color. Default is main accent color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'border_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set separator border width.Default is 1px', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border Width', 'dpr-adeline-extensions'),

				'param_name'		=> 'border_width',

				'min'				=> 1,

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set seprator border radius.Default is  3px', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border Radius', 'dpr-adeline-extensions'),

				'param_name'		=> 'border_radius',

				'min'				=> 1,

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

			),

		array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Additional Settings', 'dpr-adeline-extensions' ),

				'param_name'       => 'extra_features_title',

				'edit_field_class' => 'vc_column vc_col-sm-12',

			),

		    array(

				'type' => 'textfield',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Extra Class Name', 'dpr-adeline-extensions'),

				'param_name' => 'el_class',

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Text Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'text_typography_head',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'dependency'		=> array('element' => 'style', 'values' => 'text'),

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom ttle color. Default is #97a3b3.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'text_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'style', 'value' => 'text'),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size.Default is 12px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'text_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'style', 'value' => 'text'),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title linne height.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'text_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'style', 'value' => 'text'),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'text_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'dependency'		=> array('element' => 'style', 'value' => 'text'),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'text_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'dependency'		=> array('element' => 'style', 'value' => 'text'),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

	  		),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'use_google_fonts',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'dependency'		=> array('element' => 'style', 'value' => 'text'),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'text_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'dependency'		=> array('element' => 'use_google_fonts', 'value' => 'yes'),

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			

		),

	)

);

