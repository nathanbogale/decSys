<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
/*
Heading style
*/
$output .= $headline_html;
$output .= $separator_html;
$output .= $subtitle_html;