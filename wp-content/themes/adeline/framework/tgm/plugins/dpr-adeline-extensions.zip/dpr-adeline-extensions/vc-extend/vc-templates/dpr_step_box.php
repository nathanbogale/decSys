<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$unique_id = $style = $css_animation = $el_class = $css = $title = $subtitle = $output = $custom_el_css = $main_content = $read_more = $link = '';
$icon_type = $icon = $icon_class = $icon_image_id = $icon_size = $icon_color = $icon_hover = $icon_style = '';
$svg_id = $animation_type = $animation_duration = $svg_alignment = $draw_color = $svg_size = '';
$icon_text = $text_icon_use_google_fonts = $text_icon_custom_fonts = $text_icon_typo_style = $text_icon_color = $text_icon_font_size = $text_icon_line_height = $text_icon_letter_spacing = $text_icon__font_style = '';
$readmore_show = $icon_number = $icon_number_text = $number_color = $number_bg_color =  $link_target = '';
$title_typo_style = $title_color = $title_font_size = $title_line_height = $title_letter_spacing = $title_font_style = $use_google_fonts = $title_google_font = $title_html = '';
$subtitle_typo_style = $subtitle_color = $subtitle_font_size = $subtitle_line_height = $subtitle_letter_spacing = $subtitle_font_style = $subtitle_html = '';
$content_typo_style = $content_color = $content_font_size = $content_line_height = $content_letter_spacing = $content_font_style = $content_html = '';
$read_more_html = $title_wrap_html = '';
$icon_bg_size = $border_radius = $background_color = $badge_gradient = $use_gradient_bg = $use_gradient_bg_hover = $border_color = $border_width = $content_only_hover = $icon_size = $icon_html = '';
$hover_border_radius = $hover_background_color = $badge_gradient_hover = $hover_border_color = $use_gradient_color = $use_gradient_color_hover = '';
$last_item = $process_line_style = $process_line_thickness = $process_line_color = '';

$atts = vc_map_get_attributes( 'dpr_step_box', $atts );
extract( $atts );
wp_enqueue_script('dpr-step-box', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/dpr.step.box.js', array('jquery'), null, true);	

$unique_id = uniqid('dpr-step-box-').'-'.rand(1,9999);

$el_class .= ' '.esc_attr($style).' icon-pos-1';

if(isset($content_only_hover) && strcmp($content_only_hover, 'only_hover') == 0) {
	$el_class .= ' content-only-hover';
}
if(isset($readmore_show) && strcmp($readmore_show, 'show') == 0) {
	$el_class .= ' show-readmore';
}
$el_class .= ' text-center';
if(isset($last_item) && $last_item == 'yes') {
	$el_class .= ' last-item';
}
if ( '' !== $css_animation && 'none' !== $css_animation ) {
			wp_enqueue_script( 'vc_waypoints' );
			wp_enqueue_style( 'vc_animate-css' );
			$el_class .= ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
}

if(isset($number_color) && !empty($number_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .icon-wrapper .icon-box-icon-text {color: '.esc_js($number_color).' !important;}';
}
if(isset($number_bg_color) && !empty($number_bg_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .icon-wrapper .icon-box-icon-text {background: '.esc_js($number_bg_color).' !important;}';
}
if(isset($icon_bg_size) && !empty($icon_bg_size)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .icon-wrapper .module-icon {width: '.esc_js($icon_bg_size).'px !important; height: '.esc_js($icon_bg_size).'px !important; line-height: '.esc_js($icon_bg_size).'px !important;}';
	$custom_el_css .= '.'.esc_js($unique_id).'.style-badge.icon-pos-2.text-left .content-cell, .'.esc_js($unique_id).'.style-outlined.icon-pos-2.text-left .content-cell, .'.esc_js($unique_id).'.style-framed.icon-pos-2.text-left .content-cell {padding-left: '.esc_js($icon_bg_size + 20).'px !important;}';
	$custom_el_css .= '.'.esc_js($unique_id).'.style-badge.icon-pos-2.text-right .content-cell, .'.esc_js($unique_id).'.style-outlined.icon-pos-2.text-right .content-cell, .'.esc_js($unique_id).'.style-framed.icon-pos-2.text-right .content-cell {padding-right: '.esc_js($icon_bg_size + 20).'px !important;}';
}
if(isset($icon_size) && $icon_size != '') {
	$custom_el_css .= '.'.esc_js($unique_id).'.style-classic.icon-pos-2.text-left .content-cell {padding-left: '.esc_js($icon_size + 20).'px;}';
	$custom_el_css .= '.'.esc_js($unique_id).'.style-classic.icon-pos-2.text-right .content-cell {padding-right: '.esc_js($icon_size + 20).'px;}';
	$custom_el_css .= '.'.esc_js($unique_id).'.style-bgicon {min-height: '.esc_js($icon_size).'px;}';
	$custom_el_css .= '.'.esc_js($unique_id).'.style-classic.icon-pos-2 .module-icon, .'.esc_js($unique_id).'.style-classic.icon-pos-3 .module-icon {width: '.esc_js($icon_size).'px; height: '.esc_js($icon_size).'px;}';
}
if($icon_type == 'animated_svg' && isset($svg_size) && $svg_size != '') {
	$custom_el_css .= '.'.esc_js($unique_id).'.style-classic.icon-pos-2.text-left .content-cell {padding-left: '.esc_js($svg_size + 20).'px;}';
	$custom_el_css .= '.'.esc_js($unique_id).'.style-classic.icon-pos-2.text-right .content-cell {padding-right: '.esc_js($svg_size + 20).'px;}';
	$custom_el_css .= '.'.esc_js($unique_id).'.style-bgicon {min-height: '.esc_js($svg_size).'px;}';
	$custom_el_css .= '.'.esc_js($unique_id).'.style-classic.icon-pos-2 .module-icon, .'.esc_js($unique_id).'.style-classic.icon-pos-3 .module-icon {width: '.esc_js($svg_size).'px; height: '.esc_js($svg_size).'px;}';
}
if(isset($border_radius) && !empty($border_radius) || strcmp($border_radius, 0) === 0) {
	$custom_el_css .= '.'.esc_js($unique_id).' .icon-wrapper .module-icon {border-radius: '.esc_js($border_radius).'px;}';
}

if(isset($hover_border_radius) && $hover_border_radius != '') {
	$custom_el_css .= '.'.esc_js($unique_id).':hover .icon-wrapper .module-icon {border-radius: '.esc_js($hover_border_radius).'px;}';
}

if(isset($use_gradient_color) && !empty($use_gradient_color)) {
	if(isset($icon_gradient) && !empty($icon_gradient)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .icon-wrapper .module-icon i {'.esc_js(adeline_gradientToBgCSS ($icon_gradient)).';-webkit-background-clip: text;-webkit-text-fill-color: transparent;}';
	}
}

if(isset($icon_hover) && !empty($icon_hover)) {
	$custom_el_css .= '.'.esc_js($unique_id).':hover .icon-wrapper .module-icon i {color: '.esc_js($icon_hover).'!important;}';
}

if(isset($use_gradient_color_hover) && !empty($use_gradient_color_hover)) {
	if(isset($icon_gradient_hover) && !empty($icon_gradient_hover)) {
		$custom_el_css .= '.'.esc_js($unique_id).':hover .icon-wrapper .module-icon i {'.esc_js(adeline_gradientToBgCSS ($icon_gradient_hover)).';-webkit-background-clip: text;-webkit-text-fill-color: transparent;}';
	}
}


if(isset($background_color) && !empty($background_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).'.style-badge .icon-wrapper .module-icon, .'.esc_js($unique_id).'.style-framed .icon-wrapper .module-icon:after {background: '.esc_js($background_color).';}';
}

if(isset($use_gradient_bg) && !empty($use_gradient_bg)) {
	if(isset($badge_gradient) && !empty($badge_gradient)) {
		$custom_el_css .= '.'.esc_js($unique_id).'.style-badge .icon-wrapper .module-icon, .'.esc_js($unique_id).'.style-framed .icon-wrapper .module-icon:after {'.esc_js(adeline_gradientToBgCSS ($badge_gradient)).'}';
	}
}

if(isset($hover_background_color) && !empty($hover_background_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).'.style-badge:hover .icon-wrapper .module-icon, .'.esc_js($unique_id).'.style-framed:hover .icon-wrapper .module-icon:after {background: '.esc_js($hover_background_color).';}';
}

if(isset($use_gradient_bg_hover) && !empty($use_gradient_bg_hover)) {
	if(isset($badge_gradient_hover) && !empty($badge_gradient_hover)) {
		$custom_el_css .= '.'.esc_js($unique_id).'.style-badge:hover .icon-wrapper .module-icon, .'.esc_js($unique_id).'.style-framed:hover .icon-wrapper .module-icon:after {'.esc_js(adeline_gradientToBgCSS ($badge_gradient_hover)).'}';
	}
}

if(isset($border_color) && !empty($border_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .icon-wrapper .module-icon:before {border-color: '.esc_js($border_color).';}';
}
if(isset($hover_border_color) && !empty($hover_border_color)) {
	$custom_el_css .= '.'.esc_js($unique_id).':hover .icon-wrapper .module-icon:before {border-color: '.esc_js($hover_border_color).';}';
}
if(isset($border_width) && $border_width != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .icon-wrapper .module-icon:before {border-width: '.  esc_js($border_width).'px;}';
	$custom_el_css .= '.'.esc_js($unique_id).'.style-framed .icon-wrapper .module-icon:after {margin: '.esc_js($border_width + 5).'px;}';
}

if(isset($process_line_style) && $process_line_style != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .icon-wrapper .conector {border-bottom-style: '.  esc_js($process_line_style).' !important;}';
}
if(isset($process_line_thickness) && $process_line_thickness != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .icon-wrapper .conector {border-bottom-width: '.  esc_js($process_line_thickness).'px !important;}';
}
if(isset($process_line_color) && $process_line_color != '') {
	$custom_el_css .= '.'.esc_js($unique_id).' .icon-wrapper .conector {border-bottom-color: '.  esc_js($process_line_color).' !important;}';
}


/* HTML Parts */

if(!empty($title)) {
	$title_typo_style = dpr_generate_typography_style($title_color, $title_font_size, $title_line_height, $title_letter_spacing, $title_font_style,$title_google_font);
	if(isset($link) && strcmp($read_more, 'title') == 0) {
		$link = vc_build_link($link);
		$link_target = !empty($link['target']) ? 'target="'.esc_attr(preg_replace('/\s+/', '', $link['target'])).'"' : '';
		$title_html .= '<h4 class="icon-box-title " '.$title_typo_style.'><a href="'.esc_url($link['url']).'" title="'.esc_attr($link['title']).'" '.$link_target.' rel="'.esc_attr($link['rel']).'">'.wp_kses($title, array('span' => array(),'br' => array())).'</a></h4>';
	}else{
		$title_html .= '<h4 class="icon-box-title" '.$title_typo_style.'>'.wp_kses($title, array('span' => array(), 'br' => array())).'</h4>';
	}
}
if(!empty($subtitle)) {
	$subtitle_typo_style = dpr_generate_typography_style($subtitle_color, $subtitle_font_size, $subtitle_line_height, $subtitle_letter_spacing, $subtitle_font_style);
	$subtitle_html .= '<div class="icon-box-subtitle" '.$subtitle_typo_style.' >'.esc_html($subtitle).'</div>';
}

if(isset($title) &&!empty($title) || isset($subtitle) && !empty($subtitle)) {
	$title_wrap_html .= '<div class="title-wrap">';
		$title_wrap_html .= $title_html;
		$title_wrap_html .= $subtitle_html;
	$title_wrap_html .= '</div>';
}

$content_typo_style = dpr_generate_typography_style($content_color, $content_font_size, $content_line_height, $content_letter_spacing, $content_font_style);
$content_html .= '<div class="description" '.$content_typo_style.'>'.strip_tags($main_content,'<br><br/>').'</div>';

if(isset($icon_type) &&  $icon_type == 'icon' || $icon_type == 'custom' && !empty($icon_image_id) || $icon_type == 'animated_svg' && !empty($svg_id) || $icon_type == 'text' && !empty($icon_text)) {
	$icon_html = '<div class="icon-wrapper">';
		$icon_html .= '<div class="module-icon">';
			$icon_html .= '<div class="icon-container">';
			if ('icon' === $icon_type) {
				
				if ($icon != '') {
					
					if (!empty($icon_size) || !empty($icon_color)) {
				
						$icon_style .= 'style="';
		
						if ( ! empty( $icon_size ) ) {
							$icon_style .= 'font-size:' . $icon_size . 'px; ';
						}
		
						if ( ! empty( $icon_color ) ) {
							$icon_style .= 'color:' . $icon_color.'; ';
						}
		
						$icon_style .= '"';
						}
				
					$icon_html .= '<i class="featured-icon ' . $icon . '" ' . $icon_style . '></i>';
				
				}
			
			} elseif('custom' === $icon_type ) {
				$img_style = '';
				$image_url = dpr_get_attachment_image_src( $icon_image_id, 'full' );
				if (! empty( $icon_size )){
					
					$image_src = adeline_resize( $image_url[0], $icon_size, $icon_size, true, true, true );
					if(!$image_src) $image_src = $image_url[0];
				
				} else {
					
					$image_src = $image_url[0];
				
				}
				//$img_atts = adeline_image_attributes( $image_url[1], $image_url[2], $icon_size, $icon_size );
				if ( ! empty( $icon_size ) ) {
	
					$img_style .= 'style="';
	
					if ( isset( $icon_size ) && ! empty( $icon_size ) ) {
						$img_style .= 'width:' . esc_attr($icon_size) . 'px; ';
					}
	
					$img_style .= '"';
	
				}
				$alt_text = get_post_meta($icon_image_id , '_wp_attachment_image_alt', true);
				$icon_html .= '<img src="' . esc_url($image_src) . '"' . $img_style . '  alt ="'.esc_attr($alt_text).'"/>';
				
			}  elseif('animated_svg' === $icon_type ) {
				$svg_uid = uniqid('dpr-animated-svg-').'-'.rand(1,9999);
				wp_enqueue_script('dpr-animated-svg', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/dpr.animated.svg.js', array('jquery'), null, true);	
				$svg_attach = dpr_get_attachment_image_src( $svg_id,'full');
				$svg_url = $svg_attach[0];
				if($svg_url!=''){
					$icon_html .= '<div class="dpr-animated-svg" style="width:'.esc_attr($svg_size).'px;" data-id="'.esc_attr($svg_uid).'" data-type="'.esc_attr($animation_type).'" data-duration="'.esc_attr($animation_duration).'" data-stroke="'.esc_attr($draw_color).'" data-fill_color="none">';
						$icon_html .= '<div class="svg_inner_block" style="width:'.esc_attr($svg_size).'px;max-height:'.esc_attr($svg_size).'px;">';
							$icon_html .= '<object id="'.esc_attr($svg_uid).'" type="image/svg+xml" data="'.esc_url($svg_url).'" ></object>';
						$icon_html .= '</div>';
					$icon_html .= '</div>';
				}

				
			} elseif('text' === $icon_type ) {
				$text_icon_typo_style = dpr_generate_typography_style($text_icon_color, $text_icon_font_size, $text_icon_line_height, $text_icon_letter_spacing, $text_icon_font_style, $text_icon_custom_fonts);
				$icon_html .= '<span class="dpr-text-icon-wrap" '.$text_icon_typo_style.'>'.  esc_html($icon_text).'</span>';
			} 
				
			$icon_html .= '</div>';
			if(isset($icon_number) && strcmp($icon_number, 'yes') == 0 && isset($icon_number_text) && !empty($icon_number_text)) {
				$icon_html .= '<span class="icon-box-icon-text">'.esc_html($icon_number_text).'</span>';
				$el_class .= ' with-number';
			}
		$icon_html .='<div class="conector"></div>';
		$icon_html .= '</div>';
		
	$icon_html .= '</div>';
}else{
	$custom_el_css .= '.'.esc_js($unique_id).'.style-bgicon {padding-top: 0; min-height: initial;}';
}

// Readmore HTML output
$read_more_data = dpr_generate_read_more($atts);
$read_more_html .= $read_more_data[0];
$custom_el_css .= $read_more_data[1];

$css_classes = array(
	'dpr-featured-box dpr-step-box',
	$unique_id,
	$el_class,
	vc_shortcode_custom_css_class( $css ),
);

$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->settings['base'], $atts ) );


$output .= '<div id="'.esc_attr($unique_id).'" class="'.esc_attr($css_class).'">';
		$output .= '<div class="head-wrap">';
		$output .= $icon_html;
		$output .= $title_wrap_html;
		$output .= '</div>';
		if(isset($main_content) && !empty($main_content) || isset($readmore_show) && $readmore_show == 'show') {
			$output .= '<div class="container-info">';
				$output .= '<div class="content-cell">';
					$output .= $content_html;
					$output .= $read_more_html;
				$output .= '</div>';
			$output .= '</div>';
		}

	if(isset($link) && strcmp($read_more, 'box') == 0) {
		$link = vc_build_link( $link );
		$link_target = !empty($link['target']) ? 'target="'.esc_attr(preg_replace('/\s+/', '', $link['target'])).'"' : '';
		$output .= '<a href="'.esc_url($link['url']).'" class="dpr-cover-link" title="'.esc_attr($link['title']).'" '.$link_target.' rel="'.esc_attr($link['rel']).'"></a>';
	}
	
	if(!empty($custom_el_css)) {
		$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>");'
						. '})(jQuery);'
					. '</script>';
}

$output .= '</div>';

echo $output;