<?php

/**

 * Particle Shortcode Class

 *

 */



// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}



if ( ! class_exists( 'DPR_Particle_Shortcode' ) ) {



	class DPR_Particle_Shortcode {



		/**

		 * Start things up

		 */

		public function __construct() {

			add_shortcode( 'dpr_particle', array( $this, 'particle_shortcode' ) );

		}



		/**

		 * Registers the function as a shortcode

		 */

		public function particle_shortcode( $atts, $content = null ) {



			// Attributes

			$atts = shortcode_atts( array(

				'id' => '',

			), $atts, 'dpr_particle' );



			ob_start();

			

			if ( $atts[ 'id' ] ) {

			

			echo adeline_particle_content($atts[ 'id' ]);



			}

			

			return ob_get_clean();



		}



	}



}

new DPR_Particle_Shortcode();