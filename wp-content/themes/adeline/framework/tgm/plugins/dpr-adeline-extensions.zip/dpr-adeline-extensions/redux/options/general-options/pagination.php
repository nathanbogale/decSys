<?php

/**



 * General Options -> Pagination



 *



 */

Redux::setSection($opt_name, array(

    'title'      => esc_html__('Pagination', 'dpr-adeline-extensions'),

    'subsection' => true,

    'id'         => 'general_pagination',

    'fields'     => array(

        array(

            'id'      => 'pagination_align',

            'type'    => 'radio',

            'title'   => __('Alignment', 'dpr-adeline-extensions'),

            'options' => array(

                'left'   => 'Left',

                'center' => 'Center',

                'right'  => 'Right',

            ),

            'default' => 'center',

            'hint'    => array(

                'title'   => esc_attr__('Alignment', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set pagination alignment', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'      => 'pagination_shape',

            'type'    => 'radio',

            'title'   => __('Pagination Links Style', 'dpr-adeline-extensions'),

            'options' => array(

                'square' => 'Square',

                'round'  => 'Round',

            ),

            'default' => 'square',

            'hint'    => array(

                'title'   => esc_attr__('Pagination Links Style', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set pagination links shape', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'      => 'pagination_shadowed',

            'type'    => 'switch',

            'default' => true,

            'title'   => esc_html__('Use shadow?', 'dpr-adeline-extensions'),

            'hint'    => array(

                'title'   => esc_attr__('Use shadow', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enable or disable shadow for pagination links', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'      => 'pagination_size',

            'type'    => 'dimensions',

            'title'   => esc_html__('Size (px)', 'dpr-adeline-extensions'),

            'output'  => array('.page-numbers a, .page-numbers span, .page-links span, .page-numbers.current'),

            'width'   => true,

            'height'  => true,

            'mode'    => array('width' => 'width', 'height' => 'height'),

            'units'   => array('px'),

            'default' => array(

                'height' => '36px',

                'width'  => '36px',

            ),

            'hint'    => array(

                'title'   => esc_attr__('Button Size', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify scroll to top button size.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'             => 'pagination_font-size',

            'type'           => 'typography',

            'title'          => esc_html__('Font Size', 'dpr-adeline-extensions'),

            'output'         => array('.page-numbers a, .page-numbers span:not(.elementor-screen-only), .page-links span'),

            'google'         => false,

            'font-style'     => false,

            'font-weight'    => false,

            'subsets'        => false,

            'font-size'      => true,

            'font-family'    => false,

            'text-align'     => false,

            'line-height'    => true,

            'word-spacing'   => false,

            'letter-spacing' => false,

            'text-transform' => false,

            'color'          => false,

            'preview'        => false,

            'all_styles'     => false,

            'units'          => 'px',

            'default'        => array(

                'font-size'   => '13px',

                'line-height' => '36px',

            ),

            'hint'           => array(

                'title'   => esc_attr__('Font Size', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify font size and line height. Line height should be the same as pagination button height.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'pagination_background',

            'type'     => 'color',

            'output'   => array('background-color' => '.page-numbers a, .page-numbers span:not(.elementor-screen-only), .page-links span'),

            'validate' => 'color',

            'title'    => esc_html__('Background Color', 'dpr-adeline-extensions'),

            'default'  => '#f1f2f4',

            'hint'     => array(

                'title'   => esc_attr__('Background Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set background color for pagination link.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'pagination_background_hover',

            'type'     => 'color',

            'output'   => array('background-color' => '.page-numbers a:hover, .page-links a:hover span, .page-numbers span.current, .page-numbers span.current:hover '),

            'validate' => 'color',

            'title'    => esc_html__('Background Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'hint'     => array(

                'title'   => esc_attr__('Background Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set background color for pagination link hover and active state.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'pagination_color',

            'type'     => 'color',

            'output'   => array('color' => '.page-numbers a, .page-numbers span:not(.elementor-screen-only), .page-links span'),

            'validate' => 'color',

            'title'    => esc_html__('Color', 'dpr-adeline-extensions'),

            'default'  => '#c9c9ce ',

            'hint'     => array(

                'title'   => esc_attr__('Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set color for pagination link.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'pagination_color_hover',

            'type'     => 'color',

            'output'   => array('color' => '.page-numbers a:hover, .page-links a:hover span, .page-numbers span.current, .page-numbers span.current:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'hint'     => array(

                'title'   => esc_attr__('Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set color for pagination link hover and active state.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'      => 'pagination_border',

            'type'    => 'border',

            'title'   => __('Border', 'dpr-adeline-extensions'),

            'output'  => array('.page-numbers a, .page-numbers span:not(.elementor-screen-only), .page-links span'),

            'default' => array(

                'border-color'  => '#DFDFE4',

                'border-style'  => 'solid',

                'border-top'    => '1px',

                'border-right'  => '1px',

                'border-bottom' => '1px',

                'border-left'   => '1px',

            ),

            'hint'    => array(

                'title'   => esc_attr__('Border', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set border for pagination link.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'pagination_border_color_hover',

            'type'     => 'color',

            'output'   => array('border-color' => '.page-numbers a:hover, .page-links a:hover span, .page-numbers span.current, .page-numbers span.current:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Border Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'hint'     => array(

                'title'   => esc_attr__('Border Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set border color for pagination link hover and active state.', 'dpr-adeline-extensions'),

            ),

        ),

    ),

));
