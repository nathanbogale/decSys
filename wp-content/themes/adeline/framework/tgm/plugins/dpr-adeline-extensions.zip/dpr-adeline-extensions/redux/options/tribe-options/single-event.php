<?php



/**



 * Tribe Options -> Single Event Layout



 * 



 */







	Redux::setSection( $opt_name, array(



		'title' => esc_html__('Single Event Layout', 'dpr-adeline-extensions'),



		'id' => 'tribe_event_layout',



		'subsection' => true,



		'fields' => array(



						array (



							'id' => 'tribe_event_single_layout',



							'type' => 'image_select',



							'title' => __('General Layout', 'dpr-adeline-extensions'),



							'options' => array (



								'right-sidebar' => array (



									'title' => esc_html__('Sidebar right', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/sidebar_right.png'



								),					



								'left-sidebar' => array (



									'title' => esc_html__('Sidebar left', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/sidebar_left.png'



								),



								'both-sidebars' => array (



									'title' => esc_html__('Both sidebars', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/sidebar_both.png'



								),



	



								'full-width' => array (



									'title' => esc_html__('Full width', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/sidebar_disabled.png',	



								),



								'full-screen' => array (



									'title' => esc_html__('Full screen', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/full_screen.png',	



								),



							),



							'default' => 'right-sidebar',



							'hint' => array (



								'title' => esc_attr__('Single Event Layout', 'dpr-adeline-extensions'),



								'content' => esc_attr__('Choose default single event layoyt eg sidebar position.', 'dpr-adeline-extensions')



							)



						),



						array (



							'id' => 'tribe_event_single_both_sidebars_column_order',



							'type' => 'image_select',



							'title' => __('Both Sidebars: Column Order', 'dpr-adeline-extensions'),



							'options' => array (



								'order-scs' => array (



									'title' => esc_html__('Sidebar/Content/Sidebar', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/scs.png'



								),					



								'order-ssc' => array (



									'title' => esc_html__('Sidebar/Sidebar/Content', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/ssc.png'



								),



								'order-css' => array (



									'title' => esc_html__('Content/Sidebar/Sidebar', 'dpr-adeline-extensions'),



									'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/css.png'



								),



							),



							'default' => 'order-scs',



							'hint' => array (



								'title' => esc_attr__('Both Sidebars: Column Order', 'dpr-adeline-extensions'),



								'content' => esc_attr__('Choose default column order. This general settings can be overwriten for specific pages.', 'dpr-adeline-extensions')



							),



							'required' => array('tribe_event_single_layout','equals','both-sidebars')



						),



		)



	));



