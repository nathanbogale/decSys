<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
wp_enqueue_script( 'dpr_parralax_js', DPR_EXTENSIONS_PLUGIN_URL . 'vc-extend/assets/frontend/js/dpr.parallax.js', false, true);

$output ='';
$layer_data_atts = 'data-paroller-type = "foreground"';
$atts = vc_map_get_attributes( 'dpr_parallax_stack_layer', $atts );
extract( $atts );

	if ( $dpr_layer_parallax_type != 'none'  ) {
		$layer_data_atts .= ' data-paroller-direction="'.$dpr_layer_parallax_type.'"';
	}
	
	if ( $dpr_layer_parallax_fator != '' ) {
		$layer_data_atts .= ' data-paroller-factor="'.$dpr_layer_parallax_fator.'"';
	}





$output .= "<div class='dp-parallax-stack-layer paroller' ".$layer_data_atts.">";
$output .= "<div class='dp-parallax-stack-layer-inner'>";
$output .= do_shortcode($content);
$output .= "</div>";
$output .= "</div>";

echo $output;

