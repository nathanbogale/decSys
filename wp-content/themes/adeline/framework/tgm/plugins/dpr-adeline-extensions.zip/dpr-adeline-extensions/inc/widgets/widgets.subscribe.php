<?php

/**

 * Feedburner Signup Widget.

 *

 */



// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}



if ( ! class_exists( 'DPR_Subscribe_Widget' ) ) {

	class DPR_Subscribe_Widget extends WP_Widget {



		/**

		 * Register widget with WordPress.

		 *

		 * @since 1.0.0

		 */

		public function __construct() {

			parent::__construct(

				'dpr_subscribe',

				esc_html__( 'DPR Subscribe', 'dpr-adeline-extensions' ),

				array(

					'classname'   => 'widget-dpr-subscribe',

					'description' => esc_html__( 'Shows a Feedburner signup form.', 'dpr-adeline-extensions' ),

					'customize_selective_refresh' => true,

				)

			);



			$this->defaults = array(

				'title'      => esc_html__( 'Sign Up', 'dpr-adeline-extensions' ),

				'feed_name'     => '',

				'button_text'  => 'Sign Up',

				'placeholder_text'   => 'Enter Your Email',

				'pre_text'      => '',

				'after_text'      => '',

				'style'    => 'style-1',

				'border_radius' => '',

				'alignment' => '',

				'dark_bg' => '',

				'custom_class' => ''

			);

		}



		/**

		 * Front-end display of widget.

		 *

		 * @see WP_Widget::widget()

		 * @since 1.0.0

		 *

		 * @param array $args     Widget arguments.

		 * @param array $instance Saved values from database.

		 */

		public function widget( $args, $instance ) {



			// Parse instance

			extract( wp_parse_args( $instance, $this->defaults ) );



			// Apply filters to the title

			$title = isset( $instance['title'] ) ? apply_filters( 'widget_title', $instance['title'] ) : '';



			// Before widget WP hook

			echo $args['before_widget'];



				// Show widget title

				if ( $title ) {

					echo $args['before_title'] . esc_html( $title ) . $args['after_title'];

				} 



				if ( $pre_text ) {

					echo '<p>'. do_shortcode( $pre_text ) .'</p>';

				}

				

				$shortcode = '[dpr_subscribe';

				$shortcode .= ' btn_text="'.$button_text.'" ';

				$shortcode .= ' placeholder_text="'.$placeholder_text.'" ';

				if ($feed_name != '') {

				$shortcode .= ' feed_name="'.$feed_name.'" ';

				}

				$shortcode .= ' button_alignment="'.$alignment.'" ';

				if ($border_radius != '') {

				$shortcode .= ' border_radius="'.$border_radius.'" ';

				}

				$shortcode .= ' style="'.$style.'"';

				$shortcode .= ']';

				$classes = '';

				if ($dark_bg =='on') {

					$classes .= ' on-dark-bg';

				}

				if ($custom_class !='') {

					$classes .= ' '.$custom_class;

				}

				echo '<div class="dpr-widget-signup-form'.$classes.'">';

				echo do_shortcode( $shortcode );

				echo '</div>';

				if ( $after_text ) {

					echo '<p class="dpr-widget-signup-after">'. do_shortcode( $after_text ) .'</p>';

				}





			// After widget WP hook

			echo $args['after_widget'];



		}



		/**

		 * Sanitize widget form values as they are saved.

		 *

		 * @see WP_Widget::update()

		 * @since 1.0.0

		 *

		 * @param array $new_instance Values just sent to be saved.

		 * @param array $old_instance Previously saved values from database.

		 *

		 * @return array Updated safe values to be saved.

		 */

		public function update( $new_instance, $old_instance ) {

			$instance 				= $old_instance;

			$instance['title']      = ! empty( $new_instance['title'] ) ? strip_tags( $new_instance['title'] ) : '';

			$instance['feed_name']  = ! empty( $new_instance['feed_name'] ) ? strip_tags( $new_instance['feed_name'] ) : '';

			$instance['button_text']   = ! empty( $new_instance['button_text'] ) ? strip_tags( $new_instance['button_text'] ) : '';

			$instance['placeholder_text']      = ! empty( $new_instance['placeholder_text'] ) ? strip_tags( $new_instance['placeholder_text'] ) : '';

			$instance['pre_text']     = ! empty( $new_instance['pre_text'] ) ? strip_tags( $new_instance['pre_text'] ) : '';

			$instance['after_text']      = ! empty( $new_instance['after_text'] ) ? strip_tags( $new_instance['after_text'] ) : '';

			$instance['style']    = ! empty( $new_instance['style'] ) ? strip_tags( $new_instance['style'] ) : '';

			$instance['border_radius']    = ! empty( $new_instance['border_radius'] ) ? strip_tags( $new_instance['border_radius'] ) : '';

			$instance['alignment']    = ! empty( $new_instance['alignment'] ) ? strip_tags( $new_instance['alignment'] ) : '';

			$instance['dark_bg']    = ! empty( $new_instance['dark_bg'] ) ? strip_tags( $new_instance['dark_bg'] ) : '';

			$instance['custom_class']    = ! empty( $new_instance['custom_class'] ) ? strip_tags( $new_instance['custom_class'] ) : '';

			return $instance;

		}



		/**

		 * Back-end widget form.

		 *

		 * @see WP_Widget::form()

		 * @since 1.0.0

		 *

		 * @param array $instance Previously saved values from database.

		 */

		public function form( $instance ) {



			$instance = wp_parse_args( (array) $instance, $this->defaults );?>



			<p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title', 'dpr-adeline-extensions' ); ?></label> 

				<input class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['title'] ); ?>" />

			</p>



			<p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'feed_name' ) ); ?>"><?php esc_html_e( 'Feedburner name', 'dpr-adeline-extensions' ); ?></label> 

				<input class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'feed_name' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['feed_name'] ); ?>" />

                <br />

                <small><?php echo esc_html__('Setup guide', 'dpr-adeline-extensions') .' <a href="https://support.google.com/feedburner/answer/78978" target="_blank"> '.esc_html__('Adding FeedBurner Email', 'dpr-adeline-extensions').'</a>'; ?></small>

			</p>



			<p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'button_text' ) ); ?>"><?php esc_html_e( 'Button Text', 'dpr-adeline-extensions' ); ?></label>

				<input class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'button_text' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['button_text'] ); ?>" />

			</p>



			<p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'placeholder_text' ) ); ?>"><?php esc_html_e( 'Placeholder Text', 'dpr-adeline-extensions' ); ?></label>

				<input class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'placeholder_text' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['placeholder_text'] ); ?>" />

			</p>



			<p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'pre_text' ) ); ?>"><?php esc_html_e( 'Text Before', 'dpr-adeline-extensions' ); ?></label>

				<textarea rows="15" id="<?php echo esc_attr( $this->get_field_id( 'pre_text' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'pre_text' ) ); ?>" class="widefat" style="height: 100px;"><?php if( !empty( $instance['pre_text'] ) ) { echo esc_textarea( $instance['pre_text'] ); } ?></textarea>

			</p>



			<p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'after_text' ) ); ?>"><?php esc_html_e( 'Text After', 'dpr-adeline-extensions' ); ?></label>

				<textarea rows="15" id="<?php echo esc_attr( $this->get_field_id( 'after_text' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'after_text' ) ); ?>" class="widefat" style="height: 100px;"><?php if( !empty( $instance['after_text'] ) ) { echo esc_textarea( $instance['after_text'] ); } ?></textarea>

			</p>



			<div class="dpr-widget-inner-block">

				<h2><?php esc_html_e('Style Options:', 'dpr-adeline-extensions'); ?></h2>



			<p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'style' ) ); ?>"><?php esc_html_e( 'Style', 'dpr-adeline-extensions' ); ?></label>

				<select class='widefat' name="<?php echo $this->get_field_name( 'style' ); ?>" id="<?php echo $this->get_field_id( 'style' ); ?>">

					<option value="style-1" <?php if ( $instance['style'] == 'style-1') { ?>selected="selected"<?php } ?>><?php esc_html_e( 'Default', 'dpr-adeline-extensions' ); ?></option>

					<option value="style-2" <?php if ( $instance['style'] == 'style-2') { ?>selected="selected"<?php } ?>><?php esc_html_e( 'Inside', 'dpr-adeline-extensions' ); ?></option>

					<option value="style-3" <?php if ( $instance['style'] == 'style-3') { ?>selected="selected"<?php } ?>><?php esc_html_e( 'Outside', 'dpr-adeline-extensions' ); ?></option>

					<option value="style-4" <?php if ( $instance['style'] == 'style-4') { ?>selected="selected"<?php } ?>><?php esc_html_e( 'Minimal', 'dpr-adeline-extensions' ); ?></option>

					<option value="style-5" <?php if ( $instance['style'] == 'style-5') { ?>selected="selected"<?php } ?>><?php esc_html_e( 'Animated', 'dpr-adeline-extensions' ); ?></option>

				</select>

			</p>

			<p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'alignment' ) ); ?>"><?php esc_html_e( 'Button Alignment', 'dpr-adeline-extensions' ); ?></label>

				<select class='widefat' name="<?php echo $this->get_field_name( 'alignment' ); ?>" id="<?php echo $this->get_field_id( 'alignment' ); ?>">

					<option value="left-align" <?php if ( $instance['alignment'] == 'left-align') { ?>selected="selected"<?php } ?>><?php esc_html_e( 'Left', 'dpr-adeline-extensions' ); ?></option>

					<option value="center-align" <?php if ( $instance['alignment'] == 'center-align') { ?>selected="selected"<?php } ?>><?php esc_html_e( 'Center', 'dpr-adeline-extensions' ); ?></option>

					<option value="right-align" <?php if ( $instance['alignment'] == 'right-align') { ?>selected="selected"<?php } ?>><?php esc_html_e( 'Right', 'dpr-adeline-extensions' ); ?></option>

				</select>

                <br />

                <small><?php echo 'Only applies if you choose style <i>Animated</i>'; ?></small>

			</p>



			<p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'border_radius' ) ); ?>"><?php esc_html_e( 'Border radius (px)', 'dpr-adeline-extensions' ); ?></label> 

				<input class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'border_radius' ) ); ?>" type="number" min="0" step="1" value="<?php echo esc_attr( $instance['border_radius'] ); ?>" />

			</p>



            <p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'dark_bg' ) ); ?>">

					<input type="checkbox" name="<?php echo esc_attr( $this->get_field_name( 'dark_bg' ) ); ?>" id="<?php echo esc_attr( $this->get_field_id( 'dark_bg' ) ); ?>" <?php checked( $instance['dark_bg'] , 'on' ); ?> />

					<?php esc_html_e( 'On dark background style', 'dpr-adeline-extensions' ); ?>

				</label>

			</p>



			<p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'custom_class' ) ); ?>"><?php esc_html_e( 'Custom CSS Class', 'dpr-adeline-extensions' ); ?></label>

				<input class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'custom_class' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['custom_class'] ); ?>" />

			</p>



			</div>

		<?php



		}



	}

}