<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$output = $id = $images = $shuffle_direction = $el_class = $shuffle_direction = $appear_animation = $custom_el_css =  $css = '';

$atts = vc_map_get_attributes($this->getShortcode(), $atts);
extract( $atts );


	$id = uniqid('dpr-shuffled-images-');
  
    wp_enqueue_script('shuffled-images', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/dpr.shuffled.images.js', array('jquery'), null, true);
	wp_enqueue_script('dpr-waypoints', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/waypoints.min.js', array('jquery'), null, true);

	
	/* Element classes */

	if(isset($shuffle_direction) && !empty($shuffle_direction)) {
		$el_class .= ' dpr-items-shuffled-'.$shuffle_direction;
	} else {
		$el_class .= ' dpr-items-shuffled-left';
	}

	if($appear_animation == 'yes') {
		$el_class .= ' dpr-appear-animation';
	}

	$css_classes = array(
		'dpr-shuffled-images',
		esc_attr($id),
		$el_class,
		vc_shortcode_custom_css_class( $css ),
	);

	$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->settings['base'], $atts ) );

	// Custom CSS stuff
	
	/* Generate Output */

	if ( '' === $images ) {
	$images = '-1,-2,-3';
	}
	$images = explode( ',', $images );

	






	
	$output .= '<div id="'.esc_attr($id).'" class="'.esc_attr($css_class).'">';
	$output .= '<div class="animation-starter call-on-in-viewport"></div>';
	$output .= '<div class="dpr-si-inner">';
	// Generate shuffled images HTML
	foreach ( $images as $i => $image ) {
		if ( $image > 0 ) {
				$img = dpr_get_attachment_image_src( $image,'full');
				$large_img_src = $img[0];
				
			    $output .=  '<div class="dpr-si-item">';
				$output .=  '<div class="dpr-si-stack-item">';
				$output .=  '<img src="'.esc_url($large_img_src).'" alt="a">';
				$output .=  '</div>';
				$output .=  '</div>';
				
		}
	}

	$output .= '</div>';

	//Generate fake image HTML
	$last_image = end($images);
	if ( $last_image > 0 ) {
	$last_img = dpr_get_attachment_image_src( $last_image,'full');
	$last_img_src = $last_img[0];
	$output .=  '<div class="dpr-si-fake-item"><img src="'.esc_url($last_img_src).'" alt="a"></div>';
	}
    
	if($custom_el_css != '') {
			$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>")'
						. '})(jQuery);'
					. '</script>';
		}




	$output .= '</div>';

echo $output;