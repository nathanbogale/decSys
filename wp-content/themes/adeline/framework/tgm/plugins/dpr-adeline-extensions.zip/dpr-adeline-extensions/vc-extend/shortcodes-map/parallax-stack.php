<?php

// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}



/*** Parallax stack container ***/



  class WPBakeryShortCode_DPR_Parallax_Stack extends WPBakeryShortCodesContainer {

  }



vc_map( array(

  'name' =>  __( 'DP Parallax Stack', 'dpr-adeline-extensions' ),

  'base' => 'dpr_parallax_stack',

  'icon' => 'icon-dpr-parallax-stack',

  'as_parent' => array('only' => 'dpr_parallax_stack_layer'),

  'class' => 'dpr-split-slider',

  'content_element' => true,

  'show_settings_on_create' => false,

  'is_container' => true,

  "category" =>array( esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions')),

  "params" => array(

				array(

					'heading'			=> '',

					'type'				=> 'dpr_info',

					'param_name'		=> 'info_1',

					'title' => 'NOTE',

					'icon' => 'info',

					'text' => esc_html('This is only shortode container for Paralax Stack. Add Paralax Layers inside here.'),

					'edit_field_class'	=> 'vc_column vc_col-sm-12',

				),

		    array(

				'type' => 'textfield',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Extra Class Name', 'dpr-adeline-extensions'),

				'param_name' => 'el_class',

			),

),

  "js_view" => 'VcColumnView'

) );



/*** Parallax stack layer ***/



class WPBakeryShortCode_DPR_Parallax_Stack_Layer  extends WPBakeryShortCodesContainer {}

vc_map( 

	array(

		"name" =>  __( 'Parallax Stack Layer', 'dpr-adeline-extensions' ),

		"base" => "dpr_parallax_stack_layer",

		"as_parent" => array('except' => 'vc_accordion'),

		"as_child" => array('only' => 'dpr_parallax_stack'),

		"content_element" => true,

		"category" =>array( esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions')),

		"icon" => "icon-dpr-parallax-layer",

		"show_settings_on_create" => true,

		"js_view" => 'VcColumnView',

		'description' => 'Paralax stack layer',

		"params" => array(

                    array(

                        'type' => 'dpr_radio',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose Parallax Direction', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Layer Parallax Direction', 'dpr-adeline-extensions'),

                        'param_name' => 'dpr_layer_parallax_type',

						'value' => 'vertical',

						'std'	=> 'vertical',

						'options' => array(

							__('No Parallax', 'dpr-adeline-extensions') => 'none',

							__('Vertical', 'dpr-adeline-extensions') => 'vertical',

							__('Horizontal', 'dpr-adeline-extensions') => 'horizontal'

						)

                    ),

                    array(

                        'type' => 'number',

                        'param_name' => 'dpr_layer_parallax_fator',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('This attribute sets elements offset and speed. It can be positive (0.3) or negative (-0.3). Less means slower.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Layer Parallax Factor', 'dpr-adeline-extensions'),

						'value' => '0.3',

						'min'=>'-1',

						'max'=>'1',

						'step' => '0.01',

						'dependency'		=> array('element' => 'dpr_layer_parallax_type', 'value_not_equal_to' => 'none'),

                    ),

					array(

						'type' => 'css_editor',

						'heading' => __( 'CSS box', 'dpr-adeline-extensions' ),

						'param_name' => 'css',

						'group' => __( 'Design Options', 'dpr-adeline-extensions' ),

					),

		)

	) 

);

