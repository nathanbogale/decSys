<?php

/**



 * General Options -> Forms



 *



 */

Redux::setSection($opt_name, array(

    'title'      => esc_html__('Forms', 'dpr-adeline-extensions'),

    'id'         => 'general_forms',

    'subsection' => true,

    'fields'     => array(

        array(

            'id'       => 'form_label_color',

            'type'     => 'color',

            'output'   => array('color' => 'label'),

            'validate' => 'color',

            'title'    => esc_html__('Label Color', 'dpr-adeline-extensions'),

            'default'  => '#c9c9ce ',

            'hint'     => array(

                'title'   => esc_attr__('Label Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set label color for forms.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'             => 'form_input_padding',

            'type'           => 'spacing',

            'output'         => array('form input[type="text"],form input[type="password"],form input[type="email"],form input[type="tel"],form input[type="url"],form input[type="search"],form textarea, form select, .wpcf7-select'),

            'mode'           => 'padding',

            'units'          => array('px'),

            'display_units'  => true,

            'units_extended' => false,

            'title'          => __('Padding (px)', 'dpr-adeline-extensions'),

            'default'        => array(

                'padding-top'    => '6px',

                'padding-bottom' => '6px',

                'padding-left'   => '12px',

                'padding-right'  => '12px',

                'units'          => 'px',

            ),

            'hint'           => array(

                'title'   => esc_attr__('Padding', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Choose default padding for inputs fields.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'             => 'form_font-size',

            'type'           => 'typography',

            'title'          => esc_html__('Font', 'dpr-adeline-extensions'),

            'output'         => array('form input[type="text"],form input[type="password"],form input[type="email"],form input[type="tel"],form input[type="url"],form input[type="search"],form textarea, form select'),

            'google'         => false,

            'font-style'     => false,

            'font-weight'    => false,

            'subsets'        => false,

            'font-size'      => true,

            'font-family'    => false,

            'text-align'     => false,

            'line-height'    => true,

            'word-spacing'   => false,

            'letter-spacing' => false,

            'text-transform' => false,

            'color'          => true,

            'preview'        => false,

            'all_styles'     => false,

            'units'          => 'px',

            'default'        => array(

                'font-size'   => '16px',

                'line-height' => '36px',

                'color'       => '#555555',

            ),

            'hint'           => array(

                'title'   => esc_attr__('Font', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify font color, size and line height. Line height should be the same as pagination button height.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'form_background',

            'type'     => 'color',

            'output'   => array('background-color' => 'form input[type="text"],form input[type="password"],form input[type="email"],form input[type="tel"],form input[type="url"],form input[type="search"],form textarea'),

            'validate' => 'color',

            'title'    => esc_html__('Background Color', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'hint'     => array(

                'title'   => esc_attr__('Background Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set background color for inputs.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'      => 'form_border',

            'type'    => 'border',

            'title'   => __('Border Style', 'dpr-adeline-extensions'),

            'all'     => false,

            'output'  => array('form input[type="text"],form input[type="password"], form input[type="email"],form input[type="tel"],form input[type="url"],form input[type="search"], form textarea, form select, .select2-container .select2-choice'),

            'default' => array(

                'border-color'  => '#DFDFE4',

                'border-style'  => 'solid',

                'border-top'    => '1px',

                'border-right'  => '1px',

                'border-bottom' => '1px',

                'border-left'   => '1px',

            ),

            'hint'    => array(

                'title'   => esc_attr__('Border Style', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify border style for inputs.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'form_border_focus',

            'type'     => 'color',

            'output'   => array('border-color' => 'form input[type="text"]:focus,form input[type="password"]:focus,form input[type="email"]:focus,form input[type="tel"]:focus,form input[type="url"]:focus,form input[type="search"]:focus,form textarea:focus,form select:focus, .select2-drop-active,.select2-dropdown-open.select2-drop-above .select2-choice,.select2-dropdown-open.select2-drop-above .select2-choices,.select2-drop.select2-drop-above.select2-drop-active,.select2-container-active .select2-choice,.select2-container-active .select2-choices'),

            'validate' => 'color',

            'title'    => esc_html__('Border Color: Focus', 'dpr-adeline-extensions'),

            'default'  => '#c9c9ce',

            'hint'     => array(

                'title'   => esc_attr__('Border Color: Focus', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify border style for inputs focus state.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'             => 'form_border_radius',

            'type'           => 'dpr_border_radius',

            'units'          => array('px', '%'),

            'all'            => false,

            'output'         => array('form input[type="text"],form input[type="password"],form input[type="email"],form input[type="tel"],form input[type="url"],form input[type="search"],form textarea,form select, .wpcf7-select'),

            'units_extended' => false,

            'title'          => __('Border Radius', 'dpr-adeline-extensions'),

            'default'        => array(

                'border-top-left-radius'     => '5px',

                'border-top-right-radius'    => '5px',

                'border-bottom-right-radius' => '5px',

                'border-bottom-left-radius'  => '5px',

                'units'                      => 'px',

            ),

            'hint'           => array(

                'title'   => esc_attr__('Border Radius', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify border radius for inputs.', 'dpr-adeline-extensions'),

            ),

        ),

    ),

));
