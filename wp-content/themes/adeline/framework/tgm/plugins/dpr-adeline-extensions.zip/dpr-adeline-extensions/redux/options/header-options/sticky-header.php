<?php



/**



 * Header Options -> Sticky Menu



 * 



 */



	Redux::setSection( $opt_name, array(



		'title' => esc_html__('Sticky Header', 'dpr-adeline-extensions'),



		'id' => 'sticky_menu',



		'subsection' => true,



		'fields' => array(



						array(



						'id'       => 'sticky_heder_enable',



						'type'     => 'switch',



						'default' => false,



						'title'    => esc_html__('Use Sticky Header','dpr-adeline-extensions'),



						'hint' => array(



							'title'   => esc_attr__('Use Sticky Header','dpr-adeline-extensions'),



							'content' => esc_attr__('Enable or disable display sticky header usage','dpr-adeline-extensions')



							),



						),



						array(



							'id'   => 'sticky_menu_general_info',



							'type' => 'info',



							'style' => 'dpr-title',



							'required' =>	array('sticky_heder_enable','equals','1'),



							'title' => wp_kses_post(__('<h3>General Setting</h3>', 'dpr-adeline-extensions')),



						),



						array(



						'id'       => 'use_sticky_topbar',



						'type'     => 'switch',



						'default' => false,



						'title'    => esc_html__('Use Sticky Top Bar','dpr-adeline-extensions'),



						'required' =>	array('sticky_heder_enable','equals','1'),



						'hint' => array(



							'title'   => esc_attr__('Use Sticky Top Bar','dpr-adeline-extensions'),



							'content' => esc_attr__('Enable to display top bar in sticky header too','dpr-adeline-extensions')



							),



						),



						array(



						'id'       => 'use_sticky_mobile',



						'type'     => 'switch',



						'default' => false,



						'title'    => esc_html__('Use Sticky Mobile','dpr-adeline-extensions'),



						'required' =>	array('sticky_heder_enable','equals','1'),



						'hint' => array(



							'title'   => esc_attr__('Use Sticky Mobile','dpr-adeline-extensions'),



							'content' => esc_attr__('Enable to display top bar in sticky header too','dpr-adeline-extensions')



							),



						),



						array(



						'id'       => 'use_fullwidth_sticky_header',



						'type'     => 'switch',



						'default' => false,



						'title'    => esc_html__('Use Full Width Sticky Header','dpr-adeline-extensions'),



						'required' =>	array('sticky_heder_enable','equals','1'),



						'hint' => array(



							'title'   => esc_attr__('Use Full Width Sticky Header','dpr-adeline-extensions'),



							'content' => esc_attr__('Enable full width sticky header','dpr-adeline-extensions')



							),



						),



						array(



						'id'       => 'disable_sticky_header_shadow',



						'type'     => 'switch',



						'default' => false,



						'title'    => esc_html__('Disable Sticky Header Shadow','dpr-adeline-extensions'),



						'required' =>	array('sticky_heder_enable','equals','1'),



						'hint' => array(



							'title'   => esc_attr__('Disable Sticky Header Shadow','dpr-adeline-extensions'),



							'content' => esc_attr__('Disable bottom shadow for sticky header','dpr-adeline-extensions')



							),



						),



						array(



							'id'       => 'sticky_header_style',



							'type'     => 'radio',



							'title'    => __('Sticky Header Style', 'dpr-adeline-extensions'), 



							'required' =>	array('sticky_heder_enable','equals','1'),



							'options'  => array(



								'fixed' => 'Fixed', 



								'shrink' => 'Shrinked'



							),



							'default' => 'fixed',



							'hint' => array(



								'title'   => esc_attr__('Sticky Header Style','dpr-adeline-extensions'),



								'content' => esc_attr__('Shrinked style allow set smaller as default sticky header and resize some header elements. Fixed style leaves sticky header of the same size as default header.','dpr-adeline-extensions')



							),



						),



						array(



							'id'       => 'shrink_header_height',



							'type'     => 'dimensions',



							'units'    => array('px'),



							'mode' => array ('height' => 'height', 'width' => 'width'),



							'width' => false,



							'output' => array('.is-sticky #dpr-header.shrink-header #dpr-logo #dpr-logo-inner, .is-sticky #dpr-header.shrink-header .dpr-adeline-social-menu .social-menu-inner, .is-sticky #dpr-header.shrink-header.full_screen-header .menu-bar-inner, .is-sticky #dpr-header.shrink-header.minimal-header .menu-bar-inner'),



							'title'    => __('Shrinked Sticky Header Height', 'dpr-adeline-extensions'),



							'default'  => array(



								'height'  => '70px'



							),



							'hint' => array(



								'title'   => esc_attr__('Shrinked Sticky Header Height','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Set sticky header height when shrinked style used.','dpr-adeline-extensions')



							),



							'required' => array('sticky_header_style','equals','shrink')



						),



/* Logo settings stuff */



						array(



							'id'   => 'sticky_menu_logo_info',



							'type' => 'info',



							'style' => 'dpr-title',



							'required' =>	array('sticky_heder_enable','equals','1'),



							'title' => wp_kses_post(__('<h3>Logo</h3>', 'dpr-adeline-extensions')),



						),



						array(



							'id' => 'logo_sticky',



							'type' => 'media',



							'title' => esc_html__('Logo Sticky', 'dpr-adeline-extensions'),



							'required' =>	array('sticky_heder_enable','equals','1'),



							'default' => array(),



							'hint' => array(



								'title'   => esc_attr__('Logo Sticky','dpr-adeline-extensions'),



								'content' => esc_attr__('Select logo image for sticky header. Is optional, if you leave it blank will be used default logo in sticky header too.','dpr-adeline-extensions')



							),



						),



						array(



							'id' => 'logo_sticky_retina',



							'type' => 'media',



							'title' => esc_html__('Logo Sticky Retina', 'dpr-adeline-extensions'),



							'required' =>	array('sticky_heder_enable','equals','1'),



							'default' => array(),



							'hint' => array(



								'title'   => esc_attr__('Logo Sticky Retina','dpr-adeline-extensions'),



								'content' => esc_attr__('Select retina logo image for sticky header. Is optional, if you leave it blank will be used default logo in sticky header too.','dpr-adeline-extensions')



							),



						),



						array(



							'id'       => 'shrink_header_logo_height',



							'type'     => 'dimensions',



							'units'    => array('px'),



							'mode' => array ('height' => 'height', 'width' => 'width'),



							'width' => false,



							'output' => '',



							'title'    => __('Shrinked  Sticky Header Logo Height', 'dpr-adeline-extensions'),



							'default'  => array(



								'height'  => '50px'



							),



							'hint' => array(



								'title'   => esc_attr__('Shrinked  Sticky Header Logo Height','dpr-adeline-extensions'),



								'content' =>  esc_attr__('Set logo height when shrinked style used.','dpr-adeline-extensions')



							),



							'required' => array('sticky_header_style','equals','shrink')



						),



/* Sticky header styling*/ 						



						array(



							'id'   => 'sticky_menu_styling_info',



							'type' => 'info',



							'style' => 'dpr-title',



							'title' => wp_kses_post(__('<h3>Menu Style</h3>', 'dpr-adeline-extensions')),



							'required' =>	array('sticky_heder_enable','equals','1'),



						),



						array(



							'id' => 'sticky_header_background',



							'type' => 'color',



							'output' => array('background-color' => '.is-sticky #dpr-header, .is-sticky #searchform-header-replace'),



							'validate' => 'color',



							'title' => esc_html__('Sticky Header Background', 'dpr-adeline-extensions'),



							'required' =>	array('sticky_heder_enable','equals','1'),



							'default' => '#ffffff',



							'hint' => array(



								'title'   => esc_attr__('Sticky Header Background','dpr-adeline-extensions'),



								'content' => esc_attr__('Set sticky header background color.','dpr-adeline-extensions')



							)



						),



						array(



							'id' => 'sticky_header_link_color',



							'type' => 'color',



							'output' => array('.is-sticky  #dpr-header  #dpr-navigation-wrapper .dropdown-menu > li > a,.is-sticky #dpr-adeline-mobile-menu-icon a,.is-sticky #searchform-header-replace-close'),



							'validate' => 'color',



							'title' => esc_html__('Sticky Header Link Color', 'dpr-adeline-extensions'),



							'required' =>	array('sticky_heder_enable','equals','1'),



							'default' => '#292933',



							'hint' => array(



								'title'   => esc_attr__('Sticky Header Link Color','dpr-adeline-extensions'),



								'content' => esc_attr__('Set sticky header link color.','dpr-adeline-extensions')



							)



						),



						array(



							'id' => 'sticky_header_link_color_hover',



							'type' => 'color',



							'output' => array('.is-sticky  #dpr-header  #dpr-navigation-wrapper .dropdown-menu > li > a:hover,.is-sticky #dpr-adeline-mobile-menu-icon a:hover,.is-sticky #searchform-header-replace-close:hover'),



							'validate' => 'color',



							'title' => esc_html__('Sticky Header Link Color: Hover', 'dpr-adeline-extensions'),



							'required' =>	array('sticky_heder_enable','equals','1'),



							'default' => '#D3AE5F',



							'hint' => array(



								'title'   => esc_attr__('Sticky Header Link Color: Hover','dpr-adeline-extensions'),



								'content' => esc_attr__('Set sticky header link hover color.','dpr-adeline-extensions')



							)



						),



						array(



							'id' => 'sticky_header_link_color_current',



							'type' => 'color',



							'output' => array('.is-sticky #dpr-navigation-wrapper .dropdown-menu > .current-menu-item > a,.is-sticky #dpr-navigation-wrapper .dropdown-menu > .current-menu-parent > a > span,.is-sticky #dpr-navigation-wrapper .dropdown-menu > .current-menu-item > a:hover,.is-sticky #dpr-navigation-wrapper .dropdown-menu > .current-menu-parent > a:hover > span'),



							'validate' => 'color',



							'title' => esc_html__('Sticky Header Link Color: Current', 'dpr-adeline-extensions'),



							'required' =>	array('sticky_heder_enable','equals','1'),



							'default' => '#D3AE5F',



							'hint' => array(



								'title'   => esc_attr__('Sticky Header Link Color: Current','dpr-adeline-extensions'),



								'content' => esc_attr__('Set sticky header current link color.','dpr-adeline-extensions')



							)



						),



					)



	));



