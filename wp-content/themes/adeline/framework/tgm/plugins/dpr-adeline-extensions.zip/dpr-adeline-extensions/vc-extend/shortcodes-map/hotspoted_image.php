<?php

// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}



/*

* Add-on Name: Hotspot

*/

class WPBakeryShortCode_DPR_Hotspot extends WPBakeryShortCode {}



vc_map(

	array(

	   'name' => esc_html__('DP Hotspoted Image','dpr-adeline-extensions'),

	   'base' => 'dpr_hotspot',

	   'class' => '',

	   'icon'	=> 'icon-dpr-hotspot',

	   'admin_enqueue_js' => array(DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/admin/js/jquery.hotspot.js'),

	   'admin_enqueue_css' => array(DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/admin/css/hotspot.css' ),

  	   "category" =>array( esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions')),

	   'description' => esc_html__('Display single image with markers and tooltips','dpr-adeline-extensions'),

	   'params' => array(

			array(

				'type'				=> 'attach_image',

				'param_name'		=> 'image',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select image from media library', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Image', 'dpr-adeline-extensions'),

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

			),

			array(

				'type'				=> 'dpr_hotspot_param',

				'heading'			=> '',

				'param_name'		=> 'hotspot_data',

				'edit_field_class'	=> 'vc_column vc_col-sm-12'

			),

			array(

				'type'				=> 'dropdown',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Define the action at which the hotspot tooltip will be displayed on.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Tooltips display', 'dpr-adeline-extensions'),

				'param_name'		=> 'hotspot_action',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'default'				=> 'hover',

				'value'			=> array(

					esc_html__('Allways','dpr-adeline-extensions')		=> 'allways',

					esc_html__('On Hover','dpr-adeline-extensions')	=> 'hover',

					esc_html__('On Click','dpr-adeline-extensions')	=> 'click',

				),

			),

			vc_map_add_css_animation(),

			array(

				'type'				=> 'textfield',

				'heading'			=> esc_html__('Custom CSS Class', 'dpr-adeline-extensions'),

				'param_name'		=> 'el_class',

			),

			array(

				'type'				=> 'dropdown',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select marker style. You can leave default style or upload your own image.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Marker style', 'dpr-adeline-extensions'),

				'param_name'		=> 'marker_style',

				'default'				=> 'default',

				'value'			=> array(

					esc_html__('Default', 'dpr-adeline-extensions')			=> 'default',

					esc_html__('Image', 'dpr-adeline-extensions')			=> 'image',

				),

				'group'				=> esc_html__('Markers settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'param_name'		=> 'marker_bg',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Change the background of hotspot markers.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Marker background', 'dpr-adeline-extensions'),

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'value'				=> '#D3AE5F',

				'dependency'		=> array('element' => 'marker_style', 'value_not_equal_to' => 'image'),

				'group'				=> esc_html__('Markers settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'param_name'		=> 'marker_inner_bg',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Change the background of the hotspot marker inner dot', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Marker inner background', 'dpr-adeline-extensions'),

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'value'				=> '#ffffff',

				'dependency'		=> array('element' => 'marker_style', 'value_not_equal_to' => 'image'),

				'group'				=> esc_html__('Markers settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'attach_image',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the image to use as marker.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Image', 'dpr-adeline-extensions'),

				'param_name'		=> 'marker_image',

				'dependency'		=> array('element' => 'marker_style', 'value' => 'image'),

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_html__('Markers settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dropdown',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select the tooltip position relative to the marker.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Tooltip position', 'dpr-adeline-extensions'),

				'param_name'		=> 'tooltip_position',

				'default'				=> 'top',

				'value'			=> array(

					esc_html__('Top', 'dpr-adeline-extensions')			=> 'top',

					esc_html__('Bottom', 'dpr-adeline-extensions')			=> 'bottom',

					esc_html__('Left', 'dpr-adeline-extensions')			=> 'left',

					esc_html__('Right', 'dpr-adeline-extensions')			=> 'right',

					esc_html__('Top Left', 'dpr-adeline-extensions')		=> 'top-left',

					esc_html__('Top Right', 'dpr-adeline-extensions')		=> 'top-right',

					esc_html__('Bottom Left', 'dpr-adeline-extensions')	=> 'bottom-left',

					esc_html__('Bottom Right', 'dpr-adeline-extensions')	=> 'bottom-right',

				),

				'group'				=> esc_html__('Tooltips settings', 'dpr-adeline-extensions'),

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

			),

			array(

				'type'				=> 'dropdown',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set the tooltip text alignment.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Tooltip content alignment', 'dpr-adeline-extensions'),

				'param_name'		=> 'tooltip_content_align',

				'default'				=> 'left',

				'value'			=> array(

					esc_html__('Left', 'dpr-adeline-extensions')			=> 'left',

					esc_html__('Right', 'dpr-adeline-extensions')			=> 'right',

					esc_html__('Center', 'dpr-adeline-extensions')			=> 'center',

				),

				'group'				=> esc_html__('Tooltips settings', 'dpr-adeline-extensions'),

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set the minimal width of item tooltip.', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Tooltip min width', 'dpr-adeline-extensions'),

				'param_name'		=> 'tooltip_width',

				'value'				=> 300,

				'suffix'            => 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Tooltips settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'param_name'		=> 'tooltip_bg_color',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the color for the tooltip\'s background. The default value is #fff.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Tooltip Background Color', 'dpr-adeline-extensions'),

				'default'			=> '#fff',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Tooltips settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'param_name'		=> 'tooltip_text_color',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the color for the tooltip\'s text. The default value is #555.', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Tooltip Text Color', 'dpr-adeline-extensions'),

				'default'			=> '#555',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Tooltips settings', 'dpr-adeline-extensions'),

			)

		),

	)

);