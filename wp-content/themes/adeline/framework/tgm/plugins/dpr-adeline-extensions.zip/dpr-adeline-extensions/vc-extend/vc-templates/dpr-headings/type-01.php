<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
/*
Heading Type 01
*/
$output .= $headline_html;
$output .= $subtitle_html;
$output .= $separator_html;