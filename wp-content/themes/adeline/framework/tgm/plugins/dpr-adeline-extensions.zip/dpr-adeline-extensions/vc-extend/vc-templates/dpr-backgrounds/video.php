<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$video_atts = $poster_url = '';
$uniqid = uniqid('dpr-bg-wrapper');


if(isset($dpr_video_type) && !empty($dpr_video_type)) {
	$output .= '<div class="dpr_row_bg_container">';
	if(isset($dpr_video_poster) && !empty($dpr_video_poster)) {
		$poster_src = dpr_get_attachment_image_src($dpr_video_poster,'full');
		$poster_url = $poster_src[0];
	} 
	// Hosted Video
	if($dpr_video_type == 'hosted' && (isset($dpr_mp4_url) || isset($dpr_webm_url))) {
		
		$video_atts .= 'poster="'. $poster_url .'"';
		if(isset($dpr_video_options) && !empty($dpr_video_options)) {
			if(substr_count($dpr_video_options, 'loop') == 1) {
				$video_atts .= ' loop="true" ';
			}
			if(substr_count($dpr_video_options, 'muted') == 1) {
				$video_atts .= ' muted="true" ';
			}
		}
		$output .= '<div class="dpr_row_bg_container_inner dpr-video-bg" id="wrapper-'.esc_attr($uniqid).'">';
		$output .= '<video id="'.esc_attr($uniqid).'" class="video-js vjs-default-skin" 
			   preload="auto"
			   width="100%"
			   height="100%"
			   autoplay="autoplay"
			   '.$video_atts.'
			   data-setup="{}" data-keepplaying>';

			if (!empty($dpr_mp4_url)):
				$output .= '<source src="'.esc_url($dpr_mp4_url).'" type="video/mp4">';
			endif;
			if (!empty($dpr_webm_url)):
				$output .= '<source src="'.esc_url($dpr_webm_url).'" type="video/webm">';
			endif;
		$output .= '</video>';

		$output .= '</div>';
	} elseif($dpr_video_type == 'youtube' || $dpr_video_type == 'vimeo') {
	// Youtube and Vimeo videos	
		$loop = false;
		if(isset($dpr_video_options) && !empty($dpr_video_options)) {
			if(substr_count($dpr_video_options, 'loop') == 1) {
				$loop = true;
			}
			if(substr_count($dpr_video_options, 'muted') == 1) {
				$muted = true;
			}
		} 
	// Youtube video	
		if($dpr_video_type == 'youtube' && isset($dpr_youtube_id) && !empty($dpr_youtube_id)) {
			$extra_url_part = '';
			if(substr_count($dpr_youtube_id, '?') > 0) {
				$dpr_youtube_id = substr($dpr_youtube_id,(stripos($dpr_youtube_id,'?v=')+3));
			}
			if(substr_count($dpr_youtube_id, '&') > 0) {
				$dpr_youtube_id = substr($dpr_youtube_id, 0, stripos($dpr_youtube_id,'&'));
			}
			if ($loop) {
				$extra_url_part .= '&amp;loop=1&amp;playlist='.$dpr_youtube_id;
			}
			if ($muted) {
				$extra_url_part .= '&amp;mute=1';
			}
			if (!empty($dpr_video_start_time)){
				$extra_url_part .= '&amp;start='.$dpr_video_start_time;
			}
			if (!empty($dpr_video_stop_time)) {
				$extra_url_part .= '&amp;end='.$dpr_video_stop_time;
			}
			$output .= '<div id="wrapper-'.esc_attr($uniqid).'" class="dpr_row_bg_container_inner dpr-video-bg">
							<div class="video-iframe-wrapper"><iframe id="'.esc_attr($uniqid).'" width="100%" height="100%" src="https://www.youtube.com/embed/'.esc_attr($dpr_youtube_id).'?wmode=opaque'.esc_attr($extra_url_part).'&amp;autoplay=1&amp;enablejsapi=1&amp;showinfo=0&amp;controls=0&amp;rel=0" frameborder="0" class="dpr-bg-frame" allowfullscreen></iframe></div>
						</div>';
		}
	// Vimeo video
		if($dpr_video_type == 'vimeo' && isset($dpr_vimeo_id) && !empty($dpr_vimeo_id)) {
			add_action( 'wp_enqueue_scripts', 'dpr_enqueue_vimeo_api_js' );
			if(substr_count($dpr_vimeo_id, 'vimeo.com/') > 0) {
				$dpr_vimeo_id = substr($dpr_vimeo_id,(stripos($dpr_vimeo_id, 'vimeo.com/')+10));
			}
			if(substr_count($dpr_vimeo_id, '&') > 0) {
				$dpr_vimeo_id = substr($dpr_vimeo_id, 0, stripos($dpr_vimeo_id,'&'));
			}

			$output .= '<div id="wrapper-'.esc_attr($uniqid).'" class="dpr_row_bg_container_inner dpr-video-bg">
							<div class="video-iframe-wrapper"><iframe id="'.esc_attr($uniqid).'" src="https://player.vimeo.com/video/'.esc_attr($dpr_vimeo_id).'?background=1&amp;api=1&amp;portrait=0&amp;rel=0" width="100%" height="100%" frameborder="0" class="dpr-bg-frame"></iframe></div>
						</div>';
		}

	}
	$output .= $overlay_output;
	
	if($poster_url != '') {
		$custom_el_css .= '#wrapper-'.esc_js($uniqid).' {background-image: url(\"'.esc_js($poster_url).'\");}';
	}	
	$output .= '</div>';
}
