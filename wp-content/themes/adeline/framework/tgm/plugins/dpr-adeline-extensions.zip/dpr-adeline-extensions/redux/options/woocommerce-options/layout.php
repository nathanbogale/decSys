<?php

/**



 * Woocoommerce Options -> Woo Pages Layout



 *



 */

Redux::setSection($opt_name, array(

    'title'      => esc_html__('Woocommerce Pages Layout', 'dpr-adeline-extensions'),

    'id'         => 'woocommerce_layout',

    'subsection' => true,

    'fields'     => array(

        array(

            'id'    => 'woo_subheader_info',

            'type'  => 'info',

            'style' => 'dpr-title',

            'title' => wp_kses_post(__('<h3>Subheader</h3>', 'dpr-adeline-extensions')),

        ),

        array(

            'id'      => 'woo_subheader_display',

            'type'    => 'switch',

            'default' => true,

            'title'   => esc_html__('Display Subheader', 'dpr-adeline-extensions'),

            'hint'    => array(

                'title'   => esc_attr__('Display Subheader', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enable or disable display subheader area on woo pages.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo_subheader_visibility',

            'type'     => 'image_select',

            'title'    => __('Visibility', 'dpr-adeline-extensions'),

            'options'  => array(

                'all-devices'        => array(

                    'title' => esc_html__('All Devices', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/visibility/all.png',

                ),

                'hide-tablet'        => array(

                    'title' => esc_html__('Hide On Tablet', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/visibility/no_tablet.png',

                ),

                'hide-mobile'        => array(

                    'title' => esc_html__('Hide On Mobile', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/visibility/no_mobile.png',

                ),

                'hide-tablet-mobile' => array(

                    'title' => esc_html__('Hide On Tablet & Mobile', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/visibility/no_tablet_mobile.png',

                ),

            ),

            'default'  => 'all-devices',

            'hint'     => array(

                'title'   => esc_attr__('Visibility', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enable or disable display subheader area  on woo pages on certain devices.', 'dpr-adeline-extensions'),

            ),

            'required' => array('woo_subheader_display', 'equals', '1'),

        ),

        array(

            'id'       => 'woo_subheader_alignment',

            'type'     => 'select',

            'title'    => esc_html__('Alignment', 'dpr-adeline-extensions'),

            'desc'     => '',

            'options'  => array(

                'lefted'   => esc_html__('Left', 'dpr-adeline-extensions'),

                'centered' => esc_html__('Centered', 'dpr-adeline-extensions'),

            ),

            'default'  => 'centered',

            'hint'     => array(

                'title'   => esc_attr__('Alignment', 'dpr-adeline-extensions'),

                'content' => esc_attr__('You can use default left alignment or center subheader content on woo pages.', 'dpr-adeline-extensions'),

            ),

            'required' => array('woo_subheader_display', 'equals', '1'),

        ),

        array(

            'id'       => 'woo_subheader_height',

            'type'     => 'dimensions',

            'units'    => array('px'),

            'mode'     => array('width' => 'width', 'height' => 'height'),

            'width'    => false,

            'output'   => array('.woocommerce-page .subheader'),

            'title'    => __('Subheader Height', 'dpr-adeline-extensions'),

            'default'  => array(

                'Height' => '230px',

            ),

            'hint'     => array(

                'title'   => esc_attr__('Subheader Height', 'dpr-adeline-extensions'),

                'content' => esc_attr__('You can set subheader height  on woo pages.', 'dpr-adeline-extensions'),

            ),

            'required' => array('woo_subheader_display', 'equals', '1'),

        ),

        array(

            'id'             => 'woo_subheader_padding',

            'type'           => 'spacing',

            'output'         => array('.woocommerce-page .subheader'),

            'mode'           => 'padding',

            'units'          => array('px', 'em'),

            'left'           => false,

            'right'          => false,

            'display_units'  => true,

            'units_extended' => false,

            'title'          => __('Vertical Padding', 'dpr-adeline-extensions'),

            'default'        => array(

                'padding-top'    => '0px',

                'padding-bottom' => '0px',

                'units'          => 'px',

            ),

            'hint'           => array(

                'title'   => esc_attr__('Vertical Padding', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Using padding you can adjust vertical position of title in subheader area  on woo pages', 'dpr-adeline-extensions'),

            ),

            'required'       => array('woo_subheader_display', 'equals', '1'),

        ),

        array(

            'id'       => 'woo_subheader_bg',

            'type'     => 'background',

            'title'    => __('Background', 'dpr-adeline-extensions'),

            'default'  => array(

                'background-color' => '#424251',

            ),

            'output'   => array('.woocommerce-page .subheader'),

            'hint'     => array(

                'title'   => esc_attr__('Background', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set background for subheader area subheader area on woo pages', 'dpr-adeline-extensions'),

            ),

            'required' => array('woo_subheader_display', 'equals', '1'),

        ),

        array(

            'id'       => 'woo_subheader_overlay',

            'type'     => 'switch',

            'default'  => false,

            'title'    => esc_html__('Use Subheader Overlay', 'dpr-adeline-extensions'),

            'hint'     => array(

                'title'   => esc_attr__('Use Subheader Overlay', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enable overlay layer over subheader background on woo pages.', 'dpr-adeline-extensions'),

            ),

            'required' => array('woo_subheader_display', 'equals', '1'),

        ),

        array(

            'id'       => 'woo_subheader_overlay_bg_color',

            'type'     => 'color',

            'title'    => __('Overlay Color', 'dpr-adeline-extensions'),

            'default'  => '',

            'output'   => array('background-color' => '.woocommerce-page .subheader-overlay'),

            'hint'     => array(

                'title'   => esc_attr__('Overlay Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set background color for subheader overlay on woo pages.', 'dpr-adeline-extensions'),

            ),

            'required' => array('woo_subheader_overlay', 'equals', '1'),

        ),

        array(

            'id'       => 'woo_subheader_title_color',

            'type'     => 'color',

            'title'    => __('Title Color', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'output'   => array('.woocommerce-page .subheader-title'),

            'hint'     => array(

                'title'   => esc_attr__('Title Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set title color on woo pages.', 'dpr-adeline-extensions'),

            ),

            'required' => array('woo_subheader_display', 'equals', '1'),

        ),

        array(

            'id'       => 'woo_subheader_subtitle_color',

            'type'     => 'color',

            'title'    => __('Subtitle Color', 'dpr-adeline-extensions'),

            'default'  => 'rgba(255,2555,255,0.8)',

            'output'   => array('.woocommerce-page .subheader-subtitle'),

            'hint'     => array(

                'title'   => esc_attr__('Subtitle Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set subtitle color on woo pages.', 'dpr-adeline-extensions'),

            ),

            'required' => array('woo_subheader_display', 'equals', '1'),

        ),

        array(

            'id'    => 'woo_breadcrumb_info',

            'type'  => 'info',

            'style' => 'dpr-title',

            'title' => wp_kses_post(__('<h3>Breadcrumb</h3>', 'dpr-adeline-extensions')),

        ),

        array(

            'id'      => 'woo_breadcrumb_display',

            'type'    => 'switch',

            'default' => true,

            'title'   => esc_html__('Display Breadcrumb', 'dpr-adeline-extensions'),

            'hint'    => array(

                'title'   => esc_attr__('Display Breadcrumb', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enable or disable display breadcrumb in subheader area on woo pages.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'woo-breadcrumb_color',

            'type'     => 'color',

            'title'    => __('Breadcrumb Color', 'dpr-adeline-extensions'),

            'default'  => '#292933',

            'output'   => array('.woocommerce-page .dpr-adeline-breadcrumbs'),

            'hint'     => array(

                'title'   => esc_attr__('Breadcrumb Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set breadcrumb color on woo pages.', 'dpr-adeline-extensions'),

            ),

            'required' => array('breadcrumb_display', 'equals', '1'),

        ),

        array(

            'id'       => 'woo_breadcrumb_separator_color',

            'type'     => 'color',

            'title'    => __('Breadcrumb Separators Color', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'output'   => array('.woocommerce-page .dpr-adeline-breadcrumbs ul li:after'),

            'hint'     => array(

                'title'   => esc_attr__('Breadcrumb Separators Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set breadcrumb separators color on woo pages.', 'dpr-adeline-extensions'),

            ),

            'required' => array('breadcrumb_display', 'equals', '1'),

        ),

        array(

            'id'       => 'woo-breadcrumb_link_color',

            'type'     => 'color',

            'title'    => __('Breadcrumb Links Color', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'output'   => array('.woocommerce-page .dpr-adeline-breadcrumbs a'),

            'hint'     => array(

                'title'   => esc_attr__('Breadcrumb Links Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set breadcrumb links color on woo pages.', 'dpr-adeline-extensions'),

            ),

            'required' => array('breadcrumb_display', 'equals', '1'),

        ),

        array(

            'id'       => 'woo_breadcrumb_link_color_hover',

            'type'     => 'color',

            'title'    => __('Breadcrumb Links Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'output'   => array('.woocommerce-page .dpr-adeline-breadcrumbs a:hover'),

            'hint'     => array(

                'title'   => esc_attr__('Breadcrumb Links Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set breadcrumb hover links color on woo pages.', 'dpr-adeline-extensions'),

            ),

            'required' => array('breadcrumb_display', 'equals', '1'),

        ),

        array(

            'id'    => 'woo_sidebar_info',

            'type'  => 'info',

            'style' => 'dpr-title',

            'title' => wp_kses_post(__('<h3>Sidebar</h3>', 'dpr-adeline-extensions')),

        ),

        array(

            'id'      => 'woocommerce_custom_sidebar',

            'type'    => 'switch',

            'default' => false,

            'title'   => esc_html__('Use Woocommerce Custom Sidebar', 'dpr-adeline-extensions'),

            'hint'    => array(

                'title'   => esc_attr__('Use Woocommerce Custom Sidebar', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enable custom sidebar for Woocommerce pages.', 'dpr-adeline-extensions'),

            ),

        ),

    ),

));
