<?php



/**



 * General Options -> Scroll to top



 * 



 */







	Redux::setSection( $opt_name, array(



		'title' => esc_html__('Scroll To Top', 'dpr-adeline-extensions'),



		'id' => 'general_scroll_to_top',



		'subsection' => true,



		'fields' => array(



					array(



						'id'       => 'scroll_top',



						'type'     => 'switch',



						'default' => true,



						'title'    =>  esc_html__('Display Scroll To Top Button','dpr-adeline-extensions')



					),



					array (



						'id' => 'scroll_top_arrow',



						'type' => 'image_select',



						'title' => __('Arrow Icon', 'dpr-adeline-extensions'),



						'options' => array (



							'' => array (



								'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/to-top/no-icon.png'



							),



							'dpr-icon-angle-up' => array (



								'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/to-top/angle-up.png'



							),



							'dpr-icon-angle-double-up' => array (



								'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/to-top/angle-double-up.png'



							),



							'dpr-icon-caret-up' => 	array (



								'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/to-top/caret-up.png'



							),



							'dpr-icon-chevron-up' => array (



								'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/to-top/chevron-up.png'



							),



							'dpr-icon-long-arrow-up' => array (



								'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/to-top/long-arrow-up.png'



							),				



						),



						'default' => 'dpr-icon-angle-up',



						'hint' => array (



							'title' => esc_attr__('Arrow Icon', 'dpr-adeline-extensions'),



							'content' => esc_attr__('Choose icon for scroll to top button.', 'dpr-adeline-extensions')



						),



						'required' => array('scroll_top','equals','1')



					),



					array(



					'id' => 'scroll_top_size',



					'type' => 'dimensions',



					'title' => esc_html__('Button Size (px)', 'dpr-adeline-extensions'),



					'output' => array('#scroll-top'),



					'width' => true,



					'height' => true,



					'mode' => array ('width' => 'width', 'height' => 'height'),



					'units' => array('px'),



					'default'  => array(



						'width' => '50px',



						'height' => '50px'



					),



					'hint' => array(



						'title'   => esc_attr__('Button Size','dpr-adeline-extensions'),



						'content' => esc_attr__('Specify scroll to top button size.','dpr-adeline-extensions')



					),



					'required' => array('scroll_top','equals','1')



					),



					array(



						'id'          => 'scroll_top_font-size',



						'type'        => 'typography',



						'title'       => esc_html__( 'Arrow Size', 'dpr-adeline-extensions' ),



						'output' => array('#scroll-top'),



						'google'      => false,



						'font-style'    => false,



						'font-weight'=> false,



						'subsets'       => false, 



						'font-size'     => true,



						'font-family' => false,



						'text-align'	=> false,



						'line-height'   => true,



						'word-spacing'  => false,



						'letter-spacing'=> false, 



						'text-transform'=> false,



						'color'         => false,



						'preview'       => false,



						'all_styles'  => false,



						'units'       => 'px',



						'default'     => array(



							'font-size'   => '18px',



							'line-height' => '50px'



						),



						'hint' => array(



							'title'   => esc_attr__('Arrow Size', 'dpr-adeline-extensions'),



							'content' => esc_attr__( 'Specify arrow font size and line height. Line height should be the same as button height.', 'dpr-adeline-extensions')



						),



						'required' => array('scroll_top','equals','1')



					),



					array(



						'id'             => 'scroll_top_radius',



						'type'           => 'dpr_border_radius',



						'units' 		 => array('px','%'),



						'all' => true,



						'output' => array('#scroll-top'),



						'units_extended' => false,



						'title'          => __('Border Radius', 'dpr-adeline-extensions'),



						'default'            => array(



							'border-top-left-radius'     => '50%', 



							'border-top-right-radius'   => '50%', 



							'border-bottom-right-radius'  => '50%', 



							'border-bottom-left-radius'    => '50%',



							'units'          => '%', 



						),



						'hint' => array(



							'title'   => esc_attr__('Border Radius', 'dpr-adeline-extensions'),



							'content' => esc_attr__( 'Specify border radius for scroll to top button.', 'dpr-adeline-extensions')



						),



						'required' => array('scroll_top','equals','1')



					),



					array(



						'id' => 'scroll_top_background_color',



						'type' => 'color',



						'output' => array('background-color' => '#scroll-top'),



						'validate' => 'color',



						'title' => esc_html__('Background Color', 'dpr-adeline-extensions'),



						'default' => 'rgba(0,0,0,0.4)',



						'hint' => array(



							'title'   => esc_attr__('Background Color','dpr-adeline-extensions'),



							'content' => esc_attr__('Set scroll to top button background color.','dpr-adeline-extensions')



						),



						'required' => array('scroll_top','equals','1')



					),



					array(



						'id' => 'scroll_top_background_color_hover',



						'type' => 'color',



						'output' => array('background-color' => '#scroll-top:hover'),



						'validate' => 'color',



						'title' => esc_html__('Background Color: Hover', 'dpr-adeline-extensions'),



						'default' => 'rgba(0,0,0,0.8)',



						'hint' => array(



							'title'   => esc_attr__('Background Color: Hover','dpr-adeline-extensions'),



							'content' => esc_attr__('Set scroll to top button hover state background color.','dpr-adeline-extensions')



						),



						'required' => array('scroll_top','equals','1')



					),



					array(



						'id' => 'scroll_top_color',



						'type' => 'color',



						'output' => array('color' => '#scroll-top'),



						'validate' => 'color',



						'title' => esc_html__('Arrow Color', 'dpr-adeline-extensions'),



						'default' => '#ffffff',



						'hint' => array(



							'title'   => esc_attr__('Arrow Color','dpr-adeline-extensions'),



							'content' => esc_attr__('Set scroll to top button arrow color.','dpr-adeline-extensions')



						),



						'required' => array('scroll_top','equals','1')



					),



					array(



						'id' => 'scroll_top_color_hover',



						'type' => 'color',



						'output' => array('color' => '#scroll-top:hover'),



						'validate' => 'color',



						'title' => esc_html__('Arrow Color: Hover', 'dpr-adeline-extensions'),



						'default' => '#ffffff',



						'hint' => array(



							'title'   => esc_attr__('Arrow Color: Hover','dpr-adeline-extensions'),



							'content' => esc_attr__('Set scroll to top button hover state arrow color.','dpr-adeline-extensions')



						),



						'required' => array('scroll_top','equals','1')



					),



		)



	));