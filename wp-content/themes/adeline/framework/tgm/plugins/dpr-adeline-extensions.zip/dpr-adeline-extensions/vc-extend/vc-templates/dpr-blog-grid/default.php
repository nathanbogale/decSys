<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
/*
Default Style Blog Grid Shortcode Item
*/
if ($display_category_badge == 'yes') {
	$category = get_the_category(); 
	if( $category[0]->cat_name !='') {
	?>
	<span class="category-badge"><a href="<?php echo esc_url( get_category_link( $category[0]->term_id ) ) ?>"><?php echo $category[0]->cat_name; ?></a></span>
    <?php
	}
}

// Custom quote format template
if ( 'quote' == $format ) {
	// Get quote item content
	//get_template_part( 'template-parts/blog/quote' );
	$quote_html = '';
	$quote_text = adeline_get_meta_value (get_the_ID(), 'quote_post_quote_text', '');
	$quote_author = adeline_get_meta_value (get_the_ID(), 'quote_post_quote_author', '');
	$quote_link = adeline_get_meta_value (get_the_ID(), 'quote_post_quote_link', '');
	
	//If custom quote
	if ($quote_text != '') {
		$quote_html = '<blockquote>';
		$quote_html .= $quote_text;
			if($quote_author != '') {
				$quote_html .= '<cite>';
				if($quote_link != '') {
					$quote_html .= '<a href="'.$quote_link.'">';
				}
				$quote_html .= $quote_author;
				if($quote_link != '') {
					$quote_html .= '</a>';
				}
				$quote_html .= '</cite>';
			}
		$quote_html .= '</blockquote>';
	} else {
		$quote_html = apply_filters( 'the_content', get_the_content());
	}
	?>
        <div class="post-quote-content">
            <?php echo wp_kses_post($quote_html); ?>
            <span class="post-quote-icon dpr-icon-right-quotation-sign"></span>
        </div>
        <a href="<?php the_permalink(); ?>">	
        <div class="post-quote-author"><?php the_title(); ?></div>
        </a>
    <?php
	return;

}

// Custom link format template
if ( 'link' == $format ) {

//Generate link html
$link_html = '';
$link_text = adeline_get_meta_value (get_the_ID(), 'link_post_link_text', '');
$link_target = adeline_get_meta_value (get_the_ID(), 'link_post_link_target', '');
$link_url = adeline_get_meta_value (get_the_ID(), 'link_post_link_url', '');

	//If custom link
	if ($link_url != '') {
		$link_html = '<a href="'.$link_url.'" target="'.$link_target.'">';
		$link_html .= $link_text;
		$link_html .= '</a>';
	} else {
		$link_html = apply_filters( 'the_content', get_the_content());
	} ?>
	<div class="post-link-content">
		<?php echo wp_kses_post($link_html); ?>
		<span class="post-link-icon dpr-icon-paperclip"></span>
	</div>
    <a href="<?php the_permalink(); ?>">	
    <div class="post-link-author"><?php the_title(); ?></div>
    </a>
    <?php
	return;

}
if ($display_media == 'yes') {
get_template_part( 'template-parts/blog/media/post', $format ); 
}?>
<div class="content <?php echo esc_attr($conent_alignment) ?>">
<?php if ($display_title == 'yes') { ?>
<header class="blog-item-header clr">
	<h2 class="blog-item-title entry-title" <?php echo $title_typo_style ?>>
		<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" rel="bookmark"><?php the_title(); ?></a>
	</h2><!-- blog-item-title -->
</header><!-- blog-item-header -->
<?php }

// Get meta sections
$sections = explode(',', $meta_included);
// Return if sections are empty
if ( empty( $sections ) ) {
	return;
}

if ( 'post' == get_post_type() ) { ?>


	<ul class="meta clr ">

		<?php
		// Loop through meta sections
		foreach ( $sections as $section ) { ?>

			<?php if ( 'author' == $section ) { ?>
				<li class="meta-author"<?php adeline_schema_markup( 'author_name' ); ?>><?php echo the_author_posts_link(); ?></li>
			<?php } ?>

			<?php if ( 'date' == $section ) { ?>
				<li class="meta-date"<?php adeline_schema_markup( 'publish_date' ); ?>><?php echo get_the_date(); ?></li>
			<?php } ?>

			<?php if ( 'category' == $section ) { ?>
				<li class="meta-cat"><?php the_category( ' , ', get_the_ID() ); ?></li>
			<?php } ?>

			<?php if ( 'comments' == $section && comments_open() && ! post_password_required() ) { ?>
				<li class="meta-comments"><?php comments_popup_link( esc_html__( '0 Comments', 'dpr-adeline-extensions' ), esc_html__( '1 Comment',  'dpr-adeline-extensions' ), esc_html__( '% Comments', 'dpr-adeline-extensions' ), 'comments-link' ); ?></li>
			<?php } ?>

		<?php } ?>
		
	</ul>

	
<?php } 

if ( 'video' != $format && 'audio' != $format && $display_excerpt == 'yes') {
?>	
<p <?php echo $content_typo_style ?>>
<?php  adeline_excerpt( absint(  $excerpt_length  ) ); ?>
</p>
<?php
} ?>
</div>