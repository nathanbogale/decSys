var $j = jQuery.noConflict();



$j( document ).on( 'ready', function() {

	"use strict";

	// Custom select

	dprHideMetaboxes();

	dprRemoveMenuIcon()

	

} );



/* ==============================================

METABOXES STUFF

============================================== */

function dprHideMetaboxes() {

	"use strict"

	

	var templateSelect = $j('#page_template');

	var template = templateSelect.find('option:selected').val();

	

	if (template == 'page-templates/vc-page.php') {

	dprHideOnVcPage();

	}

	

	templateSelect.change(function () {

	var template = templateSelect.find('option:selected').val();

	if (template == 'page-templates/vc-page.php') {

	dprHideOnVcPage();

	} else {

	$j('#dpr_adeline-page_content_layout').closest( "tr" ).show();

	$j('#dpr_adeline-page_both_sidebars_column_order').closest( "tr" ).not(".hide").show();

	$j('#dpr_adeline-page_padding').closest( "tr" ).show();

	}

	})



}



function dprHideOnVcPage() {

	$j('#dpr_adeline-page_content_layout').closest( "tr" ).hide();

	$j('#dpr_adeline-page_both_sidebars_column_order').closest( "tr" ).not(".hide").hide();

	$j('#dpr_adeline-page_padding').closest( "tr" ).hide();

}



/* ==============================================

MENU EDIT STUFF

============================================== */



function dprRemoveMenuIcon() {

	"use strict"

		$j( '.remove-icon' ).on( 'click', function() {

			var PreviewToRemove = $j('#'+$j(this).attr('data-preview'));

			var FieldToRemove = $j('#'+$j(this).attr('data-field'));

			FieldToRemove.val('');

			PreviewToRemove.html('');

			

		} );



}

