<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$el_class = $el_id = $width = $parallax_speed_bg = $parallax_speed_video = $parallax = $parallax_image = $video_bg_url = $video_bg_parallax = $css = $offset = $css_animation = '';
$bg_style = $dpr_bg_type = $dpr_column_gradient = $column_shadow = $column_bg_color_hover = $column_border_color_hover = $column_border_style_hover = $column_border_radius_hover = $column_shadow_hover = $dpr_enable_responsive_options = $responsive_css_panel = $dpr_enable_sticky_column = '';
$custom_el_css = $overlay_output = $output = '';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );
$unique_class = uniqid('uniq-');

if ( '' !== $css_animation && 'none' !== $css_animation ) {
			wp_enqueue_script( 'vc_waypoints' );
			wp_enqueue_style( 'vc_animate-css' );
			$el_class .= ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
}

wp_enqueue_script( 'wpb_composer_front_js' );

$width = wpb_translateColumnWidthToSpan( $width );
$width = vc_column_offset_class_merge( $offset, $width );

$css_classes = array(
	$this->getExtraClass( $el_class ) . $this->getCSSAnimation( $css_animation ),
	'wpb_column',
	'vc_column_container',
	$width,
);
$css_classes[] = $unique_class;

if ( vc_shortcode_custom_css_has_property( $css, array(
		'border',
		'background',
	) ) || $dpr_bg_type == 'video' || $dpr_bg_type == 'parallax-image' || $parallax != ''
) {
	$css_classes[] = 'vc_col-has-fill';
}

$wrapper_attributes = array();

if  ($bg_style == 'dark') {
	$css_classes[] = ' dpr-dark-background';
}

$parallax_speed = $parallax_speed_bg;
if ( $dpr_bg_type == 'video' ) {
	$parallax = $video_bg_parallax;
	$parallax_speed = $parallax_speed_video;
	$parallax_image = $video_bg_url;
	$css_classes[] = 'vc_video-bg-container';
	wp_enqueue_script( 'vc_youtube_iframe_api_js' );
}

if (  $dpr_bg_type == 'parallax-image' && $parallax != '' ) {
	wp_enqueue_script( 'vc_jquery_skrollr_js' );
	$wrapper_attributes[] = 'data-vc-parallax="' . esc_attr( $parallax_speed ) . '"'; // parallax speed
	$css_classes[] = 'vc_general vc_parallax vc_parallax-' . $parallax;
	if ($parallax == 'content-moving-fade' ) {
		$css_classes[] = 'js-vc_parallax-o-fade';
		$wrapper_attributes[] = 'data-vc-parallax-o-fade="on"';
	} elseif ( $parallax == 'content-moving' ) {
		$css_classes[] = 'js-vc_parallax-o-fixed';
	}
}

if($dpr_enable_sticky_column == 'yes') {
	wp_enqueue_script('resize-sensor', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/ResizeSensor.js', array('jquery'), null, true);
	wp_enqueue_script('sticky-sidebar', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/sticky-sidebar.js', array('jquery'), null, true);
	wp_enqueue_script('dpr-sticky-column', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/dpr.sticky.column.js', array('jquery'), null, true);
	$css_classes[] = 'dpr-sticky-column';
} 

if ( $dpr_bg_type == 'parallax-image' && $parallax_image != ''  ) {
		$parallax_image_id = preg_replace( '/[^\d]/', '', $parallax_image );
		$parallax_image_src = dpr_get_attachment_image_src( $parallax_image_id, 'full' );
		if ( ! empty( $parallax_image_src[0] ) ) {
			$parallax_image_src = $parallax_image_src[0];
	}
	$wrapper_attributes[] = 'data-vc-parallax-image="' . esc_attr( $parallax_image_src ) . '"';
}
if ( $dpr_bg_type == 'video' ) {
	$wrapper_attributes[] = 'data-vc-video-bg="' . esc_attr( $video_bg_url ) . '"';
}

// Add custom CSS rules

if (dpr_shadow_param_to_css($column_shadow) != '') {
	$custom_el_css .= '.'.$unique_class.' {'.dpr_shadow_param_to_css($column_shadow).'}';
}

if ( $column_bg_color_hover != '' || $column_border_color_hover != '' || $column_border_style_hover != '' || $column_border_radius_hover != '' || dpr_shadow_param_to_css($column_shadow_hover) != '') {
	$css_classes[] = 'has-hover-css';
	$custom_el_css .= '.'.$unique_class.' .vc_column-inner:hover {';
		if ( $column_bg_color_hover != '') {
			$custom_el_css .= 'background-color:'.$column_bg_color_hover.'!important;';
		}
		if ( $column_border_color_hover != '') {
			$custom_el_css .= 'border-color:'.$column_border_color_hover.'!important;';
		}
		if ( $column_border_style_hover != '') {
			$custom_el_css .= 'border-style:'.$column_border_style_hover.'!important;';
		}
		if ( $column_border_radius_hover != '') {
			$custom_el_css .= 'border-radius:'.$column_border_radius_hover.'px!important;';
		}
		if (dpr_shadow_param_to_css($column_shadow_hover) != '') {
			$custom_el_css .= dpr_shadow_param_to_css($column_shadow_hover).';';
		}
	$custom_el_css .= '}';
}

// Add responsive CSS
$responsive_unique_class = '';
if($dpr_enable_responsive_options && isset($responsive_css_panel) && $responsive_css_panel != '') {
	
	$responsive_unique_class = uniqid('vc-column-responsive-');
	$css_classes[] .= $responsive_unique_class;
	$custom_el_css .= DPR_Responsive_CSS::generate_css($responsive_css_panel, '.'.esc_attr( trim( vc_shortcode_custom_css_class( $css ) ) ));

}

// Prepare Gradient Overlay Output
if($dpr_bg_type == 'gradient') {
	
	
	if( isset($dpr_column_gradient) && !empty($dpr_column_gradient)) {
		
		$overlay_output .= '<div class="dpr-row-bg-overlay" style="'.esc_attr(adeline_gradientToBgCSS ($dpr_column_gradient)).';"></div>';
	
	}

}


$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( $css_classes ) ), $this->settings['base'], $atts ) );
$wrapper_attributes[] = 'class="' . esc_attr( trim( $css_class ) ) . '"';
if ( ! empty( $el_id ) ) {
	$wrapper_attributes[] = 'id="' . esc_attr( $el_id ) . '"';
}
//$output .= $dpr_enable_sticky_column;

$output .= '<div ' . implode( ' ', $wrapper_attributes ) . '>';

$output .= '<div class="vc_column-inner ' . esc_attr( trim( vc_shortcode_custom_css_class( $css ) ) ) . ' '.$responsive_unique_class.'">';

$output .= '<div class="dpr_row_bg_container" style="z-index:-1">';
$output .= $overlay_output;
$output .= '</div>';

$output .= '<div class="wpb_wrapper">';
$output .= wpb_js_remove_wpautop( $content );
$output .= '</div>';
$output .= '</div>';

if($custom_el_css != '') {
	$output .= '<script>'
				. '(function($) {'
					. '$("head").append("<style>'.$custom_el_css.'</style>")'
				. '})(jQuery);'
			. '</script>';
}

$output .= '</div>';

echo $output;
