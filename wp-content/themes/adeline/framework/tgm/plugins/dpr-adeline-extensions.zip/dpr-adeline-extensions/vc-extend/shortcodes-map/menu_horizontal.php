<?php

// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}

/*

* Add-on Name: Countdown

*/



class WPBakeryShortCode_DPR_Menu_Horizontal extends WPBakeryShortCode {}



$custom_menus = array();

if ( 'vc_edit_form' === vc_post_param( 'action' ) && vc_verify_admin_nonce() ) {

	$menus = get_terms( 'nav_menu', array( 'hide_empty' => false ) );

	if ( is_array( $menus ) && ! empty( $menus ) ) {

		foreach ( $menus as $single_menu ) {

			if ( is_object( $single_menu ) && isset( $single_menu->name, $single_menu->term_id ) ) {

				$custom_menus[ $single_menu->name ] = $single_menu->term_id;

			}

		}

	}

}



vc_map(

	array(

		'name'					=> esc_html__(' DP Menu Horizontal', 'dpr-adeline-extensions'),

		'base'					=> 'dpr_menu_horizontal',

		'class'					=> 'dpr_menu_horizontal',

		'icon'					=> 'icon-dpr-menu-h',

  		"category" =>array( esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions'),esc_attr__('Header Builder', 'dpr-adeline-extensions'),),

		'description'			=> esc_html__('Display Horizontal Menu ', 'dpr-adeline-extensions'),

		'params'				=> array(

			array(

				'type' => 'dropdown',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select menu to display.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Menu', 'dpr-adeline-extensions'),

				'param_name' => 'nav_menu',

				'value' => $custom_menus,

				'description' => empty( $custom_menus ) ? __( 'Custom menus not found. Please visit <b>Appearance > Menus</b> page to create new menu.', 'dpr-adeline-extensions' ) : '',

				'save_always' => true,

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set menu style.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Menu Style', 'dpr-adeline-extensions'),

				'param_name'		=> 'menu_style',

				'value'				=> 'default',

				'edit_field_class'	=> 'vc_column vc_col-sm-12  ',

				'options'			=> array(

					esc_html__('Default', 'dpr-adeline-extensions')	=> 'default',

					esc_html__('Minimal', 'dpr-adeline-extensions')	=> 'minimal',

					esc_html__('Full Screen', 'dpr-adeline-extensions')	=> 'full-screen',

				)

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set menu alignment in column.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Menu Alignment', 'dpr-adeline-extensions'),

				'param_name'		=> 'menu_alignment',

				'value'				=> 'left',

				'edit_field_class'	=> 'vc_column vc_col-sm-12  ',

				'options'			=> array(

					esc_html__('Left', 'dpr-adeline-extensions')	=> 'left',

					esc_html__('Center', 'dpr-adeline-extensions')	=> 'center',

					esc_html__('Right', 'dpr-adeline-extensions')	=> 'right',

				)

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Display menu cart in in menu', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Display cart in menu', 'dpr-adeline-extensions'),

				'param_name'		=> 'display_menu_cart',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				)

			),
			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Display social links in menu', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Display social links in menu', 'dpr-adeline-extensions'),

				'param_name'		=> 'display_social_links',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				)

			),
			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Additional Settings', 'dpr-adeline-extensions' ),

				'param_name'       => 'extra_features_title',

				'edit_field_class' => 'vc_column vc_col-sm-12',

			),

		   vc_map_add_css_animation( false ),

		    array(

				'type' => 'textfield',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Extra Class Name', 'dpr-adeline-extensions'),

				'param_name' => 'el_class',

			),

			array(

				'type' => 'css_editor',

				'heading' => __( 'CSS box', 'dpr-adeline-extensions' ),

				'param_name' => 'css',

				'group' => __( 'Design Options', 'dpr-adeline-extensions' ),

			),



		)

	)

);