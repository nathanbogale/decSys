"use strict";
document.addEventListener('DOMContentLoaded', function(){ 
    


var $topSpacing = 50;

if(document.body.contains(document.getElementById('wpadminbar'))){
        $topSpacing = $topSpacing+32;
    }
	
if(document.body.classList.contains('sticky-header-enabled')){
	
        $topSpacing = $topSpacing+70;
    }
var elements = document.getElementsByClassName('dpr-sticky-column');
for (var i = 0; i < elements.length; i++) {
  new StickySidebar(elements[i], {
 topSpacing: $topSpacing,
bottomSpacing: 20,
containerSelector: ".dpr_row_wrapper",
innerWrapperSelector: ".vc_column-inner",
minWidth:769
  });
}

}, false);


