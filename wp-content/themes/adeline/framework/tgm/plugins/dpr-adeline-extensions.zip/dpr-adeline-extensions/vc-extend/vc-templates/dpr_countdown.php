<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$unique_id = $css_animation = $el_class = $output = $custom_el_css = $layout = $alignment = $date = $countdown_units = $number_bg_color = $number_border_color = '';
$number_color = $number_font_size = $number_line_height = $number_letter_spacing = $number_font_style = $number_use_google_fonts = $number_google_font = $number_typo_css = '';
$unit_color = $unit_font_size = $unit_line_height = $unit_letter_spacing = $unitr_font_style = $unit_use_google_fonts = $unit_google_font = $unit_typo_css = '';
$use_number_responsive_typo = $number_reaponsive_typography = '';
$numbers_html = '';

$atts = vc_map_get_attributes( 'dpr_countdown', $atts );
extract( $atts );

$el_class = $this->getExtraClass( $el_class );
wp_enqueue_script('dpr-countdown', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/dpr.countdown.js', array('jquery'), null, true);	
wp_enqueue_script('dpr-waypoints', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/waypoints.min.js', array('jquery'), null, true);
if ( '' !== $css_animation && 'none' !== $css_animation ) {
	dpr_enqueue_animate_css();
	$el_class .= ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
}
$unique_id = uniqid('dpr-countdown-').'-'.rand(1,9999);

if(isset($layout)) {
	$el_class .= ' '.$layout;
}
if(isset($alignment) && !empty($alignment)) {
	$el_class       .= ' text-'.$alignment;
}
$css_classes = array(
	'dpr-countdown',
	$el_class,
);

$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->settings['base'], $atts ) );

$number_typo_css = dpr_generate_typography_css($number_color, $number_font_size, $number_line_height, $number_letter_spacing, $number_font_style,$number_google_font);
if($number_typo_css != '' ) {
	$custom_el_css .= '.'.esc_js($unique_id).' .number-wrap .number {'.$number_typo_css.'}';
	$custom_el_css .= '.'.esc_js($unique_id).' .number-wrap {min-width:'.round(1.8*$number_font_size).'px;min-height:'.round(1.8*$number_font_size).'px;}';
	$custom_el_css .= '.dpr-countdown.layout-2 .'.esc_js($unique_id).' .number {min-width:'.round(2*$number_font_size).'px;height:'.round(2*$number_font_size).'px;}';
}
$unit_typo_css = dpr_generate_typography_css($unit_color, $unit_font_size, $unit_line_height, $unit_letter_spacing, $unit_font_style,$unit_google_font);	
if($unit_typo_css != '' ) {
	$custom_el_css .= '.'.esc_js($unique_id).' .unit {'.$unit_typo_css.'}';
}
if($number_bg_color !='') {
	$custom_el_css .= '.dpr-countdown.layout-2 .'.esc_js($unique_id).' .number-container:before, .dpr-countdown.layout-3 .'.esc_js($unique_id).' .number-wrap:before {background-color:'.$number_bg_color.';}';
}
if($number_border_color !='') {
	$custom_el_css .= '.dpr-countdown.layout-2 .'.esc_js($unique_id).' .number-container:before, .dpr-countdown.layout-3 .'.esc_js($unique_id).' .number-wrap:before {border-color:'.$number_border_color.';}';
}

if($use_number_responsive_typo && isset($number_reaponsive_typography) && $number_reaponsive_typography != '') {
	$responsive_unique_class = '.'.esc_js($unique_id) .' .number-wrap .number';
	$custom_el_css .= DPR_Resposive_Typography_Param::generate_css($number_reaponsive_typography,$responsive_unique_class);
}
if($use_unit_responsive_typo && isset($unit_reaponsive_typography) && $unit_reaponsive_typography != '') {
	$responsive_unique_class_1 = '.'.esc_js($unique_id) .' .unit';
	$custom_el_css .= DPR_Resposive_Typography_Param::generate_css($unit_reaponsive_typography,$responsive_unique_class_1);
}

/* HTML Parts */


$countdown_units = explode( ',', $countdown_units );


if (is_array($countdown_units)) {
	foreach ($countdown_units as $unit) {
		if ('year_val' === $unit) {
			$numbers_html .= '<span class="number-wrap">';
				$numbers_html .= '<span class="number-container"><span class="number">%-Y</span></span>';
				$numbers_html .= '<span class="unit">'.esc_html__('Years', 'dpr-adeline-extensions').'</span>';
			$numbers_html .= '</span>';
		}
		if ('month_val' === $unit) {
			$numbers_html .= '<span class="number-wrap">';
				$numbers_html .= '<span class="number-container"><span class="number">%-m</span></span>';
				$numbers_html .= '<span class="unit">'.esc_html__('Months', 'dpr-adeline-extensions').'</span>';
			$numbers_html .= '</span>';
		}
		if ('day_val' === $unit) {
			$numbers_html .= '<span class="number-wrap">';
				$numbers_html .= '<span class="number-container"><span class="number">%-n</span></span>';
				$numbers_html .= '<span class="unit">'.esc_html__('Days', 'dpr-adeline-extensions').'</span>';
			$numbers_html .= '</span>';
		}
		if ('hr_val' === $unit) {
			$numbers_html .= '<span class="number-wrap">';
				$numbers_html .= '<span class="number-container"><span class="number">%-H</span></span>';
				$numbers_html .= '<span class="unit">'.esc_html__('Hours', 'dpr-adeline-extensions').'</span>';
			$numbers_html .= '</span>';
		}
		if ('min_val' === $unit) {
			$numbers_html .= '<span class="number-wrap">';
				$numbers_html .= '<span class="number-container"><span class="number">%-M</span></span>';
				$numbers_html .= '<span class="unit">'.esc_html__('Minutes', 'dpr-adeline-extensions').'</span>';
			$numbers_html .= '</span>';
		}
		if ('sec_val' === $unit) {
			$numbers_html .= '<span class="number-wrap">';
				$numbers_html .= '<span class="number-container"><span class="number">%-S</span></span>';
				$numbers_html .= '<span class="unit">'.esc_html__('Seconds', 'dpr-adeline-extensions').'</span>';
			$numbers_html .= '</span>';
		}
	}
}




$output .= '<div class="'.esc_attr($css_class).'">';

if($date != ''){
	$output .= '<div id="'.esc_attr($unique_id).'" class="dpr-countdown-wrap '.$unique_id.'" data-date="'.esc_attr($date).'" data-finish-text="'.esc_attr__('Event already pass','dpr-adeline-extensions').'">';
		$output .= '<div class="hide dpr-countdown-html">'.wp_kses($numbers_html, array('span' => array('class' => array()))).'</div>';
	$output .= '</div>';
}

if(!empty($custom_el_css)) {
		$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>");'
						. '})(jQuery);'
					. '</script>';
}
$output .= '</div>';


echo $output;