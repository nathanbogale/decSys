<?php

/**



 * General Options -> General Settings



 *



 */

Redux::setSection($opt_name, array(

    'title'      => esc_html__('General Settings', 'dpr-adeline-extensions'),

    'id'         => 'general_general_settings',

    'subsection' => true,

    'fields'     => array(

        array(

            'id'      => 'layout_width',

            'type'    => 'image_select',

            'title'   => __('Default Page Width', 'dpr-adeline-extensions'),

            'options' => array(

                'stretched' => array(

                    'title' => esc_html__('Stretched', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/layouts/stretched_layout.png',

                ),

                'boxed'     => array(

                    'title' => esc_html__('Boxed', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/layouts/boxed_layout.png',

                ),

                'framed'    => array(

                    'title' => esc_html__('Framed', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/layouts/framed_layout.png',

                ),

            ),

            'default' => 'stretched',

            'hint'    => array(

                'title'   => esc_attr__('Default sidebar position', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Choose default sidebar position. This general settings can be overwriten for specific pages.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'container_width',

            'type'     => 'dimensions',

            'title'    => esc_html__('Main Container Width (px)', 'dpr-adeline-extensions'),

            'output'   => array('width' => '.container'),

            'width'    => true,

            'height'   => false,

            'mode'     => array('width' => 'width', 'height' => 'height'),

            'units'    => array('px'),

            'default'  => array(

                'width' => '1280px',

            ),

            'hint'     => array(

                'title'   => esc_attr__('Main Container Width', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify the maximum base width for the theme to be visible on desktop computers.', 'dpr-adeline-extensions'),

            ),

            'required' => array('layout_width', 'not', 'boxed'),

        ),

        array(

            'id'       => 'boxed_shadow',

            'type'     => 'switch',

            'title'    => esc_html__('Box Shadow', 'dpr-adeline-extensions'),

            'default'  => true,

            'hint'     => array(

                'title'   => esc_attr__('Box shadow', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enable or disable shadow for box.', 'dpr-adeline-extensions'),

            ),

            'required' => array('layout_width', 'equals', 'boxed'),

        ),

        array(

            'id'       => 'boxed_width',

            'type'     => 'dimensions',

            'title'    => esc_html__('Boxed Width (px)', 'dpr-adeline-extensions'),

            'output'   => array('width' => '.boxed-layout.wrap-boxshadow #dpr-inner-wrapper'),

            'width'    => true,

            'height'   => false,

            'mode'     => array('width' => 'width', 'height' => 'height'),

            'units'    => array('px'),

            'default'  => array(

                'width' => '1280px',

            ),

            'hint'     => array(

                'title'   => esc_attr__('Boxed Width', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify the width for inner box.', 'dpr-adeline-extensions'),

            ),

            'required' => array('layout_width', 'equals', 'boxed'),

        ),

        array(

            'id'       => 'boxed_wrapper_bg',

            'type'     => 'color',

            'output'   => array('background-color' => '.boxed-layout #dpr-wrapper'),

            'validate' => 'color',

            'title'    => esc_html__('Inner Background', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'hint'     => array(

                'title'   => esc_attr__('Inner Background', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set main content wrapper background color.', 'dpr-adeline-extensions'),

            ),

            'required' => array('layout_width', 'equals', 'boxed'),

        ),

        array(

            'id'       => 'boxed_body_bg',

            'type'     => 'background',

            'title'    => __('Outer Background', 'dpr-adeline-extensions'),

            'default'  => array(

                'background-color' => '#e9e9e9',

            ),

            'output'   => array('.boxed-layout'),

            'hint'     => array(

                'title'   => esc_attr__('Outer Background', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set body background properties for boxed layout.', 'dpr-adeline-extensions'),

            ),

            'required' => array('layout_width', 'equals', 'boxed'),

        ),

        array(

            'id'             => 'frame_width',

            'type'           => 'spacing',

            'output'         => array('.framed-layout #dpr-outer-wrapper'),

            'mode'           => 'padding',

            'units'          => array('%'),

            'display_units'  => true,

            'units_extended' => false,

            'title'          => __('Frame Width (%)', 'dpr-adeline-extensions'),

            'default'        => array(

                'padding-top'    => '1.8%',

                'padding-bottom' => '1.8%',

                'padding-left'   => '1.8%',

                'padding-right'  => '1.8%',

                'units'          => '%',

            ),

            'hint'           => array(

                'title'   => esc_attr__('Content Padding', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Choose default padding. This settings affect on default WP pages.', 'dpr-adeline-extensions'),

            ),

            'required'       => array('layout_width', 'equals', 'framed'),

        ),

        array(

            'id'       => 'framed_color',

            'type'     => 'color',

            'output'   => array('background-color' => '.framed-layout'),

            'validate' => 'color',

            'title'    => esc_html__('Frame Color', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'hint'     => array(

                'title'   => esc_attr__('Frame Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set frame background color.', 'dpr-adeline-extensions'),

            ),

            'required' => array('layout_width', 'equals', 'framed'),

        ),

        array(

            'id'       => 'framed_content_bg',

            'type'     => 'color',

            'output'   => array('background-color' => '.framed-layout #dpr-inner-wrapper'),

            'validate' => 'color',

            'title'    => esc_html__('Content Background Color', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'hint'     => array(

                'title'   => esc_attr__('Content Background Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set framed content background color.', 'dpr-adeline-extensions'),

            ),

            'required' => array('layout_width', 'equals', 'framed'),

        ),

        array(

            'id'      => 'page_content_layout',

            'type'    => 'image_select',

            'title'   => __('Default Content Layout', 'dpr-adeline-extensions'),

            'options' => array(

                'right-sidebar' => array(

                    'title' => esc_html__('Sidebar right', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/sidebar_right.png',

                ),

                'left-sidebar'  => array(

                    'title' => esc_html__('Sidebar left', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/sidebar_left.png',

                ),

                'both-sidebars' => array(

                    'title' => esc_html__('Both sidebars', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/sidebar_both.png',

                ),

                'full-width'    => array(

                    'title' => esc_html__('Full width', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/sidebar_disabled.png',

                ),

                'full-screen'   => array(

                    'title' => esc_html__('Full screen', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/full_screen.png',

                ),

            ),

            'default' => 'right-sidebar',

            'hint'    => array(

                'title'   => esc_attr__('Default Content Layout', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Choose default content layoyt eg sidebar position. This general settings can be overwriten for specific pages.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'page_both_sidebars_column_order',

            'type'     => 'image_select',

            'title'    => __('Both Sidebars: Column Order', 'dpr-adeline-extensions'),

            'options'  => array(

                'order-scs' => array(

                    'title' => esc_html__('Sidebar/Content/Sidebar', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/scs.png',

                ),

                'order-ssc' => array(

                    'title' => esc_html__('Sidebar/Sidebar/Content', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/ssc.png',

                ),

                'order-css' => array(

                    'title' => esc_html__('Content/Sidebar/Sidebar', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/sidebars/css.png',

                ),

            ),

            'default'  => 'order-scs',

            'hint'     => array(

                'title'   => esc_attr__('Both Sidebars: Column Order', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Choose default column order. This general settings can be overwriten for specific pages.', 'dpr-adeline-extensions'),

            ),

            'required' => array('page_content_layout', 'equals', 'both-sidebars'),

        ),

        array(

            'id'       => 'sidebar_right_sticky',

            'type'     => 'switch',

            'default'  => false,

            'title'    => esc_html__('Sidebar Sticky', 'dpr-adeline-extensions'),

            'hint'     => array(

                'title'   => esc_attr__('Right Sidebar Sticky', 'dpr-adeline-extensions'),

                'content' => esc_attr__('If enabled main sidebar stay sticky by scroll', 'dpr-adeline-extensions'),

            ),

            'required' => array('page_content_layout', 'equals', array('right-sidebar', 'both-sidebars', 'left-sidebar')),

        ),

        array(

            'id'       => 'sidebar_left_sticky',

            'type'     => 'switch',

            'default'  => false,

            'title'    => esc_html__('Left Sidebar Sticky', 'dpr-adeline-extensions'),

            'hint'     => array(

                'title'   => esc_attr__('Left Sidebar Sticky', 'dpr-adeline-extensions'),

                'content' => esc_attr__('If enabled left sidebar stay sticky by scroll', 'dpr-adeline-extensions'),

            ),

            'required' => array('page_content_layout', 'equals', array('both-sidebars')),

        ),

        array(

            'id'       => 'content_width',

            'type'     => 'dimensions',

            'title'    => esc_html__('Content Width (%)', 'dpr-adeline-extensions'),

            'width'    => true,

            'height'   => false,

            'mode'     => array('width' => 'width', 'height' => 'height'),

            'units'    => array('%'),

            'default'  => array(

                'width' => '72%',

            ),

            'hint'     => array(

                'title'   => esc_attr__('Content Width', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify themain content width (in %).', 'dpr-adeline-extensions'),

            ),

            'required' => array('page_content_layout', 'equals', array('left-sidebar', 'right-sidebar')),

        ),

        array(

            'id'       => 'sidebar_width',

            'type'     => 'dimensions',

            'title'    => esc_html__('Sidebar Width (%)', 'dpr-adeline-extensions'),

            'width'    => true,

            'height'   => false,

            'mode'     => array('width' => 'width', 'height' => 'height'),

            'units'    => array('%'),

            'default'  => array(

                'width' => '28%',

            ),

            'hint'     => array(

                'title'   => esc_attr__('Sidebar Width', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify the sidebar width (in %).', 'dpr-adeline-extensions'),

            ),

            'required' => array('page_content_layout', 'equals', array('left-sidebar', 'right-sidebar')),

        ),

        array(

            'id'       => 'both_sidebars_content_width',

            'type'     => 'dimensions',

            'title'    => esc_html__('Both Sidebars: Content Width (%)', 'dpr-adeline-extensions'),

            'width'    => true,

            'height'   => false,

            'mode'     => array('width' => 'width', 'height' => 'height'),

            'units'    => array('%'),

            'default'  => array(

                'width' => '44%',

            ),

            'hint'     => array(

                'title'   => esc_attr__('Both Sidebars: Content Width', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify the main content width in both sidebars layout (in %).', 'dpr-adeline-extensions'),

            ),

            'required' => array('page_content_layout', 'equals', 'both-sidebars'),

        ),

        array(

            'id'       => 'both_sidebars_sidebars_width',

            'type'     => 'dimensions',

            'title'    => esc_html__('Both Sidebars: Sidebars Width (%)', 'dpr-adeline-extensions'),

            'width'    => true,

            'height'   => false,

            'mode'     => array('width' => 'width', 'height' => 'height'),

            'units'    => array('%'),

            'default'  => array(

                'width' => '28%',

            ),

            'hint'     => array(

                'title'   => esc_attr__('Both Sidebars: Sidebars Width', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify the sidebara width in both sidebars layout (in %).', 'dpr-adeline-extensions'),

            ),

            'required' => array('page_content_layout', 'equals', 'both-sidebars'),

        ),

        array(

            'id'             => 'page_padding',

            'type'           => 'spacing',

            'output'         => array('#main #dpr-content-wrapper'),

            'mode'           => 'padding',

            'left'           => false,

            'right'          => false,

            'units'          => array('px'),

            'display_units'  => true,

            'units_extended' => false,

            'title'          => __('Content Padding (px)', 'dpr-adeline-extensions'),

            'default'        => array(

                'padding-top'    => '90px',

                'padding-bottom' => '90px',

                'units'          => 'px',

            ),

            'hint'           => array(

                'title'   => esc_attr__('Content Padding', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Choose default padding. This settings affect on default WP pages.', 'dpr-adeline-extensions'),

            ),

        ),

    ),

));
