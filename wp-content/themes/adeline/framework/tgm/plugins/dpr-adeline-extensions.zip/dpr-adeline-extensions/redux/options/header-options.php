<?php



/**



 * Header Options



 * 



 */







    Redux::setSection( $opt_name, array(



        'title'  => __( 'Header & Menu', 'dpr-adeline-extensions' ),



        'id'     => 'header_tab',



        'desc'   => __( 'Basic header area settings are configured here.', 'dpr-adeline-extensions' ),



        'icon'   => 'dashicons dashicons-editor-kitchensink'



    ) );



	 



	require_once($options_dir . '/header-options/general-style.php');



	require_once($options_dir . '/header-options/logo.php');



	require_once($options_dir . '/header-options/menu.php');



	require_once($options_dir . '/header-options/mobile-menu.php');



	require_once($options_dir . '/header-options/sticky-header.php');	



	require_once($options_dir . '/header-options/social.php');



