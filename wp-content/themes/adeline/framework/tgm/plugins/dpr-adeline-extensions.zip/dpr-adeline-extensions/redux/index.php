<?php
// Silence is golden.
?>