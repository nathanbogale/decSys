<?php

// Exit if accessed directly

if (!defined('ABSPATH')) {

    exit;

}

/*

 * Add-on Name: DP Timetable

 */

class WPBakeryShortCode_DPR_Booked_Calendar extends WPBakeryShortCode
{}

vc_map(

    array(

        'name'        => esc_html__('Booked Calendar', 'dpr-adeline-extensions'),

        'base'        => 'dpr_booked_calendar',

        "icon"        => 'icon-dpr-booked',

        "class"       => 'dpr_booked',

        "category"    => array(esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'), esc_attr__('Content', 'dpr-adeline-extensions')),

        'description' => esc_html__('Display Booked Calendar', 'dpr-adeline-extensions'),

        'params'      => array(

			array(

				'type' => 'dpr_booked_calendar_select',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select custom calendar to display.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom Calendar', 'dpr-adeline-extensions'),

				'param_name' => 'calendar_id',

				'placeholder' => esc_html__('Select custom calendar', 'dpr-adeline-extensions'),	

				'edit_field_class' => 'vc_column vc_col-sm-12',

                'description'      => esc_html__('Use to display a specific custom calendar (if you have any created). Otherwise, Booked will simply display the default calendar.', 'dpr-adeline-extensions'),				


			),        	

            array(

                'type'             => 'dpr_title',

                'text'             => esc_html__('General Settings', 'dpr-adeline-extensions'),

                'param_name'       => 'general_title',

                'edit_field_class' => 'vc_column vc_col-sm-12',

            ),


            array(

                'type'             => 'dpr_switcher',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Display calendars switcher .', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Display Calendars Switcher', 'dpr-adeline-extensions'),

                'param_name'       => 'display_switcher',

                'value'            => 'no',

                'options'          => array(

                    'yes'         => array(

                        'yes' => esc_attr__('Yes', 'dpr-adeline-extensions'),

                        'no'  => esc_attr__('No', 'dpr-adeline-extensions'),

                    ),
               
                ), 

                'description' => esc_html__('Set to "Yes" if you wish to display display switcher between custom calendars (if you have any created).', 'dpr-adeline-extensions'),


            ),
			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose display style.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Display Style', 'dpr-adeline-extensions'),

				'param_name'		=> 'display_style',

				'value'				=> 'calendar',

				'description' => esc_html__('This attribute let&#x27;s you choose between the default calendar view or a single day list view.', 'dpr-adeline-extensions'),

				'options'			=> array(

					esc_html__("Calendar", 'dpr-adeline-extensions') => "calendar",

					esc_html__("List", 'dpr-adeline-extensions') => "list",

				)

			), 

			array(

				'type' => 'dropdown',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If you wish to display certain year.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Year', 'dpr-adeline-extensions'),

				'param_name' => 'calendar_year',

				'edit_field_class' => 'vc_column vc_col-sm-4',

				'value' => array(

						'' => '',
						'2025' => '2025',
						'2024' => '2024',
						'2023' => '2023',
						'2022' => '2022',
						'2021' => '2021',
						'2020' => '2020',
						'2019' => '2019',
						'2018' => '2018',
						'2017' => '2017',
						'2016' => '2016',
						'2015' => '2015',
						'2014' => '2014',
						'2013' => '2013',
						'2012' => '2012',
						'2011' => '2011',
						'2010' => '2010',
						'2009' => '2009',
						'2008' => '2008',
						'2007' => '2007',
						'2006' => '2006',
						'2005' => '2005',
						'2004' => '2004',
						'2003' => '2003',
						'2002' => '2002',
						'2001' => '2001',
						'2000' => '2000',
						'1999' => '1999',
						'1998' => '1998',
						'1997' => '1997',
						'1996' => '1996',
						'1995' => '1995',
						'1994' => '1994',
						'1993' => '1993',
						'1992' => '1992',
						'1991' => '1991',
						'1990' => '1990',
						'1989' => '1989',
						'1988' => '1988',
						'1987' => '1987',
						'1986' => '1986',
						'1985' => '1985',
						'1984' => '1984',
						'1983' => '1983',
						'1982' => '1982',
						'1981' => '1981',
						'1980' => '1980',
						'1979' => '1979',
						'1978' => '1978',
						'1977' => '1977',
						'1976' => '1976',
						'1975' => '1975',
						'1974' => '1974',
						'1973' => '1973',
						'1972' => '1972',
						'1971' => '1971',
						'1970' => '1970',
						'1969' => '1969',
						'1968' => '1968',
						'1967' => '1967',
						'1966' => '1966',
						'1965' => '1965',
						'1964' => '1964',
						'1963' => '1963',
						'1962' => '1962',
						'1961' => '1961',
						'1960' => '1960',
						'1959' => '1959',
						'1958' => '1958',
						'1957' => '1957',
						'1956' => '1956',
						'1955' => '1955',
						'1954' => '1954',
						'1953' => '1953',
						'1952' => '1952',
						'1951' => '1951',
						'1950' => '1950',
						'1949' => '1949',
						'1948' => '1948',
						'1947' => '1947',
						'1946' => '1946',
						'1945' => '1945',
						'1944' => '1944',
						'1943' => '1943',
						'1942' => '1942',
						'1941' => '1941',
						'1940' => '1940',
						'1939' => '1939',
						'1938' => '1938',
						'1937' => '1937',
						'1936' => '1936',
						'1935' => '1935',
						'1934' => '1934',
						'1933' => '1933',
						'1932' => '1932',
						'1931' => '1931',
						'1930' => '1930'

					   )

			),

			array(

				'type' => 'dropdown',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If you wish to display certain month.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Month', 'dpr-adeline-extensions'),

				'param_name' => 'calendar_month',

				'edit_field_class' => 'vc_column vc_col-sm-4',

				'value' => array(

						'' => '',
						'01' => '1',
						'02' => '2',
						'03' => '3',
						'04' => '4',
						'05' => '5',
						'06' => '6',
						'07' => '7',
						'08' => '8',
						'09' => '9',
						'10' => '10',
						'11' => '11',
						'12' => '12'

					   )

			),

			array(

				'type' => 'dropdown',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If you wish to display certain day. Only for list view.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Day', 'dpr-adeline-extensions'),

				'param_name' => 'calendar_day',

				'edit_field_class' => 'vc_column vc_col-sm-4',

                'dependency'		=> array('element' => 'display_style', 'value' => 'list'),

				'value' => array(


						'' => '',
						'01' => '1',
						'02' => '2',
						'03' => '3',
						'04' => '4',
						'05' => '5',
						'06' => '6',
						'07' => '7',
						'08' => '8',
						'09' => '9',
						'10' => '10',
						'11' => '11',
						'12' => '12',
						'13' => '13',
						'14' => '14',
						'15' => '15',
						'16' => '16',
						'17' => '17',
						'18' => '18',
						'19' => '19',
						'20' => '20',
						'21' => '21',
						'22' => '22',
						'23' => '23',
						'24' => '24',
						'25' => '25',
						'26' => '26',
						'27' => '27',
						'28' => '28',
						'29' => '29',
						'30' => '30',
						'31' => '31'

					   )

			),


            array(

                'type'             => 'dpr_title',

                'text'             => esc_html__('', 'dpr-adeline-extensions'),

                'param_name'       => 'general_explanation',

                'edit_field_class' => 'vc_column vc_col-sm-12',

                'description' => esc_html__('Use these attributes to display a specific &#x22;year&#x22; and/or &#x22;month&#x22;. You can also add a &#x22;day&#x22; attribute when using the &#x22;list&#x22; style (see above).', 'dpr-adeline-extensions'),


            ),

/*EXTRA FEATURES */

            array(

                'type'             => 'dpr_title',

                'text'             => esc_html__('Additional Settings', 'dpr-adeline-extensions'),

                'param_name'       => 'extra_features_title',

                'edit_field_class' => 'vc_column vc_col-sm-12',

            ),

            vc_map_add_css_animation(false),

            array(

                'type'             => 'textfield',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="' . esc_html__('If you use more than one table on a page specify the unique ID for a timetable. Make sure it is unique, and it is valid as w3c specification (Must not have spaces).', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Unique ID', 'dpr-adeline-extensions'),

                'param_name'       => 'el_id',

                'value'            => '',

                'edit_field_class' => 'vc_col-sm-6 vc_column ',

            ),

            array(

                'type'       => 'textfield',

                'heading'    => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Use these attributes to display a specific "year" and/or "month". You can also add a "day" attribute when using the "list" style.', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Extra Class Name', 'dpr-adeline-extensions'),

                'param_name' => 'el_class',

            ),

            array(

                'type'             => 'dpr_switcher',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Hide the appointment calendar from non-logged-in users.', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Members Only?', 'dpr-adeline-extensions'),

                'param_name'       => 'members_only',

                'edit_field_class' => 'vc_column vc_col-sm-4',

                'value'            => 'no',

                'options'          => array(

                    'yes' => array(

                        'yes' => esc_attr__('Yes', 'dpr-adeline-extensions'),

                        'no'  => esc_attr__('No', 'dpr-adeline-extensions'),

                    ),

                )
            ),            

/*LAYOUT & STYLE */

			array(

			'type'            	=> 'dpr_title',

			'text'            	=> esc_html__( 'Header', 'dpr-adeline-extensions' ),

			'param_name'       	=> 'booking_style_title_1',

			'edit_field_class' 	=> 'vc_column vc_col-sm-12',

			'group'	=> esc_html__('Calendar Style', 'dpr-adeline-extensions'),

			),
           array(

                'type'             => 'colorpicker',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Choose lighter background color in heading', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Lighter Background Color', 'dpr-adeline-extensions'),

                'param_name'       => 'light_color_bg',

                'edit_field_class' => 'vc_column vc_col-sm-4',

                'value'            => '#424251',

                'group'            => esc_html__('Calendar Style', 'dpr-adeline-extensions'),

            ),
             array(

                'type'             => 'colorpicker',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Choose text color for lighter background color in heading', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Lighter Background Text Color', 'dpr-adeline-extensions'),

                'param_name'       => 'light_color_text',

                'edit_field_class' => 'vc_column vc_col-sm-4',

                'value'            => '#ffffff',

                'group'            => esc_html__('Calendar Style', 'dpr-adeline-extensions'),

            ), 
			array(

				'type'				=> 'dpr_clear',

				'param_name'		=> 'clear_1',

				'edit_field_class'	=> 'vc_col-sm-12 vc_column ',

				'group'				=> esc_html__('Calendar Style', 'dpr-adeline-extensions'),

			),          

            array(

                'type'             => 'colorpicker',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Choose darker background color in heading', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Darker Background Color', 'dpr-adeline-extensions'),

                'param_name'       => 'dark_color_bg',

                'edit_field_class' => 'vc_column vc_col-sm-4',

                'value'            => '#292933',

                'group'            => esc_html__('Calendar Style', 'dpr-adeline-extensions'),

            ),
             array(

                'type'             => 'colorpicker',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Choose text color for darker background color in heading', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Darker Background Text Color', 'dpr-adeline-extensions'),

                'param_name'       => 'dark_color_text',

                'edit_field_class' => 'vc_column vc_col-sm-4',

                'value'            => '#ffffff',

                'group'            => esc_html__('Calendar Style', 'dpr-adeline-extensions'),

            ),                      

			array(

			'type'            	=> 'dpr_title',

			'text'            	=> esc_html__( 'Date', 'dpr-adeline-extensions' ),

			'param_name'       	=> 'booking_style_title_2',

			'edit_field_class' 	=> 'vc_column vc_col-sm-12',

			'group'	=> esc_html__('Calendar Style', 'dpr-adeline-extensions'),

			),
            
            array(

                'type'             => 'colorpicker',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Choose background color for date', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Date Background', 'dpr-adeline-extensions'),

                'param_name'       => 'date_bg',

                'edit_field_class' => 'vc_column vc_col-sm-4',

                'value'            => '#f1f2f4',

                'group'            => esc_html__('Calendar Style', 'dpr-adeline-extensions'),

            ),

            array(

                'type'             => 'colorpicker',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Choose color for date number', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Number Color', 'dpr-adeline-extensions'),

                'param_name'       => 'date_number_color',

                'edit_field_class' => 'vc_column vc_col-sm-4',

                'value'            => '#c9c9ce',

                'group'            => esc_html__('Calendar Style', 'dpr-adeline-extensions'),

            ), 

            array(

                'type'             => 'colorpicker',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Choose border color for date', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Date Border', 'dpr-adeline-extensions'),

                'param_name'       => 'date_border',

                'edit_field_class' => 'vc_column vc_col-sm-4',

                'value'            => '#e5e5e9',

                'group'            => esc_html__('Calendar Style', 'dpr-adeline-extensions'),

            ), 

			array(

			'type'            	=> 'dpr_title',

			'text'            	=> esc_html__( 'Available Dates Style', 'dpr-adeline-extensions' ),

			'class'				=> 'small',

			'param_name'       	=> 'booking_style_title_5',

			'edit_field_class' 	=> 'vc_column vc_col-sm-12',

			'group'	=> esc_html__('Calendar Style', 'dpr-adeline-extensions'),

			),			          
            array(

                'type'             => 'colorpicker',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Choose background color for available date', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Date Background', 'dpr-adeline-extensions'),

                'param_name'       => 'av_date_bg',

                'edit_field_class' => 'vc_column vc_col-sm-4',

                'value'            => '#ffffff',

                'group'            => esc_html__('Calendar Style', 'dpr-adeline-extensions'),

            ),

            array(

                'type'             => 'colorpicker',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Choose color for available date number', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Number Color', 'dpr-adeline-extensions'),

                'param_name'       => 'av_date_number_color',

                'edit_field_class' => 'vc_column vc_col-sm-4',

                'value'            => '#292933',

                'group'            => esc_html__('Calendar Style', 'dpr-adeline-extensions'),

            ), 
             array(

                'type'             => 'colorpicker',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Choose background color for available date hover state', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Background Color:Hover', 'dpr-adeline-extensions'),

                'param_name'       => 'av_date_bg_h',

                'edit_field_class' => 'vc_column vc_col-sm-4',

                'value'            => '#fcfcfc',

                'group'            => esc_html__('Calendar Style', 'dpr-adeline-extensions'),

            ),

            array(

                'type'             => 'colorpicker',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Choose available data number background color hover state', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Number Background:Hover', 'dpr-adeline-extensions'),

                'param_name'       => 'av_date_number_bg_h',

                'edit_field_class' => 'vc_column vc_col-sm-4',

                'value'            => '#D3AE5F',

                'group'            => esc_html__('Calendar Style', 'dpr-adeline-extensions'),

            ), 

            array(

                'type'             => 'colorpicker',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Choose color for available date number hover state', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Number Color:Hover', 'dpr-adeline-extensions'),

                'param_name'       => 'av_date_number_color_h',

                'edit_field_class' => 'vc_column vc_col-sm-4',

                'value'            => '#ffffff',

                'group'            => esc_html__('Calendar Style', 'dpr-adeline-extensions'),

            ),            
			array(

			'type'            	=> 'dpr_title',

			'text'            	=> esc_html__( 'Today Date Style', 'dpr-adeline-extensions' ),

			'class'				=> 'small',

			'param_name'       	=> 'booking_style_title_6',

			'edit_field_class' 	=> 'vc_column vc_col-sm-12',

			'group'	=> esc_html__('Calendar Style', 'dpr-adeline-extensions'),

			),
            array(

                'type'             => 'colorpicker',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Choose color for today date number border', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Number Border', 'dpr-adeline-extensions'),

                'param_name'       => 't_date_number_border',

                'edit_field_class' => 'vc_column vc_col-sm-4',

                'value'            => '#D3AE5F',

                'group'            => esc_html__('Calendar Style', 'dpr-adeline-extensions'),

            ), 

			array(

			'type'            	=> 'dpr_title',

			'text'            	=> esc_html__( 'Active Date Style', 'dpr-adeline-extensions' ),

			'class'				=> 'small',

			'param_name'       	=> 'booking_style_title_7',

			'edit_field_class' 	=> 'vc_column vc_col-sm-12',

			'group'	=> esc_html__('Calendar Style', 'dpr-adeline-extensions'),

			),
 
           array(

                'type'             => 'colorpicker',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Choose color for active date background. This will be also background for expanded appoitments block', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Background', 'dpr-adeline-extensions'),

                'param_name'       => 'ac_date_bg',

                'edit_field_class' => 'vc_column vc_col-sm-4',

                'value'            => '#e5e5e9',

                'group'            => esc_html__('Calendar Style', 'dpr-adeline-extensions'),

            ), 
         
                                                         
			array(

			'type'            	=> 'dpr_title',

			'text'            	=> esc_html__( 'Appoitments Block', 'dpr-adeline-extensions' ),

			'param_name'       	=> 'booking_style_title_3',

			'edit_field_class' 	=> 'vc_column vc_col-sm-12',

			'group'	=> esc_html__('Calendar Style', 'dpr-adeline-extensions'),

            ), 

           array(

                'type'             => 'colorpicker',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Choose background color for appoitment block.', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Background Color', 'dpr-adeline-extensions'),

                'param_name'       => 'app_bg',

                'edit_field_class' => 'vc_column vc_col-sm-4',

                'value'            => '#ffffff',

                'group'            => esc_html__('Calendar Style', 'dpr-adeline-extensions'),

            ), 
           array(

                'type'             => 'colorpicker',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Choose header color for appoitment block.', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Header Color', 'dpr-adeline-extensions'),

                'param_name'       => 'app_header',

                'edit_field_class' => 'vc_column vc_col-sm-4',

                'value'            => '#292933',

                'group'            => esc_html__('Calendar Style', 'dpr-adeline-extensions'),

            ), 
           array(

                'type'             => 'colorpicker',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Choose text color for appoitment block.', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Text Color', 'dpr-adeline-extensions'),

                'param_name'       => 'app_text',

                'edit_field_class' => 'vc_column vc_col-sm-4',

                'value'            => '#292933',

                'group'            => esc_html__('Calendar Style', 'dpr-adeline-extensions'),

            ), 
            array(

                'type'             => 'colorpicker',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Choose light text color for appoitment block.', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Text Light Color', 'dpr-adeline-extensions'),

                'param_name'       => 'app_text_light',

                'edit_field_class' => 'vc_column vc_col-sm-4',

                'value'            => '#555555',

                'group'            => esc_html__('Calendar Style', 'dpr-adeline-extensions'),

            ), 
            array(

                'type'             => 'colorpicker',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Choose border color for appoitment block.', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Border Color', 'dpr-adeline-extensions'),

                'param_name'       => 'app_border',

                'edit_field_class' => 'vc_column vc_col-sm-4',

                'value'            => '#e5e5e9',

                'group'            => esc_html__('Calendar Style', 'dpr-adeline-extensions'),

            ), 
             array(

                'type'             => 'colorpicker',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Choose hover background color for appoitment block.', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Hover Background Color', 'dpr-adeline-extensions'),

                'param_name'       => 'app_hover_bg',

                'edit_field_class' => 'vc_column vc_col-sm-4',

                'value'            => '#fcfcfc',

                'group'            => esc_html__('Calendar Style', 'dpr-adeline-extensions'),

            ), 
 			array(

			'type'            	=> 'dpr_title',

			'text'            	=> esc_html__( 'Button Settings', 'dpr-adeline-extensions' ),
			
			'class'				=> 'small',

			'param_name'       	=> 'booking_style_title_12',

			'edit_field_class' 	=> 'vc_column vc_col-sm-12',

			'group'	=> esc_html__('Calendar Style', 'dpr-adeline-extensions'),

			),
           array(

                'type'             => 'colorpicker',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Choose button background color.', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Background Color', 'dpr-adeline-extensions'),

                'param_name'       => 'button_bg',

                'edit_field_class' => 'vc_column vc_col-sm-4',

                'value'            => '#D3AE5F',

                'group'            => esc_html__('Calendar Style', 'dpr-adeline-extensions'),

            ), 
            array(

                'type'             => 'colorpicker',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Choose button text color.', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Text Color', 'dpr-adeline-extensions'),

                'param_name'       => 'button_color',

                'edit_field_class' => 'vc_column vc_col-sm-4',

                'value'            => '#ffffff',

                'group'            => esc_html__('Calendar Style', 'dpr-adeline-extensions'),

            ), 
			array(

				'type'				=> 'dpr_clear',

				'param_name'		=> 'clear_2',

				'edit_field_class'	=> 'vc_col-sm-12 vc_column ',

				'group'				=> esc_html__('Calendar Style', 'dpr-adeline-extensions'),

			),          				
            array(

                'type'             => 'colorpicker',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Choose button hover background color.', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Background Color:Hover', 'dpr-adeline-extensions'),

                'param_name'       => 'button_bg_h',

                'edit_field_class' => 'vc_column vc_col-sm-4',

                'value'            => '#313e4c',

                'group'            => esc_html__('Calendar Style', 'dpr-adeline-extensions'),

            ), 
            array(

                'type'             => 'colorpicker',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Choose button hover text color.', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Text Color:Hover', 'dpr-adeline-extensions'),

                'param_name'       => 'button_color_h',

                'edit_field_class' => 'vc_column vc_col-sm-4',

                'value'            => '#ffffff',

                'group'            => esc_html__('Calendar Style', 'dpr-adeline-extensions'),

            ), 

			array(

			'type'            	=> 'dpr_title',

			'text'            	=> esc_html__( 'Small Size Setting', 'dpr-adeline-extensions' ),

			'param_name'       	=> 'booking_style_title_4',

			'edit_field_class' 	=> 'vc_column vc_col-sm-12',

			'group'	=> esc_html__('Calendar Style', 'dpr-adeline-extensions'),

			),
            array(

                'type'             => 'dpr_switcher',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Use small calendar size style?', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Use small size style?', 'dpr-adeline-extensions'),

                'param_name'       => 'small_style',

                'edit_field_class' => 'vc_column vc_col-sm-12',

                'value'            => 'no',

                'options'          => array(

                    'yes' => array(

                        'yes' => esc_attr__('Yes', 'dpr-adeline-extensions'),

                        'no'  => esc_attr__('No', 'dpr-adeline-extensions'),

                    ),

                ),

                'description' => esc_html__('This attribute let&#x27;s you change the size from the default full size to the &#x22;small&#x22; size if needed. This is good for calendars that are displayed in narrow areas.', 'dpr-adeline-extensions'),

                

                'group'            => esc_html__('Calendar Style', 'dpr-adeline-extensions'),
            ),
			array(

                'type'             => 'colorpicker',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Choose today data background color in small view.', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Today Data Background', 'dpr-adeline-extensions'),

                'param_name'       => 'small_today_bg',

                'edit_field_class' => 'vc_column vc_col-sm-4',

                'value'            => '#f1f8f8',

                'dependency'		=> array('element' => 'small_style', 'value' => 'yes'),

                'group'            => esc_html__('Calendar Style', 'dpr-adeline-extensions'),

            ), 

 			array(

                'type'             => 'colorpicker',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Choose today data color in small view.', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Today Data Color', 'dpr-adeline-extensions'),

                'param_name'       => 'small_today_color',

                'edit_field_class' => 'vc_column vc_col-sm-4',

                'value'            => '#D3AE5F',

                'dependency'		=> array('element' => 'small_style', 'value' => 'yes'),

                'group'            => esc_html__('Calendar Style', 'dpr-adeline-extensions'),

            ), 			
            array(

				'type'				=> 'dpr_clear',

				'param_name'		=> 'clear_4',

				'edit_field_class'	=> 'vc_col-sm-12 vc_column ',

				'group'				=> esc_html__('Calendar Style', 'dpr-adeline-extensions'),

			),        
			array(

                'type'             => 'colorpicker',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Choose today data hover background color in small view.', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Today Data Background:hover', 'dpr-adeline-extensions'),

                'param_name'       => 'small_today_bg_h',

                'edit_field_class' => 'vc_column vc_col-sm-4',

                'value'            => '#D3AE5F',

                'dependency'		=> array('element' => 'small_style', 'value' => 'yes'),

                'group'            => esc_html__('Calendar Style', 'dpr-adeline-extensions'),

            ),
 			array(

                'type'             => 'colorpicker',

                'heading'          => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="' . esc_html__('Choose today data hover color in small view.', 'dpr-adeline-extensions') . '" data-balloon-pos="right"><span></span></span>' . esc_html__('Today Data Color:Hover', 'dpr-adeline-extensions'),

                'param_name'       => 'small_today_color_h',

                'edit_field_class' => 'vc_column vc_col-sm-4',

                'value'            => '#ffffff',

                'dependency'		=> array('element' => 'small_style', 'value' => 'yes'),

                'group'            => esc_html__('Calendar Style', 'dpr-adeline-extensions'),

            ), 





 

/* CSS */

            array(

                'type'       => 'css_editor',

                'heading'    => __('CSS box', 'dpr-adeline-extensions'),

                'param_name' => 'css',

                'group'      => __('Design Options', 'dpr-adeline-extensions'),

            ),

        ),

    )

);
