<?php



/**



 * General Options -> API Integrations



 * 



 */







	Redux::setSection( $opt_name, array(



		'title' => esc_html__('API Integrations', 'dpr-adeline-extensions'),



		'id' => 'general_api_integrations',



		'subsection' => true,



		'fields' => array(



					array(



						'id' => 'google_map_api_key',



						'type' => 'text',



						'title' => esc_html__('Google Map API key', 'dpr-adeline-extensions'),



						'desc' => __('Enter an <a target="_blank" href="https://console.developers.google.com/flows/enableapi?apiid=maps_backend,geocoding_backend,directions_backend,distance_matrix_backend,elevation_backend&amp;keyType=CLIENT_SIDE&amp;reusekey=true">API key</a> for Google Maps.<br>1. Go to the <a target="_blank" href="https://console.developers.google.com/flows/enableapi?apiid=maps_backend,geocoding_backend,directions_backend,distance_matrix_backend,elevation_backend&amp;keyType=CLIENT_SIDE&amp;reusekey=true">Google Developers Console</a>. <br>2. Create or select a project. <br>3. Click Continue to enable the API and any related services.<br>4. On the Credentials page, get a Browser key (and set the API Credentials).'),



						'default' => '',



						'hint' => array(



							'title'   => esc_attr__('Google Map API key','dpr-adeline-extensions'),



							'content' => esc_attr__('Enter Google Map API key. It is necessary for correct display of Google maps on your site','dpr-adeline-extensions')



						)



					),



					)



	));	