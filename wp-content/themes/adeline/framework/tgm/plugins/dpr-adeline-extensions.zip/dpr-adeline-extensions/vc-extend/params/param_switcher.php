<?php

// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}



if(!class_exists('DPR_Switcher_Param')) {



	class DPR_Switcher_Param {

		

		function __construct() {

			add_action( 'admin_enqueue_scripts', array( $this, 'param_scripts' ) );



			if(function_exists('vc_add_shortcode_param')) {

				vc_add_shortcode_param('dpr_switcher' , array(&$this,'switcher') );

			}

		}

		

		function param_scripts($hook) {

		}

		function switcher($settings, $value) {

		$param_name = isset($settings['param_name']) ? $settings['param_name'] : '';

		$type = isset($settings['type']) ? $settings['type'] : '';

		$options = isset($settings['options']) ? $settings['options'] : '';

		$default_set = isset($settings['default_set']) ? $settings['default_set'] : false;

		$class = isset($settings['class']) ? $settings['class'] : '';

		$output = $checked = '';

		$un = uniqid('-'.rand());

		if(is_array($options) && !empty($options)){

			foreach($options as $key => $opts){

				if($value == $key){

					$checked = "checked";

				} else {

					$checked = "";

				}

				$uid = uniqid('-'.rand());

				$output .= '<div class="dpr-switcher-container">

						<input type="checkbox" name="'.esc_attr( $param_name ).'" value="'.esc_attr( $value ).'" class="dpr-switcher wpb_vc_param_value ' . esc_attr( $param_name ) . ' ' . esc_attr( $type ) . ' ' . esc_attr( $class ) . '" id="dpr-switch'.esc_attr( $uid ).'" '.$checked.'>

						<label  for="dpr-switch'.esc_attr( $uid ).'"></label>

					</div>';

					if(isset($opts['label']))

						$lbl = $opts['label'];

					else

						$lbl = '';

				$output .= '<div class="dpr-switcher-label">'.$lbl.'</div><br/>';

			}

		}



		if($default_set)

			$set_value = 'off';

		else

			$set_value = '';



		$output .= '<script>

			jQuery("#dpr-switch'.esc_attr( $uid ).'").change(function(){



				 if(jQuery("#dpr-switch'.esc_attr( $uid ).'").is(":checked")){

					jQuery("#dpr-switch'.esc_attr( $uid ).'").val("'.esc_attr( $key ).'");

					jQuery("#dpr-switch'.esc_attr( $uid ).'").attr("checked","checked");

				 } else {

					jQuery("#dpr-switch'.esc_attr( $uid ).'").val("'.esc_attr( $set_value ).'");

					jQuery("#dpr-switch'.esc_attr( $uid ).'").removeAttr("checked");

				 }



			});

		</script>';		

		

		return $output;

	}

	}

}



if(class_exists('DPR_Switcher_Param')) {

	$DPR_Switcher_Param = new DPR_Switcher_Param();

}

