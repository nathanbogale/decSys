<?php

// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}



/*

  Shortcode: Full Page Slider

 */



class WPBakeryShortCode_DPR_Fp_Slider extends WPBakeryShortCodesContainer {

	

}

vc_map(

	array(

		'name' => esc_html__('DP Full Page Slider', 'dpr-adeline-extensions'),

		'base' => 'dpr_fp_slider',

		'icon' => 'icon-dpr-fp-slider',

		'class' => 'dpr-fp-slider',

		'as_parent' => array('only' =>'dpr_fp_slider_section'),

		'content_element' => true,

		'controls' => 'full',

		'show_settings_on_create' => true,

  		"category" =>array( esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions')),

		'description' => 'Display full page slider',

		'params' => array_merge(array(

			array(

			'type' => 'dpr_radio',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows to choose one of the preset scrolling animation styles.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Section Animation Style', 'dpr-adeline-extensions'),

			'param_name' => 'animation_type',

			'value' => '',

			'edit_field_class'	=> 'vc_col-sm-8 vc_column ',

			'options' => array(

				__('Simple', 'dpr-adeline-extensions') => '',

				__('Scale', 'dpr-adeline-extensions') => 'scale',

				)

			),

			array(

				'type'			=> 'dpr_switcher',

				'heading' 		=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable pagination for this full page slider.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Enable Pagination?', 'dpr-adeline-extensions'),

				'param_name'	=> 'enable_pagination',

				'value' => 'yes',

				'edit_field_class'	=> 'vc_col-sm-4 vc_column ',

				'options'		=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

			),

				),

			),



		)),

		'js_view' => 'VcColumnView'

	)

);





/*** Full Page Slider Section ***/



class WPBakeryShortCode_DPR_Fp_Slider_Section  extends WPBakeryShortCodesContainer {}

vc_map( 

	array(

		"name" =>  __( 'Full Page Slider Section', 'dpr-adeline-extensions' ),

		"base" => "dpr_fp_slider_section",

		"as_parent" => array('only' => 'vc_row'),

		"as_child" => array('only' => 'dpr_fp_slider'),

		"content_element" => true,

		"category" =>array( esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions')),

		"icon" => "icon-dpr-split-slider-item",

		"show_settings_on_create" => true,

		"js_view" => 'VcColumnView',

		'description' => 'Full screen section for Full Page Slider',

		"params" => array(

			array(

			'type' => 'dpr_radio',

			'class' => '',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('You can set custom navigation style for this section', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Navigation Style', 'dpr-adeline-extensions'),

			'param_name' => 'navigation_style',

			'value' => '',

			'options' => array(

				__('Inherit', 'dpr-adeline-extensions') => '',

				__('Dark', 'dpr-adeline-extensions') => 'dark',

				__('Light', 'dpr-adeline-extensions') => 'light'

				)

			),

			array(

				'type' => 'textfield',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enter optional section ID. Make sure it is unique, and it is valid as w3c specification: %s (Must not have spaces).', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Section ID', 'dpr-adeline-extensions'),

				'param_name' => 'el_id',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

			),

			array(

				'type'				=> 'vc_link',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Add a custom link around this section .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Link URL', 'dpr-adeline-extensions'),

				'param_name'		=> 'link',

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

			),

			array(

				'type' => 'textfield',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Extra Class Name', 'dpr-adeline-extensions'),

				'param_name' => 'el_class',

			),

		)

	) 

);

