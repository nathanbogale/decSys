(function(a){function d(b){var c=b||window.event,d=[].slice.call(arguments,1),e=0,f=!0,g=0,h=0;return b=a.event.fix(c),b.type="mousewheel",c.wheelDelta&&(e=c.wheelDelta/120),c.detail&&(e=-c.detail/3),h=e,c.axis!==undefined&&c.axis===c.HORIZONTAL_AXIS&&(h=0,g=-1*e),c.wheelDeltaY!==undefined&&(h=c.wheelDeltaY/120),c.wheelDeltaX!==undefined&&(g=-1*c.wheelDeltaX/120),d.unshift(b,e,g,h),(a.event.dispatch||a.event.handle).apply(this,d)}var b=["DOMMouseScroll","mousewheel"];if(a.event.fixHooks)for(var c=b.length;c;)a.event.fixHooks[b[--c]]=a.event.mouseHooks;a.event.special.mousewheel={setup:function(){if(this.addEventListener)for(var a=b.length;a;)this.addEventListener(b[--a],d,!1);else this.onmousewheel=d},teardown:function(){if(this.removeEventListener)for(var a=b.length;a;)this.removeEventListener(b[--a],d,!1);else this.onmousewheel=null}},a.fn.extend({mousewheel:function(a){return a?this.bind("mousewheel",a):this.trigger("mousewheel")},unmousewheel:function(a){return this.unbind("mousewheel",a)}})})(jQuery)


var $j = jQuery.noConflict();



$j( document ).on( 'ready', function() {

	"use strict";

	// Custom select

	dprInitializeInteractiveShowcase();

} );



/* ==============================================

VERTICAL SHOWCASE

============================================== */

function dprInitializeInteractiveShowcase() {

	"use strict";

	var interactiveShowcase = $j('.dpr-ishowcase-wrapper');
	if (interactiveShowcase.length) {
		interactiveShowcase.each(function(){
			var thisinteractiveShowcase = $j(this),
			slicknavID = thisinteractiveShowcase.find('.dpr-ishowcase-item-content').attr('id'),
			slickimgID = thisinteractiveShowcase.find('.dpr-ishowcase-image-wrapper').attr('id'),			
			singleDesc = thisinteractiveShowcase.find('.dpr-ishowcase-item-description'),
			dataAutoPlay = thisinteractiveShowcase.attr('data-autoplay'),
			$autoplay = false,
			$speed = '',
			linksCount = thisinteractiveShowcase.attr('data-links-count');
			
			

			if (dataAutoPlay > 0 ) {
				$autoplay = true;
				$speed = dataAutoPlay ;
			}
			switch (linksCount) {
			  case '1':
			    $j('#'+slicknavID).slick({
				  slidesToShow: 1,
				  slidesToScroll: 1,
				  autoplay: $autoplay,
      			  autoplaySpeed: $speed,
				  dots: false,
				  arrows: false,
				  vertical: true,
				  asNavFor: '#'+slickimgID,
				  cssEase: 'ease-out',
				  responsive: [
							{
							  breakpoint: 1024,
							  settings: {
								slidesToShow: 2,
								centerMode:false

							  }
							},
							{
							  breakpoint: 600,
							  settings: {
								slidesToShow: 1
							  }
							},									

						  ]
				});			
				break;
					
			  case '3':
				$j('#'+slicknavID).slick({
				  slidesToShow: 3,
				  slidesToScroll: 1,
				  autoplay: $autoplay,
      			  autoplaySpeed: $speed,			  
				  dots: false,
				  arrows: false,
				  vertical: true,
				  centerMode: true,
				  centerPadding: 150,
				  asNavFor: '#'+slickimgID,
				  cssEase: 'ease-out',
				  responsive: [
							{
							  breakpoint: 1024,
							  settings: {
								slidesToShow: 2,
								centerMode:false

							  }
							},
							{
							  breakpoint: 600,
							  settings: {
								slidesToShow: 1
							  }
							},									

						  ]
				});
				break;
			  case '5':
				$j('#'+slicknavID).slick({
				  slidesToShow: 5,
				  slidesToScroll: 1,
				  autoplay: $autoplay,
      			  autoplaySpeed: $speed,		  
				  dots: false,
				  arrows: false,
				  vertical: true,
				  centerMode: true,
				  centerPadding: 0,
				  asNavFor: '#'+slickimgID,
				  cssEase: 'ease-out',
				  responsive: [
							{
							  breakpoint: 1024,
							  settings: {
								slidesToShow: 2,
								centerMode:false

							  }
							},
							{
							  breakpoint: 600,
							  settings: {
								slidesToShow: 1
							  }
							},									

						  ]
				});
				break;
			}

			
			


			$j('#'+slickimgID).slick({
			  slidesToShow: 1,
			  slidesToScroll: 1,
			  dots: false,
			  arrows: false,
			  cssEase: 'cubic-bezier(0.645, 0.045, 0.355, 1.000)',
			  vertical: true,
			  speed: 700
			});

			singleDesc.eq(0).addClass('dpr-active');
			thisinteractiveShowcase.find('#'+slicknavID).on('afterChange', function(event, slick, currentSlide, nextSlide){
			  var thisLink = $j('.slick-current').find('.dpr-ishowcase-item-link'),
				  index = parseInt( thisLink.data('index'), 10 );
			  	  singleDesc.removeClass('dpr-active').eq(index).addClass('dpr-active');
			});

			
			var lastAnimation = 0;
			var animationTime = 700; // in ms
			var quietPeriod = 500; // in ms, time after animation to ignore mousescroll
			var deltaOfInterest = 0;

			function scrollThis(event, delta, deltaX, deltaY) {

				var timeNow = new Date().getTime();

				// change this to deltaX/deltaY depending on which
				// scrolling dir you want to capture
				deltaOfInterest = deltaY;

				if (deltaOfInterest === 0) {
					// Uncomment if you want to use deltaX
					// event.preventDefault();
					return;
				}

				// Cancel scroll if currently animating or within quiet period
				if(timeNow - lastAnimation < quietPeriod + animationTime) {
					event.preventDefault();
					return;
				}

				if (deltaOfInterest < 0) {
					lastAnimation = timeNow;
					$j('#'+slicknavID).slick('slickNext');
				} else {
					lastAnimation = timeNow;
					$j('#'+slicknavID).slick('slickPrev');
				}
			}

			thisinteractiveShowcase.find('.dpr-ishowcase-content-inner').mousewheel(scrollThis);


		});
	}	

}


