<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$output = $uniqid = $el_class  = $delay = $alignment = $stack_list = '';
$animation_class = $animation_style = '';

$atts = vc_map_get_attributes(  $this->getShortcode(), $atts  );
extract( $atts );

$id = uniqid('dpr-image-stack-').'-'.rand(1,9999);

dpr_enqueue_waypoint_js();
dpr_enqueue_animate_css();

if(isset($alignment)) {
	$el_class .= ' items-'.$alignment;
}
		
$output .= '<div id="'.esc_attr($id).'" class="dpr-image-stack-wrap '.esc_attr($el_class).'">';
	
	$max_val_x = $max_val_y = $item_no = 0;
	$translate = -100; $translate_step = 100;
	$animation_delay = - $delay;

	if(isset($stack_list) && !empty($stack_list) && function_exists('vc_param_group_parse_atts')) {
		$stack_list = (array) vc_param_group_parse_atts($stack_list);
		
		foreach($stack_list as $item) {
			
			$image = $offset_x_style = $offset_y_style = '';
			
			if(isset($item['image_id']) && !empty($item['image_id'])) {
				if(isset($item['dpr_animation']) && !empty($item['dpr_animation'])) {
					$animation = str_replace('dpr_','',$item['dpr_animation']);
					$animation_class = 'class="dpr-stack-container';
					if ($animation != 'none' && $animation != '') {
					$animation_class .=' wpb_animate_when_almost_visible wpb_slide'.$animation.' '.$animation.'"';
					}
				}
				$animation_delay = 1000*$item_no*$delay;
				$animation_style = ' style="animation-delay:'.$animation_delay.'ms;"';
				$item_no = ++$item_no;
				$translate = $translate + $translate_step;


				if(!isset($item['offset_x'])) {
					$item['offset_x'] = 0;
				}
				if(!isset($item['offset_y'])) {
					$item['offset_y'] = 0;
				}
				if($item['offset_x'] >= 100) {
					$item['offset_x'] = 100;
				}
				if($item['offset_x'] <= -100) {
					$item['offset_x'] = -100;
				}
				if($item['offset_y'] >= 100) {
					$item['offset_y'] = 100;
				}
				if($item['offset_y'] <= -100) {
					$item['offset_y'] = -100;
				}
				
				if( (isset($item['offset_x']) && strcmp($item['offset_x'], '') != 0) || (isset($item['offset_y']) && strcmp($item['offset_y'], '') != 0) ) {
					$offset_x_style = '-webkit-transform: translate('.esc_attr($item['offset_x']).'%, '.esc_attr($item['offset_y']).'%); -moz-transform: translate('.esc_attr($item['offset_x']).'%, '.esc_attr($item['offset_y']).'%); -o-transform: translate('.esc_attr($item['offset_x']).'%, '.esc_attr($item['offset_y']).'%); transform: translate('.esc_attr($item['offset_x']).'%, '.esc_attr($item['offset_y']).'%);';
				}
				$alt_text = get_post_meta($item['image_id'] , '_wp_attachment_image_alt', true);
				$image_html = '';
				if ( $item['image_size'] == 'custom' && $item['image_width'] != '' && $item['image_height'] != '' ) {
					$img_url 	= dpr_get_attachment_image_src( $item['image_id'], 'full' );
					$img_atts 	= adeline_image_attributes( $img_url[1], $img_url[2], $item['image_width'], $item['image_height'] );
					if (! empty( $img_atts ) ) {
						$image_html = '<img src='.adeline_resize( $img_url[0], $img_atts[ 'width' ], $img_atts[ 'height' ], $img_atts[ 'crop' ], true, $img_atts[ 'upscale' ] ).' alt="'.esc_attr($alt_text).'" width="'.$item['image_width'].'" height="'.$item['image_height'].'" />';
					}
				} else {
					$image = dpr_get_attachment_image_src($item['image_id'], 'full');
					$image_html = '<img src="'.esc_url($image[0]).'" alt ="'.esc_attr($alt_text).'"/>';
				}
				
				
				$output .= '<div '.$animation_class.$animation_style.'>';
					$output .= '<div class="dpr-item-centered" style="'.$offset_x_style.' '.$offset_y_style.'">';
						$output .= '<div class="dpr-stack-item">';
							$output .= $image_html;
						$output .= '</div>';
					$output .= '</div>';
				$output .= '</div>';
			}
		}
		
	}
	
$output .= '</div>';
echo $output;