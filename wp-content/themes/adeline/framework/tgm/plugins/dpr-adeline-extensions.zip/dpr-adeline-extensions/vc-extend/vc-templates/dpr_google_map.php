<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}


$unique_id = $css_animation = $el_class = $output = $custom_el_css = $style = $map_custom_style = $markers_list = '';
$map_height = $height_units = $auto_zoom = $zoom = $disable_all_controls = $map_type_disable = $full_screen_disable = $zoom_control_disable = $street_view_disable = $scrollwheel_disable = '';
$tooltip_text_alignment = $tooltip_max_width = '';
$tooltip_title_color = $tooltip_title_font_size = $tooltip_title_line_height = $tooltip_title_letter_spacing = $tooltip_title_font_style = $title_use_google_fonts = $tooltip_title_google_font = $tooltip_title_typo_style = '';
$tooltip_content_color = $tooltip_content_font_size = $tooltip_content_line_height = $tooltip_content_letter_spacing = $tooltip_content_font_style = $content_use_google_fonts = $tooltip_content_google_font = $tooltip_content_typo_style = '';
$map_wraper_style = $markers_string = $custom_map_style = '';
$markers_array = array();

$atts = vc_map_get_attributes( 'dpr_google_map', $atts );
extract( $atts );
wp_enqueue_script('gmaps', '//maps.googleapis.com/maps/api/js?key='.adeline_get_option_value( 'google_map_api_key', '', '' ), array('jquery'), null, false, true);
wp_enqueue_script('gmap3', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/gmap3.min.js', array('jquery'), null, true);	

$el_class = $this->getExtraClass( $el_class );
if ( '' !== $css_animation && 'none' !== $css_animation ) {
	dpr_enqueue_waypoint_js();
	dpr_enqueue_animate_css();
	$el_class .= ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
}
$unique_id = uniqid('dpr-map-wrap').'-'.rand(1,9999);

/* Element classes */

$css_classes = array(
	'dpr-google-map',
	$el_class,
);

$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->settings['base'], $atts ) );

/* Styles */
if(isset($map_height) && $map_height !='') {
	$map_wraper_style .= 'height:'.$map_height.$height_units.';';
}
if($map_wraper_style != '') {
	$map_wraper_style = ' style="'.$map_wraper_style.'"';
}
if ($style != '') {
	if (dpr_getGoogleMapStyle($style,$map_custom_style) != '') {
		$custom_map_style = 'styles:'.dpr_getGoogleMapStyle($style,$map_custom_style);
	}
}

if(isset($tooltip_max_width) && $tooltip_max_width != '' ) {
	$custom_el_css .= '.'.esc_js($unique_id) .' .tooltip-inner {max-width:'.($tooltip_max_width-50).'px;}';
}

$tooltip_title_typo_style = dpr_generate_typography_style($tooltip_title_color, $tooltip_title_font_size, $tooltip_title_line_height, $tooltip_title_letter_spacing, $tooltip_title_font_style,$tooltip_title_google_font);
$tooltip_content_typo_style = dpr_generate_typography_style($tooltip_content_color, $tooltip_content_font_size, $tooltip_content_line_height, $tooltip_content_letter_spacing, $tooltip_content_font_style,$tooltip_content_google_font);

/* Output */
$output .= '<div class="'.esc_attr($css_class).'">';
$output .= '<div id="'.esc_attr($unique_id).'"'.$map_wraper_style.' class="'.$unique_id.'"></div>';

/* Map settings */
$map_zoom = 14;
if(isset($zoom) && $zoom != '') {
	$map_zoom = $zoom;
}
if($map_type_disable == 'yes' || $disable_all_controls == 'yes') {
	$map_type_control = 'mapTypeControl: false';
} else {
	$map_type_control = 'mapTypeControl: true';
}
if($zoom_control_disable == 'yes' || $disable_all_controls == 'yes') {
	$map_zoom_control = 'zoomControl: false';
} else {
	$map_zoom_control = 'zoomControl: true';
}
if($full_screen_disable == 'yes' || $disable_all_controls == 'yes') {
	$map_fullscreen_control = 'fullscreenControl: false';
} else {
	$map_fullscreen_control = 'fullscreenControl: true';
}
if($scrollwheel_disable == 'yes' || $disable_all_controls == 'yes') {
	$map_scrollweel_control = 'scrollwheel: false';
} else {
	$map_scrollweel_control = 'scrollwheel: true';
}
if($street_view_disable == 'yes' || $disable_all_controls == 'yes') {
	$map_streetview_control = 'streetViewControl: false';
} else {
	$map_streetview_control = 'streetViewControl: true';
}





/* Markers Output */
if(isset($markers_list) && !empty($markers_list) && function_exists('vc_param_group_parse_atts')) {
	$markers_list = (array) vc_param_group_parse_atts($markers_list);
		
		/*Set map center for first marker (if no marker for Paris) */
		$map_center = 'address:"Paris, France"';
		if($markers_list[0] != '') {
			if($markers_list[0]['located_by'] == 'address' && $markers_list[0]['location_address'] !='' ) {
				$map_center = 'address:"'.$markers_list[0]['location_address'].'"';
			}
			if($markers_list[0]['located_by'] == 'lat_long' && $markers_list[0]['location_long'] !='' && $markers_list[0]['location_lat'] !='' ) {
				$map_center = 'center:['.$markers_list[0]['location_lat'].', '.$markers_list[0]['location_long'].']';
			}
		}
		/* Get all markers */
		foreach($markers_list as $marker) {
			$marker_attr = $marker_icon = '';
			$marker_unique = uniqid('marker-content-').'-'.rand(1,9999);
			$marker_url = DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/img/markers/'.$marker['marker_img'].'.png';
			if ($marker['marker_img'] == 'custom') {
				if($marker['marker_image_id'] != '') {
				$custom_marker = dpr_get_attachment_image_src($marker['marker_image_id'], 'full');
				$marker_url = esc_url($custom_marker[0]);
				}
			}
			$marker_attr .= ',icon:"'.$marker_url.'"';
			
			if(isset( $marker['enable_tooltip']) && $marker['enable_tooltip'] == 'yes') {
			$output .= '<div id="'.$marker_unique.'" class="dpr-tooltip-content-div"><div class="tooltip-inner text-'.esc_attr($tooltip_text_alignment).'">';
			if($marker['tooltip_title'] !='') {
			$output .= '<h6 class="map-tooltip-title" '.$tooltip_title_typo_style.'>'.$marker['tooltip_title'].'</h6>';
			}
			if($marker['tooltip_content'] !='') {
			$output .= '<div class="map-tooltip-content" '.$tooltip_content_typo_style.'>'.$marker['tooltip_content'].'</div>';
			}
			$output .= '</div></div>';
			$marker_attr .= ',id:"#'.$marker_unique.'", havetip: true';
			}
			if($marker['located_by'] == 'address') {
				$markers_array[] = '{address:"'.$marker['location_address'].'"'.$marker_attr.'}';
			}
			if($marker['located_by'] == 'lat_long') {
				$markers_array[] = '{position:['.$marker['location_lat'].','.$marker['location_long'].']'.$marker_attr.'}';
			}
		}
		$markers_string .= implode (',', $markers_array);
		
}




if(!empty($custom_el_css)) {
		$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>");'
						. '})(jQuery);'
					. '</script>';
}
?>
<script>
  jQuery(function () {
    jQuery('#<?php echo esc_attr($unique_id) ?>')
      .gmap3({
        <?php echo $map_center ?>,
        zoom:<?php echo $map_zoom ?>,
		<?php echo $map_type_control ?>,
		<?php echo $map_streetview_control ?>,
		<?php echo $map_scrollweel_control ?>,
		<?php echo $map_fullscreen_control ?>,
		<?php echo $map_zoom_control ?>,
		<?php echo $custom_map_style ?>
      })
	  .infowindow({content: ''})
	  .marker([<?php echo $markers_string ?>])
        .on('click', function (marker) {
		  var map = this.get(0); 
		  var infowindow = this.get(1);
		  if (marker.havetip == true) {
		  var content =jQuery(marker.id).html();
		  infowindow.setContent(content);
		  infowindow.open(map, marker);	
		  }
        })
	<?php if(isset($auto_zoom) && $auto_zoom == 'yes') { ?>	
	.fit()
	<?php } ?>
    ;
  });
</script>

<?php
$output .= '</div>';
echo $output;
