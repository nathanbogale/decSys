<?php



/**



 * General Options -> Page Preloader



 * 



 */







	Redux::setSection( $opt_name, array(



		'title' => esc_html__('Page Preloader', 'dpr-adeline-extensions'),



		'id' => 'general_page_preloader',



		'subsection' => true,



		'fields' => array(



					array(



						'id'       => 'page_preloader',



						'type'     => 'switch',



						'title'    =>  esc_html__('Page Preloader','dpr-adeline-extensions'),



						'default' => false,



						'hint' => array(



							'title'   => esc_attr__('Page Preloader','dpr-adeline-extensions'),



							'content' => esc_attr__('You can enable or disable page preloader feature.','dpr-adeline-extensions')



						)



					),



					array(         



						'id'       => 'preloader_bg_color',



						'type'     => 'color',



						'title'    => __('Page Preloader Background Color', 'dpr-adeline-extensions'),



						'output' => array('background-color' => '#dpr-loading'),



						'default'  => '#f1f2f4',



						'hint' => array(



							'title'   => esc_attr__('Page Preloader Background Color','dpr-adeline-extensions'),



							'content' => esc_attr__('Page preloader background color for login page.','dpr-adeline-extensions')



						),



						'required' => array('page_preloader','equals','1')



					),



					array(



						'id'       => 'preloader_image',



						'type'     => 'switch',



						'title'    =>  esc_html__('Use Page Preloader Image?','dpr-adeline-extensions'),



						'default' => false,



						'hint' => array(



							'title'   => esc_attr__('Use Page Preloader Image','dpr-adeline-extensions'),



							'content' => esc_attr__('You can enable or disable page preloader image. Will be dispayed over preloader spinner.','dpr-adeline-extensions')



						),



						'required' => array('page_preloader','equals','1')



					),



					array(



						'id' => 'preloader_image_source',



						'type' => 'media',



						'title' => esc_html__('Page Preloader Image', 'dpr-adeline-extensions'),



						'desc' => wp_kses_post(__('&nbsp;&nbsp;You can use any type of  static image or animated gif.<br/>&nbsp;&nbsp;Great collection of preloaders you can find eg. on <a target ="_blank" href="https://preloaders.net/">Preloaders.net/</a>','dpr-adeline-extensions')),



						'hint' => array(



							'title'   => esc_attr__('Page Preloader Image','dpr-adeline-extensions'),



							'content' => esc_attr__('Select custom image for page preloader.','dpr-adeline-extensions')



						),



						'required' => array('preloader_image','equals','1')



					),



					array(



						'id'       => 'preloader_spinner',



						'type'     => 'switch',



						'title'    =>  esc_html__('Use Predefined CSS Spinner?','dpr-adeline-extensions'),



						'default' => true,



						'hint' => array(



							'title'   => esc_attr__('Use Predefined CSS Spinner','dpr-adeline-extensions'),



							'content' => esc_attr__('You can enable or disable page preloader CSS animated spinner.','dpr-adeline-extensions')



						),



						'required' => array('page_preloader','equals','1')



					),



					array (



						'id' => 'preloader_spinner_type',



						'type' => 'image_select',



						'title' => __('Spinner', 'dpr-adeline-extensions'),



						'options' => array (



							'rotating-plane' => array (



								'alt'   => esc_attr__('Rotating Plane','dpr-adeline-extensions'), 



								'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/preloaders/rotating-plane.png'



							),



							'double-bounce' => array (



								'alt'   => esc_attr__('Double Bounce','dpr-adeline-extensions'), 



								'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/preloaders/double-bounce.png'



							),



							'wave' => array (



								'alt'   => esc_attr__('Wave','dpr-adeline-extensions'), 



								'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/preloaders/wave.png'



							),



							'wanedering-cubes' => 	array (



								'alt'   => esc_attr__('Wandering cubes','dpr-adeline-extensions'), 



								'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/preloaders/wanedering-cubes.png'



							),



							'pulse' => array (



								'alt'   => esc_attr__('Pulse','dpr-adeline-extensions'), 



								'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/preloaders/pulse.png'



							),



							'chasing-dots' => array (



								'alt'   => esc_attr__('Chasing dots','dpr-adeline-extensions'), 



								'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/preloaders/chasing-dots.png'



							),



							'three-bounce' => array (



								'alt'   => esc_attr__('Three bounce','dpr-adeline-extensions'), 



								'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/preloaders/three-bounce.png'



							),				



							'cube-grid' => array (



								'alt'   => esc_attr__('Cube grid','dpr-adeline-extensions'), 



								'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/preloaders/cube-grid.png'



							),				



							'circle' => array (



								'alt'   => esc_attr__('Circle','dpr-adeline-extensions'), 



								'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/preloaders/circle.png'



							),				



							'fading-circle' => array (



								'alt'   => esc_attr__('Fading circle','dpr-adeline-extensions'), 



								'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/preloaders/fadding-circle.png'



							),				



							'folding-cube' => array (



								'alt'   => esc_attr__('Folding cube','dpr-adeline-extensions'), 



								'img' => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/preloaders/folding-cube.png'



							),				



						),



						'default' => 'rotating-plane',



						'hint' => array (



							'title' => esc_attr__('Spinner', 'dpr-adeline-extensions'),



							'content' => esc_attr__('Choose one of predefined CSS spinners.', 'dpr-adeline-extensions')



						),



						'required' => array('preloader_spinner','equals','1')



					),					



					array(         



						'id'       => 'preloader_spinner_color',



						'type'     => 'color',



						'output' =>	array('background-color' => '.dpr-spinner-rotating-plane, .dpr-spinner-double-bounce .dpr-spinner-child, .dpr-spinner-wave .dpr-spinner-rect, .dpr-spinner-wandering-cubes .dpr-spinner-cube, .dpr-spinner-pulse, .dpr-spinner-chasing-dots .dpr-spinner-child, .dpr-spinner-three-bounce .dpr-spinner-child, .dpr-spinner-circle .dpr-spinner-child:before, .dpr-spinner-cube-grid .dpr-spinner-cube, .dpr-spinner-fading-circle .dpr-spinner-circle:before, .dpr-spinner-folding-cube .dpr-spinner-cube:before'),



						'title'    => __('Spinner Color', 'dpr-adeline-extensions'),



						'default'  => '#D3AE5F',



						'hint' => array(



							'title'   => esc_attr__('Spinner Color','dpr-adeline-extensions'),



							'content' => esc_attr__('Set spinner color for page preloader.','dpr-adeline-extensions')



						),



						'required' => array('preloader_spinner','equals','1')



					),



					array(



						'id'       => 'preloader_text',



						'type'     => 'switch',



						'title'    =>  esc_html__('Use Preloader Text?','dpr-adeline-extensions'),



						'default' => false,



						'hint' => array(



							'title'   => esc_attr__('Use Preloader Text?','dpr-adeline-extensions'),



							'content' => esc_attr__('You can enable or disable page preloader text. Will be displayed bellow spinner.','dpr-adeline-extensions')



						),



						'required' => array('page_preloader','equals','1')



					),



					array(



						'id'       => 'preloader_text_content',



						'type'     => 'text',



						'title'    => __('Preloader Text', 'dpr-adeline-extensions'),



						'default'  => 'Loading...',



						'hint' => array(



							'title'   => esc_attr__('Preloader Text','dpr-adeline-extensions'),



							'content' =>  esc_attr__('You can set text for preloader. No HTML allowed.','dpr-adeline-extensions')



						),



						'required' => array('preloader_text','equals','1')



					),



					array(



						'id'          => 'preloader_text_typography',



						'type'        => 'typography', 



						'title'       => __('Preloader Text Typography', 'redux-framework-demo'),



						'google'      => true,



						'letter-spacing' => true,



						'text-transform' => true,



						'all_styles' => true,



						'output'      => array('.dpr-loading-text-holder'),



						'units'       =>'px',



						'default'     => array(



							'color'       => '#555555', 



							'font-style'  => '700', 



							'font-family' => 'Roboto', 



							'google'      => true,



							'font-size'   => '18px', 



							'line-height' => '22px',



							'text-align' => 'center'



						),



						'hint' => array(



							'title'   => esc_attr__('Preloader Text Typography','dpr-adeline-extensions'),



							'content' =>  esc_attr__('You can set typography for preloader text. No HTML allowed.','dpr-adeline-extensions')



						),



						'required' => array('preloader_text','equals','1')



					)



					)



	));