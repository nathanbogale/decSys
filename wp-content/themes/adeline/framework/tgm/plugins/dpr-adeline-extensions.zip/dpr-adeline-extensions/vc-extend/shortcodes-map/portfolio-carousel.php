<?php

// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}

/*

* Add-on Name: Portfolio Carousel

*/



class WPBakeryShortCode_DPR_Portfolio_Carousel extends WPBakeryShortCode {}



vc_map(

	array(

		'name'					=> esc_html__('DP Portfolio Carousel', 'dpr-adeline-extensions'),

		'base'					=> 'dpr_portfolio_carousel',

		"icon"					=> 'icon-dpr-portfolio-carousel',

		"class"					=> 'dpr_portfolio_carousel',

  		"category" =>array( esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions')),

		'description'			=> esc_html__('Display portfolio items carousel', 'dpr-adeline-extensions'),

		'params'				=> array(

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Source Settings', 'dpr-adeline-extensions' ),

				'param_name'       => 'extra_features_title',

				'edit_field_class' => 'vc_column vc_col-sm-12',

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to choose the source for this carousel.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Source Type', 'dpr-adeline-extensions'),

				'param_name'		=> 'source_type',

				'value'				=> 'all',

				'options'			=> array(

					esc_html__('All Items', 'dpr-adeline-extensions')	=> 'all',

					esc_html__('Query', 'dpr-adeline-extensions')	=> 'query',

					esc_html__('Selected Items', 'dpr-adeline-extensions')	=> 'list'

				),

				'edit_field_class'	=> 'vc_col-sm-6 vc_column ',

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set itms count to display.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Items to display', 'dpr-adeline-extensions'),

				'param_name'		=> 'items_to_display',

				'min'				=> 1,

				'value' 			=> 12,

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'dependency' => array('element' => 'source_type', 'value' => array('all','query')),

			),

			array(

				'type' => 'dpr_tax_multi_select',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select categories to include in source.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Categories To Include', 'dpr-adeline-extensions'),

				'param_name' => 'categories_include',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'taxonomy' => 'dpr_portfolio_category',

				'dependency' => array('element' => 'source_type', 'value' => array('query')),

			),

			array(

				'type' => 'dpr_tax_multi_select',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select categories to exclude from source.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Categories To Exclude', 'dpr-adeline-extensions'),

				'param_name' => 'categories_exclude',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'taxonomy' => 'dpr_portfolio_category',

				'dependency' => array('element' => 'source_type', 'value' => array('query')),

			),

			array(

				'type'				=> 'param_group',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Add portfolio items to display.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('List of portfolio items', 'dpr-adeline-extensions'),

				'param_name'		=> 'item_list',

				'params'			=> array(

					array(

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose portfolio item.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Portfolio Item', 'dpr-adeline-extensions'),

						'type'				=> 'dpr_image_post_select',

						'param_name'		=> 'portfolio_item',

						'admin_label' => true,

						'value' 			=> '',

						'edit_field_class' => 'vc_column vc_col-sm-12',

						'post_type' => 'dpr_portfolio'

					),

				),

				'dependency' => array('element' => 'source_type', 'value' => array('list')),

			),

			array(

				'type' => 'dropdown',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Sort by parameter.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Order by', 'dpr-adeline-extensions'),

				'param_name' => 'order_by',

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'value' => array(

						__('None', 'dpr-adeline-extensions') => 'none',

						__('Date', 'dpr-adeline-extensions') => 'date',

						__('Title', 'dpr-adeline-extensions') => 'title',

						__('Name', 'dpr-adeline-extensions') => 'id',

						__('Author', 'dpr-adeline-extensions') => 'author',

					   ),

				'dependency' => array('element' => 'source_type', 'value' => array('all','query')),

			),

			array(

				'type' => 'dropdown',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Sort ascending or descending.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Order by', 'dpr-adeline-extensions'),

				'param_name' => 'order',

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'value' => array(

						__('Ascending sort', 'dpr-adeline-extensions') => 'ASC',

						__('Descending sort', 'dpr-adeline-extensions') => 'DESC'

					   ),

				'dependency' => array('element' => 'source_type', 'value' => array('all','query')),

			),			

			array(

			'type'             => 'dpr_title',

			'text'             => esc_html__( 'Additional Settings', 'dpr-adeline-extensions' ),

			'param_name'       => 'extra_features_title',

			'edit_field_class' => 'vc_column vc_col-sm-12',

		),

			vc_map_add_css_animation( false ),

		    array(

				'type' => 'textfield',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Extra Class Name', 'dpr-adeline-extensions'),

				'param_name' => 'el_class',

			),

			array(

			'type'             => 'dpr_title',

			'text'             => esc_html__( 'Carousel General Settings', 'dpr-adeline-extensions' ),

			'param_name'       => 'carousel_title_1',

			'edit_field_class' => 'vc_column vc_col-sm-12',

			'group'				=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

		),

			array(

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose carousel mode.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Carousel Mode', 'dpr-adeline-extensions'),

				'type'				=> 'dpr_image_select',

				'param_name'		=> 'carousel_mode',

				'value' 			=> 'outside',

				'edit_field_class' => 'vc_column vc_col-sm-8',

				'options'			=> array(

					'default'			=> array(

						'label'			=> esc_html__('Default', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'portfolio/carousel_default.png'

					),

					'center'			=> array(

						'label'			=> esc_html__('Center Mode', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'portfolio/carousel_center.png'

					),

				),

				'group'				=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__(' This settings determine how many of next/prev items will be visible when center mode active.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Center Mode Padding', 'dpr-adeline-extensions'),

				'param_name'		=> 'center_mode_padding',

				'value' 			=> 100,

				'suffix' => 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'dependency'		=> array('element' => 'carousel_mode', 'value' => array('center')),

				'group'				=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

			),

			array(

			'type'            	=> 'dpr_title',

			'text'            	=> '',

			'class'				=> 'separator',

			'param_name'      	=> 'carousel_sep_10',

			'edit_field_class'	=> 'vc_column vc_col-sm-12',

			'group'				=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

		),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__(' This settings determine carousel animation speed.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Slideshow speed', 'dpr-adeline-extensions'),

				'param_name'		=> 'slideshow_speed',

				'value' 			=> 300,

				'prefix'			=> 'ms',

				'edit_field_class'	=> 'vc_column vc_col-sm-3',

				'group'				=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to enable or disable the autoplay for the carousel.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Autoplay', 'dpr-adeline-extensions'),

				'param_name'		=> 'autoplay',

				'edit_field_class' => 'vc_column vc_col-sm-3',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'number',

				'class' => '',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the speed for the autoplay.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Autoplay Speed', 'dpr-adeline-extensions'),

				'param_name' => 'autoplay_speed',

				'value' => '5000',

				'min' => '100',

				'suffix' => 'ms',

				'max' => '10000',

				'step' => '10',

				'edit_field_class' => 'vc_column vc_col-sm-3',

				'dependency' => array('element' => 'autoplay', 'value' => array('yes')),

				'group' => esc_html__('Carousel settings', 'dpr-adeline-extensions'),

			),

			array(

			'type'            	=> 'dpr_title',

			'text'            	=> '',

			'class'				=> 'separator',

			'param_name'      	=> 'carousel_sep_14',

			'edit_field_class'	=> 'vc_column vc_col-sm-12',

			'group'				=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

		),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to enable or disable the dragging of the carousel\'s slides.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Draggable slides', 'dpr-adeline-extensions'),

				'param_name'		=> 'draggable',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_col-sm-3 vc_column ',

				'group'				=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to enable or disable the carousel sliding by swiping on touch devices.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Touch Move', 'dpr-adeline-extensions'),

				'param_name'		=> 'touchable',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_col-sm-3 vc_column ',

				'dependency'		=> array('element' => 'draggable', 'value' => array('yes')),

				'group'				=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

			),

			array(

			'type'            	=> 'dpr_title',

			'text'            	=> esc_html__('Items to show', 'dpr-adeline-extensions'),

			'class'				=> 'small',

			'param_name'      	=> 'carousel_sep_11',

			'edit_field_class'	=> 'vc_column vc_col-sm-12',

			'group'				=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

		),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set slides to show count.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Default', 'dpr-adeline-extensions'),

				'param_name'		=> 'to_show',

				'min'				=> 1,

				'max' 				=> 8,

				'value' 			=> 4,

				'edit_field_class'	=> 'vc_column vc_col-sm-3',

				'group'				=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set slides to show count for desktop.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Desktop', 'dpr-adeline-extensions'),

				'param_name'		=> 'to_show_desktop',

				'min'				=> 1,

				'max' 				=> 8,

				'value' 			=> 3,

				'edit_field_class'	=> 'vc_column vc_col-sm-3',

				'group'				=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set slides to show count for tablets.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Tablet', 'dpr-adeline-extensions'),

				'param_name'		=> 'to_show_tablet',

				'min'				=> 1,

				'max' 				=> 8,

				'value' 			=> 2,

				'edit_field_class'	=> 'vc_column vc_col-sm-3',

				'group'				=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set slides to show count for mobile.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Mobile', 'dpr-adeline-extensions'),

				'param_name'		=> 'to_show_mobile',

				'min'				=> 1,

				'max' 				=> 8,

				'value' 			=> 1,

				'edit_field_class'	=> 'vc_column vc_col-sm-3',

				'group'				=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

			),

			array(

			'type'            	=> 'dpr_title',

			'text'            	=> esc_html__('Items to scroll', 'dpr-adeline-extensions'),

			'class'				=> 'small',

			'param_name'      	=> 'carousel_sep_12',

			'edit_field_class'	=> 'vc_column vc_col-sm-12',

			'group'				=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

		),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set slides to scroll count.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Default', 'dpr-adeline-extensions'),

				'param_name'		=> 'to_scroll',

				'min'				=> 1,

				'max' 				=> 8,

				'value' 			=> 1,

				'edit_field_class'	=> 'vc_column vc_col-sm-3',

				'group'				=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set slides to scroll count for desktop.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Desktop', 'dpr-adeline-extensions'),

				'param_name'		=> 'to_scroll_desktop',

				'min'				=> 1,

				'max' 				=> 8,

				'edit_field_class'	=> 'vc_column vc_col-sm-3',

				'group'				=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set slides to scroll count for tablets.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Tablet', 'dpr-adeline-extensions'),

				'param_name'		=> 'to_scroll_tablet',

				'min'				=> 1,

				'max' 				=> 8,

				'edit_field_class'	=> 'vc_column vc_col-sm-3',

				'group'				=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set slides to scroll count for mobile.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Mobile', 'dpr-adeline-extensions'),

				'param_name'		=> 'to_scroll_mobile',

				'min'				=> 1,

				'max' 				=> 8,

				'edit_field_class'	=> 'vc_column vc_col-sm-3',

				'group'				=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

			),

			array(

			'type'             => 'dpr_title',

			'text'             => esc_html__( 'Carousel Items Settings', 'dpr-adeline-extensions' ),

			'param_name'       => 'carousel_title_2',

			'edit_field_class' => 'vc_column vc_col-sm-12',

			'group'				=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

		),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set spacing for items.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Items Spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'items_margin',

				'suffix'			=> 'px',

				'value' 			=> 20,

				'min'	=> 0,

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'group'				=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set padding for portfolio entry.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Entry Padding', 'dpr-adeline-extensions'),

				'param_name'		=> 'items_padding',

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'group'				=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose entry background color. Default is transparent', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Entry Background Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'items_bg_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'group'				=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set border width for items.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Items Border Width', 'dpr-adeline-extensions'),

				'param_name'		=> 'items_border_width',

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'group'				=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set border radius for items.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Items Border Radius', 'dpr-adeline-extensions'),

				'param_name'		=> 'items_border_radius',

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'group'				=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose items border color. Default is transparent', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Items Border Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'items_border_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'group'				=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

			),

			array(

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose content position for portfolio items.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Items Content Position', 'dpr-adeline-extensions'),

				'type'				=> 'dpr_image_select',

				'param_name'		=> 'content_position',

				'value' 			=> 'outside',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'options'			=> array(

					'outside'			=> array(

						'label'			=> esc_html__('Outside', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'portfolio/outside.png'

					),

					'inside'			=> array(

						'label'			=> esc_html__('Inside(as overlay)', 'dpr-adeline-extensions'),

						'src'				=> $module_images.'portfolio/inside.png'

					),

				),

				'group'				=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

			),

			array(

			'type'            	=> 'dpr_title',

			'class'			  	=> 'small',

			'text'            	=> esc_html__( 'Outside Content Style', 'dpr-adeline-extensions' ),

			'param_name'       	=> 'carousel_title_3',

			'edit_field_class' 	=> 'vc_column vc_col-sm-12',

			'group'				=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

			'dependency'		=> array('element' => 'content_position', 'value' => array('outside')),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set outside content padding.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Outside Content Padding', 'dpr-adeline-extensions'),

				'param_name'		=> 'outside_content_padding',

				'value'				=> 25,

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'content_position', 'value' => array('outside')),

			),

			array(

				'type' => 'dpr_switcher',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('This option allows you to enable use arrow style.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Use Arrow?', 'dpr-adeline-extensions'),

				'param_name' => 'outside_arrowed_style',

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'value' => '',

				'options' => array(

					'yes' => array(

							'label' => '',

							'on' => 'Yes',

							'off' => 'No',

						),

					),

				'group'				=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'content_position', 'value' => array('outside')),

			),			

			array(

				'type' => 'dpr_switcher',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('This option allows you to enable or disable display of entry title.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Display Entry Title?', 'dpr-adeline-extensions'),

				'param_name' => 'outside_display_title',

				'edit_field_class' => 'vc_column vc_col-sm-4',

				'value' => 'yes',

				'options' => array(

					'yes' => array(

							'label' => '',

							'on' => 'Yes',

							'off' => 'No',

						),

					),

				'group'				=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'content_position', 'value' => array('outside')),

			),

			array(

				'type' => 'dpr_switcher',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('This option allows you to enable or disable display of entry category.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Display Entry Category?', 'dpr-adeline-extensions'),

				'param_name' => 'outside_display_category',

				'edit_field_class' => 'vc_column vc_col-sm-4',

				'value' => '',

				'options' => array(

					'yes' => array(

							'label' => '',

							'on' => 'Yes',

							'off' => 'No',

						),

					),

				'group'				=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'content_position', 'value' => array('outside')),

			),

			array(

				'type' => 'dpr_switcher',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('This option allows you to enable or disable display of entry excerpt.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Display Entry Excerpt?', 'dpr-adeline-extensions'),

				'param_name' => 'outside_display_excerpt',

				'edit_field_class' => 'vc_column vc_col-sm-4',

				'value' => '',

				'options' => array(

					'yes' => array(

							'label' => '',

							'on' => 'Yes',

							'off' => 'No',

						),

					),

				'group'				=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'content_position', 'value' => array('outside')),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose title color. Default is as set in Template Options.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Title Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'outside_title_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'outside_display_title', 'value' => array('yes')),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose title hover color. Default is as set in Template Options.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Title Color: Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'outside_title_color_hover',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'outside_display_title', 'value' => array('yes')),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose category link color. Default is as set in Template Options.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Category Link Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'outside_category_link_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'outside_display_category', 'value' => array('yes')),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose category link hover color. Default is as set in Template Options.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Category Link Color: Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'outside_category_link_color_hover',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'outside_display_category', 'value' => array('yes')),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose excerpt color. Default is as set in Template Options.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Excerpt Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'outside_excerpt_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'outside_display_excerpt', 'value' => array('yes')),

			),

			array(

			'type'            	=> 'dpr_title',

			'class'			  	=> 'small',

			'text'            	=> esc_html__( 'Inside Content Style', 'dpr-adeline-extensions' ),

			'param_name'       	=> 'carousel_title_4',

			'edit_field_class' 	=> 'vc_column vc_col-sm-12',

			'group'				=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

			'dependency'		=> array('element' => 'content_position', 'value' => array('inside')),

			),

			array(

				'type' => 'dpr_switcher',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('This option allows you to enable or disable display of entry title.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Display Entry Title?', 'dpr-adeline-extensions'),

				'param_name' => 'inside_display_title',

				'edit_field_class' => 'vc_column vc_col-sm-4',

				'value' => 'yes',

				'options' => array(

					'yes' => array(

							'label' => '',

							'on' => 'Yes',

							'off' => 'No',

						),

					),

				'group'				=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'content_position', 'value' => array('inside')),

			),

			array(

				'type' => 'dpr_switcher',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('This option allows you to enable or disable display of entry category.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Display Entry Category?', 'dpr-adeline-extensions'),

				'param_name' => 'inside_display_category',

				'edit_field_class' => 'vc_column vc_col-sm-4',

				'value' => '',

				'options' => array(

					'yes' => array(

							'label' => '',

							'on' => 'Yes',

							'off' => 'No',

						),

					),

				'group'				=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'content_position', 'value' => array('inside')),

			),

			array(

				'type' => 'dpr_switcher',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('This option allows you to enable or disable display of entry excerpt.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Display Entry excerpt?', 'dpr-adeline-extensions'),

				'param_name' => 'inside_display_excerpt',

				'edit_field_class' => 'vc_column vc_col-sm-4',

				'value' => '',

				'options' => array(

					'yes' => array(

							'label' => '',

							'on' => 'Yes',

							'off' => 'No',

						),

					),

				'group'				=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'content_position', 'value' => array('inside')),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose title color. Default is as set in Template Options.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Title Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'inside_title_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'inside_display_title', 'value' => array('yes')),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose title hover color. Default is as set in Template Options.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Title Color: Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'inside_title_color_hover',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'inside_display_title', 'value' => array('yes')),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose category link color. Default is as set in Template Options.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Category Link Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'inside_category_link_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'inside_display_category', 'value' => array('yes')),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose category link hover color. Default is as set in Template Options.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Category Link Color: Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'inside_category_link_color_hover',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'inside_display_category', 'value' => array('yes')),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose excerpt color. Default is as set in Template Options.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Excerpt Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'inside_excerpt_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

				'group'				=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'inside_display_excerpt', 'value' => array('yes')),

			),

			array(

			'type'            	=> 'dpr_title',

			'class'			  	=> 'small',

			'text'            	=> esc_html__( 'Portfolio Entry Decoration && Hover State', 'dpr-adeline-extensions' ),

			'param_name'       	=> 'carousel_title_5',

			'edit_field_class' 	=> 'vc_column vc_col-sm-12',

			'group'				=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'dropdown',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set shadow for portfolio items.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Item Shadow', 'dpr-adeline-extensions'),

				'param_name' => 'item_shadow',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'value' => array(

						__('None', 'dpr-adeline-extensions') => '',

						__('Shadow Depth 1', 'dpr-adeline-extensions') => '1',

						__('Shadow Depth 2', 'dpr-adeline-extensions') => '2',

						__('Shadow Depth 3', 'dpr-adeline-extensions') => '3',

						__('Shadow Depth 4', 'dpr-adeline-extensions') => '4',

						__('Shadow Depth 5', 'dpr-adeline-extensions') => '5',

						__('Shadow Depth 6', 'dpr-adeline-extensions') => '6',

						__('Custom Shadow', 'dpr-adeline-extensions') => 'custom',

					   ),

				'group'	=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

			),

			array(

				"type" => "dpr_shadow_picker",

				"class" => "",

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom shadow for portfolio items.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom Shadow', 'dpr-adeline-extensions'),

				"param_name" => "item_shadow_custom",

				"value" => "none||||||",

				'dependency'		=> array('element' => 'item_shadow', 'value' => array('custom')),

				'group'	=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'dropdown',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set hover shadow for portfolio items.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Item Shadow: Hover', 'dpr-adeline-extensions'),

				'param_name' => 'item_shadow_hover',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'value' => array(

						__('None', 'dpr-adeline-extensions') => '',

						__('Shadow Depth 1', 'dpr-adeline-extensions') => '1',

						__('Shadow Depth 2', 'dpr-adeline-extensions') => '2',

						__('Shadow Depth 3', 'dpr-adeline-extensions') => '3',

						__('Shadow Depth 4', 'dpr-adeline-extensions') => '4',

						__('Shadow Depth 5', 'dpr-adeline-extensions') => '5',

						__('Shadow Depth 6', 'dpr-adeline-extensions') => '6',

						__('Custom Shadow', 'dpr-adeline-extensions') => 'custom',

					   ),

				'group'	=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

			),

			array(

				"type" => "dpr_shadow_picker",

				"class" => "",

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom shadow for portfolio items hover state.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom Shadow: Hover', 'dpr-adeline-extensions'),

				"param_name" => "item_shadow_hover_custom",

				"value" => "none||||||",

				'dependency'		=> array('element' => 'item_shadow_hover', 'value' => array('custom')),

				'group'	=> esc_html__('Carousel settings', 'dpr-adeline-extensions'),

			),

			array(

			'type'            	=> 'dpr_title',

			'class'			  	=> 'small',

			'text'            	=> esc_html__( 'Image Settings', 'dpr-adeline-extensions' ),

			'param_name'       	=> 'overlay_title_1',

			'edit_field_class' 	=> 'vc_column vc_col-sm-12',

			'group'	=> esc_html__('Image & Overlay', 'dpr-adeline-extensions'),	

			),

			array(

				'type' => 'dropdown',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set image size', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Image size', 'dpr-adeline-extensions'),

				'param_name' => 'entry_img_size',

				'edit_field_class' => 'vc_column vc_col-sm-4',

				'std'	=> 'medium',

				'value' => array(

								esc_html__('Thumbnail', 'dpr-adeline-extensions') => 'thumbnail',

								esc_html__('Medium', 'dpr-adeline-extensions') => 'medium',

								esc_html__('Medium Large', 'dpr-adeline-extensions') => 'medium_large',

								esc_html__('Large', 'dpr-adeline-extensions') => 'large',

								esc_html__('Full', 'dpr-adeline-extensions') => 'full',

								esc_html__('Custom', 'dpr-adeline-extensions') => 'custom',

					   ),

				'group'	=> esc_html__('Image & Overlay', 'dpr-adeline-extensions'),	

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom image width.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom Image width', 'dpr-adeline-extensions'),

				'param_name'		=> 'entry_img_width',

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 no-padding-top',

				'group'	=> esc_html__('Image & Overlay', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'entry_img_size', 'value' => 'custom'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom image height.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom Image width', 'dpr-adeline-extensions'),

				'param_name'		=> 'entry_img_height',

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 no-padding-top',

				'group'	=> esc_html__('Image & Overlay', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'entry_img_size', 'value' => 'custom'),

			),

			array(

			'type'            	=> 'dpr_title',

			'class'			  	=> 'small',

			'text'            	=> esc_html__( 'Overlay Settings', 'dpr-adeline-extensions' ),

			'param_name'       	=> 'overlay_title_2',

			'edit_field_class' 	=> 'vc_column vc_col-sm-12',

			'group'	=> esc_html__('Image & Overlay', 'dpr-adeline-extensions'),	

			),

			array (

				'type' => 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set image overlay style.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Image Overlay Type', 'dpr-adeline-extensions'),

				'param_name' => 'entry_overlay_type',

				'value' => 'solid',

				'edit_field_class'	=> 'vc_column vc_col-sm-4 ',

				'options' => array (

					esc_attr__('Solid Color', 'dpr-adeline-extensions') => 'solid',

					esc_attr__('Gradient', 'dpr-adeline-extensions') => 'gradient'

				),

				'group'	=> esc_html__('Image & Overlay', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose image overlay color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Image Overlay Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'overlay_color',

				'value' => 'rgba(0,0,0,0.4)',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'group'	=> esc_html__('Image & Overlay', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'entry_overlay_type', 'value' => 'solid'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set overlay spacing if you wish make overlay smaller as image.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Overlay spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'overlay_spacing',

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'group'	=> esc_html__('Image & Overlay', 'dpr-adeline-extensions'),

			),

			array(

			'type'            	=> 'dpr_title',

			'class'			  	=> 'separator',

			'text'            	=> '',

			'param_name'       	=> 'carousel_sep_2',

			'edit_field_class' 	=> 'vc_column vc_col-sm-12',

			'group'	=> esc_html__('Image & Overlay', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'dpr_gradient_picker',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the gradient background for button. Solid color set above will be ignored', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Gradient background', 'dpr-adeline-extensions'),

				'param_name' => 'overlay_gradient',

				'value' => '45;0%/rgba(75, 50, 255, 0.5);100%/rgba(13, 193, 255, 0.5)',

				'group'	=> esc_html__('Image & Overlay', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'entry_overlay_type', 'value' => 'gradient'),

			),

			array(

			'type'            	=> 'dpr_title',

			'class'			  	=> 'small',

			'text'            	=> esc_html__( 'Overlay Icons Settings', 'dpr-adeline-extensions' ),

			'param_name'       	=> 'overlay_title_3',

			'edit_field_class' 	=> 'vc_column vc_col-sm-12',

			'group'	=> esc_html__('Image & Overlay', 'dpr-adeline-extensions'),	

			),

			array (

				'type' => 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set image overlay icons style.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Overlay Icons Style', 'dpr-adeline-extensions'),

				'param_name' => 'overlay_icons_style',

				'value' => 'icons',

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'options' => array (

					esc_attr__('No Icons', 'dpr-adeline-extensions') => 'none',

					esc_attr__('Icons', 'dpr-adeline-extensions') => 'icons',

					esc_attr__('Plus sign', 'dpr-adeline-extensions') => 'plus'

				),

				'group'	=> esc_html__('Image & Overlay', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set overlay icons size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Overlay icons size', 'dpr-adeline-extensions'),

				'param_name'		=> 'overlay_icons_size',

				'value' => 45,

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'group'	=> esc_html__('Image & Overlay', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'overlay_icons_style', 'value' => 'icons'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set overlay icons font size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Overlay icons font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'overlay_icons_font_size',

				'value' => 16,

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'group'	=> esc_html__('Image & Overlay', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'overlay_icons_style', 'value' => 'icons'),

			),

			array (

				'type' => 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set image overlay link icon type.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Link Icon', 'dpr-adeline-extensions'),

				'param_name' => 'link_icon_type',

				'value' => 'theme-default',

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'options' => array (

					esc_attr__('None', 'dpr-adeline-extensions') => 'none',			

					esc_attr__('Theme Default', 'dpr-adeline-extensions') => 'theme-default',

					esc_attr__('Custom', 'dpr-adeline-extensions') => 'custom'

				),

				'group'	=> esc_html__('Image & Overlay', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'overlay_icons_style', 'value' => 'icons'),

			),

			array(

				'type' => 'dropdown',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select icon library for link icon .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom Link Icon Library ', 'dpr-adeline-extensions'),

				'value' => array(

					__( 'Font Awesome', 'dpr-adeline-extensions' ) => 'fontawesome',

					__( 'Open Iconic', 'dpr-adeline-extensions' ) => 'openiconic',

					__( 'Typicons', 'dpr-adeline-extensions' ) => 'typicons',

					__( 'Entypo', 'dpr-adeline-extensions' ) => 'entypo',

					__( 'Linecons', 'dpr-adeline-extensions' ) => 'linecons'

				),

				'param_name' => 'link_icon_lib',

				'description' => __( 'Select icon library.', 'dpr-adeline-extensions' ),

				'dependency' => array(

					'element' => 'link_icon_type',

					'value' => 'custom',

				),

				'group'	=> esc_html__('Image & Overlay', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'iconpicker',

				'heading' => __( 'Icon', 'dpr-adeline-extensions' ),

				'param_name' => 'link_icon_fontawesome',

				'value' => 'fa fa-external-link',

				'settings' => array(

					'emptyIcon' => false,

					// default true, display an "EMPTY" icon?

					'iconsPerPage' => 4000,

					// default 100, how many icons per/page to display

				),

				'dependency' => array(

					'element' => 'link_icon_lib',

					'value' => 'fontawesome',

				),

				'description' => __( 'Select icon from library.', 'dpr-adeline-extensions' ),

				'group'	=> esc_html__('Image & Overlay', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'iconpicker',

				'heading' => __( 'Icon', 'dpr-adeline-extensions' ),

				'param_name' => 'link_icon_openiconic',

				'value' => 'vc-oi vc-oi-link',

				'settings' => array(

					'emptyIcon' => false,

					// default true, display an "EMPTY" icon?

					'type' => 'openiconic',

					'iconsPerPage' => 4000,

					// default 100, how many icons per/page to display

				),

				'dependency' => array(

					'element' => 'link_icon_lib',

					'value' => 'openiconic',

				),

				'description' => __( 'Select icon from library.', 'dpr-adeline-extensions' ),

				'group'	=> esc_html__('Image & Overlay', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'iconpicker',

				'heading' => __( 'Icon', 'dpr-adeline-extensions' ),

				'param_name' => 'link_icon_typicons',

				'value' => 'typcn typcn-link',

				'settings' => array(

					'emptyIcon' => false,

					// default true, display an "EMPTY" icon?

					'type' => 'typicons',

					'iconsPerPage' => 4000,

					// default 100, how many icons per/page to display

				),

				'dependency' => array(

					'element' => 'link_icon_lib',

					'value' => 'typicons',

				),

				'description' => __( 'Select icon from library.', 'dpr-adeline-extensions' ),

				'group'	=> esc_html__('Image & Overlay', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'iconpicker',

				'heading' => __( 'Icon', 'dpr-adeline-extensions' ),

				'param_name' => 'link_icon_entypo',

				'value' => 'entypo-icon entypo-icon-link',

				'settings' => array(

					'emptyIcon' => false,

					// default true, display an "EMPTY" icon?

					'type' => 'entypo',

					'iconsPerPage' => 4000,

					// default 100, how many icons per/page to display

				),

				'dependency' => array(

					'element' => 'link_icon_lib',

					'value' => 'entypo',

				),

				'group'	=> esc_html__('Image & Overlay', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'iconpicker',

				'heading' => __( 'Icon', 'dpr-adeline-extensions' ),

				'param_name' => 'link_icon_linecons',

				'value' => 'vc_li vc_li-clip',

				'settings' => array(

					'emptyIcon' => false,

					// default true, display an "EMPTY" icon?

					'type' => 'linecons',

					'iconsPerPage' => 4000,

					// default 100, how many icons per/page to display

				),

				'dependency' => array(

					'element' => 'link_icon_lib',

					'value' => 'linecons',

				),

				'description' => __( 'Select icon from library.', 'dpr-adeline-extensions' ),

				'group'	=> esc_html__('Image & Overlay', 'dpr-adeline-extensions'),

			),

			array (

				'type' => 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set image overlay zoom icon type.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Zoom Icon', 'dpr-adeline-extensions'),

				'param_name' => 'zoom_icon_type',

				'value' => 'theme-default',

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'options' => array (

					esc_attr__('None', 'dpr-adeline-extensions') => 'none',			

					esc_attr__('Theme Default', 'dpr-adeline-extensions') => 'theme-default',

					esc_attr__('Custom', 'dpr-adeline-extensions') => 'custom'

				),

				'group'	=> esc_html__('Image & Overlay', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'overlay_icons_style', 'value' => 'icons'),

			),

			array(

				'type' => 'dropdown',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Select icon library for zoom icon .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom Zoom Icon Library ', 'dpr-adeline-extensions'),

				'value' => array(

					__( 'Font Awesome', 'dpr-adeline-extensions' ) => 'fontawesome',

					__( 'Open Iconic', 'dpr-adeline-extensions' ) => 'openiconic',

					__( 'Typicons', 'dpr-adeline-extensions' ) => 'typicons',

					__( 'Entypo', 'dpr-adeline-extensions' ) => 'entypo',

					__( 'Linecons', 'dpr-adeline-extensions' ) => 'linecons'

				),

				'param_name' => 'zoom_icon_lib',

				'description' => __( 'Select icon library.', 'dpr-adeline-extensions' ),

				'dependency' => array(

					'element' => 'zoom_icon_type',

					'value' => 'custom',

				),

				'group'	=> esc_html__('Image & Overlay', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'iconpicker',

				'heading' => __( 'Icon', 'dpr-adeline-extensions' ),

				'param_name' => 'zoom_icon_fontawesome',

				'value' => 'fa fa-search-plus',

				'settings' => array(

					'emptyIcon' => false,

					// default true, display an "EMPTY" icon?

					'iconsPerPage' => 4000,

					// default 100, how many icons per/page to display

				),

				'dependency' => array(

					'element' => 'zoom_icon_lib',

					'value' => 'fontawesome',

				),

				'description' => __( 'Select icon from library.', 'dpr-adeline-extensions' ),

				'group'	=> esc_html__('Image & Overlay', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'iconpicker',

				'heading' => __( 'Icon', 'dpr-adeline-extensions' ),

				'param_name' => 'zoom_icon_openiconic',

				'value' => 'vc-oi vc-oi-resize-full',

				'settings' => array(

					'emptyIcon' => false,

					// default true, display an "EMPTY" icon?

					'type' => 'openiconic',

					'iconsPerPage' => 4000,

					// default 100, how many icons per/page to display

				),

				'dependency' => array(

					'element' => 'zoom_icon_lib',

					'value' => 'openiconic',

				),

				'description' => __( 'Select icon from library.', 'dpr-adeline-extensions' ),

				'group'	=> esc_html__('Image & Overlay', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'iconpicker',

				'heading' => __( 'Icon', 'dpr-adeline-extensions' ),

				'param_name' => 'zoom_icon_typicons',

				'value' => 'typcn typcn-arrow-maximise',

				'settings' => array(

					'emptyIcon' => false,

					// default true, display an "EMPTY" icon?

					'type' => 'typicons',

					'iconsPerPage' => 4000,

					// default 100, how many icons per/page to display

				),

				'dependency' => array(

					'element' => 'zoom_icon_lib',

					'value' => 'typicons',

				),

				'description' => __( 'Select icon from library.', 'dpr-adeline-extensions' ),

				'group'	=> esc_html__('Image & Overlay', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'iconpicker',

				'heading' => __( 'Icon', 'dpr-adeline-extensions' ),

				'param_name' => 'zoom_icon_entypo',

				'value' => 'entypo-icon entypo-icon-resize-full',

				'settings' => array(

					'emptyIcon' => false,

					// default true, display an "EMPTY" icon?

					'type' => 'entypo',

					'iconsPerPage' => 4000,

					// default 100, how many icons per/page to display

				),

				'dependency' => array(

					'element' => 'zoom_icon_lib',

					'value' => 'entypo',

				),

				'group'	=> esc_html__('Image & Overlay', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'iconpicker',

				'heading' => __( 'Icon', 'dpr-adeline-extensions' ),

				'param_name' => 'zoom_icon_linecons',

				'value' => 'vc_li vc_li-search',

				'settings' => array(

					'emptyIcon' => false,

					// default true, display an "EMPTY" icon?

					'type' => 'linecons',

					'iconsPerPage' => 4000,

					// default 100, how many icons per/page to display

				),

				'dependency' => array(

					'element' => 'zoom_icon_lib',

					'value' => 'linecons',

				),

				'description' => __( 'Select icon from library.', 'dpr-adeline-extensions' ),

				'group'	=> esc_html__('Image & Overlay', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose overlay icons color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icons Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'overlay_icons_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'group'	=> esc_html__('Image & Overlay', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'overlay_icons_style', 'value' => 'icons'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose overlay icons background color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icons Background', 'dpr-adeline-extensions'),

				'param_name'		=> 'overlay_icons_bg',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'group'	=> esc_html__('Image & Overlay', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'overlay_icons_style', 'value' => 'icons'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose overlay icons border color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icons Border', 'dpr-adeline-extensions'),

				'param_name'		=> 'overlay_icons_border',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'group'	=> esc_html__('Image & Overlay', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'overlay_icons_style', 'value' => 'icons'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose overlay icons hover color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icons Color: Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'overlay_icons_color_hover',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'group'	=> esc_html__('Image & Overlay', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'overlay_icons_style', 'value' => 'icons'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose overlay icons background hover color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icons Background: Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'overlay_icons_bg_hover',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'group'	=> esc_html__('Image & Overlay', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'overlay_icons_style', 'value' => 'icons'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose overlay icons border hover color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Icons Border: Hover', 'dpr-adeline-extensions'),

				'param_name'		=> 'overlay_icons_border_hover',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'group'	=> esc_html__('Image & Overlay', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'overlay_icons_style', 'value' => 'icons'),

			),

			array (

				'type' => 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose where to link the plus sign.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Plus Sign Link', 'dpr-adeline-extensions'),

				'param_name' => 'plus_link',

				'value' => 'lightbox',

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'options' => array (

					esc_attr__('Lightbox', 'dpr-adeline-extensions') => 'lightbox',

					esc_attr__('Portfolio Item', 'dpr-adeline-extensions') => 'item',

				),

				'group'	=> esc_html__('Image & Overlay', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'overlay_icons_style', 'value' => 'plus'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set plus sign size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Plus sign size', 'dpr-adeline-extensions'),

				'param_name'		=> 'plus_size',

				'value' => 45,

				'suffix'			=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'group'	=> esc_html__('Image & Overlay', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'overlay_icons_style', 'value' => 'plus'),

			),

			array(

				'type'				=> 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose plus sign color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Plus Sign Color', 'dpr-adeline-extensions'),

				'param_name'		=> 'plus_color',

				'edit_field_class'	=> 'vc_column vc_col-sm-4',

				'value'  => 'rgba(255,255,255,0.8)',

				'group'	=> esc_html__('Image & Overlay', 'dpr-adeline-extensions'),

				'dependency'		=> array('element' => 'overlay_icons_style', 'value' => 'plus'),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to add the pagination dots for your carousel.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Pagination Dots', 'dpr-adeline-extensions'),

				'param_name'		=> 'dots',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Pagination', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'dpr_image_select',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Select style for pagination dots', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Dots Style', 'dpr-adeline-extensions'),

				'param_name' => 'dots_style',

				'weight' => '1',

				'value' => 'outline-round',

				'options'			=> array(

					'outline-square'			=> array(

						'label'			=> esc_html__('Square','dpr-adeline-extension'),

						'src'				=> $module_images . 'dots/square.png'

					),

					'outline-round'			=> array(

						'label'			=> esc_html__('Radio','dpr-adeline-extension'),

						'src'				=> $module_images . 'dots/radio.png'

					),

					'flat-round'			=> array(

						'label'			=> esc_html__('Point','dpr-adeline-extension'),

						'src'				=> $module_images . 'dots/points.png'

					),

					'flat-square'			=> array(

						'label'			=> esc_html__('Fill Square','dpr-adeline-extension'),

						'src'				=> $module_images . 'dots/filled-square.png'

					),

					'flat-rounded'			=> array(

						'label'			=> esc_html__('Fill Rounded','dpr-adeline-extension'),

						'src'				=> $module_images . 'dots/filled-rounded.png'

					),

					'outline-bar'			=> array(

						'label'			=> esc_html__('Bar','dpr-adeline-extension'),

						'src'				=> $module_images . 'dots/bars.png'

					),

					'flat-bar'			=> array(

						'label'			=> esc_html__('Fill Bar','dpr-adeline-extension'),

						'src'				=> $module_images . 'dots/filed-bars.png'

					)

				),

				'dependency' => array('element' => 'dots', 'value' => array('yes')),

				'group'				=> esc_html__('Pagination', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_radio',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to choose the horizontal alignment for pagination.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Pagination Alignment', 'dpr-adeline-extensions'),

				'param_name'		=> 'pagination_alignment',

				'value'				=> 'pagination-center',

				'options'			=> array(

					esc_html__('Left', 'dpr-adeline-extensions')	=> 'pagination-left',

					esc_html__('Center', 'dpr-adeline-extensions')	=> 'pagination-center',

					esc_html__('Right', 'dpr-adeline-extensions')	=> 'pagination-right'

				),

				'dependency' => array('element' => 'dots', 'value' => array('yes')),

				'group'				=> esc_html__('Pagination', 'dpr-adeline-extensions'),

			),

				array(

				'type' => 'colorpicker',

				'class' => '',

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Choose color for the active dot. The default color is inherited from Theme Options > Styling Options > Main Accent Color', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Active dot color', 'dpr-adeline-extensions'),

				'param_name' => 'dots_color',

				'value' => '',

				'dependency' => array('element' => 'dots', 'value' => array('yes')),

				'group'				=> esc_html__('Pagination', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'colorpicker',

				'class' => '',

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Choose color for the inactive dot.','dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('InActive dot color', 'dpr-adeline-extensions'),

				'param_name' => 'dots_color_inactive',

				'value' => '',

				'dependency' => array('element' => 'dots', 'value' => array('yes')),

				'group'				=> esc_html__('Pagination', 'dpr-adeline-extensions'),

			),

			array (

				'type' => 'number',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set the space between dots. Default is 14px.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Dots Spacing', 'dpr-adeline-extensions'),

				'param_name' => 'dots_spacing',

				'suffix' => 'px',

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'dependency' => array('element' => 'dots', 'value' => array('yes')),

				'group'				=> esc_html__('Pagination', 'dpr-adeline-extensions'),

			),

			array (

				'type' => 'number',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set the top margin for dots. Default is 15px.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Dots Top Margin', 'dpr-adeline-extensions'),

				'param_name' => 'dots_top_margin',

				'suffix' => 'px',

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'dependency' => array('element' => 'dots', 'value' => array('yes')),

				'group'				=> esc_html__('Pagination', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to enable or disable the carousel navigation arrows.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Navigation Arrows?', 'dpr-adeline-extensions'),

				'param_name'		=> 'arrows',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Navigation', 'dpr-adeline-extensions'),

			),

			array(

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to choose the navigation arrows position.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Arrows position', 'dpr-adeline-extensions'),

				'type'				=> 'dpr_image_select',

				'param_name'		=> 'arrows_position',

				'value' => 'aside-outside',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'options'			=> array(

					'aside'	=> array(

						'label'	=> esc_html__('Aside','dpr-adeline-extensions'),

						'src'		=> $module_images . 'carousel/arrows-aside.png'

					),

					'aside-outside'	=> array(

						'label'	=> esc_html__('Outside','dpr-adeline-extensions'),

						'src'		=> $module_images . 'carousel/arrows-aside-outside.png'

					),

					'top-center'	=> array(

						'label'	=> esc_html__('Top','dpr-adeline-extensions'),

						'src'		=> $module_images . 'carousel/arrows-top.png'

					),

					'bottom-center'	=> array(

						'label'	=> esc_html__('Bottom','dpr-adeline-extensions'),

						'src'		=> $module_images . 'carousel/arrows-bottom.png'

					),

				),

				'group'				=> esc_html__('Navigation', 'dpr-adeline-extensions'),

				'dependency' => array('element' => 'arrows', 'value' => array('yes')),

			),

			array (

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the arrow style.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Arrow Type', 'dpr-adeline-extensions'),

				'type'				=> 'dpr_image_select',

				'param_name' => 'arrow_icon',

				'value'=>'arrow_type-1',

				'options'			=> array(

					'arrow-type-1'	=> array(

						'label'	=> esc_html__('Type 1','dpr-adeline-extensions'),

						'src'		=> $module_images . 'carousel/arrows-01.png'

					),

					'arrow-type-2'	=> array(

						'label'	=> esc_html__('Type 2','dpr-adeline-extensions'),

						'src'		=> $module_images . 'carousel/arrows-02.png'

					),

					'arrow-type-3'	=> array(

						'label'	=> esc_html__('Type 3','dpr-adeline-extensions'),

						'src'		=> $module_images . 'carousel/arrows-03.png'

					),

					'arrow-type-4'	=> array(

						'label'	=> esc_html__('Type 4','dpr-adeline-extensions'),

						'src'		=> $module_images . 'carousel/arrows-04.png'

					),

					'arrow-type-5'	=> array(

						'label'	=> esc_html__('Type 5','dpr-adeline-extensions'),

						'src'		=> $module_images . 'carousel/arrows-05.png'

					),

					'arrow-type-6'	=> array(

						'label'	=> esc_html__('Type 6','dpr-adeline-extensions'),

						'src'		=> $module_images . 'carousel/arrows-06.png'

					),

				),

				'dependency' => array('element' => 'arrows', 'value' => array('yes')),

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group' => esc_html__('Navigation', 'dpr-adeline-extensions'),

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Arrow Icon Style', 'dpr-adeline-extensions' ),

				'param_name'       => 'arrows_title_1',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group' => esc_attr__('Navigation', 'dpr-adeline-extensions'),

				'dependency' => array('element' => 'arrows', 'value' => array('yes')),

			),

			array (

				'type' => 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose icon color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Arrow Color', 'dpr-adeline-extensions'),

				'param_name' => 'arrow_icon_color',

				'edit_field_class' => 'vc_column vc_col-sm-4 ',

				'dependency' => array('element' => 'arrows', 'value' => array('yes')),

				'group' => esc_html__('Navigation', 'dpr-adeline-extensions'),

			),

			array (

				'type' => 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('CChoose icon hover color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Arrow Color: Hover', 'dpr-adeline-extensions'),

				'param_name' => 'arrow_icon_color_hover',

				'edit_field_class' => 'vc_column vc_col-sm-4',

				'dependency' => array('element' => 'arrows', 'value' => array('yes')),

				'group' => esc_html__('Navigation', 'dpr-adeline-extensions'),

			),

			array (

				'type' => 'number',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set the size of the icon. Default is 10px.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Arrow Icon Size', 'dpr-adeline-extensions'),

				'param_name' => 'arrow_icon_size',

				'suffix' => 'px',

				'edit_field_class' => 'vc_column vc_col-sm-4',

				'dependency' => array('element' => 'arrows', 'value' => array('yes')),

				'group' => esc_html__('Navigation', 'dpr-adeline-extensions'),

			),

			array(

				'type'             => 'dpr_title',

				'text'             => esc_html__( 'Arrow Background Style', 'dpr-adeline-extensions' ),

				'param_name'       => 'arrows_title_2',

				'edit_field_class' => 'vc_column vc_col-sm-12',

				'group' => esc_attr__('Navigation', 'dpr-adeline-extensions'),

				'dependency' => array('element' => 'arrows', 'value' => array('yes')),

			),

			array (

				'type' => 'number',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set border radius for the icon\'s background.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background border radius', 'dpr-adeline-extensions'),

				'param_name' => 'arrow_bg_border_radius',

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'group' => esc_attr__('Navigation', 'dpr-adeline-extensions'),

				'dependency' => array('element' => 'arrows', 'value' => array('yes')),

			),

			array (

				'type' => 'number',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set border width for the icon\'s background.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background border width', 'dpr-adeline-extensions'),

				'param_name' => 'arrow_bg_border_width',

				'suffix' => 'px',

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'group' => esc_attr__('Navigation', 'dpr-adeline-extensions'),

				'dependency' => array('element' => 'arrows', 'value' => array('yes')),

			),

			array (

				'type' => 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set the icon\'s background color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background color', 'dpr-adeline-extensions'),

				'param_name' => 'arrow_bg_color',

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'group' => esc_attr__('Navigation', 'dpr-adeline-extensions'),

				'dependency' => array('element' => 'arrows', 'value' => array('yes')),

			),

			array (

				'type' => 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to set the icon\'s hover background color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Background color: Hover', 'dpr-adeline-extensions'),

				'param_name' => 'arrow_bg_color_hover',

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'group' => esc_attr__('Navigation', 'dpr-adeline-extensions'),

				'dependency' => array('element' => 'arrows', 'value' => array('yes')),

			),

			array (

				'type' => 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the border color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border color', 'dpr-adeline-extensions'),

				'param_name' => 'arrow_bg_border_color',

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'group' => esc_attr__('Navigation', 'dpr-adeline-extensions'),

				'dependency' => array('element' => 'arrows', 'value' => array('yes')),

			),

			array (

				'type' => 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the hover border color.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Border color: Hover', 'dpr-adeline-extensions'),

				'param_name' => 'arrow_bg_border_color_hover',

				'edit_field_class' => 'vc_column vc_col-sm-6',

				'group' => esc_attr__('Navigation', 'dpr-adeline-extensions'),

				'dependency' => array('element' => 'arrows', 'value' => array('yes')),

			),

			array(

				'type' => 'dpr_switcher',

				'param_name' => 'arrow_use_shadow_on_hover',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Allows you to show the shadow for the arrow.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Shadow on hover', 'dpr-adeline-extensions'),

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group' => esc_attr__('Navigation', 'dpr-adeline-extensions'),

				'dependency' => array('element' => 'arrows', 'value' => array('yes')),

			),

			array(

				"type" => "dpr_shadow_picker",

				"class" => "",

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set hover shadow for aroow.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Shadow', 'dpr-adeline-extensions'),

				"param_name" => "arrow_hover_shadow",

				"value" => "||||||",

				'dependency'		=> array('element' => 'arrow_use_shadow_on_hover', 'value' => array('yes')),

				'group'				=> esc_html__('Navigation', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'dpr_switcher',

				'param_name' => 'arrow_allways_visible',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Make arrows allways visible?', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Arrows allways visible?', 'dpr-adeline-extensions'),

				'edit_field_class' => 'vc_column vc_col-sm-4',

				'value' => 'yes',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group' => esc_attr__('Navigation', 'dpr-adeline-extensions'),

				'dependency' => array('element' => 'arrows', 'value' => array('yes')),

			),

			array(

				'type' => 'dpr_switcher',

				'param_name' => 'arrow_use_numbers',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Use navigation numbers above the arrows?', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Use Navigation Numbers?', 'dpr-adeline-extensions'),

				'edit_field_class' => 'vc_column vc_col-sm-4',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group' => esc_attr__('Navigation', 'dpr-adeline-extensions'),

				'dependency' => array('element' => 'arrows', 'value' => array('yes')),

			),

			array (

				'type' => 'colorpicker',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Choose the color for the numbers. The default color is #292933.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Numbers color', 'dpr-adeline-extensions'),

				'param_name' => 'arrow_numbers_color',

				'edit_field_class' => 'vc_column vc_col-sm-4',

				'dependency' => array(

					'element' => 'arrow_use_numbers',

					'value' => 'yes',

				),

				'group' => esc_html__('Navigation', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Tilte Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_typography_head',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size. If you leave this field blank will be used default size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title linne height.Default is 18px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom title letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'title_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

	  		),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font. .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'title_use_google_fonts',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'title_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'dependency'		=> array('element' => 'title_use_google_fonts', 'value' => 'yes'),

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),



			array(

				'type'				=> 'dpr_title',

				'text'				=> esc_html__('Category Typography', 'dpr-adeline-extensions'),

				'param_name'		=> 'category_typography_head',

				'class'				=> '',

				'edit_field_class'	=> 'vc_column vc_col-sm-12',

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font size. If you leave this field blank will be used default size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font size', 'dpr-adeline-extensions'),

				'param_name'		=> 'category_font_size',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom category linne height.Default is 18px .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Line Height', 'dpr-adeline-extensions'),

				'param_name'		=> 'category_line_height',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom category letter sapacing. Default is 0 .', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Letter spacing', 'dpr-adeline-extensions'),

				'param_name'		=> 'category_letter_spacing',

				'min'				=> 1,

				'suffix'				=> 'px',

				'edit_field_class'	=> 'vc_column vc_col-sm-3 ',

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type' => 'checkbox',

				'class' => '',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom font style', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Font style', 'dpr-adeline-extensions'),

				'param_name' => 'category_font_style',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'value' => array(

						__('<i>Italic</i>','dpr-adeline-extensions') => 'italic',

						__('<u>Underline</u>','dpr-adeline-extensions') => 'underline',

						__('<b>Bold</b>','dpr-adeline-extensions') => 'bold',

					),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

	  		),

			array(

				'type'				=> 'dpr_switcher',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Enable custom Google font. .', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Custom font family', 'dpr-adeline-extensions'),

				'param_name'		=> 'category_use_google_fonts',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 ',

				'options'			=> array(

					'yes'				=> array(

						'yes'				=> esc_attr__('Yes', 'dpr-adeline-extensions'),

						'no'				=> esc_attr__('No', 'dpr-adeline-extensions'),

					),

				),

				'group'				=> esc_html__('Typography', 'dpr-adeline-extensions'),

			),

			array(

				'type'				=> 'google_fonts',

				'param_name'		=> 'category_google_font',

				'settings'			=> array(

					'fields'			=> array(

						'font_family_description' => esc_html__('Select font family.', 'dpr-adeline-extensions'),

						'font_style_description'  => esc_html__('Select font style.', 'dpr-adeline-extensions'),

					),

				),

				'edit_field_class'	=> 'vc_column vc_col-sm-12 ',

				'dependency'		=> array('element' => 'category_use_google_fonts', 'value' => 'yes'),

				'group'				=> esc_attr__('Typography', 'dpr-adeline-extensions'),

			),		

		),

	)

);