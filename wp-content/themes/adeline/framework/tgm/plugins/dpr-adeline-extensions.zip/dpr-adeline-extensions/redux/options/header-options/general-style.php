<?php

/**



 * Header Options -> General Style



 *



 */

Redux::setSection($opt_name, array(

    'title'      => esc_html__('General Style', 'dpr-adeline-extensions'),

    'id'         => 'header_general',

    'subsection' => true,

    'fields'     => array(

        array(

            'id'      => 'header_style',

            'type'    => 'image_select',

            'title'   => __('Header Style', 'dpr-adeline-extensions'),

            'options' => array(

                'default'         => array(

                    'title' => esc_html__('Default', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/header-styles/default.png',

                ),

                'center'          => array(

                    'title' => esc_html__('Center Logo', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/header-styles/center.png',

                ),

                'top'             => array(

                    'title' => esc_html__('Top Logo', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/header-styles/logo-top.png',

                ),

                'minimal'         => array(

                    'title' => esc_html__('Minimal', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/header-styles/minimal.png',

                ),

                'magazine'        => array(

                    'title' => esc_html__('Magazine', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/header-styles/magazine.png',

                ),

                'full_screen'     => array(

                    'title' => esc_html__('Fullscreen', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/header-styles/fullscreen.png',

                ),

                'vertical'        => array(

                    'title' => esc_html__('Vertical', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/header-styles/vertical.png',

                ),

                'custom'          => array(

                    'title' => esc_html__('Custom Horizontal', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/header-styles/custom-h.png',

                ),

                'custom_vertical' => array(

                    'title' => esc_html__('Custom Vertical', 'dpr-adeline-extensions'),

                    'img'   => DPR_EXTENSIONS_PLUGIN_URL . 'redux/redux-framework/assets/img/header-styles/custom-v.png',

                ),

            ),

            'default' => 'default',

            'hint'    => array(

                'title'   => esc_attr__('Header Style', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Choose default header style. This general settings can be overwriten for specific pages.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'default_header_info',

            'type'     => 'info',

            'style'    => 'dpr-title',

            'title'    => wp_kses_post(__('<h3>Default Header Specific Settings</h3>', 'dpr-adeline-extensions')),

            'required' => array('header_style', 'equals', array('default')),

        ),

        array(

            'id'       => 'center_header_info',

            'type'     => 'info',

            'style'    => 'dpr-title',

            'title'    => wp_kses_post(__('<h3>Center Header Specific Settings</h3>', 'dpr-adeline-extensions')),

            'required' => array('header_style', 'equals', array('center')),

        ),

        array(

            'id'       => 'top_header_info',

            'type'     => 'info',

            'style'    => 'dpr-title',

            'title'    => wp_kses_post(__('<h3>Top Header Specific Settings</h3>', 'dpr-adeline-extensions')),

            'required' => array('header_style', 'equals', array('top')),

        ),

        array(

            'id'       => 'minimal_header_info',

            'type'     => 'info',

            'style'    => 'dpr-title',

            'title'    => wp_kses_post(__('<h3>Minimal Header Specific Settings</h3>', 'dpr-adeline-extensions')),

            'required' => array('header_style', 'equals', array('minimal')),

        ),

        array(

            'id'       => 'magazine_header_info',

            'type'     => 'info',

            'style'    => 'dpr-title',

            'title'    => wp_kses_post(__('<h3>Magazine Header Specific Settings</h3>', 'dpr-adeline-extensions')),

            'required' => array('header_style', 'equals', array('magazine')),

        ),

        array(

            'id'       => 'fullscreen_header_info',

            'type'     => 'info',

            'style'    => 'dpr-title',

            'title'    => wp_kses_post(__('<h3>Full Screen Header Specific Settings</h3>', 'dpr-adeline-extensions')),

            'required' => array('header_style', 'equals', array('full_screen')),

        ),

        array(

            'id'       => 'custom_header_info',

            'type'     => 'info',

            'style'    => 'dpr-title',

            'title'    => wp_kses_post(__('<h3>Custom Header Specific Settings</h3>', 'dpr-adeline-extensions')),

            'required' => array('header_style', 'contains', 'custom'),

        ),

// Custom Header Settings

        array(

            'id'       => 'header_particle_selected',

            'type'     => 'select',

            'data'     => 'posts',

            'args'     => array('post_type' => array('dpr_particle'), 'posts_per_page' => -1),

            'title'    => esc_html__('Custom Header Template', 'dpr-adeline-extensions'),

            'desc'     => __('Please note that you need first create custom template in Particles menu'),

            'hint'     => array(

                'title'   => esc_attr__('Header Template', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Create custom header template first.', 'dpr-adeline-extensions'),

            ),

            'required' => array('header_style', 'contains', 'custom'),

        ),

        array(

            'id'       => 'vertical_header_info',

            'type'     => 'info',

            'style'    => 'dpr-title',

            'title'    => wp_kses_post(__('<h3>Vertical Header Specific Settings</h3>', 'dpr-adeline-extensions')),

            'required' => array('header_style', 'contains', 'vertical'),

        ),

// Default & Center Header specifing settings

        array(

            'id'       => 'header_height',

            'type'     => 'dimensions',

            'title'    => esc_html__('Header Height (px)', 'dpr-adeline-extensions'),

            'output'   => array('height' => '#dpr-logo #dpr-logo-inner,.dpr-adeline-social-menu .social-menu-inner,.full_screen-header .menu-bar-inner,.minimal-header .menu-bar-inner'),

            'width'    => false,

            'height'   => true,

            'mode'     => array('width' => 'width', 'height' => 'height'),

            'units'    => array('px'),

            'default'  => array(

                'height' => '90px',

            ),

            'hint'     => array(

                'title'   => esc_attr__('Header Height', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify the header height.', 'dpr-adeline-extensions'),

            ),

            'required' => array('header_style', 'equals', array('default', 'center', 'minimal', 'full_screen')),

        ),

        array(

            'id'       => 'header_bg_color',

            'type'     => 'color',

            'output'   => array('background-color' => '#dpr-header,.vertical-header-overlapping-used .is-sticky #dpr-header.vertical-header,#searchform-header-replace'),

            'validate' => 'color',

            'title'    => esc_html__('Header Background Color', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'required' => array('header_style', 'equals', array('default', 'center', 'minimal', 'full_screen')),

            'hint'     => array(

                'title'   => esc_attr__('Header Background Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set header background color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'menu_alignment',

            'type'     => 'radio',

            'title'    => __('Menu Alignment', 'dpr-adeline-extensions'),

            'options'  => array(

                'left-menu'   => 'Left',

                'center-menu' => 'Center',

                'right-menu'  => 'Right',

            ),

            'default'  => 'right-menu',

            'required' => array('header_style', 'equals', array('default')),

            'hint'     => array(

                'title'   => esc_attr__('Menu Alignment', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set default menu alignment', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'center_header_menu_alignment',

            'type'     => 'radio',

            'title'    => __('Center Header Menus Position', 'dpr-adeline-extensions'),

            'options'  => array(

                'outside-aligned' => 'Outside aligned',

                'centered'        => 'Centered',

                'inside-aligned'  => 'Inside aligned',

            ),

            'default'  => 'inside-aligned',

            'required' => array('header_style', 'equals', 'center'),

            'hint'     => array(

                'title'   => esc_attr__('Center Header Menus Position', 'dpr-adeline-extensions'),

                'content' => esc_attr__('You can set default menus alignment in center header style', 'dpr-adeline-extensions'),

            ),

        ),

// Top Header specifing settings

        array(

            'id'             => 'top_header_logo_padding',

            'type'           => 'spacing',

            'output'         => array('#dpr-header.top-header .top-header-wrapper'),

            'mode'           => 'padding',

            'units'          => array('px'),

            'display_units'  => true,

            'units_extended' => false,

            'left'           => false,

            'right'          => false,

            'title'          => __('Logo Vertical Padding (px)', 'dpr-adeline-extensions'),

            'default'        => array(

                'padding-top'    => '30px',

                'padding-bottom' => '30px',

                'units'          => 'px',

            ),

            'required'       => array('header_style', 'equals', 'top'),

            'hint'           => array(

                'title'   => esc_attr__('Logo Vertical Padding', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Choose default verticl padding for logo.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'top_header_top_bg_color',

            'type'     => 'color',

            'output'   => array('background-color' => '#dpr-header.top-header .top-header-wrapper'),

            'validate' => 'color',

            'title'    => esc_html__('Logo Area Background Color', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'required' => array('header_style', 'equals', 'top'),

            'hint'     => array(

                'title'   => esc_attr__('Logo Area Background Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set logo area background color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'top_header_nav_height',

            'type'     => 'dimensions',

            'title'    => esc_html__('Navigation Bar Height (px)', 'dpr-adeline-extensions'),

            'output'   => array('height' => '#dpr-header.top-header #dpr-navigation-wrapper'),

            'width'    => false,

            'height'   => true,

            'mode'     => array('width' => 'width', 'height' => 'height'),

            'units'    => array('px'),

            'default'  => array(

                'height' => '70px',

            ),

            'hint'     => array(

                'title'   => esc_attr__('Navigation Bar Height', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify top header navigation bar height.', 'dpr-adeline-extensions'),

            ),

            'required' => array('header_style', 'equals', 'top'),

        ),

        array(

            'id'             => 'top_header_nav_item_padding',

            'type'           => 'spacing',

            'output'         => array('#dpr-header.top-header #dpr-navigation-wrapper .dropdown-menu > li > a'),

            'mode'           => 'padding',

            'units'          => array('px'),

            'display_units'  => true,

            'units_extended' => false,

            'top'            => false,

            'bottom'         => false,

            'title'          => __('Menu Items Padding (px)', 'dpr-adeline-extensions'),

            'default'        => array(

                'padding-left'  => '20px',

                'padding-right' => '20px',

                'units'         => 'px',

            ),

            'required'       => array('header_style', 'equals', 'top'),

            'hint'           => array(

                'title'   => esc_attr__('Menu Item Padding', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Choose default padding for menu items.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'top_header_nav_bg_color',

            'type'     => 'color',

            'output'   => array('background-color' => '#dpr-header.top-header .bottom-header-wrapper'),

            'validate' => 'color',

            'title'    => esc_html__('Navigation Bar Background Color', 'dpr-adeline-extensions'),

            'default'  => '#f1f2f4',

            'required' => array('header_style', 'equals', 'top'),

            'hint'     => array(

                'title'   => esc_attr__('Navigation Bar Background Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set navigation bar background color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'top_header_only_menu_sticky',

            'type'     => 'switch',

            'default'  => false,

            'title'    => esc_html__('Sticky Only Menu', 'dpr-adeline-extensions'),

            'required' => array('header_style', 'equals', array('top')),

            'hint'     => array(

                'title'   => esc_attr__('Sticky Only menu', 'dpr-adeline-extensions'),

                'content' => esc_attr__('If enabled in sticky header will be only menu displayed ', 'dpr-adeline-extensions'),

            ),

        ),

// Magazine Header specifing settings

        array(

            'id'             => 'magazine_header_top_area_padding',

            'type'           => 'spacing',

            'output'         => array('#dpr-header.magazine-header .top-header-wrapper'),

            'mode'           => 'padding',

            'units'          => array('px'),

            'display_units'  => true,

            'units_extended' => false,

            'left'           => false,

            'right'          => false,

            'title'          => __('Top Area Vertical Padding (px)', 'dpr-adeline-extensions'),

            'default'        => array(

                'padding-top'    => '30px',

                'padding-bottom' => '30px',

                'units'          => 'px',

            ),

            'required'       => array('header_style', 'equals', 'magazine'),

            'hint'           => array(

                'title'   => esc_attr__('Top Area Vertical Padding', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Choose default verticl padding for top area.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'magazine_header_top_bg_color',

            'type'     => 'color',

            'output'   => array('background-color' => '#dpr-header.magazine-header .top-header-wrapper'),

            'validate' => 'color',

            'title'    => esc_html__('Top Area Background Color', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'required' => array('header_style', 'equals', 'magazine'),

            'hint'     => array(

                'title'   => esc_attr__('Top Area Background Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set top area background color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'magazine_header_content_type',

            'type'     => 'radio',

            'title'    => __('Header Content Type', 'dpr-adeline-extensions'),

            'options'  => array(

                'default' => 'Default',

                'custom'  => 'Custom Template',

            ),

            'default'  => 'default',

            'required' => array('header_style', 'equals', 'magazine'),

            'hint'     => array(

                'title'   => esc_attr__('Header Content Type', 'dpr-adeline-extensions'),

                'content' => esc_attr__('By default is used HTML content entered bellow but you can also use custom template from Particles library. ', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'magazine_header_content',

            'type'     => 'textarea',

            'title'    => __('Header Content', 'dpr-adeline-extensions'),

            'validate' => 'html',

            'desc'     => __('<i><small>HTML is allowed.</small></i>'),

            'default'  => '',

            'hint'     => array(

                'title'   => esc_attr__('Header Content', 'dpr-adeline-extensions'),

                'content' => esc_attr__('You can enter magazine header content here. HTML is allowed', 'dpr-adeline-extensions'),

            ),

            'required' => array('magazine_header_content_type', 'equals', 'default'),

        ),

        array(

            'id'       => 'magazine_header_particle_selected',

            'type'     => 'select',

            'data'     => 'posts',

            'args'     => array('post_type' => array('dpr_particle'), 'posts_per_page' => -1),

            'title'    => esc_html__('Custom Header Content Template', 'dpr-adeline-extensions'),

            'desc'     => __('Please note that you need first create custom content template in Particles menu'),

            'hint'     => array(

                'title'   => esc_attr__('Custom Header Content Template', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Select previously prepared particle to display in magazine header content area. ', 'dpr-adeline-extensions'),

            ),

            'required' => array('magazine_header_content_type', 'equals', 'custom'),

        ),

        array(

            'id'       => 'magazine_header_nav_bg_color',

            'type'     => 'color',

            'output'   => array('background-color' => '#dpr-header.magazine-header .bottom-header-wrapper'),

            'validate' => 'color',

            'title'    => esc_html__('Navigation Bar Background Color', 'dpr-adeline-extensions'),

            'default'  => '#f1f2f4',

            'required' => array('header_style', 'equals', 'magazine'),

            'hint'     => array(

                'title'   => esc_attr__('Navigation Bar Background Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set navigation bar background color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'magazine_header_only_menu_sticky',

            'type'     => 'switch',

            'default'  => false,

            'title'    => esc_html__('Sticky Only Menu', 'dpr-adeline-extensions'),

            'required' => array('header_style', 'equals', array('magazine')),

            'hint'     => array(

                'title'   => esc_attr__('Sticky Only menu', 'dpr-adeline-extensions'),

                'content' => esc_attr__('If enabled in sticky header will be only menu displayed ', 'dpr-adeline-extensions'),

            ),

        ),

// Fullscreen Header specifing settings

        array(

            'id'       => 'fullscreen_appear_effect',

            'type'     => 'select',

            'title'    => esc_html__('Fullscreen Menu Appearance Effect', 'dpr-adeline-extensions'),

            'desc'     => '',

            'options'  => array(

                'overlay-hugeinc'     => esc_html__('Fade', 'dpr-adeline-extensions'),

                'overlay-corner'      => esc_html__('Corner', 'dpr-adeline-extensions'),

                'overlay-slidedown'   => esc_html__('Slide Down', 'dpr-adeline-extensions'),

                'overlay-scale'       => esc_html__('Scale', 'dpr-adeline-extensions'),

                'overlay-simplegenie' => esc_html__('Genie', 'dpr-adeline-extensions'),

            ),

            'default'  => 'overlay-hugeinc',

            'hint'     => array(

                'title'   => esc_attr__('Fullscreen Menu Appearance Effect', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Select the appear animation effect for the full screen menu.', 'dpr-adeline-extensions'),

            ),

            'required' => array('header_style', 'equals', array('full_screen')),

        ),

        array(

            'id'       => 'fullscreen_hamburger_color',

            'type'     => 'color',

            'output'   => array('background-color' => '.full_screen-header .menu-bar .opener,.full_screen-header .menu-bar .opener:before, .full_screen-header .menu-bar .opener:after'),

            'validate' => 'color',

            'title'    => esc_html__('Hamburger Color', 'dpr-adeline-extensions'),

            'default'  => '#292933',

            'required' => array('header_style', 'equals', array('full_screen')),

            'hint'     => array(

                'title'   => esc_attr__('Hamburger Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set hamburger color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'fullscreen_hamburger_close_color',

            'type'     => 'color',

            'output'   => array('background-color' => ' .full_screen-header .menu-bar.close-menu .opener:before, .full_screen-header .menu-bar.close-menu .opener:after'),

            'validate' => 'color',

            'title'    => esc_html__('Hamburger Color Close', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'required' => array('header_style', 'equals', array('full_screen')),

            'hint'     => array(

                'title'   => esc_attr__('Hamburger Color Close', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set hamburger close color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'fullscreen_menu_bg',

            'type'     => 'color',

            'output'   => array('background-color' => '.full_screen-header #full-screen-menu'),

            'validate' => 'color',

            'title'    => esc_html__('Full Screen Menu Background Color', 'dpr-adeline-extensions'),

            'default'  => 'rgba(17,25,34,0.95)',

            'required' => array('header_style', 'equals', array('full_screen')),

            'hint'     => array(

                'title'   => esc_attr__('Full Screen Menu Background Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set full screen overlay background color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'fullscreen_link_color',

            'type'     => 'color',

            'output'   => array('color' => '.full_screen-header .fs-dropdown-menu > li > a'),

            'validate' => 'color',

            'title'    => esc_html__('Full Screen Menu Link Color', 'dpr-adeline-extensions'),

            'default'  => '#cccccc',

            'required' => array('header_style', 'equals', array('full_screen')),

            'hint'     => array(

                'title'   => esc_attr__('Full Screen Menu Link Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set full screen menu link color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'fullscreen_hover_link_color',

            'type'     => 'color',

            'output'   => array('color' => '.full_screen-header .fs-dropdown-menu > li > a:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Full Screen Menu Link Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'required' => array('header_style', 'equals', array('full_screen')),

            'hint'     => array(

                'title'   => esc_attr__('Full Screen Menu Link Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set full screen menu link hover color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'fullscreen_custom_logo',

            'type'     => 'switch',

            'default'  => false,

            'title'    => esc_html__('Display Custom Logo', 'dpr-adeline-extensions'),

            'required' => array('header_style', 'equals', array('full_screen')),

            'hint'     => array(

                'title'   => esc_attr__('Display Custom Logo', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enable or disable display of custom logo ', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'fullscreen_logo',

            'type'     => 'media',

            'title'    => esc_html__('Logo', 'dpr-adeline-extensions'),

            'required' => array('fullscreen_custom_logo', 'equals', '1'),

            'hint'     => array(

                'title'   => esc_attr__('Logo', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Select image for fullscreen logo', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'fullscreen_logo_retina',

            'type'     => 'media',

            'title'    => esc_html__('Retina Logo', 'dpr-adeline-extensions'),

            'required' => array('fullscreen_custom_logo', 'equals', '1'),

            'hint'     => array(

                'title'   => esc_attr__('Logo', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Select image for fullscreen retina logo', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'fullscreen_search_form',

            'type'     => 'switch',

            'default'  => false,

            'title'    => esc_html__('Display Serch Field', 'dpr-adeline-extensions'),

            'required' => array('header_style', 'equals', array('full_screen')),

            'hint'     => array(

                'title'   => esc_attr__('Display Serch Form', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enable or disable serch field bellow menu ', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'fullscreen_search_color',

            'type'     => 'color',

            'output'   => array('color' => '.full_screen-header .fs-dropdown-menu>li.search-toggle-li input,.full_screen-header .fs-dropdown-menu>li.search-toggle-li label',

                'background-color'          => '.full_screen-header .fs-dropdown-menu>li.search-toggle-li label i'),

            'validate' => 'color',

            'title'    => esc_html__('Search Input Color', 'dpr-adeline-extensions'),

            'default'  => 'rgba(255,255,255,.8)',

            'required' => array('fullscreen_search_form', 'equals', '1'),

            'hint'     => array(

                'title'   => esc_attr__('Search Input Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set color for search input.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'fullscreen_search_underline_color',

            'type'     => 'color',

            'output'   => array('border-color' => '.full_screen-header .fs-dropdown-menu>li.search-toggle-li input'),

            'validate' => 'color',

            'title'    => esc_html__('Search Input Underline Color', 'dpr-adeline-extensions'),

            'default'  => 'rgba(255,255,255,.8)',

            'required' => array('fullscreen_search_form', 'equals', '1'),

            'hint'     => array(

                'title'   => esc_attr__('Search Input Underline Color: Active', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set color for search input underline.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'fullscreen_search_underline_color_active',

            'type'     => 'color',

            'output'   => array('border-color' => '.full_screen-header .fs-dropdown-menu>li.search-toggle-li input:hover, .full_screen-header .fs-dropdown-menu>li.search-toggle-li input:focus '),

            'validate' => 'color',

            'title'    => esc_html__('Search Input Underline Color: Focus', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'required' => array('fullscreen_search_form', 'equals', '1'),

            'hint'     => array(

                'title'   => esc_attr__('Full Screen Menu Link Color: Focus', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set color for search focus and active input underline', 'dpr-adeline-extensions'),

            ),

        ),

// Vertical Header specifing settings

        array(

            'id'       => 'vertical_header_position',

            'type'     => 'radio',

            'title'    => __('Header Position', 'dpr-adeline-extensions'),

            'options'  => array(

                'left-header'  => 'Left',

                'right-header' => 'Right',

            ),

            'default'  => 'left-header',

            'required' => array('header_style', 'contains', 'vertical'),

            'hint'     => array(

                'title'   => esc_attr__('Header Position', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set default header position', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'vertical_header_expandable',

            'type'     => 'switch',

            'default'  => false,

            'title'    => esc_html__('Header Expandable', 'dpr-adeline-extensions'),

            'required' => array('header_style', 'contains', 'vertical'),

            'hint'     => array(

                'title'   => esc_attr__('Header Expandable', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Make header hidden on load and expandable on hamburger click.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'vertical_header_hamburger_color',

            'type'     => 'color',

            'output'   => array('background-color' => '#dpr-header.vertical-header .vertical-toggle .opener, #dpr-header.vertical-header .vertical-toggle .opener:before, #dpr-header.vertical-header .vertical-toggle .opener:after'),

            'validate' => 'color',

            'title'    => esc_html__('Hamburger Icon Color', 'dpr-adeline-extensions'),

            'default'  => '#292933',

            'required' => array('vertical_header_expandable', 'equals', '1'),

            'hint'     => array(

                'title'   => esc_attr__('Hamburger Icon Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set hamburger icon color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'vertical_header_width',

            'type'     => 'dimensions',

            'title'    => esc_html__('Header Width (px)', 'dpr-adeline-extensions'),

            'output'   => array('width' => '#dpr-header.vertical-header'),

            'width'    => true,

            'height'   => false,

            'mode'     => array('width' => 'width', 'height' => 'height'),

            'units'    => array('px'),

            'default'  => array(

                'width' => '300px',

            ),

            'hint'     => array(

                'title'   => esc_attr__('Width', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Specify vertical header width.', 'dpr-adeline-extensions'),

            ),

            'required' => array('header_style', 'equals', 'vertical'),

        ),

        array(

            'id'       => 'vertical_header_bg',

            'type'     => 'color',

            'output'   => array('background-color' => '#dpr-header.vertical-header'),

            'validate' => 'color',

            'title'    => esc_html__('Background Color', 'dpr-adeline-extensions'),

            'default'  => '#ffffff',

            'required' => array('header_style', 'contains', 'vertical'),

            'hint'     => array(

                'title'   => esc_attr__('Background Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set vertical header background color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'vertical_header_shadow',

            'type'     => 'switch',

            'default'  => false,

            'title'    => esc_html__('Use Shadow', 'dpr-adeline-extensions'),

            'required' => array('header_style', 'contains', 'vertical'),

            'hint'     => array(

                'title'   => esc_attr__('Use Shadow', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enable or disable box shadow effect for header ', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'             => 'vertical_header_padding',

            'type'           => 'spacing',

            'output'         => array('#dpr-header.vertical-header #dpr-header-inner'),

            'mode'           => 'padding',

            'units'          => array('px'),

            'display_units'  => true,

            'units_extended' => false,

            'title'          => __('Inner Padding (px)', 'dpr-adeline-extensions'),

            'default'        => array(

                'padding-top'    => '30px',

                'padding-bottom' => '30px',

                'padding-left'   => '30px',

                'padding-right'  => '30px',

                'units'          => 'px',

            ),

            'required'       => array('header_style', 'equals', 'vertical'),

            'hint'           => array(

                'title'   => esc_attr__('Padding', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Choose default inner padding for verticalheader.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'vertical_header_logo_position',

            'type'     => 'radio',

            'title'    => __('Logo Position', 'dpr-adeline-extensions'),

            'options'  => array(

                'left-logo'   => 'Left',

                'center-logo' => 'Center',

                'right-logo'  => 'Right',

            ),

            'default'  => 'center-logo',

            'required' => array('header_style', 'contains', 'vertical'),

            'hint'     => array(

                'title'   => esc_attr__('Logo Position', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set default logo position', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'vertical_custom_logo',

            'type'     => 'switch',

            'default'  => false,

            'title'    => esc_html__('Display Custom Logo', 'dpr-adeline-extensions'),

            'required' => array('header_style', 'contains', 'vertical'),

            'hint'     => array(

                'title'   => esc_attr__('Display Custom Logo', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enable or disable display of custom logo ', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'vertical_logo',

            'type'     => 'media',

            'title'    => esc_html__('Logo', 'dpr-adeline-extensions'),

            'required' => array('vertical_custom_logo', 'equals', '1'),

            'hint'     => array(

                'title'   => esc_attr__('Logo', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Select image for fullscreen logo', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'vertical_logo_retina',

            'type'     => 'media',

            'title'    => esc_html__('Retina Logo', 'dpr-adeline-extensions'),

            'required' => array('vertical_custom_logo', 'equals', '1'),

            'hint'     => array(

                'title'   => esc_attr__('Logo', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Select image for fullscreen retina logo', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'vertical_header_menu_align',

            'type'     => 'radio',

            'title'    => __('Menu Alignment', 'dpr-adeline-extensions'),

            'options'  => array(

                'left-vmenu'   => 'Left',

                'center-vmenu' => 'Center',

                'right-vmenu'  => 'Right',

            ),

            'default'  => 'left-menu',

            'required' => array('header_style', 'contains', 'vertical'),

            'hint'     => array(

                'title'   => esc_attr__('Menu Alignment', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set default menu alignment', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'             => 'vertical_header_menu_items_padding',

            'type'           => 'spacing',

            'output'         => array('#dpr-header.vertical-header #dpr-navigation-wrapper .dropdown-menu li > a '),

            'mode'           => 'padding',

            'units'          => array('px'),

            'left'           => false,

            'right'          => false,

            'display_units'  => true,

            'units_extended' => false,

            'title'          => __('Menu Iteems Vertical Padding (px)', 'dpr-adeline-extensions'),

            'default'        => array(

                'padding-top'    => '18px',

                'padding-bottom' => '18px',

                'units'          => 'px',

            ),

            'required'       => array('header_style', 'equals', 'vertical'),

            'hint'           => array(

                'title'   => esc_attr__('Menu Iteems Vertical Padding', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Choose default menu items padding for vertical header menu.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'vertical_menu_link_color',

            'type'     => 'color',

            'output'   => array('color' => '#dpr-header.vertical-header #dpr-navigation-wrapper .dropdown-menu li > a '),

            'validate' => 'color',

            'title'    => esc_html__('Menu Link Color', 'dpr-adeline-extensions'),

            'default'  => '#292933',

            'required' => array('header_style', 'contains', 'vertical'),

            'hint'     => array(

                'title'   => esc_attr__('Menu Link Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set menu link color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'vertical_menu_link_color_hover',

            'type'     => 'color',

            'output'   => array('color' => '#dpr-header.vertical-header #dpr-navigation-wrapper .dropdown-menu li > a:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Menu Link Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'required' => array('header_style', 'contains', 'vertical'),

            'hint'     => array(

                'title'   => esc_attr__('Menu Link Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set menu link hover color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'vertical_menu_separator_color',

            'type'     => 'color',

            'output'   => array('border-color' => '#dpr-header.vertical-header #dpr-navigation-wrapper .dropdown-menu li'),

            'validate' => 'color',

            'title'    => esc_html__('Menu Separator Color', 'dpr-adeline-extensions'),

            'default'  => 'rgba(0, 0, 0, 0.05)',

            'required' => array('header_style', 'contains', 'vertical'),

            'hint'     => array(

                'title'   => esc_attr__('Menu Separator Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set menu separator color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'vertical_header_search',

            'type'     => 'switch',

            'default'  => false,

            'title'    => esc_html__('Display Search Field', 'dpr-adeline-extensions'),

            'required' => array('header_style', 'contains', 'vertical'),

            'hint'     => array(

                'title'   => esc_attr__('Display Search Field', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enable or disable display search box for header ', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'vertical_header_search_bg',

            'type'     => 'color',

            'output'   => array('background-color' => '#dpr-header.vertical-header #vertical-searchform form .search-bg'),

            'validate' => 'color',

            'title'    => esc_html__('Search Field Background', 'dpr-adeline-extensions'),

            'default'  => '#f1f2f4',

            'required' => array('vertical_header_search', 'equals', '1'),

            'hint'     => array(

                'title'   => esc_attr__('Search Field Background', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set background color for search box.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'vertical_header_search_color',

            'type'     => 'color',

            'output'   => array('color' => '#dpr-header.vertical-header #vertical-searchform form input, #dpr-header.vertical-header #vertical-searchform form label'),

            'validate' => 'color',

            'title'    => esc_html__('Search Field Text Color', 'dpr-adeline-extensions'),

            'default'  => '#243854',

            'required' => array('vertical_header_search', 'equals', '1'),

            'hint'     => array(

                'title'   => esc_attr__('Search Field Text Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set color for search box.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'vertical_header_search_border',

            'type'     => 'color',

            'output'   => array('border-color' => '#dpr-header.vertical-header #vertical-searchform form input'),

            'validate' => 'color',

            'title'    => esc_html__('Search Field Border Color', 'dpr-adeline-extensions'),

            'default'  => 'rgba(0, 0, 0, 0.1)',

            'required' => array('vertical_header_search', 'equals', '1'),

            'hint'     => array(

                'title'   => esc_attr__('Search Field Border Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set border color for search box.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'vertical_header_search_border_hover',

            'type'     => 'color',

            'output'   => array('border-color' => '#dpr-header.vertical-header #vertical-searchform form input:hover, #dpr-header.vertical-header #vertical-searchform form input:focus'),

            'validate' => 'color',

            'title'    => esc_html__('Search Field Border Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'required' => array('vertical_header_search', 'equals', '1'),

            'hint'     => array(

                'title'   => esc_attr__('Search Field Border Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set border hover and focus color for search box.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'vertical_header_search_button_color',

            'type'     => 'color',

            'output'   => array('color' => '#dpr-header.vertical-header #vertical-searchform form button'),

            'validate' => 'color',

            'title'    => esc_html__('Search Field Border Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '#243854',

            'required' => array('vertical_header_search', 'equals', '1'),

            'hint'     => array(

                'title'   => esc_attr__('Search Field Button Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set search button (icon) color for search box.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'vertical_header_search_button_color_hover',

            'type'     => 'color',

            'output'   => array('color' => '#dpr-header.vertical-header #vertical-searchform form button:hover'),

            'validate' => 'color',

            'title'    => esc_html__('Search Field Border Color: Hover', 'dpr-adeline-extensions'),

            'default'  => '#D3AE5F',

            'required' => array('vertical_header_search', 'equals', '1'),

            'hint'     => array(

                'title'   => esc_attr__('Search Field Bytton Color: Hover', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set search button (icon) hover color for search box.', 'dpr-adeline-extensions'),

            ),

        ),

// Common Settings

        array(

            'id'       => 'common_header_info',

            'type'     => 'info',

            'style'    => 'dpr-title',

            'required' => array('header_style', 'not_contain', 'vertical'),

            'title'    => wp_kses_post(__('<h3>Settings Common For All Header Styles </h3>', 'dpr-adeline-extensions')),

        ),

        array(

            'id'       => 'use_header_border',

            'type'     => 'switch',

            'default'  => false,

            'title'    => esc_html__('Use Header Border Bottom', 'dpr-adeline-extensions'),

            'required' => array('header_style', 'not_contain', 'vertical'), 'hint' => array(

                'title'   => esc_attr__('Use Header Border Bottom', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Enable or disable header bottom border ', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'header_border_color',

            'type'     => 'color',

            'output'   => array('border-color' => '#dpr-header'),

            'validate' => 'color',

            'title'    => esc_html__('Header Border Color', 'dpr-adeline-extensions'),

            'default'  => '#e5e5e9',

            'required' => array('use_header_border', 'equals', '1'),

            'hint'     => array(

                'title'   => esc_attr__('Header Border Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set header bottom border color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'header_full_width',

            'type'     => 'switch',

            'default'  => false,

            'title'    => esc_html__('Force Fullwidth Header', 'dpr-adeline-extensions'),

            'required' => array('header_style', 'not_contain', 'vertical'), 'hint' => array(

                'title'   => esc_attr__('Force Fullwidth Header', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Add content (eg. the address information) which will be visible in top bar', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'             => 'header_full_width_padding',

            'type'           => 'spacing',

            'output'         => array('.full-width-header #dpr-header-inner'),

            'mode'           => 'padding',

            'units'          => array('px'),

            'display_units'  => true,

            'units_extended' => false,

            'top'            => false,

            'bottom'         => false,

            'title'          => __('Fullwidth Header Padding (px)', 'dpr-adeline-extensions'),

            'default'        => array(

                'padding-left'  => '30px',

                'padding-right' => '30px',

                'units'         => 'px',

            ),

            'required'       => array('header_full_width', 'equals', '1'),

            'hint'           => array(

                'title'   => esc_attr__('Fullwidth Header Paddingg', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Choose default padding for full width header.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'use_header_overlapping',

            'type'     => 'switch',

            'default'  => false,

            'title'    => esc_html__('Use Header Overlapping', 'dpr-adeline-extensions'),

            'required' => array('header_style', 'not_contain', 'vertical'), 'hint' => array(

                'title'   => esc_attr__('Use Header Overlapping', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Use transparent or semitransparent overlapped header', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'overlapping_header_bg_color',

            'type'     => 'color',

            'output'   => array('background-color' => '.header-overlapping-used #dpr-header'),

            'validate' => 'color',

            'title'    => esc_html__('Overlapping Header Background Color', 'dpr-adeline-extensions'),

            'default'  => 'rgba(0,0,0,0)',

            'required' => array('use_header_overlapping', 'equals', '1'),

            'hint'     => array(

                'title'   => esc_attr__('Overlapping Header Background Color', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set overlapping header background color.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'overlapping_header_style',

            'type'     => 'radio',

            'title'    => __('Overlapping Header Style', 'dpr-adeline-extensions'),

            'options'  => array(

                'light' => 'Light',

                'dark'  => 'Dark',

            ),

            'default'  => 'light',

            'required' => array('use_header_overlapping', 'equals', '1'),

            'hint'     => array(

                'title'   => esc_attr__('Overlapping Header Style', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Select default overlapping style. Light is intented for headers with a dark background , dark for light backgrounds,', 'dpr-adeline-extensions'),

            ),

        ),

    ),

));
