<?php

/**

 * Social Icons Block Widget.

 *

 */



// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}



if ( ! class_exists( 'DPR_Social_Icons_Widget' ) ) {

	class DPR_Social_Icons_Widget extends WP_Widget {



		/**

		 * Register widget with WordPress.

		 *

		 */

		public function __construct() {

			parent::__construct(

				'dpr_social_icons',

				esc_html__( 'DPR Social Icons', 'dpr-adeline-extensions' ),

				array(

					'classname'   => 'widget-dpr-social-icons',

					'description' => esc_html__( 'Display social icons block.', 'dpr-adeline-extensions' ),

					'customize_selective_refresh' => true,

				)

			);



		}



		/**

		 * Front-end display of widget.

		 *

		 *

		 * @param array $args     Widget arguments.

		 * @param array $instance Saved values from database.

		 */

		public function widget( $args, $instance ) {



			$title      	= isset( $instance['title'] ) ? apply_filters( 'widget_title', $instance['title'] ) : '';

			$style   		= isset( $instance['style'] ) ? $instance['style'] : 'minimal-social';

			$alignment   		= isset( $instance['alignment'] ) ? $instance['alignment'] : '';

			$icon_size   		= isset( $instance['icon_size'] ) ? $instance['icon_size'] : '14';

			$icon_spacing   		= isset( $instance['icon_spacing'] ) ? $instance['icon_spacing'] : '6';

			$dark_bg   		= isset( $instance['dark_bg'] ) ? $instance['dark_bg'] : '';

			$custom_class   		= isset( $instance['custom_class'] ) ? $instance['custom_class'] : '';

			$facebook   		= isset( $instance['facebook'] ) ? $instance['facebook'] : '';

			$twitter   		= isset( $instance['twitter'] ) ? $instance['twitter'] : '';

			$google_plus   		= isset( $instance['google_plus'] ) ? $instance['google_plus'] : '';

			$pinterest  		= isset( $instance['pinterest'] ) ? $instance['pinterest'] : '';

			$dribbble  		= isset( $instance['dribbble'] ) ? $instance['dribbble'] : '';

			$instagram   		= isset( $instance['instagram'] ) ? $instance['instagram'] : '';

			$linkedin   		= isset( $instance['linkedin'] ) ? $instance['linkedin'] : '';

			$flickr   		= isset( $instance['flickr'] ) ? $instance['flickr'] : '';

			$skype   		= isset( $instance['skype'] ) ? $instance['skype'] : '';

			$vk   		= isset( $instance['vk'] ) ? $instance['vk'] : '';

			$tumblr   		= isset( $instance['tumblr'] ) ? $instance['tumblr'] : '';

			$github   		= isset( $instance['github'] ) ? $instance['github'] : '';

			$youtube   		= isset( $instance['youtube'] ) ? $instance['youtube'] : '';

			$vimeo   		= isset( $instance['vimeo'] ) ? $instance['vimeo'] : '';

			$vine   		= isset( $instance['vine'] ) ? $instance['vine'] : '';

			$stumbleupon   		= isset( $instance['stumbleupon'] ) ? $instance['stumbleupon'] : '';

			$xing   		= isset( $instance['xing'] ) ? $instance['xing'] : '';

			$digg   		= isset( $instance['digg'] ) ? $instance['digg'] : '';

			$lastfm   		= isset( $instance['lastfm'] ) ? $instance['lastfm'] : '';

			$soundcloud   		= isset( $instance['soundcloud'] ) ? $instance['soundcloud'] : '';

			$delicious  		= isset( $instance['delicious'] ) ? $instance['delicious'] : '';

			$yelp   		= isset( $instance['yelp'] ) ? $instance['yelp'] : '';

			$tripadvisor   		= isset( $instance['tripadvisor'] ) ? $instance['tripadvisor'] : '';
			
			$odnoklassniki   		= isset( $instance['odnoklassniki'] ) ? $instance['odnoklassniki'] : '';
			
			$rss  		= isset( $instance['rss'] ) ? $instance['rss'] : '';

			$target 		= isset( $instance['target'] ) ? $instance['target'] : '_blank';



			$dim_style =  'margin-right:'.round($icon_spacing/2).'px;margin-left:'.round($icon_spacing/2).'px;font-size:'.$icon_size.'px;line-height:'.$icon_size.'px;';

			$dark_bg_style = '';

			if( $dark_bg == 'on' )  {

				$dark_bg_style = ' on-dark-bg';

			}

			// Before widget WP hook

			echo $args['before_widget'];



				// Show widget title

				if ( $title ) {

					echo $args['before_title'] . esc_html( $title ). $args['after_title'];

				} ?>

				<div class="dpr-social-icons">

                

                    <div class="dpr-adeline-social-block clr">

                        

                        <div class="social-menu-inner clr <?php echo esc_attr($style.$dark_bg_style.' '.$alignment) ?>">

                        	                            

                            <ul>

                            	<?php if ($facebook != '') { ?>

                            	<li class="dpr-adeline-facebook"><a href="<?php echo esc_url($facebook) ?>" target="<?php echo $target ?>" style=" <?php echo esc_attr($dim_style) ?> "><span class="dpr-icon-facebook"></span></a></li>

                                <?php } ?>

                                <?php if ($twitter != '') { ?>

                                <li class="dpr-adeline-twitter"><a href="<?php echo esc_url($twitter) ?>" target="<?php echo $target ?>" style=" <?php echo esc_attr($dim_style) ?> "><span class="dpr-icon-twitter"></span></a></li>

                            	<?php } ?>

								<?php if ($google_plus != '') { ?>

                                <li class="dpr-adeline-google-plus"><a href="<?php echo esc_url($google_plus) ?>" target="<?php echo $target ?>" style=" <?php echo esc_attr($dim_style) ?> "><span class="dpr-icon-google-plus"></span></a></li>

								<?php } ?>

                            	<?php if ($pinterest != '') { ?>

                                <li class="dpr-adeline-pinterest-p"><a href="<?php echo esc_url($pinterest) ?>" target="<?php echo $target ?>" style=" <?php echo esc_attr($dim_style) ?> "><span class="dpr-icon-pinterest-p"></span></a></li>

								<?php } ?>

                            	<?php if ($dribbble != '') { ?>

                                <li class="dpr-adeline-dribbble"><a href="<?php echo esc_url($dribbble) ?>" target="<?php echo $target ?>" style=" <?php echo esc_attr($dim_style) ?> "><span class="dpr-icon-dribbble"></span></a></li>

								<?php } ?>

                            	<?php if ($instagram != '') { ?>                               

                                <li class="dpr-adeline-instagram"><a href="<?php echo esc_url($instagram) ?>" target="<?php echo $target ?>" style=" <?php echo esc_attr($dim_style) ?> "><span class="dpr-icon-instagram"></span></a></li>

								<?php } ?>

                            	<?php if ($linkedin != '') { ?>

                                <li class="dpr-adeline-linkedin"><a href="<?php echo esc_url($linkedin) ?>" target="<?php echo $target ?>" style=" <?php echo esc_attr($dim_style) ?> "><span class="dpr-icon-linkedin"></span></a></li>

								<?php } ?>

                            	<?php if ($flickr != '') { ?>                                

                                <li class="dpr-adeline-flickr"><a href="<?php echo esc_url($flickr) ?>" target="<?php echo $target ?>" style=" <?php echo esc_attr($dim_style) ?> "><span class="dpr-icon-flickr"></span></a></li>

								<?php } ?>

                            	<?php if ($skype != '') { ?>

                                <li class="dpr-adeline-skype"><a href="<?php echo esc_url($skype) ?>" target="<?php echo $target ?>" style=" <?php echo esc_attr($dim_style) ?> "><span class="dpr-icon-skype"></span></a></li>

								<?php } ?>

                            	<?php if ($vk != '') { ?>

                                <li class="dpr-adeline-vk"><a href="<?php echo esc_url($vk) ?>" target="<?php echo $target ?>" style=" <?php echo esc_attr($dim_style) ?> "><span class="dpr-icon-vk"></span></a></li>

								<?php } ?>

                            	<?php if ($tumblr != '') { ?>

                                <li class="dpr-adeline-tumblr"><a href="<?php echo esc_url($tumblr) ?>" target="<?php echo $target ?>" style=" <?php echo esc_attr($dim_style) ?> "><span class="dpr-icon-tumblr"></span></a></li>

								<?php } ?>

                            	<?php if ($github != '') { ?>

                                <li class="dpr-adeline-github-alt"><a href="<?php echo esc_url($github) ?>" target="<?php echo $target ?>" style=" <?php echo esc_attr($dim_style) ?> "><span class="dpr-icon-github-alt"></span></a></li>

								<?php } ?>

                            	<?php if ($youtube != '') { ?>

                                <li class="dpr-adeline-youtube"><a href="<?php echo esc_url($youtube) ?>" target="<?php echo $target ?>" style=" <?php echo esc_attr($dim_style) ?> "><span class="dpr-icon-youtube"></span></a></li>

								<?php } ?>

                            	<?php if ($vimeo != '') { ?>

                                <li class="dpr-adeline-vimeo"><a href="<?php echo esc_url($vimeo) ?>" target="<?php echo $target ?>" style=" <?php echo esc_attr($dim_style) ?> "><span class="dpr-icon-vimeo"></span></a></li>

								<?php } ?>

                            	<?php if ($vine != '') { ?>

                                <li class="dpr-adeline-vine"><a href="<?php echo esc_url($vine) ?>" target="<?php echo $target ?>" style=" <?php echo esc_attr($dim_style) ?> "><span class="dpr-icon-vine"></span></a></li>

								<?php } ?>

                            	<?php if ($stumbleupon != '') { ?>

                                <li class="dpr-adeline-stumbleupon"><a href="<?php echo esc_url($stumbleupon) ?>" target="<?php echo $target ?>" style=" <?php echo esc_attr($dim_style) ?> "><span class="dpr-icon-stumbleupon"></span></a></li>

								<?php } ?>

                            	<?php if ($xing != '') { ?>

                                <li class="dpr-adeline-xing"><a href="<?php echo esc_url($xing) ?>" target="<?php echo $target ?>" style=" <?php echo esc_attr($dim_style) ?> "><span class="dpr-icon-xing"></span></a></li>

								<?php } ?>

                            	<?php if ($digg != '') { ?>

                                <li class="dpr-adeline-digg"><a href="<?php echo esc_url($digg) ?>" target="<?php echo $target ?>" style=" <?php echo esc_attr($dim_style) ?> "><span class="dpr-icon-digg"></span></a></li>

								<?php } ?>

                            	<?php if ($lastfm != '') { ?>

                                <li class="dpr-adeline-lastfm"><a href="<?php echo esc_url($lastfm) ?>" target="<?php echo $target ?>" style=" <?php echo esc_attr($dim_style) ?> "><span class="dpr-icon-lastfm"></span></a></li>

								<?php } ?>

                            	<?php if ($soundcloud != '') { ?>

                                <li class="dpr-adeline-soundcloud"><a href="<?php echo esc_url($soundcloud) ?>" target="<?php echo $target ?>" style=" <?php echo esc_attr($dim_style) ?> "><span class="dpr-icon-soundcloud"></span></a></li>

								<?php } ?>

                            	<?php if ($delicious != '') { ?>

                                <li class="dpr-adeline-delicious"><a href="<?php echo esc_url($delicious) ?>" target="<?php echo $target ?>" style=" <?php echo esc_attr($dim_style) ?> "><span class="dpr-icon-delicious"></span></a></li>

								<?php } ?>

                            	<?php if ($yelp != '') { ?>

                                <li class="dpr-adeline-yelp"><a href="<?php echo esc_url($yelp) ?>" target="<?php echo $target ?>" style=" <?php echo esc_attr($dim_style) ?> "><span class="dpr-icon-yelp"></span></a></li>

								<?php } ?>

                            	<?php if ($tripadvisor != '') { ?>

                                <li class="dpr-adeline-tripadvisor"><a href="<?php echo esc_url($tripadvisor) ?>" target="<?php echo $target ?>" style=" <?php echo esc_attr($dim_style) ?> "><span class="dpr-icon-tripadvisor"></span></a></li>

								<?php } ?>
<?php if ($odnoklassniki != '') { ?>
                                <li class="dpr-adeline-odnoklassniki"><a href="<?php echo esc_url($odnoklassniki) ?>" target="<?php echo $target ?>" style=" <?php echo esc_attr($dim_style) ?> "><span class="dpr-icon-odnoklassniki"></span></a></li>
								<?php } ?>
                            	<?php if ($rss != '') { ?>

                                <li class="dpr-adeline-rss"><a href="<?php echo esc_url($rss) ?>" target="<?php echo $target ?>" style=" <?php echo esc_attr($dim_style) ?> "><span class="dpr-icon-rss"></span></a></li>

                                <?php } ?>

                            </ul>

                        </div>

                    </div>

                </div>



			<?php

			// After widget WP hook

			echo $args['after_widget'];



		}



		/**

		 * Sanitize widget form values as they are saved.

		 *

		 *

		 * @param array $new_instance Values just sent to be saved.

		 * @param array $old_instance Previously saved values from database.

		 *

		 * @return array Updated safe values to be saved.

		 */

		public function update( $new_instance, $old_instance ) {

			$instance               	= $old_instance;

			$instance['title']      	= ! empty( $new_instance['title'] ) ? strip_tags( $new_instance['title'] ) : '';

			$instance['style']    		= ! empty( $new_instance['style'] ) ? $new_instance['style'] : '';

			$instance['alignment']    		= ! empty( $new_instance['alignment'] ) ? $new_instance['alignment'] : '';

			$instance['icon_size']    		= ! empty( $new_instance['icon_size'] ) ? $new_instance['icon_size'] : '';

			$instance['icon_spacing']    		= ! empty( $new_instance['icon_spacing'] ) ? $new_instance['icon_spacing'] : '';

			$instance['dark_bg']    = ! empty( $new_instance['dark_bg'] ) ? strip_tags( $new_instance['dark_bg'] ) : '';

			$instance['custom_class']    = ! empty( $new_instance['custom_class'] ) ? strip_tags( $new_instance['custom_class'] ) : '';

			$instance['facebook']      	= ! empty( $new_instance['facebook'] ) ? strip_tags( $new_instance['facebook'] ) : '';

			$instance['twitter']    		= ! empty( $new_instance['twitter'] ) ? $new_instance['twitter'] : '';

			$instance['google_plus']    		= ! empty( $new_instance['google_plus'] ) ? $new_instance['google_plus'] : '';

			$instance['pinterest']    		= ! empty( $new_instance['pinterest'] ) ? $new_instance['pinterest'] : '';

			$instance['dribbble']    		= ! empty( $new_instance['dribbble'] ) ? $new_instance['dribbble'] : '';

			$instance['instagram']    = ! empty( $new_instance['instagram'] ) ? strip_tags( $new_instance['instagram'] ) : '';

			$instance['linkedin']    = ! empty( $new_instance['linkedin'] ) ? strip_tags( $new_instance['linkedin'] ) : '';

			$instance['flickr']      	= ! empty( $new_instance['flickr'] ) ? strip_tags( $new_instance['flickr'] ) : '';

			$instance['skype']    		= ! empty( $new_instance['skype'] ) ? $new_instance['skype'] : '';

			$instance['vk']    		= ! empty( $new_instance['vk'] ) ? $new_instance['vk'] : '';

			$instance['tumblr']    		= ! empty( $new_instance['tumblr'] ) ? $new_instance['tumblr'] : '';

			$instance['github']    		= ! empty( $new_instance['github'] ) ? $new_instance['github'] : '';

			$instance['youtube']    = ! empty( $new_instance['youtube'] ) ? strip_tags( $new_instance['youtube'] ) : '';

			$instance['vimeo']    = ! empty( $new_instance['vimeo'] ) ? strip_tags( $new_instance['vimeo'] ) : '';

			$instance['vine']      	= ! empty( $new_instance['vine'] ) ? strip_tags( $new_instance['vine'] ) : '';

			$instance['stumbleupon']    		= ! empty( $new_instance['stumbleupon'] ) ? $new_instance['stumbleupon'] : '';

			$instance['xing']    		= ! empty( $new_instance['xing'] ) ? $new_instance['xing'] : '';

			$instance['digg']    		= ! empty( $new_instance['digg'] ) ? $new_instance['digg'] : '';

			$instance['lastfm']    		= ! empty( $new_instance['lastfm'] ) ? $new_instance['lastfm'] : '';

			$instance['soundcloud']    = ! empty( $new_instance['soundcloud'] ) ? strip_tags( $new_instance['soundcloud'] ) : '';

			$instance['delicious']    = ! empty( $new_instance['delicious'] ) ? strip_tags( $new_instance['delicious'] ) : '';

			$instance['yelp']    		= ! empty( $new_instance['yelp'] ) ? $new_instance['yelp'] : '';

			$instance['tripadvisor']    = ! empty( $new_instance['tripadvisor'] ) ? strip_tags( $new_instance['tripadvisor'] ) : '';
			$instance['odnoklassniki']    = ! empty( $new_instance['odnoklassniki'] ) ? strip_tags( $new_instance['odnoklassniki'] ) : '';
			$instance['rss']    = ! empty( $new_instance['rss'] ) ? strip_tags( $new_instance['rss'] ) : '';

			$instance['target']    = ! empty( $new_instance['target'] ) ? strip_tags( $new_instance['target'] ) : '';

			return $instance;

		}



		/**

		 * Back-end widget form.

		 *

		 *

		 * @param array $instance Previously saved values from database.

		 */

		public function form( $instance ) {

			// Parse arguments

			$instance = wp_parse_args( (array) $instance, array(

				'title'         => esc_attr__( 'Find Us On', 'dpr-adeline-extensions' ),

				'style' 		=> esc_attr__( 'minimal-social', 'dpr-adeline-extensions' ),

				'alignment'		=> esc_attr__( '', 'dpr-adeline-extensions' ),

				'icon_size'		=> esc_attr__( '16', 'dpr-adeline-extensions' ),

				'icon_spacing'		=> esc_attr__( '4', 'dpr-adeline-extensions' ),

				'dark_bg'		=> esc_attr__( '', 'dpr-adeline-extensions' ),

				'custom_class'		=> esc_attr__( '', 'dpr-adeline-extensions' ),

				'facebook'		=> esc_attr__( '', 'dpr-adeline-extensions' ),

				'twitter'		=> esc_attr__( '', 'dpr-adeline-extensions' ),

				'google_plus'		=> esc_attr__( '', 'dpr-adeline-extensions' ),

				'pinterest'		=> esc_attr__( '', 'dpr-adeline-extensions' ),

				'dribbble'		=> esc_attr__( '', 'dpr-adeline-extensions' ),

				'instagram'		=> esc_attr__( '', 'dpr-adeline-extensions' ),

				'linkedin'		=> esc_attr__( '', 'dpr-adeline-extensions' ),

				'flickr'		=> esc_attr__( '', 'dpr-adeline-extensions' ),

				'skype'		=> esc_attr__( '', 'dpr-adeline-extensions' ),

				'vk'		=> esc_attr__( '', 'dpr-adeline-extensions' ),

				'tumblr'		=> esc_attr__( '', 'dpr-adeline-extensions' ),

				'github'		=> esc_attr__( '', 'dpr-adeline-extensions' ),

				'youtube'		=> esc_attr__( '', 'dpr-adeline-extensions' ),

				'vimeo'		=> esc_attr__( '', 'dpr-adeline-extensions' ),

				'vine'		=> esc_attr__( '', 'dpr-adeline-extensions' ),

				'stumbleupon'		=> esc_attr__( '', 'dpr-adeline-extensions' ),

				'xing'		=> esc_attr__( '', 'dpr-adeline-extensions' ),

				'digg'		=> esc_attr__( '', 'dpr-adeline-extensions' ),

				'lastfm'		=> esc_attr__( '', 'dpr-adeline-extensions' ),

				'soundcloud'		=> esc_attr__( '', 'dpr-adeline-extensions' ),

				'delicious'		=> esc_attr__( '', 'dpr-adeline-extensions' ),

				'yelp'		=> esc_attr__( '', 'dpr-adeline-extensions' ),

				'tripadvisor'		=> esc_attr__( '', 'dpr-adeline-extensions' ),
				'odnoklassniki'		=> esc_attr__( '', 'dpr-activia-extensions' ),
				'rss'		=> esc_attr__( '', 'dpr-adeline-extensions' ),

				'target'		=> esc_attr__( '_blank', 'dpr-adeline-extensions' )

			) ); ?>



			<p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title', 'dpr-adeline-extensions' ); ?>:</label>

				<input class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['title'] ); ?>" />

			</p>



			<div class="dpr-widget-inner-block">

				<h2><?php esc_html_e('Social Networks:', 'dpr-adeline-extensions'); ?></h2>



			<p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'facebook' ) ); ?>"><?php esc_html_e( 'Facebook', 'dpr-adeline-extensions' ); ?></label>

				<input class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'facebook' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['facebook'] ); ?>" />

			</p>



			<p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'twitter' ) ); ?>"><?php esc_html_e( 'Twitter', 'dpr-adeline-extensions' ); ?></label>

				<input class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'twitter' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['twitter'] ); ?>" />

			</p>



			<p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'google_plus' ) ); ?>"><?php esc_html_e( 'Google+', 'dpr-adeline-extensions' ); ?></label>

				<input class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'google_plus' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['google_plus'] ); ?>" />

			</p>



			<p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'pinterest' ) ); ?>"><?php esc_html_e( 'Pinterest', 'dpr-adeline-extensions' ); ?></label>

				<input class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'pinterest' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['pinterest'] ); ?>" />

			</p>



			<p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'dribbble' ) ); ?>"><?php esc_html_e( 'Dribbble', 'dpr-adeline-extensions' ); ?></label>

				<input class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'dribbble' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['dribbble'] ); ?>" />

			</p>



			<p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'instagram' ) ); ?>"><?php esc_html_e( 'Instagram', 'dpr-adeline-extensions' ); ?></label>

				<input class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'instagram' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['instagram'] ); ?>" />

			</p>



			<p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'linkedin' ) ); ?>"><?php esc_html_e( 'Linkedin', 'dpr-adeline-extensions' ); ?></label>

				<input class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'linkedin' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['linkedin'] ); ?>" />

			</p>



			<p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'flickr' ) ); ?>"><?php esc_html_e( 'Flickr', 'dpr-adeline-extensions' ); ?></label>

				<input class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'flickr' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['flickr'] ); ?>" />

			</p>



			<p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'skype' ) ); ?>"><?php esc_html_e( 'Skype', 'dpr-adeline-extensions' ); ?></label>

				<input class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'skype' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['skype'] ); ?>" />

			</p>



			<p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'vk' ) ); ?>"><?php esc_html_e( 'VK', 'dpr-adeline-extensions' ); ?></label>

				<input class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'vk' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['vk'] ); ?>" />

			</p>



			<p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'tumblr' ) ); ?>"><?php esc_html_e( 'Tumblr', 'dpr-adeline-extensions' ); ?></label>

				<input class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'tumblr' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['tumblr'] ); ?>" />

			</p>

			

			<p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'github' ) ); ?>"><?php esc_html_e( 'Github', 'dpr-adeline-extensions' ); ?></label>

				<input class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'github' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['github'] ); ?>" />

			</p>

			

			<p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'youtube' ) ); ?>"><?php esc_html_e( 'Youtube', 'dpr-adeline-extensions' ); ?></label>

				<input class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'youtube' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['youtube'] ); ?>" />

			</p>



			<p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'vimeo' ) ); ?>"><?php esc_html_e( 'Vimeo', 'dpr-adeline-extensions' ); ?></label>

				<input class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'vimeo' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['vimeo'] ); ?>" />

			</p>



			<p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'vine' ) ); ?>"><?php esc_html_e( 'Vine', 'dpr-adeline-extensions' ); ?></label>

				<input class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'vine' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['vine'] ); ?>" />

			</p>



			<p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'stumbleupon' ) ); ?>"><?php esc_html_e( 'Stumbleupon', 'dpr-adeline-extensions' ); ?></label>

				<input class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'stumbleupon' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['stumbleupon'] ); ?>" />

			</p>



			<p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'xing' ) ); ?>"><?php esc_html_e( 'Xing', 'dpr-adeline-extensions' ); ?></label>

				<input class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'xing' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['xing'] ); ?>" />

			</p>



			<p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'digg' ) ); ?>"><?php esc_html_e( 'Digg', 'dpr-adeline-extensions' ); ?></label>

				<input class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'digg' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['digg'] ); ?>" />

			</p>



			<p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'lastfm' ) ); ?>"><?php esc_html_e( 'Lastfm', 'dpr-adeline-extensions' ); ?></label>

				<input class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'lastfm' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['lastfm'] ); ?>" />

			</p>



			<p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'soundcloud' ) ); ?>"><?php esc_html_e( 'Soundcloud', 'dpr-adeline-extensions' ); ?></label>

				<input class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'soundcloud' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['soundcloud'] ); ?>" />

			</p>



			<p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'delicious' ) ); ?>"><?php esc_html_e( 'Delicious', 'dpr-adeline-extensions' ); ?></label>

				<input class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'delicious' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['delicious'] ); ?>" />

			</p>



			<p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'yelp' ) ); ?>"><?php esc_html_e( 'Yelp', 'dpr-adeline-extensions' ); ?></label>

				<input class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'yelp' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['yelp'] ); ?>" />

			</p>



			<p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'tripadvisor' ) ); ?>"><?php esc_html_e( 'Tripadvisor', 'dpr-adeline-extensions' ); ?></label>

				<input class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'tripadvisor' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['tripadvisor'] ); ?>" />

			</p>
<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'odnoklassniki' ) ); ?>"><?php esc_html_e( 'Odnoklassniki', 'dpr-activia-extensions' ); ?></label>
				<input class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'odnoklassniki' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['odnoklassniki'] ); ?>" />
			</p>


			<p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'rss' ) ); ?>"><?php esc_html_e( 'RSS', 'dpr-adeline-extensions' ); ?></label>

				<input class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'rss' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['rss'] ); ?>" />

			</p>



            </div>

            

			<div class="dpr-widget-inner-block">

				<h2><?php esc_html_e('Styling Options:', 'dpr-adeline-extensions'); ?></h2>

			<p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'style' ) ); ?>"><?php esc_html_e( 'Style', 'dpr-adeline-extensions' ); ?></label>

				<select class='widefat' name="<?php echo $this->get_field_name( 'style' ); ?>" id="<?php echo $this->get_field_id( 'style' ); ?>">

					<option value="minimal-social" <?php if ( $instance['style'] == 'minimal-social') { ?>selected="selected"<?php } ?>><?php esc_html_e( 'Minimal', 'dpr-adeline-extensions' ); ?></option>

					<option value="rounded" <?php if ( $instance['style'] == 'rounded') { ?>selected="selected"<?php } ?>><?php esc_html_e( 'Rounded', 'dpr-adeline-extensions' ); ?></option>

					<option value="outlined" <?php if ( $instance['style'] == 'outlined') { ?>selected="selected"<?php } ?>><?php esc_html_e( 'Outlined', 'dpr-adeline-extensions' ); ?></option>

					<option value="colored" <?php if ( $instance['style'] == 'colored') { ?>selected="selected"<?php } ?>><?php esc_html_e( 'Colored', 'dpr-adeline-extensions' ); ?></option>

				</select>

			</p>



			<p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'alignment' ) ); ?>"><?php esc_html_e( 'Icons alignment', 'dpr-adeline-extensions' ); ?></label>

				<select class='widefat' name="<?php echo $this->get_field_name( 'alignment' ); ?>" id="<?php echo $this->get_field_id( 'alignment' ); ?>">

					<option value="minimal-social" <?php if ( $instance['alignment'] == '') { ?>selected="selected"<?php } ?>><?php esc_html_e( 'Left', 'dpr-adeline-extensions' ); ?></option>

					<option value="text-center" <?php if ( $instance['alignment'] == 'text-center') { ?>selected="selected"<?php } ?>><?php esc_html_e( 'Center', 'dpr-adeline-extensions' ); ?></option>

					<option value="text-right" <?php if ( $instance['style'] == 'text-right') { ?>selected="selected"<?php } ?>><?php esc_html_e( 'Right', 'dpr-adeline-extensions' ); ?></option>

				</select>

			</p>



			<p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'icon_size' ) ); ?>"><?php esc_html_e( 'Icon size (px)', 'dpr-adeline-extensions' ); ?></label> 

				<input class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'icon_size' ) ); ?>" type="number" min="0" step="1" value="<?php echo esc_attr( $instance['icon_size'] ); ?>" />

			</p>



			<p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'icon_spacing' ) ); ?>"><?php esc_html_e( 'Icon spacing (px)', 'dpr-adeline-extensions' ); ?></label> 

				<input class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'icon_spacing' ) ); ?>" type="number" min="0" step="1" value="<?php echo esc_attr( $instance['icon_spacing'] ); ?>" />

			</p>



            <p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'dark_bg' ) ); ?>">

					<input type="checkbox" name="<?php echo esc_attr( $this->get_field_name( 'dark_bg' ) ); ?>" id="<?php echo esc_attr( $this->get_field_id( 'dark_bg' ) ); ?>" <?php checked( $instance['dark_bg'] , 'on' ); ?> />

					<?php esc_html_e( 'On dark background style', 'dpr-adeline-extensions' ); ?>

				</label>

			</p>



			<p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'target' ) ); ?>"><?php esc_html_e( 'Open links', 'dpr-adeline-extensions' ); ?></label>

				<select class='widefat' name="<?php echo $this->get_field_name( 'target' ); ?>" id="<?php echo $this->get_field_id( 'target' ); ?>">

					<option value="_blank" <?php if ( $instance['target'] == '_blank') { ?>selected="selected"<?php } ?>><?php esc_html_e( 'In new window', 'dpr-adeline-extensions' ); ?></option>

					<option value="_self" <?php if ( $instance['target'] == '_self') { ?>selected="selected"<?php } ?>><?php esc_html_e( 'In the same window', 'dpr-adeline-extensions' ); ?></option>

				</select>



			<p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'custom_class' ) ); ?>"><?php esc_html_e( 'Custom CSS Class', 'dpr-adeline-extensions' ); ?></label>

				<input class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'custom_class' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['custom_class'] ); ?>" />

			</p>



			</div>







		<?php



		}



	}

}