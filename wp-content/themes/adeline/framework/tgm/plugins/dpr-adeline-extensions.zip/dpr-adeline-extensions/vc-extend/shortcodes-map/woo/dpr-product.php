<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
/*
* Add-on Name: Product (tweek for core VC Product shortcode)
*/
	vc_add_param(
		'product', array(
			'type' => 'hidden',
			'heading' => '',
			'param_name' => 'columns',
			'std' => '1',
			'save_always' => true,
		)
	);