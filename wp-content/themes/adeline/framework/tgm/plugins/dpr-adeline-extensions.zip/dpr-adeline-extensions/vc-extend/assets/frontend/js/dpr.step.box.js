var $j = jQuery.noConflict();

$j( document ).on( 'ready', function() {
	"use strict";
	// Custom select
	dprInitializeStepBoxes();
} );

/* ==============================================
BEFORE AFTER
============================================== */
function dprInitializeStepBoxes() {
	"use strict"
    $j(function(){

		$j('.dpr-step-box').each(function() {
			var element = $j(this);
			var parent_width = element.closest( ".vc_column-inner " ).outerWidth();
			var icon_width = element.find(".module-icon").outerWidth();
			var conector_width = parent_width - icon_width;
			var conector = element.find(".conector");
			conector.width(conector_width);
			conector.css("left",icon_width);
			
		});

    });
}