<?php



/**



 * Icons Theme Options



 * 



 */







    Redux::setSection( $opt_name, array(



        'title'  => __( 'Icon Manager', 'dpr-adeline-extensions' ),



        'id'     => 'icons',



        'icon'   => 'el el-star-alt',



		'fields' => array(



					array(



				'id' => 'icon_manager',



				'type' => 'icon_manager',



				'title' => 'Icon fonts list',



				'subtitle'  => 'Upload .zip archive with font-icon files.<br/><br/><span style="color:#B94A48"><strong>Note:</strong></span>  Supports zip archives generated on https://icomoon.io website only.<br/>



				<a href="https://icomoon.io/app/" target="_blank">Create you font-icon package</a>'



			)







		)



    ) );