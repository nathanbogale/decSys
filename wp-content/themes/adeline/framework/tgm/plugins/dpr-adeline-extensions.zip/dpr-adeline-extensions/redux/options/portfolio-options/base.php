<?php



/**



 * Portfolio Options -> General Settings



 * 



 */







	Redux::setSection( $opt_name, array(



		'title' => esc_html__('Base Settings', 'dpr-adeline-extensions'),



		'id' => 'portfolio_base_settings',



		'subsection' => true,



		'fields' => array(



						array(



							'id'       => 'portfolio_slug',



							'type'     => 'text',



							'title'    => __('Portfolio Item Slug', 'dpr-adeline-extensions'),



							'default'  => '',



							'desc' => __('Please note that you need to update your permalinks if you edit this field'),



							'hint' => array(



								'title'   => esc_attr__('Portfolio Item Slug','dpr-adeline-extensions'),



								'content' =>  esc_attr__('You can change default portfolio item slug.','dpr-adeline-extensions')



							),



						),



						array(



							'id'       => 'portfolio_category_slug',



							'type'     => 'text',



							'title'    => __('Portfolio Category Slug', 'dpr-adeline-extensions'),



							'default'  => '',



							'desc' => __('Please note that you need to update your permalinks if you edit this field'),



							'hint' => array(



								'title'   => esc_attr__('Portfolio Category Slug','dpr-adeline-extensions'),



								'content' =>  esc_attr__('You can change default portfolio category slug.','dpr-adeline-extensions')



							),



						),



						array(



							'id'       => 'portfolio_tag_slug',



							'type'     => 'text',



							'title'    => __('Portfolio Tag Slug', 'dpr-adeline-extensions'),



							'default'  => '',



							'desc' => __('Please note that you need to update your permalinks if you edit this field'),



							'hint' => array(



								'title'   => esc_attr__('Portfolio Tag Slug','dpr-adeline-extensions'),



								'content' =>  esc_attr__('You can change default portfolio tag slug.','dpr-adeline-extensions')



							),



						),



						array(



							'id'       => 'portfolio_default_page_link',



							'type'     => 'text',



							'title'    => __('Portfolio Default Page Link', 'dpr-adeline-extensions'),



							'default'  => '',



							'desc' => __('This link will be used in Next / Prev nawigation in single portfolio item view'),



							'hint' => array(



								'title'   => esc_attr__('Portfolio Default Page Link','dpr-adeline-extensions'),



								'content' =>  esc_attr__('This link will be used in Next / Prev nawigation in single portfolio item view')



							),



						),







		)



	));



