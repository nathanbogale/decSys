/**



 * Redux Metaboxes



 * Dependencies      : jquery



 * Created by        : Dovy Paukstys



 * Date              : 19 Feb. 2014



 */







/* global reduxMetaboxes, redux */







jQuery(function($){







    "use strict";







    $.reduxMetaBoxes = $.reduxMetaBoxes || {};



		var curentTemplate, curentFormat



		curentTemplate = postData.PageTemplate;



		curentFormat = postData.PostFormat;







    $(document).ready(function () {



         $.reduxMetaBoxes.init();



    });







    $.reduxMetaBoxes.init = function(){



        $.reduxMetaBoxes.notLoaded = true;



        $.reduxMetaBoxes.checkBoxVisibility(curentTemplate, curentFormat);



		



		jQuery(document).on('change', 'select[id*="post-format"]',function(){ 



		curentFormat = this.value; 



		$.reduxMetaBoxes.checkBoxVisibility(curentTemplate, curentFormat)



		});



 		



		jQuery(document).on('change', '.editor-page-attributes__template select',function(){ 



		curentTemplate = this.value; 



		$.reduxMetaBoxes.checkBoxVisibility(curentTemplate, curentFormat)



		});



       







        $.redux.initFields();



    };







    $('#publishing-action .button, #save-action .button').click(function() {



        window.onbeforeunload = null;



    });



    



    



    $.reduxMetaBoxes.checkBoxVisibility = function(curentTemplate, curentFormat){



		



			if(curentTemplate != 'page-templates/blog-page.php') {



			$('#redux-dpr_adeline-metabox-blog-options').addClass('hiden');



			} else {



			$('#redux-dpr_adeline-metabox-blog-options').removeClass('hiden');



			}



			



			if(curentTemplate != 'page-templates/portfolio.php') {



			$('#redux-dpr_adeline-metabox-portfolio-options').addClass('hiden');



			} else {



			$('#redux-dpr_adeline-metabox-portfolio-options').removeClass('hiden');



			}



			



			if(curentFormat != 'video') {



				$('#redux-dpr_adeline-metabox-post_format_video').addClass('hiden');



			} else {



				$('#redux-dpr_adeline-metabox-post_format_video').removeClass('hiden');



			}



			if(curentFormat != 'audio') {



				$('#redux-dpr_adeline-metabox-post_format_audio').addClass('hiden');



			} else {



				$('#redux-dpr_adeline-metabox-post_format_audio').removeClass('hiden');



			}



			if(curentFormat != 'gallery') {



				$('#redux-dpr_adeline-metabox-post_format_gallery').addClass('hiden');



			} else {



				$('#redux-dpr_adeline-metabox-post_format_gallery').removeClass('hiden');



			}



			if(curentFormat != 'quote') {



				$('#redux-dpr_adeline-metabox-post_format_quote').addClass('hiden');



			} else {



				$('#redux-dpr_adeline-metabox-post_format_quote').removeClass('hiden');



			}



			if(curentFormat != 'link') {



				$('#redux-dpr_adeline-metabox-post_format_link').addClass('hiden');



			} else {



				$('#redux-dpr_adeline-metabox-post_format_link').removeClass('hiden');



			}



			



			



    };



});