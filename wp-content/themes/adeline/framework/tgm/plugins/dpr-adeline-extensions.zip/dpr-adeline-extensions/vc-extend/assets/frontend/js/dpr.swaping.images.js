var $j = jQuery.noConflict();



$j( document ).on( 'ready', function() {

	"use strict";

	// Custom select

	dprInitializeSwapingImages();

} );



/* ==============================================

SWAPING IMAGES

============================================== */

function dprInitializeSwapingImages() {

	"use strict";
	
	var swapImageElement = $j('.dpr-swaping-images');
	
	if (swapImageElement.length) {
		
		swapImageElement.each(function(){
			
			var thisiswapImageElement = $j(this),
				swapImageWrap = thisiswapImageElement.find('.swap-image-wrap'),
				swapImageContainer = thisiswapImageElement.find('.swap-images-container'),
				swapStyle = '',
				swapMode =thisiswapImageElement.attr('data-mode');
				if(thisiswapImageElement.hasClass('style-fade')) {
					swapStyle = 'fade'
				} else {
					swapStyle = 'reveal'
				}
				  let isOut = true;
				  let isActive = false;
				  if (swapMode == 'allways') {
				     isOut = false;
					 isActive = true;
					 swapImageContainer.css('visibility','visible');
				  } 
				
			   if (swapStyle=='fade') {
				   
				  var InfiniteRotator =
					{
						init: function()
						{ 
								//initial fade-in time (in milliseconds)
								var initialFadeIn = 0;

								//interval between items (in milliseconds)
								var itemInterval = thisiswapImageElement.attr('data-speed');

								//cross-fade time (in milliseconds)
								var fadeTime = thisiswapImageElement.attr('data-duration');

								//count number of items
								var numberOfItems = swapImageWrap.length;

								//set current item
								var currentItem = 0;

								//show first item
								if (isOut == false){
								swapImageWrap.eq(currentItem).fadeIn(initialFadeIn);
								}
								//loop through the items
								var infiniteLoop = setInterval(function(){
									if (isOut == false && isActive == true){
									swapImageWrap.eq(currentItem).fadeOut(fadeTime);

									if(currentItem == numberOfItems -1){
										currentItem = 0;
									}else{
										currentItem++;
									}
									swapImageWrap.eq(currentItem).fadeIn(fadeTime);
									}
								}, itemInterval);


						}

				  };

				  InfiniteRotator.init();
				  
				  if(swapMode == 'onhover') {
				  thisiswapImageElement.mouseenter(function() {
					  isOut = false;
					  isActive = true;
					  swapImageContainer.css('visibility','visible')

				  });
				  thisiswapImageElement.mouseleave(function() {
					  isOut = true;
					  isActive = false;
					  swapImageContainer.css('visibility','hidden')
				  });
				  }

				  if(swapMode == 'onclick') {
				  thisiswapImageElement.click(function() {
					  if (isActive == false) {
					  isOut = false;
					  isActive =true;
					  swapImageContainer.css('visibility','visible');
					  } else {
					  isOut = true;
					  isActive =false;
					  swapImageContainer.css('visibility','hidden');					  
					  }

				  });
				  }
				   
				   
			   } else {
				  var animation = null;
				  TweenMax.set(swapImageWrap, { transformOrigin: "100% 100%" });
				  var InfiniteSwaper =
					{
						init: function()
						{ 
								
								
								//initial fade-in time (in milliseconds)
								var initialFadeIn = 0;

								//interval between items (in milliseconds)
								var itemInterval = thisiswapImageElement.attr('data-speed');

								//cross-fade time (in milliseconds)
								var fadeTime = thisiswapImageElement.attr('data-duration');

								//count number of items
								var numberOfItems = swapImageWrap.length;

								//set current item
								var currentItem = 0;
								var nextItem = 1;

								//show first item
								if (isOut == false){
								animation = new TimelineMax();
								
									animation.set(swapImageWrap.eq(nextItem), { zIndex: 10 });
									animation.set(swapImageWrap.eq(currentItem), { zIndex: 11 });
									animation.to(swapImageWrap.eq(currentItem), 0.4, { rotation: -10, xPercent: -100, ease: Power1.easeInOut });
									animation.set(swapImageWrap.eq(currentItem), { zIndex: 9 });
									animation.to(swapImageWrap.eq(currentItem), 0.4, { rotation: 0, xPercent: 0 });										}
								//loop through the items
								var infiniteLoop = setInterval(function(){
									if (isOut == false && isActive == true){
									animation = new TimelineMax();
									animation.set(swapImageWrap.eq(nextItem), { zIndex: 10 });
									animation.set(swapImageWrap.eq(currentItem), { zIndex: 11 });
									animation.to(swapImageWrap.eq(currentItem), 0.4, { rotation: -10, xPercent: -100, ease: Power1.easeInOut });
									animation.set(swapImageWrap.eq(currentItem), { zIndex: 9 });
									animation.to(swapImageWrap.eq(currentItem), 0.4, { rotation: 0, xPercent: 0 });								

									if(currentItem == numberOfItems -2){
										currentItem++;
										nextItem =0;
									}else if(currentItem == numberOfItems -1){
										currentItem =0;
										nextItem++;										
									}else{
										currentItem++;
										nextItem++;
									}
									
									}
								}, itemInterval);


						}

				  };

				  InfiniteSwaper.init();
				  
				  if(swapMode == 'onhover') {
				  thisiswapImageElement.mouseenter(function() {
					  isOut = false;
					  isActive = true;
					  swapImageContainer.css('visibility','visible')

				  });
				  thisiswapImageElement.mouseleave(function() {
					  isOut = true;
					  isActive = false;
					  swapImageContainer.css('visibility','hidden')
				  });
				  }

				  if(swapMode == 'onclick') {
				  thisiswapImageElement.click(function() {
					  if (isActive == false) {
					  isOut = false;
					  isActive =true;
					  swapImageContainer.css('visibility','visible');
					  } else {
					  isOut = true;
					  isActive =false;
					  swapImageContainer.css('visibility','hidden');					  
					  }

				  });
				  }
				   
			   }
	
		});
	}
	
}


