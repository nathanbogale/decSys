<?php

if ( ! defined( 'ABSPATH' ) ) { exit; }



class WPBakeryShortCode_DPR_Image_Stack extends WPBakeryShortCode {}



vc_map(

	array(

		'name'					=> esc_html__('DP Image Stack', 'dpr-adeline-extensions'),

		'base'					=> 'dpr_image_stack',

		'class'					=> '',

		'icon'					=> 'icon-dpr-image-stack',

  		"category" =>array( esc_attr__('by Dynamicpress', 'dpr-adeline-extensions'),esc_attr__('Content', 'dpr-adeline-extensions')),

		"description" => esc_attr__('Animated stack of images', 'dpr-adeline-extensions'),

		'params'				=> array(

			array(

				'type' => 'dpr_radio',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="large" data-balloon="'.esc_html__('Set image alignment in staack', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Alignment', 'dpr-adeline-extensions'),

				'param_name'		=> 'alignment',

				'edit_field_class'	=> 'vc_column vc_col-sm-6 no-padding-top',

				'options' => array(

					__('Left', 'dpr-adeline-extensions') => 'left',

					__('Center', 'dpr-adeline-extensions') => 'center',

					__('Right', 'dpr-adeline-extensions') => 'right',

				),

				'value'			=> 'left',

				'edit_field_class'	=> 'vc_column vc_col-sm-6',

			),

			array(

				'type'				=> 'number',

				'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set the delay for image appearing in seconds', 'dpr-adeline-extensions').'" data-balloon-pos="left"><span></span></span>'.esc_html__('Animation delay', 'dpr-adeline-extensions'),

				'param_name'		=> 'delay',

				'value'				=> 0.3,

				"suffix"=>"sec",

				'edit_field_class'	=> 'vc_column vc_col-sm-6 no-padding-top',

			),

			array(

			'type' => 'textfield',

			'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Extra Class Name', 'dpr-adeline-extensions'),

			'param_name' => 'el_class',

			),

			array(

				'type'				=> 'param_group',

				'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Add images to the strack, set postion, animation and animation delay.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('List of stack images', 'dpr-adeline-extensions'),

				'param_name'		=> 'stack_list',

				'params'			=> array(

					array(

						'type'			=> 'attach_image',

						'heading'		=> esc_html__('Upload Image:', 'dpr-adeline-extensions'),

						'param_name'	=> 'image_id',

					),

					array(

						'type' => 'dropdown',

						'heading' => '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('select image size.', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Image size', 'dpr-adeline-extensions'),

						'param_name' => 'image_size',

						'value' => array(

								__('Original', 'dpr-adeline-extensions') => 'original',

								__('Custom', 'dpr-adeline-extensions') => 'custom',

							   )

					),

					array(

						'type'				=> 'number',

						'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom image width in px', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Image Width', 'dpr-adeline-extensions'),

						'param_name'		=> 'image_width',

						"suffix"=>"px",

						'edit_field_class'	=> 'vc_column vc_col-sm-6',

						'dependency' => array('element' => 'image_size', 'value' => array('custom')),

					),

					array(

						'type'				=> 'number',

						'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set custom image height in px', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Image Height', 'dpr-adeline-extensions'),

						'param_name'		=> 'image_height',

						"suffix"=>"px",

						'edit_field_class'	=> 'vc_column vc_col-sm-6',

						'dependency' => array('element' => 'image_size', 'value' => array('custom')),

					),

					array(

						'type'				=> 'number',

						'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Add the layer horizintal offset in %, for example -50% or 50%', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Horizontal offset', 'dpr-adeline-extensions'),

						'param_name'		=> 'offset_x',

						"suffix"=>"%",

						'edit_field_class'	=> 'vc_column vc_col-sm-6',

					),

					array(

						'type'				=> 'number',

						'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Add the layer vertical offset in %, for example -50% or 50%', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Vertical offset', 'dpr-adeline-extensions'),

						'param_name'		=> 'offset_y',

						"suffix"=>"%",

						'edit_field_class'	=> 'vc_column vc_col-sm-6',

					),

					array(

						'type'				=> 'dropdown',

						'param_name'		=> 'dpr_animation',

						'heading'			=> '<span class="dp-vc-tip" data-balloon-length="medium" data-balloon="'.esc_html__('Set animation type for this image', 'dpr-adeline-extensions').'" data-balloon-pos="right"><span></span></span>'.esc_html__('Animation', 'dpr-adeline-extensions'),

						'default' => 'left',

						'value'			=> array(

							esc_html__('None', 'dpr-adeline-extensions')	=> 'none',

							esc_html__('bounceIn', 'dpr-adeline-extensions')	=> 'dpr_bounceIn',

							esc_html__('bounceInDown', 'dpr-adeline-extensions')	=> 'dpr_bounceInDown',

							esc_html__('bounceInLeft', 'dpr-adeline-extensions')	=> 'dpr_bounceInLeft',

							esc_html__('bounceInRight', 'dpr-adeline-extensions')	=> 'dpr_bounceInRight',

							esc_html__('bounceInUp', 'dpr-adeline-extensions')	=> 'dpr_bounceInUp',

							esc_html__('fadeIn', 'dpr-adeline-extensions')	=> 'dpr_fadeIn',

							esc_html__('fadeInDown', 'dpr-adeline-extensions')	=> 'dpr_fadeInDown',

							esc_html__('fadeInDownBig', 'dpr-adeline-extensions')	=> 'dpr_fadeInDownBig',

							esc_html__('fadeInLeft', 'dpr-adeline-extensions')	=> 'dpr_fadeInLeft',

							esc_html__('fadeInLeftBig', 'dpr-adeline-extensions')	=> 'dpr_fadeInLeftBig',

							esc_html__('fadeInRight', 'dpr-adeline-extensions')	=> 'dpr_fadeInRight',

							esc_html__('fadeInRightBig', 'dpr-adeline-extensions')	=> 'dpr_fadeInRightBig',

							esc_html__('fadeInUp', 'dpr-adeline-extensions')	=> 'dpr_fadeInUp',

							esc_html__('fadeInUpBig', 'dpr-adeline-extensions')	=> 'dpr_fadeInUpBig',

							esc_html__('flipInX', 'dpr-adeline-extensions')	=> 'dpr_flipInX',

							esc_html__('flipInY', 'dpr-adeline-extensions')	=> 'dpr_flipInY',

							esc_html__('lightSpeedIn', 'dpr-adeline-extensions')	=> 'dpr_lightSpeedIn',

							esc_html__('rotateIn', 'dpr-adeline-extensions')	=> 'dpr_rotateIn',

							esc_html__('rotateInDownLeft', 'dpr-adeline-extensions')	=> 'dpr_rotateInDownLeft',

							esc_html__('rotateInDownRight', 'dpr-adeline-extensions')	=> 'dpr_rotateInDownRight',

							esc_html__('rotateInUpLeft', 'dpr-adeline-extensions')	=> 'dpr_rotateInUpLeft',

							esc_html__('rotateInUpRight', 'dpr-adeline-extensions')	=> 'dpr_rotateInUpRight',

							esc_html__('rollIn', 'dpr-adeline-extensions')	=> 'dpr_rollIn',

							esc_html__('zoomIn', 'dpr-adeline-extensions')	=> 'dpr_zoomIn',

							esc_html__('zoomInDown', 'dpr-adeline-extensions')	=> 'dpr_zoomInDown',

							esc_html__('zoomInLeft', 'dpr-adeline-extensions')	=> 'dpr_zoomInLeft',

							esc_html__('zoomInRight', 'dpr-adeline-extensions')	=> 'dpr_zoomInRight',

							esc_html__('zoomInUp', 'dpr-adeline-extensions')	=> 'dpr_zoomInUp',

							esc_html__('slideInDown', 'dpr-adeline-extensions')	=> 'dpr_slideInDown',

							esc_html__('slideInLeft', 'dpr-adeline-extensions')	=> 'dpr_slideInLeft',

							esc_html__('slideInRight', 'dpr-adeline-extensions')	=> 'dpr_slideInRight',

							esc_html__('slideInUp', 'dpr-adeline-extensions')	=> 'dpr_slideInUp',

							esc_html__('top-to-bottom', 'dpr-adeline-extensions')	=> 'dpr_Top to bottom',

							esc_html__('bottom-to-top', 'dpr-adeline-extensions')	=> 'dpr_Bottom to top',

							esc_html__('left-to-right', 'dpr-adeline-extensions')	=> 'dpr_Left to right',

							esc_html__('right-to-left', 'dpr-adeline-extensions')	=> 'dpr_Right to left',

							esc_html__('appear', 'dpr-adeline-extensions')	=> 'dpr_Appear from center',

						),

					

					)

				),

				'group'				=> esc_html__('Stack images', 'dpr-adeline-extensions'),

			),

		),

		

	)

);