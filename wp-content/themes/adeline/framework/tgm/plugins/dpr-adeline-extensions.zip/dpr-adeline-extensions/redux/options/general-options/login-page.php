<?php



/**



 * General Options -> Login Page



 * 



 */







	Redux::setSection( $opt_name, array(



		'title' => esc_html__('Login Page', 'dpr-adeline-extensions'),



		'subsection' => true,



		'id' => 'general_login_page',



		'fields' => array(



					array(



						'id' => 'branding_login_logo',



						'type' => 'media',



						'title' => esc_html__('Login Page Logo', 'dpr-adeline-extensions'),



						'default' => array(



						'url' => $assets_folder . 'img/logo/login_logo.png'



						),



						'compiler' => '',



						'hint' => array(



							'title'   => esc_attr__('Login Page Logo','dpr-adeline-extensions'),



							'content' => esc_attr__('Select image for login page branding logo','dpr-adeline-extensions')



						)



					),



					array(         



						'id'       => 'branding_login_bg_color',



						'type'     => 'color',



						'title'    => __('Login Page Background Color', 'dpr-adeline-extensions'),



						'default'  => '#f1f2f4',



						'hint' => array(



							'title'   => esc_attr__('Login Page Background Color','dpr-adeline-extensions'),



							'content' => esc_attr__('Set body background color for login page.','dpr-adeline-extensions')



						)



					),



					array(         



						'id'       => 'branding_login_text_color',



						'type'     => 'color',



						'title'    => __('Login Page Text Color', 'dpr-adeline-extensions'),



						'default'  => '#292933',



						'hint' => array(



							'title'   => esc_attr__('Login Page Text Color','dpr-adeline-extensions'),



							'content' => esc_attr__('Set color for links on login page.','dpr-adeline-extensions')



						)



					),	



					array(



						'id' => 'branding_login_bg_img',



						'type' => 'media',



						'title' => esc_html__('Login Page Background Image', 'dpr-adeline-extensions'),



						'hint' => array(



							'title'   => esc_attr__('Login Page Background Image','dpr-adeline-extensions'),



							'content' => esc_attr__('Select image for login page','dpr-adeline-extensions')



						)



					),



					)



	));