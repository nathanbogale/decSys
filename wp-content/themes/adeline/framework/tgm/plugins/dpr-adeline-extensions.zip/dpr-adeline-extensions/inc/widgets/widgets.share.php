<?php

/**

 * Share Buttons Widget.

 *

 */



// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}



if ( ! class_exists( 'DPR_Share_Buttons_Widget' ) ) {

	class DPR_Share_Buttons_Widget extends WP_Widget {



		/**

		 * Register widget with WordPress.

		 *

		 * @since 1.0.0

		 */

		public function __construct() {

			parent::__construct(

				'dpr_share',

				esc_html__( 'DPR Social Share', 'dpr-adeline-extensions' ),

				array(

					'classname'   => 'widget-dpr-share',

					'description' => esc_html__( 'Display social share buttons.', 'dpr-adeline-extensions' ),

					'customize_selective_refresh' => true,

				)

			);



			$this->defaults = array(

				'title'      => esc_html__( 'Share This', 'dpr-adeline-extensions' ),

				'layout'	=> 'horizontal',

				'style'    => 'minimal',

				'rounded_style' => '',

				'button_size' => 'small-buttons',

				'alignment' => '',

				'full_width' =>'',

				'facebook' => '',

				'twitter' => '',

				'google' => '',

				'pinterest' => '',

				'linkedin' => '',

				'button_spacing' => '5',

				'border_radius' => '3',

				'dark_bg' => '',

				'custom_class' => ''

			);

		}



		/**

		 * Front-end display of widget.

		 *

		 * @see WP_Widget::widget()

		 * @since 1.0.0

		 *

		 * @param array $args     Widget arguments.

		 * @param array $instance Saved values from database.

		 */

		public function widget( $args, $instance ) {



			// Parse instance

			extract( wp_parse_args( $instance, $this->defaults ) );

			

			// Apply filters to the title

			$title = isset( $instance['title'] ) ? apply_filters( 'widget_title', $instance['title'] ) : '';



			// Before widget WP hook

			echo $args['before_widget'];



				// Show widget title

				if ( $title ) {

					echo $args['before_title'] . esc_html( $title ) . $args['after_title'];

				} 



				$shortcode = '[dpr_share';

				$shortcode .= ' style="'.$style.'" ';

				$shortcode .= ' layout="'.$layout.'" ';

				if ($button_size != '') {

				$shortcode .= ' button_size="'.$button_size.'" ';

				}

				if ($style == 'rounded' && $rounded_style == 'rounded-filed' ) {

				$shortcode .= ' rounded_style="'.$rounded_style.'" ';

				}

				$shortcode .= ' alignment="'.$alignment.'" ';

				

				if ($border_radius != '') {

				$shortcode .= ' button_border_radius="'.$border_radius.'"';

				}

				if ($layout == 'horizontal' && $button_spacing != '') {

				$shortcode .= ' button_padding="'.$button_spacing.'" ';

				}

				if ($layout == 'vertical' && $button_spacing != '') {

				$shortcode .= ' button_gapping="'.$button_spacing.'" ';

				}

				if ($facebook == 'on') {

				$shortcode .= ' facebook_link="yes"';

				}

				if ($twitter == 'on') {

				$shortcode .= ' twitter_link="yes"';

				}

				if ($google == 'on') {

				$shortcode .= ' google_link="yes"';

				}

				if ($pinterest == 'on') {

				$shortcode .= ' pinterest_link="yes"';

				}

				if ($linkedin == 'on') {

				$shortcode .= ' linkedin_link="yes"';

				}

				$shortcode .= ']';

				

				$classes = '';

				if ($dark_bg =='on') {

					$classes .= ' on-dark-bg';

				}

				if ($custom_class !='') {

					$classes .= ' '.$custom_class;

				}



				echo '<div class="dpr-widget-share-wrap'.$classes.'">';

				echo do_shortcode( $shortcode );

				echo '</div>';







			// After widget WP hook

			echo $args['after_widget'];



		}



		/**

		 * Sanitize widget form values as they are saved.

		 *

		 * @see WP_Widget::update()

		 * @since 1.0.0

		 *

		 * @param array $new_instance Values just sent to be saved.

		 * @param array $old_instance Previously saved values from database.

		 *

		 * @return array Updated safe values to be saved.

		 */

		public function update( $new_instance, $old_instance ) {

			$instance 				= $old_instance;

			$instance['title']      = ! empty( $new_instance['title'] ) ? strip_tags( $new_instance['title'] ) : '';

			$instance['layout']  = ! empty( $new_instance['layout'] ) ? strip_tags( $new_instance['layout'] ) : '';

			$instance['style']   = ! empty( $new_instance['style'] ) ? strip_tags( $new_instance['style'] ) : '';

			$instance['rounded_style']   = ! empty( $new_instance['rounded_style'] ) ? strip_tags( $new_instance['rounded_style'] ) : '';

			$instance['button_size']    = ! empty( $new_instance['button_size'] ) ? strip_tags( $new_instance['button_size'] ) : '';

			$instance['alignment']    = ! empty( $new_instance['alignment'] ) ? strip_tags( $new_instance['alignment'] ) : '';

			$instance['full_width']      = ! empty( $new_instance['full_width'] ) ? strip_tags( $new_instance['full_width'] ) : '';

			$instance['facebook']      = ! empty( $new_instance['facebook'] ) ? strip_tags( $new_instance['facebook'] ) : '';

			$instance['twitter']    = ! empty( $new_instance['twitter'] ) ? strip_tags( $new_instance['twitter'] ) : '';

			$instance['google']    = ! empty( $new_instance['google'] ) ? strip_tags( $new_instance['google'] ) : '';

			$instance['pinterest']    = ! empty( $new_instance['pinterest'] ) ? strip_tags( $new_instance['pinterest'] ) : '';

			$instance['linkedin']    = ! empty( $new_instance['linkedin'] ) ? strip_tags( $new_instance['linkedin'] ) : '';

			$instance['button_spacing']    = ! empty( $new_instance['button_spacing'] ) ? strip_tags( $new_instance['button_spacing'] ) : '';

			$instance['border_radius']    = ! empty( $new_instance['border_radius'] ) ? strip_tags( $new_instance['border_radius'] ) : '';

			$instance['dark_bg']    = ! empty( $new_instance['dark_bg'] ) ? strip_tags( $new_instance['dark_bg'] ) : '';

			$instance['custom_class']    = ! empty( $new_instance['custom_class'] ) ? strip_tags( $new_instance['custom_class'] ) : '';

			return $instance;

		}



		/**

		 * Back-end widget form.

		 *

		 * @see WP_Widget::form()

		 * @since 1.0.0

		 *

		 * @param array $instance Previously saved values from database.

		 */

		public function form( $instance ) {

		

			$instance = wp_parse_args( (array) $instance, $this->defaults ); ?>



			

			<p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title', 'dpr-adeline-extensions' ); ?></label> 

				<input class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['title'] ); ?>" />

			</p>



            <p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'facebook' ) ); ?>">

					<input type="checkbox" name="<?php echo esc_attr( $this->get_field_name( 'facebook' ) ); ?>" id="<?php echo esc_attr( $this->get_field_id( 'facebook' ) ); ?>" <?php checked( $instance['facebook'] , 'on' ); ?> />

					<?php esc_html_e( 'Display Facebook share button', 'dpr-adeline-extensions' ); ?>

				</label>

			</p>

            

            <p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'twitter' ) ); ?>">

					<input type="checkbox" name="<?php echo esc_attr( $this->get_field_name( 'twitter' ) ); ?>" id="<?php echo esc_attr( $this->get_field_id( 'twitter' ) ); ?>" <?php checked( $instance['twitter'] , 'on' ); ?> />

					<?php esc_html_e( 'Display Twitter share button', 'dpr-adeline-extensions' ); ?>

				</label>

			</p>

            

            <p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'google' ) ); ?>">

					<input type="checkbox" name="<?php echo esc_attr( $this->get_field_name( 'google' ) ); ?>" id="<?php echo esc_attr( $this->get_field_id( 'google' ) ); ?>" <?php checked( $instance['google'] , 'on' ); ?> />

					<?php esc_html_e( 'Display Google+ share button', 'dpr-adeline-extensions' ); ?>

				</label>

			</p>

            

            <p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'pinterest' ) ); ?>">

					<input type="checkbox" name="<?php echo esc_attr( $this->get_field_name( 'pinterest' ) ); ?>" id="<?php echo esc_attr( $this->get_field_id( 'pinterest' ) ); ?>" <?php checked( $instance['pinterest'] , 'on' ); ?> />

					<?php esc_html_e( 'Display Pinterest share button', 'dpr-adeline-extensions' ); ?>

				</label>

			</p>

            

            <p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'linkedin' ) ); ?>">

					<input type="checkbox" name="<?php echo esc_attr( $this->get_field_name( 'linkedin' ) ); ?>" id="<?php echo esc_attr( $this->get_field_id( 'linkedin' ) ); ?>" <?php checked( $instance['linkedin'] , 'on' ); ?> />

					<?php esc_html_e( 'Display LinkedIn share button', 'dpr-adeline-extensions' ); ?>

				</label>

			</p>









			<div class="dpr-widget-inner-block">

				<h2><?php esc_html_e('Style Options:', 'dpr-adeline-extensions'); ?></h2>

			<p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'layout' ) ); ?>"><?php esc_html_e( 'Layout', 'dpr-adeline-extensions' ); ?></label>

				<select class='widefat' name="<?php echo $this->get_field_name( 'layout' ); ?>" id="<?php echo $this->get_field_id( 'layout' ); ?>">

					<option value="horizontal" <?php if ( $instance['layout'] == 'horizontal') { ?>selected="selected"<?php } ?>><?php esc_html_e( 'Horizontal', 'dpr-adeline-extensions' ); ?></option>

					<option value="vertical" <?php if ( $instance['layout'] == 'vertical') { ?>selected="selected"<?php } ?>><?php esc_html_e( 'Vertical', 'dpr-adeline-extensions' ); ?></option>

				</select>

			</p>

			<p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'style' ) ); ?>"><?php esc_html_e( 'Style', 'dpr-adeline-extensions' ); ?></label>

				<select class='widefat' name="<?php echo $this->get_field_name( 'style' ); ?>" id="<?php echo $this->get_field_id( 'style' ); ?>">

					<option value="minimal" <?php if ( $instance['style'] == 'minimal') { ?>selected="selected"<?php } ?>><?php esc_html_e( 'Minimal', 'dpr-adeline-extensions' ); ?></option>

					<option value="flat" <?php if ( $instance['style'] == 'flat') { ?>selected="selected"<?php } ?>><?php esc_html_e( 'Flat', 'dpr-adeline-extensions' ); ?></option>

					<option value="rounded" <?php if ( $instance['style'] == 'rounded') { ?>selected="selected"<?php } ?>><?php esc_html_e( 'Rounded', 'dpr-adeline-extensions' ); ?></option>

					<option value="expandable" <?php if ( $instance['style'] == 'expandable') { ?>selected="selected"<?php } ?>><?php esc_html_e( 'Expandable', 'dpr-adeline-extensions' ); ?></option>

				</select>

			</p>

			<p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'rounded_style' ) ); ?>"><?php esc_html_e( 'Rounded Buttons Style', 'dpr-adeline-extensions' ); ?></label>

				<select class='widefat' name="<?php echo $this->get_field_name( 'rounded_style' ); ?>" id="<?php echo $this->get_field_id( 'rounded_style' ); ?>">

					<option value="" <?php if ( $instance['rounded_style'] == '') { ?>selected="selected"<?php } ?>><?php esc_html_e( 'Outlined', 'dpr-adeline-extensions' ); ?></option>

					<option value="rounded-filed" <?php if ( $instance['rounded_style'] == 'rounded-filed') { ?>selected="selected"<?php } ?>><?php esc_html_e( 'Filed', 'dpr-adeline-extensions' ); ?></option>

				</select>

                <small><?php echo esc_html__('It only affects the rounded style', 'dpr-adeline-extensions') ; ?></small>



                

			</p>

			<p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'button_size' ) ); ?>"><?php esc_html_e( 'Button Size', 'dpr-adeline-extensions' ); ?></label>

				<select class='widefat' name="<?php echo $this->get_field_name( 'button_size' ); ?>" id="<?php echo $this->get_field_id( 'button_size' ); ?>">

					<option value="small-buttons" <?php if ( $instance['button_size'] == 'small-buttons') { ?>selected="selected"<?php } ?>><?php esc_html_e( 'Small', 'dpr-adeline-extensions' ); ?></option>

					<option value="medium-buttons" <?php if ( $instance['button_size'] == 'medium-buttons') { ?>selected="selected"<?php } ?>><?php esc_html_e( 'Medium', 'dpr-adeline-extensions' ); ?></option>

					<option value="" <?php if ( $instance['button_size'] == '') { ?>selected="selected"<?php } ?>><?php esc_html_e( 'Large', 'dpr-adeline-extensions' ); ?></option>

				</select>

			</p>

			<p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'alignment' ) ); ?>"><?php esc_html_e( 'Button Alignment', 'dpr-adeline-extensions' ); ?></label>

				<select class='widefat' name="<?php echo $this->get_field_name( 'alignment' ); ?>" id="<?php echo $this->get_field_id( 'alignment' ); ?>">

					<option value="" <?php if ( $instance['alignment'] == '') { ?>selected="selected"<?php } ?>><?php esc_html_e( 'Left', 'dpr-adeline-extensions' ); ?></option>

					<option value="text-center" <?php if ( $instance['alignment'] == 'text-center') { ?>selected="selected"<?php } ?>><?php esc_html_e( 'Center', 'dpr-adeline-extensions' ); ?></option>

					<option value="text-right" <?php if ( $instance['alignment'] == 'text-right') { ?>selected="selected"<?php } ?>><?php esc_html_e( 'Right', 'dpr-adeline-extensions' ); ?></option>

				</select>

			</p>



			<p >

				<label for="<?php echo esc_attr( $this->get_field_id( 'border_radius' ) ); ?>"><?php esc_html_e( 'Border radius (px)', 'dpr-adeline-extensions' ); ?></label> 

				<input class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'border_radius' ) ); ?>" type="number" min="0" step="1" value="<?php echo esc_attr( $instance['border_radius'] ); ?>" />

                <small><?php echo esc_html__('It only affects the minimal and flat style', 'dpr-adeline-extensions') ; ?></small>

            </p>



			<p >

				<label for="<?php echo esc_attr( $this->get_field_id( 'button_spacing' ) ); ?>"><?php esc_html_e( 'Button spacing (px)', 'dpr-adeline-extensions' ); ?></label> 

				<input class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'button_spacing' ) ); ?>" type="number" min="0" step="1" value="<?php echo esc_attr( $instance['button_spacing'] ); ?>" />

            </p>



            <p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'dark_bg' ) ); ?>">

					<input type="checkbox" name="<?php echo esc_attr( $this->get_field_name( 'dark_bg' ) ); ?>" id="<?php echo esc_attr( $this->get_field_id( 'dark_bg' ) ); ?>" <?php checked( $instance['dark_bg'] , 'on' ); ?> />

					<?php esc_html_e( 'On dark background style', 'dpr-adeline-extensions' ); ?>

				</label>

			</p>



			<p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'custom_class' ) ); ?>"><?php esc_html_e( 'Custom CSS Class', 'dpr-adeline-extensions' ); ?></label>

				<input class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'custom_class' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['custom_class'] ); ?>" />

			</p>



			</div>

		<?php



		}



	}

}