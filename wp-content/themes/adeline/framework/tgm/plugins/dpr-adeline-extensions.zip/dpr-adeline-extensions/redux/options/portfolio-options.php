<?php



/**



 * Portfolio Options



 * 



 */







    Redux::setSection( $opt_name, array(



        'title'  => __( 'Portfolio', 'dpr-adeline-extensions' ),



        'id'     => 'portfolio_tab',



        'icon'   => 'el el-folder-open'



    ) );



	require_once($options_dir . '/portfolio-options/base.php');



	require_once($options_dir . '/portfolio-options/source.php');



	require_once($options_dir . '/portfolio-options/layout.php');



	require_once($options_dir . '/portfolio-options/filter.php');



	require_once($options_dir . '/portfolio-options/style.php');



	require_once($options_dir . '/portfolio-options/single-portfolio.php');



