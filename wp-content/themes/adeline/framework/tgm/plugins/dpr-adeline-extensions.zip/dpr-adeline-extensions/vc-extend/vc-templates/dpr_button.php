<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$output = $unique_id = $style = $css_animation = $el_class = $inner_class  = $custom_el_css = $open_tag_html = $close_tag_html = '';
$title = $link = $type = $style = $size = $shape = $full_width = $button_alignment = $icon = $icon_size = $icon_color = $icon_color_hover = '';
$padding_left = $padding_right = $button_color = $button_color_hover = $button_bg_color = $button_bg_color_hover = $use_gradient_bg = $use_gradient_bg_hover = $button_gradient = $button_gradient_hover =  '';
$border_animation = $button_border_color = $button_border_color_hover  = $border_radius = $border_radius_hover = $border_width = $border_style = $button_shadow = $button_shadow_hover = '';
$title_typo_style = $title_color = $title_font_size = $title_line_height = $title_letter_spacing = $title_font_style = $title_google_font = $title_html = $icon_html = '';

$atts = vc_map_get_attributes( 'dpr_button', $atts );
extract( $atts );

$unique_id = uniqid('dpr-button-').'-'.rand(1,9999);


if ( '' !== $css_animation && 'none' !== $css_animation ) {
	dpr_enqueue_waypoint_js();
	dpr_enqueue_animate_css();
	$el_class .= ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
}

$el_class .= ' '.esc_attr($type).' '.esc_attr($button_alignment);

$inner_class .= 'btn '.esc_attr($style).' '.esc_attr($shape).' '.esc_attr($size).' '.$unique_id;

if(isset($type) && $type == 'type-2') {
	$inner_class .= ' btn-with-icon btn-icon-left';
}

if(isset($type) && $type == 'type-3') {
	$inner_class .= ' btn-with-icon btn-icon-right';
}

if(isset($type) && $type == 'type-4') {
	$inner_class .= ' btn-with-icon btn-icon-left btn-icon-animated';
}

if(isset($type) && $type == 'type-5') {
	$inner_class .= ' btn-with-icon btn-icon-right btn-icon-animated';
}

if(isset($type) && $type == 'type-6') {
	$inner_class .= ' btn-with-icon btn-icon-top btn-icon-animated';
}

if(isset($border_animation) && $border_animation == 'ripple-in') {
	$inner_class .= ' btn-border-animated btn-ripple-in'; 
}

if(isset($border_animation) && $border_animation == 'ripple-out') {
	$inner_class .= ' btn-border-animated btn-ripple-out'; 
}

if( $full_width == 'yes') {
$inner_class .= ' btn-block';
}

if(isset($button_color) && !empty($button_color)) {
	$custom_el_css .= '.'.esc_js($unique_id) .', .'.esc_js($unique_id) .'.btn.btn-min {color:'.$button_color.'!important;}';
}

if(isset($button_color_hover) && !empty($button_color_hover)) {
	$custom_el_css .= '.'.esc_js($unique_id) .':hover,.'.esc_js($unique_id) .'.btn.btn-min:hover{color: '.esc_js($button_color_hover).'!important;}';
}

if(isset($button_bg) && !empty($button_bg)) {
	$custom_el_css .= '.'.esc_js($unique_id) .' { background-color:'.esc_js($button_bg).'!important;}';
}

if(isset($button_bg_hover) && !empty($button_bg_hover)) {
	$custom_el_css .= '.'.esc_js($unique_id) .':hover {background-color: '.esc_js($button_bg_hover).'!important;}';
}

if(isset($use_gradient_bg) && !empty($use_gradient_bg)) {
	if(isset($button_gradient) && !empty($button_gradient)) {
		$custom_el_css .= '.'.esc_js($unique_id).'{'.esc_js(adeline_gradientToBgCSS ($button_gradient)).';}';
	}
}

if(isset($use_gradient_bg_hover) && !empty($use_gradient_bg_hover)) {
	if(isset($button_gradient_hover) && !empty($button_gradient_hover)) {
		$custom_el_css .= '.'.esc_js($unique_id).':hover {'.esc_js(adeline_gradientToBgCSS ($button_gradient_hover)).';}';
	}
}


if(isset($button_border_color) && !empty($button_border_color)) {
	$custom_el_css .= '.'.esc_js($unique_id) .' { border-color:'.esc_js($button_border_color).'!important;}';
}

if(isset($button_border_color_hover) && !empty($button_border_color_hover)) {
	$custom_el_css .= '.'.esc_js($unique_id) .':hover {border-color: '.esc_js($button_border_color_hover).'!important;}';
}

if(isset($border_radius) && !empty($border_radius)) {
	$custom_el_css .= '.'.esc_js($unique_id) .' { border-radius:'.esc_js($border_radius).'px !important;}';
}

if(isset($hover_border_radius) && !empty($hover_border_radius)) {
	$custom_el_css .= '.'.esc_js($unique_id) .':hover { border-radius:'.esc_js($hover_border_radius).'px !important;}';
}

if(isset($border_width) ) {
	$custom_el_css .= '.'.esc_js($unique_id) .' { border-width:'.esc_js($border_width).'px;}';
}

if(isset($border_style) && !empty($border_style)) {
	$custom_el_css .= '.'.esc_js($unique_id) .' { border-style:'.esc_js($border_style).';}';
}

if(isset($icon_size) && !empty($icon_size)) {
	$custom_el_css .= '.'.esc_js($unique_id) .' .button-icon-wrapper { font-size:'.esc_js($icon_size).'px;}';
}

if(isset($icon_color) && !empty($icon_color)) {
	$custom_el_css .= '.'.esc_js($unique_id) .' .button-icon-wrapper { color:'.esc_js($icon_color).';}';
}

if(isset($icon_color_hover) && !empty($icon_color_hover)) {
	$custom_el_css .= '.'.esc_js($unique_id) .':hover .button-icon-wrapper { color:'.esc_js($icon_color_hover).';}';
}

if(dpr_shadow_param_to_css($button_shadow) != '') {
	$custom_el_css .= '.'.esc_js($unique_id) .' {'.dpr_shadow_param_to_css($button_shadow).'}';
}

if(dpr_shadow_param_to_css($button_shadow_hover) != '') {
	$custom_el_css .= '.'.esc_js($unique_id) .':hover {'.dpr_shadow_param_to_css($button_shadow_hover).'}';
}


if(isset($link) ) {
	$link = vc_build_link($link);
	$link_target = !empty($link['target']) ? 'target="'.esc_attr(preg_replace('/\s+/', '', $link['target'])).'"' : '';
}
if(isset($link) && $link['url'] != '' ) {
	$link_target = !empty($link['target']) ? 'target="'.esc_attr(preg_replace('/\s+/', '', $link['target'])).'"' : '';
	$open_tag_html .= '<a id="'.esc_attr($unique_id).'" href="'.esc_url($link['url']).'" title="'.esc_attr($link['title']).'" '.$link_target.' rel="'.esc_attr($link['rel']).'" class ="'.esc_attr($inner_class).'">';
	$close_tag_html .= '</a>';
}else{
	$open_tag_html .= '<span id="'.esc_attr($unique_id).'" class ="'.esc_attr($inner_class).'">';
	$close_tag_html .= '</span>';
}

if(!empty($title)) {
	$title_typo_style = dpr_generate_typography_style($title_color, $title_font_size, $title_line_height, $title_letter_spacing, $title_font_style,$title_google_font);
	$title_html .= '<span class="button-text " '.$title_typo_style.'>'.wp_kses($title, array('span' => array(),'br' => array())).'</span>';
}

if(isset($icon) && $icon !='none' && $icon !='') {
	$icon_html = '<span class="button-icon-wrapper"><i class="'.esc_attr($icon).'"></i></span>';
}




$output .= '<div class="dpr-button-wrapper '.esc_attr($el_class).'">';

$output .= $open_tag_html;

if( $type == 'type-2' || $type == 'type-4' || $type == 'type-6') {
$output .= $icon_html;
}

$output .= $title_html;

if( $type == 'type-3' || $type == 'type-5') {
$output .= $icon_html;
}

$output .= $close_tag_html;

	if(!empty($custom_el_css)) {
		$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>");'
						. '})(jQuery);'
					. '</script>';
}


$output .= '</div>';

echo $output;