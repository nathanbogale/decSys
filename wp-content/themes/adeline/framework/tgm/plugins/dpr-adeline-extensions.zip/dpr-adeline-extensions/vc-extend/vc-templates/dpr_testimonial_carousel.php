<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$unique_id = $css_animation = $el_class = $carousel_wrap_class = $testimonial_class = $output = $custom_el_css = $style = $layout = '';
$testimonials = $img_size = $img_border_radius = $enable_shadow = $image_shadow = $bg_color = $bg_border_radius = $enable_arrow = '';
$title = $title_color = $title_font_size = $title_line_height  = $title_letter_spacing = $title_font_style = $title_google_font = $title_typo_style = '';
$subtitle = $subtitle_color = $subtitle_font_size = $subtitle_line_height  = $subtitle_letter_spacing = $subtitle_font_style = $subtitle_google_font = $subtitle_typo_style = $one_line_title = '';
$description = $content_color = $content_font_size = $content_line_height  = $content_letter_spacing = $content_font_style = $content_google_font = $content_typo_style = '';
$arrows = $arrows_position = $arrow_icon = $arrow_icon_size = $arrow_icon_color = $arrow_icon_color_hover = $arrow_bg_border_radius = $arrow_bg_border_width = $arrow_bg_color = $arrow_bg_color_hover = $arrow_bg_border_color = $arrow_bg_border_color_hover = $arrow_use_shadow_on_hover = $arrow_hover_shadow = $arrow_allways_visible = $arrow_use_numbers = $arrow_numbers_color = ''; 
$slick_settings = $thumb_nav_setting = $speed = $items_offset = $draggable = $touchable = $center_padding = $inactive_opacity = '';
$left_arrow_html = $right_arrow_html = $counter_html = '';
$pagination_alignment = '';
$content_html = $thumb_nav_html = '';





$atts = vc_map_get_attributes( 'dpr_testimonial_carousel', $atts );
extract( $atts );
if($center_padding == '')  {
	$center_padding == 0;
}
if($speed == '')  {
	$speed = 300;
}


$el_class = $this->getExtraClass( $el_class );
if ( '' !== $css_animation && 'none' !== $css_animation ) {
	dpr_enqueue_waypoint_js();
	dpr_enqueue_animate_css();
	$el_class .= ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
}
$unique_id = uniqid('dpr-tesimonial-carousel-').'-'.rand(1,9999);
$carousel_id = uniqid('dpr-carousel-').'-'.rand(1,9999);
$carousel_nav_id =  uniqid('dpr-carousel-nav-').'-'.rand(1,9999);
/* Element classes */
if(isset($layout)) {
	$el_class .= ' '.$layout;
}

$css_classes = array(
	'dpr-carousel-wrap dpr-testimonial-carousel',
	$pagination_alignment,
	$el_class,
);

$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->settings['base'], $atts ) );

/* Testimonial classes */
	$testimonial_class = 'style-2';
if(isset($image_position) && $image_position == 'image-bellow') {
	$testimonial_class = ' style-1';
}
if(isset($one_line_title) && $one_line_title == 'yes') {
	$testimonial_class .= ' one-line-title';
}
if(isset($enable_shadow) && $enable_shadow == 'yes') {
	$testimonial_class .= ' img-with-shadow';
}

if(isset($bg_color) && $bg_color != '') {
	$testimonial_class .= ' bubble-with-bg';
}
if(isset($enable_arrow) && $enable_arrow == 'yes') {
	$testimonial_class .= ' bubble-with-arrow';
}

if(isset($content_alignment)) {
	$testimonial_class .= ' '.$content_alignment;
}

/* * ************************
 * Styles and custom CSS
 * *********************** */
if (isset($enable_shadow) && $enable_shadow == 'yes') {
		$custom_el_css .= '#'.esc_js($unique_id) .' .dpr-testimonial .image-wrap .inner img, #'.esc_js($unique_id) .' .dpr-carousel-nav .image-wrap .inner img {'.dpr_shadow_param_to_css($image_shadow).'}';
		$custom_el_css .= '#'.esc_js($unique_id) .' .dpr-carousel-nav .slick-list {padding:20px 0 !important;}';
}
if($img_size == '') {
	$img_size = 90;
}
$custom_el_css .= '#'.esc_js($unique_id) .' .dpr-testimonial .image-wrap .inner img,#'.esc_js($unique_id) .' .dpr-carousel-nav .image-wrap .inner img {width:'.$img_size.'px; height:'.$img_size.'px;}';

if(isset($img_border_radius) && $img_border_radius !='' ) {
	$custom_el_css .= '#'.esc_js($unique_id) .' .dpr-testimonial .image-wrap .inner img,#'.esc_js($unique_id) .' .dpr-carousel-nav .image-wrap .inner img {border-radius:'.$img_border_radius.'px;}';
}
if($layout == 'layout-2') {
	$custom_el_css .= '#'.esc_js($unique_id) .' .dpr-carousel-nav {width:'.round($img_size*3.333).'px;}';
}
if (isset($bg_color) && $bg_color != '') {
	$custom_el_css .= '#'.esc_js($unique_id).' .dpr-testimonial.bubble-with-bg .box-content {background-color:'.esc_attr($bg_color).';}';
}
if (isset($bg_border_radius) && $bg_border_radius != '') {
		$custom_el_css .= '#'.esc_js($unique_id) .' .dpr-testimonial.bubble-with-bg .box-content  {border-radius:'.$bg_border_radius.'px;}';
}
if (isset($enable_arrow) && $enable_arrow == 'yes' && $bg_color != '' ) {
		$arrow_offset_left = 45;
		$arrow_offset_right = 30;
		if(isset($img_size) && $img_size !='') {
			$arrow_offset_left = round($img_size/2);
			$arrow_offset_right = round(($img_size/2)-15);
		}
		$custom_el_css .= '#'.esc_js($unique_id) .' .dpr-testimonial .box-content-wrap:after {border-color: '.$bg_color.' transparent;}';
		$custom_el_css .= '#'.esc_js($unique_id) .' .dpr-testimonial.text-right .box-content-wrap:after {left:auto;right:'.$arrow_offset_right.'px;}';
		$custom_el_css .= '#'.esc_js($unique_id) .' .dpr-testimonial.text-left .box-content-wrap:after {left:'.$arrow_offset_left.'px;}';
}
if($items_offset != '') {
	$custom_el_css .= '#'.esc_js($unique_id).' .slick-slide {padding: '.esc_js($items_offset/2).'px;}';
}

if($dots_color_inactive != '') {
	$custom_el_css .=	'#'.esc_js($unique_id).' .dpr-dots-outline-square .slick-slider .dpr-slick-dots li, #'.esc_js($unique_id).' .dpr-dots-outline-round .slick-slider .dpr-slick-dots li, #'.esc_js($unique_id).' .dpr-dots-outline-bar .slick-slider .dpr-slick-dots li  {border-color: '.esc_js($dots_color_inactive).'}';
	$custom_el_css .=	'#'.esc_js($unique_id).' .dpr-dots-flat-round .slick-slider .dpr-slick-dots li, #'.esc_js($unique_id).' .dpr-dots-flat-rounded .slick-slider .dpr-slick-dots li, #'.esc_js($unique_id).' .dpr-dots-flat-square .slick-slider .dpr-slick-dots li  {background-color: '.esc_js($dots_color_inactive).'}';
}
if($dots_color != '') {
	$custom_el_css .=	'#'.esc_js($unique_id).' .dpr-dots-outline-square .slick-slider .dpr-slick-dots li:hover, #'.esc_js($unique_id).' .dpr-dots-outline-round .slick-slider .dpr-slick-dots li:hover, #'.esc_js($unique_id).' .dpr-dots-outline-bar .slick-slider .dpr-slick-dots li:hover {border-color: '.esc_js($dots_color).';background-color: '.esc_js($dots_color).'}';
	$custom_el_css .=	'#'.esc_js($unique_id).' .dpr-dots-flat-round .slick-slider .dpr-slick-dots li:hover, #'.esc_js($unique_id).' .dpr-dots-flat-rounded .slick-slider .dpr-slick-dots li:hover, #'.esc_js($unique_id).' .dpr-dots-flat-square .slick-slider .dpr-slick-dots li:hover  {background-color: '.esc_js($dots_color).'}';
	$custom_el_css .=	'#'.esc_js($unique_id).' .dpr-dots-outline-square .slick-slider .dpr-slick-dots li.slick-active, #'.esc_js($unique_id).' .dpr-dots-outline-round .slick-slider .dpr-slick-dots li.slick-active, #'.esc_js($unique_id).' .dpr-dots-outline-bar .slick-slider .dpr-slick-dots li.slick-active {border-color: '.esc_js($dots_color).';background-color: '.esc_js($dots_color).'}';
	$custom_el_css .=	'#'.esc_js($unique_id).' .dpr-dots-flat-round .slick-slider .dpr-slick-dots li.slick-active, #'.esc_js($unique_id).' .dpr-dots-flat-rounded .slick-slider .dpr-slick-dots li.slick-active, #'.esc_js($unique_id).' .dpr-dots-flat-square .slick-slider .dpr-slick-dots li.slick-active  {background-color: '.esc_js($dots_color).'}';
}

if($dots_spacing != '') {
	$dots_margin = intval($dots_spacing/2);
	$custom_el_css .=	'#'.esc_js($unique_id).' .dpr-carousel-wrap-inner .dpr-slick-dots li {margin-left: '.esc_js($dots_margin).'px;margin-right: '.esc_js($dots_margin).'px}';
}

if($dots_top_margin != '') {
	$custom_el_css .=	'#'.esc_js($unique_id).' .dpr-carousel-wrap-inner .dpr-slick-dots {margin-top: '.esc_js($dots_top_margin).'px;}';
}

$title_typo_style = dpr_generate_typography_style($title_color, $title_font_size, $title_line_height, $title_letter_spacing, $title_font_style,$title_google_font);
$subtitle_typo_style = dpr_generate_typography_style($subtitle_color, $subtitle_font_size, $subtitle_line_height, $subtitle_letter_spacing, $subtitle_font_style,$subtitle_google_font);
$content_typo_style = dpr_generate_typography_style($content_color, $content_font_size, $content_line_height, $content_letter_spacing, $content_font_style,$content_google_font);
if($inactive_opacity != '' && $layout =='layout-3') {
	$custom_el_css .=	'#'.esc_js($unique_id).'.layout-3 .slick-slide:not(.slick-center) {opacity: '.esc_js(($inactive_opacity/100)).'}';
}
/* * ************************
 * Carousel Settings
 * *********************** */
$slick_settings .= 'arrows: false,';
$slick_settings .= 'dotsClass: \'dpr-slick-dots\',';
$slick_settings .= 'slidesToScroll: 1,';
$slick_settings .= 'adaptiveHeight: true,';
if($layout == 'layout-3') {
	$slick_settings .= 'slidesToShow: 3,';
	$slick_settings .= 'centerMode: true,';
	$slick_settings .= 'centerPadding: "'.$center_padding.'px",';
	$slick_settings .= " cssEase: 'cubic-bezier(0.175, 0.885, 0.32, 1.275)',";
}
if ($dots == 'yes') {
	$carousel_wrap_class .= ' dots-enabled';
	if(isset($dots_style) && $dots_style !='') {
		$carousel_wrap_class .= ' dpr-dots-'.$dots_style;
	}
	$slick_settings .= 'dots: true,';
	$slick_settings .=	'customPaging: function(slider, i) {
						return \'<span data-role="none" role="button" aria-required="false" tabindex="0"></span>\';
					},';
} else {
	$slick_settings .= 'dots: false,';
}
if ($arrows == 'yes') {
	$carousel_wrap_class .= ' arrows-enabled';
	
	if(isset($arrows_position) && $arrows_position !='') {
		$carousel_wrap_class .= ' arrows-'.$arrows_position;
	}
	
	if($arrow_allways_visible == 'yes') {
		$carousel_wrap_class .= ' arrows-allways';
	}

	if($arrow_use_numbers == 'yes') {
		$carousel_wrap_class .= ' show-numbers';
	} else {
		$carousel_wrap_class .= ' hide-numbers';
	}
	$arrow_style = dpr_getSlickArrowsStyle($atts);
	
	$custom_el_css .= "#".$unique_id." a.dpr-slider-controls:hover i{".$arrow_style["style-hover-icon"]."}";
	$custom_el_css .= "#".$unique_id." a.dpr-slider-controls:hover{".$arrow_style["style-hover-bg"]."}";
	$custom_el_css .= "#".$unique_id." a.dpr-slider-controls .counter{".$arrow_style["style-navigation"]."}";
	
	$style_icon = 'style="'.$arrow_style["style-icon"].'"';
	$style_bg = 'style="'.$arrow_style["style-bg"].'"';
	$left_arrow_html .= '<i class="'.$arrow_style["icon_left"].'" '.$style_icon.'></i>';
	$right_arrow_html .= '<i class="'.$arrow_style["icon_right"].'" '.$style_icon.'></i>';	
}
if($autoplay == 'yes') {
	$slick_settings .= 'autoplay: true,';
	if($autoplay != '') {
		$slick_settings .= 'autoplaySpeed: '.esc_js($autoplay_speed).',';
	}
}
if(is_rtl()) {
	$slick_settings .= 'rtl: true,';
}
if($draggable == 'yes') {
	$slick_settings .= 'swipe: true,';
	$slick_settings .= 'draggable: true,';
} else {
	$slick_settings .= 'swipe: false,';
	$slick_settings .= 'draggable: false,';

	if($touchable == 'yes') {
		$slick_settings .= 'touchMove: true,';
	}
}
if($speed != '') {
	$slick_settings .= 'speed: '.esc_js($speed).',';
}


/* * ************************
 * Parse array of testimonials items.
 * *********************** */
if (function_exists('vc_param_group_parse_atts')) {
	$testimonials = (array) vc_param_group_parse_atts($testimonials);
}
/* * ************************
 * Partial HTML.
 * *********************** */
foreach ($testimonials as $testimonial) {
	$image_html = $title_html = $subtitle_html = $description_html =  '';
	if(isset($testimonial['image_id']) && $testimonial['image_id'] != '') {
		$image = dpr_get_attachment_image_src($testimonial['image_id'], 'full');
		$alt_text = get_post_meta($testimonial['image_id'] , '_wp_attachment_image_alt', true);
		$image_html .= '<div class="inner"><img src="'.esc_url($image[0]).'" alt ="'.esc_attr($alt_text).'" /></div>';
	}
	if(!empty($testimonial['title'])) {
		$title_html .= '<h4 class="title" ' . $title_typo_style . '>' . $testimonial['title'] . '</h4>';
	}
	if(!empty($testimonial['subtitle'])) {
		$subtitle_html .= '<div class="subtitle" ' . $subtitle_typo_style . '>' . $testimonial['subtitle'] . '</div>';
	}
	if(!empty($testimonial['description'])) {
		$description_html .= '<div class="box-content" ' . $content_typo_style . '>' . wp_kses_post($testimonial['description']) . '</div>';
	}
	$content_html .= '<div class="dpr-testimonial '.esc_attr($testimonial_class).'">';
	switch ($layout) {
		case 'layout-1':
			switch ($image_position ) {
			case 'image-bellow':
			$content_html .= '<div class="box-content-wrap">';
			$content_html .= $description_html;
			$content_html .= '</div>';
			$content_html .= '<div class="image-wrap">';
			$content_html .= $image_html;
			$content_html .= '</div>';
			$content_html .= '<div class="box-title">';
			$content_html .= $title_html;
			$content_html .= $subtitle_html;
			$content_html .= '</div>';
			break;
			case 'image-above':
			$content_html .= '<div class="box-title">';
			$content_html .= $title_html;
			$content_html .= $subtitle_html;
			$content_html .= '</div>';
			$content_html .= '<div class="image-wrap">';
			$content_html .= $image_html;
			$content_html .= '</div>';
			$content_html .= '<div class="box-content-wrap">';
			$content_html .= $description_html;
			$content_html .= '</div>';
			break;
			}
		break;
		case 'layout-2':
			switch ($image_position ) {
			case 'image-bellow':
			$content_html .= '<div class="box-content-wrap">';
			$content_html .= $description_html;
			$content_html .= '</div>';
			$content_html .= '<div class="box-title">';
			$content_html .= $title_html;
			$content_html .= $subtitle_html;
			$content_html .= '</div>';
			$thumb_nav_html .= '<div class="image-wrap">';
			$thumb_nav_html .= $image_html;
			$thumb_nav_html .= '</div>';
			break;
			case 'image-above':
			$thumb_nav_html .= '<div class="image-wrap">';
			$thumb_nav_html .= $image_html;
			$thumb_nav_html .= '</div>';
			$content_html .= '<div class="box-content-wrap">';
			$content_html .= $description_html;
			$content_html .= '</div>';
			$content_html .= '<div class="box-title">';
			$content_html .= $title_html;
			$content_html .= $subtitle_html;
			$content_html .= '</div>';
			break;
			}
		break;
		case 'layout-3':
			switch ($image_position ) {
			case 'image-bellow':
			$content_html .= '<div class="box-content-wrap">';
			$content_html .= $description_html;
			$content_html .= '</div>';
			$content_html .= '<div class="image-wrap">';
			$content_html .= $image_html;
			$content_html .= '</div>';
			$content_html .= '<div class="box-title">';
			$content_html .= $title_html;
			$content_html .= $subtitle_html;
			$content_html .= '</div>';
			break;
			case 'image-above':
			$content_html .= '<div class="box-title">';
			$content_html .= $title_html;
			$content_html .= $subtitle_html;
			$content_html .= '</div>';
			$content_html .= '<div class="image-wrap">';
			$content_html .= $image_html;
			$content_html .= '</div>';
			$content_html .= '<div class="box-content-wrap">';
			$content_html .= $description_html;
			$content_html .= '</div>';
			break;
			}
		break;
	}
	
	$content_html .= '</div>';
}

$counter_html = '<span class="counter"></span>';






/* * ************************
 * Output
 * *********************** */
$output .= '<div id="'.esc_attr($unique_id).'" class="'.esc_attr($css_class).'">';
	$output .= '<div class="dpr-carousel-wrap-inner '.$carousel_wrap_class.'">';
		if($layout == 'layout-2') {
			switch ($image_position ) {
			case 'image-bellow':
			$output .= '<div id="'.esc_attr($carousel_id).'" class="dpr-carousel">';
			$output .= $content_html;
			$output .= '</div>';
			$output .= '<div id="'.esc_attr($carousel_nav_id).'" class="dpr-carousel-nav">';
			$output .= $thumb_nav_html;
			$output .= '</div>';
			break;
			case 'image-above':
			$output .= '<div id="'.esc_attr($carousel_nav_id).'" class="dpr-carousel-nav">';
			$output .= $thumb_nav_html;
			$output .= '</div>';
			$output .= '<div id="'.esc_attr($carousel_id).'" class="dpr-carousel">';
			$output .= $content_html;
			$output .= '</div>';
			break;
			}

		} else {
			$output .= '<div id="'.esc_attr($carousel_id).'" class="dpr-carousel">';
			$output .= $content_html;
			$output .= '</div>';
		}
		if($arrows == 'yes') {
			$output .=  '<a href="#" class="dpr-slider-controls prev" '.$style_bg.' title="'.esc_attr__('Previous slide','dpr-adeline-extensions').'">'.$counter_html.$left_arrow_html.'</a>';
			$output .=  '<a href="#" class="dpr-slider-controls next" '.$style_bg.' title="'.esc_attr__('Next slide','dpr-adeline-extensions').'">'.$counter_html.$right_arrow_html.'</a>';
		}
	$output .= '</div>';
$output .= '</div>';


if(!empty($custom_el_css)) {
		$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>");'
						. '})(jQuery);'
					. '</script>';
}

echo $output;
?>
	<script>
		jQuery( document ).on( 'ready', function() {
			"use strict";
			var $carousel = jQuery('#<?php echo esc_js($carousel_id); ?>');
			var $thumbsNav = jQuery('#<?php echo esc_js($carousel_nav_id); ?>');		
			<?php if($arrows == 'yes') {
					if($arrow_use_numbers == 'yes') :  ?>
						var total_slides;
						$carousel.on('init reInit afterChange', function (event, slick, currentSlide) {
							var prev_slide_index, next_slide_index, current;
							var $prev_counter = $carousel.siblings('.dpr-slider-controls.prev').find('.counter');
							var $next_counter = $carousel.siblings('.dpr-slider-controls.next').find('.counter');
							total_slides = slick.slideCount;
							current = (currentSlide ? currentSlide : 0) + 1;
							prev_slide_index = (current - 1 < 1) ? total_slides : current - 1;
							next_slide_index = (current + 1 > total_slides) ? 1 : current + 1;
							$prev_counter.text(prev_slide_index + '/' + total_slides);
							$next_counter.text(next_slide_index + '/'+ total_slides);
						});
					<?php endif;
				} ?>
				$carousel.siblings('.dpr-slider-controls.prev').click(function(e) {
					e.preventDefault();
					$carousel.slick("slickPrev");
					$thumbsNav.slick("slickPrev");
				});
				$carousel.siblings('.dpr-slider-controls.next').click(function(e) {
					e.preventDefault();
					$carousel.slick("slickNext");
					$thumbsNav.slick("slickNext");
				});
			$carousel.slick({<?php echo $slick_settings; ?>});
			$thumbsNav.slick({
			  slidesToShow: 3,
			  slidesToScroll: 1,
			  asNavFor: $carousel,
			  dots: false,
			  centerMode: true,
			  draggable: false,
			  focusOnSelect: true,
			  arrows: false,
			  speed: <?php echo esc_js($speed*1.5); ?>,
			  centerPadding:0
			});
		} );
	</script>
<?php
