<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$unique_id = $css_animation = $el_class = $css = $svg_id = $animation_type = $animation_duration = $svg_alignment = $draw_color = $max_width = $output = '';

$atts = vc_map_get_attributes( 'dpr_animated_svg', $atts );
extract( $atts );

wp_enqueue_script('dpr-animated-svg', DPR_EXTENSIONS_PLUGIN_URL.'vc-extend/assets/frontend/js/dpr.animated.svg.js', array('jquery'), null, true);	


$unique_id = uniqid('dpr-animated-svg-').'-'.rand(1,9999);

$svg_attach = dpr_get_attachment_image_src( $svg_id,'full');
$svg_url = $svg_attach[0];


if ( '' !== $css_animation && 'none' !== $css_animation ) {
	dpr_enqueue_waypoint_js();
	dpr_enqueue_animate_css();
	$el_class .= ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
}


$css_classes = array(
	'dpr-animated-svg',
	$el_class,
	vc_shortcode_custom_css_class( $css ),
);

$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->settings['base'], $atts ) );

if($svg_url!=''){
$output .= '<div class="dpr-animated-svg-wraper '.esc_attr($svg_alignment).'">';
	$output .= '<div class="'.esc_attr($css_class).'" style="max-height:'.esc_attr($max_width).';" data-id="'.esc_attr($unique_id).'" data-type="'.esc_attr($animation_type).'" data-duration="'.esc_attr($animation_duration).'" data-stroke="'.esc_attr($draw_color).'" data-fill_color="none">';
		$output .='<div class="svg_inner_block" style="max-width:'.esc_attr($max_width).';max-height:'.esc_attr($max_width).';">';
			$output .='<object id="'.esc_attr($unique_id).'" type="image/svg+xml" data="'.esc_url($svg_url).'" ></object>';
		$output .='</div>';
	$output .= '</div>';
$output .= '</div>';}
echo $output;