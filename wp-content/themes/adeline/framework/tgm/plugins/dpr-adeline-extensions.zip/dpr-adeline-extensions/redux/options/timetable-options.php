<?php



/**



 * Woocommerce Options



 * 



 */







    Redux::setSection( $opt_name, array(



        'title'  => __( 'Timetable', 'dpr-adeline-extensions' ),



        'id'     => 'timetable_tab',



        'icon'   => 'el el-th-large'



    ) );



	require_once($options_dir . '/timetable-options/table.php');



	require_once($options_dir . '/timetable-options/filter.php');



	require_once($options_dir . '/timetable-options/single-event.php');



