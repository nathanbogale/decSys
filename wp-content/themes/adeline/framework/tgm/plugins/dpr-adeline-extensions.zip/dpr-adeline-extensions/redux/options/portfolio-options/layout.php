<?php

/**



 * Portfolio Options -> General Layout



 *



 */

Redux::setSection($opt_name, array(

    'title'      => esc_html__('General Layout', 'dpr-adeline-extensions'),

    'id'         => 'portfolio_psge_layout',

    'subsection' => true,

    'fields'     => array(

        array(

            'id'      => 'portfolio_main_content_position',

            'type'    => 'radio',

            'title'   => __('Main Page Content Position', 'dpr-adeline-extensions'),

            'options' => array(

                'above'  => 'Above Portfolio Grid',

                'bellow' => 'Bellow Portfolio Grid',

            ),

            'default' => 'above',

            'hint'    => array(

                'title'   => esc_attr__('Main Page Content Position', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set main page content (entered in WP editor or created in composer) position in relation to the portfolio grid', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'      => 'portfolio_posts_per_page',

            'type'    => 'spinner',

            'title'   => __('Portfolio Items per Page', 'dpr-adeline-extensions'),

            'desc'    => wp_kses_post(__('<small><i>Put -1 to display all portfolio items. Default is 12.</i></small>', 'dpr-adeline-extensions')),

            'default' => '12',

            'min'     => '-1',

            'step'    => '1',

            'max'     => '200',

            'hint'    => array(

                'title'   => esc_attr__('Portfolio Items per Page', 'dpr-adeline-extensions'),

                'content' => esc_attr__('You can set default portfolio items per page count for portfolio page.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'      => 'portfolio_columns',

            'type'    => 'slider',

            'title'   => __('Columns', 'dpr-adeline-extensions'),

            'default' => '3',

            'min'     => '1',

            'step'    => '1',

            'max'     => '10',

            'hint'    => array(

                'title'   => esc_attr__('Portfolio Columns', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set default columns count on portfolio page. This value can be overwriten in individual page or grid setting.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'      => 'portfolio_tablet_columns',

            'type'    => 'slider',

            'title'   => __('Columns: Tablet', 'dpr-adeline-extensions'),

            'default' => '2',

            'min'     => '1',

            'step'    => '1',

            'max'     => '10',

            'hint'    => array(

                'title'   => esc_attr__('Portfolio Tablet Columns', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set default tablet columns count on portfolio page. This value can be overwriten in individual page or grid setting.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'      => 'portfolio_mobile_columns',

            'type'    => 'slider',

            'title'   => __('Columns: Mobile', 'dpr-adeline-extensions'),

            'default' => '1',

            'min'     => '1',

            'step'    => '1',

            'max'     => '10',

            'hint'    => array(

                'title'   => esc_attr__('Portfolio Mobile Columns', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set default mobile columns count on portfolio page. This value can be overwriten in individual page or grid setting.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'      => 'portfolio_masonry',

            'type'    => 'switch',

            'default' => false,

            'title'   => esc_html__('Use Masonry', 'dpr-adeline-extensions'),

            'hint'    => array(

                'title'   => esc_attr__('Use Masonry', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Use masonry for protfolio items grid by default.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'      => 'portfolio_pagination_style',

            'type'    => 'radio',

            'title'   => __('Pagination Style', 'dpr-adeline-extensions'),

            'options' => array(

                'none'      => 'No Pagination',

                'default'   => 'Default Numbered Pagination',

                'load_more' => 'Load More Button',

            ),

            'default' => 'default',

            'hint'    => array(

                'title'   => esc_attr__('Pagination Style', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set default pagination style', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'portfolio_pagination_position',

            'type'     => 'radio',

            'title'    => __('Pagination Position', 'dpr-adeline-extensions'),

            'options'  => array(

                'left'   => 'Left',

                'center' => 'Center',

                'right'  => 'Right',

            ),

            'default'  => 'left',

            'required' => array('portfolio_pagination_style', 'equals', 'default'),

            'hint'     => array(

                'title'   => esc_attr__('Pagination Position', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set default pagination position', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'portfolio_pagination_loadmore_button_text',

            'type'     => 'text',

            'title'    => __('Load More: Button Text', 'dpr-adeline-extensions'),

            'default'  => 'Load More',

            'required' => array('portfolio_pagination_style', 'equals', 'load_more'),

            'hint'     => array(

                'title'   => esc_attr__('Load More: Button Text', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set load more button text.', 'dpr-adeline-extensions'),

            ),

        ),

        array(

            'id'       => 'portfolio_pagination_loadmore_nomore_text',

            'type'     => 'text',

            'title'    => __('Load More: End Text', 'dpr-adeline-extensions'),

            'default'  => 'No more items to load',

            'required' => array('portfolio_pagination_style', 'equals', 'load_more'),

            'hint'     => array(

                'title'   => esc_attr__('Load More: End Text', 'dpr-adeline-extensions'),

                'content' => esc_attr__('Set load more end text.', 'dpr-adeline-extensions'),

            ),

        ),

    ),

));
