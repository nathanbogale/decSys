<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$output = $custom_el_css = $el_class  = $source_type = $items_to_display = $categories_include = $categories_exclude = $format_exclude = $item_list = $order_by = $order = '';
$columns = $columns_tablet = $columns_mobile = $enable_masonry = $items_margin = $items_margin_bottom = $items_style = $tiled = $items_background_color = $items_border_width = $items_border_color = '';
$item_shadow = $item_shadow_custom = $item_shadow_hover = $item_shadow_hover_custom = $entry_hover_animation = $entry_appear_animation = $appear_animation_duration = $appear_animation_easing = $appear_animation_delay = '';
$entry_img_size = $entry_img_width = $entry_img_height = $image_border_radius = $entry_overlay_type = $overlay_color = $overlay_gradient = $entry_overlay_type_hover = $overlay_color_hover = $overlay_gradient_hover = '';
$display_media = $conent_alignment = $display_title = $display_excerpt  = $excerpt_length = $meta_included = $display_category_badge = $title_color = $title_color_hover = $content_color = $meta_color = $category_color = $category_bg_color = $image_position = '';
$enable_filter = $enable_all = $all_text = $filter_position = $filter_taxonomy = $filter_bar_margin = $filter_buttons_spacing = $filter_buttons_vertical_padding = $filter_buttons_horizontal_padding = '';$filter_buttons_border_radius = $filter_buttons_bg_color = $filter_buttons_bg_color_hover = $filter_buttons_color = $filter_buttons_color_hover = $filter_border_color = $filter_border_color_hover = '';
$title_font_size = $title_line_height = $title_letter_spacing = $title_font_style = $title_use_google_fonts = $title_google_font = '';
$content_font_size = $content_line_height = $content_letter_spacing = $content_font_style = $content_use_google_fonts = $content_google_font = '';
$filter_font_size = $filter_line_height = $filter_letter_spacing = $filter_font_style = $filter_use_google_fonts = $filter_google_font = '';

$atts = vc_map_get_attributes(  $this->getShortcode(), $atts  );
extract( $atts );

$el_class = $this->getExtraClass( $el_class );
if ( '' !== $css_animation && 'none' !== $css_animation ) {
	dpr_enqueue_waypoint_js();
	dpr_enqueue_animate_css();
	$el_class .= ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
}

if (isset($entry_hover_animation) && ($entry_hover_animation == 'dpr-image-tilt' || $entry_hover_animation == 'dpr-item-tilt')) {
    wp_enqueue_script('jquery-tilt', DPR_EXTENSIONS_PLUGIN_URL . 'vc-extend/assets/frontend/js/universal-tilt.min.js', array('jquery'), null, true);
    wp_enqueue_script('dpr-portfolio-scat-grid-hover-animations', DPR_EXTENSIONS_PLUGIN_URL . 'vc-extend/assets/frontend/js/dpr.scat.grid.anim.js', array('jquery'), null, true);
}
$unique_id = uniqid('dpr-blog-grid-').'-'.rand(1,9999);
$template_file = DPR_EXTENSIONS_PLUGIN_PATH.'vc-extend/vc-templates/dpr-blog-grid/' . $items_style . '.php';
// Enqueue AOS JS if appear animation selected

if( 'none' != $entry_appear_animation ) {
	wp_enqueue_script( 'aos' );
}


/* Element classes */
$wrap_classes 	   	= array( 'portfolio-items', 'clr', 'tablet-col', 'mobile-col' );
$wrap_classes[] 	= 'tablet-' . $columns_tablet . '-col';
$wrap_classes[] 	= 'mobile-' . $columns_mobile . '-col';
// If masonry
if ( $enable_masonry == 'yes' && $enable_filter !='yes' ) {
	$wrap_classes[] = 'masonry-grid';
}
// Enable isotope if filter
if ( $enable_filter =='yes' ) {
	$wrap_classes[] = 'isotope-grid';
}

$wrap_classes 		= implode( ' ', $wrap_classes );


$css_classes = array(
	'dpr-portfolio-grid dpr-blog-grid',
	$unique_id,
	'grid-style-'.$items_style,
	$wrap_classes,
	$el_class,
);

$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->settings['base'], $atts ) );


$item_classes 	= array('blog-item-inner','clr');
if ( 'custom' != $item_shadow && '' != $item_shadow ) $item_classes[] = 'dpr-shadow-'.$item_shadow;
if ( 'custom' != $item_shadow_hover && '' != $item_shadow_hover ) $item_classes[] = 'dpr-shadow-onhover-'.$item_shadow_hover;


$item_classes 		= implode( ' ', $item_classes );

$aos_data = '';

if ($entry_appear_animation != 'none')  {
	$aos_data .= ' data-aos-once ="true" data-aos="'.$entry_appear_animation.'"';
	if( !empty( $appear_animation_easing ) ) {
		$aos_data .= ' data-aos-easing="'.$appear_animation_easing.'"';
	}
	if( !empty( $appear_animation_duration ) ) {
		$aos_data .= ' data-aos-duration="'. $appear_animation_duration .'"';
	}
	if( !empty( $appear_animation_delay ) ) {
		$aos_data .= ' data-aos-delay="'.$appear_animation_delay.'"';
	}
}

/* * ************************
 * Styles and custom CSS
 * *********************** 
*/
$title_typo_style = dpr_generate_typography_style('', $title_font_size, $title_line_height, $title_letter_spacing, $title_font_style,$title_google_font);
$content_typo_style = dpr_generate_typography_style('', $content_font_size, $content_line_height, $content_letter_spacing, $content_font_style,$content_google_font);
$filter_typo_style = dpr_generate_typography_style('', $filter_font_size, $filter_line_height, $filter_letter_spacing, $filter_font_style,$filter_google_font);

//Grid 
if(empty($items_margin) || !isset($items_margin)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .portfolio-item {padding: 0;}';
	$custom_el_css .= '.'.esc_js($unique_id).' {margin-left: 0;margin-right: 0;}';
}
if(isset($items_margin) && !empty($items_margin)) {
	$custom_el_css .= '.'.esc_js($unique_id).' .portfolio-item {padding: '.esc_js(round($items_margin/2)).'px;}';
	$custom_el_css .= '.'.esc_js($unique_id).' {margin-left: -'.esc_js(round($items_margin/2)).'px;margin-right: -'.esc_js(round($items_margin/2)).'px;}';
}
$custom_el_css .= '.'.esc_js($unique_id).' .blog-item.posts-grid.entry-style-tiled .blog-item-inner {margin-bottom: '.esc_js($items_margin_bottom).'px;}';

if(isset($image_border_radius) && !empty($image_border_radius)) { 
$custom_el_css .= '.'.esc_js($unique_id).' .blog-item.posts-grid.entry-style-tiled .blog-item-inner {border-radius: '.esc_js($image_border_radius).'px;}';
$custom_el_css .= '.'.esc_js($unique_id).'.grid-style-thumb .thumbnail, .'.esc_js($unique_id).'.grid-style-minimal-post .thumbnail {border-radius: '.esc_js($image_border_radius).'px;}';
}
if(isset($items_border_width) && !empty($items_border_width)) { 
$custom_el_css .= '.'.esc_js($unique_id).' .blog-item.posts-grid.entry-style-tiled .blog-item-inner {border-width: '.esc_js($items_border_width).'px;}';
}
if(isset($items_border_color) && !empty($items_border_color)) { 
$custom_el_css .= '.'.esc_js($unique_id).' .blog-item.posts-grid.entry-style-tiled .blog-item-inner {border-color: '.esc_js($items_border_color).';}';
}
if(isset($items_background_color) && !empty($items_background_color)) { 
$custom_el_css .= '.'.esc_js($unique_id).' .blog-item.posts-grid.entry-style-tiled .blog-item-inner:not(.post-link-wrapper,.post-quote-wrapper) {background-color: '.esc_js($items_background_color).';}';
}
if(isset($title_color) && !empty($title_color)) { 
$custom_el_css .= '.'.esc_js($unique_id).' .blog-item-title.entry-title a {color: '.esc_js($title_color).'!important;}';
}
if(isset($title_color_hover) && !empty($title_color_hover)) { 
$custom_el_css .= '.'.esc_js($unique_id).' .blog-item-title.entry-title a:hover {color: '.esc_js($title_color_hover).'!important;}';
}
if(isset($meta_color) && !empty($meta_color)) { 
$custom_el_css .= '.'.esc_js($unique_id).' .meta li , .'.esc_js($unique_id).' .meta li a, .'.esc_js($unique_id).' .meta li i {color: '.esc_js($meta_color).'!important;}';
}
if(isset($content_color) && !empty($content_color)) { 
$custom_el_css .= '.'.esc_js($unique_id).' .blog-item-inner {color: '.esc_js($content_color).';}';
}
if(isset($category_color) && !empty($category_color)) { 
$custom_el_css .= '.'.esc_js($unique_id).' .category-badge a {color: '.esc_js($category_color).';}';
}
if(isset($category_bg_color) && !empty($category_bg_color)) { 
$custom_el_css .= '.'.esc_js($unique_id).' .category-badge {background-color: '.esc_js($category_bg_color).';}';
}


//Overlay 
if(isset($overlay_color) && !empty($overlay_color) && $entry_overlay_type == 'solid') {
	$custom_el_css .= '.'.esc_js($unique_id).' .blog-item.post .thumbnail .overlay  {background-color: '.esc_js($overlay_color).';}';
}
if(isset($entry_overlay_type) && $entry_overlay_type == 'gradient') {
	if(isset($overlay_gradient) && !empty($overlay_gradient)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .blog-item.post .thumbnail .overlay {'.esc_js(adeline_gradientToBgCSS ($overlay_gradient)).'}';
	}
}

if(isset($overlay_color_hover) && !empty($overlay_color_hover) && $entry_overlay_type_hover == 'solid') {
	$custom_el_css .= '.'.esc_js($unique_id).' .blog-item.post:hover .thumbnail .overlay  {background-color: '.esc_js($overlay_color_hover).';}';
}
if(isset($entry_overlay_type_hover) && $entry_overlay_type_hover == 'gradient') {
	if(isset($overlay_gradient_hover) && !empty($overlay_gradient_hover)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .blog-item.post:hover .thumbnail .overlay {'.esc_js(adeline_gradientToBgCSS ($overlay_gradient_hover)).'}';
	}
}

//Filter
if($enable_filter == 'yes') {
	if(isset($filter_bar_margin) && !empty($filter_bar_margin)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .portfolio-filters {margin-bottom: '.esc_js($filter_bar_margin).'px;}';
	}
	if(isset($filter_buttons_spacing) && !empty($filter_buttons_spacing)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .portfolio-filters li {margin-right: '.esc_js($filter_buttons_spacing).'px;}';
	}
	if(isset($filter_buttons_vertical_padding) && !empty($filter_buttons_vertical_padding)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .portfolio-filters li a {padding-top: '.esc_js($filter_buttons_vertical_padding).'px; padding-bottom: '.esc_js($filter_buttons_vertical_padding).'px;}';
	}
	if(isset($filter_buttons_horizontal_padding) && !empty($filter_buttons_horizontal_padding)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .portfolio-filters li a {padding-left: '.esc_js($filter_buttons_horizontal_padding).'px; padding-right: '.esc_js($filter_buttons_horizontal_padding).'px;}';
	}
	if(isset($filter_buttons_border_radius) && !empty($filter_buttons_border_radius)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .portfolio-filters li a {border-radius: '.esc_js($filter_buttons_border_radius).'px;}';
	}
	if(isset($filter_buttons_bg_color) && !empty($filter_buttons_bg_color)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .portfolio-filters li a {background-color: '.esc_js($filter_buttons_bg_color).';}';
	}
	if(isset( $filter_buttons_bg_color_hover) && !empty( $filter_buttons_bg_color_hover)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .portfolio-filters li a:hover {background-color: '.esc_js( $filter_buttons_bg_color_hover).';}';
	}
	if(isset($filter_buttons_color) && !empty($filter_buttons_color)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .portfolio-filters li a {color: '.esc_js($filter_buttons_color).';}';
	}
	if(isset($filter_buttons_color_hover) && !empty($filter_buttons_color_hover)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .portfolio-filters li a:hover {color: '.esc_js($filter_buttons_color_hover).';}';
	}
	if(isset($filter_border_color) && !empty($filter_border_color)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .portfolio-filters li a {border-color: '.esc_js($filter_border_color).';}';
	}
	if(isset($filter_border_color_hover) && !empty($filter_border_color_hover)) {
		$custom_el_css .= '.'.esc_js($unique_id).' .portfolio-filters li a:hover {border-color: '.esc_js($filter_border_color_hover).';}';
	}
}


/* * ************************
 * Query args
 * *********************** 
*/

if($source_type != 'list') {
		$args = array(
			'post_type'      	=> 'post',
			'posts_per_page' 	=> $items_to_display,
			'order'				=> $order,
			'orderby'			=> $order_by,
			'post_status' 		=> 'publish',
			'tax_query' 		=> array(
				'relation' 		=> 'AND',
			),
		);
		
		// Categories IDs
		if ( ! empty( $categories_include ) ) {
		
			// Convert to array
			$categories_include = explode( ',', $categories_include );
		
			// Add to query arg
			$args['tax_query'][] = array(
				'taxonomy' => 'category',
				'field'    => 'term_id',
				'terms'    => $categories_include,
				'operator' => 'IN',
			);
		
		}
		
		// Order
		if ( $order != '' ) {
			$args['order'] = $order;
		}
		// Orderby
		if ( $order_by != 'none' ) {
			$args['orderby'] = $order_by;
		}
		
		// Exclude category
		if ( ! empty( $categories_exclude ) ) {
		
			// Convert to array
			$categories_exclude = explode( ',', $categories_exclude );
		
			// Add to query arg
			$args['tax_query'][] = array(
				'taxonomy' => 'category',
				'field'    => 'term_id',
				'terms'    => $categories_exclude,
				'operator' => 'NOT IN',
			);
		
		}
		// Exclude post format
		if ( ! empty( $format_exclude ) ) {
		
			// Convert to array
			$format_exclude = explode( ',', $format_exclude );
		
			// Add to query arg
			$args['tax_query'][] = array(
				'taxonomy' => 'post_format',
				'field'    => 'term_id',
				'terms'    => $format_exclude,
				'operator' => 'NOT IN',
			);
		
		}
} else {
	$items_ids = array();
	if(isset($item_list) && !empty($item_list) && function_exists('vc_param_group_parse_atts')) {
	$item_list = (array) vc_param_group_parse_atts($item_list);
		foreach($item_list as $item) {
			$items_ids[] = $item['post_item'];
		}
	}
		$args = array(
		'post_type'      	=> 'post',
		'post__in'  => $items_ids
		);
		
}

/* * ************************
 * Partial HTML.
 * *********************** */

// Filter
$filter_html = '';

if ( $enable_filter =='yes' ) {

	// Get taxonomy
	if ( 'categories' == $filter_taxonomy ) {
		$taxonomy = 'category';
		$tax = 'cat';
	} else if ( 'tags' == $filter_taxonomy ) {
		$taxonomy = 'post_tag';
		$tax = 'tag';
	}

	// Filter args
	$filter_args = array(
		'taxonomy' 	 => $taxonomy,
		'hide_empty' => 1,
	);

	// Get filter terms
	$filter_terms = get_terms( $filter_args );

	// Class
	$filter_classes 	   	= array( 'portfolio-filters' );

	// Filter position
	if ( 'center' != $filter_position ) {
		$filter_classes[] 	= 'filter-pos-' . $filter_position;
	}
	
	$filter_classes 		= implode( ' ', $filter_classes ); 

	$filter_html .= '<ul class="'.$filter_classes.'">';
	if ( $enable_all == 'yes' ) {
	$filter_html .= '<li class="portfolio-filter active"><a href="#" data-filter="*"  '.$filter_typo_style.'>'. esc_html( $all_text ).'</a></li>';
	}
	foreach ( $filter_terms as $term ) { 
		$filter_html .= '<li class="portfolio-filter"><a href="#" data-filter=".cat-'. $term->term_id.'" '.$filter_typo_style.'>'.$term->name.'</a></li>';
	} 
	$filter_html .= '</ul>';
}

$dpr_blog_query = new WP_Query( $args );


/* * ************************
 * Output
 * *********************** */
if ( $dpr_blog_query->have_posts() ) {

echo '<div id="'.esc_attr($unique_id).'" class="'.esc_attr($css_class).'">';
echo $filter_html;

// If masonry
if ( $enable_masonry == 'yes' ) {
	$data = 'masonry';
} else {
	$data = 'fitRows';
} 
echo '<div class="portfolio-wrap" data-layout="'.esc_attr( $data ).'">';
// Loop
while ( $dpr_blog_query->have_posts() ) : $dpr_blog_query->the_post();
	
	// Get posts format
	$format_classes = '';
	$format = get_post_format();
	if ( $items_style == 'default') {
	if($format == 'quote') $format_classes = 'post-quote-wrapper'; 
	if($format == 'link') $format_classes = 'post-link-wrapper';
	}
	// Inner classes
	$inner_classes 		= array( 'portfolio-item', 'blog-item', 'clr', 'isotope-entry', 'posts-grid', 'col' );
	$inner_classes[] 	= 'column-'. $columns;
	if ( ! has_post_thumbnail()
	&& '' == get_post_meta( get_the_ID(), 'dpr_post_self_hosted_shortcode', true )
	&& '' == get_post_meta( get_the_ID(), 'dpr_post_oembed', true ) ) {
	$inner_classes[] = 'no-featured-image';
	}
	if ($display_title != 'yes') $inner_classes[] = 'no-title';
	if ($display_excerpt != 'yes') $inner_classes[] = 'no-excerpt';
	if ($display_category_badge == 'yes') $inner_classes[] = 'with-category-badge';
	if ( 'none' != $entry_hover_animation ) $inner_classes[] = $entry_hover_animation;
	if ($tiled == 'yes') $inner_classes[] = 'entry-style-tiled';
	// If filter
	if ( $enable_filter && ! empty( $filter_terms ) ) {

		$terms_list = wp_get_post_terms( get_the_ID(), $taxonomy );

		foreach ( $terms_list as $term ) {
			$inner_classes[] = $tax . '-' . $term->term_id;
		}

	}
	$inner_classes = get_post_class($inner_classes, get_the_ID());
	$inner_classes 		= implode( ' ', $inner_classes );
	echo '<article  id="post-'. get_the_ID().'" class="'. esc_attr( $inner_classes ).'">';
	echo '<div class="'.$format_classes.' '. $item_classes.'" '.$aos_data.'>';
	if(file_exists($template_file)) {
		include($template_file);
	}
	echo '</div>';
	echo '</article>';


// End entry loop
endwhile;



echo '</div>';
if(!empty($custom_el_css)) {
		$output .= '<script>'
						. '(function($) {'
							. '$("head").append("<style>'.$custom_el_css.'</style>");'
						. '})(jQuery);'
					. '</script>';
}
echo '</div>';

// Reset the post data to prevent conflicts with WP globals
wp_reset_postdata(); 

} else {
	$output .= '<p class="portfolio-not-found">'.esc_html_e( 'You have no items to display', 'dpr-adeline-extensions' ).'</p>';
}

echo $output;